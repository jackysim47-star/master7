# MASTER7 V173 Payment Scope Gate Update

日期：2026-11-13（MYT）  
版本：`17.0.0-selfbuilt.173-staff-setup-route`

## 已实施

- `MYR_PRIMARY` 主范围包含 VPay MYR、GSPAY MYR、1MPAY MYR。
- `paymentReady` 与 `primaryPaymentReady` 只计算上述三个 MYR profile。
- GSPAY USDT 保留在 acceptance ledger，但属于 `separate_pending`；没有合同、UAT、签名、查单、恢复和对账证据时仍为 `contract_missing` / `enabled=false`。
- GSPAY+ 没有被加入正式 provider scope，等待官方身份确认。
- Staff 的生产验收状态增加主范围和独立范围状态；Customer API 未增加交易接口。
- 所有生产 flags、游戏、充值、提款、钱包、回调和结算开关继续关闭。

## 当前边界

这一步只改变本地验收计算与只读状态表达，不代表任何厂家接口已连接，也不代表 MYR UAT 已通过。没有调用供应商、没有创建订单、没有移动资金、没有执行真钱游戏或生产部署。
