# MASTER7 V173 Auto Setup

## 命令

在 V173 Render staging 源码包根目录执行：

```text
npm run setup:v173
```

也可以输出机器可读结果：

```text
npm run setup:v173 -- --json
```

## 命令会检查

- V173 release 和必要源码/测试文件
- staging `PUBLIC_ORIGIN` 与允许来源
- 游戏、充值、提款、恢复相关开关是否明确为 `false`
- 合同 intake 和 fail-closed 交接入口是否存在
- 合同 scope 是否仍准确登记 38 个游戏品牌、43 个 profile、3 个 MYR 主支付 profile
- MYR 主支付验收是否与 GSPAY USDT 独立待确认范围分开登记
- UAT package 的五项游戏能力、六项支付能力和证据记录字段是否存在
- OpenAI 是否仅保持 server-only、非交易用途
- 上传审批是否为 safe layered 模式，且收据自动入账硬性关闭
- 两个正式域名的 DNS/TLS 是否仍待外部验证
- Lebet/支付合同、UAT 和生产签收是否缺失

## 安全行为

Auto Setup 只做本地预检：不会调用供应商、写数据库、读取或打印密钥、修改 DNS、部署 Render 或启用真实游戏/充值/提款/钱包。

预检成功只代表 staging 配置满足安全初始化条件；生产仍必须等外部证据，结果不会自动变为 GO。
