# MASTER7 V173 UAT Package Schema Update

日期：2026-11-13（MYT）  
版本：`17.0.0-selfbuilt.173-staff-setup-route`

Staff 只读 `GET /api/admin/integration-contracts` 提供机器可读 `uatPackage`：游戏五项能力、支付六项能力、证据记录字段及每项需要的官方合同资料。

VPay MYR、GSPAY MYR、1MPAY MYR 属于 `primary_myr`；GSPAY USDT 属于 `separate_pending`；GSPAY+ 是 `identity_unresolved` 且不进入正式 scope。

该 schema 不接收凭据、不调用供应商、不创建订单、不移动资金，也不会自动 accepted。Owner 通过既有 immutable acceptance ledger 写证据，Staff 只读查看。
