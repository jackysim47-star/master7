# MASTER7 V173 Integration Contract Intake

版本：`17.0.0-selfbuilt.173-staff-setup-route`  
性质：只读、非交易、staging 交接资料

## 新增只读入口

Owner 或 Staff 登录后可读取：

```text
GET /api/admin/integration-contracts
```

该入口只返回供应商合同所需的证据字段名称和当前 fail-closed 状态，不返回密码、密钥、Token、商户号或供应商响应，也不会调用供应商、创建订单、启动游戏或移动钱包资金。

范围摘要：38 个游戏品牌、43 个 lobby profile、1 个 Lebet gateway、3 个 MYR 主支付 profile；USDT 作为 1 个独立待确认支付 profile，不计入 MYR 主支付数量。

生产验收计算使用 `MYR_PRIMARY` 主范围：VPay MYR、GSPAY MYR、1MPAY MYR。GSPAY USDT 保留为 `separate_pending`，GSPAY+ 在官方身份确认前不进入正式 provider scope。主范围和独立范围只影响只读验收状态，不会启用交易能力。

Staff 只读结果同时提供 `uatPackage`：游戏五项能力、支付六项能力、证据记录字段和每项所需合同资料。Owner 仍只能通过既有 immutable acceptance ledger 写入证据；Staff 只读查看，资料齐全也不会自动 accepted。

## 当前登记

| 类型 | Profile | 状态 | Runtime capability |
|---|---|---|---|
| Game | Lebet | `contract_missing` | launch / wallet / recovery / live 全部 false |
| Payment | VPay MYR | `documented_not_verified` | order / callback / recovery / settlement 全部 false |
| Payment | GSPAY MYR | `documented_not_verified` | order / callback / recovery / settlement 全部 false |
| Payment | GSPAY USDT | `contract_missing` | order / callback / recovery / settlement 全部 false |
| Payment | 1MPAY MYR | `documented_not_verified` | order / callback / recovery / settlement 全部 false |

## 通过资料后才可进入的评审项

- 官方 API 版本与 UAT/生产范围
- 认证、签名、时钟和重放规则
- 游戏目录、玩家映射、启动和回调合同
- 钱包模式、余额、转账、查询恢复和结算规则
- 充值下单、回调、查询恢复、钱包入账和商户对账合同
- 厂商批准的 UAT 测试范围与证据引用

即使资料完整，也不会自动把 profile 标记为 implemented、enabled 或 live-ready；必须经过现有 acceptance ledger、runtime readiness 和生产审批闸门。
