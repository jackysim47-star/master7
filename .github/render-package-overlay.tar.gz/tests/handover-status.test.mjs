import assert from 'node:assert/strict';
import test from 'node:test';
import {getV173HandoverStatus,OFFICIAL_ENTRY_HOSTS} from '../lib/handover-status.ts';

test('V173 handover status describes the shared entry contract and remains fail-closed',()=>{
 const status=getV173HandoverStatus({
  release:'17.0.0-selfbuilt.173-staff-setup-route',
  flags:{readOnly:true,newDepositsEnabled:false,newGameLaunchesEnabled:false,newPayoutsEnabled:false,transactionsEnabled:false,realPayments:false}
 });
 assert.deepEqual(status.entry.hosts,OFFICIAL_ENTRY_HOSTS);
 assert.equal(status.entry.mode,'same_application');
 assert.equal(status.entry.roleResolution,'authenticated_session');
 assert.deepEqual(status.roles,['owner','staff','member']);
 assert.deepEqual(status.roleLabels,{owner:'Master Admin',staff:'Staff',member:'Member'});
 assert.equal(status.runtime.readOnly,true);
 assert.equal(status.production.status,'NO-GO');
 assert.equal(status.production.ready,false);
 assert.ok(status.production.blockers.includes('supplier_contract_and_uat_not_verified'));
 assert.ok(status.production.blockers.includes('official_dns_tls_not_verified'));
 assert.ok(status.production.blockers.includes('real_money_capabilities_disabled'));
 assert.doesNotMatch(JSON.stringify(status),/password|secret|apiKey|token|merchantId/i);
});

test('V173 handover status does not convert open runtime flags into production approval',()=>{
 const status=getV173HandoverStatus({
  release:'17.0.0-selfbuilt.173-staff-setup-route',
  flags:{readOnly:false,newDepositsEnabled:true,newGameLaunchesEnabled:true,newPayoutsEnabled:true,transactionsEnabled:true,realPayments:true}
 });
 assert.equal(status.production.status,'NO-GO');
 assert.equal(status.production.ready,false);
 assert.equal(status.runtime.newDepositsEnabled,true);
 assert.ok(status.production.blockers.includes('production_signoff_not_verified'));
});
