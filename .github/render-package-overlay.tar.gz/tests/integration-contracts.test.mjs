import assert from 'node:assert/strict';
import test from 'node:test';
import {getIntegrationContractIntake} from '../lib/integration-contracts.ts';

test('integration contract intake is documentation-only and fail-closed',()=>{
 const intake=getIntegrationContractIntake();
 assert.equal(intake.documentationOnly,true);
 assert.equal(intake.gatewayCount,1);
 assert.equal(intake.gameProfileCount,43);
 assert.deepEqual(intake.scope,{gameBrandCount:38,gameProfileCount:43,gatewayCount:1,primaryPaymentProfileCount:3,separatePaymentProfileCount:1});
 assert.deepEqual(intake.uatPackage.evidenceRecordFields,['environment','release_version','provider_profile','capability','observed_at_myt','verified_by','evidence_reference','evidence_sha256','result']);
 assert.deepEqual(Object.keys(intake.uatPackage.gameCapabilities),['catalogue','launch','wallet','settlement','recovery']);
 assert.deepEqual(Object.keys(intake.uatPackage.paymentCapabilities),['order','payment','callback','query_recovery','wallet_credit','merchant_settlement']);
 assert.deepEqual({ownerEvidenceWriteOnly:intake.uatPackage.ownerEvidenceWriteOnly,staffReadOnly:intake.uatPackage.staffReadOnly,autoAcceptance:intake.uatPackage.autoAcceptance,productionSwitchesRemainClosed:intake.uatPackage.productionSwitchesRemainClosed},{ownerEvidenceWriteOnly:true,staffReadOnly:true,autoAcceptance:false,productionSwitchesRemainClosed:true});
 assert.deepEqual(intake.excludedProviderCandidates,[{providerId:'gspay_plus',status:'identity_unresolved',formalScope:false,enabled:false}]);
 assert.equal(intake.gameProviders.length,44);
 assert.deepEqual(intake.gameProviders[0].providerId,'lebet');
 assert.equal(intake.gameProviders[0].role,'gateway');
 assert.equal(intake.gameProviders[0].status,'contract_missing');
 assert.equal(intake.gameProviders.filter(item=>item.role==='profile').length,43);
 assert.ok(intake.gameProviders.some(item=>item.profileId==='jdb_myr'&&item.implemented===true));
 assert.deepEqual(intake.paymentProviders.map(item=>item.providerId),['vpay_myr','gspay_myr','gspay_usdt','onempay_myr']);
 assert.equal(intake.paymentProviders.find(item=>item.providerId==='gspay_usdt').status,'contract_missing');
 assert.deepEqual(intake.paymentProviders.map(item=>[item.providerId,item.acceptanceScope]),[['vpay_myr','primary_myr'],['gspay_myr','primary_myr'],['gspay_usdt','separate_pending'],['onempay_myr','primary_myr']]);
 for(const item of intake.gameProviders){
  assert.equal(item.enabled,false,item.providerId);
  assert.equal(item.liveReady,false,item.providerId);
  assert.equal(item.uatReady,false,item.providerId);
  assert.equal(item.accepted,false,item.providerId);
  assert.deepEqual(item.acceptanceCapabilities,['catalogue','launch','wallet','settlement','recovery']);
  assert.ok(item.requiredEvidence.length>0,item.providerId);
 }
 for(const item of intake.paymentProviders){
  assert.equal(item.enabled,false,item.providerId);
  assert.equal(item.liveReady,false,item.providerId);
  assert.equal(item.uatReady,false,item.providerId);
  assert.equal(item.accepted,false,item.providerId);
  assert.deepEqual(item.acceptanceCapabilities,['order','payment','callback','query_recovery','wallet_credit','merchant_settlement']);
  assert.ok(item.requiredEvidence.length>0,item.providerId);
 }
});

test('contract intake never reflects credentials or grants runtime capability',()=>{
 const intake=getIntegrationContractIntake();
 const serialized=JSON.stringify(intake);
 for(const value of ['password','secret','apiKey','token','merchantId'])assert.doesNotMatch(serialized,new RegExp(value,'i'));
 assert.ok(intake.gameProviders.every(item=>item.launchReady===false&&item.walletReady===false&&item.recoveryReady===false));
 assert.ok(intake.paymentProviders.every(item=>item.orderReady===false&&item.callbackReady===false&&item.settlementVerified===false));
});
