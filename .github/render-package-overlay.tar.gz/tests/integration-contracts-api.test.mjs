import assert from 'node:assert/strict';
import test from 'node:test';
import {handle} from '../lib/backend.ts';

function contextFor(userId){
 const users={
  owner:{id:'owner',username:'owner',role:'owner',approved:1,csrf:'owner-csrf',created_at:0},
  member:{id:'member',username:'member',role:'member',approved:1,csrf:'member-csrf',created_at:0},
 };
 const db={prepare(sql){
  let args=[];
  return {bind(...values){args=values;return this;},async first(){return sql.includes('FROM users WHERE id=?')?users[args[0]]??null:null;}};
 }};
 return {db,identity:{userId,email:`${userId}@example.test`},ownerEmail:'owner@example.test'};
}

test('staff integration contract endpoint is read-only and exposes no credentials',async()=>{
 const response=await handle(new Request('https://portal.example.test/api/admin/integration-contracts'),contextFor('owner'));
 assert.equal(response.status,200);
 const data=await response.json();
 assert.equal(data.documentationOnly,true);
 assert.equal(data.gatewayCount,1);
 assert.equal(data.gameProfileCount,43);
 assert.deepEqual(data.scope,{gameBrandCount:38,gameProfileCount:43,gatewayCount:1,primaryPaymentProfileCount:3,separatePaymentProfileCount:1});
 assert.deepEqual(Object.keys(data.uatPackage.gameCapabilities),['catalogue','launch','wallet','settlement','recovery']);
 assert.deepEqual(Object.keys(data.uatPackage.paymentCapabilities),['order','payment','callback','query_recovery','wallet_credit','merchant_settlement']);
 assert.equal(data.uatPackage.autoAcceptance,false);
 assert.equal(data.uatPackage.productionSwitchesRemainClosed,true);
 assert.deepEqual(data.excludedProviderCandidates,[{providerId:'gspay_plus',status:'identity_unresolved',formalScope:false,enabled:false}]);
 assert.equal(data.gameProviders.length,44);
 assert.equal(data.gameProviders[0].providerId,'lebet');
 assert.equal(data.gameProviders[0].liveReady,false);
 assert.equal(data.paymentProviders.length,4);
 assert.equal(data.paymentProviders.find(item=>item.providerId==='gspay_usdt').acceptanceScope,'separate_pending');
 assert.doesNotMatch(JSON.stringify(data),/password|secret|apiKey|token|merchantId/i);
});

test('member cannot read staff integration contract intake',async()=>{
 const response=await handle(new Request('https://portal.example.test/api/admin/integration-contracts'),contextFor('member'));
 assert.equal(response.status,403);
});
