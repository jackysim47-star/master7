export { GET,dynamic } from '../../../api/[...path]/route';
