/**
 * Non-secret supplier contract inventory used by the staging handover.
 *
 * This module deliberately contains documentation requirements only. It does
 * not accept credentials, call a supplier, create an order, move funds, or
 * grant any game capability. Runtime readiness remains owned by the existing
 * payment and game acceptance gates.
 */

import {GAME_PROVIDER_PROFILES} from './game-provider-registry.ts';
import {GAME_PROVIDER_ACCEPTANCE_CAPABILITIES,type GameProviderAcceptanceCapability} from './game-provider-acceptance.ts';
import {PAYMENT_ACCEPTANCE_CAPABILITIES} from './production-acceptance.ts';

export type IntegrationContractStatus = 'contract_missing' | 'documented_not_verified';

export type GameIntegrationContract = Readonly<{
  providerId: string;
  profileId: string | null;
  role: 'gateway' | 'profile';
  displayName: string;
  status: IntegrationContractStatus;
  documentationOnly: true;
  implemented: boolean;
  enabled: false;
  launchReady: boolean;
  walletReady: boolean;
  recoveryReady: boolean;
  liveReady: boolean;
  adapterStatus: 'implemented' | 'adapter_unimplemented' | 'contract_missing';
  acceptanceCapabilities: readonly GameProviderAcceptanceCapability[];
  uatReady: false;
  accepted: false;
  requiredEvidence: readonly string[];
}>;

export type PaymentIntegrationContract = Readonly<{
  providerId: 'vpay_myr' | 'gspay_myr' | 'gspay_usdt' | 'onempay_myr';
  acceptanceScope: 'primary_myr' | 'separate_pending';
  displayName: string;
  status: IntegrationContractStatus;
  documentationOnly: true;
  implemented: boolean;
  enabled: false;
  orderReady: false;
  callbackReady: false;
  recoveryReady: false;
  settlementVerified: false;
  liveReady: false;
  acceptanceCapabilities: readonly string[];
  uatReady: false;
  accepted: false;
  requiredEvidence: readonly string[];
}>;

const GAME_EVIDENCE = Object.freeze([
  'official_api_document',
  'api_version_and_environment',
  'authentication_and_signature',
  'timestamp_and_replay_contract',
  'network_and_callback_rules',
  'catalogue_contract',
  'player_mapping_contract',
  'launch_contract',
  'wallet_mode_and_balance_contract',
  'wallet_transfer_contract',
  'callback_and_deduplication_contract',
  'recovery_and_timeout_contract',
  'settlement_and_reconciliation_contract',
  'maintenance_and_error_contract',
  'authorized_uat_scope',
  'provider_uat_evidence',
]);

const PAYMENT_EVIDENCE = Object.freeze([
  'official_api_document',
  'api_version_and_environment',
  'authentication_and_signature',
  'timestamp_and_replay_contract',
  'credential_rotation_evidence',
  'order_contract',
  'return_url_contract',
  'callback_contract',
  'duplicate_callback_and_idempotency_contract',
  'query_and_recovery_contract',
  'amount_member_currency_binding_contract',
  'wallet_credit_contract',
  'manual_review_contract',
  'payout_and_status_query_contract',
  'settlement_and_reconciliation_contract',
  'authorized_uat_scope',
  'provider_uat_evidence',
]);

const EVIDENCE_RECORD_FIELDS = Object.freeze([
  'environment',
  'release_version',
  'provider_profile',
  'capability',
  'observed_at_myt',
  'verified_by',
  'evidence_reference',
  'evidence_sha256',
  'result',
]);

const GAME_EVIDENCE_BY_CAPABILITY = Object.freeze({
  catalogue: Object.freeze(['official_api_document','api_version_and_environment','authentication_and_signature','timestamp_and_replay_contract','catalogue_contract','authorized_uat_scope','provider_uat_evidence']),
  launch: Object.freeze(['player_mapping_contract','launch_contract','network_and_callback_rules','maintenance_and_error_contract','provider_uat_evidence']),
  wallet: Object.freeze(['authentication_and_signature','wallet_mode_and_balance_contract','wallet_transfer_contract','provider_uat_evidence']),
  settlement: Object.freeze(['settlement_and_reconciliation_contract','provider_uat_evidence']),
  recovery: Object.freeze(['callback_and_deduplication_contract','recovery_and_timeout_contract','maintenance_and_error_contract','provider_uat_evidence']),
});

const PAYMENT_EVIDENCE_BY_CAPABILITY = Object.freeze({
  order: Object.freeze(['official_api_document','api_version_and_environment','authentication_and_signature','timestamp_and_replay_contract','credential_rotation_evidence','order_contract','return_url_contract','authorized_uat_scope']),
  payment: Object.freeze(['order_contract','amount_member_currency_binding_contract','provider_uat_evidence']),
  callback: Object.freeze(['callback_contract','duplicate_callback_and_idempotency_contract','authentication_and_signature','amount_member_currency_binding_contract','provider_uat_evidence']),
  query_recovery: Object.freeze(['query_and_recovery_contract','manual_review_contract','provider_uat_evidence']),
  wallet_credit: Object.freeze(['wallet_credit_contract','amount_member_currency_binding_contract','manual_review_contract','provider_uat_evidence']),
  merchant_settlement: Object.freeze(['payout_and_status_query_contract','settlement_and_reconciliation_contract','provider_uat_evidence']),
});

const lebetGateway: GameIntegrationContract = Object.freeze({
  providerId: 'lebet',
  profileId: null,
  role: 'gateway',
  displayName: 'Lebet',
  status: 'contract_missing',
  documentationOnly: true,
  implemented: false,
  enabled: false,
  launchReady: false,
  walletReady: false,
  recoveryReady: false,
  liveReady: false,
  adapterStatus: 'contract_missing',
  acceptanceCapabilities: GAME_PROVIDER_ACCEPTANCE_CAPABILITIES,
  uatReady: false,
  accepted: false,
  requiredEvidence: GAME_EVIDENCE,
});

const gameProfileContracts: readonly GameIntegrationContract[] = Object.freeze(
  GAME_PROVIDER_PROFILES
    .filter(profile => profile.listedInLobby)
    .map(profile => Object.freeze({
      providerId: profile.providerId,
      profileId: profile.profileId,
      role: 'profile' as const,
      displayName: profile.displayName,
      status: profile.contractStatus === 'documented' ? 'documented_not_verified' as const : 'contract_missing' as const,
      documentationOnly: true as const,
      implemented: profile.implemented,
      enabled: false as const,
      launchReady: false,
      walletReady: false,
      recoveryReady: false,
      liveReady: false,
      adapterStatus: profile.adapterStatus,
      acceptanceCapabilities: GAME_PROVIDER_ACCEPTANCE_CAPABILITIES,
      uatReady: false as const,
      accepted: false as const,
      requiredEvidence: GAME_EVIDENCE,
    })),
);

const gameContracts: readonly GameIntegrationContract[] = Object.freeze([
  lebetGateway,
  ...gameProfileContracts,
]);

const listedGameProfiles = gameContracts.filter(item => item.role === 'profile');

const paymentContracts: readonly PaymentIntegrationContract[] = Object.freeze([
  Object.freeze({
    providerId: 'vpay_myr',
    acceptanceScope: 'primary_myr',
    displayName: 'VPay · MYR',
    status: 'documented_not_verified',
    documentationOnly: true,
    implemented: true,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    acceptanceCapabilities: PAYMENT_ACCEPTANCE_CAPABILITIES,
    uatReady: false,
    accepted: false,
    requiredEvidence: PAYMENT_EVIDENCE,
  }),
  Object.freeze({
    providerId: 'gspay_myr',
    acceptanceScope: 'primary_myr',
    displayName: 'GSPAY · MYR',
    status: 'documented_not_verified',
    documentationOnly: true,
    implemented: true,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    acceptanceCapabilities: PAYMENT_ACCEPTANCE_CAPABILITIES,
    uatReady: false,
    accepted: false,
    requiredEvidence: PAYMENT_EVIDENCE,
  }),
  Object.freeze({
    providerId: 'gspay_usdt',
    acceptanceScope: 'separate_pending',
    displayName: 'GSPAY · USDT',
    status: 'contract_missing',
    documentationOnly: true,
    implemented: false,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    acceptanceCapabilities: PAYMENT_ACCEPTANCE_CAPABILITIES,
    uatReady: false,
    accepted: false,
    requiredEvidence: Object.freeze([
      ...PAYMENT_EVIDENCE,
      'asset_network_and_scale_rules',
    ]),
  }),
  Object.freeze({
    providerId: 'onempay_myr',
    acceptanceScope: 'primary_myr',
    displayName: '1MPAY · MYR',
    status: 'documented_not_verified',
    documentationOnly: true,
    implemented: true,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    acceptanceCapabilities: PAYMENT_ACCEPTANCE_CAPABILITIES,
    uatReady: false,
    accepted: false,
    requiredEvidence: PAYMENT_EVIDENCE,
  }),
]);

const primaryPaymentProfiles = paymentContracts.filter(item => item.providerId.endsWith('_myr'));

export function getIntegrationContractIntake() {
  return Object.freeze({
    documentationOnly: true as const,
    gatewayCount: gameContracts.filter(item => item.role === 'gateway').length,
    gameProfileCount: listedGameProfiles.length,
    scope: Object.freeze({
      gameBrandCount: new Set(listedGameProfiles.map(item => item.providerId)).size,
      gameProfileCount: listedGameProfiles.length,
      gatewayCount: gameContracts.filter(item => item.role === 'gateway').length,
      primaryPaymentProfileCount: primaryPaymentProfiles.length,
      separatePaymentProfileCount: paymentContracts.length - primaryPaymentProfiles.length,
    }),
    uatPackage: Object.freeze({
      evidenceRecordFields: EVIDENCE_RECORD_FIELDS,
      gameCapabilities: GAME_EVIDENCE_BY_CAPABILITY,
      paymentCapabilities: PAYMENT_EVIDENCE_BY_CAPABILITY,
      ownerEvidenceWriteOnly: true,
      staffReadOnly: true,
      autoAcceptance: false,
      productionSwitchesRemainClosed: true,
    }),
    excludedProviderCandidates: Object.freeze([
      Object.freeze({providerId:'gspay_plus',status:'identity_unresolved',formalScope:false,enabled:false}),
    ]),
    gameProviders: gameContracts,
    paymentProviders: paymentContracts,
  });
}
