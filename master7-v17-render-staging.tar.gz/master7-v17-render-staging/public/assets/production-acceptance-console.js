(function installProductionAcceptanceConsole(scope){
 'use strict';

 const $=id=>document.getElementById(id),CAPABILITIES=['catalogue','launch','wallet','settlement','recovery'];
 let session=null,production=null,games=null,loading=null,lastLoaded=0;
 const key=(category,subjectId,capability)=>`${category}:${subjectId}:${capability}`;
 const stateMap=()=>new Map((production?.requirements||[]).flatMap(item=>Object.entries(item.capabilities||{}).map(([capability,value])=>[key(item.category,item.subjectId,capability),value])));
 const gameStateMap=()=>new Map((games?.profiles||[]).flatMap(item=>Object.entries(item.capabilities||{}).map(([capability,value])=>[`${item.profileId}:${capability}`,value])));
 const json=async(path,options={})=>{const response=await fetch(path,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json',...(options.body?{'Content-Type':'application/json'}:{}),...(options.headers||{})},...options});let body={};try{body=await response.json();}catch{}if(!response.ok)throw new Error(body.error||body.message||`HTTP ${response.status}`);return body;};
 const digest=async(file,value)=>{if(file){const bytes=await file.arrayBuffer(),hash=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(hash)].map(byte=>byte.toString(16).padStart(2,'0')).join('');}const normalized=String(value||'').trim().toLowerCase();if(!/^[a-f0-9]{64}$/.test(normalized))throw new Error('Select an evidence file or enter its 64-character SHA-256.');return normalized;};
 const option=(value,label)=>{const item=document.createElement('option');item.value=value;item.textContent=label;return item;};
 const metric=(label,value,ready)=>{const card=document.createElement('article');card.className='stat';const name=document.createElement('span'),result=document.createElement('strong');name.textContent=label;result.textContent=value;result.className=ready?'ready':'pending';card.append(name,result);return card;};
 function renderRequirements(){
  const host=$('productionAcceptanceRequirements'),summary=$('productionAcceptanceSummary'),selector=$('productionAcceptanceRequirement');if(!host||!summary||!selector)return;
  host.replaceChildren();summary.replaceChildren();const requirements=production?.requirements||[],groups={domain:'DNS / TLS',credential:'Credential rotation',payment:'Real payment',signoff:'Final sign-off'};
  for(const [category,label] of Object.entries(groups)){const states=requirements.filter(item=>item.category===category).flatMap(item=>Object.values(item.capabilities||{})),ready=states.length>0&&states.every(item=>item.passed===true);summary.append(metric(label,ready?'PASS':'PENDING',ready));}
  selector.replaceChildren();for(const requirement of requirements)for(const capability of Object.keys(requirement.capabilities||{}))selector.append(option(key(requirement.category,requirement.subjectId,capability),`${groups[requirement.category]||requirement.category} · ${requirement.subjectId} · ${capability}`));
  for(const requirement of requirements)for(const [capability,item] of Object.entries(requirement.capabilities||{})){const row=document.createElement('article'),title=document.createElement('strong'),status=document.createElement('span'),detail=document.createElement('small');row.className='readiness-row';title.textContent=`${requirement.subjectId} · ${capability}`;status.className=`status ${item.passed?'ready':'pending'}`;status.textContent=item.passed?'PASS':item.result==='not_recorded'?'NOT VERIFIED':String(item.result).toUpperCase();detail.className='muted';detail.textContent=item.evidenceReference?`Evidence: ${item.evidenceReference} · SHA-256 ${String(item.evidenceSha256).slice(0,12)}…`:'No durable evidence event';row.append(title,status,detail);host.append(row);}
 }
 function renderGames(){
  const selector=$('gameAcceptanceProfile'),summary=$('gameAcceptanceSummary');if(!selector||!summary)return;selector.replaceChildren();summary.replaceChildren();const profiles=games?.profiles||[];for(const profile of profiles)selector.append(option(profile.profileId,`${profile.displayName||profile.profileId} · ${profile.profileId}`));const accepted=profiles.filter(profile=>CAPABILITIES.every(capability=>profile.capabilities?.[capability]?.passed===true)).length;summary.append(metric('Game profiles',String(profiles.length),profiles.length>0),metric('Fully accepted',String(accepted),profiles.length>0&&accepted===profiles.length));
 }
 function paint(){
  renderRequirements();renderGames();const owner=session?.user?.role==='owner';for(const id of ['productionAcceptanceForm','gameAcceptanceForm'])if($(id))$(id).hidden=!owner;const pending=(production?.requirements||[]).flatMap(item=>Object.values(item.capabilities||{})).filter(item=>item.passed!==true).length;$('productionAcceptanceNotice').textContent=pending===0?'All canonical external acceptance evidence is recorded. Runtime gates still apply.':`${pending} canonical acceptance checks remain unverified. No evidence was inferred.`;
 }
 async function load(force=false){
  const panel=$('productionAcceptancePanel');if(!panel||panel.hidden)return;if(loading)return loading;if(!force&&Date.now()-lastLoaded<10000)return;
  $('productionAcceptanceNotice').textContent='Loading durable acceptance evidence…';loading=(async()=>{[session,production,games]=await Promise.all([json('/api/session'),json('/api/admin/production-acceptance?environment=production&limit=100'),json('/api/admin/game-acceptance?environment=production&limit=0')]);paint();lastLoaded=Date.now();})().catch(error=>{$('productionAcceptanceNotice').textContent=error.message;}).finally(()=>{loading=null;});return loading;
 }
 async function post(path,payload){
  if(!session?.csrf)session=await json('/api/session');return json(path,{method:'POST',headers:{'X-CSRF-Token':session.csrf},body:JSON.stringify(payload)});
 }
 async function submitProduction(event){
  event.preventDefault();const status=$('productionAcceptanceFormStatus'),button=event.currentTarget.querySelector('button[type="submit"]');button.disabled=true;status.textContent='Hashing and recording evidence…';try{const [category,subjectId,capability]=$('productionAcceptanceRequirement').value.split(':'),current=stateMap().get(key(category,subjectId,capability));await post('/api/admin/production-acceptance',{category,subjectId,capability,environment:'production',result:$('productionAcceptanceResult').value,evidenceSha256:await digest($('productionAcceptanceFile').files[0],$('productionAcceptanceDigest').value),evidenceReference:$('productionAcceptanceReference').value.trim(),observedAt:Math.floor(Date.now()/1000),expectedEventId:current?.eventId??null});event.currentTarget.reset();status.textContent='Recorded.';await load(true);}catch(error){status.textContent=error.message;}finally{button.disabled=false;}
 }
 async function submitGame(event){
  event.preventDefault();const status=$('gameAcceptanceFormStatus'),button=event.currentTarget.querySelector('button[type="submit"]');button.disabled=true;status.textContent='Hashing and recording evidence…';try{const profileId=$('gameAcceptanceProfile').value,capability=$('gameAcceptanceCapability').value,current=gameStateMap().get(`${profileId}:${capability}`);await post('/api/admin/game-acceptance',{profileId,capability,environment:'production',result:$('gameAcceptanceResult').value,evidenceSha256:await digest($('gameAcceptanceFile').files[0],$('gameAcceptanceDigest').value),evidenceReference:$('gameAcceptanceReference').value.trim(),observedAt:Math.floor(Date.now()/1000),expectedEventId:current?.eventId??null});event.currentTarget.reset();status.textContent='Recorded.';await load(true);}catch(error){status.textContent=error.message;}finally{button.disabled=false;}
 }
 function install(){
  const panel=$('productionAcceptancePanel');if(!panel)return;$('refreshProductionAcceptance')?.addEventListener('click',()=>load(true));$('productionAcceptanceForm')?.addEventListener('submit',submitProduction);$('gameAcceptanceForm')?.addEventListener('submit',submitGame);document.querySelectorAll('a[href="#productionAcceptancePanel"]').forEach(link=>link.addEventListener('click',()=>setTimeout(()=>load(true),0)));if(typeof MutationObserver==='function')new MutationObserver(()=>{if(!panel.hidden)load(false);}).observe(panel,{attributes:true,attributeFilter:['hidden']});
 }
 scope.Master7ProductionAcceptance=Object.freeze({load});if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',install,{once:true});
})(typeof globalThis==='object'?globalThis:this);
