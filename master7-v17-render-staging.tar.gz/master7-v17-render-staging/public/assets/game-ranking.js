(function(){
 const categories=["HOT","SLOT","LIVE","FISH","COCK","SPORT"];
 let adminData=null,currentCategory="HOT";
 const byId=id=>document.getElementById(id);
 function element(tag,className="",content=""){const item=document.createElement(tag);if(className)item.className=className;if(content!=="")item.textContent=String(content);return item;}
 function providerMap(){return new Map((adminData?.providers||[]).map(item=>[item.id,item.name]));}
 function publicCategories(payload){return payload?.ranking?.categories||payload?.categories||null;}
 function orderEntries(entries,category,payload){
  const ids=publicCategories(payload)?.[category];if(!Array.isArray(ids))return entries;const source=new Map(entries.map(item=>[item.id,item]));return ids.map(id=>source.get(id)).filter(Boolean);
 }
 function render(){
  const host=byId("gameRankingList"),notice=byId("gameRankingNotice");if(!host||!adminData)return;host.replaceChildren();const order=adminData.ranking.categories[currentCategory]||[],names=providerMap();
  if(notice)notice.textContent=`Admin curated · ${order.length} platform${order.length===1?"":"s"} · internal games are not ranked`;
  if(!order.length){host.append(element("p","muted","This category has no assigned platforms."));return;}
  order.forEach((id,index)=>{const row=element("article","game-ranking-row"),rank=element("strong","game-ranking-position",String(index+1).padStart(2,"0")),copy=element("div","game-ranking-copy"),name=element("strong","",names.get(id)||id),code=element("small","",id),actions=element("div","game-ranking-actions"),up=element("button","button button-outline small","↑"),down=element("button","button button-outline small","↓");up.type=down.type="button";up.disabled=index===0;down.disabled=index===order.length-1;up.setAttribute("aria-label",`Move ${name.textContent} up`);down.setAttribute("aria-label",`Move ${name.textContent} down`);up.onclick=()=>move(index,-1);down.onclick=()=>move(index,1);copy.append(name,code);actions.append(up,down);row.append(rank,copy,actions);host.append(row);});
 }
 function move(index,direction){const order=adminData.ranking.categories[currentCategory],target=index+direction;if(target<0||target>=order.length)return;[order[index],order[target]]=[order[target],order[index]];render();}
 async function loadAdmin(){
  if(typeof state!=="undefined"&&state.user?.role!=="owner")return;const status=byId("gameRankingStatus");if(status)status.textContent="Loading…";
  try{adminData=await api("/api/admin/game-ranking");currentCategory=categories.includes(byId("gameRankingCategory")?.value)?byId("gameRankingCategory").value:"HOT";render();if(status)status.textContent=adminData.configured?"✅ Saved owner ranking loaded":"Default order loaded · save to configure";}catch(error){if(status)status.textContent=error.message;}
 }
 async function save(){const button=byId("saveGameRanking"),status=byId("gameRankingStatus");if(!adminData)return;button.disabled=true;status.textContent="Saving…";try{adminData=await api("/api/admin/game-ranking","POST",{ranking:adminData.ranking});status.textContent="✅ Game platform ranking saved";if(typeof loadGameCatalogue==="function")await loadGameCatalogue();render();if(typeof notification==="function")notification("Game platform ranking saved");}catch(error){status.textContent=error.message;}finally{button.disabled=false;}}
 function bind(){const select=byId("gameRankingCategory");if(select)select.onchange=()=>{currentCategory=select.value;render();};byId("saveGameRanking")?.addEventListener("click",save);byId("reloadGameRanking")?.addEventListener("click",loadAdmin);}
 window.Master7GameRanking={loadAdmin,orderEntries,publicCategories};if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bind);else bind();
})();
