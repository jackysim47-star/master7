(()=>{
 const get=id=>document.getElementById(id);
 const copy={
  zh:{gateEnabled:'新充值、游戏启动及提现申请需要身份和风险审核通过。现有订单查询及游戏结算仍可使用。',gateDisabled:'目前只记录审核结果，尚未限制新交易。',nav:'身份审核',title:'身份审核',intro:'提交申请后，请通过客服了解身份审核步骤。请勿在此输入证件号码或上传照片。',request:'申请审核',loading:'正在读取审核状态…',pending:'待人工审核',not_started:'尚未申请',passed:'已审核通过',failed:'未通过，请联系客户服务',identity:'身份审核',aml:'风险审核',failedLoad:'暂时无法读取审核状态。',submitted:'申请已提交。',admin:'身份与风险审核',adminIntro:'仅记录人工审核结果。请先完成证件核验和风险检查；此处不接收证件资料。',refresh:'刷新',empty:'暂无审核申请。',pass:'通过',reject:'不通过',confirmPass:'确认已按照内部流程完成此项人工核验并记录为通过？',confirmReject:'确认此项人工审核不通过？',saved:'审核结果已记录。',reviewError:'审核未保存，请刷新后重试。'},
  en:{gateEnabled:'New deposits, game launches and withdrawal requests require identity and risk review. Existing orders and game settlement remain accessible.',gateDisabled:'Review decisions are recorded but do not currently restrict new transactions.',nav:'Verification',title:'Identity verification',intro:'Submit a request and contact support for verification steps. Do not enter document numbers or upload photos here.',request:'Request review',loading:'Loading review status…',pending:'Awaiting manual review',not_started:'Not requested',passed:'Manually reviewed: passed',failed:'Not passed; contact support',identity:'Identity review',aml:'Risk review',failedLoad:'Review status is temporarily unavailable.',submitted:'Review requested.',admin:'Identity and risk review',adminIntro:'Records manual decisions only. Complete identity and risk checks first; do not enter documents here.',refresh:'Refresh',empty:'No review requests.',pass:'Pass',reject:'Not passed',confirmPass:'Confirm this check was completed manually under your internal procedure and passed?',confirmReject:'Confirm this manual check did not pass?',saved:'Review decision recorded.',reviewError:'Review was not saved. Refresh and try again.'},
  ms:{gateEnabled:'Deposit baharu, pelancaran permainan dan permintaan pengeluaran memerlukan semakan identiti dan risiko. Pesanan sedia ada dan penyelesaian permainan masih boleh diakses.',gateDisabled:'Keputusan semakan direkodkan tetapi belum mengehadkan transaksi baharu.',nav:'Pengesahan',title:'Pengesahan identiti',intro:'Hantar permintaan dan hubungi sokongan untuk langkah pengesahan. Jangan masukkan nombor dokumen atau muat naik gambar di sini.',request:'Mohon semakan',loading:'Memuatkan status semakan…',pending:'Menunggu semakan manual',not_started:'Belum dimohon',passed:'Semakan manual: lulus',failed:'Tidak lulus; hubungi sokongan',identity:'Semakan identiti',aml:'Semakan risiko',failedLoad:'Status semakan tidak tersedia buat sementara.',submitted:'Permintaan semakan dihantar.',admin:'Semakan identiti dan risiko',adminIntro:'Merekod keputusan manual sahaja. Lengkapkan semakan identiti dan risiko dahulu; jangan masukkan dokumen di sini.',refresh:'Muat semula',empty:'Tiada permintaan semakan.',pass:'Lulus',reject:'Tidak lulus',confirmPass:'Sahkan semakan manual ini telah lengkap mengikut prosedur dalaman dan lulus?',confirmReject:'Sahkan semakan manual ini tidak lulus?',saved:'Keputusan semakan direkodkan.',reviewError:'Semakan tidak disimpan. Muat semula dan cuba lagi.'}
 };
 let generation=0,memberResult=null,adminResult=null,memberBusy=false,adminBusy=false;
 const tr=key=>(copy[state.lang]||copy.en)[key]||key;
 const safeRole=role=>typeof state!=='undefined'&&state.user?.role===role;
 const set=(id,value)=>{const node=get(id);if(node)node.textContent=value;};
 function labels(){
  set('manualComplianceTitle',tr('title'));set('manualComplianceIntro',tr('intro'));set('manualComplianceRequest',tr('request'));
  set('manualComplianceAdminTitle',tr('admin'));set('manualComplianceAdminIntro',tr('adminIntro'));set('manualComplianceAdminRefresh',tr('refresh'));
  document.querySelectorAll('[data-section="member-verification"]').forEach(node=>{const label=node.querySelector('span:last-child');if(label)label.textContent=tr('nav');else node.textContent=tr('nav');});
 }
 function renderMember(){
  const status=get('manualComplianceStatus'),button=get('manualComplianceRequest');if(!status||!button)return;
  if(!memberResult){status.textContent=tr('failedLoad');button.hidden=true;return;}
  status.textContent=`${tr('identity')}: ${tr(memberResult.identityStatus)} · ${tr('aml')}: ${tr(memberResult.amlStatus)}. ${tr(memberResult.enforcementEnabled?'gateEnabled':'gateDisabled')}`;
  button.hidden=memberResult.identityStatus!=='not_started';button.disabled=memberBusy;
 }
 async function load(){
  if(!safeRole('member')||memberBusy)return;const requestGeneration=++generation,userId=state.user.id;memberResult=null;set('manualComplianceStatus',tr('loading'));get('manualComplianceRequest').hidden=true;
  try{const data=await api('/api/compliance');if(requestGeneration!==generation||!safeRole('member')||state.user.id!==userId)return;memberResult=data;renderMember();}
  catch{if(requestGeneration===generation&&safeRole('member')&&state.user.id===userId){memberResult=null;renderMember();}}
 }
 async function requestReview(){
  if(!safeRole('member')||memberBusy)return;memberBusy=true;const requestGeneration=generation,userId=state.user.id;get('manualComplianceRequest').disabled=true;
  try{const data=await api('/api/compliance','POST',{});if(requestGeneration!==generation||!safeRole('member')||state.user.id!==userId)return;memberResult=data;renderMember();}
  catch{if(requestGeneration===generation&&safeRole('member')&&state.user.id===userId)set('manualComplianceStatus',tr('failedLoad'));}
  finally{if(requestGeneration===generation&&safeRole('member')&&state.user.id===userId){memberBusy=false;renderMember();}}
 }
 function makeButton(label,fn){const button=document.createElement('button');button.type='button';button.className='button button-outline small';button.textContent=label;button.addEventListener('click',fn);return button;}
 function renderAdmin(){
  const host=get('manualComplianceAdminRows');if(!host)return;host.replaceChildren();
  if(!adminResult){set('manualComplianceAdminStatus',tr('failedLoad'));return;}
  if(!adminResult.items?.length){set('manualComplianceAdminStatus',tr('empty'));return;}
  set('manualComplianceAdminStatus','');
  for(const item of adminResult.items){
   const row=document.createElement('article'),name=document.createElement('strong'),statuses=document.createElement('p');row.className='surface stack';name.textContent=String(item.username);statuses.textContent=`${tr('identity')}: ${tr(item.identity_status)} · ${tr('aml')}: ${tr(item.aml_status)}`;row.append(name,statuses);
   for(const kind of ['identity','aml'])for(const decision of ['passed','failed'])row.append(makeButton(`${tr(kind)} · ${tr(decision==='passed'?'pass':'reject')}`,()=>review(item,kind,decision)));
   host.append(row);
  }
 }
 async function loadAdmin(){
  if(!safeRole('owner'))return;const requestGeneration=++generation,userId=state.user.id;adminResult=null;get('manualComplianceAdminRows').replaceChildren();set('manualComplianceAdminStatus',tr('loading'));
  try{const data=await api('/api/admin/compliance');if(requestGeneration!==generation||!safeRole('owner')||state.user.id!==userId)return;adminResult=data;renderAdmin();}
  catch{if(requestGeneration===generation&&safeRole('owner')&&state.user.id===userId){adminResult=null;renderAdmin();}}
 }
 async function review(item,reviewType,decision){
  if(!safeRole('owner')||adminBusy)return;if(!window.confirm(tr(decision==='passed'?'confirmPass':'confirmReject')))return;
  adminBusy=true;const requestGeneration=generation,userId=state.user.id;
  try{await api('/api/admin/compliance','POST',{memberId:item.user_id,reviewType,decision,expectedVersion:Number(item.version),confirmed:true});if(requestGeneration!==generation||!safeRole('owner')||state.user.id!==userId)return;adminBusy=false;await loadAdmin();}
  catch{if(requestGeneration===generation&&safeRole('owner')&&state.user.id===userId)set('manualComplianceAdminStatus',tr('reviewError'));}
  finally{if(requestGeneration===generation&&safeRole('owner')&&state.user.id===userId)adminBusy=false;}
 }
 function sessionChanged(user){generation++;memberResult=null;adminResult=null;memberBusy=false;adminBusy=false;get('manualComplianceAdminRows')?.replaceChildren();set('manualComplianceStatus','');set('manualComplianceAdminStatus','');document.querySelectorAll('[data-section="member-verification"]').forEach(node=>node.hidden=user?.role!=='member');if(user?.role==='member'&&state.section==='member-verification')load();}
 get('manualComplianceRequest')?.addEventListener('click',requestReview);get('manualComplianceAdminRefresh')?.addEventListener('click',loadAdmin);
 get('locale')?.addEventListener('change',()=>{labels();if(safeRole('member')&&memberResult)renderMember();if(safeRole('owner')&&adminResult)renderAdmin();});
 labels();window.Master7ManualCompliance={load,loadAdmin,sessionChanged};sessionChanged(state.user);
})();
