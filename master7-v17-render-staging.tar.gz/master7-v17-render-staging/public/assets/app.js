"use strict";
const $ = id => document.getElementById(id);
const state = {lang:"zh", user:null, csrf:null, authMethod:null, authMode:"login", register:false, providers:[], games:[], gameCatalogue:null, announcements:[], tickets:[], social:null, loginChallenge:null, section:"home"};
const translations = {
 zh: {
  requestTimeout:"连接超时，操作结果未确认。请检查连接和记录后再试。",networkError:"无法连接服务。请检查网络后重试。",serviceUnavailable:"服务暂时不可用。请稍后重试。",
  demoWarning:"V17 QA3 独立整合测试 · 未连接真实会员、游戏或资金系统",navHome:"首页",lobbyEyebrow:"供应商只读测试目录",gamesLoading:"正在读取供应商测试目录…",catalogSummary:"读取到 {count} 个测试目录项目；不可启动。",catalogUnavailable:"暂时无法读取供应商测试目录。",providerAvailable:"目录可读",providerBlocked:"上游拒绝",providerUnavailable:"暂不可用",providerEmpty:"目录为空",providerNotConfigured:"未配置",uatNotPlayable:"测试目录 · 不可启动",navLobby:"游戏目录（测试）",navSupport:"客服",navAdmin:"后台",language:"语言",login:"登录",logout:"退出",eyebrow:"MASTER7 · NEW EXPERIENCE",heroTitle:"前台与后台",heroAccent:"统一体验。",heroDescription:"以三种语言、受保护的登录和清晰的服务管理，为 V17 奠定基础。",explore:"查看测试游戏目录",viewStatus:"查看连接状态",previewLabel:"独立测试版本",featureLang:"三种语言",featureLangDesc:"中文、英文、马来文切换",featureOtp:"两步验证",featureOtpDesc:"账号密码 + 6 位动态 OTP",featureStaff:"员工权限",featureStaffDesc:"老板、员工和会员分级",featureAudit:"操作记录",featureAuditDesc:"审批和更改可追踪",announcements:"系统公告",loading:"读取中…",lobbyTitle:"供应商游戏目录（测试）",lobbyNotice:"这里读取已配置厂牌的只读测试目录。游戏目前不可启动、下注或结算；每家厂商通过 UAT 前不会开放游玩。",searchPlaceholder:"搜索展示项目",allCategories:"全部类别",slots:"老虎机",arcade:"街机",tableGames:"桌面游戏",live:"真人类",sports:"体育类",supportTitle:"客户服务中心",supportIntro:"可创建测试工单；不会发送给真实客服系统。",newTicket:"创建工单",subject:"主题",message:"内容",submitTicket:"提交测试工单",ticketLogin:"需要先登录并通过 OTP 验证。",myTickets:"工单记录",loginFirst:"请先登录。",adminTitle:"运营管理后台",adminIntro:"仅测试账户；不会接触原站真实数据。",staffOnly:"员工权限保护",publishAnnouncement:"发布测试公告",publish:"发布",providerManager:"展示厂家管理",providerManagerHint:"仅调整模拟卡片是否显示，不连接真实游戏。",memberApproval:"会员审批",auditTrail:"操作审计",adminDenied:"需要员工或老板账号登录后才可进入。",footerDisclaimer:"此独立测试版不提供真实游戏、充值、提款或资金结算。",sandbox:"ISOLATED PREVIEW · NO REAL TRANSACTIONS",signInTitle:"安全登录",signIn:"登录",register:"注册",username:"用户名",password:"密码（最少12位）",otp:"动态 OTP（6位）",otpNote:"本测试版使用验证器 TOTP；不是短信或真实顾客系统。注册后需老板批准。",demoOnly:"示例 · 不可游玩",hidden:"已隐藏",visible:"可展示",loginRequired:"请先登录。",success:"操作成功",error:"操作未完成",registerSaved:"账号已注册，等待老板批准。请立即保存下方 OTP 密钥并加入验证器：",neverShare:"不要将 OTP 密钥发送给任何人。",authError:"登录失败。请检查账号、密码、OTP 或审批状态。",role_owner:"老板",role_staff:"员工",role_member:"会员",users:"账号总数",pending:"待审批",openTickets:"待处理工单",visibleProviders:"展示项目",demoFunds:"真实资金数据未连接",approve:"批准",approved:"已批准",open:"处理中",closed:"已关闭",closeTicket:"关闭",reopenTicket:"重开",itemSearchNoResults:"没有匹配的测试目录项目。",noTickets:"暂无工单。",noAnnouncements:"暂无公告。",credentials:"仅用于本地测试。",statusTitle:"V17 连接检查",statusMessage:"本地数据库与演示 API 可检查；原 MASTER7 生产网站、真实游戏和支付均未连接。",badResponse:"服务异常",noUsers:"暂无注册会员。",notReady:"未接通",save:"保存",identity:"账号与 OTP"
 },
 en: {
  requestTimeout:"Request timed out; the outcome is unconfirmed. Check your connection and records before retrying.",networkError:"Cannot reach the service. Check your connection and retry.",serviceUnavailable:"Service temporarily unavailable. Please try again later.",
  demoWarning:"V17 QA3 integrated offline preview · No real members, games or payments",navHome:"Home",lobbyEyebrow:"READ-ONLY PROVIDER TEST CATALOG",gamesLoading:"Loading provider test catalogs…",catalogSummary:"{count} test catalog entries loaded; not playable.",catalogUnavailable:"Provider test catalogs are temporarily unavailable.",providerAvailable:"Catalog readable",providerBlocked:"Upstream rejected",providerUnavailable:"Temporarily unavailable",providerEmpty:"Empty catalog",providerNotConfigured:"Not configured",uatNotPlayable:"Test catalog · Not playable",navLobby:"Game catalog (test)",navSupport:"Support",navAdmin:"Admin",language:"Language",login:"Sign in",logout:"Log out",eyebrow:"MASTER7 · NEW EXPERIENCE",heroTitle:"Frontend and backoffice",heroAccent:"One experience.",heroDescription:"A foundation for V17 with three languages, secure sign-in and manageable support workflows.",explore:"View test game catalog",viewStatus:"Connection status",previewLabel:"Isolated preview",featureLang:"Three languages",featureLangDesc:"Chinese, English and Malay",featureOtp:"Two-step login",featureOtpDesc:"Password + 6-digit OTP",featureStaff:"Staff permissions",featureStaffDesc:"Owner, staff and member roles",featureAudit:"Audit history",featureAuditDesc:"Traceable approvals and changes",announcements:"System notices",loading:"Loading…",lobbyTitle:"Provider game catalog (test)",lobbyNotice:"This page reads read-only test catalogs from configured providers. Games cannot launch, accept bets or settle; play remains closed until each provider passes UAT.",searchPlaceholder:"Search demo items",allCategories:"All categories",slots:"Slots",arcade:"Arcade",tableGames:"Table",live:"Live",sports:"Sports",supportTitle:"Support center",supportIntro:"Create test tickets; these are not sent to real support.",newTicket:"New ticket",subject:"Subject",message:"Message",submitTicket:"Submit test ticket",ticketLogin:"Sign in with an OTP to submit a ticket.",myTickets:"Ticket history",loginFirst:"Please sign in.",adminTitle:"Operations backoffice",adminIntro:"Test accounts only; original site data is never accessed.",staffOnly:"Staff access only",publishAnnouncement:"Publish test notice",publish:"Publish",providerManager:"Demo catalog management",providerManagerHint:"Show or hide placeholder cards only. No real games connected.",memberApproval:"Member approvals",auditTrail:"Audit log",adminDenied:"Sign in with an owner or staff account.",footerDisclaimer:"No real games, deposits, withdrawals or payments in this isolated preview.",sandbox:"ISOLATED PREVIEW · NO REAL TRANSACTIONS",signInTitle:"Secure sign-in",signIn:"Sign in",register:"Register",username:"Username",password:"Password (min 12 characters)",otp:"6-digit authenticator OTP",otpNote:"This demo uses authenticator TOTP, not SMS. New members require owner approval.",demoOnly:"Demo · Not playable",hidden:"Hidden",visible:"Visible",loginRequired:"Please sign in first.",success:"Saved",error:"Action not completed",registerSaved:"Account registered, pending owner approval. Save this OTP secret and add it to your authenticator now:",neverShare:"Never share the OTP secret.",authError:"Sign-in failed. Check username, password, OTP or approval status.",role_owner:"Owner",role_staff:"Staff",role_member:"Member",users:"Total accounts",pending:"Pending approval",openTickets:"Open tickets",visibleProviders:"Catalog items",demoFunds:"Real financial data not connected",approve:"Approve",approved:"Approved",open:"Open",closed:"Closed",closeTicket:"Close",reopenTicket:"Reopen",itemSearchNoResults:"No matching test catalog entries.",noTickets:"No tickets yet.",noAnnouncements:"No notices yet.",credentials:"Local preview only.",statusTitle:"V17 connectivity",statusMessage:"Local database and demo APIs can be checked; original production MASTER7, games and payments are not connected.",badResponse:"Service unavailable",noUsers:"No registered members.",notReady:"Not connected",save:"Save",identity:"Username and OTP"
 },
 ms: {
  requestTimeout:"Permintaan tamat masa; hasil belum disahkan. Semak sambungan dan rekod sebelum mencuba lagi.",networkError:"Tidak dapat menghubungi perkhidmatan. Semak sambungan dan cuba lagi.",serviceUnavailable:"Perkhidmatan tidak tersedia buat sementara waktu. Sila cuba lagi kemudian.",
  demoWarning:"Pratonton QA3 berasingan · Tiada akaun sebenar, permainan atau pembayaran",navHome:"Utama",lobbyEyebrow:"KATALOG UJIAN PEMBEKAL BACA SAHAJA",gamesLoading:"Memuatkan katalog ujian pembekal…",catalogSummary:"{count} item katalog ujian dimuatkan; tidak boleh dimainkan.",catalogUnavailable:"Katalog ujian pembekal tidak tersedia buat sementara.",providerAvailable:"Katalog boleh dibaca",providerBlocked:"Ditolak pembekal",providerUnavailable:"Tidak tersedia sementara",providerEmpty:"Katalog kosong",providerNotConfigured:"Belum dikonfigurasi",uatNotPlayable:"Katalog ujian · Tidak boleh dimainkan",navLobby:"Katalog permainan (ujian)",navSupport:"Bantuan",navAdmin:"Pentadbir",language:"Bahasa",login:"Log masuk",logout:"Log keluar",eyebrow:"MASTER7 · PENGALAMAN BAHARU",heroTitle:"Laman ahli & pentadbir",heroAccent:"Satu pengalaman.",heroDescription:"Asas V17 dengan tiga bahasa, log masuk selamat dan pengurusan bantuan yang jelas.",explore:"Lihat katalog ujian",viewStatus:"Status sambungan",previewLabel:"Pratonton berasingan",featureLang:"Tiga bahasa",featureLangDesc:"Cina, Inggeris dan Melayu",featureOtp:"Pengesahan dua langkah",featureOtpDesc:"Kata laluan + OTP 6 digit",featureStaff:"Akses kakitangan",featureStaffDesc:"Peranan pemilik, staf dan ahli",featureAudit:"Rekod audit",featureAuditDesc:"Kelulusan dan perubahan boleh dijejak",announcements:"Pengumuman",loading:"Memuatkan…",lobbyTitle:"Katalog permainan pembekal (ujian)",lobbyNotice:"Halaman ini membaca katalog ujian baca sahaja daripada pembekal yang dikonfigurasi. Permainan tidak boleh dilancarkan, menerima pertaruhan atau diselesaikan sehingga lulus UAT.",searchPlaceholder:"Cari item demo",allCategories:"Semua kategori",slots:"Slot",arcade:"Arked",tableGames:"Meja",live:"Langsung",sports:"Sukan",supportTitle:"Pusat bantuan",supportIntro:"Cipta tiket ujian; tidak dihantar kepada sokongan sebenar.",newTicket:"Tiket baharu",subject:"Tajuk",message:"Mesej",submitTicket:"Hantar tiket ujian",ticketLogin:"Log masuk dengan OTP untuk menghantar tiket.",myTickets:"Sejarah tiket",loginFirst:"Sila log masuk dahulu.",adminTitle:"Panel pentadbiran",adminIntro:"Akaun ujian sahaja; data laman asal tidak diakses.",staffOnly:"Akses staf sahaja",publishAnnouncement:"Terbit pengumuman ujian",publish:"Terbit",providerManager:"Urus katalog demo",providerManagerHint:"Papar/sembunyikan kad contoh sahaja; tidak menghubungkan permainan sebenar.",memberApproval:"Kelulusan ahli",auditTrail:"Log audit",adminDenied:"Log masuk sebagai pemilik atau staf.",footerDisclaimer:"Tiada permainan, deposit, pengeluaran atau pembayaran sebenar dalam pratonton ini.",sandbox:"PRATONTON BERASINGAN · TIADA TRANSAKSI SEBENAR",signInTitle:"Log masuk selamat",signIn:"Log masuk",register:"Daftar",username:"Nama pengguna",password:"Kata laluan (minimum 12 aksara)",otp:"OTP pengesah 6 digit",otpNote:"Demo ini menggunakan TOTP melalui aplikasi pengesah, bukan SMS. Ahli baharu perlu kelulusan pemilik.",demoOnly:"Demo · Tidak boleh dimainkan",hidden:"Disembunyikan",visible:"Dipaparkan",loginRequired:"Sila log masuk dahulu.",success:"Berjaya disimpan",error:"Tindakan tidak selesai",registerSaved:"Akaun didaftarkan; menunggu kelulusan pemilik. Simpan rahsia OTP ini dan tambahkan pada aplikasi pengesah sekarang:",neverShare:"Jangan kongsi rahsia OTP.",authError:"Log masuk gagal. Semak nama, kata laluan, OTP atau kelulusan.",role_owner:"Pemilik",role_staff:"Staf",role_member:"Ahli",users:"Jumlah akaun",pending:"Menunggu kelulusan",openTickets:"Tiket terbuka",visibleProviders:"Item katalog",demoFunds:"Data kewangan sebenar tidak disambungkan",approve:"Lulus",approved:"Diluluskan",open:"Terbuka",closed:"Ditutup",closeTicket:"Tutup",reopenTicket:"Buka semula",itemSearchNoResults:"Tiada item katalog ujian yang sepadan.",noTickets:"Belum ada tiket.",noAnnouncements:"Belum ada pengumuman.",credentials:"Untuk ujian setempat sahaja.",statusTitle:"Sambungan V17",statusMessage:"Pangkalan data setempat dan API demo boleh diperiksa; MASTER7 asal, permainan dan pembayaran belum disambungkan.",badResponse:"Perkhidmatan tidak tersedia",noUsers:"Belum ada ahli.",notReady:"Belum disambungkan",save:"Simpan",identity:"Akaun dan OTP"
 }
};

const hostedCopy={"zh": {"demoWarning": "V17 自建服务门户 · 会员与工单已接入独立数据库", "previewLabel": "自建服务门户", "featureOtp": "安全登录", "featureOtpDesc": "使用 ChatGPT 身份验证", "supportIntro": "创建工单并在这里接收员工回复。", "submitTicket": "提交工单", "ticketLogin": "登录并通过会员审批后可提交工单。", "adminIntro": "管理本门户的会员、员工、公告和工单。", "publishAnnouncement": "发布公告", "footerDisclaimer": "客服门户提供会员及工单服务；游戏、充值和提款尚未开放。", "sandbox": "V17 · SERVICE PORTAL", "statusMessage": "独立数据库服务；旧会员、游戏及支付未连接。", "memberApproval": "会员审批与员工授权", "hostedLogin": "使用 ChatGPT 登录", "hostedLoginNotice": "首次登录建立本门户的独立账号。会员需老板审批；员工权限由老板授予。", "refreshRecords": "刷新记录", "staffInstruction": "员工先登录，再由老板在此批准和授权。", "exportRecords": "导出门户数据", "accountPending": "账号已建立，正在等待老板审批。审批后刷新页面即可使用客服。", "reply": "回复内容", "sendReply": "发送回复", "makeStaff": "授权为员工", "removeStaff": "取消员工权限", "credentials": "通过安全登录访问本门户。"}, "en": {"demoWarning": "V17 service portal · Members and support use a dedicated database", "previewLabel": "Self-built service portal", "featureOtp": "Secure sign-in", "featureOtpDesc": "Sign in with ChatGPT", "supportIntro": "Create a ticket and receive replies from our staff.", "submitTicket": "Submit ticket", "ticketLogin": "Sign in and await member approval to submit a ticket.", "adminIntro": "Manage this portal’s members, staff, announcements and tickets.", "publishAnnouncement": "Publish announcement", "footerDisclaimer": "Member and support services. Games, deposits and withdrawals are not connected.", "sandbox": "V17 · SERVICE PORTAL", "statusMessage": "Dedicated portal database. Legacy members, games and payments are not connected.", "memberApproval": "Member approval and staff access", "hostedLogin": "Sign in with ChatGPT", "hostedLoginNotice": "Your first sign-in creates a portal account. The owner approves members and grants staff access.", "refreshRecords": "Refresh records", "staffInstruction": "Staff sign in first, then the owner grants access here.", "exportRecords": "Export portal records", "accountPending": "Your account is awaiting owner approval. Refresh after approval to use support.", "reply": "Reply message", "sendReply": "Send reply", "makeStaff": "Grant staff access", "removeStaff": "Remove staff access", "credentials": "Secure sign-in for this portal."}, "ms": {"demoWarning": "Portal perkhidmatan V17 · Ahli dan tiket dalam pangkalan data khusus", "previewLabel": "Portal perkhidmatan", "featureOtp": "Log masuk selamat", "featureOtpDesc": "Log masuk dengan ChatGPT", "supportIntro": "Cipta tiket dan terima balasan kakitangan di sini.", "submitTicket": "Hantar tiket", "ticketLogin": "Log masuk dan tunggu kelulusan ahli untuk menghantar tiket.", "adminIntro": "Urus ahli, kakitangan, pengumuman dan tiket portal ini.", "publishAnnouncement": "Terbitkan pengumuman", "footerDisclaimer": "Perkhidmatan ahli dan sokongan. Permainan, deposit dan pengeluaran belum disambung.", "sandbox": "V17 · SERVICE PORTAL", "statusMessage": "Pangkalan data portal khusus. Ahli lama, permainan dan pembayaran belum disambung.", "memberApproval": "Kelulusan ahli dan akses kakitangan", "hostedLogin": "Log masuk dengan ChatGPT", "hostedLoginNotice": "Log masuk pertama mencipta akaun portal. Pemilik meluluskan ahli dan akses kakitangan.", "refreshRecords": "Muat semula rekod", "staffInstruction": "Kakitangan log masuk dahulu, kemudian pemilik memberi akses di sini.", "exportRecords": "Eksport rekod portal", "accountPending": "Akaun menunggu kelulusan pemilik. Muat semula selepas kelulusan.", "reply": "Mesej balasan", "sendReply": "Hantar balasan", "makeStaff": "Beri akses kakitangan", "removeStaff": "Buang akses kakitangan", "credentials": "Log masuk selamat untuk portal ini."}};
for(const lang of Object.keys(hostedCopy))Object.assign(translations[lang],hostedCopy[lang]);
const passwordCopy={
 zh:{portalId:"MASTER7 ID",password:"密码",accountSecurity:"账号安全",currentPassword:"当前密码",confirmPassword:"确认新密码",newPassword:"新密码（至少 15 个字符）",activationCode:"一次性激活码",activateTitle:"激活老板账号",activateSubmit:"设置密码并激活",activateNotice:"老板 ID：master7_owner。输入交接激活码，并设置只有你知道的密码。激活码只能使用一次。",loginNotice:"使用你的 MASTER7 ID 和密码登录。前台与后台共用账号，权限由老板管理。",registerNotice:"ID 为 4–32 位字母、数字或下划线；密码为 15–128 个字符。注册后需老板审批。",securityNotice:"可修改登录 ID 和密码。保存后，使用此 ID 登录的设备会退出。ChatGPT 登录独立管理。",createMember:"注册会员 ID",backToLogin:"返回登录",saveAccount:"保存并退出此 ID",passwordMismatch:"两次输入的密码不一致。",activationDone:"老板账号已激活。请使用刚设置的密码登录。",registrationDone:"会员 ID 已建立。登录后等待老板审批。",passwordChanged:"账号已更新，请使用新 ID 和密码登录。",busy:"处理中…",featureOtpDesc:"MASTER7 ID 与密码登录",securityHelp:"忘记密码请联系站点所有者核实身份；本站不会通过聊天索取密码。"},
 en:{portalId:"MASTER7 ID",password:"Password",accountSecurity:"Account security",currentPassword:"Current password",confirmPassword:"Confirm new password",newPassword:"New password (at least 15 characters)",activationCode:"One-time activation code",activateTitle:"Activate owner account",activateSubmit:"Set password and activate",activateNotice:"Owner ID: master7_owner. Enter your handover code and set your own password. The code can only be used once.",loginNotice:"Sign in with your MASTER7 ID and password. One account works across the portal and backoffice, according to its role.",registerNotice:"ID: 4–32 letters, digits or underscores. Password: 15–128 characters. New members require owner approval.",securityNotice:"Change your login ID and password. Saving signs out all password sessions for this ID. ChatGPT sessions are managed separately.",createMember:"Register member ID",backToLogin:"Back to sign-in",saveAccount:"Save and sign out this ID",passwordMismatch:"The passwords do not match.",activationDone:"Owner account activated. Sign in with the password you just set.",registrationDone:"Member ID created. Sign in and await owner approval.",passwordChanged:"Account updated. Sign in with your new ID and password.",busy:"Working…",featureOtpDesc:"Sign in with your MASTER7 ID and password",securityHelp:"Forgot your password? Contact the site owner to verify your identity. Never send your password in chat."},
 ms:{portalId:"ID MASTER7",password:"Kata laluan",accountSecurity:"Keselamatan akaun",currentPassword:"Kata laluan semasa",confirmPassword:"Sahkan kata laluan baharu",newPassword:"Kata laluan baharu (sekurang-kurangnya 15 aksara)",activationCode:"Kod pengaktifan sekali guna",activateTitle:"Aktifkan akaun pemilik",activateSubmit:"Tetapkan kata laluan dan aktifkan",activateNotice:"ID pemilik: master7_owner. Masukkan kod serahan dan tetapkan kata laluan sendiri. Kod hanya boleh digunakan sekali.",loginNotice:"Log masuk dengan ID MASTER7 dan kata laluan. Akaun yang sama digunakan pada portal dan panel mengikut peranan.",registerNotice:"ID: 4–32 huruf, angka atau garis bawah. Kata laluan: 15–128 aksara. Ahli baharu perlu kelulusan pemilik.",securityNotice:"Tukar ID dan kata laluan. Semua sesi kata laluan ID ini akan dilog keluar. Sesi ChatGPT diurus berasingan.",createMember:"Daftar ID ahli",backToLogin:"Kembali ke log masuk",saveAccount:"Simpan dan log keluar ID ini",passwordMismatch:"Kata laluan tidak sepadan.",activationDone:"Akaun pemilik diaktifkan. Log masuk dengan kata laluan baharu.",registrationDone:"ID ahli dicipta. Log masuk dan tunggu kelulusan pemilik.",passwordChanged:"Akaun dikemas kini. Log masuk dengan ID dan kata laluan baharu.",busy:"Memproses…",featureOtpDesc:"Log masuk dengan ID MASTER7 dan kata laluan",securityHelp:"Terlupa kata laluan? Hubungi pemilik laman untuk pengesahan identiti. Jangan hantar kata laluan melalui sembang."}
};
for(const lang of Object.keys(passwordCopy))Object.assign(translations[lang],passwordCopy[lang]);
const activationCopy={
 zh:{activationAlreadyDone:"老板账号已激活。请使用首次激活时设置的密码；重复提交激活页不会更改密码。如果已更改 ID，请输入新 ID。",activationUnavailable:"当前没有可用的激活码。已有账号请登录；首次设置请联系站点维护人员。"},
 en:{activationAlreadyDone:"The owner account is already activated. Use the password set during the first activation; submitting activation again does not change it. If you changed your ID, enter the new ID.",activationUnavailable:"No activation code is currently available. Sign in if you have an account; contact the site maintainer for initial setup."},
 ms:{activationAlreadyDone:"Akaun pemilik sudah diaktifkan. Gunakan kata laluan yang ditetapkan semasa pengaktifan pertama; pengaktifan semula tidak menukar kata laluan. Jika ID telah ditukar, masukkan ID baharu.",activationUnavailable:"Tiada kod pengaktifan tersedia sekarang. Log masuk jika sudah mempunyai akaun; hubungi penyelenggara laman untuk persediaan pertama."}
};
for(const lang of Object.keys(activationCopy))Object.assign(translations[lang],activationCopy[lang]);
const resetCopy={
 zh:{resetUnavailable:"当前没有有效的老板重设码（可能已过期或已使用）。请联系站点维护人员重新签发；不要重复提交旧码。",sessionMissing:"登录响应未建立有效会话，请刷新后重试。",resetTitle:"重设老板密码",resetNotice:"输入私下交接的一次性重设码，并设置新密码。提交成功后，老板账号的旧密码和密码登录会话将失效，网站资料保留。",resetCode:"一次性重设码",resetSubmit:"确认重设密码",resetDone:"密码已重设。请使用新密码登录。",passwordsMatch:"两次密码一致。",showPasswords:"显示新密码（仅在私密环境查看）"},
 en:{resetUnavailable:"No active owner reset code is available. It may have expired or been used. Contact the site maintainer for a new code; do not resubmit the old code.",sessionMissing:"Sign-in did not establish a valid session. Refresh and try again.",resetTitle:"Reset owner password",resetNotice:"Enter your private one-time reset code and choose a new password. A successful reset revokes the owner's old password and password sessions, and preserves site data.",resetCode:"One-time reset code",resetSubmit:"Confirm password reset",resetDone:"Password reset. Sign in with your new password.",passwordsMatch:"The passwords match.",showPasswords:"Show new password (only in private)"},
 ms:{resetUnavailable:"Tiada kod tetapan semula pemilik yang aktif. Kod mungkin tamat tempoh atau telah digunakan. Hubungi penyelenggara untuk kod baharu; jangan hantar kod lama semula.",sessionMissing:"Log masuk tidak menghasilkan sesi sah. Muat semula dan cuba lagi.",resetTitle:"Tetapkan semula kata laluan pemilik",resetNotice:"Masukkan kod tetapan semula sekali guna peribadi dan pilih kata laluan baharu. Selepas berjaya, kata laluan lama dan sesi kata laluan pemilik dibatalkan. Data laman dikekalkan.",resetCode:"Kod tetapan semula sekali guna",resetSubmit:"Sahkan tetapan semula",resetDone:"Kata laluan ditetapkan semula. Log masuk dengan kata laluan baharu.",passwordsMatch:"Kata laluan sepadan.",showPasswords:"Tunjukkan kata laluan baharu (di tempat peribadi sahaja)"}
};
for(const lang of Object.keys(resetCopy))Object.assign(translations[lang],resetCopy[lang]);
function t(key){return translations[state.lang][key] || translations.en[key] || key;}

const socialCopy = {
 zh:{adminTitle:"社交媒体管理",adminHint:"保存官方 Facebook / Instagram 网址；没有连接广告 API。",facebookLabel:"Facebook 公司主页 URL",instagramLabel:"Instagram 公司账号 URL",publishToggle:"在前台显示这些已确认的链接",saveLinks:"保存链接",metaSuite:"打开 Meta Business Suite",metaAds:"打开 Meta 广告管理",noAutoAds:"仅提供官方入口；未获广告审批、没有自动发帖或广告扣费。",publicTitle:"官方社交媒体",publicHint:"仅展示已审核的公司官方主页",readOnly:"只有老板可以修改社媒链接。",noLinks:"尚未设置已审核的社交媒体链接"},
 en:{adminTitle:"Social media management",adminHint:"Save official Facebook / Instagram URLs; no ad API connection.",facebookLabel:"Facebook company page URL",instagramLabel:"Instagram business profile URL",publishToggle:"Show approved links on public frontend",saveLinks:"Save links",metaSuite:"Open Meta Business Suite",metaAds:"Open Meta Ads Manager",noAutoAds:"Official portals only. No advertising approval, auto-posting or ad spending.",publicTitle:"Official social accounts",publicHint:"Only approved official company pages",readOnly:"Only owners can edit social links.",noLinks:"No approved social links configured"},
 ms:{adminTitle:"Pengurusan media sosial",adminHint:"Simpan URL rasmi Facebook / Instagram; API iklan belum disambung.",facebookLabel:"URL halaman syarikat Facebook",instagramLabel:"URL profil perniagaan Instagram",publishToggle:"Papar pautan diluluskan di laman hadapan",saveLinks:"Simpan pautan",metaSuite:"Buka Meta Business Suite",metaAds:"Buka Meta Ads Manager",noAutoAds:"Pautan rasmi sahaja. Tiada kelulusan iklan, penerbitan automatik atau perbelanjaan iklan.",publicTitle:"Media sosial rasmi",publicHint:"Hanya halaman syarikat yang disahkan",readOnly:"Hanya pemilik boleh menyunting pautan.",noLinks:"Tiada pautan media sosial yang disahkan"}
};
const otpStageCopy = {
 zh:{verify:"验证 OTP 后登录",otpStage:"密码已验证，请输入验证器中的 6 位 OTP；5 分钟内有效。"},
 en:{verify:"Verify OTP and sign in",otpStage:"Password verified. Enter the 6-digit authenticator OTP within 5 minutes."},
 ms:{verify:"Sahkan OTP untuk log masuk",otpStage:"Kata laluan disahkan. Masukkan OTP pengesah 6 digit dalam masa 5 minit."}
};
function otpText(k){return (otpStageCopy[state.lang]||otpStageCopy.zh)[k];}
function st(key){return (socialCopy[state.lang]||socialCopy.zh)[key]||key;}
function applySocialLanguage(){document.querySelectorAll("[data-social-key]").forEach(e=>e.textContent=st(e.dataset.socialKey));if(state.user?.role==="staff")$("socialReadOnly").textContent=st("readOnly");}
function renderSocial(){const host=$("publicSocialLinks");clear(host);const data=state.social;const parent=$("publicSocial");parent.hidden=!data?.enabled; if(parent.hidden)return;
 for(const [name,url,hostnames] of [["Facebook",data.facebookUrl,["facebook.com","www.facebook.com"]],["Instagram",data.instagramUrl,["instagram.com","www.instagram.com"]]]){
  if(typeof url!=="string"||!url)continue;
  try{const u=new URL(url);if(u.protocol!=="https:"||!hostnames.includes(u.hostname)||u.username||u.password)continue;
   const a=node("a","social-link",name);a.href=u.href;a.target="_blank";a.rel="noopener noreferrer";host.append(a);}catch{}
 }
 parent.hidden=!host.childElementCount;
}
async function renderSocialAdmin(owner){$("socialForm").hidden=!owner;$("socialReadOnly").hidden=owner;
 const d=await api("/api/admin/social-links");if(owner){$("facebookLink").value=d.facebookUrl||"";$("instagramLink").value=d.instagramUrl||"";$("socialEnabled").checked=!!d.enabled;}else $("socialReadOnly").textContent=st("readOnly");
}
// Branded bonus buttons are an isolated presentation only. No claim/payment requests.
const bonusBrandOptions = Object.freeze([
 {code:"jili",label:"JILI"},
 {code:"megah5",label:"MegaH5"},
 {code:"918kiss",label:"918KISS"}
]);
const bonusBrandTranslations = {
 zh:{title:"三家厂牌 · Claim Bonus",intro:"三家独立品牌入口；一次性免费福利及领取资格尚待厂家正式确认。",brandCount:"品牌入口",locked:"待核实",cta:"查看领取说明",disclosure:"当前采用品牌名称的艺术字设计，不是厂家官方 Logo。免费额度、一次性资格、流水及期限必须由各厂家书面确认；测试版不发放 Bonus。",pending:"尚未开放领取 · 待厂家确认",dialogNotice:"{name} 的一次性免费 Claim Bonus 尚未获得正式核实。目前只能查看说明，不能直接领取。",termsTitle:"需要厂家确认的条件",term1:"是否提供免费一次性领取及真实额度",term2:"适用会员、地区、币种及账号资格",term3:"领取次数、流水要求、截止日期与审核方式",dialogDisclaimer:"本测试版不连接厂家 Bonus API、不创建领取订单，也不调整钱包余额。",close:"关闭"},
 en:{title:"3 Partner Brands · Claim Bonus",intro:"Each brand has its own distinct showcase; one-time free offers and eligibility need provider verification.",brandCount:"Brand entries",locked:"Unverified",cta:"View claim details",disclosure:"These are custom typographic brand treatments, NOT official provider logos. Free amounts, one-time eligibility, wagering and end dates require written provider confirmation. No bonuses are issued here.",pending:"Claims unavailable · Provider verification pending",dialogNotice:"A one-time free Claim Bonus for {name} has not been verified. Preview information only; claiming is unavailable.",termsTitle:"Terms requiring confirmation",term1:"Whether a free one-time offer exists and its exact amount",term2:"Member, country, currency and account eligibility",term3:"Claim limits, wagering conditions, expiration and review",dialogDisclaimer:"This preview has no provider claim API, creates no claim orders, and does not change wallet balances.",close:"Close"},
 ms:{title:"3 Jenama Rakan · Claim Bonus",intro:"Paparan berasingan bagi setiap jenama; tawaran percuma sekali sahaja dan kelayakan belum disahkan oleh pembekal.",brandCount:"Pilihan jenama",locked:"Belum sah",cta:"Lihat syarat tuntutan",disclosure:"Ini hanya reka bentuk tulisan jenama, BUKAN logo rasmi pembekal. Jumlah percuma, kelayakan sekali sahaja, syarat pertaruhan dan tempoh mesti disahkan secara bertulis. Tiada bonus dikeluarkan.",pending:"Tuntutan belum tersedia · Pengesahan diperlukan",dialogNotice:"Bonus percuma sekali sahaja untuk {name} belum disahkan. Paparan maklumat sahaja; tuntutan tidak tersedia.",termsTitle:"Syarat yang perlu disahkan",term1:"Sama ada tawaran percuma sekali sahaja wujud dan amaun tepat",term2:"Kelayakan ahli, lokasi, mata wang dan akaun",term3:"Had tuntutan, syarat pertaruhan, tarikh luput dan semakan",dialogDisclaimer:"Pratonton ini tiada API tuntutan, tidak membuat pesanan dan tidak mengubah baki dompet.",close:"Tutup"}
};
function bonusText(key){return bonusBrandTranslations[state.lang]?.[key] || bonusBrandTranslations.en[key] || key;}
function bonusBrandLookup(code){return bonusBrandOptions.find(b=>b.code===code) || null;}
function renderBonusBrandPreview(){
 document.querySelectorAll("[data-bonus-i18n]").forEach(el=>{el.textContent=bonusText(el.dataset.bonusI18n);});
 for(const b of document.querySelectorAll("[data-bonus-brand]")){
  const provider=bonusBrandLookup(b.dataset.bonusBrand);
  if(provider)b.setAttribute("aria-label",provider.label+" — "+bonusText("locked")+" — "+bonusText("cta"));
 }
 const dialog=document.getElementById("bonusDialog");
 const provider=bonusBrandLookup(dialog?.dataset.brand);
 if(provider)document.getElementById("bonusDialogNotice").textContent=bonusText("dialogNotice").replace("{name}",provider.label);
}
function bindBonusBrandPreview(){
 document.querySelectorAll("[data-bonus-brand]").forEach(button=>button.addEventListener("click",()=>{
  const provider=bonusBrandLookup(button.dataset.bonusBrand);
  if(!provider)return;
  const dialog=document.getElementById("bonusDialog");
  dialog.dataset.brand=provider.code;
  document.getElementById("bonusDialogTitle").textContent=provider.label;
  document.getElementById("bonusDialogNotice").textContent=bonusText("dialogNotice").replace("{name}",provider.label);
  dialog.showModal();
 }));
 document.getElementById("closeBonusDialog").addEventListener("click",()=>document.getElementById("bonusDialog").close());
 document.getElementById("dismissBonusDialog").addEventListener("click",()=>document.getElementById("bonusDialog").close());
}

const paymentPreview = Object.freeze([
 {code:"vpay",label:"VPAY"},
 {code:"gspay",label:"GSPAY"},
 {code:"1mpay",label:"1MPAY"},
 {code:"gspay-plus",label:"GSPAY+"}
]);
const paymentPreviewCopy = {
 zh:{title:"四个支付入口",notice:"四家公司／通道独立展示，全部以 MYR 为单位；目前只供预览。",vpayHint:"独立入口 · MYR",gspayHint:"独立入口 · MYR",oneMpayHint:"独立入口 · MYR",gspayPlusHint:"GSP 额外通道 · MYR",status:"未接通 · 查看状态",caveat:"GSPAY+ 暂按第四个展示入口设计；是否为独立公司、正式商户号及 MYR 交易权限仍待核实。",dialogText:"{name} 尚未完成正式接口、回调及后台对账验收，不能存款或提款。",dialogWarning:"此测试按钮不连接顾客钱包、不创建支付订单，也不扣款。",dismiss:"关闭"},
 en:{title:"Four payment options",notice:"Four separate MYR entries for layout preview only; none are connected to live payments.",vpayHint:"Separate option · MYR",gspayHint:"Separate option · MYR",oneMpayHint:"Separate option · MYR",gspayPlusHint:"Additional GSP channel · MYR",status:"Offline · View status",caveat:"GSPAY+ is shown as the fourth option pending verification of its company identity, merchant configuration and MYR authorization.",dialogText:"{name} is not live. Its gateway, callbacks and backoffice reconciliation have not been verified; deposits and withdrawals are unavailable.",dialogWarning:"This preview does not connect wallets, create payment orders or charge money.",dismiss:"Close"},
 ms:{title:"Empat pilihan pembayaran",notice:"Empat pilihan MYR dipaparkan secara berasingan untuk pratonton sahaja; tiada pembayaran langsung.",vpayHint:"Pilihan berasingan · MYR",gspayHint:"Pilihan berasingan · MYR",oneMpayHint:"Pilihan berasingan · MYR",gspayPlusHint:"Saluran tambahan GSP · MYR",status:"Belum aktif · Lihat status",caveat:"GSPAY+ dipaparkan sebagai pilihan keempat sementara status syarikat, ID peniaga dan kebenaran MYR disahkan.",dialogText:"{name} belum disahkan untuk pembayaran sebenar, panggil balik atau rekonsiliasi; deposit dan pengeluaran tidak tersedia.",dialogWarning:"Butang demo ini tidak menghubungkan dompet, membuat pesanan bayaran atau mengenakan caj.",dismiss:"Tutup"}
};
function paymentText(key){return paymentPreviewCopy[state.lang]?.[key] || paymentPreviewCopy.en[key] || key;}
function paymentPreviewStatus(code){return paymentPreview.find(p=>p.code===code) || null;}
function renderPaymentPreview(){
 document.querySelectorAll("[data-payment-i18n]").forEach(el=>{el.textContent=paymentText(el.dataset.paymentI18n);});
 const dialog=$("paymentDialog");
 const current=dialog?.dataset.channel;
 if(current){const p=paymentPreviewStatus(current);if(p)$("paymentDialogText").textContent=paymentText("dialogText").replace("{name}",p.label);}
 for(const button of document.querySelectorAll("[data-payment-channel]")){
  const p=paymentPreviewStatus(button.dataset.paymentChannel);
  if(p) button.setAttribute("aria-label",p.label+" · "+paymentText("status"));
 }
}
function bindPaymentPreview(){
 document.querySelectorAll("[data-payment-channel]").forEach(button=>button.addEventListener("click",()=>{
   const p=paymentPreviewStatus(button.dataset.paymentChannel);if(!p)return;
   $("paymentDialog").dataset.channel=p.code;
   $("paymentDialogTitle").textContent=p.label;
   $("paymentDialogText").textContent=paymentText("dialogText").replace("{name}",p.label);
   $("paymentDialog").showModal();
 }));
 $("closePaymentDialog").addEventListener("click",()=>$("paymentDialog").close());
 $("dismissPaymentDialog").addEventListener("click",()=>$("paymentDialog").close());
}


function node(tag, css="", text=""){const x=document.createElement(tag);if(css)x.className=css;if(text!==null)x.textContent=String(text);return x;}
function clear(el){el.replaceChildren();}
function notification(text){const n=$("toast");n.textContent=text;n.classList.add("show");setTimeout(()=>n.classList.remove("show"),4200);}
function applyLang(){document.documentElement.lang=state.lang==="zh"?"zh-Hans":state.lang;document.querySelectorAll("[data-i18n]").forEach(el=>{el.textContent=t(el.dataset.i18n);});document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{el.placeholder=t(el.dataset.i18nPlaceholder);});renderCatalog();renderAnnouncements();renderTickets();renderSession();renderPaymentPreview();renderBonusBrandPreview();applySocialLanguage();renderSocial();renderAuthMode();if(state.section==="admin")renderAdmin();}
async function api(url,method="GET",payload=undefined){
 const headers={};
 if(payload!==undefined)headers["Content-Type"]="application/json";
 if(method!=="GET"&&state.csrf)headers["X-CSRF-Token"]=state.csrf;
 const controller=new AbortController();
 let timedOut=false;
 const timer=setTimeout(()=>{timedOut=true;controller.abort();},12000);
 const unavailable=(key,status)=>{const error=new Error(t(key));error.connectionFailure=true;error.status=status;return error;};
 try{
  const resp=await fetch(url,{method,headers,credentials:"same-origin",body:payload===undefined?undefined:JSON.stringify(payload),cache:"no-store",signal:controller.signal});
  if(!/^application\/json(?:;|$)/i.test(resp.headers.get("Content-Type")||""))throw unavailable("badResponse",resp.status);
  let body;
  try{body=await resp.json();}catch{throw unavailable("badResponse",resp.status);}
  if(!body||typeof body!=="object"||Array.isArray(body))throw unavailable("badResponse",resp.status);
  if(!resp.ok){
   if(resp.status>=500)throw unavailable("serviceUnavailable",resp.status);
   const error=new Error(body.error||`${resp.status} ${t("badResponse")}`);error.status=resp.status;throw error;
  }
  return body;
 }catch(error){
  if(timedOut)throw unavailable("requestTimeout");
  if(error.name==="TypeError")throw unavailable("networkError");
  throw error;
 }finally{clearTimeout(timer);}
}
function selected(section){state.section=section;document.querySelectorAll(".section").forEach(el=>el.classList.toggle("active",el.id===section));document.querySelectorAll(".nav-button").forEach(el=>el.classList.toggle("active",el.dataset.section===section));window.scrollTo({top:0,behavior:"smooth"});if(section==="support")refreshTickets();if(section==="admin")renderAdmin();}
function renderSession(){const u=state.user;$("accountSecurity").hidden=!(u&&state.authMethod==="password");$("accountNotice").hidden=!u||u.approved;$("accountNotice").textContent=t("accountPending");$("loginButton").hidden=!!u;$("logoutButton").hidden=!u;$("userChip").hidden=!u;$("adminNav").hidden=!(u&&(u.role==="owner"||u.role==="staff"));if(u)$("userChip").textContent=`${u.username} · ${t("role_"+u.role)}`;if(state.section==="admin"&&!u)renderAdmin();}
function renderAnnouncements(){const host=$("announcements");clear(host);if(!state.announcements.length){host.append(node("p","muted",t("noAnnouncements")));return;}for(const a of state.announcements){const card=node("article","announcement"),title=node("h3","",a.title),body=node("p","",a.body),time=node("time","",new Date(a.created_at*1000).toLocaleDateString(state.lang==="zh"?"zh-CN":state.lang));card.append(title,body,time);host.append(card);}}
function renderCatalog(){const el=$("providers");clear(el);const search=($("search").value||"").toLowerCase().trim();const list=state.games.filter(g=>!search||`${g.name} ${g.nameZh} ${g.providerName} ${g.category}`.toLowerCase().includes(search));const status=$("gamesStatus");if(status){if(!state.gameCatalogue)status.textContent=t("gamesLoading");else if(!state.games.length)status.textContent=t("catalogUnavailable");else{const text=t("catalogSummary").replace("{count}",state.games.length);const providers=state.gameCatalogue.providers.map(p=>`${p.name}: ${t(({available:"providerAvailable",blocked:"providerBlocked",unavailable:"providerUnavailable",empty:"providerEmpty",not_configured:"providerNotConfigured"})[p.status]||"providerUnavailable")} (${p.count})`).join(" · ");status.textContent=`${text} ${providers}`;}}if(!list.length){el.append(node("p","muted",t("itemSearchNoResults")));return;}for(const g of list){const item=node("article","provider-card game-card"),cover=node("div","game-cover"),title=node("h3","",g.nameZh||g.name),provider=node("p","",g.providerName),category=node("p","",g.category?`ID ${g.category}`:""),tag=node("span","tag",t("uatNotPlayable"));if(g.imageUrl){const img=document.createElement("img");img.src=g.imageUrl;img.alt="";img.loading="lazy";img.referrerPolicy="no-referrer";img.onerror=()=>img.remove();cover.append(img);}else cover.textContent="7";item.append(cover,title,provider,category,tag);el.append(item);}}
function renderTickets(){const host=$("tickets");clear(host);if(!state.user){host.append(node("p","muted",t("loginFirst")));return;}if(!state.tickets.length){host.append(node("p","muted",t("noTickets")));return;}for(const ticket of state.tickets){const box=node("div","ticket"),heading=node("h4","",`#${ticket.id} · ${ticket.subject}`),msg=node("p","",ticket.message),meta=node("time","",`${ticket.username} · ${new Date(ticket.created_at*1000).toLocaleString()} · ${t(ticket.status)}`);box.append(heading,msg,meta);if(state.user.role!=="member"){const close=node("button","button button-ghost",ticket.status==="open"?t("closeTicket"):t("reopenTicket"));close.type="button";close.onclick=async()=>{try{await api("/api/admin/ticket-status","POST",{ticketId:ticket.id,status:ticket.status==="open"?"closed":"open"});await refreshTickets();await renderAdmin();notification(t("success"));}catch(e){notification(e.message)}};box.append(close);}for(const reply of ticket.replies||[]){const replyBox=node("div","ticket-reply");replyBox.append(node("small","muted",reply.username+" · "+new Date(reply.created_at*1000).toLocaleString()),node("p","",reply.message));box.append(replyBox);}if(ticket.status==="open"&&state.user.approved){const form=node("form","stack"),input=node("textarea");input.required=true;input.maxLength=2000;input.rows=2;input.setAttribute("aria-label",t("reply"));input.placeholder=t("reply");const send=node("button","button button-outline",t("sendReply"));send.type="submit";form.append(input,send);form.onsubmit=async e=>{e.preventDefault();send.disabled=true;try{await api("/api/tickets/reply","POST",{ticketId:ticket.id,message:input.value});await refreshTickets();}catch(e){notification(e.message);send.disabled=false;}};box.append(form);}host.append(box);}}
async function refreshTickets(){if(!state.user){state.tickets=[];renderTickets();return;}try{const r=await api("/api/tickets");state.tickets=r.items;renderTickets();}catch(e){notification(e.message)}}
async function loadPublic(){try{const [providers,anns,social]=await Promise.all([api("/api/providers"),api("/api/announcements"),api("/api/social-links")]);state.providers=providers.items;state.announcements=anns.items;state.social=social;renderAnnouncements();renderSocial();}catch(e){notification(e.message)}loadGameCatalogue();}
async function loadGameCatalogue(){try{state.gameCatalogue=await api("/api/games");state.games=state.gameCatalogue.games||[];renderCatalog();}catch(e){state.gameCatalogue={providers:[],games:[]};state.games=[];renderCatalog();}}
function renderItem(host,left,right,buttonLabel,action,disabled=false){const row=node("div","row-item"),lhs=node("div"),name=node("strong","",left);lhs.append(name);if(right)lhs.append(node("small","",right));row.append(lhs);if(buttonLabel){const btn=node("button","button button-outline",buttonLabel);btn.type="button";btn.disabled=disabled;btn.addEventListener("click",action);row.append(btn);}host.append(row);}
const previewDashboardCopy = {
 zh:{ops:"今日门户数据",opsNotice:"真实 Deposit、Withdraw、Bonus、进群数据尚未接通；未连接不等于 RM0。",security:"🔒 今日操作监控",securityNotice:"本站统计业务写入限流；密码登录已设尝试限制，尚未汇总到此面板，显示 —。",newMembers:"今日新会员",deposit:"Deposit 充值 (MYR)",withdraw:"Withdraw 提款 (MYR)",bonus:"Bonus 奖励 (MYR)",netRevenue:"营业净收益 (MYR)",group:"今日进群人数",loginDenied:"登录失败",loginBlocked:"登录限流",registerBlocked:"注册限流",writeBlocked:"操作限流",unavailable:"未连接"},
 en:{ops:"Today's portal activity",opsNotice:"Real deposit, withdrawal, bonus and group data are not connected. Missing is not zero.",security:"🔒 Today's portal security",securityNotice:"Password sign-in is rate-limited. This panel counts business write limits; unavailable totals are shown as —.",newMembers:"New portal members",deposit:"Deposit (MYR)",withdraw:"Withdraw (MYR)",bonus:"Bonus (MYR)",netRevenue:"Net operating revenue (MYR)",group:"Group joins today",loginDenied:"Rejected logins",loginBlocked:"Login rate-limited",registerBlocked:"Registration rate-limited",writeBlocked:"Write rate-limited",unavailable:"Not connected"},
 ms:{ops:"Aktiviti portal hari ini",opsNotice:"Data deposit, pengeluaran, bonus dan kumpulan sebenar belum disambung; tiada data bukan RM0.",security:"🔒 Keselamatan portal",securityNotice:"Log masuk kata laluan mempunyai had percubaan. Metrik belum tersedia dipaparkan sebagai —.",newMembers:"Ahli portal baharu",deposit:"Deposit (MYR)",withdraw:"Pengeluaran (MYR)",bonus:"Bonus (MYR)",netRevenue:"Hasil operasi bersih (MYR)",group:"Ahli sertai kumpulan",loginDenied:"Log masuk ditolak",loginBlocked:"Had log masuk",registerBlocked:"Had pendaftaran",writeBlocked:"Had perubahan",unavailable:"Belum disambung"}
};
function previewMetric(host,value,label,missing){const item=node("div","stat");item.append(node("strong","",missing?"—":value),node("span","",label+(missing?" · "+(previewDashboardCopy[state.lang]||previewDashboardCopy.zh).unavailable:"")));host.append(item);}
async function renderPreviewDashboards(owner){
 const text=previewDashboardCopy[state.lang]||previewDashboardCopy.zh;
 $("operationsHeading").textContent=text.ops;$("operationsNotice").textContent=text.opsNotice;
 $("securityHeading").textContent=text.security;$("securityNotice").textContent=text.securityNotice;
 const op=await api("/api/admin/operations");const grid=$("operationsStats");clear(grid);
 for(const [name,label] of [["depositMYR",text.deposit],["withdrawMYR",text.withdraw],["bonusMYR",text.bonus],["netRevenueMYR",text.netRevenue],["groupJoins",text.group],["newMembersPreview",text.newMembers]]){
  const value=op.metrics[name];previewMetric(grid,value,label,value===null||value===undefined);
 }
 $("securityPanel").hidden=!owner;
 if(owner){const sec=await api("/api/admin/security"),host=$("securityStats");clear(host);
  for(const [name,label] of [["login_denied",text.loginDenied],["login_rate_limited",text.loginBlocked],["registration_rate_limited",text.registerBlocked],["write_rate_limited",text.writeBlocked]])previewMetric(host,sec.today[name],label,sec.today[name]===null);
 }
}
async function renderAdmin(){const auth=state.user&&(state.user.role==="owner"||state.user.role==="staff");$("adminBody").hidden=!auth;$("adminDenied").hidden=!!auth;if(!auth)return;try{const sum=await api("/api/admin/summary");const host=$("adminStats");clear(host);for(const [value,key] of [[sum.users,"users"],[sum.pending,"pending"],[sum.ticketsOpen,"openTickets"],[sum.providersVisible,"visibleProviders"]]){const item=node("div","stat");item.append(node("strong","",value),node("span","",t(key)));host.append(item);}const prov=$("providerManager");clear(prov);for(const p of state.providers){renderItem(prov,p.name,t(p.visible?"visible":"hidden"),p.visible?t("hidden"):t("visible"),async()=>{try{await api("/api/admin/provider","POST",{id:p.id,visible:!Boolean(p.visible)});await loadPublic();await renderAdmin();notification(t("success"));}catch(e){notification(e.message)}})}
 const owner=state.user.role==="owner";await renderPreviewDashboards(owner);await renderSocialAdmin(owner);$("pendingPanel").hidden=!owner;$("auditPanel").hidden=!owner;if(owner){const users=(await api("/api/admin/users")).items,list=$("userManager");clear(list);for(const x of users){renderItem(list,x.username,`${t("role_"+x.role)} · ${x.approved?t("approved"):t("pending")}`,x.approved||x.role!=="member"?null:t("approve"),async()=>{try{await api("/api/admin/approve","POST",{userId:x.id});await renderAdmin();notification(t("success"));}catch(e){notification(e.message)}});if(x.role!=="owner"){renderItem(list,t("role_"+x.role),null,x.role==="staff"?t("removeStaff"):t("makeStaff"),async()=>{try{await api("/api/admin/role","POST",{userId:x.id,role:x.role==="staff"?"member":"staff"});await renderAdmin();notification(t("success"));}catch(e){notification(e.message);}});}}const logs=(await api("/api/admin/audit")).items,auditHost=$("auditLog");clear(auditHost);for(const a of logs.slice(0,25))renderItem(auditHost,`${a.event} · ${a.target}`,`${a.username||"system"} · ${new Date(a.created_at*1000).toLocaleString()}`);}}
catch(e){notification(e.message)}}
function showAuth(mode="login"){
 state.authMode=mode;$("passwordForm").reset();$("authFeedback").textContent="";
 $("showPasswords").checked=false;$("authPassword").type=$("confirmPassword").type="password";$("passwordMatch").textContent="";
 if(mode==="activate")$("authUsername").value="master7_owner";
 if(mode==="security")$("authUsername").value=state.user?.username||"";
 renderAuthMode();if(!$("authDialog").open)$("authDialog").showModal();
}
function activationToSignIn(message){
 showAuth("login");$("authUsername").value="master7_owner";$("authFeedback").textContent=message;
 history.replaceState(null,"","/signin");
}
async function openActivation(){
 try{
  const options=await api("/api/auth/options");
  if(options.ownerSetupComplete)activationToSignIn(t("activationAlreadyDone"));
  else if(options.ownerSetupAvailable)showAuth("activate");
  else activationToSignIn(t("activationUnavailable"));
 }catch(error){showAuth("login");$("authFeedback").textContent=error.message;}
}
async function openOwnerReset(){
 try{
  const options=await api("/api/auth/options");
  if(options.ownerResetAvailable===true)showAuth("reset");
  else {showAuth("login");$("authFeedback").textContent=t("resetUnavailable");}
 }catch(error){showAuth("login");$("authFeedback").textContent=error.message;}
}
function renderAuthMode(){
 const mode=state.authMode,creating=mode!=="login";
 $("authTitle").textContent=t(mode==="reset"?"resetTitle":mode==="activate"?"activateTitle":mode==="security"?"accountSecurity":mode==="register"?"createMember":"signInTitle");
 $("authNotice").textContent=t(mode==="reset"?"resetNotice":mode==="activate"?"activateNotice":mode==="security"?"securityNotice":mode==="register"?"registerNotice":"loginNotice");
 $("authUsername").readOnly=mode==="activate";
 $("usernameField").hidden=mode==="reset";$("authUsername").required=mode!=="reset";
 $("activationField").hidden=mode!=="activate"&&mode!=="reset";$("activationCode").required=mode==="activate"||mode==="reset";
 $("codeLabel").textContent=t(mode==="reset"?"resetCode":"activationCode");
 $("currentPasswordField").hidden=mode!=="security";$("currentPassword").required=mode==="security";
 $("passwordLabel").textContent=t(creating?"newPassword":"password");
 $("authPassword").autocomplete=creating?"new-password":"current-password";$("authPassword").minLength=creating?15:1;
 $("confirmPasswordField").hidden=!creating;$("confirmPassword").required=creating;
 $("showPasswordField").hidden=!creating;
 $("authSubmit").textContent=t(mode==="reset"?"resetSubmit":mode==="activate"?"activateSubmit":mode==="security"?"saveAccount":mode==="register"?"createMember":"signIn");
 $("registerToggle").textContent=t(mode==="login"?"createMember":"backToLogin");$("registerToggle").hidden=mode==="security";
 $("ownerResetLink").hidden=mode!=="login";
}
async function refreshSession(){const s=await api("/api/session");state.user=s.user;state.csrf=s.csrf;state.authMethod=s.authMethod;renderSession();}
function bindPasswordAuth(){
 $("adminSignIn").onclick=()=>showAuth();$("accountSecurity").onclick=()=>showAuth("security");
 $("registerToggle").onclick=()=>showAuth(state.authMode==="login"?"register":"login");
 $("authDialog").addEventListener("close",()=>$("passwordForm").reset());
 $("showPasswords").onchange=()=>{$("authPassword").type=$("confirmPassword").type=$("showPasswords").checked?"text":"password";};
 for(const id of ["authPassword","confirmPassword"] )$(id).addEventListener("input",()=>{
  $("authFeedback").textContent="";
  $("passwordMatch").textContent=state.authMode!=="login"&&$("confirmPassword").value?t($("authPassword").value===$("confirmPassword").value?"passwordsMatch":"passwordMismatch"):"";
 });
 $("logoutButton").onclick=async e=>{if(state.authMethod!=="password")return;e.preventDefault();try{await api("/api/auth/logout","POST",{});location.assign("/signin");}catch(error){notification(error.message);}};
 $("passwordForm").addEventListener("submit",async e=>{
  e.preventDefault();const mode=state.authMode,username=$("authUsername").value.trim(),pass=$("authPassword").value;
  if(mode!=="login"&&pass!==$("confirmPassword").value){$("authFeedback").textContent=t("passwordMismatch");return;}
  const submit=$("authSubmit");submit.disabled=true;submit.textContent=t("busy");$("authFeedback").textContent="";
  try{
   if(mode==="login"){
    await api("/api/auth/login","POST",{username,password:pass});await refreshSession();if(!state.user)throw new Error(t("sessionMissing"));$("authDialog").close();await loadPublic();await refreshTickets();
    if(state.user&&(state.user.role==="owner"||state.user.role==="staff")){history.replaceState(null,"","/admin");selected("admin");}else{history.replaceState(null,"","/");selected("support");}
   }else if(mode==="activate"){
    const result=await api("/api/auth/activate","POST",{code:$("activationCode").value.trim(),password:pass});showAuth("login");$("authUsername").value=result.username;$("authFeedback").textContent=t("activationDone");history.replaceState(null,"","/signin");
   }else if(mode==="register"){
    await api("/api/auth/register","POST",{username,password:pass});showAuth("login");$("authUsername").value=username;$("authFeedback").textContent=t("registrationDone");
   }else if(mode==="reset"){
    const result=await api("/api/auth/reset-owner","POST",{code:$("activationCode").value.trim(),password:pass});
    state.user=null;state.csrf=null;state.authMethod=null;state.tickets=[];renderSession();renderTickets();
    showAuth("login");$("authUsername").value=result.username;$("authFeedback").textContent=t("resetDone");history.replaceState(null,"","/signin");
   }else{
    await api("/api/auth/change-password","POST",{currentPassword:$("currentPassword").value,newPassword:pass,newUsername:username});state.user=null;state.csrf=null;state.authMethod=null;state.tickets=[];renderSession();renderTickets();showAuth("login");$("authUsername").value=username;$("authFeedback").textContent=t("passwordChanged");
   }
  }catch(error){
   let completed=false;
   if(mode==="activate"&&error.status===409){
    try{completed=(await api("/api/auth/options")).ownerSetupComplete===true;}catch{}
   }
   if(completed)activationToSignIn(t("activationAlreadyDone"));
   else $("authFeedback").textContent=error.message;
  }finally{submit.disabled=false;renderAuthMode();}
 });
}
function bind(){document.querySelectorAll("[data-section]").forEach(b=>b.onclick=()=>selected(b.dataset.section));$("exploreButton").onclick=()=>selected("lobby");$("aboutButton").onclick=async()=>{try{const data=await api("/health");notification(`${t("statusTitle")}: ${data.status} · ${data.release} · ${t("statusMessage")}`);}catch(e){notification(e.message)}};$("loginButton").onclick=()=>showAuth();$("closeAuth").onclick=()=>$("authDialog").close();$("refreshTickets").onclick=refreshTickets;$("search").oninput=renderCatalog;$("category").onchange=renderCatalog;$("locale").onchange=e=>{state.lang=e.target.value;applyLang();};$("ticketForm").addEventListener("submit",async e=>{e.preventDefault();if(!state.user){showAuth();return;}try{await api("/api/tickets","POST",{subject:$("ticketSubject").value,message:$("ticketMessage").value});$("ticketForm").reset();await refreshTickets();notification(t("success"));}catch(err){notification(err.message)}});$("socialForm").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/admin/social-links","POST",{facebookUrl:$("facebookLink").value,instagramUrl:$("instagramLink").value,enabled:$("socialEnabled").checked});await loadPublic();await renderSocialAdmin(true);notification(t("success"));}catch(err){notification(err.message)}});$("announcementForm").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/admin/announcement","POST",{title:$("announcementTitle").value,body:$("announcementBody").value});$("announcementForm").reset();await loadPublic();notification(t("success"));}catch(err){notification(err.message)}});}
(async function start(){bind();bindPasswordAuth();bindPaymentPreview();bindBonusBrandPreview();
 if(location.pathname==="/admin")selected("admin");
 applyLang();
 if(location.pathname==="/activate")await openActivation();
 else if(location.pathname==="/reset-owner")await openOwnerReset();
 else if(location.pathname==="/signin")showAuth();
 try{await refreshSession();}catch{renderSession();}
 await loadPublic();if(state.user)await refreshTickets();if(state.section==="admin")renderAdmin();
})();
