"use strict";
(function master7RewardsHub(){
 const byId=id=>document.getElementById(id);
 const el=(tag,className,value)=>{const item=document.createElement(tag);if(className)item.className=className;if(value!==undefined)item.textContent=String(value);return item;};
 const locale=()=>typeof state!=="undefined"&&["en","zh","ms"].includes(state.lang)?state.lang:"zh";
 const copy=(english,chinese)=>locale()==="en"?english:chinese;
 const hub={publicData:null,publicError:null,adminData:null,loading:false,promotions:[],promotionCategory:"all"};
 const number=value=>{const parsed=Number(value);return Number.isFinite(parsed)&&parsed>=0?parsed:0;};
 const integer=value=>Math.max(0,Math.trunc(number(value)));
 const chip=(label,ready)=>el("span",`rewards-chip ${ready?"ready":"pending"}`,`${ready?"●":"○"} ${label}`);

 function promotionKind(item){
  const rules=item?.rules||{},copy=`${item?.title||""} ${item?.description||""} ${rules.rewardType||""}`.toLowerCase();
  if(rules.newMemberOnly===true||/welcome|new member|newbie/.test(copy))return "new-member";
  if(Number(rules.freeChances)>0||rules.providerId&&rules.providerId!=="all"||/game|spin|slot|casino/.test(copy))return "games";
  if(rules.rewardAmountMYR!=null||rules.rewardPercent!=null||rules.minDepositMYR!=null||/deposit|reload|cashback|rebate/.test(copy))return "deposit";
  return "other";
 }
 function promotionKindLabel(kind){return {"new-member":"NEW MEMBER",deposit:"DEPOSIT",games:"GAME OFFER",other:"MEMBER OFFER"}[kind]||"MEMBER OFFER";}
 function promotionTerms(rules={}){
  const terms=[];
  if(rules.newMemberOnly===true)terms.push("New members only");
  if(rules.rewardAmountMYR!=null)terms.push(`Reward RM ${number(rules.rewardAmountMYR).toFixed(2)}`);
  if(rules.rewardPercent!=null)terms.push(`Reward ${number(rules.rewardPercent)}%`);
  if(number(rules.freeChances)>0)terms.push(`${integer(rules.freeChances)} free chances`);
  if(rules.minDepositMYR!=null)terms.push(`Minimum deposit RM ${number(rules.minDepositMYR).toFixed(2)}`);
  if(number(rules.turnoverRequiredMYR)>0)terms.push(`Displayed turnover RM ${number(rules.turnoverRequiredMYR).toFixed(2)}`);
  else if(number(rules.turnoverMultiplier)>0)terms.push(`Displayed turnover ${number(rules.turnoverMultiplier)}×`);
  if(number(rules.validityDays)>0)terms.push(`${integer(rules.validityDays)} day validity`);
  return terms.join(" · ")||"Review the published offer details before taking part.";
 }
 function renderPromotions(data={}){
  const host=byId("promotionsPublishedList");if(!host)return;
  hub.promotions=Array.isArray(data.items)?data.items:hub.promotions;host.replaceChildren();
  const visible=hub.promotions.filter(item=>hub.promotionCategory==="all"||promotionKind(item)===hub.promotionCategory);
  if(!visible.length){host.append(el("p","promotions-empty",hub.promotions.length?"No published promotions are available in this category.":"No published promotions are available right now."));return;}
  visible.forEach((item,index)=>{
   const kind=promotionKind(item),card=el("article",`promotion-card promotion-${kind}`),button=el("button","promotion-card-main"),art=el("span","promotion-card-art"),artBrand=el("strong","","MASTER7"),artLabel=el("span","",promotionKindLabel(kind)),copy=el("span","promotion-card-copy"),title=el("strong","",item.title||"MASTER7 member offer"),summary=el("span","",item.description||"Open to review the published promotion details."),arrow=el("span","promotion-card-arrow","›"),detail=el("div","promotion-card-detail"),terms=el("p","promotion-card-terms",promotionTerms(item.rules)),notice=el("p","promotion-card-notice","Details and eligibility only · No automatic wallet credit or reward claim");
   button.type="button";button.setAttribute("aria-expanded","false");detail.id=`promotion-detail-${index}`;detail.hidden=true;button.setAttribute("aria-controls",detail.id);art.setAttribute("aria-hidden","true");art.append(artBrand,artLabel);copy.append(title,summary);button.append(art,copy,arrow);detail.append(terms,notice);button.onclick=()=>{const open=detail.hidden;detail.hidden=!open;button.setAttribute("aria-expanded",String(open));arrow.textContent=open?"⌄":"›";};card.append(button,detail);host.append(card);
  });
 }

 function renderStatus(data){
  const host=byId("rewardsProgramStatus"),program=data?.program||{};if(!host)return;
  host.replaceChildren(chip(program.enabled?"PROGRAM ON":"PROGRAM OFF",program.enabled),chip(program.pointsEnabled?`${program.pointsName||"Lucky Points"} ON`:"POINTS OFF",program.pointsEnabled),chip("NON-CASH LEDGER",true),chip("NO REDEMPTION",false));
  const notice=byId("rewardsNotice");if(notice)notice.textContent=program.enabled?copy("Rewards Hub is available. Only connected data sources show actual progress; points do not enter the real-money wallet and cannot be redeemed for cash.","Rewards Hub 已开放。只有已连接的数据来源会显示实际进度；积分不会进入真钱钱包，也不能兑换现金。"):copy("Rewards Hub is not available yet. Management can configure it in the backoffice; no points are issued while it is off.","Rewards Hub 尚未开放。管理员可先在后台配置，关闭期间不会派发积分。");
 }
 function renderPoints(member,program){
  const panel=byId("rewardsMemberArea"),login=byId("rewardsLoginNotice"),isMember=typeof state!=="undefined"&&state.user?.role==="member";
  if(panel)panel.hidden=!isMember||!member;if(login)login.hidden=isMember&&!!member;if(!isMember||!member)return;
  byId("rewardsPointsBalance").textContent=integer(member.points?.balance).toLocaleString();
  byId("rewardsPointsName").textContent=program.pointsName||"Lucky Points";
  const week=byId("rewardsWeek");week.replaceChildren();const next=integer(member.checkIn?.nextCycleDay)||1;
  (member.checkIn?.dailyPoints||[0,0,0,0,0,0,0]).forEach((points,index)=>{const day=el("div",`rewards-day${next===index+1?" current":""}${member.checkIn?.checkedInToday&&next===index+1?" claimed":""}`);day.append(el("span","",`DAY ${index+1}`),el("strong","",`+${integer(points)}`),el("span","",program.pointsName||"POINTS"));week.append(day);});
  const button=byId("rewardsCheckIn"),enabled=Boolean(member.checkIn?.enabled),done=Boolean(member.checkIn?.checkedInToday);button.disabled=!enabled||done;button.textContent=done?copy("Checked in today","今日已签到"):enabled?copy("Check in for points","签到领取积分"):copy("Check-in unavailable","签到尚未开放");
  byId("rewardsCheckInMeta").textContent=locale()==="en"?`MYT · ${integer(member.checkIn?.streak)} day streak · Day ${next}`:`MYT · 连续 ${integer(member.checkIn?.streak)} 天 · 第 ${next} 天`;
 }
 function renderLedger(member){const host=byId("rewardsLedger");if(!host)return;host.replaceChildren();const entries=member?.points?.ledger||[];if(!entries.length){host.append(el("p","rewards-empty",copy("No points history yet.","暂无积分记录。")));return;}entries.forEach(item=>{const row=el("div","rewards-ledger-row"),entryCopy=el("div");entryCopy.append(el("strong","",item.source_type==="checkin"?copy("Daily check-in","每日签到"):"Rewards event"),el("span","",new Date(number(item.created_at)*1000).toLocaleString()));row.append(entryCopy,el("strong","",`+${integer(item.points)}`));host.append(row);});}
 function renderPublic(data){hub.publicError=null;hub.publicData=data||{};renderStatus(hub.publicData);renderPoints(data?.member,data?.program||{});renderLedger(data?.member);}
 function renderPublicError(error){hub.publicError=error;const notice=byId("rewardsNotice");if(notice)notice.textContent=`${copy("Rewards Hub is temporarily unavailable","Rewards Hub 暂时无法读取")}：${error.message}`;renderPromotions({items:[]});}
 async function loadPublic(){if(hub.loading)return;hub.loading=true;try{const [rewards,promotions]=await Promise.all([api("/api/rewards"),api("/api/benefits").catch(()=>({items:[]}))]);renderPublic(rewards);renderPromotions(promotions);}catch(error){renderPublicError(error);}finally{hub.loading=false;}}
 async function checkIn(){const button=byId("rewardsCheckIn");button.disabled=true;try{const result=await api("/api/rewards/check-in","POST",{});hub.publicData={...(hub.publicData||{}),member:result.member};renderPublic(hub.publicData);if(typeof notification==="function")notification(result.idempotent?copy("Already checked in today.","今日已经签到。"):`${copy("Check-in complete","签到成功")} · +${integer(result.points)} ${hub.publicData.program?.pointsName||"Points"}`);}catch(error){if(typeof notification==="function")notification(error.message);else button.title=error.message;}finally{if(!hub.publicData?.member?.checkIn?.checkedInToday)button.disabled=false;}}

 function input(label,key,value,{type="number",step="1",min="0",className=""}={}){const wrap=el("label",className,label),field=document.createElement("input");field.dataset.rewardField=key;field.type=type;if(type==="number"){field.min=min;field.step=step;field.inputMode=step==="1"?"numeric":"decimal";}field.value=value??"";wrap.append(field);return wrap;}
 function renderDayEditor(program){const host=byId("rewardsDayEditor");host.replaceChildren();program.checkIn.dailyPoints.forEach((value,index)=>host.append(input(`Day ${index+1}`,`day.${index}`,value)));}
 function renderAdmin(data){hub.adminData=data;const program=data.program;byId("rewardsAdminEnabled").checked=program.enabled;byId("rewardsAdminPointsEnabled").checked=program.pointsEnabled;byId("rewardsAdminCheckinEnabled").checked=program.checkIn.enabled;byId("rewardsAdminName").value=program.name;byId("rewardsAdminPointsName").value=program.pointsName;renderDayEditor(program);const activity=data.activity||{};byId("rewardsAdminActivity").textContent=`${integer(activity.checkIns)} check-ins · ${integer(activity.ledgerEntries)} ledger entries · ${integer(activity.issuedNonCashPoints)} non-cash points`;}
 function programFromForm(){
  const base=hub.adminData?.program;if(!base)throw new Error("Load the saved Rewards settings before saving.");
  const dailyPoints=[...document.querySelectorAll('#rewardsDayEditor [data-reward-field^="day."]')].map(item=>integer(item.value));
  // Hidden mission, milestone and coupon configuration remains exactly as loaded.
  return {...base,name:byId("rewardsAdminName").value.trim(),enabled:byId("rewardsAdminEnabled").checked,pointsName:byId("rewardsAdminPointsName").value.trim(),pointsEnabled:byId("rewardsAdminPointsEnabled").checked,checkIn:{...base.checkIn,enabled:byId("rewardsAdminCheckinEnabled").checked,dailyPoints}};
 }
 function hidePreviewSections(){
  for(const id of ["rewardsMissions","rewardsReferralMilestones","rewardsCoupons"]){const panel=byId(id)?.closest("section");if(panel)panel.hidden=true;}
  for(const id of ["rewardsMissionEditor","rewardsMilestoneEditor","rewardsCouponEditor"]){const panel=byId(id)?.closest("fieldset");if(panel)panel.hidden=true;}
 }
 async function loadAdmin(){const status=byId("rewardsManagerStatus");try{status.textContent="Loading…";renderAdmin(await api("/api/admin/rewards"));status.textContent="Configuration loaded.";}catch(error){status.textContent=error.message;}}
 async function saveAdmin(event){event.preventDefault();const button=byId("saveRewardsManager"),status=byId("rewardsManagerStatus");button.disabled=true;try{const data=await api("/api/admin/rewards","POST",{program:programFromForm()});renderAdmin(data);status.textContent="Rewards Hub configuration saved with audit record.";await loadPublic();}catch(error){status.textContent=error.message;}finally{button.disabled=false;}}
 function languageChanged(){if(hub.publicError)renderPublicError(hub.publicError);else if(hub.publicData)renderPublic(hub.publicData);}
 function sessionChanged(){loadPublic();}
 function bind(){hidePreviewSections();byId("rewardsCheckIn")?.addEventListener("click",checkIn);byId("rewardsManagerForm")?.addEventListener("submit",saveAdmin);byId("reloadRewardsManager")?.addEventListener("click",loadAdmin);document.querySelectorAll('[data-promotion-category]').forEach(button=>button.addEventListener("click",()=>{hub.promotionCategory=button.dataset.promotionCategory||"all";document.querySelectorAll('[data-promotion-category]').forEach(item=>{const active=item===button;item.classList.toggle("active",active);item.setAttribute("aria-pressed",String(active));});renderPromotions({items:hub.promotions});}));document.querySelectorAll('[data-section="rewards"]').forEach(button=>button.addEventListener("click",loadPublic));}
 window.Master7Rewards={loadPublic,loadAdmin,renderPublic,sessionChanged,languageChanged};
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",()=>{bind();loadPublic();});else{bind();loadPublic();}
})();
