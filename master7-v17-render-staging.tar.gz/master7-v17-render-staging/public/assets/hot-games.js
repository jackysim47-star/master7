(function () {
  const byId = id => document.getElementById(id);
  const labels = {
    en: { title: "Hot Games", previous: "Previous games", next: "Next games", loading: "Loading games…", empty: "No catalogue games available yet.", error: "The game catalogue is temporarily unavailable.", rtpHint: "Provider's theoretical long-term return", unknown: "Unavailable", maintenance: "Maintenance" },
    zh: { title: "热门游戏", previous: "上一组游戏", next: "下一组游戏", loading: "正在读取游戏…", empty: "目前还没有可展示的游戏。", error: "暂时无法读取游戏目录。", rtpHint: "厂家公布的长期理论返还率", unknown: "暂无数据", maintenance: "维护中" },
    ms: { title: "Permainan Popular", previous: "Permainan sebelumnya", next: "Permainan seterusnya", loading: "Memuatkan permainan…", empty: "Belum ada permainan dalam katalog.", error: "Katalog permainan tidak tersedia buat sementara.", rtpHint: "Pulangan teori jangka panjang penyedia", unknown: "Tiada data", maintenance: "Penyelenggaraan" }
  };
  const maximumProviders = 3;
  const maximumCards = 12;
  let revision = 0;
  let status = "loading";
  let games = [];
  let megaH5Rates = null;

  function updateControls() {
    const track = byId("hotGamesTrack");
    const controls = byId("hotGamesControls");
    if (!track || !controls) return;
    const remaining = track.scrollWidth - track.clientWidth;
    controls.hidden = track.hidden || remaining <= 1;
    byId("hotGamesPrevious").disabled = track.scrollLeft <= 1;
    byId("hotGamesNext").disabled = track.scrollLeft >= remaining - 1;
  }

  function makeCard(game, copy) {
    const item = document.createElement("li");
    const button = document.createElement("button");
    const image = document.createElement("img");
    const name = document.createElement("strong");
    const rate = document.createElement("small");
    const title = state.lang === "zh" && game.nameZh ? game.nameZh : game.name;

    button.type = "button";
    button.className = "hot-game-card";
    const artwork = [...new Set([game.imageData || game.imageUrl, game.fallback, "/assets/master7-casino-lobby-premium.webp"].filter(Boolean))];
    let artworkIndex = 0;
    image.src = artwork[artworkIndex];
    image.alt = "";
    image.loading = "lazy";
    image.decoding = "async";
    image.onerror = () => {
      artworkIndex += 1;
      if (artworkIndex < artwork.length) image.src = artwork[artworkIndex];
      else image.onerror = null;
    };
    name.className = "hot-game-name";
    name.textContent = title;
    rate.className = "hot-game-rate";
    rate.title = copy.rtpHint;
    rate.textContent = game.rtp === null ? `RTP · ${copy.unknown}` : `RTP ${game.rtp}%`;
    button.append(image, name, rate);

    if (game.status === "suspended" || game.maintenance === true) {
      const maintenance = document.createElement("span");
      maintenance.className = "hot-game-maintenance";
      maintenance.textContent = copy.maintenance;
      button.append(maintenance);
    }

    button.onclick = () => {
      // Use the ordinary catalogue controls before applying a title-specific search.
      document.querySelector('[data-game-category="HOT"]')?.click();
      openCatalogProvider(game.profileId, game.profileName, game.provider, game.gameCode);
    };
    item.append(button);
    return item;
  }

  function render() {
    const track = byId("hotGamesTrack");
    if (!track) return;
    const copy = labels[state.lang] || labels.en;
    const notice = byId("hotGamesNotice");
    byId("hotGamesTitle").textContent = copy.title;
    byId("hotGamesPrevious").setAttribute("aria-label", copy.previous);
    byId("hotGamesNext").setAttribute("aria-label", copy.next);
    notice.hidden = games.length > 0;
    notice.textContent = notice.hidden ? "" : copy[status];
    const scrollPosition = track.scrollLeft;
    track.hidden = games.length === 0;
    track.replaceChildren(...games.map(game => makeCard(game, copy)));
    track.scrollLeft = scrollPosition;
    updateControls();
  }

  async function loadMegaH5Rates() {
    if (megaH5Rates) return megaH5Rates;
    try {
      const data = await api("/assets/megah5-rtp.json?v=1", "GET", undefined, 3500);
      if (data.provider !== "megah5" || data.profileId !== "megah5_myr" ||
          !data.rates || typeof data.rates !== "object" || Array.isArray(data.rates)) return null;
      megaH5Rates = data.rates;
      return megaH5Rates;
    } catch {
      return null;
    }
  }

  async function load(catalogue) {
    if (!byId("hotGamesTrack") || document.body.classList.contains("auth-entry") || state.user?.role !== "member") return;
    const id = ++revision;
    if (!catalogue) {
      games = [];
      status = "error";
      render();
      return;
    }
    const providers = new Map((catalogue.providers || []).map(provider => [provider.id, provider]));
    const profiles = catalogue.profiles || [];
    const order = catalogue.ranking?.categories?.HOT || [...providers.keys()];
    const candidates = [];
    for (const providerId of order) {
      const provider = providers.get(providerId);
      const profile = profiles.find(item => item.providerId === providerId && item.currency === "MYR" && item.qaOnly !== true);
      const cache = profile?.catalogueProfileBound === true ? profile : provider;
      if (provider && profile && Number(cache?.cachedGameCount) > 0) candidates.push(profile);
      if (candidates.length === maximumProviders) break;
    }

    const rates = candidates.some(profile => profile.profileId === "megah5_myr") ? loadMegaH5Rates() : null;
    const results = await Promise.allSettled(candidates.map(async profile => {
      const data = await api(`/api/games?profileId=${encodeURIComponent(profile.profileId)}`);
      if (data.selectedProvider !== profile.providerId || data.selectedProfileId !== profile.profileId || data.qaOnly === true) return [];
      const reported = profile.profileId === "megah5_myr" && profile.providerId === "megah5" ? await rates : null;
      return (data.games || []).filter(game =>
        game.provider === profile.providerId && game.qaOnly !== true &&
        (!game.profileId || game.profileId === profile.profileId) &&
        typeof game.gameCode === "string" && game.gameCode && typeof game.name === "string" && game.name
      ).slice(0, maximumCards).map(game => {
        const rtp = reported?.[game.gameCode];
        return {
          ...game,
          profileId: profile.profileId,
          profileName: profile.displayName || profile.providerId,
          rtp: Number.isFinite(rtp) && rtp >= 0 && rtp <= 100 ? rtp : null,
          fallback: `/assets/providers/${encodeURIComponent(profile.providerId)}.webp`
        };
      });
    }));
    if (id !== revision || state.user?.role !== "member") return;

    const lists = results.filter(result => result.status === "fulfilled" && result.value.length).map(result => result.value);
    games = [];
    // Keep the first row diverse without overriding the backoffice's provider order.
    for (let index = 0; games.length < maximumCards && lists.some(list => index < list.length); index += 1) {
      for (const list of lists) {
        if (list[index]) games.push(list[index]);
        if (games.length === maximumCards) break;
      }
    }
    status = results.some(result => result.status === "rejected") ? "error" : "empty";
    render();
  }

  function bind() {
    const track = byId("hotGamesTrack");
    if (!track) return;
    const move = direction => track.scrollBy({
      left: direction * track.clientWidth * 0.9,
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"
    });
    byId("hotGamesPrevious").onclick = () => move(-1);
    byId("hotGamesNext").onclick = () => move(1);
    track.addEventListener("scroll", updateControls, { passive: true });
    new ResizeObserver(updateControls).observe(track);
  }

  globalThis.Master7HotGames = { load, render };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, { once: true });
  else bind();
})();
