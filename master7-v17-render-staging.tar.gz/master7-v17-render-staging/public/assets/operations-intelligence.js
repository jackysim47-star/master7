(()=>{
 const byId=id=>document.getElementById(id);
 const node=(tag,className='',text='')=>{const item=document.createElement(tag);if(className)item.className=className;if(text!==''&&text!==null)item.textContent=String(text);return item;};
 const money=value=>value===null||value===undefined?'—':new Intl.NumberFormat(undefined,{style:'currency',currency:'MYR'}).format(Number(BigInt(String(value)))/100);
 const severityLabel={get critical(){return (document.documentElement.lang==='en'?"Review now":"立即复核");},get high(){return (document.documentElement.lang==='en'?"High priority":"高优先");},get medium(){return (document.documentElement.lang==='en'?"Attention":"注意");},get low(){return (document.documentElement.lang==='en'?"Awaiting setup":"待配置");}};
 const englishRecommendations={
  "configure_company_bank": [
    "Company receiving bank is not enabled",
    "Manual deposits have no receiving account to show members.",
    "An administrator should enter and verify the company account before making it visible."
  ],
  "review_wallet_reconciliation": [
    "Wallet double-entry ledger needs review",
    "At least one credited deposit differs from its member or provider clearing entry.",
    "Pause the affected manual credits and verify each wallet entry against its evidence."
  ],
  "review_manual_deposits": [
    "Bank receipts are awaiting review",
    "Members have submitted manual bank deposit requests.",
    "Verify the actual company bank credit, amount and receipt before approving or rejecting each request."
  ],
  "review_pending_deposits": [
    "Deposit orders are pending",
    "Some deposit orders are pending, creating, created or under review.",
    "Review provider queries, callbacks and manual receipts before crediting an order."
  ],
  "reconcile_unknown_deposits": [
    "Payment order status unknown",
    "One or more orders lack a reliable final payment result.",
    "Check the provider order and callback records. Credit only against reliable success evidence."
  ],
  "review_payment_recovery_health": [
    "Payment recovery needs manual review",
    "A recovery candidate is overdue or an uncredited order has exceeded the attempt threshold.",
    "Reconcile orders, callbacks, queries and merchant settlements. An attempt count alone never proves payment."
  ],
  "review_accounting_job_health": [
    "Accounting job needs manual review",
    "The latest job failed or has been running for more than fifteen minutes.",
    "Check application logs and database state. Verify that a retry will not duplicate the close."
  ],
  "review_withdrawals": [
    "Withdrawals are awaiting review",
    "Requests are still pending, approved or processing.",
    "Review member funds, bank details and provider status before approving."
  ],
  "complete_production_readiness": [
    "Production requirements are pending",
    "Production readiness checks have not all passed.",
    "Complete payment, payout, settlement, game, encrypted backup and isolated restore acceptance before go-live."
  ],
  "create_current_encrypted_backup": [
    "Current encrypted backup required",
    "There is no encrypted backup from the past seven days matching the release and full table inventory.",
    "Generate and securely retain the current release backup in System Readiness."
  ],
  "complete_isolated_restore_rehearsal": [
    "Isolated restore verification pending",
    "The current backup lacks a matching verified restore receipt for foreign keys, row counts and rollback.",
    "Rehearse restore in isolated PostgreSQL and retain a verification receipt for the same backup."
  ],
  "complete_payment_acceptance": [
    "Production deposit acceptance pending",
    "Real payment channels still need order, callback, query or duplicate-callback evidence.",
    "Complete provider-specific controlled acceptance and retain the evidence."
  ],
  "complete_payout_acceptance": [
    "Production payout acceptance pending",
    "Payout permissions, allowlist, queries and callbacks lack verified evidence.",
    "Keep automated payouts closed while administrators complete provider and bank checks."
  ],
  "verify_settlement": [
    "Settlement verification pending",
    "The portal has no verified provider settlement reconciliation.",
    "Reconcile provider statements against orders, bank records and wallet entries."
  ],
  "complete_game_acceptance": [
    "Game launch and settlement acceptance pending",
    "A required launch, transfer in, return or settlement check has yet to pass.",
    "Verify the full flow with authorized provider test accounts and keep unverified providers closed."
  ],
  "review_game_wallet_sessions": [
    "Game wallet sessions need manual review",
    "Some game wallet sessions are unknown or awaiting manual review.",
    "Query provider balances and transaction references to confirm the location of the funds."
  ],
  "answer_support_tickets": [
    "Support tickets awaiting replies",
    "There are open support tickets.",
    "Review Stephanie's draft and send an approved reply. Escalate finance or complaint cases to staff."
  ],
  "repair_catalogue_connections": [
    "Game catalogue connections need attention",
    "A configured provider catalogue is missing, incomplete, stale or unavailable.",
    "Check the provider API, allowlist and credentials. Sync again once the connection is restored."
  ],
  "inspect_failed_deposits": [
    "Deposit orders failed this period",
    "Failed order creation can affect member deposits.",
    "Group failures by provider error code and investigate their actual status."
  ],
  "complete_whatsapp_setup": [
    "WhatsApp Business setup pending",
    "Templates, phone number, permissions or contact consent still require verification.",
    "Enable sending after Meta setup and send approved templates only to opted-in contacts."
  ]
};
 const englishSummary={critical:'Items require immediate administrator review.',attention:'Launch or operating tasks are awaiting review.',ready:'Production and operating checks passed.',pending:'Some connections or manual reviews are pending.'};
 let period='day',requestId=0;
 function metric(host,label,value,detail=''){const card=node('article','ops-ai-metric');card.append(node('span','',label),node('strong','',value));if(detail)card.append(node('small','',detail));host.append(card);}
 function renderSummary(data){const host=byId('operationsAiSummary');if(!host)return;host.replaceChildren();const external=data.assistant?.externalModelStatus==='available_not_used_for_actions'?(document.documentElement.lang==='en'?"External AI available for read-only assistance":"外部 AI 可用但无执行权"):(document.documentElement.lang==='en'?"External AI disconnected":"外部 AI 未连接");metric(host,(document.documentElement.lang==='en'?"Checks engine":"检查引擎"),data.assistant?.mode==='deterministic_rules'?(document.documentElement.lang==='en'?"Rules engine available":"确定性规则可用"):(document.documentElement.lang==='en'?"Checking":"检查中"),(document.documentElement.lang==='en'?`${external} · Read-only`:`${external} · 只读`));metric(host,(document.documentElement.lang==='en'?"Review now":"立即复核"),data.summary?.critical??0,(document.documentElement.lang==='en'?"Manual administrator review":"管理员人工处理"));metric(host,(document.documentElement.lang==='en'?"High priority":"高优先"),data.summary?.high??0,(document.documentElement.lang==='en'?"Review each item against its evidence":"按证据逐项处理"));metric(host,(document.documentElement.lang==='en'?"All recommendations":"全部建议"),data.summary?.openRecommendations??0,(document.documentElement.lang==='en'?"All actions require approval":"所有动作均需批准"));}
 function renderMetrics(data){const host=byId('operationsAiMetrics');if(!host)return;host.replaceChildren();const metrics=data.metrics||{},reconcile=metrics.reconciliation||{},recovery=metrics.paymentRecovery||{},accounting=metrics.accountingJob||{},reconcileText=reconcile.status==='matched'?(document.documentElement.lang==='en'?"Matched":"一致"):reconcile.status==='no_activity'?(document.documentElement.lang==='en'?"No credited activity this period":"本期无入账活动"):(document.documentElement.lang==='en'?"Order discrepancies found":"有逐单差异");metric(host,(document.documentElement.lang==='en'?"Active CRM members":"会员 CRM 活跃"),metrics.members?.activeInWindow??0,(document.documentElement.lang==='en'?`Members ${metrics.members?.total??0} · New ${metrics.members?.newInWindow??0} · Repeat depositors ${metrics.members?.repeatDepositMembers??0}`:`会员 ${metrics.members?.total??0} · 新增 ${metrics.members?.newInWindow??0} · 复充 ${metrics.members?.repeatDepositMembers??0}`));metric(host,(document.documentElement.lang==='en'?"Credited deposits this period":"本期已入账充值"),money(metrics.deposits?.creditedMinor),(document.documentElement.lang==='en'?`${metrics.deposits?.creditedOrders??0} orders · Unknown ${metrics.deposits?.unknown??0}`:`${metrics.deposits?.creditedOrders??0} 笔 · unknown ${metrics.deposits?.unknown??0}`));metric(host,(document.documentElement.lang==='en'?"Payment recovery requiring review":"支付恢复待人工"),recovery.excessiveAttemptLeases??0,(document.documentElement.lang==='en'?`Uncredited ${recovery.nonCredited??0} · Highest attempt count ${recovery.maxAttempts??0}`:`未入账 ${recovery.nonCredited??0} · 最高尝试 ${recovery.maxAttempts??0}`));metric(host,(document.documentElement.lang==='en'?"Accounting job":"作账任务"),accounting.status==='completed'?(document.documentElement.lang==='en'?"Completed":"正常"):accounting.status==='not_run'?(document.documentElement.lang==='en'?"Not yet run":"尚未执行"):(document.documentElement.lang==='en'?"Needs review":"需检查"),(document.documentElement.lang==='en'?`Status ${accounting.status||'unknown'} · Automatic retries off`:`状态 ${accounting.status||'unknown'} · 自动重跑关闭`));metric(host,(document.documentElement.lang==='en'?"Paid withdrawals this period":"本期已付款提款"),money(metrics.withdrawals?.paidMinor),(document.documentElement.lang==='en'?`${metrics.withdrawals?.paidOrders??0} orders · Pending ${metrics.withdrawals?.pending??0}`:`${metrics.withdrawals?.paidOrders??0} 笔 · 待处理 ${metrics.withdrawals?.pending??0}`));metric(host,(document.documentElement.lang==='en'?"Bank receipts awaiting review":"待核对银行单"),metrics.companyBank?.pendingReceipts??0,metrics.companyBank?.status==='configured'?(document.documentElement.lang==='en'?`${metrics.companyBank?.enabled??0} receiving accounts enabled`:`${metrics.companyBank?.enabled??0} 个收款户口启用`):(document.documentElement.lang==='en'?"Company bank accounts are not configured":"公司银行尚未配置"));metric(host,(document.documentElement.lang==='en'?"Open support tickets":"开放客服工单"),metrics.support?.open??0,(document.documentElement.lang==='en'?`${metrics.support?.newOpenInWindow??0} opened this period`:`本期新增 ${metrics.support?.newOpenInWindow??0}`));metric(host,(document.documentElement.lang==='en'?"Game wallets requiring review":"游戏钱包待复核"),metrics.gameWallet?.reviewRequired??0,metrics.gameWallet?.status==='verified'?(document.documentElement.lang==='en'?"Verified":"已验收"):(document.documentElement.lang==='en'?"Settlement unverified":"结算未验证"));metric(host,(document.documentElement.lang==='en'?"Game provider health":"38 家厂家健康"),`${metrics.catalogue?.freshAvailableCatalogues??0}/${metrics.catalogue?.expectedCatalogues??0}`,(document.documentElement.lang==='en'?`${metrics.catalogue?.missingCatalogues??0} missing · ${metrics.catalogue?.staleOrEmptyCatalogues??0} stale or incomplete`:`${metrics.catalogue?.missingCatalogues??0} 缺少 · ${metrics.catalogue?.staleOrEmptyCatalogues??0} 过期或不完整`));metric(host,(document.documentElement.lang==='en'?"Pending benefits and referrals":"福利／代理待处理"),metrics.rewards?.benefitClaimsAwaitingAcceptance??0,(document.documentElement.lang==='en'?`${metrics.rewards?.commissionPreviewPeriods??0} commission preview periods`:`佣金预览期 ${metrics.rewards?.commissionPreviewPeriods??0}`));metric(host,(document.documentElement.lang==='en'?"Opted-in marketing contacts":"已同意推广联系人"),metrics.marketing?.contacts?.optedIn??0,(document.documentElement.lang==='en'?"Send only to opted-in contacts":"只有已同意名单可发送"));metric(host,(document.documentElement.lang==='en'?"Order-level wallet reconciliation":"钱包逐单对账"),reconcileText,(document.documentElement.lang==='en'?`${reconcile.creditedOrders??0} credited orders · ${reconcile.mismatchOrders??0} discrepancies`:`入账 ${reconcile.creditedOrders??0} 笔 · 差异 ${reconcile.mismatchOrders??0} 笔`));}
 function renderRecommendations(data){const host=byId('operationsAiRecommendations');if(!host)return;host.replaceChildren();const items=data.recommendations||[];if(!items.length){host.append(node('p','ops-ai-empty',(document.documentElement.lang==='en'?"No high-priority recommendations at present. The monitor remains read-only while awaiting manual review.":"目前没有高优先级建议。系统仍会保持只读并等待人工检查。")));return;}for(const item of items){const card=node('article',`ops-ai-recommendation severity-${item.severity}`),head=node('div','ops-ai-recommendation-head'),copy=node('div');const labels=document.documentElement.lang==='en'?englishRecommendations[item.id]:null;const englishReason=labels&&item.id==='review_accounting_job_health'?(item.evidence?.status==='failed'?'The latest accounting job failed.':'The latest job has been running for more than fifteen minutes.'):labels?.[1];copy.append(node('h3','',labels?.[0]||item.title),node('p','',englishReason||item.reason));head.append(copy,node('span',`ops-ai-severity ${item.severity}`,severityLabel[item.severity]||item.severity));const evidence=node('dl','ops-ai-evidence');for(const [key,value] of Object.entries(item.evidence||{})){evidence.append(node('dt','',key),node('dd','',value));}card.append(head,evidence,node('p','ops-ai-action',labels?.[2]||item.recommendedAction),node('small','ops-ai-boundary',(document.documentElement.lang==='en'?"Manual approval required · No action has been taken":"需人工批准 · 系统没有执行动作")));host.append(card);}}
 function render(data){renderSummary(data);renderMetrics(data);renderRecommendations(data);const status=byId('operationsAiStatus');if(status){status.className=`verification-note ${data.summary?.status==='ready'?'ready':'pending'}`;status.textContent=(document.documentElement.lang==='en'?`${(document.documentElement.lang==='en'?englishSummary[data.summary?.status]:data.summary?.statement)||''} · ${new Date((data.generatedAt||0)*1000).toLocaleString()} · All actions require manual approval`:`${(document.documentElement.lang==='en'?englishSummary[data.summary?.status]:data.summary?.statement)||''} · ${new Date((data.generatedAt||0)*1000).toLocaleString()} · 所有动作保持人工批准`);};const policy=byId('operationsAiSourcePolicy');if(policy)policy.textContent=data.sourcePolicy||'';document.querySelectorAll('[data-ops-period]').forEach(button=>{const selected=button.dataset.opsPeriod===period;button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected));});}
 async function load(nextPeriod=period){
  if(typeof state!=='undefined'&&state.user?.role!=='owner')return;
  const currentRequest=++requestId;period=['day','week','month'].includes(nextPeriod)?nextPeriod:'day';
  for(const id of ['operationsAiSummary','operationsAiMetrics','operationsAiRecommendations'])byId(id)?.replaceChildren();const policy=byId('operationsAiSourcePolicy');if(policy)policy.textContent='';
  document.querySelectorAll('[data-ops-period]').forEach(button=>{const selected=button.dataset.opsPeriod===period;button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected));});
  const status=byId('operationsAiStatus');if(status){status.className='verification-note pending';status.textContent=(document.documentElement.lang==='en'?"Loading operating records…":"正在读取真实运营记录…");}
  try{const data=await api('/api/admin/operations-intelligence?period='+encodeURIComponent(period));if(currentRequest!==requestId)return;render(data);}catch(error){if(currentRequest===requestId&&status)status.textContent=error.message;}
 }
 function bind(){byId('refreshOperationsAi')?.addEventListener('click',()=>load());document.querySelectorAll('[data-ops-period]').forEach(button=>button.addEventListener('click',()=>load(button.dataset.opsPeriod)));}
 window.Master7OperationsIntelligence={load,render};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();
})();
