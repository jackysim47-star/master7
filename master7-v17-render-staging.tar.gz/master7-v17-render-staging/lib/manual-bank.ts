type User={id:string;username:string;role:string;approved:number};
type Ctx={db:D1Database;user:User|null};
const json=(v:unknown,s=200)=>Response.json(v,{status:s,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const stamp=()=>Math.floor(Date.now()/1000);
const ident=(v:unknown,max=100)=>typeof v==='string'&&v.length>0&&v.length<=max&&/^[A-Za-z0-9_-]+$/.test(v)?v:null;
function amount(v:unknown){if(typeof v!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(v))return null;const[a,b='']=v.split('.'),n=BigInt(a)*100n+BigInt(b.padEnd(2,'0'));return n>0n&&n<=10000000n?n.toString():null;}
function image(v:unknown){if(typeof v!=='string'||v.length>500000||!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(v))return null;try{const raw=atob(v.slice(v.indexOf(',')+1)),b=[...raw.slice(0,12)].map(x=>x.charCodeAt(0)),magic=v.startsWith('data:image/jpeg;')&&b[0]===255&&b[1]===216&&b[2]===255||v.startsWith('data:image/png;')&&b.slice(0,8).join(',')==='137,80,78,71,13,10,26,10'||v.startsWith('data:image/webp;')&&raw.slice(0,4)==='RIFF'&&raw.slice(8,12)==='WEBP';return raw.length>=16&&raw.length<=350000&&magic?v:null;}catch{return null;}}
const text=(v:unknown,min:number,max:number)=>typeof v==='string'&&v.trim().length>=min&&v.trim().length<=max?v.trim():null;
function must(c:Ctx,roles:string[]){if(!c.user)return json({error:'Sign in required'},401);if(!roles.includes(c.user.role))return json({error:'Access denied'},403);return null;}
export async function manualBankGet(req:Request,c:Ctx):Promise<Response|null>{
 const p=new URL(req.url).pathname;
 if(p==='/api/manual-bank/accounts'){
  const r=await c.db.prepare("SELECT id,bank_name,account_name,account_number FROM company_bank_accounts WHERE enabled=1 ORDER BY position,id").all();return json({items:r.results??[]});
 }
 if(p==='/api/manual-bank/deposits'){
  const denied=must(c,['member']);if(denied)return denied;const r=await c.db.prepare("SELECT d.id,d.amount_minor,d.status,d.created_at,d.updated_at,b.bank_name,b.account_name,b.account_number FROM manual_deposit_requests m JOIN deposit_orders d ON d.id=m.deposit_order_id JOIN company_bank_accounts b ON b.id=m.bank_account_id WHERE d.user_id=? ORDER BY d.created_at DESC LIMIT 100").bind(c.user!.id).all();return json({items:r.results??[]});
 }
 if(p==='/api/admin/manual-bank'){
  const denied=must(c,['owner','staff']);if(denied)return denied;
  const [banks,requests]=await Promise.all([c.db.prepare("SELECT id,bank_name,account_name,account_number,enabled,position,updated_at FROM company_bank_accounts ORDER BY position,id").all(),c.db.prepare("SELECT d.id,d.amount_minor,d.status,d.created_at,d.updated_at,u.username,b.bank_name,b.account_name,b.account_number,m.receipt_data!='' receipt_available,m.reviewed_by FROM manual_deposit_requests m JOIN deposit_orders d ON d.id=m.deposit_order_id JOIN users u ON u.id=d.user_id JOIN company_bank_accounts b ON b.id=m.bank_account_id ORDER BY CASE d.status WHEN 'pending' THEN 0 ELSE 1 END,d.created_at DESC LIMIT 500").all()]);
  return json({banks:banks.results??[],requests:requests.results??[],pending:(requests.results??[]).filter((x:any)=>x.status==='pending').length});
 }
 if(p==='/api/admin/manual-bank/receipt'){
  const denied=must(c,['owner','staff']);if(denied)return denied;const id=ident(new URL(req.url).searchParams.get('id'));if(!id)return json({error:'Invalid receipt'},400);
  const row=await c.db.prepare("SELECT m.receipt_data FROM manual_deposit_requests m JOIN deposit_orders d ON d.id=m.deposit_order_id WHERE d.id=?").bind(id).first<{receipt_data:string}>(),match=row?.receipt_data.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);if(!match)return json({error:'Receipt not found'},404);const bytes=Uint8Array.from(atob(match[2]),x=>x.charCodeAt(0));return new Response(bytes,{headers:{'Content-Type':match[1],'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
 }
 return null;
}
export async function manualBankPost(path:string,d:Record<string,unknown>,c:Ctx):Promise<Response|null>{
 if(path==='/api/manual-bank/deposits'){
  const denied=must(c,['member']);if(denied)return denied;if(!c.user!.approved)return json({error:'Account awaiting approval'},403);
  const bankId=ident(d.bankId),requestKey=ident(d.requestKey,80),minor=amount(d.amount),receipt=image(d.receiptData);if(!bankId||!requestKey||!minor||!receipt)return json({error:'Bank, amount and receipt are required'},400);
  if(!await c.db.prepare('SELECT id FROM company_bank_accounts WHERE id=? AND enabled=1').bind(bankId).first())return json({error:'Bank account is unavailable'},409);
  const id=crypto.randomUUID(),t=stamp(),fingerprint=`${bankId}:${minor}`;
  await c.db.batch([c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?, 'manual_bank',?,'MYR',?,'pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(id,c.user!.id,requestKey,fingerprint,minor,bankId,t,t),c.db.prepare("INSERT INTO manual_deposit_requests(deposit_order_id,bank_account_id,receipt_data,created_at,updated_at) SELECT id,? ,?,?,? FROM deposit_orders WHERE user_id=? AND request_key=? AND provider='manual_bank' ON CONFLICT(deposit_order_id) DO NOTHING").bind(bankId,receipt,t,t,c.user!.id,requestKey)]);
  const order=await c.db.prepare("SELECT id,fingerprint,status FROM deposit_orders WHERE user_id=? AND request_key=? AND provider='manual_bank'").bind(c.user!.id,requestKey).first<any>();if(!order||order.fingerprint!==fingerprint)return json({error:'Request conflict'},409);return json({id:order.id,status:order.status},201);
 }
 if(path==='/api/admin/manual-bank/account'){
  const denied=must(c,['owner']);if(denied)return denied;const id=ident(d.id)||crypto.randomUUID(),bank=text(d.bankName,2,80),name=text(d.accountName,2,100),number=text(d.accountNumber,6,32),enabled=d.enabled===true?1:0,position=Number.isInteger(d.position)&&Number(d.position)>=0&&Number(d.position)<=1000?Number(d.position):0;if(!bank||!name||!number||!/^[0-9 -]+$/.test(number))return json({error:'Invalid bank account'},400);const t=stamp();await c.db.prepare('INSERT INTO company_bank_accounts(id,bank_name,account_name,account_number,enabled,position,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET bank_name=excluded.bank_name,account_name=excluded.account_name,account_number=excluded.account_number,enabled=excluded.enabled,position=excluded.position,updated_by=excluded.updated_by,updated_at=excluded.updated_at').bind(id,bank,name,number,enabled,position,c.user!.id,t).run();return json({status:'ok',id});
 }
 if(path==='/api/admin/manual-bank/review'){
  const denied=must(c,['owner','staff']);if(denied)return denied;const id=ident(d.id),action=d.action;if(!id||!['approve','reject'].includes(String(action)))return json({error:'Invalid review'},400);const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='manual_bank'").bind(id).first<any>();if(!order)return json({error:'Deposit not found'},404);if(order.status!=='pending')return json({error:'Deposit already reviewed'},409);const t=stamp();
  if(action==='reject'){await c.db.batch([c.db.prepare("UPDATE deposit_orders SET status='failed',updated_at=? WHERE id=? AND status='pending'").bind(t,id),c.db.prepare('UPDATE manual_deposit_requests SET reviewed_by=?,updated_at=? WHERE deposit_order_id=?').bind(c.user!.id,t,id)]);return json({status:'rejected'});}
  await c.db.batch([c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'member',amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='manual_bank' AND status='pending' ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),t,id),c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'provider_clearing',-amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='manual_bank' AND status='pending' ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),t,id),c.db.prepare("UPDATE deposit_orders SET status='credited',updated_at=? WHERE id=? AND status='pending'").bind(t,id),c.db.prepare("UPDATE manual_deposit_requests SET reviewed_by=?,updated_at=? WHERE deposit_order_id=? AND EXISTS(SELECT 1 FROM deposit_orders WHERE id=? AND status='credited')").bind(c.user!.id,t,id,id)]);return json({status:'approved'});
 }
 return null;
}
