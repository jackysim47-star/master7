import {withdrawalWalletState} from './withdrawals.ts';
import {walletGuardStatements} from './wallet-guard.ts';
import {bankAccountKey,bankAmount,bankEvidence,bankHash,bankImage} from './manual-bank-evidence.ts';
type User={id:string;username:string;role:string;approved:number};
type Ctx={db:D1Database;user:User|null;newDepositsEnabled?:string;newPayoutsEnabled?:string};
const json=(v:unknown,s=200)=>Response.json(v,{status:s,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const stamp=()=>Math.floor(Date.now()/1000);
const audit=(c:Ctx,event:string,target:string,timestamp:number)=>c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),c.user!.id,event,target,timestamp);
const changed=(r:any)=>Number(r?.meta?.changes??r?.changes??0);
const ident=(v:unknown,max=100)=>typeof v==='string'&&v.length>0&&v.length<=max&&/^[A-Za-z0-9_-]+$/.test(v)?v:null;
const text=(v:unknown,min:number,max:number)=>typeof v==='string'&&v.trim().length>=min&&v.trim().length<=max&&!/[\u0000-\u001f\u007f]/.test(v)?v.trim():null;
function must(c:Ctx,roles:string[]){if(!c.user)return json({error:'Sign in required'},401);if(!roles.includes(c.user.role)||c.user.approved!==1)return json({error:'Access denied'},403);return null;}
const parse=(v:unknown)=>{try{return typeof v==='string'?JSON.parse(v):null;}catch{return null;}};
export async function manualBankConfiguration(db:D1Database){
 const value=parse((await db.prepare("SELECT value FROM settings WHERE id='manual_bank:configuration'").first<{value:string}>())?.value);
 return {mode:['closed','qa','live'].includes(value?.mode)?value.mode:'closed',qaMemberIds:Array.isArray(value?.qaMemberIds)?value.qaMemberIds.filter((x:unknown)=>ident(x)).slice(0,20) as string[]:[]};
}
export async function manualBankReadiness(db:D1Database){
 const accepted=parse((await db.prepare("SELECT value FROM settings WHERE id='manual_bank:acceptance'").first<{value:string}>())?.value);
 if(!ident(accepted?.depositId)||!ident(accepted?.withdrawalId))return false;
 const proof=await db.prepare(`SELECT d.id,d.user_id,dp.id deposit_proof,dp.proof_data deposit_data,dp.proof_sha256 deposit_sha,wp.id payout_proof,wp.proof_data payout_data,wp.proof_sha256 payout_sha FROM deposit_orders d
 JOIN manual_deposit_requests m ON m.deposit_order_id=d.id AND m.bank_account_id=d.trade_code
 JOIN manual_bank_transactions dp ON dp.deposit_order_id=d.id AND dp.bank_account_id=m.bank_account_id AND dp.direction='deposit' AND dp.amount_minor=d.amount_minor AND dp.currency=d.currency
 JOIN company_bank_accounts b ON b.id=m.bank_account_id AND b.enabled=1
 JOIN withdrawal_requests w ON w.id=? AND w.user_id=d.user_id AND w.status='paid' AND w.provider_id='manual_bank'
 JOIN provider_payouts p ON p.withdrawal_id=w.id AND p.provider_id=w.provider_id AND p.amount_minor=w.amount_minor AND p.currency=w.currency AND p.status='succeeded' AND p.create_outcome='accepted' AND COALESCE(p.last_error_code,'')=''
 JOIN manual_bank_transactions wp ON wp.id=p.provider_reference AND wp.payout_id=p.id AND wp.bank_account_id=p.manual_bank_account_id AND wp.direction='withdrawal' AND wp.amount_minor=p.amount_minor AND wp.currency=p.currency AND wp.proof_sha256=p.last_event_hash
 WHERE d.id=? AND d.provider='manual_bank' AND d.status='credited' AND d.currency='MYR'
 AND NOT EXISTS(SELECT 1 FROM wallet_reservations r WHERE r.reference_id=w.id)
 AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=d.id)=2
 AND EXISTS(SELECT 1 FROM wallet_ledger l JOIN wallet_ledger c ON c.order_id=l.order_id WHERE l.order_id=d.id AND l.user_id=d.user_id AND l.account_code='member' AND l.amount_minor=d.amount_minor AND l.currency='MYR' AND c.user_id=d.user_id AND c.account_code='provider_clearing' AND c.amount_minor=-d.amount_minor AND c.currency='MYR')
 AND EXISTS(SELECT 1 FROM audit a WHERE a.id='manual_bank_payout_paid_'||p.id AND a.event='manual_bank_payout_paid' AND a.target=wp.id AND a.user_id=wp.recorded_by)
 AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.event='manual_bank_acceptance' AND a.target=?)`).bind(accepted.withdrawalId,accepted.depositId,accepted.auditId,accepted.evidenceSha256).first<any>();
 return !!proof&&bankHash(proof.deposit_data)===proof.deposit_sha&&bankHash(proof.payout_data)===proof.payout_sha&&accepted.evidenceSha256===bankHash(JSON.stringify([proof.id,accepted.withdrawalId,proof.deposit_proof,proof.payout_proof]))&&!(await withdrawalWalletState(db,proof.user_id)).reconciliationRequired;
}
export async function manualBankAvailability(c:Ctx){
 const [configuration,banks,control,ready,paused]=await Promise.all([manualBankConfiguration(c.db),c.db.prepare('SELECT COUNT(*) count FROM company_bank_accounts b WHERE enabled=1 AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=b.id)').first<{count:number}>(),c.db.prepare("SELECT submission_enabled FROM provider_payout_controls WHERE provider_id='manual_bank'").first<{submission_enabled:number}>(),manualBankReadiness(c.db),c.db.prepare("SELECT value FROM settings WHERE id='deposit_control:manual_bank'").first<{value:string}>()]);
 const memberAllowed=configuration.mode==='qa'?!!c.user&&configuration.qaMemberIds.includes(c.user.id):configuration.mode==='live'&&ready;
 return {...configuration,bankCount:Number(banks?.count??0),ready,memberAllowed,depositEnabled:c.newDepositsEnabled==='true'&&memberAllowed&&Number(banks?.count??0)>0&&paused?.value!=='paused',payoutGateOpen:c.newPayoutsEnabled==='true'&&(configuration.mode==='qa'&&configuration.qaMemberIds.length>0||configuration.mode==='live'&&ready)&&Number(banks?.count??0)>0&&control?.submission_enabled===1,payoutEnabled:c.newPayoutsEnabled==='true'&&memberAllowed&&Number(banks?.count??0)>0&&control?.submission_enabled===1};
}
export async function manualBankGet(req:Request,c:Ctx):Promise<Response|null>{
 const p=new URL(req.url).pathname;
 if(p==='/api/manual-bank/accounts'){
  const denied=must(c,['member']);if(denied)return denied;const availability=await manualBankAvailability(c);
  if(!availability.depositEnabled)return json({items:[],maintenance:true,mode:availability.mode});
  const r=await c.db.prepare('SELECT id,bank_name,account_name,account_number,image_data FROM company_bank_accounts b WHERE enabled=1 AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=b.id) ORDER BY position,id').all();return json({items:r.results??[],mode:availability.mode});
 }
 if(p==='/api/manual-bank/deposits'){
  const denied=must(c,['member']);if(denied)return denied;const r=await c.db.prepare("SELECT d.id,d.amount_minor,d.status,d.created_at,d.updated_at,b.bank_name,b.account_name,b.account_number FROM manual_deposit_requests m JOIN deposit_orders d ON d.id=m.deposit_order_id JOIN company_bank_accounts b ON b.id=m.bank_account_id WHERE d.user_id=? ORDER BY d.created_at DESC LIMIT 100").bind(c.user!.id).all();return json({items:r.results??[]});
 }
 if(p==='/api/admin/manual-bank'){
  const denied=must(c,['owner','staff']);if(denied)return denied;
  const [banks,requests,availability,transactions]=await Promise.all([
   c.db.prepare('SELECT id,bank_name,account_name,account_number,image_data,enabled,position,updated_at,supersedes_id FROM company_bank_accounts ORDER BY position,id').all(),
   c.db.prepare("SELECT d.id,d.amount_minor,d.status,d.created_at,d.updated_at,u.username,b.id bank_account_id,b.bank_name,b.account_name,b.account_number,m.receipt_data!='' receipt_available,m.reviewed_by,t.bank_reference,t.id bank_transaction_id,t.bank_occurred_at FROM manual_deposit_requests m JOIN deposit_orders d ON d.id=m.deposit_order_id JOIN users u ON u.id=d.user_id JOIN company_bank_accounts b ON b.id=m.bank_account_id LEFT JOIN manual_bank_transactions t ON t.deposit_order_id=d.id ORDER BY CASE d.status WHEN 'pending' THEN 0 ELSE 1 END,d.created_at DESC LIMIT 500").all(),manualBankAvailability(c),
   c.db.prepare('SELECT t.id,t.bank_account_id,t.bank_reference,t.direction,t.amount_minor,t.currency,t.deposit_order_id,t.payout_id,t.proof_sha256,t.bank_occurred_at,t.recorded_by,t.recorded_at FROM manual_bank_transactions t ORDER BY recorded_at DESC,id LIMIT 500').all()]);
  return json({banks:banks.results??[],requests:requests.results??[],transactions:transactions.results??[],configuration:c.user!.role==='owner'?availability:{mode:availability.mode,ready:availability.ready},pending:(requests.results??[]).filter((x:any)=>x.status==='pending').length});
 }
 if(p==='/api/admin/manual-bank/receipt'||p==='/api/admin/manual-bank/proof'){
  const denied=must(c,['owner','staff']);if(denied)return denied;const id=ident(new URL(req.url).searchParams.get('id'));if(!id)return json({error:'Invalid receipt'},400);
  const row=p.endsWith('/proof')?await c.db.prepare('SELECT proof_data receipt_data FROM manual_bank_transactions WHERE id=?').bind(id).first<{receipt_data:string}>():await c.db.prepare('SELECT receipt_data FROM manual_deposit_requests WHERE deposit_order_id=?').bind(id).first<{receipt_data:string}>();
  const match=row?.receipt_data.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);if(!match)return json({error:'Receipt not found'},404);
  return new Response(Uint8Array.from(atob(match[2]),x=>x.charCodeAt(0)),{headers:{'Content-Type':match[1],'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
 }
 return null;
}
export async function manualBankPost(path:string,d:Record<string,unknown>,c:Ctx):Promise<Response|null>{
 if(path==='/api/admin/manual-bank/settings'){
  const denied=must(c,['owner']);if(denied)return denied;
  if(!['closed','qa','live'].includes(String(d.mode))||!Array.isArray(d.qaMemberIds)||d.qaMemberIds.length>20||d.qaMemberIds.some(x=>!ident(x)))return json({error:'Invalid banking mode or QA members'},400);
  if(d.mode==='qa'&&!d.qaMemberIds.length)return json({error:'Choose dedicated QA members'},400);
  for(const id of d.qaMemberIds)if(!await c.db.prepare("SELECT id FROM users WHERE id=? AND role='member' AND approved=1").bind(id).first())return json({error:'QA member is not approved'},400);
  if(d.mode==='live'&&!await manualBankReadiness(c.db))return json({error:'Real deposit and manual payout acceptance is required'},409);
  const t=stamp(),value=JSON.stringify({mode:d.mode,qaMemberIds:[...new Set(d.qaMemberIds)]});
  await c.db.batch([c.db.prepare("INSERT INTO settings(id,value) VALUES('manual_bank:configuration',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(value),c.db.prepare("UPDATE provider_payout_controls SET submission_enabled=?,updated_at=? WHERE provider_id='manual_bank'").bind(d.mode==='closed'?0:1,t),audit(c,'manual_bank_mode_changed',value,t)]);return json({status:'ok',mode:d.mode});
 }
 if(path==='/api/admin/manual-bank/acceptance'){
  const denied=must(c,['owner']);if(denied)return denied;const config=await manualBankConfiguration(c.db),depositId=ident(d.depositId),withdrawalId=ident(d.withdrawalId);
  if(config.mode!=='qa'||!depositId||!withdrawalId||d.bankConfirmed!==true)return json({error:'Complete restricted real-bank QA first'},400);
  const row=await c.db.prepare('SELECT d.user_id,dp.id deposit_proof,wp.id payout_proof FROM deposit_orders d JOIN manual_bank_transactions dp ON dp.deposit_order_id=d.id JOIN withdrawal_requests w ON w.id=? AND w.user_id=d.user_id JOIN provider_payouts p ON p.withdrawal_id=w.id JOIN manual_bank_transactions wp ON wp.payout_id=p.id WHERE d.id=?').bind(withdrawalId,depositId).first<any>();
  if(!row||!config.qaMemberIds.includes(row.user_id))return json({error:'Linked QA deposit and withdrawal proofs are required'},409);
  const evidenceSha256=bankHash(JSON.stringify([depositId,withdrawalId,row.deposit_proof,row.payout_proof])),auditId=crypto.randomUUID(),t=stamp(),value=JSON.stringify({depositId,withdrawalId,evidenceSha256,auditId});
  // The single write transaction stores the audit pointer. Readiness always
  // revalidates the underlying posting records, including after a rollback.
  await c.db.batch([audit(c,'manual_bank_acceptance_attempt',evidenceSha256,t),c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,'manual_bank_acceptance',?,?)").bind(auditId,c.user!.id,evidenceSha256,t),c.db.prepare("INSERT INTO settings(id,value) VALUES('manual_bank:acceptance',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(value)]);
  if(!await manualBankReadiness(c.db))return json({error:'Linked wallet or bank evidence is incomplete',manualBankReady:false},409);
  return json({status:'accepted',manualBankReady:true,evidenceSha256});
 }
 if(path==='/api/manual-bank/deposits'){
  const denied=must(c,['member']);if(denied)return denied;
  const bankId=ident(d.bankId),requestKey=ident(d.requestKey,80),minor=bankAmount(d.amount),receipt=bankImage(d.receiptData);if(!bankId||!requestKey||!minor||!receipt)return json({error:'Bank, amount and receipt are required'},400);
  const fingerprint=`${bankId}:${minor}`,replay=await c.db.prepare("SELECT id,fingerprint,status FROM deposit_orders WHERE user_id=? AND request_key=?").bind(c.user!.id,requestKey).first<any>();
  if(replay)return replay.fingerprint===fingerprint?json({id:replay.id,status:replay.status},201):json({error:'Request conflict'},409);
  if(!(await manualBankAvailability(c)).depositEnabled)return json({error:'Company-bank deposits are temporarily unavailable',code:'DEPOSITS_MAINTENANCE'},503);
  const id=crypto.randomUUID(),t=stamp();
  const results=await c.db.batch([
   c.db.prepare("UPDATE company_bank_accounts SET updated_at=updated_at WHERE id=? AND enabled=1 AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=company_bank_accounts.id)").bind(bankId),
   c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) SELECT ?,?,?,?,'manual_bank',?,'MYR',?,'pending',?,? FROM company_bank_accounts b WHERE b.id=? AND b.enabled=1 AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=b.id) ON CONFLICT(user_id,request_key) DO NOTHING").bind(id,c.user!.id,requestKey,fingerprint,minor,bankId,t,t,bankId),
   c.db.prepare("INSERT INTO manual_deposit_requests(deposit_order_id,bank_account_id,receipt_data,created_at,updated_at) SELECT id,?,?,?,? FROM deposit_orders WHERE user_id=? AND request_key=? AND provider='manual_bank' AND fingerprint=? ON CONFLICT(deposit_order_id) DO NOTHING").bind(bankId,receipt,t,t,c.user!.id,requestKey,fingerprint),
   c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'manual_bank_deposit_submitted',o.id,? FROM deposit_orders o WHERE o.id=?").bind(crypto.randomUUID(),c.user!.id,t,id)
  ]);
  if(changed(results[0])!==1)return json({error:'Bank account is unavailable'},409);
  const order=await c.db.prepare("SELECT id,fingerprint,status FROM deposit_orders WHERE user_id=? AND request_key=? AND provider='manual_bank'").bind(c.user!.id,requestKey).first<any>();if(!order||order.fingerprint!==fingerprint)return json({error:'Request conflict'},409);return json({id:order.id,status:order.status},201);
 }
 if(path==='/api/admin/manual-bank/account'){
  const denied=must(c,['owner']);if(denied)return denied;
  const requested=ident(d.id),bank=text(d.bankName,2,80),name=text(d.accountName,2,100),number=text(d.accountNumber,6,32),enabled=d.enabled===true?1:0,position=Number.isInteger(d.position)&&Number(d.position)>=0&&Number(d.position)<=1000?Number(d.position):0;
  if(!bank||!name||!number||!/^[0-9 -]+$/.test(number)||number.replace(/[ -]/g,'').length<6)return json({error:'Invalid bank account'},400);
  const exists=requested?await c.db.prepare('SELECT * FROM company_bank_accounts WHERE id=?').bind(requested).first<any>():null;
  if(requested&&!exists)return json({error:'Bank account not found'},404);
  if(exists&&await c.db.prepare('SELECT id FROM company_bank_accounts WHERE supersedes_id=?').bind(requested).first())return json({error:'This historical account has been replaced; refresh'},409);
  let imageData=exists?.image_data??'';if(d.imageData!==undefined){const checked=bankImage(d.imageData);if(!checked)return json({error:'Upload a valid JPG, PNG or WebP bank image under 350 KB'},400);imageData=checked;}
  const versioned=!!exists&&(exists.bank_name!==bank||exists.account_name!==name||exists.account_number!==number),id=exists&&!versioned?exists.id:crypto.randomUUID(),t=stamp();
  const statements=exists&&!versioned?[c.db.prepare('UPDATE company_bank_accounts SET image_data=?,enabled=?,position=?,updated_by=?,updated_at=? WHERE id=? AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=company_bank_accounts.id)').bind(imageData,enabled,position,c.user!.id,t,id)]:[
   c.db.prepare('INSERT INTO company_bank_accounts(id,bank_name,account_name,account_number,image_data,enabled,position,updated_by,updated_at,supersedes_id) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT DO NOTHING').bind(id,bank,name,number,imageData,enabled,position,c.user!.id,t,versioned?exists.id:null),
   ...(versioned?[c.db.prepare('UPDATE company_bank_accounts SET enabled=0,updated_by=?,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.id=? AND n.supersedes_id=company_bank_accounts.id)').bind(c.user!.id,t,exists.id,id)]:[])
  ];
  const result=await c.db.batch([...statements,c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,?,?,? FROM company_bank_accounts b WHERE b.id=? AND b.updated_by=? AND b.updated_at=? AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=b.id)').bind(crypto.randomUUID(),c.user!.id,versioned?'manual_bank_account_replaced':exists?'manual_bank_account_updated':'manual_bank_account_created',JSON.stringify({id,previousId:versioned?exists.id:null}),t,id,c.user!.id,t)]);
  if(changed(result[0])!==1)return json({error:'Bank account changed; refresh'},409);
  return json({status:'ok',id,previousId:versioned?exists.id:null,imageSaved:!!imageData});
 }
 if(path==='/api/admin/manual-bank/review'){
  const denied=must(c,['owner','staff']);if(denied)return denied;
  const id=ident(d.id),action=d.action;if(!id||!['approve','reject'].includes(String(action)))return json({error:'Invalid review'},400);
  const order=await c.db.prepare("SELECT d.*,m.bank_account_id,b.account_number FROM deposit_orders d JOIN manual_deposit_requests m ON m.deposit_order_id=d.id JOIN company_bank_accounts b ON b.id=m.bank_account_id WHERE d.id=? AND d.provider='manual_bank'").bind(id).first<any>();
  if(!order)return json({error:'Deposit not found'},404);if(order.status!=='pending')return json({error:'Deposit already reviewed'},409);
  const minor=String(order.amount_minor??''),t=stamp(),proof=action==='approve'?bankEvidence(d,t):null;
  if(action==='approve'&&!proof)return json({error:'Confirm bank receipt, MYR amount, account, reference, time and bank proof image'},400);
  if(proof&&(proof.amount!==minor||d.bankAccountId!==order.bank_account_id))return json({error:'Bank amount or company account does not match this order'},409);
  if(typeof order.user_id!=='string'||order.currency!=='MYR'||!/^[1-9]\d{0,7}$/.test(minor))return json({error:'Deposit requires manual reconciliation'},409);
  const actor=c.user!.id,decisionId=crypto.randomUUID(),proofId=crypto.randomUUID(),memberId=crypto.randomUUID(),event=action==='approve'?'manual_bank_deposit_approved':'manual_bank_deposit_rejected';
  const statements=[...walletGuardStatements(c.db,order.user_id),
   c.db.prepare("UPDATE deposit_orders SET updated_at=updated_at WHERE id=? AND provider='manual_bank' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='pending'").bind(id,order.user_id,minor),
   c.db.prepare("UPDATE manual_deposit_requests SET updated_at=updated_at WHERE deposit_order_id=? AND reviewed_by IS NULL").bind(id),
   c.db.prepare(`INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,CASE WHEN EXISTS(SELECT 1 FROM wallet_ledger l WHERE l.order_id=o.id) OR m.bank_account_id<>o.trade_code OR m.receipt_data='' THEN 'manual_bank_deposit_review' ELSE ? END,o.id,? FROM deposit_orders o JOIN manual_deposit_requests m ON m.deposit_order_id=o.id WHERE o.id=? AND o.provider='manual_bank' AND o.user_id=? AND o.amount_minor=CAST(? AS BIGINT) AND o.currency='MYR' AND o.status='pending' AND m.reviewed_by IS NULL`).bind(decisionId,actor,event,t,id,order.user_id,minor),
   c.db.prepare('UPDATE manual_deposit_requests SET reviewed_by=?,updated_at=? WHERE deposit_order_id=? AND reviewed_by IS NULL AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.target=manual_deposit_requests.deposit_order_id)').bind(actor,t,id,decisionId),
  ];
  if(proof)statements.push(c.db.prepare(`INSERT INTO manual_bank_transactions(id,bank_account_id,bank_account_key,bank_reference,normalized_reference,direction,amount_minor,currency,deposit_order_id,proof_data,proof_sha256,bank_occurred_at,recorded_by,recorded_at)
   SELECT ?,m.bank_account_id,?,?,?,'deposit',o.amount_minor,'MYR',o.id,?,?,?,?,? FROM deposit_orders o JOIN manual_deposit_requests m ON m.deposit_order_id=o.id JOIN audit a ON a.target=o.id WHERE o.id=? AND o.status='pending' AND o.amount_minor=CAST(? AS BIGINT) AND o.currency='MYR' AND m.reviewed_by=? AND m.bank_account_id=o.trade_code AND a.id=? AND a.event='manual_bank_deposit_approved' ON CONFLICT DO NOTHING`).bind(proofId,bankAccountKey(order.account_number),proof.reference.original,proof.reference.normalized,proof.proof,proof.hash,proof.occurred,actor,t,id,minor,actor,decisionId));
  statements.push(
   c.db.prepare("UPDATE audit SET event='manual_bank_deposit_review' WHERE id=? AND event='manual_bank_deposit_approved' AND NOT EXISTS(SELECT 1 FROM manual_bank_transactions b WHERE b.id=? AND b.deposit_order_id=audit.target)").bind(decisionId,proofId),
   c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND status='pending' AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.target=deposit_orders.id AND a.event='manual_bank_deposit_review')").bind(t,id,decisionId),
   c.db.prepare("UPDATE deposit_orders SET status='failed',updated_at=? WHERE id=? AND status='pending' AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.target=deposit_orders.id AND a.event='manual_bank_deposit_rejected') AND NOT EXISTS(SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)").bind(t,id,decisionId),
   c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,o.id,o.user_id,'member',o.amount_minor,'MYR',? FROM deposit_orders o JOIN manual_bank_transactions b ON b.deposit_order_id=o.id AND b.id=? WHERE o.id=? AND o.status='pending' AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.event='manual_bank_deposit_approved' AND a.target=o.id) AND NOT EXISTS(SELECT 1 FROM wallet_ledger l WHERE l.order_id=o.id) ON CONFLICT(order_id,account_code) DO NOTHING").bind(memberId,t,proofId,id,decisionId),
   c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,o.id,o.user_id,'provider_clearing',-o.amount_minor,'MYR',? FROM deposit_orders o JOIN wallet_ledger l ON l.order_id=o.id AND l.id=? AND l.account_code='member' AND l.user_id=o.user_id AND l.amount_minor=o.amount_minor AND l.currency='MYR' WHERE o.id=? AND o.status='pending' AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.event='manual_bank_deposit_approved' AND a.target=o.id) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),t,memberId,id,decisionId),
   c.db.prepare("UPDATE deposit_orders SET status='credited',updated_at=? WHERE id=? AND status='pending' AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.event='manual_bank_deposit_approved' AND a.target=deposit_orders.id) AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2 AND EXISTS(SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor)").bind(t,id,decisionId),
   c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND status='pending' AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.target=deposit_orders.id)").bind(t,id,decisionId),
   c.db.prepare("UPDATE audit SET event='manual_bank_deposit_review' WHERE id=? AND EXISTS(SELECT 1 FROM deposit_orders o WHERE o.id=audit.target AND o.status='review')").bind(decisionId)
  );
  const result=await c.db.batch(statements);
  if(changed(result[4])!==1||changed(result[5])!==1)return json({error:'Deposit already reviewed or changed'},409);
  const current=await c.db.prepare('SELECT status FROM deposit_orders WHERE id=?').bind(id).first<{status:string}>();
  if(!current||!['credited','failed'].includes(current.status))return json({error:'Deposit requires manual reconciliation',status:'review'},409);
  return json({status:current.status==='credited'?'approved':'rejected',bankTransactionId:current.status==='credited'?proofId:undefined});
 }
 return null;
}
