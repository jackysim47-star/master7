import {registeredCashProfileRatioSql} from './game-profile-units.ts';

/** Correlated, static SQL: m.id is the member alias. The original wallet ledger
 * projection remains authoritative; additional provider sessions must prove the
 * same debit, closure and return before they can release its reservation. */
export const providerWalletRiskFreeSql=`
 NOT EXISTS(SELECT 1 FROM game_wallet_sessions s
 LEFT JOIN provider_wallet_operations o ON o.session_id=s.id
 LEFT JOIN game_provider_profiles p ON p.id=s.profile_id
 LEFT JOIN game_provider_players player ON player.profile_id=s.profile_id AND player.user_id=s.user_id
 LEFT JOIN wallet_reservations r ON r.reference_id=s.id AND r.kind='game'
 WHERE s.user_id=m.id AND s.provider<>'megah5' AND (
  o.session_id IS NULL OR p.id IS NULL OR player.user_id IS NULL
  OR o.profile_id<>s.profile_id OR o.user_id<>s.user_id OR p.provider_id<>s.provider
  OR player.provider_player_id<>s.player_id OR player.status<>'verified'
  OR p.wallet_mode<>'transfer' OR p.balance_class<>'cash' OR p.currency<>'MYR' OR NOT ${registeredCashProfileRatioSql}
  OR (s.status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review') AND (r.user_id IS NULL OR r.user_id<>s.user_id OR r.amount_minor<>s.amount_out_minor))
  OR (s.status IN ('settled','deposit_failed') AND r.user_id IS NOT NULL)
  OR (o.deposit_state='prepared' AND o.deposit_attempts<>0)
  OR (o.deposit_state IN ('submitting','unknown','confirmed') AND o.deposit_attempts<>1)
  OR (o.deposit_state='confirmed' AND (o.deposit_provider_reference IS NULL OR LENGTH(o.deposit_provider_reference)<1))
  OR (o.withdrawal_state IN ('submitting','unknown') AND o.withdrawal_attempts<>1)
  OR s.status='manual_review' OR o.deposit_state='review' OR o.withdrawal_state='review'
  OR (s.status IN ('active','withdraw_pending','withdraw_unknown','settled') AND o.deposit_state<>'confirmed')
  OR (s.status='deposit_unknown' AND o.deposit_state<>'unknown')
  OR (s.status='deposit_failed' AND NOT (o.deposit_state='rejected' AND o.withdrawal_state='none' AND NOT EXISTS(SELECT 1 FROM game_wallet_ledger l WHERE l.session_id=s.id)))
  OR (s.status='settled' AND NOT (
   o.deposit_state='confirmed' AND o.closure_state='confirmed' AND LENGTH(o.closure_evidence)=64
   AND o.zero_balance_verified=1 AND o.launch_state='closed'
   AND s.amount_returned_minor IS NOT NULL AND s.amount_returned_minor>=0
   AND s.expected_return_minor=s.amount_returned_minor AND o.withdrawal_state='confirmed'
   AND ((s.amount_returned_minor=0 AND o.withdrawal_attempts=0 AND o.withdrawal_provider_reference IS NULL)
    OR (s.amount_returned_minor>0 AND o.withdrawal_attempts=1 AND o.withdrawal_provider_reference IS NOT NULL AND LENGTH(o.withdrawal_provider_reference)>0))
   AND EXISTS(SELECT 1 FROM game_wallet_ledger l WHERE l.session_id=s.id AND l.user_id=s.user_id AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=s.amount_returned_minor-s.amount_out_minor)
  ))
 ))
 AND NOT EXISTS(SELECT 1 FROM provider_wallet_operations o LEFT JOIN game_wallet_sessions s ON s.id=o.session_id WHERE o.user_id=m.id AND (s.id IS NULL OR s.user_id<>o.user_id OR s.profile_id<>o.profile_id OR s.provider='megah5'))`;

/** Static aliases g / wallet_reservations are owned by stale-hold cleanup.
 * A terminal session alone is insufficient to release another provider's hold. */
export const providerTerminalHoldEvidenceSql=`(g.provider='megah5' OR EXISTS(
 SELECT 1 FROM provider_wallet_operations o
 JOIN game_provider_profiles p ON p.id=o.profile_id
 JOIN game_provider_players player ON player.profile_id=o.profile_id AND player.user_id=o.user_id
 WHERE o.session_id=g.id AND o.profile_id=g.profile_id AND o.user_id=g.user_id
 AND p.provider_id=g.provider AND p.wallet_mode='transfer' AND p.balance_class='cash' AND p.currency='MYR' AND ${registeredCashProfileRatioSql}
 AND player.provider_player_id=g.player_id AND player.status='verified'
 AND g.amount_out_minor=wallet_reservations.amount_minor
 AND ((g.status='deposit_failed' AND o.deposit_state='rejected' AND o.deposit_attempts IN (0,1) AND o.deposit_provider_reference IS NULL AND o.withdrawal_state='none' AND o.withdrawal_attempts=0)
  OR (g.status='settled' AND o.deposit_state='confirmed' AND o.deposit_attempts=1 AND o.deposit_provider_reference IS NOT NULL
   AND o.closure_state='confirmed' AND LENGTH(o.closure_evidence)=64 AND o.launch_state='closed' AND o.zero_balance_verified=1
   AND o.withdrawal_state='confirmed' AND g.expected_return_minor=g.amount_returned_minor
   AND ((g.amount_returned_minor=0 AND o.withdrawal_attempts=0 AND o.withdrawal_provider_reference IS NULL)
    OR (g.amount_returned_minor>0 AND o.withdrawal_attempts=1 AND o.withdrawal_provider_reference IS NOT NULL))))
))`;
