import {randomUUID} from 'node:crypto';
import {GAME_PROVIDER_PROFILES,getGameProviderProfile} from './game-provider-registry.ts';

export const GAME_PROVIDER_ACCEPTANCE_CAPABILITIES = Object.freeze([
  'catalogue','launch','wallet','settlement','recovery',
] as const);
export type GameProviderAcceptanceCapability = typeof GAME_PROVIDER_ACCEPTANCE_CAPABILITIES[number];
export type GameProviderAcceptanceEnvironment = 'uat'|'production';
export type GameProviderAcceptanceResult = 'passed'|'failed'|'revoked';
export type GameProviderAcceptanceActor = {id:string;role:string};

type CurrentRow={
 profile_id:string;capability:GameProviderAcceptanceCapability;environment:GameProviderAcceptanceEnvironment;
 event_id:string;revision:number;result:GameProviderAcceptanceResult;evidence_sha256:string;evidence_reference:string;
 verified_by:string;observed_at:number;recorded_at:number;
};

export class GameProviderAcceptanceError extends Error {
 status:number;code:string;
 constructor(status:number,code:string,message:string){super(message);this.status=status;this.code=code;}
}

const fail=(status:number,code:string,message:string):never=>{throw new GameProviderAcceptanceError(status,code,message);};
const validActorId=(value:unknown):value is string=>typeof value==='string'&&value.length>0&&value.length<=256&&!/[\u0000-\u001f\u007f]/u.test(value);
const isCapability=(value:unknown):value is GameProviderAcceptanceCapability=>GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.includes(value as GameProviderAcceptanceCapability);
const isEnvironment=(value:unknown):value is GameProviderAcceptanceEnvironment=>value==='uat'||value==='production';
const isResult=(value:unknown):value is GameProviderAcceptanceResult=>value==='passed'||value==='failed'||value==='revoked';
const safeEvidenceReference=(value:unknown):value is string=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9._:/#-]{0,199}$/.test(value);

function requireRead(actor:GameProviderAcceptanceActor){
 if(!validActorId(actor?.id))fail(401,'SIGN_IN_REQUIRED','Sign in required');
 if(actor.role!=='owner'&&actor.role!=='staff')fail(403,'ACCESS_DENIED','Owner or staff access required');
}

function requireOwner(actor:GameProviderAcceptanceActor){
 if(!validActorId(actor?.id))fail(401,'SIGN_IN_REQUIRED','Sign in required');
 if(actor.role!=='owner')fail(403,'OWNER_REQUIRED','Owner access required');
}

async function currentRows(db:D1Database,environment?:GameProviderAcceptanceEnvironment){
 const where=environment?'WHERE c.environment=?':'',statement=db.prepare(`SELECT c.profile_id,c.capability,c.environment,c.event_id,
   e.revision,e.result,e.evidence_sha256,e.evidence_reference,e.verified_by,e.observed_at,e.recorded_at
   FROM game_provider_acceptance_current c JOIN game_provider_acceptance_events e ON e.id=c.event_id
   ${where} ORDER BY c.profile_id,c.environment,c.capability`);
 const result=environment?await statement.bind(environment).all<CurrentRow>():await statement.all<CurrentRow>();
 return (result.results??[]) as CurrentRow[];
}

function profileStatuses(rows:CurrentRow[],environment:GameProviderAcceptanceEnvironment){
 const byKey=new Map(rows.filter(row=>row.environment===environment).map(row=>[`${row.profile_id}:${row.capability}`,row]));
 return GAME_PROVIDER_PROFILES.map(profile=>{
  const capabilities=Object.fromEntries(GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.map(capability=>{
   const row=byKey.get(`${profile.profileId}:${capability}`);
   return [capability,row?{
    passed:row.result==='passed',result:row.result,eventId:row.event_id,revision:Number(row.revision),evidenceSha256:row.evidence_sha256,
    evidenceReference:row.evidence_reference,verifiedBy:row.verified_by,observedAt:Number(row.observed_at),recordedAt:Number(row.recorded_at),
   }:{passed:false,result:'not_recorded',eventId:null,revision:0,evidenceSha256:null,evidenceReference:null,verifiedBy:null,observedAt:null,recordedAt:null}];
  }));
  const accepted=GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.every(capability=>capabilities[capability].passed===true);
  return {profileId:profile.profileId,providerId:profile.providerId,displayName:profile.displayName,listedInLobby:profile.listedInLobby,
   adapterStatus:profile.adapterStatus,implemented:profile.implemented,environment,capabilities,accepted};
 });
}

export async function getGameProviderAcceptanceReadiness(db:D1Database,runtimeReadyProfileIds:readonly string[]=[]){
 const rows=await currentRows(db,'production'),profiles=profileStatuses(rows,'production'),required=profiles.filter(profile=>profile.listedInLobby),runtimeReady=new Set(runtimeReadyProfileIds);
 const profileReadiness=required.map(profile=>({profileId:profile.profileId,providerId:profile.providerId,
  evidenceAccepted:profile.accepted,adapterImplemented:profile.implemented,runtimeReady:runtimeReady.has(profile.profileId),
  effectiveReady:profile.accepted&&profile.implemented&&runtimeReady.has(profile.profileId),
  capabilities:Object.fromEntries(GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.map(capability=>[capability,profile.capabilities[capability].passed===true])),
 }));
 const acceptedProfiles=profileReadiness.filter(profile=>profile.evidenceAccepted),liveProfiles=profileReadiness.filter(profile=>profile.effectiveReady);
 const allAcceptanceEvidencePassed=required.length>0&&acceptedProfiles.length===required.length;
 const liveGames=required.length>0&&liveProfiles.length===required.length;
 const allGamesVerified=liveGames;
 return {
  requiredProfileCount:required.length,acceptedProfileCount:acceptedProfiles.length,liveProfileCount:liveProfiles.length,
  allAcceptanceEvidencePassed,allGamesVerified,liveGames,anyGamePlayable:liveProfiles.length>0,profiles:profileReadiness,
  blockers:required.filter(profile=>!profile.accepted||!profile.implemented||!runtimeReady.has(profile.profileId)).map(profile=>({
   profileId:profile.profileId,
   missingEvidence:GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.filter(capability=>!profile.capabilities[capability].passed),
   adapterImplemented:profile.implemented,runtimeReady:runtimeReady.has(profile.profileId),
  })),
 };
}

export async function getGameProviderAcceptance(db:D1Database,actor:GameProviderAcceptanceActor,input:{environment?:unknown;eventLimit?:unknown}={}){
 requireRead(actor);
 const requestedEnvironment=input.environment??'production';
 if(!isEnvironment(requestedEnvironment))fail(400,'INVALID_ENVIRONMENT','Environment must be uat or production');
 const environment=requestedEnvironment as GameProviderAcceptanceEnvironment;
 const eventLimit=input.eventLimit===undefined?200:Number(input.eventLimit);
 if(!Number.isSafeInteger(eventLimit)||eventLimit<0||eventLimit>500)fail(400,'INVALID_LIMIT','Event limit must be between 0 and 500');
 const rows=await currentRows(db,environment),profiles=profileStatuses(rows,environment);
 let events:unknown[]=[];
 if(eventLimit>0){
  const result=await db.prepare(`SELECT id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at
    FROM game_provider_acceptance_events WHERE environment=? ORDER BY recorded_at DESC,id DESC LIMIT ?`).bind(environment,eventLimit).all();
  events=result.results??[];
 }
 return {environment,capabilities:[...GAME_PROVIDER_ACCEPTANCE_CAPABILITIES],profiles,events};
}

export async function recordGameProviderAcceptance(db:D1Database,actor:GameProviderAcceptanceActor,input:Record<string,unknown>,at=Math.floor(Date.now()/1000)){
 requireOwner(actor);
 if(Object.keys(input).some(key=>!['profileId','capability','environment','result','evidenceSha256','evidenceReference','observedAt','expectedEventId'].includes(key)))fail(400,'INVALID_FIELDS','Only acceptance evidence fields are accepted');
 const profileId=input.profileId,capability=input.capability,environment=input.environment,result=input.result,evidenceSha256=input.evidenceSha256,
  evidenceReference=input.evidenceReference,observedAt=Number(input.observedAt),expectedEventId=input.expectedEventId;
 if(typeof profileId!=='string'||!getGameProviderProfile(profileId))fail(400,'PROFILE_NOT_REGISTERED','Provider profile is not registered');
 if(!isCapability(capability))fail(400,'INVALID_CAPABILITY','Invalid acceptance capability');
 if(!isEnvironment(environment))fail(400,'INVALID_ENVIRONMENT','Environment must be uat or production');
 if(!isResult(result))fail(400,'INVALID_RESULT','Result must be passed, failed or revoked');
 if(typeof evidenceSha256!=='string'||!/^[a-f0-9]{64}$/.test(evidenceSha256))fail(400,'INVALID_EVIDENCE_DIGEST','Evidence SHA-256 must be lowercase hexadecimal');
 if(!safeEvidenceReference(evidenceReference))fail(400,'INVALID_EVIDENCE_REFERENCE','Evidence reference must be a non-secret identifier');
 if(!Number.isSafeInteger(observedAt)||observedAt<0||observedAt>at+300)fail(400,'INVALID_OBSERVED_AT','Observed time is invalid');
 if(!Object.hasOwn(input,'expectedEventId')||expectedEventId!==null&&(typeof expectedEventId!=='string'||!/^[a-f0-9-]{36}$/.test(expectedEventId)))fail(400,'INVALID_EXPECTED_EVENT','Current event id or null is required');
 const id=randomUUID(),target=`${profileId}:${capability}:${environment}:${result}:${id}`;
 try{await db.batch([
  db.prepare(`INSERT INTO game_provider_acceptance_events
   (id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
   SELECT ?,?,COALESCE((SELECT e.revision FROM game_provider_acceptance_current c JOIN game_provider_acceptance_events e ON e.id=c.event_id
    WHERE c.profile_id=? AND c.capability=? AND c.environment=?),0)+1,?,?,?,?,?,?,?,? WHERE
    (? IS NULL AND NOT EXISTS(SELECT 1 FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=?)) OR
    (? IS NOT NULL AND EXISTS(SELECT 1 FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=? AND event_id=?))`)
   .bind(id,profileId,profileId,capability,environment,capability,environment,result,evidenceSha256,evidenceReference,actor.id,observedAt,at,
    expectedEventId,profileId,capability,environment,expectedEventId,profileId,capability,environment,expectedEventId),
  db.prepare(`INSERT INTO game_provider_acceptance_current(profile_id,capability,environment,event_id)
   SELECT ?,?,?,id FROM game_provider_acceptance_events WHERE id=?
   ON CONFLICT(profile_id,capability,environment) DO UPDATE SET event_id=excluded.event_id
   WHERE ? IS NOT NULL AND game_provider_acceptance_current.event_id=?`).bind(profileId,capability,environment,id,expectedEventId,expectedEventId),
  db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'game_provider_acceptance_recorded',?,? FROM game_provider_acceptance_events WHERE id=?").bind(randomUUID(),actor.id,target,at,id),
 ]);}catch(error){
  const detail=String(error instanceof Error?error.message:error),revisionConflict=/(?:unique|duplicate key)/i.test(detail)&&/game_provider_acceptance_events/i.test(detail)&&/(?:revision|profile_id)/i.test(detail);
  if(revisionConflict){
   const current=await db.prepare('SELECT event_id FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=?').bind(profileId,capability,environment).first<{event_id:string}>();
   if(current&&(expectedEventId===null||current.event_id!==expectedEventId))fail(409,'STALE_ACCEPTANCE','Acceptance changed; refresh and try again');
  }
  throw error;
 }
 if(!await db.prepare('SELECT id FROM game_provider_acceptance_events WHERE id=?').bind(id).first())fail(409,'STALE_ACCEPTANCE','Acceptance changed; refresh and try again');
 return {status:'recorded',id,profileId,capability,environment,result,accepted:result==='passed'};
}
