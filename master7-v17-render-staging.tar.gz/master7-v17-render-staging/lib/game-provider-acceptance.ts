import {randomUUID} from 'node:crypto';
import {GAME_PROVIDER_PROFILES,getGameProviderProfile} from './game-provider-registry.ts';
import {COBA8_PROFILE_ID,inspectCoba8ContractManifest} from './coba8-contract-readiness.ts';
import {inspectKissH5ContractManifest,KISS_H5_PROFILE_IDS} from './kissh5-contract-readiness.ts';

export const GAME_PROVIDER_ACCEPTANCE_CAPABILITIES = Object.freeze([
  'catalogue','launch','wallet','settlement','recovery',
] as const);
export type GameProviderAcceptanceCapability = typeof GAME_PROVIDER_ACCEPTANCE_CAPABILITIES[number];
export type GameProviderAcceptanceEnvironment = 'uat'|'production';
export type GameProviderAcceptanceResult = 'passed'|'failed'|'revoked';
export type GameProviderAcceptanceActor = {id:string;role:string};

type CurrentRow={
 profile_id:string;capability:GameProviderAcceptanceCapability;environment:GameProviderAcceptanceEnvironment;
 event_id:string;current_event_id:string|null;projection_integrity:number;revision:number;result:GameProviderAcceptanceResult;evidence_sha256:string;evidence_reference:string;
 verified_by:string;observed_at:number;recorded_at:number;
};

type LatestRow={latest_event_id:string|null;latest_revision:number|null;current_event_id:string|null;history_min_revision:number|null;history_count:number|string};

export class GameProviderAcceptanceError extends Error {
 status:number;code:string;
 constructor(status:number,code:string,message:string){super(message);this.status=status;this.code=code;}
}

const fail=(status:number,code:string,message:string):never=>{throw new GameProviderAcceptanceError(status,code,message);};
const validActorId=(value:unknown):value is string=>typeof value==='string'&&value.length>0&&value.length<=256&&!/[\u0000-\u001f\u007f]/u.test(value);
const isCapability=(value:unknown):value is GameProviderAcceptanceCapability=>GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.includes(value as GameProviderAcceptanceCapability);
const isEnvironment=(value:unknown):value is GameProviderAcceptanceEnvironment=>value==='uat'||value==='production';
const isResult=(value:unknown):value is GameProviderAcceptanceResult=>value==='passed'||value==='failed'||value==='revoked';
const safeEvidenceReference=(value:unknown):value is string=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9._:/#-]{0,199}$/.test(value);

function requireRead(actor:GameProviderAcceptanceActor){
 if(!validActorId(actor?.id))fail(401,'SIGN_IN_REQUIRED','Sign in required');
 if(actor.role!=='owner'&&actor.role!=='staff')fail(403,'ACCESS_DENIED','Owner or staff access required');
}

function requireOwner(actor:GameProviderAcceptanceActor){
 if(!validActorId(actor?.id))fail(401,'SIGN_IN_REQUIRED','Sign in required');
 if(actor.role!=='owner')fail(403,'OWNER_REQUIRED','Owner access required');
}

async function currentRows(db:D1Database,environment?:GameProviderAcceptanceEnvironment){
 const where=environment?'AND e.environment=?':'',statement=db.prepare(`SELECT e.profile_id,e.capability,e.environment,e.id AS event_id,
   c.event_id AS current_event_id,CASE WHEN c.event_id=e.id
    AND (SELECT MIN(history.revision) FROM game_provider_acceptance_events history WHERE history.profile_id=e.profile_id AND history.capability=e.capability AND history.environment=e.environment)=1
    AND (SELECT COUNT(*) FROM game_provider_acceptance_events history WHERE history.profile_id=e.profile_id AND history.capability=e.capability AND history.environment=e.environment)=e.revision
    THEN 1 ELSE 0 END AS projection_integrity,
   e.revision,e.result,e.evidence_sha256,e.evidence_reference,e.verified_by,e.observed_at,e.recorded_at
   FROM game_provider_acceptance_events e LEFT JOIN game_provider_acceptance_current c
    ON c.profile_id=e.profile_id AND c.capability=e.capability AND c.environment=e.environment
   WHERE NOT EXISTS(SELECT 1 FROM game_provider_acceptance_events newer
    WHERE newer.profile_id=e.profile_id AND newer.capability=e.capability AND newer.environment=e.environment AND newer.revision>e.revision)
   ${where} ORDER BY e.profile_id,e.environment,e.capability`);
 const result=environment?await statement.bind(environment).all<CurrentRow>():await statement.all<CurrentRow>();
 return (result.results??[]) as CurrentRow[];
}

function profileStatuses(rows:CurrentRow[],environment:GameProviderAcceptanceEnvironment){
 const byKey=new Map(rows.filter(row=>row.environment===environment).map(row=>[`${row.profile_id}:${row.capability}`,row]));
 return GAME_PROVIDER_PROFILES.map(profile=>{
  const capabilities=Object.fromEntries(GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.map(capability=>{
   const row=byKey.get(`${profile.profileId}:${capability}`);
   return [capability,row?{
    passed:row.result==='passed'&&Number(row.projection_integrity)===1,integrityValid:Number(row.projection_integrity)===1,
    result:row.result,eventId:row.event_id,currentEventId:row.current_event_id,revision:Number(row.revision),evidenceSha256:row.evidence_sha256,
    evidenceReference:row.evidence_reference,verifiedBy:row.verified_by,observedAt:Number(row.observed_at),recordedAt:Number(row.recorded_at),
   }:{passed:false,integrityValid:true,result:'not_recorded',eventId:null,currentEventId:null,revision:0,evidenceSha256:null,evidenceReference:null,verifiedBy:null,observedAt:null,recordedAt:null}];
  }));
  const accepted=GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.every(capability=>capabilities[capability].passed===true);
  const integrityReady=GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.every(capability=>capabilities[capability].integrityValid===true);
  return {profileId:profile.profileId,providerId:profile.providerId,displayName:profile.displayName,listedInLobby:profile.listedInLobby,
   adapterStatus:profile.adapterStatus,implemented:profile.implemented,environment,capabilities,accepted,integrityReady};
 });
}

function contractDiagnostic(profileId:string){
 if((KISS_H5_PROFILE_IDS as readonly string[]).includes(profileId))return inspectKissH5ContractManifest(profileId);
 if(profileId===COBA8_PROFILE_ID)return inspectCoba8ContractManifest();
 return null;
}

export async function getGameProviderAcceptanceReadiness(db:D1Database,runtimeReadyProfileIds:readonly string[]=[]){
 const rows=await currentRows(db,'production'),profiles=profileStatuses(rows,'production'),required=profiles.filter(profile=>profile.listedInLobby),runtimeReady=new Set(runtimeReadyProfileIds);
 const integrityBlockers=rows.filter(row=>Number(row.projection_integrity)!==1).map(row=>`${row.profile_id}:${row.capability}:${row.environment}`),integrityReady=integrityBlockers.length===0;
 const profileReadiness=required.map(profile=>({profileId:profile.profileId,providerId:profile.providerId,
  evidenceAccepted:profile.accepted,integrityReady:profile.integrityReady,adapterImplemented:profile.implemented,runtimeReady:runtimeReady.has(profile.profileId),
  effectiveReady:profile.accepted&&profile.integrityReady&&profile.implemented&&runtimeReady.has(profile.profileId),
  capabilities:Object.fromEntries(GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.map(capability=>[capability,profile.capabilities[capability].passed===true])),
  contractDiagnostic:contractDiagnostic(profile.profileId),
 }));
 const acceptedProfiles=profileReadiness.filter(profile=>profile.evidenceAccepted),liveProfiles=profileReadiness.filter(profile=>profile.effectiveReady);
 const allAcceptanceEvidencePassed=integrityReady&&required.length>0&&acceptedProfiles.length===required.length;
 const liveGames=integrityReady&&required.length>0&&liveProfiles.length===required.length;
 const allGamesVerified=liveGames;
 return {
  requiredProfileCount:required.length,acceptedProfileCount:acceptedProfiles.length,liveProfileCount:liveProfiles.length,
  allAcceptanceEvidencePassed,integrityReady,integrityBlockers,allGamesVerified,liveGames,anyGamePlayable:integrityReady&&liveProfiles.length>0,profiles:profileReadiness,
  blockers:required.filter(profile=>!profile.accepted||!profile.integrityReady||!profile.implemented||!runtimeReady.has(profile.profileId)).map(profile=>({
   profileId:profile.profileId,
   missingEvidence:GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.filter(capability=>!profile.capabilities[capability].passed),
   integrityFailures:GAME_PROVIDER_ACCEPTANCE_CAPABILITIES.filter(capability=>!profile.capabilities[capability].integrityValid),
   adapterImplemented:profile.implemented,runtimeReady:runtimeReady.has(profile.profileId),
   contractDiagnostic:contractDiagnostic(profile.profileId),
  })),
 };
}

export async function getGameProviderAcceptance(db:D1Database,actor:GameProviderAcceptanceActor,input:{environment?:unknown;eventLimit?:unknown}={}){
 requireRead(actor);
 const requestedEnvironment=input.environment??'production';
 if(!isEnvironment(requestedEnvironment))fail(400,'INVALID_ENVIRONMENT','Environment must be uat or production');
 const environment=requestedEnvironment as GameProviderAcceptanceEnvironment;
 const eventLimit=input.eventLimit===undefined?200:Number(input.eventLimit);
 if(!Number.isSafeInteger(eventLimit)||eventLimit<0||eventLimit>500)fail(400,'INVALID_LIMIT','Event limit must be between 0 and 500');
 const rows=await currentRows(db,environment),profiles=profileStatuses(rows,environment);
 let events:unknown[]=[];
 if(eventLimit>0){
  const result=await db.prepare(`SELECT id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at
    FROM game_provider_acceptance_events WHERE environment=? ORDER BY recorded_at DESC,id DESC LIMIT ?`).bind(environment,eventLimit).all();
  events=result.results??[];
 }
 const integrityBlockers=rows.filter(row=>Number(row.projection_integrity)!==1).map(row=>`${row.profile_id}:${row.capability}:${row.environment}`);
 return {environment,capabilities:[...GAME_PROVIDER_ACCEPTANCE_CAPABILITIES],integrityReady:integrityBlockers.length===0,integrityBlockers,profiles,events};
}

export async function recordGameProviderAcceptance(db:D1Database,actor:GameProviderAcceptanceActor,input:Record<string,unknown>,at=Math.floor(Date.now()/1000)){
 requireOwner(actor);
 if(Object.keys(input).some(key=>!['profileId','capability','environment','result','evidenceSha256','evidenceReference','observedAt','expectedEventId'].includes(key)))fail(400,'INVALID_FIELDS','Only acceptance evidence fields are accepted');
 const profileId=input.profileId,capability=input.capability,environment=input.environment,result=input.result,evidenceSha256=input.evidenceSha256,
  evidenceReference=input.evidenceReference,observedAt=Number(input.observedAt),expectedEventId=input.expectedEventId;
 if(typeof profileId!=='string'||!getGameProviderProfile(profileId))fail(400,'PROFILE_NOT_REGISTERED','Provider profile is not registered');
 if(!isCapability(capability))fail(400,'INVALID_CAPABILITY','Invalid acceptance capability');
 if(!isEnvironment(environment))fail(400,'INVALID_ENVIRONMENT','Environment must be uat or production');
 if(!isResult(result))fail(400,'INVALID_RESULT','Result must be passed, failed or revoked');
 if(typeof evidenceSha256!=='string'||!/^[a-f0-9]{64}$/.test(evidenceSha256))fail(400,'INVALID_EVIDENCE_DIGEST','Evidence SHA-256 must be lowercase hexadecimal');
 if(!safeEvidenceReference(evidenceReference))fail(400,'INVALID_EVIDENCE_REFERENCE','Evidence reference must be a non-secret identifier');
 if(!Number.isSafeInteger(observedAt)||observedAt<0||observedAt>at+300)fail(400,'INVALID_OBSERVED_AT','Observed time is invalid');
 if(!Object.hasOwn(input,'expectedEventId')||expectedEventId!==null&&(typeof expectedEventId!=='string'||!/^[a-f0-9-]{36}$/.test(expectedEventId)))fail(400,'INVALID_EXPECTED_EVENT','Current event id or null is required');
 const latest=await db.prepare(`SELECT
  (SELECT id FROM game_provider_acceptance_events WHERE profile_id=? AND capability=? AND environment=? ORDER BY revision DESC LIMIT 1) AS latest_event_id,
  (SELECT revision FROM game_provider_acceptance_events WHERE profile_id=? AND capability=? AND environment=? ORDER BY revision DESC LIMIT 1) AS latest_revision,
  (SELECT event_id FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=?) AS current_event_id,
  (SELECT MIN(revision) FROM game_provider_acceptance_events WHERE profile_id=? AND capability=? AND environment=?) AS history_min_revision,
  (SELECT COUNT(*) FROM game_provider_acceptance_events WHERE profile_id=? AND capability=? AND environment=?) AS history_count`)
  .bind(profileId,capability,environment,profileId,capability,environment,profileId,capability,environment,profileId,capability,environment,profileId,capability,environment).first<LatestRow>();
 const latestEventId=latest?.latest_event_id??null,currentEventId=latest?.current_event_id??null;
 const latestRevision=latest?.latest_revision===null||latest?.latest_revision===undefined?null:Number(latest.latest_revision),historyCount=Number(latest?.history_count??0),historyMin=latest?.history_min_revision===null||latest?.history_min_revision===undefined?null:Number(latest.history_min_revision);
 if(latestEventId!==currentEventId||(latestEventId!==null&&(historyMin!==1||historyCount!==latestRevision)))fail(409,'ACCEPTANCE_INTEGRITY_ERROR','Acceptance projection does not match immutable history');
 if(expectedEventId!==latestEventId)fail(409,'STALE_ACCEPTANCE','Acceptance changed; refresh and try again');
 const id=randomUUID(),target=`${profileId}:${capability}:${environment}:${result}:${id}`;
 try{await db.batch([
  db.prepare(`INSERT INTO game_provider_acceptance_events
   (id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
   SELECT ?,?,COALESCE((SELECT MAX(e.revision) FROM game_provider_acceptance_events e
    WHERE e.profile_id=? AND e.capability=? AND e.environment=?),0)+1,?,?,?,?,?,?,?,? WHERE
    (CAST(? AS TEXT) IS NULL AND NOT EXISTS(SELECT 1 FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=?)) OR
    (CAST(? AS TEXT) IS NOT NULL AND EXISTS(SELECT 1 FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=? AND event_id=?))`)
   .bind(id,profileId,profileId,capability,environment,capability,environment,result,evidenceSha256,evidenceReference,actor.id,observedAt,at,
    expectedEventId,profileId,capability,environment,expectedEventId,profileId,capability,environment,expectedEventId),
  db.prepare(`INSERT INTO game_provider_acceptance_current(profile_id,capability,environment,event_id)
   SELECT ?,?,?,id FROM game_provider_acceptance_events WHERE id=?
   ON CONFLICT(profile_id,capability,environment) DO UPDATE SET event_id=excluded.event_id
   WHERE CAST(? AS TEXT) IS NOT NULL AND game_provider_acceptance_current.event_id=?`).bind(profileId,capability,environment,id,expectedEventId,expectedEventId),
  db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'game_provider_acceptance_recorded',?,? FROM game_provider_acceptance_events WHERE id=?").bind(randomUUID(),actor.id,target,at,id),
 ]);}catch(error){
  const detail=String(error instanceof Error?error.message:error),sqlState=error&&typeof error==='object'&&'code' in error?String(error.code):'';
  if(/acceptance (?:projection|history)/i.test(detail))fail(409,'ACCEPTANCE_INTEGRITY_ERROR','Acceptance projection does not match immutable history');
  const revisionConflict=sqlState==='23505'||/(?:unique|duplicate key)/i.test(detail)&&/game_provider_acceptance_events/i.test(detail)&&/(?:revision|profile_id)/i.test(detail);
  if(revisionConflict){
   const state=await db.prepare(`SELECT
    (SELECT id FROM game_provider_acceptance_events WHERE profile_id=? AND capability=? AND environment=? ORDER BY revision DESC LIMIT 1) AS latest_event_id,
    (SELECT event_id FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=?) AS current_event_id`)
    .bind(profileId,capability,environment,profileId,capability,environment).first<{latest_event_id:string|null;current_event_id:string|null}>();
   if((state?.latest_event_id??null)!==(state?.current_event_id??null))fail(409,'ACCEPTANCE_INTEGRITY_ERROR','Acceptance projection does not match immutable history');
   fail(409,'STALE_ACCEPTANCE','Acceptance changed; refresh and try again');
  }
  throw error;
 }
 const recorded=await db.prepare(`SELECT e.id,c.event_id AS current_event_id FROM game_provider_acceptance_events e
  LEFT JOIN game_provider_acceptance_current c ON c.profile_id=e.profile_id AND c.capability=e.capability AND c.environment=e.environment
  WHERE e.id=?`).bind(id).first<{id:string;current_event_id:string|null}>();
 if(!recorded)fail(409,'STALE_ACCEPTANCE','Acceptance changed; refresh and try again');
 if(recorded!.current_event_id!==id)fail(409,'ACCEPTANCE_INTEGRITY_ERROR','Acceptance projection does not match immutable history');
 return {status:'recorded',id,profileId,capability,environment,result,accepted:result==='passed'};
}
