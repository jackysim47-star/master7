import {createMetaGamingProviderAdapter,type MetaGamingGatewayConfig} from './metagaming-provider-adapter.ts';
import {getGameProviderProfile} from './game-provider-registry.ts';

const CUSTOMER_RETURN_ORIGIN='https://www.master7.best';
const DEFAULT_RETURN_ORIGINS=Object.freeze([CUSTOMER_RETURN_ORIGIN]);
function exactOrigin(value:unknown){if(typeof value!=='string')return null;try{const url=new URL(value);return url.origin===value&&url.protocol==='https:'&&!url.username&&!url.password&&!url.port?url.origin:null;}catch{return null;}}
function token(value:unknown){return typeof value==='string'&&Buffer.byteLength(value,'utf8')>=32&&Buffer.byteLength(value,'utf8')<=1024&&!/[\u0000-\u0020\u007f-\u009f]/u.test(value)?value:null;}
function sha(value:unknown){return typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);}
function expectedAccount(profileId:string){return profileId==='metagaming_normal_myr'?'normal':profileId==='metagaming_free_myr'?'free':null;}

/** Parse one profile from the server-side GAME_TRANSFER_PROFILES_JSON secret.
 * No browser input can select an account, gateway origin, peer token or mode. */
export function metaGamingProfileRuntime(raw:string|undefined,profileId:string,userId:string,options:{fetchImpl?:typeof fetch;productionAccepted?:boolean}={}){
 if(!raw||Buffer.byteLength(raw)>262_144)return null;const account=expectedAccount(profileId);if(!account)return null;
 try{
  const root=JSON.parse(raw),value=root?.profiles?.[profileId],profile=getGameProviderProfile(profileId);if(!profile||!value||!['closed','qa','production'].includes(value.mode)||value.environment!=='production'||typeof value.recoveryEnabled!=='boolean')return null;
  const connection=value.connection as MetaGamingGatewayConfig,base=exactOrigin(connection?.baseUrl),approved=Array.isArray(value.approvedApiOrigins)?value.approvedApiOrigins.map(exactOrigin):[];
  if(!connection||connection.profile!==profileId||connection.account!==account||connection.currency!=='MYR'||!base||approved.length===0||approved.length>20||approved.some((x:unknown)=>x===null)||!approved.includes(base))return null;
  const tokens=[token(connection.playerToken),token(connection.walletToken),token(connection.recoveryToken),token(connection.reportToken)];if(tokens.some(x=>x===null)||new Set(tokens).size!==tokens.length)return null;
  if(!Array.isArray(connection.launchOrigins)||connection.launchOrigins.length===0||connection.launchOrigins.length>20||connection.launchOrigins.map(exactOrigin).some(x=>x===null))return null;
  if(!Array.isArray(value.qaMemberIds)||value.qaMemberIds.length>50||value.qaMemberIds.some((x:unknown)=>typeof x!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(x)))return null;
  const returnValues=value.allowedReturnOrigins===undefined?DEFAULT_RETURN_ORIGINS:value.allowedReturnOrigins;if(!Array.isArray(returnValues)||returnValues.length===0||returnValues.length>20)return null;const returns=returnValues.map(exactOrigin);if(returns.some(x=>x===null))return null;
  const contractVerified=value.merchantContractVerified===true&&sha(value.merchantContractEvidenceSha256);
  const closureVerified=contractVerified&&value.sessionClosureVerified===true&&value.allIssuedLaunchesInvalidated===true&&value.lateResultsFinal===true&&sha(value.sessionClosureEvidenceSha256);
  const recoveryEnabled=value.recoveryEnabled===true&&closureVerified;
  const memberAuthorized=value.mode==='qa'?value.qaMemberIds.includes(userId):value.mode==='production'&&options.productionAccepted===true;
  const launchAuthorized=closureVerified&&recoveryEnabled&&returns.length===1&&returns[0]===CUSTOMER_RETURN_ORIGIN&&memberAuthorized;
  const reportEnabled=contractVerified&&value.reportEnabled===true&&value.reportFlaggingVerified===true&&sha(value.reportEvidenceSha256);
  const adapter=createMetaGamingProviderAdapter({...connection,baseUrl:base,launchOrigins:connection.launchOrigins.map(exactOrigin) as string[]},{fetchImpl:options.fetchImpl??fetch,allowedReturnOrigins:returns as string[],merchantContractVerified:contractVerified,sessionClosureVerified:closureVerified,playerCreationEnabled:launchAuthorized,balanceEnabled:launchAuthorized||recoveryEnabled,depositEnabled:launchAuthorized,withdrawalEnabled:recoveryEnabled,launchEnabled:launchAuthorized,transferStatusEnabled:recoveryEnabled,recoveryEnabled,reportEnabled});
  return{profile,adapter,launchAuthorized,recoveryEnabled,reportEnabled,mode:value.mode as 'closed'|'qa'|'production',environment:'production' as const};
 }catch{return null;}
}
