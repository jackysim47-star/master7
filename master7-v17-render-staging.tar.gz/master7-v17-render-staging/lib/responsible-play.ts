const MYT_OFFSET_SECONDS=8*60*60;
const DAY_SECONDS=24*60*60;
const LIMIT_CHANGE_DELAY_SECONDS=DAY_SECONDS;
const RESERVATION_SECONDS=15*60;
const MAX_LIMIT_MINOR=BigInt('100000000000');
const NON_TERMINAL_DEPOSIT_STATUSES=['pending','creating','created','unknown','review'] as const;
const PROVIDERS=new Set(['vpay','gspay','1mpay','manual_bank']);

type LimitValue=string|null;
type ProfileRow={
 user_id:string;
 daily_limit_minor:string|number|bigint|null;
 weekly_limit_minor:string|number|bigint|null;
 monthly_limit_minor:string|number|bigint|null;
 pending_daily_limit_minor:string|number|bigint|null;
 pending_weekly_limit_minor:string|number|bigint|null;
 pending_monthly_limit_minor:string|number|bigint|null;
 pending_limits_effective_at:string|number|bigint|null;
 cooling_off_until:string|number|bigint|null;
 self_excluded_until:string|number|bigint|null;
 version:string|number|bigint;
 last_change_id:string;
 created_at:string|number|bigint;
 updated_at:string|number|bigint;
};

type PeriodWindow={start:number;end:number};
export type ResponsiblePlayPeriodWindows={daily:PeriodWindow;weekly:PeriodWindow;monthly:PeriodWindow};

export class ResponsiblePlayError extends Error{
 status:number;
 code:string;
 constructor(status:number,code:string,message:string){super(message);this.status=status;this.code=code;}
}

const epoch=()=>Math.floor(Date.now()/1000);
const id=()=>crypto.randomUUID();
const asEpoch=(value:unknown)=>value===null||value===undefined?null:Number(value);
const asLimit=(value:unknown):LimitValue=>value===null||value===undefined?null:String(value);
const bigint=(value:unknown)=>BigInt(String(value??0));
const active=(until:unknown,at:number)=>{const value=asEpoch(until);return value!==null&&Number.isSafeInteger(value)&&value>at;};
const changes=(result:unknown)=>Number((result as any)?.meta?.changes??(result as any)?.changes??0)||0;

export function mytPeriodWindows(at=epoch()):ResponsiblePlayPeriodWindows{
 if(!Number.isSafeInteger(at)||at<0)throw new ResponsiblePlayError(400,'INVALID_TIME','Invalid timestamp');
 const dailyStart=Math.floor((at+MYT_OFFSET_SECONDS)/DAY_SECONDS)*DAY_SECONDS-MYT_OFFSET_SECONDS;
 const shifted=new Date((at+MYT_OFFSET_SECONDS)*1000);
 const dayOfWeek=(shifted.getUTCDay()+6)%7;
 const weeklyStart=dailyStart-dayOfWeek*DAY_SECONDS;
 const monthlyStart=Math.floor(Date.UTC(shifted.getUTCFullYear(),shifted.getUTCMonth(),1)/1000)-MYT_OFFSET_SECONDS;
 const nextMonthStart=Math.floor(Date.UTC(shifted.getUTCFullYear(),shifted.getUTCMonth()+1,1)/1000)-MYT_OFFSET_SECONDS;
 return {
  daily:{start:dailyStart,end:dailyStart+DAY_SECONDS},
  weekly:{start:weeklyStart,end:weeklyStart+7*DAY_SECONDS},
  monthly:{start:monthlyStart,end:nextMonthStart},
 };
}

export function strictMinor(value:unknown,name='limit'):LimitValue{
 if(value===null)return null;
 if(typeof value!=='string')throw new ResponsiblePlayError(400,'INVALID_LIMIT',`Invalid ${name}`);
 if(!/^[1-9]\d*$/.test(value))throw new ResponsiblePlayError(400,'INVALID_LIMIT',`${name} must be a positive integer in MYR minor units`);
 const parsed=BigInt(value);
 if(parsed>MAX_LIMIT_MINOR)throw new ResponsiblePlayError(400,'INVALID_LIMIT',`${name} is too large`);
 return parsed.toString();
}

// Deposit APIs accept MYR major units while the policy engine stores integer
// minor units. Keep this conversion identical across all deposit providers so
// no route can round differently and accidentally bypass a limit.
export function depositAmountMinor(value:unknown){
 if(typeof value==='number'){
  if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;
  value=value.toFixed(2);
 }
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*BigInt(100)+BigInt(fraction.padEnd(2,'0'));
 return minor>BigInt(0)&&minor<=BigInt(10000000)?minor.toString():null;
}

function strictObject(value:unknown,allowed:string[]){
 if(!value||typeof value!=='object'||Array.isArray(value))throw new ResponsiblePlayError(400,'INVALID_REQUEST','Invalid Responsible Play request');
 for(const key of Object.keys(value))if(!allowed.includes(key))throw new ResponsiblePlayError(400,'INVALID_REQUEST',`Unexpected field: ${key}`);
 return value as Record<string,unknown>;
}

function currentLimits(profile:ProfileRow|null){return {
 daily:asLimit(profile?.daily_limit_minor),weekly:asLimit(profile?.weekly_limit_minor),monthly:asLimit(profile?.monthly_limit_minor),
};}
function pendingLimits(profile:ProfileRow|null){return {
 daily:asLimit(profile?.pending_daily_limit_minor),weekly:asLimit(profile?.pending_weekly_limit_minor),monthly:asLimit(profile?.pending_monthly_limit_minor),
};}
function validateHierarchy(limits:{daily:LimitValue;weekly:LimitValue;monthly:LimitValue}){
 if(limits.daily!==null&&limits.weekly!==null&&bigint(limits.daily)>bigint(limits.weekly))throw new ResponsiblePlayError(400,'INVALID_LIMIT_ORDER','Weekly limit must be at least the daily limit');
 if(limits.weekly!==null&&limits.monthly!==null&&bigint(limits.weekly)>bigint(limits.monthly))throw new ResponsiblePlayError(400,'INVALID_LIMIT_ORDER','Monthly limit must be at least the weekly limit');
 if(limits.daily!==null&&limits.monthly!==null&&bigint(limits.daily)>bigint(limits.monthly))throw new ResponsiblePlayError(400,'INVALID_LIMIT_ORDER','Monthly limit must be at least the daily limit');
}
function lessRestrictive(current:LimitValue,next:LimitValue){return current!==null&&(next===null||bigint(next)>bigint(current));}
function profileVersion(profile:ProfileRow|null){return Number(profile?.version??0);}
async function profile(db:D1Database,userId:string){return db.prepare('SELECT * FROM responsible_play_profiles WHERE user_id=?').bind(userId).first<ProfileRow>();}
function audit(db:D1Database,userId:string,event:string,target:string,at:number,auditId=id()){return db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(auditId,userId,event,target,at);}
function lock(db:D1Database,userId:string,at:number){return db.prepare('INSERT INTO responsible_play_locks(user_id,touched_at) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET touched_at=excluded.touched_at').bind(userId,at);}

async function applyMaturedLimits(db:D1Database,userId:string,at:number){
 const before=await profile(db,userId),effective=asEpoch(before?.pending_limits_effective_at);
 if(!before||effective===null||effective>at)return before;
 const auditId=`responsible-play-limits-applied:${userId}:${effective}`;
 await db.batch([
  lock(db,userId,at),
  db.prepare(`UPDATE responsible_play_profiles SET
    daily_limit_minor=pending_daily_limit_minor,weekly_limit_minor=pending_weekly_limit_minor,monthly_limit_minor=pending_monthly_limit_minor,
    pending_daily_limit_minor=NULL,pending_weekly_limit_minor=NULL,pending_monthly_limit_minor=NULL,pending_limits_effective_at=NULL,
    version=version+1,last_change_id=?,updated_at=? WHERE user_id=? AND pending_limits_effective_at IS NOT NULL AND pending_limits_effective_at<=?`).bind(auditId,at,userId,at),
  db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM responsible_play_profiles WHERE user_id=? AND last_change_id=?) ON CONFLICT(id) DO NOTHING').bind(auditId,userId,'responsible_play_limits_applied',JSON.stringify({effectiveAt:effective}),at,userId,auditId),
 ]);
 return profile(db,userId);
}

function validateUntil(value:unknown,at:number,minimum:number,maximum:number,name:string){
 if(typeof value!=='number'||!Number.isSafeInteger(value))throw new ResponsiblePlayError(400,'INVALID_UNTIL',`${name} must be an integer Unix timestamp`);
 if(value<at+minimum||value>at+maximum)throw new ResponsiblePlayError(400,'INVALID_UNTIL',`Invalid ${name}`);
 return value;
}

async function saveProfileChange(db:D1Database,userId:string,before:ProfileRow|null,changeId:string,at:number,columns:{
 daily:LimitValue;weekly:LimitValue;monthly:LimitValue;pendingDaily:LimitValue;pendingWeekly:LimitValue;pendingMonthly:LimitValue;pendingAt:number|null;coolingUntil:number|null;excludedUntil:number|null;
},event:string,target:Record<string,unknown>){
 const expected=profileVersion(before),nextVersion=expected+1;
 await db.batch([
  lock(db,userId,at),
  db.prepare(`INSERT INTO responsible_play_profiles(
   user_id,daily_limit_minor,weekly_limit_minor,monthly_limit_minor,pending_daily_limit_minor,pending_weekly_limit_minor,pending_monthly_limit_minor,pending_limits_effective_at,cooling_off_until,self_excluded_until,version,last_change_id,created_at,updated_at
  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  ON CONFLICT(user_id) DO UPDATE SET
   daily_limit_minor=excluded.daily_limit_minor,weekly_limit_minor=excluded.weekly_limit_minor,monthly_limit_minor=excluded.monthly_limit_minor,
   pending_daily_limit_minor=excluded.pending_daily_limit_minor,pending_weekly_limit_minor=excluded.pending_weekly_limit_minor,pending_monthly_limit_minor=excluded.pending_monthly_limit_minor,pending_limits_effective_at=excluded.pending_limits_effective_at,
   cooling_off_until=excluded.cooling_off_until,self_excluded_until=excluded.self_excluded_until,
   version=excluded.version,last_change_id=excluded.last_change_id,updated_at=excluded.updated_at
  WHERE responsible_play_profiles.version=?`).bind(
   userId,columns.daily,columns.weekly,columns.monthly,columns.pendingDaily,columns.pendingWeekly,columns.pendingMonthly,columns.pendingAt,columns.coolingUntil,columns.excludedUntil,nextVersion,changeId,at,at,expected,
  ),
  db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM responsible_play_profiles WHERE user_id=? AND last_change_id=?) ON CONFLICT(id) DO NOTHING').bind(changeId,userId,event,JSON.stringify(target),at,userId,changeId),
 ]);
 const after=await profile(db,userId);
 if(!after||after.last_change_id!==changeId)throw new ResponsiblePlayError(409,'CONCURRENT_UPDATE','Responsible Play settings changed in another request. Reload and try again.');
 return after;
}

export async function updateResponsiblePlay(db:D1Database,userId:string,input:unknown,at=epoch()){
 const base=strictObject(input,['action','dailyLimitMinor','weeklyLimitMinor','monthlyLimitMinor','durationHours','durationDays','until']);
 const action=base.action;
 if(!['set_limits','cooling_off','self_exclude'].includes(String(action)))throw new ResponsiblePlayError(400,'INVALID_ACTION','Choose a Responsible Play action');
 const before=await applyMaturedLimits(db,userId,at);let limits=currentLimits(before),pending=pendingLimits(before),pendingAt=asEpoch(before?.pending_limits_effective_at),coolingUntil=asEpoch(before?.cooling_off_until),excludedUntil=asEpoch(before?.self_excluded_until);
 const changeId=id();let event:string,target:Record<string,unknown>;
 if(action==='set_limits'){
  strictObject(input,['action','dailyLimitMinor','weeklyLimitMinor','monthlyLimitMinor']);
  if(!Object.hasOwn(base,'dailyLimitMinor')||!Object.hasOwn(base,'weeklyLimitMinor')||!Object.hasOwn(base,'monthlyLimitMinor'))throw new ResponsiblePlayError(400,'INVALID_LIMIT','All three limit fields are required; use null for no limit');
  const next={daily:strictMinor(base.dailyLimitMinor,'daily limit'),weekly:strictMinor(base.weeklyLimitMinor,'weekly limit'),monthly:strictMinor(base.monthlyLimitMinor,'monthly limit')};validateHierarchy(next);
  const delayedFields={daily:lessRestrictive(limits.daily,next.daily),weekly:lessRestrictive(limits.weekly,next.weekly),monthly:lessRestrictive(limits.monthly,next.monthly)},delayed=Object.values(delayedFields).some(Boolean);
  if(delayed){
   // Apply every safer field immediately. Only fields that increase or remove
   // protection retain their current value until the complete target becomes
   // effective after the safety delay.
   limits={daily:delayedFields.daily?limits.daily:next.daily,weekly:delayedFields.weekly?limits.weekly:next.weekly,monthly:delayedFields.monthly?limits.monthly:next.monthly};validateHierarchy(limits);
   pending=next;pendingAt=at+LIMIT_CHANGE_DELAY_SECONDS;event='responsible_play_limits_scheduled';target={effectiveAt:pendingAt};
  }
  else{limits=next;pending={daily:null,weekly:null,monthly:null};pendingAt=null;event='responsible_play_limits_updated';target={effectiveAt:at};}
 }else if(action==='cooling_off'){
  strictObject(input,['action','durationHours','until']);
  if((base.durationHours===undefined)===(base.until===undefined))throw new ResponsiblePlayError(400,'INVALID_UNTIL','Choose either durationHours or until');
  let until:number;if(base.durationHours!==undefined){if(typeof base.durationHours!=='number'||![24,72,168,720].includes(base.durationHours))throw new ResponsiblePlayError(400,'INVALID_DURATION','Choose 24, 72, 168 or 720 hours');until=at+base.durationHours*3600;}else until=validateUntil(base.until,at,3600,365*DAY_SECONDS,'cooling-off end');
  if(active(coolingUntil,at)&&until<=coolingUntil!)throw new ResponsiblePlayError(409,'ACTIVE_WINDOW_IMMUTABLE','An active cooling-off period cannot be shortened or cancelled');
  coolingUntil=Math.max(coolingUntil??0,until);event='responsible_play_cooling_off_started';target={until:coolingUntil,timezone:'Asia/Kuching'};
 }else{
  strictObject(input,['action','durationDays','until']);
  if((base.durationDays===undefined)===(base.until===undefined))throw new ResponsiblePlayError(400,'INVALID_UNTIL','Choose either durationDays or until');
  let until:number;if(base.durationDays!==undefined){if(typeof base.durationDays!=='number'||![30,90,180,365,1825].includes(base.durationDays))throw new ResponsiblePlayError(400,'INVALID_DURATION','Choose 30, 90, 180, 365 or 1825 days');until=at+base.durationDays*DAY_SECONDS;}else until=validateUntil(base.until,at,30*DAY_SECONDS,5*365*DAY_SECONDS,'self-exclusion end');
  if(active(excludedUntil,at)&&until<=excludedUntil!)throw new ResponsiblePlayError(409,'ACTIVE_WINDOW_IMMUTABLE','An active self-exclusion cannot be shortened or cancelled');
  excludedUntil=Math.max(excludedUntil??0,until);event='responsible_play_self_exclusion_started';target={until:excludedUntil,timezone:'Asia/Kuching'};
 }
 await saveProfileChange(db,userId,before,changeId,at,{daily:limits.daily,weekly:limits.weekly,monthly:limits.monthly,pendingDaily:pending.daily,pendingWeekly:pending.weekly,pendingMonthly:pending.monthly,pendingAt,coolingUntil,excludedUntil},event,target);
 return getResponsiblePlay(db,userId,at);
}

async function usage(db:D1Database,userId:string,at:number,windows= mytPeriodWindows(at)){
 const statuses=NON_TERMINAL_DEPOSIT_STATUSES.map(()=>'?').join(',');
 const orders=await db.prepare(`SELECT
  COALESCE(SUM(CASE WHEN status IN (${statuses}) THEN CAST(amount_minor AS BIGINT) ELSE 0 END),0) unresolved_minor,
  COALESCE(SUM(CASE WHEN status='credited' AND updated_at>=? AND updated_at<? THEN CAST(amount_minor AS BIGINT) ELSE 0 END),0) daily_credited_minor,
  COALESCE(SUM(CASE WHEN status='credited' AND updated_at>=? AND updated_at<? THEN CAST(amount_minor AS BIGINT) ELSE 0 END),0) weekly_credited_minor,
  COALESCE(SUM(CASE WHEN status='credited' AND updated_at>=? AND updated_at<? THEN CAST(amount_minor AS BIGINT) ELSE 0 END),0) monthly_credited_minor
  FROM deposit_orders WHERE user_id=?`).bind(...[...NON_TERMINAL_DEPOSIT_STATUSES,windows.daily.start,windows.daily.end,windows.weekly.start,windows.weekly.end,windows.monthly.start,windows.monthly.end,userId]).first<any>();
 const reservations=await db.prepare(`SELECT COALESCE(SUM(CAST(r.amount_minor AS BIGINT)),0) amount_minor FROM responsible_play_deposit_reservations r
  WHERE r.user_id=? AND r.status='reserved' AND r.expires_at>? AND NOT EXISTS(SELECT 1 FROM deposit_orders d WHERE d.user_id=r.user_id AND d.request_key=r.request_key)`).bind(userId,at).first<{amount_minor:string|number|bigint}>();
 const outstanding=bigint(orders?.unresolved_minor)+bigint(reservations?.amount_minor);
 return {
  outstanding:outstanding.toString(),
  daily:(bigint(orders?.daily_credited_minor)+outstanding).toString(),
  weekly:(bigint(orders?.weekly_credited_minor)+outstanding).toString(),
  monthly:(bigint(orders?.monthly_credited_minor)+outstanding).toString(),
 };
}

function allowance(limit:LimitValue,used:string){return limit===null?null:(bigint(limit)>bigint(used)?bigint(limit)-bigint(used):BigInt(0)).toString();}

export async function getResponsiblePlay(db:D1Database,userId:string,at=epoch()){
 const saved=await applyMaturedLimits(db,userId,at),limits=currentLimits(saved),pending=pendingLimits(saved),windows=mytPeriodWindows(at),used=await usage(db,userId,at,windows);
 const coolingUntil=asEpoch(saved?.cooling_off_until),excludedUntil=asEpoch(saved?.self_excluded_until),coolingActive=active(coolingUntil,at),excludedActive=active(excludedUntil,at);
 return {
  configured:!!saved,timezone:'Asia/Kuching',currency:'MYR',minorUnit:100,
  restricted:coolingActive||excludedActive,
  restrictions:{coolingOff:{active:coolingActive,until:coolingUntil},selfExclusion:{active:excludedActive,until:excludedUntil}},
  limits:{dailyMinor:limits.daily,weeklyMinor:limits.weekly,monthlyMinor:limits.monthly},
  pendingLimits:saved?.pending_limits_effective_at?{dailyMinor:pending.daily,weeklyMinor:pending.weekly,monthlyMinor:pending.monthly,effectiveAt:asEpoch(saved.pending_limits_effective_at)}:null,
  periods:windows,
  usage:{outstandingMinor:used.outstanding,dailyMinor:used.daily,weeklyMinor:used.weekly,monthlyMinor:used.monthly},
  remaining:{dailyMinor:allowance(limits.daily,used.daily),weeklyMinor:allowance(limits.weekly,used.weekly),monthlyMinor:allowance(limits.monthly,used.monthly)},
  availability:{newDeposits:!(coolingActive||excludedActive),gameLaunch:!(coolingActive||excludedActive),withdrawalRestriction:'not_added_by_play_settings',withdrawalChannelReadiness:'separate',login:true,records:true,support:true,balanceFrozen:false,balanceForfeited:false},
  policy:{lessRestrictiveLimitDelaySeconds:LIMIT_CHANGE_DELAY_SECONDS,activeWindowsCanBeShortened:false,ownerOverride:false},
  updatedAt:saved?Number(saved.updated_at):null,
 };
}

function limitCondition(column:string,start:number,end:number){
 const statuses=NON_TERMINAL_DEPOSIT_STATUSES.map(()=>'?').join(',');
 const sql=`(p.${column} IS NULL OR (
  COALESCE((SELECT SUM(CAST(d.amount_minor AS BIGINT)) FROM deposit_orders d WHERE d.user_id=p.user_id AND ((d.status='credited' AND d.updated_at>=? AND d.updated_at<?) OR d.status IN (${statuses}))),0)
  +COALESCE((SELECT SUM(CAST(r.amount_minor AS BIGINT)) FROM responsible_play_deposit_reservations r WHERE r.user_id=p.user_id AND r.status='reserved' AND r.expires_at>? AND NOT EXISTS(SELECT 1 FROM deposit_orders x WHERE x.user_id=r.user_id AND x.request_key=r.request_key)),0)
  +CAST(? AS BIGINT))<=CAST(p.${column} AS BIGINT))`;
 return {sql,values:[start,end,...NON_TERMINAL_DEPOSIT_STATUSES]};
}

export async function reserveResponsiblePlayDeposit(db:D1Database,userId:string,input:{provider:string;requestKey:string;amountMinor:string},at=epoch()){
 if(!PROVIDERS.has(input.provider))throw new ResponsiblePlayError(400,'INVALID_PROVIDER','Invalid deposit provider');
 if(typeof input.requestKey!=='string'||!/^[A-Za-z0-9_-]{1,80}$/.test(input.requestKey))throw new ResponsiblePlayError(400,'INVALID_REQUEST_KEY','Invalid deposit request key');
 const amount=strictMinor(input.amountMinor,'deposit amount');if(amount===null)throw new ResponsiblePlayError(400,'INVALID_AMOUNT','Invalid deposit amount');
 const windows=mytPeriodWindows(at),daily=limitCondition('daily_limit_minor',windows.daily.start,windows.daily.end),weekly=limitCondition('weekly_limit_minor',windows.weekly.start,windows.weekly.end),monthly=limitCondition('monthly_limit_minor',windows.monthly.start,windows.monthly.end);
 const sql=`INSERT INTO responsible_play_deposit_reservations(user_id,request_key,provider,amount_minor,status,order_id,expires_at,created_at,updated_at)
  SELECT ?,?,?,?,'reserved',NULL,?,?,? FROM responsible_play_profiles p WHERE p.user_id=?
  AND (p.cooling_off_until IS NULL OR p.cooling_off_until<=?) AND (p.self_excluded_until IS NULL OR p.self_excluded_until<=?)
  AND ${daily.sql} AND ${weekly.sql} AND ${monthly.sql}
  ON CONFLICT(user_id,request_key) DO UPDATE SET
   status='reserved',order_id=NULL,expires_at=excluded.expires_at,updated_at=excluded.updated_at
  WHERE responsible_play_deposit_reservations.status='released'
   AND responsible_play_deposit_reservations.provider=excluded.provider
   AND responsible_play_deposit_reservations.amount_minor=excluded.amount_minor
   AND NOT EXISTS(SELECT 1 FROM deposit_orders existing_order WHERE existing_order.user_id=excluded.user_id AND existing_order.request_key=excluded.request_key)`;
 const binds:any[]=[userId,input.requestKey,input.provider,amount,at+RESERVATION_SECONDS,at,at,userId,at,at];
 for(const item of [daily,weekly,monthly])binds.push(...item.values,at,amount);
 const transaction=await db.batch([
  lock(db,userId,at),
  db.prepare("UPDATE responsible_play_deposit_reservations SET status='released',updated_at=? WHERE user_id=? AND status='reserved' AND expires_at<=? AND NOT EXISTS(SELECT 1 FROM deposit_orders d WHERE d.user_id=responsible_play_deposit_reservations.user_id AND d.request_key=responsible_play_deposit_reservations.request_key)").bind(at,userId,at),
  db.prepare(sql).bind(...binds),
 ]);
 const [saved,order,reservation]=await Promise.all([
  profile(db,userId),
  db.prepare('SELECT provider,amount_minor FROM deposit_orders WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<{provider:string;amount_minor:string|number|bigint}>(),
  db.prepare('SELECT provider,amount_minor,status,expires_at FROM responsible_play_deposit_reservations WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<{provider:string;amount_minor:string|number|bigint;status:string;expires_at:number}>(),
 ]);
 const blocked=async(code:string,message:string)=>{await audit(db,userId,'responsible_play_deposit_blocked',JSON.stringify({code,provider:input.provider}),at).run();throw new ResponsiblePlayError(409,code,message);};
 if(active(saved?.self_excluded_until,at))return blocked('SELF_EXCLUSION_ACTIVE','New deposits are paused during your self-exclusion. Play settings do not add a withdrawal block; actual submission follows payout-channel status. Login, records and support remain available.');
 if(active(saved?.cooling_off_until,at))return blocked('COOLING_OFF_ACTIVE','New deposits are paused during your cooling-off period. Play settings do not add a withdrawal block; actual submission follows payout-channel status. Login, records and support remain available.');
 if(order){if(order.provider!==input.provider||String(order.amount_minor)!==amount)return blocked('IDEMPOTENCY_CONFLICT','This deposit request key is already used for another order');return {reserved:false,idempotent:true};}
 if(!saved)return {reserved:false,idempotent:false};
 if(reservation&&reservation.status==='reserved'&&reservation.provider===input.provider&&String(reservation.amount_minor)===amount)return {reserved:true,idempotent:changes(transaction[2])!==1};
 if(reservation)return blocked('IDEMPOTENCY_CONFLICT','This deposit request key is already used for another order');
 const state=await getResponsiblePlay(db,userId,at),requested=bigint(amount);
 for(const period of ['daily','weekly','monthly'] as const){const remaining=state.remaining[`${period}Minor` as keyof typeof state.remaining];if(remaining!==null&&requested>bigint(remaining))return blocked(`${period.toUpperCase()}_DEPOSIT_LIMIT`,`${period[0].toUpperCase()+period.slice(1)} deposit limit reached`);}
 return blocked('DEPOSIT_LIMIT','Deposit limit reached');
}

export async function finalizeResponsiblePlayDeposit(db:D1Database,userId:string,provider:string,requestKey:string,at=epoch()){
 const order=await db.prepare('SELECT id,provider,amount_minor FROM deposit_orders WHERE user_id=? AND request_key=?').bind(userId,requestKey).first<{id:string;provider:string;amount_minor:string|number|bigint}>();
 if(order){await db.prepare("UPDATE responsible_play_deposit_reservations SET status='consumed',order_id=?,updated_at=? WHERE user_id=? AND request_key=? AND provider=? AND amount_minor=? AND status='reserved'").bind(order.id,at,userId,requestKey,provider,String(order.amount_minor)).run();return {consumed:true,orderId:order.id};}
 await db.prepare("UPDATE responsible_play_deposit_reservations SET status='released',updated_at=? WHERE user_id=? AND request_key=? AND provider=? AND status='reserved'").bind(at,userId,requestKey,provider).run();return {consumed:false,orderId:null};
}

export async function assertResponsiblePlayGameLaunch(db:D1Database,userId:string,at=epoch()){
 const saved=await profile(db,userId);let code:string|undefined,message:string|undefined;
 if(active(saved?.self_excluded_until,at)){code='SELF_EXCLUSION_ACTIVE';message='Game launch is paused during your self-exclusion. Play settings do not add a withdrawal block; actual submission follows payout-channel status. Login, records and support remain available.';}
 else if(active(saved?.cooling_off_until,at)){code='COOLING_OFF_ACTIVE';message='Game launch is paused during your cooling-off period. Play settings do not add a withdrawal block; actual submission follows payout-channel status. Login, records and support remain available.';}
 if(code){await audit(db,userId,'responsible_play_game_launch_blocked',JSON.stringify({code}),at).run();throw new ResponsiblePlayError(409,code,message!);}
 return true;
}

export async function responsiblePlayAdminStats(db:D1Database,at=epoch()){
 const profileStats=await db.prepare(`SELECT COUNT(*) profiles,
  SUM(CASE WHEN daily_limit_minor IS NOT NULL OR weekly_limit_minor IS NOT NULL OR monthly_limit_minor IS NOT NULL THEN 1 ELSE 0 END) members_with_limits,
  SUM(CASE WHEN cooling_off_until>? THEN 1 ELSE 0 END) active_cooling_off,
  SUM(CASE WHEN self_excluded_until>? THEN 1 ELSE 0 END) active_self_exclusion
  FROM responsible_play_profiles`).bind(at,at).first<any>();
 const auditStats=await db.prepare(`SELECT
  SUM(CASE WHEN event='responsible_play_deposit_blocked' THEN 1 ELSE 0 END) deposit_blocks,
  SUM(CASE WHEN event='responsible_play_game_launch_blocked' THEN 1 ELSE 0 END) game_launch_blocks
  FROM audit WHERE created_at>=?`).bind(at-30*DAY_SECONDS).first<any>();
 return {timezone:'Asia/Kuching',anonymous:true,memberDetailsExposed:false,ownerOverride:false,counts:{profiles:Number(profileStats?.profiles??0),membersWithLimits:Number(profileStats?.members_with_limits??0),activeCoolingOff:Number(profileStats?.active_cooling_off??0),activeSelfExclusion:Number(profileStats?.active_self_exclusion??0),blockedDepositsLast30Days:Number(auditStats?.deposit_blocks??0),blockedGameLaunchesLast30Days:Number(auditStats?.game_launch_blocks??0)}};
}

export async function suppressResponsiblePlayMarketing(db:D1Database,at=epoch()){
 const result=await db.prepare(`UPDATE marketing_deliveries SET status='failed',claim_token=NULL,locked_until=0,provider_error_code='responsible_play_suppressed',failed_at=COALESCE(failed_at,?),updated_at=?
  WHERE status IN ('queued','unknown') AND EXISTS(
   SELECT 1 FROM marketing_contacts c JOIN users u ON u.phone=c.phone JOIN responsible_play_profiles p ON p.user_id=u.id
   WHERE c.id=marketing_deliveries.contact_id AND (p.cooling_off_until>? OR p.self_excluded_until>?)
  )`).bind(at,at,at,at).run();
 const raw=(result as any)?.meta?.changes??(result as any)?.changes??0;return Number(raw)||0;
}

export function responsiblePlayMarketingAllowedSql(contactAlias='c',at?:number){
 if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(contactAlias))throw new Error('Invalid SQL alias');
 if(at!==undefined&&!Number.isSafeInteger(at))throw new Error('Invalid Responsible Play timestamp');
 const cutoff=at===undefined?'?':String(at);
 return `NOT EXISTS(SELECT 1 FROM users rp_u JOIN responsible_play_profiles rp ON rp.user_id=rp_u.id WHERE rp_u.phone=${contactAlias}.phone AND (rp.cooling_off_until>${cutoff} OR rp.self_excluded_until>${cutoff}))`;
}

export const responsiblePlayPolicy=Object.freeze({timezone:'Asia/Kuching',lessRestrictiveLimitDelaySeconds:LIMIT_CHANGE_DELAY_SECONDS,reservationSeconds:RESERVATION_SECONDS,nonTerminalDepositStatuses:[...NON_TERMINAL_DEPOSIT_STATUSES],withdrawalsNotBlockedByPlaySettings:true,withdrawalChannelReadiness:'separate',loginRemainsAvailable:true,supportRemainsAvailable:true,balanceFrozen:false,balanceForfeited:false});
