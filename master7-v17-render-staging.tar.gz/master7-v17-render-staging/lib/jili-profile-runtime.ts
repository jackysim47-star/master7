import {getGameProviderProfile} from './game-provider-registry.ts';
import {createJiliGameProviderAdapter} from './jili-provider-adapter.ts';
import type {JiliConfig} from './jili-transfer-protocol.ts';

const CUSTOMER_RETURN_ORIGIN='https://www.master7.best';
const DEFAULT_RETURN_ORIGINS=Object.freeze([CUSTOMER_RETURN_ORIGIN,'https://master7-v17-staging.onrender.com']);

function apiEndpoint(raw:unknown){
 if(typeof raw!=='string')return null;try{const u=new URL(raw);return u.protocol==='https:'&&!u.username&&!u.password&&!u.search&&!u.hash&&!u.port&&/^\/api1\/?$/.test(u.pathname)?u.href.replace(/\/$/,''):null;}catch{return null;}
}
function returnOrigins(raw:unknown){
 const values=raw===undefined?DEFAULT_RETURN_ORIGINS:raw;
 if(!Array.isArray(values)||values.length===0||values.length>20)return {allowed:[] as string[],customerAllowed:false};
 const allowed=values.map(value=>{if(typeof value!=='string')return null;try{const u=new URL(value);return u.origin===value&&u.protocol==='https:'&&!u.username&&!u.password&&!u.port?u.origin:null;}catch{return null;}});
 if(allowed.some(value=>value===null))return {allowed:[] as string[],customerAllowed:false};
 const exact=allowed as string[];return {allowed:exact,customerAllowed:exact.includes(CUSTOMER_RETURN_ORIGIN)};
}
export function jiliProfileRuntime(raw:string|undefined,profileId:string,userId:string,options:{fetchImpl?:typeof fetch;productionAccepted?:boolean}={}){
 if(!raw||Buffer.byteLength(raw)>32_768||!['jili_myr_1to1','jili_my1_1to100'].includes(profileId))return null;
 try{
  const root=JSON.parse(raw),v=root?.profiles?.[profileId],profile=getGameProviderProfile(profileId);
  if(!profile||!v||!['closed','qa','production'].includes(v.mode)||v.environment!=='production'||typeof v.recoveryEnabled!=='boolean')return null;
  const cfg=v.connection as JiliConfig,endpoint=apiEndpoint(cfg?.baseUrl),approved=Array.isArray(v.approvedApiEndpoints)?v.approvedApiEndpoints.map(apiEndpoint):[];
  if(!cfg||cfg.profile!==profileId||!endpoint||approved.length===0||approved.length>20||approved.some((x:unknown)=>x===null)||!approved.includes(endpoint)||!Array.isArray(v.qaMemberIds)||v.qaMemberIds.length>50||v.qaMemberIds.some((x:unknown)=>typeof x!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(x)))return null;
  // A secondary legacy manual does not confirm this merchant's amount units,
  // issued-token invalidation or late-round finality. Keep those explicit.
  const contractVerified=v.merchantContractVerified===true&&typeof v.merchantContractEvidenceSha256==='string'&&/^[a-f0-9]{64}$/.test(v.merchantContractEvidenceSha256);
  const closureVerified=contractVerified&&v.sessionClosureVerified===true&&v.allIssuedLaunchesInvalidated===true&&v.lateResultsFinal===true;
  const recoveryEnabled=v.recoveryEnabled===true&&closureVerified;
  // The wallet transfer precedes LoginWithoutRedirect. Refuse a new launch
  // before reserving or submitting funds unless the exact customer return
  // origin used by backend.ts is allowlisted. Keep the adapter available for
  // recovery when only this launch-only setting is malformed.
  const returns=returnOrigins(v.allowedReturnOrigins);
  const launchAuthorized=recoveryEnabled&&returns.customerAllowed&&cfg.launchOrigins?.length>0&&(v.mode==='qa'?v.qaMemberIds.includes(userId):v.mode==='production'&&options.productionAccepted===true);
  const adapter=createJiliGameProviderAdapter(cfg,{fetchImpl:options.fetchImpl??fetch,allowedReturnOrigins:returns.allowed,playerCreationEnabled:launchAuthorized,depositEnabled:launchAuthorized,launchEnabled:launchAuthorized,recoveryEnabled,merchantContractVerified:contractVerified,sessionClosureVerified:closureVerified});
  return {profile,adapter,launchAuthorized:!!launchAuthorized,recoveryEnabled,mode:v.mode as 'closed'|'qa'|'production',environment:'production' as const};
 }catch{return null;}
}
