import {getGameProviderProfile} from './game-provider-registry.ts';
import {createJiliGameProviderAdapter} from './jili-provider-adapter.ts';
import type {JiliConfig} from './jili-transfer-protocol.ts';

function apiEndpoint(raw:unknown){
 if(typeof raw!=='string')return null;try{const u=new URL(raw);return u.protocol==='https:'&&!u.username&&!u.password&&!u.search&&!u.hash&&!u.port&&/^\/api1\/?$/.test(u.pathname)?u.href.replace(/\/$/,''):null;}catch{return null;}
}
export function jiliProfileRuntime(raw:string|undefined,profileId:string,userId:string,options:{fetchImpl?:typeof fetch;productionAccepted?:boolean}={}){
 if(!raw||Buffer.byteLength(raw)>32_768||!['jili_myr_1to1','jili_my1_1to100'].includes(profileId))return null;
 try{
  const root=JSON.parse(raw),v=root?.profiles?.[profileId],profile=getGameProviderProfile(profileId);
  if(!profile||!v||!['closed','qa','production'].includes(v.mode)||v.environment!=='production'||typeof v.recoveryEnabled!=='boolean')return null;
  const cfg=v.connection as JiliConfig,endpoint=apiEndpoint(cfg?.baseUrl),approved=Array.isArray(v.approvedApiEndpoints)?v.approvedApiEndpoints.map(apiEndpoint):[];
  if(!cfg||cfg.profile!==profileId||!endpoint||approved.length===0||approved.length>20||approved.some((x:unknown)=>x===null)||!approved.includes(endpoint)||!Array.isArray(v.qaMemberIds)||v.qaMemberIds.length>50||v.qaMemberIds.some((x:unknown)=>typeof x!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(x)))return null;
  // A secondary legacy manual does not confirm this merchant's amount units,
  // issued-token invalidation or late-round finality. Keep those explicit.
  const contractVerified=v.merchantContractVerified===true&&typeof v.merchantContractEvidenceSha256==='string'&&/^[a-f0-9]{64}$/.test(v.merchantContractEvidenceSha256);
  const closureVerified=contractVerified&&v.sessionClosureVerified===true&&v.allIssuedLaunchesInvalidated===true&&v.lateResultsFinal===true;
  const recoveryEnabled=v.recoveryEnabled===true&&closureVerified;
  const launchAuthorized=recoveryEnabled&&cfg.launchOrigins?.length>0&&(v.mode==='qa'?v.qaMemberIds.includes(userId):v.mode==='production'&&options.productionAccepted===true);
  const adapter=createJiliGameProviderAdapter(cfg,{fetchImpl:options.fetchImpl??fetch,allowedReturnOrigins:v.allowedReturnOrigins??['https://www.master7.best','https://master7-v17-staging.onrender.com'],playerCreationEnabled:launchAuthorized,depositEnabled:launchAuthorized,launchEnabled:launchAuthorized,recoveryEnabled,merchantContractVerified:contractVerified,sessionClosureVerified:closureVerified});
  return {profile,adapter,launchAuthorized:!!launchAuthorized,recoveryEnabled,mode:v.mode as 'closed'|'qa'|'production',environment:'production' as const};
 }catch{return null;}
}
