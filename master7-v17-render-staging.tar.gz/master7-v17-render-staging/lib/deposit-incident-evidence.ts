import {createHash,timingSafeEqual} from 'node:crypto';
import {definitivePaymentRejectionFacts} from './payment-diagnostics.ts';

type Row=Record<string,unknown>;
type Client={query(sql:string,values?:unknown[]):Promise<{rows:Row[]}>;release(destroy?:boolean):unknown};
type Pool={connect():Promise<Client>};
const LIMIT=1000,AUDIT_LIMIT=10000;
const paymentEvents=['payment_order_diagnostic','deposit_credited','deposit_callback_review','vpay_callback_authenticated','gspay_callback_received','1mpay_callback_verified','1mpay_deposit_credited','1mpay_query_conflict_review','1mpay_recovery_review','1mpay_late_success_review','gspay_deposit_credited','gspay_late_success_review','gspay_partial_ledger_review','gspay_paid_status_conflict_review','gspay_failed_partial_ledger_review','gspay_paid_binding_conflict_review','gspay_member_binding_review','manual_bank_deposit_approved','manual_bank_deposit_rejected','manual_bank_deposit_review','manual_bank_deposit_submitted','deposit_ledger_review','deposit_member_binding_review','deposit_query_binding_review','vpay_deposit_failed','vpay_deposit_reversed_review','vpay_deposit_risk_control_review','vpay_deposit_state_review'];
const digest=(value:string)=>createHash('sha256').update(value).digest('hex');
const integer=(value:unknown)=>{const text=String(value);if(!/^-?\d+$/.test(text))throw Error('Invalid incident evidence');return BigInt(text).toString();};
const at=(value:unknown)=>{const n=Number(integer(value));if(!Number.isSafeInteger(n)||n<0)throw Error('Invalid incident evidence');return n;};
const opaque=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(value)?value:null;
function object(value:unknown):Row|null{if(typeof value!=='string'||value.length>8192)return null;try{const x=JSON.parse(value);return x&&typeof x==='object'&&!Array.isArray(x)?x:null;}catch{return null;}}

export function authorizeDepositIncidentRead(authorization:string|null,hash:unknown,expiresAt:unknown,now=Math.floor(Date.now()/1000)){
 if(typeof hash!=='string'||!/^[a-f0-9]{64}$/.test(hash)||typeof expiresAt!=='number'||!Number.isSafeInteger(expiresAt)||expiresAt<=now||expiresAt>now+3600)return false;
 const token=authorization?.startsWith('Bearer ')?authorization.slice(7):'';
 return /^[a-f0-9]{64}$/.test(token)&&timingSafeEqual(Buffer.from(digest(token),'hex'),Buffer.from(hash,'hex'));
}

/** Fixed SELECTs only, one database snapshot, no provider queries or repairs.
 * The transaction is READ ONLY in PostgreSQL, independently of application code.
 * The pool is the same source used by the deployed application, not a new URL. */
export async function readDepositIncidentSnapshot(pool:Pool){
 const client=await pool.connect();let result:unknown;const errors:unknown[]=[];
 try{
  await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
  await client.query("SET LOCAL statement_timeout = '5s'");
  const identity=(await client.query('SELECT current_database() AS database_name,EXTRACT(EPOCH FROM transaction_timestamp())::bigint AS observed_at')).rows[0];
  if(!identity||typeof identity.database_name!=='string')throw Error('Incident snapshot identity unavailable');
  const totals=(await client.query('SELECT provider,status,currency,COUNT(*)::text AS orders,CAST(SUM(amount_minor) AS TEXT) AS amount_minor FROM deposit_orders GROUP BY provider,status,currency ORDER BY provider,status,currency')).rows;
  const candidates=(await client.query('SELECT id,user_id,provider,CAST(amount_minor AS TEXT) AS amount_minor,currency,status,provider_trade_no,checkout_url,created_at,updated_at FROM deposit_orders ORDER BY created_at,id LIMIT $1',[LIMIT+1])).rows;
  const orders=candidates.slice(0,LIMIT),ids=orders.map(x=>String(x.id)),users=[...new Set(orders.map(x=>String(x.user_id)))];
  const ledger=ids.length?(await client.query('SELECT id,order_id,user_id,account_code,CAST(amount_minor AS TEXT) AS amount_minor,currency,created_at FROM wallet_ledger WHERE order_id=ANY($1::text[]) ORDER BY order_id,account_code,id',[ids])).rows:[];
  const audits=ids.length?(await client.query('SELECT id,user_id,event,target,created_at FROM audit WHERE event=ANY($1::text[]) AND (target=ANY($2::text[]) OR user_id=ANY($3::text[])) ORDER BY created_at DESC,id DESC LIMIT $4',[paymentEvents,ids,users,AUDIT_LIMIT+1])).rows:[];
  const manual=ids.length?(await client.query('SELECT deposit_order_id,(reviewed_by IS NOT NULL) AS review_recorded,created_at,updated_at FROM manual_deposit_requests WHERE deposit_order_id=ANY($1::text[]) ORDER BY deposit_order_id',[ids])).rows:[];
  const events=new Map<string,Row[]>(),diagnostics=new Map<string,Row[]>();
  for(const a of audits.slice(0,AUDIT_LIMIT)){
   const detail=object(a.target),orderId=detail?.orderId??a.target;if(typeof orderId!=='string'||!ids.includes(orderId))continue;
   const order=orders.find(o=>o.id===orderId);if(!order||(order.user_id!==a.user_id&&!String(a.event).startsWith('manual_bank_deposit_')))continue;
   const event={id:String(a.id),event:String(a.event),createdAt:at(a.created_at)};
   events.set(orderId,[...(events.get(orderId)??[]),event]);
   if(a.event==='payment_order_diagnostic'&&detail&&detail.provider===order.provider){
    const safe:Row={...event};
    if(typeof detail.kind==='string'&&/^[A-Z_]{1,50}$/.test(detail.kind))safe.kind=detail.kind;
    for(const key of ['httpStatus','upstreamStatus','providerCode'])if(typeof detail[key]==='number'&&Number.isSafeInteger(detail[key])&&Math.abs(detail[key] as number)<=999999)safe[key]=detail[key];
    // Retain presence, never signing material, raw messages or checkout tokens.
    safe.providerReferencePresent=!!detail.providerTradeNo;safe.checkoutHostPresent=!!detail.checkoutHost;
    safe.definitiveOrderRejection=definitivePaymentRejectionFacts(detail);
    diagnostics.set(orderId,[...(diagnostics.get(orderId)??[]),safe]);
   }
  }
  const items=orders.map(o=>{
   const orderId=String(o.id),amount=integer(o.amount_minor),legs=ledger.filter(l=>l.order_id===o.id),traces=events.get(orderId)??[],facts=diagnostics.get(orderId)??[];
   const balanced=legs.length===2&&legs.every(l=>l.user_id===o.user_id&&l.currency===o.currency)&&legs.some(l=>l.account_code==='member'&&integer(l.amount_minor)===amount)&&legs.some(l=>l.account_code==='provider_clearing'&&BigInt(integer(l.amount_minor))===-BigInt(amount));
   const verifiedCredit=o.status==='credited'&&balanced;
   const rejection=facts[0]?.definitiveOrderRejection===true&&!o.provider_trade_no&&!o.checkout_url&&!legs.length;
   const callbackVerified=o.provider==='1mpay'&&traces.some(a=>a.event==='1mpay_callback_verified'),callbackAuthenticated=(o.provider==='vpay'&&traces.some(a=>a.event==='vpay_callback_authenticated'))||(o.provider==='gspay'&&traces.some(a=>a.event==='gspay_callback_received')),callbackReview=traces.some(a=>a.event==='deposit_callback_review');
   let checkoutHost:string|null=null;try{const u=new URL(String(o.checkout_url));if(u.protocol==='https:'&&!u.username&&!u.password)checkoutHost=u.hostname;}catch{}
   const manualReview=manual.find(m=>m.deposit_order_id===o.id);
   return {orderId,provider:String(o.provider),memberReference:digest('MASTER7:incident-member:'+String(o.user_id)).slice(0,20),amountMinor:amount,currency:String(o.currency),status:String(o.status),createdAt:at(o.created_at),updatedAt:at(o.updated_at),providerTransactionId:opaque(o.provider_trade_no),providerReferencePresent:!!o.provider_trade_no,checkoutHost,
    ledger:{rows:legs.map(l=>({id:String(l.id),accountCode:String(l.account_code),amountMinor:integer(l.amount_minor),currency:String(l.currency),memberMatches:l.user_id===o.user_id,createdAt:at(l.created_at)})),balanced,verifiedCredit},
    auditEvents:traces,diagnostics:facts,callbackEvidence:callbackVerified?'signed_callback_event_present':callbackAuthenticated?'authenticated_callback_event_present':callbackReview?'callback_review_event_present':'no_dedicated_callback_evidence',manualReview:manualReview?{reviewRecorded:manualReview.review_recorded===true,createdAt:at(manualReview.created_at),updatedAt:at(manualReview.updated_at)}:null,
    finding:verifiedCredit?'wallet_credit_recorded_frontend_not_verified':balanced?'wallet_ledger_present_order_status_conflict':legs.length&&!balanced?'wallet_ledger_mismatch':o.status==='credited'&&!balanced?'credited_status_without_balanced_ledger':rejection?'B_provider_order_rejected':callbackVerified?'callback_verified_wallet_credit_not_verified':callbackAuthenticated?'callback_authenticated_wallet_credit_not_verified':callbackReview?'callback_review_wallet_credit_not_verified':'after_order_payment_and_callback_not_verified',
    providerPaymentVerified:false,frontendBalanceVerified:false};
  });
  result={readOnly:true,scope:'stored_deposit_incident_evidence',readConsistency:'transaction_snapshot',databaseName:identity.database_name,observedAt:at(identity.observed_at),limits:{orders:LIMIT,auditCandidates:AUDIT_LIMIT},coverage:{ordersTruncated:candidates.length>LIMIT,auditCandidatesTruncated:audits.length>AUDIT_LIMIT},summary:totals.map(r=>({provider:String(r.provider),status:String(r.status),currency:String(r.currency),orders:at(r.orders),amountMinor:integer(r.amount_minor)})),items,providerQueriesExecuted:false,repairsExecuted:false,limitations:['Legacy credit events do not distinguish callback from recovery/query.','An authenticated callback receipt proves delivery and order binding, not provider payment success.','No dedicated callback evidence does not prove no callback was received.','Provider payment and frontend balance require independent evidence.','Rows in another historical database are outside this snapshot.']};
 }catch(error){errors.push(error);}
 finally{try{await client.query('ROLLBACK');}catch(error){errors.push(error);}try{await client.release(errors.length>0);}catch(error){errors.push(error);}}
 if(errors.length===1)throw errors[0];if(errors.length>1)throw new AggregateError(errors,'Incident snapshot failed');
 if(result===undefined)throw Error('Incident snapshot incomplete');return result;
}
