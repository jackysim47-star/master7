import {createHash} from 'node:crypto';
import {gameAmountToWalletMinor,walletMinorToGameAmount} from './game-unit-conversion.ts';
import type {
 GameProviderAdapter,GameProviderContext,GameProviderGame,GameProviderTransferInput,
 GameProviderTransferResult,GameProviderWager,
} from './game-provider-adapter.ts';

export type MetaGamingProfile='metagaming_normal_myr'|'metagaming_free_myr';
export type MetaGamingAccount='normal'|'free';
export type MetaGamingGatewayConfig={
 profile:MetaGamingProfile;
 account:MetaGamingAccount;
 baseUrl:string;
 currency:'MYR';
 playerToken:string;
 walletToken:string;
 recoveryToken:string;
 reportToken:string;
 launchOrigins:readonly string[];
};
export type MetaGamingAdapterOptions={
 fetchImpl:typeof fetch;
 allowedReturnOrigins:readonly string[];
 playerCreationEnabled?:boolean;
 balanceEnabled?:boolean;
 depositEnabled?:boolean;
 withdrawalEnabled?:boolean;
 launchEnabled?:boolean;
 transferStatusEnabled?:boolean;
 recoveryEnabled?:boolean;
 reportEnabled?:boolean;
 merchantContractVerified?:boolean;
 sessionClosureVerified?:boolean;
};

export class MetaGamingAdapterError extends Error{
 readonly code:string;
 constructor(code:string){super(code);this.name='MetaGamingAdapterError';this.code=code;}
}
const fail=(code:string):never=>{throw new MetaGamingAdapterError(code);};
const profileAccount=(profile:MetaGamingProfile):MetaGamingAccount=>profile==='metagaming_normal_myr'?'normal':'free';
const cleanText=(value:unknown,pattern:RegExp,code:string)=>typeof value==='string'&&pattern.test(value)?value:fail(code);
const isObject=(value:unknown):value is Record<string,unknown>=>!!value&&typeof value==='object'&&!Array.isArray(value);
const token=(value:unknown)=>typeof value==='string'&&Buffer.byteLength(value,'utf8')>=32&&Buffer.byteLength(value,'utf8')<=1024&&!/[\u0000-\u0020\u007f-\u009f]/u.test(value)?value:fail('META_TOKEN_INVALID');
function exactOrigin(raw:unknown,code:string){
 if(typeof raw!=='string')return fail(code);try{const u=new URL(raw);if(u.origin!==raw||u.protocol!=='https:'||u.username||u.password||u.port)return fail(code);return u.origin;}catch{return fail(code);}
}
function gatewayOrigin(raw:unknown){return exactOrigin(raw,'META_GATEWAY_ORIGIN_INVALID');}
function member(value:unknown){if(typeof value!=='string'||value.length<1||value.length>200||/[\u0000-\u001f\u007f]/u.test(value))return fail('META_MEMBER_INVALID');return value;}
function boundHash(parts:readonly string[],prefix:string,max=50){return `${prefix}${createHash('sha256').update(JSON.stringify(parts)).digest('hex').slice(0,max-prefix.length)}`;}
export function metaGamingPlayerId(profile:MetaGamingProfile,userId:string){return boundHash([profile,member(userId)],profile==='metagaming_normal_myr'?'m7mn_':'m7mf_');}
export function metaGamingReferenceId(profile:MetaGamingProfile,platformTransactionId:string,direction:'deposit'|'withdrawal'){
 cleanText(platformTransactionId,/^[A-Za-z0-9_.:-]{1,200}$/,'META_TRANSACTION_ID_INVALID');
 return boundHash([profile,platformTransactionId,direction],'m7mt_');
}
function readJson(text:string){if(Buffer.byteLength(text,'utf8')>2*1024*1024)return fail('META_GATEWAY_RESPONSE_INVALID');try{const value=JSON.parse(text);if(!isObject(value))return fail('META_GATEWAY_RESPONSE_INVALID');return value;}catch{return fail('META_GATEWAY_RESPONSE_INVALID');}}
function resultEnvelope(value:Record<string,unknown>,profile:MetaGamingProfile,account:MetaGamingAccount,operation:string){
 if(value.provider!=='metagaming'||value.profileId!==profile||value.account!==account||value.operation!==operation||!isObject(value.result))return fail('META_GATEWAY_BINDING_INVALID');
 const result=value.result;if(result.ok!==true||result.status!==200)return fail('META_PROVIDER_REJECTED');return result;
}
function cents(raw:unknown){
 if((typeof raw!=='string'&&typeof raw!=='number')||raw==='')return fail('META_AMOUNT_INVALID');
 let converted;try{converted=gameAmountToWalletMinor(String(raw),1);}catch{return fail('META_AMOUNT_INVALID');}
 if(converted.residual)return fail('META_AMOUNT_PRECISION_REVIEW');return converted;
}
function isoUtc(raw:unknown){
 if(typeof raw!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,7})?Z$/.test(raw))return fail('META_REPORT_TIME_INVALID');
 const value=Date.parse(raw);if(!Number.isFinite(value))return fail('META_REPORT_TIME_INVALID');return value;
}
function ipv4(raw:unknown){
 if(typeof raw!=='string')return fail('META_IP_INVALID');
 const parts=raw.split('.');
 if(parts.length!==4||!parts.every(part=>/^(?:0|[1-9]\d{0,2})$/.test(part)&&Number.isInteger(Number(part))&&Number(part)>=0&&Number(part)<=255))return fail('META_IP_INVALID');
 return raw;
}

/** Server-side gateway adapter only. Constructing it does not enable a profile,
 * submit money, establish session finality, or record supplier acceptance. */
export function createMetaGamingProviderAdapter(config:MetaGamingGatewayConfig,options:MetaGamingAdapterOptions):GameProviderAdapter&{readonly profileId:MetaGamingProfile;readonly account:MetaGamingAccount}{
 if(!config||!options||!Array.isArray(config.launchOrigins)||!Array.isArray(options.allowedReturnOrigins))return fail('META_CONFIGURATION_INVALID');
 const profileId=config.profile,account=profileAccount(profileId);
 if(config.account!==account||config.currency!=='MYR')return fail('META_PROFILE_ACCOUNT_MISMATCH');
 const baseUrl=gatewayOrigin(config.baseUrl),tokens=[token(config.playerToken),token(config.walletToken),token(config.recoveryToken),token(config.reportToken)];
 if(new Set(tokens).size!==tokens.length)return fail('META_TOKEN_ALIAS');
 const launchOrigins=new Set(config.launchOrigins.map(value=>exactOrigin(value,'META_LAUNCH_ORIGIN_INVALID'))),returns=new Set(options.allowedReturnOrigins.map(value=>exactOrigin(value,'META_RETURN_ORIGIN_INVALID')));
 const flags=Object.freeze({
  contract:options.merchantContractVerified===true,closure:options.sessionClosureVerified===true,
  player:options.playerCreationEnabled===true,balance:options.balanceEnabled===true,
  deposit:options.depositEnabled===true,withdrawal:options.withdrawalEnabled===true,
  launch:options.launchEnabled===true,status:options.transferStatusEnabled===true,
  recovery:options.recoveryEnabled===true,report:options.reportEnabled===true,
 });
 const transport=options.fetchImpl;
 function context(c:GameProviderContext){
  const p=c?.profile,expectedClass=account==='free'?'free_credit':'cash';
  if(!p||p.profileId!==profileId||p.providerId!=='metagaming'||p.adapterKey!=='metagaming'||p.walletMode!=='transfer'||p.currency!=='MYR'||p.unitScale!==1||p.balanceClass!==expectedClass||p.playerNamespace!==profileId||p.ledgerNamespace!==profileId)return fail('META_PROFILE_MISMATCH');
 }
 function boundPlayer(userId:unknown,supplied:unknown){const expected=metaGamingPlayerId(profileId,member(userId));if(supplied!==expected)return fail('META_PLAYER_MISMATCH');return expected;}
 function cashGate(enabled:boolean,code:string){if(!flags.contract||!flags.closure)return fail('META_MERCHANT_CONTRACT_UNVERIFIED');if(!enabled)return fail(code);}
 async function call(method:string,credential:string,fields:Record<string,unknown>={}){
  const response=await transport(`${baseUrl}/platform/metagaming/${method}`,{method:'POST',redirect:'error',headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${credential}`},body:JSON.stringify({profileId,account,...fields})});
  const raw=await response.text(),value=readJson(raw);if(!response.ok)return fail(response.status===503?'META_CAPABILITY_DISABLED':response.status===401?'META_GATEWAY_UNAUTHORIZED':'META_GATEWAY_REQUEST_FAILED');return resultEnvelope(value,profileId,account,method);
 }
 async function catalogue():Promise<readonly GameProviderGame[]>{
  const response=await transport(`${baseUrl}/providers/metagaming/games?account=${account}`,{method:'GET',redirect:'error',headers:{Accept:'application/json'}}),value=readJson(await response.text());
  if(!response.ok||value.provider!=='metagaming'||value.account!==account||value.currency!=='MYR'||!Array.isArray(value.games)||value.games.length>2000)return fail('META_CATALOGUE_UNAVAILABLE');
  const seen=new Set<string>();return value.games.map(row=>{if(!isObject(row))return fail('META_CATALOGUE_INVALID');const id=cleanText(row.gameCode,/^[^\u0000-\u001f\u007f]{1,50}$/u,'META_CATALOGUE_INVALID'),name=cleanText(row.name,/^[^\u0000-\u001f\u007f]{1,200}$/u,'META_CATALOGUE_INVALID');if(seen.has(id))return fail('META_CATALOGUE_INVALID');seen.add(id);return{providerGameId:id,name,category:String(row.gameType??''),maintenance:row.maintenance!==false};});
 }
 function transferInput(input:GameProviderTransferInput,direction:'deposit'|'withdrawal'){
  if(!input||input.currency!=='MYR'||typeof input.amountMinor!=='string'||!/^[1-9]\d{0,15}$/.test(input.amountMinor))return fail('META_TRANSFER_INPUT_INVALID');
  return{playerId:boundPlayer(input.userId,input.providerPlayerId),referenceId:metaGamingReferenceId(profileId,input.platformTransactionId,direction),amount:walletMinorToGameAmount(input.amountMinor,1),amountMinor:input.amountMinor};
 }
 async function transfer(c:GameProviderContext,input:GameProviderTransferInput,direction:'deposit'|'withdrawal'):Promise<GameProviderTransferResult>{
  context(c);const value=transferInput(input,direction);cashGate(direction==='deposit'?flags.deposit:flags.withdrawal,`META_${direction.toUpperCase()}_DISABLED`);
  await call(direction==='deposit'?'deposit':'withdraw',tokens[1],{playerId:value.playerId,amount:value.amount,referenceId:value.referenceId});
  // Deposit/Withdraw success has no transaction identifier. Only the signed
  // CheckTransferStatus response may confirm the original reference and amount.
  return{state:'unknown',errorCode:'META_TRANSFER_STATUS_REQUIRED',requiresLedgerReconciliation:true};
 }
 const adapter:GameProviderAdapter&{readonly profileId:MetaGamingProfile;readonly account:MetaGamingAccount}={
  key:'metagaming',profileId,account,executable:true,
  transferContractFingerprint:createHash('sha256').update(JSON.stringify([profileId,account,baseUrl,'MYR',1])).digest('hex'),
  async listGames(c){context(c);return catalogue();},
  async createOrVerifyPlayer(c,input){context(c);cashGate(flags.player,'META_PLAYER_SUBMISSION_DISABLED');const playerId=metaGamingPlayerId(profileId,input.userId);await call('player',tokens[0],{playerId});return{providerPlayerId:playerId,created:false};},
  depositToGame:(c,input)=>transfer(c,input,'deposit'),
  withdrawFromGame:(c,input)=>transfer(c,input,'withdrawal'),
  async queryBalance(c,input){context(c);cashGate(flags.balance,'META_BALANCE_DISABLED');const playerId=boundPlayer(input.userId,input.providerPlayerId),result=await call('balance',tokens[0],{playerId});if(result.currency!=='MYR')return fail('META_CURRENCY_MISMATCH');const value=cents(result.currentBalance);return{...value,currency:'MYR'};},
  async launchGame(c,input){
   context(c);cashGate(flags.launch,'META_LAUNCH_DISABLED');const playerId=boundPlayer(input.userId,input.providerPlayerId);
   if(input.language!=='en')return fail('META_LANGUAGE_UNCONFIRMED');let returnUrl:URL;try{returnUrl=new URL(input.returnUrl);}catch{return fail('META_RETURN_URL_INVALID');}
   if(!returns.has(returnUrl.origin)||returnUrl.protocol!=='https:'||returnUrl.username||returnUrl.password||returnUrl.hash||returnUrl.href.length>100)return fail('META_RETURN_URL_INVALID');
   const result=await call('launch',tokens[0],{playerId,gameCode:cleanText(input.providerGameId,/^[^\u0000-\u001f\u007f]{1,50}$/u,'META_GAME_INVALID'),ip:ipv4(input.ip),language:'en',returnUrl:returnUrl.href,demo:false});
   if(typeof result.url!=='string'||result.url.length>2000)return fail('META_LAUNCH_URL_INVALID');let url:URL;try{url=new URL(result.url);}catch{return fail('META_LAUNCH_URL_INVALID');}if(url.protocol!=='https:'||url.username||url.password||url.hash||!launchOrigins.has(url.origin))return fail('META_LAUNCH_URL_INVALID');return{launchUrl:url.href};
  },
  async queryTransfer(c,input){
   context(c);const direction=input?.direction;if(direction!=='deposit'&&direction!=='withdrawal')return fail('META_TRANSFER_INPUT_INVALID');const value=transferInput(input,direction);cashGate(flags.status,'META_TRANSFER_STATUS_DISABLED');
   const result=await call('transfer-status',tokens[1],{playerId:value.playerId,referenceId:value.referenceId,transferType:direction}),transaction=result.transaction;if(!isObject(transaction))return{state:'unknown',errorCode:'META_TRANSFER_STATUS_UNCONFIRMED',requiresLedgerReconciliation:true};
   const amount=cents(transaction.amount),providerTransactionId=String(transaction.transactionId??'');if(amount.amountMinor!==value.amountMinor||amount.residual||!/^[1-9]\d{0,30}$/.test(providerTransactionId)||(input.providerTransactionId!==undefined&&input.providerTransactionId!==providerTransactionId))return{state:'unknown',errorCode:'META_TRANSFER_RECEIPT_MISMATCH',requiresLedgerReconciliation:true};
   return{state:'confirmed',providerTransactionId,requiresLedgerReconciliation:true};
  },
  async closeGame(c,input){
   context(c);const playerId=boundPlayer(input.userId,input.providerPlayerId);if(!flags.closure)return fail('META_SESSION_CLOSURE_UNVERIFIED');
   if(input.requestClosure===true){if(!flags.recovery)return fail('META_RECOVERY_DISABLED');try{await call('kick',tokens[2],{playerId});}catch{return{state:'unknown'};}}
   try{const result=await call('unfinished-rounds',tokens[2],{playerId}),rounds=result.rounds;if(!Array.isArray(rounds))return{state:'unknown'};return rounds.length?{state:'playing'}:{state:'closed',evidenceCode:input.requestClosure?'META_VERIFIED_KICK_NO_UNFINISHED_ROUNDS':'META_NO_UNFINISHED_ROUNDS'};}catch{return{state:'unknown'};}
  },
  async fetchWagers(c,cursor){
   context(c);if(!flags.report)return fail('META_REPORT_DISABLED');if(!cursor||cursor.cursor!==undefined||!Number.isSafeInteger(cursor.from)||!Number.isSafeInteger(cursor.to)||cursor.from<0||cursor.to<=cursor.from)return fail('META_REPORT_WINDOW_INVALID');
   const result=await call('reports',tokens[3]),logs=result.logs;if(!Array.isArray(logs)||logs.length>1000)return fail('META_REPORT_INVALID');const seen=new Set<string>();
   const items:GameProviderWager[]=logs.map(row=>{if(!isObject(row))return fail('META_REPORT_INVALID');const id=String(row.transactionId??'');if(!/^[1-9]\d{0,30}$/.test(id)||seen.has(id))return fail('META_REPORT_INVALID');seen.add(id);const playerId=cleanText(row.playerId,account==='normal'?/^m7mn_[a-f0-9]{45}$/:/^m7mf_[a-f0-9]{45}$/,'META_REPORT_PROFILE_MISMATCH'),bet=cents(row.turnover),win=cents(row.payout),settledAt=isoUtc(row.transactionDateTime);return{providerRoundId:null,providerBetId:id,providerPlayerId:playerId,providerGameId:cleanText(row.gameCode,/^[^\u0000-\u001f\u007f]{1,50}$/u,'META_REPORT_INVALID'),betMinor:bet.amountMinor,winMinor:win.amountMinor,currency:'MYR',settledAt,sourceDetails:Object.freeze({validTurnover:String(row.validTurnover??''),winLose:String(row.winLose??''),transactionType:String(row.transactionType??''),gameType:String(row.gameType??''),gameName:String(row.gameName??''),flagging:'not_performed'})};});
   // PullLog has no time window and rows must only be flagged after durable
   // ingestion. This adapter never auto-flags and never reports page coverage.
   return{items,complete:false};
  },
  async handleCallback(c){context(c);return{accepted:false,duplicate:false,responseBody:'UNSUPPORTED_TRANSFER_CALLBACK',responseStatus:403};},
 };
 return Object.freeze(adapter);
}
