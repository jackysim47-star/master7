// Parsing and matching only: no provider calls, no authentication and no wallet
// writes. Callers must independently authenticate the HTTPS response, bind the
// provider code to the correct merchant profile, and apply a durable idempotent
// ledger transaction before treating a transfer as settled.
export class GodeeTransferRecordError extends Error {
 constructor(){super('GODEE_TRANSFER_UNCONFIRMED');}
}
const fail=():never=>{throw new GodeeTransferRecordError();};
const safeText=(value:unknown,max:number):value is string=>typeof value==='string'&&value.length>0&&value.length<=max&&value===value.trim()&&!/[\u0000-\u001f\u007f]/.test(value);
function positiveMinor(value:unknown):string{
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,11})(?:\.\d{1,2})?$/.test(value))return fail();
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 if(minor<=0n)return fail();return minor.toString();
}
type ExpectedTransfer={providerCode:string;username:string;transferId:string;amount:string;currency:'MYR';action:'IN'|'OUT'};

export function matchGodeeTransferRecord(response:unknown,expected:ExpectedTransfer){
 if(!expected||!safeText(expected.providerCode,128)||!safeText(expected.transferId,128)||!safeText(expected.username,64)||!/^[A-Za-z0-9]{5,64}$/.test(expected.username)||expected.currency!=='MYR'||!['IN','OUT'].includes(expected.action))return fail();
 const amountMinor=positiveMinor(expected.amount);
 if(!response||typeof response!=='object'||Array.isArray(response))return fail();
 const envelope=response as Record<string,unknown>,raw=envelope.data;
 if(envelope.status!=='success'||!raw||typeof raw!=='object'||Array.isArray(raw))return fail();
 const record=raw as Record<string,unknown>;
 if(record.provider!==expected.providerCode||record.username!==expected.username||record.transfercode!==expected.transferId||record.currency!==expected.currency||typeof record.actions!=='string'||record.actions.toUpperCase()!==expected.action||positiveMinor(record.amount)!==amountMinor)return fail();
 // This is only a match against fields supplied by the provider; it does not
 // prove the transport, merchant binding, transfer finality, or wallet credit.
 return {amountMinor,currency:'MYR' as const,action:expected.action,matched:true,settlementVerified:false as const};
}
