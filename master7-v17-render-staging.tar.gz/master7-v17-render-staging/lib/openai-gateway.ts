/**
 * One server-side OpenAI-compatible gateway for non-transactional AI tasks.
 *
 * This module deliberately has no tools, provider adapters or database write
 * helpers. It can generate text for an allow-listed task, but it cannot
 * approve deposits, submit payouts, launch games or move wallet funds.
 */

export const OPENAI_TASKS = Object.freeze([
  'support_reply',
  'operations_summary',
  'handover_summary',
  'translation',
] as const);

export type OpenAiTask = (typeof OPENAI_TASKS)[number];

export type OpenAiGatewayConfig = Readonly<{
  enabled?: string;
  apiBaseUrl?: string;
  apiKey?: string;
  model?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}>;

export type OpenAiGatewayRequest = Readonly<{
  task: OpenAiTask;
  systemPrompt: string;
  userPrompt: string;
  maxTokens?: number;
  timeoutMs?: number;
}>;

export type OpenAiGatewayResult = Readonly<{
  task: OpenAiTask;
  text: string | null;
  providerAttempted: boolean;
  reason?: 'not_ready' | 'invalid_request' | 'provider_error' | 'invalid_response';
}>;

const MAX_USER_INPUT = 2600;
const MAX_SYSTEM_INPUT = 4000;
const MAX_RESPONSE_BYTES = 65_536;

function externalBase(value?: string) {
  try {
    const url = new URL(value ?? ''), hostname = url.hostname.toLowerCase();
    if (url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash) return null;
    if (hostname === 'localhost' || hostname.endsWith('.local') || /^(?:127\.|10\.|169\.254\.|192\.168\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(hostname)) return null;
    url.pathname = url.pathname.replace(/\/+$/, '');
    return url;
  } catch {
    return null;
  }
}

function validModel(value?: string) {
  return typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,99}$/.test(value) ? value : null;
}

function taskAllowed(value: unknown): value is OpenAiTask {
  return typeof value === 'string' && (OPENAI_TASKS as readonly string[]).includes(value);
}

export function redactSensitive(input: string) {
  return input
    .replace(/\b(?:otp|password|passwd|passcode|pin|kata\s+laluan|密码|验证码)\s*[:=：-]?\s*[^,;\s]+/gi, '[REDACTED_SECRET]')
    .replace(/\b(?:api[_ -]?key|secret[_ -]?key|access[_ -]?token|token|bearer)\s*[:=：-]?\s*[A-Za-z0-9._~+/=-]+/gi, '[REDACTED_TOKEN]')
    .replace(/\b\d{8,24}\b/g, '[REDACTED_NUMBER]')
    .replace(/\b[A-Fa-f0-9]{32,}\b/g, '[REDACTED_TOKEN]');
}

function safeGeneratedText(value: unknown) {
  if (typeof value !== 'string') return null;
  const text = redactSensitive(value).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  return text.length >= 5 && text.length <= 1600 ? text : null;
}

export function openAiGatewayStatus(config: OpenAiGatewayConfig) {
  const base = externalBase(config.apiBaseUrl);
  const keyConfigured = typeof config.apiKey === 'string' && config.apiKey.length >= 20 && config.apiKey.length <= 2048;
  const model = validModel(config.model);
  const enabled = config.enabled === 'true';
  const configured = !!(base && keyConfigured && model);
  return Object.freeze({
    provider: 'openai' as const,
    protocol: 'chat_completions' as const,
    configured,
    enabled,
    ready: enabled && configured,
    apiBaseConfigured: !!base,
    modelConfigured: !!model,
    serverOnly: true as const,
    toolCalling: false as const,
    transactionAutomation: false as const,
    rulesFallbackReady: true as const,
    tasks: OPENAI_TASKS,
  });
}

export async function generateOpenAiText(config: OpenAiGatewayConfig, request: OpenAiGatewayRequest): Promise<OpenAiGatewayResult> {
  const task = taskAllowed(request.task) ? request.task : 'support_reply';
  const status = openAiGatewayStatus(config);
  if (!status.ready) return { task, text: null, providerAttempted: false, reason: 'not_ready' };
  if (typeof request.systemPrompt !== 'string' || request.systemPrompt.trim() === '' || typeof request.userPrompt !== 'string') {
    return { task, text: null, providerAttempted: false, reason: 'invalid_request' };
  }

  const base = externalBase(config.apiBaseUrl);
  const model = validModel(config.model);
  if (!base || !model) return { task, text: null, providerAttempted: false, reason: 'not_ready' };

  const controller = new AbortController();
  const timeout = Math.min(12_000, Math.max(1_000, request.timeoutMs ?? config.timeoutMs ?? 7_000));
  const timer = setTimeout(() => controller.abort(), timeout);
  const maxTokens = Math.min(500, Math.max(32, Math.floor(request.maxTokens ?? 350)));
  try {
    const response = await (config.fetchImpl ?? fetch)(`${base.href.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      redirect: 'error',
      signal: controller.signal,
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${config.apiKey}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.2,
        max_tokens: maxTokens,
        messages: [
          { role: 'system', content: redactSensitive(request.systemPrompt).slice(0, MAX_SYSTEM_INPUT) },
          { role: 'user', content: redactSensitive(request.userPrompt).slice(0, MAX_USER_INPUT) },
        ],
      }),
    });
    if (!response.ok) return { task, text: null, providerAttempted: true, reason: 'provider_error' };
    const raw = await response.text();
    if (raw.length > MAX_RESPONSE_BYTES) return { task, text: null, providerAttempted: true, reason: 'invalid_response' };
    let parsed: any;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return { task, text: null, providerAttempted: true, reason: 'invalid_response' };
    }
    const text = safeGeneratedText(parsed?.choices?.[0]?.message?.content);
    return text
      ? { task, text, providerAttempted: true }
      : { task, text: null, providerAttempted: true, reason: 'invalid_response' };
  } catch {
    return { task, text: null, providerAttempted: true, reason: 'provider_error' };
  } finally {
    clearTimeout(timer);
  }
}
