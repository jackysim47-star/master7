import {postgresSql} from './render-sql.mjs';
import {BACKUP_TABLES,type BackupReader} from './encrypted-backup.ts';

type SnapshotClient={
 query(sql:string,values?:unknown[]):Promise<{rows:unknown[];rowCount?:number|null}>;
 release(destroy?:boolean):void|Promise<void>;
};
type SnapshotPool={connect():Promise<SnapshotClient>};
type SnapshotStatement={bind(...values:unknown[]):SnapshotStatement;all():Promise<{results:unknown[]}>};

// Only this acquired client participates in the snapshot. Ordinary requests
// retain their normal pool path, and no session-wide settings are changed.
export async function withPostgresReadSnapshot<T>(pool:SnapshotPool,read:(db:BackupReader)=>Promise<T>):Promise<T>{
 const client=await pool.connect(),errors:unknown[]=[];
 let active=false,discard=false,result:{value:T}|undefined;
 const assertActive=()=>{if(!active)throw new Error('Backup read snapshot is closed');};
 const assertBackupSelect=(sql:string)=>{
  const match=sql.match(/^SELECT \* FROM ([a-z][a-z0-9_]*) ORDER BY [a-z][a-z0-9_]*(?:,[a-z][a-z0-9_]*)* LIMIT \? OFFSET \?$/);
  if(!match||!(BACKUP_TABLES as readonly string[]).includes(match[1]))throw new Error('Backup read snapshot only accepts a single backup page SELECT');
 };
 const statement=(sql:string,values:unknown[]):SnapshotStatement=>({
  bind(...next:unknown[]){return statement(sql,next);},
  async all(){
   assertActive();
   const result=await client.query(postgresSql(sql),values);
   assertActive();
   return {results:result.rows};
  },
 });
 const reader:BackupReader={prepare(sql){assertActive();assertBackupSelect(sql);return statement(sql,[]);}};
 try{
  await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
  active=true;
  result={value:await read(reader)};
 }catch(error){errors.push(error);discard=true;}
 finally{
  active=false;
  // Attempt rollback even if BEGIN failed after reaching the server. A failed
  // query or rollback discards this client instead of returning it for reuse.
  try{await client.query('ROLLBACK');}catch(error){errors.push(error);discard=true;}
  try{await client.release(discard);}catch(error){errors.push(error);}
 }
 if(errors.length===1)throw errors[0];
 if(errors.length)throw new AggregateError(errors,'Backup read snapshot failed during reading or cleanup');
 if(!result)throw new Error('Backup read snapshot did not complete');
 return result.value;
}
