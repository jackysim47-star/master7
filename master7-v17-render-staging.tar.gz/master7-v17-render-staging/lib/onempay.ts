import {walletGuardStatements} from './wallet-guard.ts';
import {createHash,timingSafeEqual} from 'node:crypto';
import {isIP} from 'node:net';
import {PaymentRequestError,definitivePaymentRejection,reconcileHistoricalPaymentRejections,recordPaymentDiagnostic,safeProviderCode,paymentUrlHost} from './payment-diagnostics.ts';
import {automaticDepositCapability,automaticPaymentStatus,unavailableBalanceCapability} from './payment-capabilities.ts';
import {providerPayoutCapabilities} from './payout-state.ts';
import {customerPortalOriginForEndpoint} from './portal-origin.mjs';

// 1MPay API Specification 1.3, sections 4, 7 and 8. This module creates
// customer checkout pages and verifies deposits. It never invokes /payout.
type Member={id:string;username:string;role:string;approved:number};
export type OneMpayContext={db:D1Database;user:Member|null;apiBase?:string;merchant?:string;secretKey?:string;enabled?:string;newDepositsEnabled?:string;portalOrigins?:string[];callbackUrl?:string;returnUrl?:string;diagnosticToken?:string;recoveryEnabled?:string;acceptance?:{realPaymentVerified:boolean;settlementVerified:boolean};fetchImpl?:typeof fetch};
const provider='1mpay',base='https://api.1mpay.net';
const callbackPath='/api/payment-callbacks/1mpay/payment';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
// The supplier accepts either `ok` or `success`; keep one stable lowercase ACK
// so callback retries see the same exact HTTP 200 response every time.
const ack=(value='ok',status=200)=>new Response(value,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const digest=(value:string)=>createHash('sha256').update(value).digest('hex');
const same=(a:unknown,b:string)=>typeof a==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const id=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(value)?value:null;
function money(value:unknown):{minor:string;decimal:string}|null{
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 return minor>0n&&minor<=10000000n?{minor:minor.toString(),decimal:`${minor/100n}.${String(minor%100n).padStart(2,'0')}`}:null;
}
export const oneMpayCustomer=(userId:string)=>'M7'+digest(userId).slice(0,24);
export function oneMpayOrderToken(merchant:string,amount:string,refid:string,customer:string,secretKey:string,currency='MYR'){
 return createHash('sha256').update(merchant+amount+refid+customer+secretKey+currency).digest('base64');
}
export function oneMpayCallbackToken(merchant:string,amount:string,refid:string,customer:string,secretKey:string,trxno:string){
 return createHash('sha256').update(merchant+amount+refid+customer+secretKey+trxno).digest('base64');
}
function credentials(c:OneMpayContext){const callbackOrigin=customerPortalOriginForEndpoint(c.callbackUrl,c.portalOrigins,callbackPath),returnOrigin=customerPortalOriginForEndpoint(c.returnUrl,c.portalOrigins,'/payment/return');return c.apiBase===base&&typeof c.merchant==='string'&&/^[A-Za-z0-9_-]{6,64}$/.test(c.merchant)&&typeof c.secretKey==='string'&&Buffer.byteLength(c.secretKey)>=16&&Buffer.byteLength(c.secretKey)<=1024&&!!callbackOrigin&&callbackOrigin===returnOrigin;}
export const oneMpayConfigurationReady=credentials;
export function oneMpayCapabilitySnapshot(c:OneMpayContext){
 const configured=credentials(c),depositEnabled=configured&&c.enabled==='true'&&c.newDepositsEnabled==='true';
 return {
   deposit:automaticDepositCapability({implemented:true,configured,enabled:depositEnabled,blockers:[...(!configured?['deposit_configuration_incomplete']:[]),...(c.newDepositsEnabled!=='true'?['new_deposits_paused']:[]),...(c.enabled!=='true'?['profile_orders_disabled']:[])]},'configuration'),
  payout:providerPayoutCapabilities['1mpay'],
  balance:unavailableBalanceCapability(),
 };
}
function checkoutUrl(value:unknown){try{const u=new URL(String(value));return u.origin===base&&u.protocol==='https:'&&u.pathname!=='/'&&u.pathname!=='/login'&&!u.username&&!u.password&&!u.port&&!u.hash?u.href:'';}catch{return '';}}
async function textBounded(response:Response,max=65536){const reader=response.body?.getReader();if(!reader)return '';let size=0;const parts:Uint8Array[]=[];for(;;){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>max){await reader.cancel();throw Error('RESPONSE_TOO_LARGE');}parts.push(next.value);}const bytes=new Uint8Array(size);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}return new TextDecoder().decode(bytes);}
async function providerJson(c:OneMpayContext,path:string,fields?:Record<string,string>){
 const response=await(c.fetchImpl??fetch)(base+path,{method:fields?'POST':'GET',redirect:'error',signal:AbortSignal.timeout(15000),headers:{Accept:'application/json',...(fields?{'Content-Type':'application/x-www-form-urlencoded'}:{})},...(fields?{body:new URLSearchParams(fields).toString()}:{})});
 if(!response.ok||response.redirected){await response.body?.cancel();throw new PaymentRequestError({kind:'PROVIDER_HTTP',httpStatus:response.status});}
 let value;try{value=JSON.parse(await textBounded(response));}catch{throw new PaymentRequestError({kind:'INVALID_JSON',httpStatus:response.status});}
 if(!value||typeof value!=='object'||Array.isArray(value))throw new PaymentRequestError({kind:'INVALID_JSON',httpStatus:response.status});return value;
}
async function readCallback(req:Request):Promise<Record<string,unknown>>{
 const type=req.headers.get('content-type')??'',body=await textBounded(new Response(req.body),8192);let value:unknown;
 if(type.toLowerCase().startsWith('application/json'))value=JSON.parse(body);
 else if(type.toLowerCase().startsWith('application/x-www-form-urlencoded')){const form=new URLSearchParams(body),result:Record<string,string>={};for(const [key,v]of form){if(Object.hasOwn(result,key))throw Error('DUPLICATE_FIELD');result[key]=v;}value=result;}
 else if(type.toLowerCase().startsWith('multipart/form-data')){const form=await new Response(body,{headers:{'Content-Type':type}}).formData(),result:Record<string,string>={};for(const [key,v]of form){if(typeof v!=='string'||Object.hasOwn(result,key))throw Error('INVALID_FORM');result[key]=v;}value=result;}
 else throw Error('UNSUPPORTED_CONTENT_TYPE');
 if(!value||typeof value!=='object'||Array.isArray(value))throw Error('INVALID_BODY');return value as Record<string,unknown>;
}
async function verifyLedger(c:OneMpayContext,order:any){const data=await c.db.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=?').bind(order.id).all<any>();const rows=data.results??[],member=rows.find((x:any)=>x.account_code==='member'),clearing=rows.find((x:any)=>x.account_code==='provider_clearing');return rows.length===2&&rows.every((x:any)=>x.currency==='MYR'&&x.user_id===order.user_id)&&String(member?.amount_minor)===String(order.amount_minor)&&BigInt(clearing?.amount_minor??0)===-BigInt(order.amount_minor);}
// Verify the current order and both ledger legs in one database statement.
// A ledger from an earlier credit alone is insufficient if the order has
// since moved to review or its provider reference has changed.
async function confirmedCredit(c:OneMpayContext,order:any,trxno:string){
 return !!await c.db.prepare(`SELECT o.id FROM deposit_orders o
  JOIN wallet_ledger m ON m.order_id=o.id AND m.account_code='member'
  JOIN wallet_ledger p ON p.order_id=o.id AND p.account_code='provider_clearing'
  WHERE o.id=? AND o.provider='1mpay' AND o.user_id=? AND o.currency='MYR'
   AND o.amount_minor=CAST(? AS BIGINT) AND o.status='credited' AND o.provider_trade_no=?
   AND m.user_id=o.user_id AND p.user_id=o.user_id AND m.currency='MYR' AND p.currency='MYR'
   AND m.amount_minor=o.amount_minor AND p.amount_minor=-o.amount_minor
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=o.id)=2`).bind(order.id,order.user_id,String(order.amount_minor),trxno).first();
}
async function settle(c:OneMpayContext,order:any,trxno:string){
 const existing=await c.db.prepare('SELECT id FROM wallet_ledger WHERE order_id=?').bind(order.id).all();
 if((existing.results??[]).length&&!await verifyLedger(c,order)){
  await c.db.batch([...walletGuardStatements(c.db,order.user_id),c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(Math.floor(Date.now()/1000),order.id,order.user_id,String(order.amount_minor),trxno)]);
  throw Error('LEDGER_REVIEW_REQUIRED');
 }
 const amount=money((BigInt(order.amount_minor)/100n).toString()+'.'+String(BigInt(order.amount_minor)%100n).padStart(2,'0'))!;
 const customer=oneMpayCustomer(order.user_id),token=oneMpayCallbackToken(c.merchant!,amount.decimal,order.id,customer,c.secretKey!,trxno);
 const encoded=Buffer.from(token,'utf8').toString('base64');
 const query=await providerJson(c,`/transquery/${encodeURIComponent(trxno)}/${encodeURIComponent(encoded)}`);
 if(query.merchant!==c.merchant||query.refid!==order.id||String(query.customer)!==customer||query.trxno!==trxno||money(query.amount)?.minor!==String(order.amount_minor)||!same(query.token,token)||(query.currency!==undefined&&query.currency!=='MYR'))throw Error('QUERY_BINDING_MISMATCH');
 const timestamp=Math.floor(Date.now()/1000),creditAuditId='1mpay-credit-'+digest(String(order.id)).slice(0,48);
 // Status is not covered by the documented callback token. Only the independent
 // authenticated HTTPS query can establish success. Late success after timeout
 // remains eligible; failure never deletes the order or its financial history.
 if(String(query.status).trim().toLowerCase()!=='successful'){
  // The provider's terminal failure vocabulary is not verified. Pending or
  // other non-success never reopens an uncredited order. If a previously
  // credited order can no longer be confirmed, preserve its ledger but freeze
  // new spending until reconciliation; do not label this provider result failed.
  await c.db.batch([
   ...walletGuardStatements(c.db,order.user_id),
   c.db.prepare("UPDATE deposit_orders SET updated_at=updated_at WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'").bind(order.id,order.user_id,String(order.amount_minor)),
   c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'1mpay_query_conflict_review',id,? FROM deposit_orders WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=? ON CONFLICT(id) DO NOTHING").bind('1mpay-query-review-'+digest(String(order.id)).slice(0,48),timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
   c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=?").bind(timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
   c.db.prepare("UPDATE deposit_orders SET provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('credited','review') AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(trxno,timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  ]);return false;
 }
 // The preliminary ledger read and the provider query happen outside the lock.
 // Recheck under the member guard and order row lock before writing either
 // leg: historical partial journals must never be completed automatically.
 await c.db.batch([
  ...walletGuardStatements(c.db,order.user_id),
  c.db.prepare("UPDATE deposit_orders SET updated_at=updated_at WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'").bind(order.id,order.user_id,String(order.amount_minor)),
  // A verified success that contradicts a locally terminal failed order is
  // evidence for manual review, not permission to create wallet entries.
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'1mpay_late_success_review',id,? FROM deposit_orders WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='failed' AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(id) DO NOTHING").bind('1mpay-late-review-'+digest(String(order.id)).slice(0,48),timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='failed' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(trxno,timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  c.db.prepare(`INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'1mpay_ledger_review',id,? FROM deposit_orders WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status<>'review' AND (provider_trade_no IS NULL OR provider_trade_no=?)
   AND (status='credited' OR EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id))
   AND NOT ((SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
    AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor)) ON CONFLICT(id) DO NOTHING`).bind('1mpay-review-'+digest(String(order.id)).slice(0,48),timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  c.db.prepare(`UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status<>'review' AND (provider_trade_no IS NULL OR provider_trade_no=?)
   AND (status='credited' OR EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id))
   AND NOT ((SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
    AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor))`).bind(timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'member',amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('review','credited') AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'provider_clearing',-amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('review','credited') AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  c.db.prepare(`UPDATE deposit_orders SET status='credited',provider_trade_no=?,updated_at=? WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('review','credited') AND (provider_trade_no IS NULL OR provider_trade_no=?)
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
   AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor)`).bind(trxno,timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
  c.db.prepare(`INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'1mpay_deposit_credited',id,? FROM deposit_orders WHERE id=? AND provider='1mpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=?
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
   AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor) ON CONFLICT(id) DO NOTHING`).bind(creditAuditId,timestamp,order.id,order.user_id,String(order.amount_minor),trxno),
 ]);
 if(!await confirmedCredit(c,order,trxno))throw Error('LEDGER_REVIEW_REQUIRED');return true;
}
async function callback(req:Request,c:OneMpayContext){
 if(!credentials(c))return ack('UNAVAILABLE',503);
 let data:Record<string,unknown>;try{data=await readCallback(req);}catch{return ack('INVALID',400);}
 const refid=id(data.refid),trxno=id(data.trxno),amount=money(data.amount),customer=id(data.customer);
 if(!refid||!trxno||!amount||!customer||data.merchant!==c.merchant||!same(data.token,oneMpayCallbackToken(c.merchant!,amount.decimal,refid,customer,c.secretKey!,trxno)))return ack('UNAUTHORIZED',401);
 let order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='1mpay'").bind(refid).first<any>();
 if(!order)return ack('UNKNOWN_ORDER',404);
 if(order.currency!=='MYR')return ack('REVIEW_REQUIRED',409);
 if(String(order.amount_minor)!==amount.minor||oneMpayCustomer(order.user_id)!==customer||(order.provider_trade_no&&order.provider_trade_no!==trxno))return ack('REVIEW_REQUIRED',409);
 if(order.status==='credited'&&!await confirmedCredit(c,order,trxno))return ack('LEDGER_REVIEW',503);
 if(order.status==='review')return ack('REVIEW_REQUIRED',503);
 // Keep the reference from a fully authenticated, order-bound notification
 // before the independent provider query. A timeout must not lose the only
 // reference that lets recovery find this payment; this does not credit it.
 if(!order.provider_trade_no){
  try{
   const bound=await c.db.prepare("UPDATE deposit_orders SET provider_trade_no=?,updated_at=? WHERE id=? AND provider='1mpay' AND status NOT IN ('credited','review') AND provider_trade_no IS NULL RETURNING id").bind(trxno,Math.floor(Date.now()/1000),order.id).first();
   if(!bound){
    order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='1mpay'").bind(refid).first<any>();
    if(!order||String(order.amount_minor)!==amount.minor||oneMpayCustomer(order.user_id)!==customer||order.provider_trade_no!==trxno)return ack('REVIEW_REQUIRED',409);
    if(order.status==='credited'&&!await confirmedCredit(c,order,trxno))return ack('LEDGER_REVIEW',503);
    if(order.status==='review')return ack('REVIEW_REQUIRED',503);
   }else order={...order,provider_trade_no:trxno};
  }catch{return ack('PENDING',503);}
 }
 try{return await settle(c,order,trxno)?ack():ack('PENDING',503);}catch{return ack('PENDING',503);}
}
let observedIp:{ip:string;time:number}|null=null;
export async function handleOneMpay(req:Request,c:OneMpayContext):Promise<Response|null>{
 const path=new URL(req.url).pathname;
 if(path===callbackPath&&req.method==='POST')return callback(req,c);
 if(path==='/api/payments/1mpay/status'&&req.method==='GET'){
  const programReady=credentials(c),capabilities=oneMpayCapabilitySnapshot(c),enabled=capabilities.deposit.enabled;
  const realPaymentVerified=c.acceptance?.realPaymentVerified===true,settlementVerified=c.acceptance?.settlementVerified===true;
  return json({provider,profileId:'onempay_myr',currency:'MYR',enabled,mode:enabled?'production':'disabled',...automaticPaymentStatus(capabilities.deposit),programReady,orderReady:enabled,queryReady:programReady,callbacksReady:programReady,recoveryReady:c.recoveryEnabled==='true'&&programReady,payoutReady:capabilities.payout.enabled,balanceReady:capabilities.balance.enabled,realPayments:enabled,realPaymentVerified,liveReady:enabled&&realPaymentVerified&&settlementVerified,settlementVerified,capabilities});
 }
 if(path==='/api/payments/1mpay/diagnostics'&&req.method==='GET'){
  const bearer=req.headers.get('authorization')??'';
  if(!c.diagnosticToken||c.diagnosticToken.length<32||!bearer.startsWith('Bearer ')||!same(bearer.slice(7),c.diagnosticToken))return json({error:'Access denied'},401);
  if(!observedIp||Date.now()-observedIp.time>300000){try{const r=await(c.fetchImpl??fetch)('https://api64.ipify.org?format=json',{headers:{Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(8000)});const data=JSON.parse(await textBounded(r,1000));if(!r.ok||typeof data.ip!=='string'||!isIP(data.ip))throw Error();observedIp={ip:data.ip,time:Date.now()};}catch{return json({provider,configurationReady:credentials(c),outboundIp:null},503);}}
  return json({provider,configurationReady:credentials(c),source:'payment-application',outboundIp:observedIp.ip,observedAt:new Date(observedIp.time).toISOString(),fixedIpVerified:false});
 }
 return null;
}
export async function createOneMpayOrder(data:Record<string,unknown>,c:OneMpayContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);
 if(c.newDepositsEnabled!=='true')return json({error:'New deposits are temporarily unavailable',code:'DEPOSITS_MAINTENANCE'},503);
 if(c.enabled!=='true')return json({error:'1MPay new orders are disabled',code:'PROVIDER_ORDERS_DISABLED'},503);
 if(!credentials(c))return json({error:'1MPAY_NOT_CONFIGURED'},503);
 const amount=money(data.amount),requestKey=typeof data.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(data.requestKey)?data.requestKey:null;
 if(!amount||!requestKey)return json({error:'Invalid MYR order'},400);
 // 1MPay v1.3 limits refid to 20 characters. Keep the database/order ID
 // identical to the provider refid so callbacks and reconciliation bind to
 // one durable identifier without truncation.
 const customer=oneMpayCustomer(u.id),fingerprint=digest(JSON.stringify({provider,amount:amount.minor,customer,currency:'MYR',merchant:c.merchant})),timestamp=Math.floor(Date.now()/1000),newId='M7'+crypto.randomUUID().replaceAll('-','').slice(0,18);
 await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,'1mpay',?,'MYR','bank','pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(newId,u.id,requestKey,fingerprint,amount.minor,timestamp,timestamp).run();
 const order=await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(u.id,requestKey).first<any>();
 if(!order)return json({error:'Order unavailable'},503);if(order.fingerprint!==fingerprint||order.provider!==provider)return json({error:'IDEMPOTENCY_CONFLICT'},409);
 if(order.status==='credited'){
  const reference=id(order.provider_trade_no);
  return reference&&order.currency==='MYR'&&String(order.amount_minor)===amount.minor&&await confirmedCredit(c,order,reference)?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'review',payUrl:null},409);
 }
 if(order.status==='created'){
  const reference=id(order.provider_trade_no),url=checkoutUrl(order.checkout_url);
  if(reference&&url&&String(order.amount_minor)===amount.minor&&order.currency==='MYR')return json({id:order.id,status:'awaiting_payment',payUrl:url,providerTradeNo:reference});
  return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 }
 if(order.status==='unknown'&&!order.provider_trade_no&&!order.checkout_url){await reconcileHistoricalPaymentRejections(c.db,u.id);const historical=await c.db.prepare('SELECT status FROM deposit_orders WHERE id=? AND user_id=?').bind(order.id,u.id).first<{status:string}>();if(historical?.status==='failed')return json({error:'PROVIDER_REJECTED',id:order.id,status:'failed',payUrl:null},422);}
 if(order.status!=='pending')return order.status==='failed'?json({error:'PROVIDER_REJECTED',id:order.id,status:'failed',payUrl:null},422):json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 const claimed=await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(timestamp,order.id).first();if(!claimed)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 try{
  const result=await providerJson(c,'/fundtransfer/json',{merchant:c.merchant!,amount:amount.decimal,refid:order.id,customer,currency:'MYR',token:oneMpayOrderToken(c.merchant!,amount.decimal,order.id,customer,c.secretKey!),post_url:c.callbackUrl!,return_url:c.returnUrl!,failed_return_url:c.returnUrl!});
  const trxno=id(result.data?.trxno),url=checkoutUrl(result.redirect_url);if((result.code!==0&&result.code!=='0')||!trxno||!url)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerCode:safeProviderCode(result.code),providerTradeNo:trxno??undefined,checkoutHost:paymentUrlHost(result.redirect_url),missing:[...(!trxno?['providerTradeNo']:[]),...(!url?['checkoutUrl']:[])]});
  await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,updated_at=? WHERE id=? AND status IN ('creating','unknown') AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(trxno,url,Math.floor(Date.now()/1000),order.id,trxno).run();
  const current=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='1mpay'").bind(order.id,u.id).first<any>();
  if(current?.provider_trade_no!==trxno||current.fingerprint!==fingerprint||String(current.amount_minor)!==amount.minor||current.currency!=='MYR'||!['credited','created'].includes(current.status))return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
  if(current.status==='credited')return await confirmedCredit(c,current,trxno)?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'review',payUrl:null},409);
  return current.checkout_url===url?json({id:order.id,status:'awaiting_payment',payUrl:url,providerTradeNo:trxno},201):json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 }catch(error){
  const rejected=definitivePaymentRejection(error);
  const reference=!rejected&&error instanceof PaymentRequestError?id(error.facts.providerTradeNo):null;
  const rejectionGuard=rejected?' AND provider_trade_no IS NULL':'';
  await c.db.prepare(`UPDATE deposit_orders SET status=?,provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status='creating'${rejectionGuard}`).bind(rejected?'failed':'unknown',reference,Math.floor(Date.now()/1000),order.id).run();
  await recordPaymentDiagnostic(c.db,u.id,provider,order.id,error);
  const current=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='1mpay'").bind(order.id,u.id).first<any>();
  if(current?.status==='credited'){
   const currentReference=id(current.provider_trade_no);
   return currentReference&&current.fingerprint===fingerprint&&current.currency==='MYR'&&String(current.amount_minor)===amount.minor&&await confirmedCredit(c,current,currentReference)?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'review',payUrl:null},409);
  }
  return rejected&&current?.status==='failed'&&!current.provider_trade_no?json({error:'PROVIDER_REJECTED',id:order.id,status:'failed',payUrl:null},422):json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 }
}
export async function refreshOneMpayOrder(data:Record<string,unknown>,c:OneMpayContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member'||!u.approved)return json({error:'Member account required'},403);
 if(!credentials(c))return json({error:'1MPAY_NOT_CONFIGURED'},503);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='1mpay'").bind(id(data.orderId)??'',u.id).first<any>();if(!order)return json({error:'Order not found'},404);
 if(order.status==='credited'){
  const reference=id(order.provider_trade_no);
  return reference&&await confirmedCredit(c,order,reference)?json({id:order.id,status:'credited'}):json({id:order.id,status:'review'},409);
 }
 if(order.status==='review')return json({id:order.id,status:'review'},409);
 if(!id(order.provider_trade_no))return json({id:order.id,status:'awaiting_confirmation'},202);
 try{return json({id:order.id,status:await settle(c,order,order.provider_trade_no)?'credited':'awaiting_confirmation'});}catch{
  const current=await c.db.prepare("SELECT status FROM deposit_orders WHERE id=? AND user_id=? AND provider='1mpay'").bind(order.id,u.id).first<{status:string}>();
  return current?.status==='review'?json({id:order.id,status:'review'},409):json({id:order.id,status:'awaiting_confirmation'},202);
 }
}

/** Incident review only: GET the supplier's existing transaction, without
 * settlement, recovery leases, order updates, audit writes or wallet posting. */
export async function readOneMpayDepositProviderEvidence(c:OneMpayContext){
 const baseResult={readOnly:true,provider:'1mpay',providerQueriesExecuted:0,repairsExecuted:false,walletCreditExecuted:false};
 if(!credentials(c))return {...baseResult,configured:false,items:[],truncated:false};
 const result=await c.db.prepare("SELECT id,user_id,amount_minor,currency,provider_trade_no,status FROM deposit_orders WHERE provider='1mpay' AND provider_trade_no IS NOT NULL ORDER BY created_at,id LIMIT 4").all<{id:string;user_id:string;amount_minor:string;currency:string;provider_trade_no:string;status:string}>();
 if(!Array.isArray(result.results))throw Error('Incident orders unavailable');
 const items=[];let queried=0;
 for(const order of result.results.slice(0,3)){
  const ref=id(order.id),trxno=id(order.provider_trade_no),amount=/^[1-9]\d*$/.test(String(order.amount_minor))?money(`${BigInt(order.amount_minor)/100n}.${String(BigInt(order.amount_minor)%100n).padStart(2,'0')}`):null;
  if(!ref||!trxno||!amount||order.currency!=='MYR'){items.push({orderId:order.id,outcome:'invalid_stored_binding',paymentVerified:false});continue;}
  const customer=oneMpayCustomer(order.user_id),token=oneMpayCallbackToken(c.merchant!,amount.decimal,ref,customer,c.secretKey!,trxno),encoded=Buffer.from(token,'utf8').toString('base64');
  queried++;
  try{
   const reply=await providerJson(c,`/transquery/${encodeURIComponent(trxno)}/${encodeURIComponent(encoded)}`);
   const bound=reply.merchant===c.merchant&&reply.refid===ref&&String(reply.customer)===customer&&reply.trxno===trxno&&money(reply.amount)?.minor===String(order.amount_minor)&&same(reply.token,token)&&(reply.currency===undefined||reply.currency==='MYR');
   if(!bound){items.push({orderId:ref,providerTransactionId:trxno,outcome:'provider_binding_mismatch',paymentVerified:false});continue;}
   const observed=String(reply.status).trim().toLowerCase(),status=['successful','pending','fail','failed','timeout'].includes(observed)?observed:'unrecognized';
   items.push({orderId:ref,providerTransactionId:trxno,amountMinor:amount.minor,currency:'MYR',storedStatus:order.status,outcome:'provider_query_bound',providerStatus:status,paymentVerified:status==='successful'});
  }catch(error){items.push({orderId:ref,providerTransactionId:trxno,outcome:'provider_query_unavailable',paymentVerified:false,...(error instanceof PaymentRequestError?{kind:error.facts.kind,httpStatus:error.facts.httpStatus}:{} )});}
 }
 return {...baseResult,configured:true,providerQueriesExecuted:queried,items,truncated:result.results.length>3};
}

async function holdRecoveryReview(c:OneMpayContext,order:any,reason:string,at=Math.floor(Date.now()/1000)){
 const auditId='1mpay-recovery-review-'+digest(`${order.id}:${reason}`).slice(0,40);
 await c.db.batch([
  ...walletGuardStatements(c.db,order.user_id),
  c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='1mpay' AND status<>'credited' AND COALESCE(provider_trade_no,'')=COALESCE(?,'') AND (?<>'provider_reference_missing' OR status IN ('creating','created','unknown'))").bind(at,order.id,order.provider_trade_no??null,reason),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'1mpay_recovery_review',?,? FROM deposit_orders WHERE id=? AND provider='1mpay' AND status='review' ON CONFLICT(id) DO NOTHING").bind(auditId,JSON.stringify({orderId:order.id,reason}),at,order.id),
 ]);
 const current=await c.db.prepare("SELECT status FROM deposit_orders WHERE id=? AND provider='1mpay'").bind(order.id).first<{status:string}>();
 return current?.status==='review';
}

/**
 * Reconcile only durable 1MPay orders already stored by this portal. Recovery
 * never creates or resubmits an order. The existing recovery lease table is
 * intentionally limited to VPay/GSPAY, so 1MPay uses an optimistic update on
 * the order timestamp to let only one worker query a stale candidate.
 */
export async function recoverOneMpayDeposits(c:OneMpayContext,limit=25,at=Math.floor(Date.now()/1000)){
 const summary={provider,enabled:c.recoveryEnabled==='true'&&credentials(c),scanned:0,claimed:0,queried:0,credited:0,review:0,pending:0,skipped:0,errors:0};
 if(!summary.enabled)return summary;
 const safeLimit=Math.max(1,Math.min(25,Math.trunc(limit))),result=await c.db.prepare(`SELECT * FROM deposit_orders
  WHERE provider='1mpay' AND status IN ('creating','created','unknown','failed') AND updated_at<=?
  ORDER BY updated_at ASC,id ASC LIMIT ?`).bind(at-60,safeLimit).all<any>();
 for(const order of result.results??[]){
  summary.scanned++;
  const reference=id(order.provider_trade_no);
  if(!reference){
   if(['creating','created','unknown'].includes(String(order.status))){if(await holdRecoveryReview(c,order,'provider_reference_missing',at))summary.review++;else summary.skipped++;}
   else summary.skipped++;
   continue;
  }
  const previous=Number(order.updated_at),claimedAt=Math.max(at,Number.isFinite(previous)?previous+1:at);
  const claim=await c.db.prepare("UPDATE deposit_orders SET updated_at=? WHERE id=? AND provider='1mpay' AND updated_at=? AND status IN ('creating','created','unknown','failed') RETURNING id").bind(claimedAt,order.id,order.updated_at).first<{id:string}>();
  if(!claim){summary.skipped++;continue;}summary.claimed++;
  try{
   summary.queried++;
   if(await settle(c,{...order,updated_at:claimedAt},reference))summary.credited++;else summary.pending++;
  }catch(error){
   if(error instanceof Error&&error.message==='QUERY_BINDING_MISMATCH'){if(await holdRecoveryReview(c,order,'query_binding_mismatch',Math.max(at,claimedAt)))summary.review++;else summary.skipped++;}
   else summary.errors++;
  }
 }
 return summary;
}
