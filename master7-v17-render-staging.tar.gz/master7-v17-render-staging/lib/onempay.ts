import {createHash,timingSafeEqual} from 'node:crypto';
import {isIP} from 'node:net';
import {PaymentRequestError,recordPaymentDiagnostic,safeProviderCode,paymentUrlHost} from './payment-diagnostics.ts';

// 1MPay API Specification 1.3, sections 4, 7 and 8. This module creates
// customer checkout pages and verifies deposits. It never invokes /payout.
type Member={id:string;username:string;role:string;approved:number};
export type OneMpayContext={db:D1Database;user:Member|null;apiBase?:string;merchant?:string;secretKey?:string;enabled?:string;callbackUrl?:string;returnUrl?:string;diagnosticToken?:string;fetchImpl?:typeof fetch};
const provider='1mpay',base='https://api.1mpay.net';
const portal='https://master7-v17-staging.onrender.com';
const callbackPath='/api/payment-callbacks/1mpay/payment';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
// The supplier accepts either `ok` or `success`; keep one stable lowercase ACK
// so callback retries see the same exact HTTP 200 response every time.
const ack=(value='ok',status=200)=>new Response(value,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const digest=(value:string)=>createHash('sha256').update(value).digest('hex');
const same=(a:unknown,b:string)=>typeof a==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const id=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(value)?value:null;
function money(value:unknown):{minor:string;decimal:string}|null{
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 return minor>0n&&minor<=10000000n?{minor:minor.toString(),decimal:`${minor/100n}.${String(minor%100n).padStart(2,'0')}`}:null;
}
export const oneMpayCustomer=(userId:string)=>'M7'+digest(userId).slice(0,24);
export function oneMpayOrderToken(merchant:string,amount:string,refid:string,customer:string,secretKey:string,currency='MYR'){
 return createHash('sha256').update(merchant+amount+refid+customer+secretKey+currency).digest('base64');
}
export function oneMpayCallbackToken(merchant:string,amount:string,refid:string,customer:string,secretKey:string,trxno:string){
 return createHash('sha256').update(merchant+amount+refid+customer+secretKey+trxno).digest('base64');
}
function credentials(c:OneMpayContext){return c.apiBase===base&&typeof c.merchant==='string'&&/^[A-Za-z0-9_-]{6,64}$/.test(c.merchant)&&typeof c.secretKey==='string'&&Buffer.byteLength(c.secretKey)>=16&&Buffer.byteLength(c.secretKey)<=1024&&c.callbackUrl===portal+callbackPath&&c.returnUrl===portal+'/payment/return';}
export const oneMpayConfigurationReady=credentials;
function checkoutUrl(value:unknown){try{const u=new URL(String(value));return u.origin===base&&u.protocol==='https:'&&u.pathname!=='/'&&u.pathname!=='/login'&&!u.username&&!u.password&&!u.port&&!u.hash?u.href:'';}catch{return '';}}
async function textBounded(response:Response,max=65536){const reader=response.body?.getReader();if(!reader)return '';let size=0;const parts:Uint8Array[]=[];for(;;){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>max){await reader.cancel();throw Error('RESPONSE_TOO_LARGE');}parts.push(next.value);}const bytes=new Uint8Array(size);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}return new TextDecoder().decode(bytes);}
async function providerJson(c:OneMpayContext,path:string,fields?:Record<string,string>){
 const response=await(c.fetchImpl??fetch)(base+path,{method:fields?'POST':'GET',redirect:'error',signal:AbortSignal.timeout(15000),headers:{Accept:'application/json',...(fields?{'Content-Type':'application/x-www-form-urlencoded'}:{})},...(fields?{body:new URLSearchParams(fields).toString()}:{})});
 if(!response.ok||response.redirected){await response.body?.cancel();throw new PaymentRequestError({kind:'PROVIDER_HTTP',httpStatus:response.status});}
 let value;try{value=JSON.parse(await textBounded(response));}catch{throw new PaymentRequestError({kind:'INVALID_JSON',httpStatus:response.status});}
 if(!value||typeof value!=='object'||Array.isArray(value))throw new PaymentRequestError({kind:'INVALID_JSON',httpStatus:response.status});return value;
}
async function readCallback(req:Request):Promise<Record<string,unknown>>{
 const type=req.headers.get('content-type')??'',body=await textBounded(new Response(req.body),8192);let value:unknown;
 if(type.toLowerCase().startsWith('application/json'))value=JSON.parse(body);
 else if(type.toLowerCase().startsWith('application/x-www-form-urlencoded')){const form=new URLSearchParams(body),result:Record<string,string>={};for(const [key,v]of form){if(Object.hasOwn(result,key))throw Error('DUPLICATE_FIELD');result[key]=v;}value=result;}
 else if(type.toLowerCase().startsWith('multipart/form-data')){const form=await new Response(body,{headers:{'Content-Type':type}}).formData(),result:Record<string,string>={};for(const [key,v]of form){if(typeof v!=='string'||Object.hasOwn(result,key))throw Error('INVALID_FORM');result[key]=v;}value=result;}
 else throw Error('UNSUPPORTED_CONTENT_TYPE');
 if(!value||typeof value!=='object'||Array.isArray(value))throw Error('INVALID_BODY');return value as Record<string,unknown>;
}
async function verifyLedger(c:OneMpayContext,order:any){const data=await c.db.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=?').bind(order.id).all<any>();const rows=data.results??[],member=rows.find((x:any)=>x.account_code==='member'),clearing=rows.find((x:any)=>x.account_code==='provider_clearing');return rows.length===2&&rows.every((x:any)=>x.currency==='MYR'&&x.user_id===order.user_id)&&String(member?.amount_minor)===String(order.amount_minor)&&BigInt(clearing?.amount_minor??0)===-BigInt(order.amount_minor);}
async function settle(c:OneMpayContext,order:any,trxno:string){
 const existing=await c.db.prepare('SELECT id FROM wallet_ledger WHERE order_id=?').bind(order.id).all();
 if((existing.results??[]).length&&!await verifyLedger(c,order)){
  await c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=?").bind(Math.floor(Date.now()/1000),order.id).run();
  throw Error('LEDGER_REVIEW_REQUIRED');
 }
 const amount=money((BigInt(order.amount_minor)/100n).toString()+'.'+String(BigInt(order.amount_minor)%100n).padStart(2,'0'))!;
 const customer=oneMpayCustomer(order.user_id),token=oneMpayCallbackToken(c.merchant!,amount.decimal,order.id,customer,c.secretKey!,trxno);
 const encoded=Buffer.from(token,'utf8').toString('base64');
 const query=await providerJson(c,`/transquery/${encodeURIComponent(trxno)}/${encodeURIComponent(encoded)}`);
 if(query.merchant!==c.merchant||query.refid!==order.id||String(query.customer)!==customer||query.trxno!==trxno||money(query.amount)?.minor!==String(order.amount_minor)||!same(query.token,token)||(query.currency!==undefined&&query.currency!=='MYR'))throw Error('QUERY_BINDING_MISMATCH');
 const timestamp=Math.floor(Date.now()/1000);
 // Status is not covered by the documented callback token. Only the independent
 // authenticated HTTPS query can establish success. Late success after timeout
 // remains eligible; failure never deletes the order or its financial history.
 if(String(query.status).trim().toLowerCase()!=='successful'){
  await c.db.prepare("UPDATE deposit_orders SET provider_trade_no=COALESCE(provider_trade_no,?),status=CASE WHEN status IN ('pending','creating') THEN status ELSE 'unknown' END,updated_at=? WHERE id=? AND status NOT IN ('credited','review') AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(trxno,timestamp,order.id,trxno).run();return false;
 }
 await c.db.batch([
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'member',amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='1mpay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,trxno),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'provider_clearing',-amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='1mpay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,trxno),
  c.db.prepare("UPDATE deposit_orders SET status='credited',provider_trade_no=?,updated_at=? WHERE id=? AND provider='1mpay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(trxno,timestamp,order.id,trxno),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),order.user_id,'1mpay_deposit_credited',order.id,timestamp),
 ]);
 if(!await verifyLedger(c,order))throw Error('LEDGER_REVIEW_REQUIRED');return true;
}
async function callback(req:Request,c:OneMpayContext){
 if(!credentials(c))return ack('UNAVAILABLE',503);
 let data:Record<string,unknown>;try{data=await readCallback(req);}catch{return ack('INVALID',400);}
 const refid=id(data.refid),trxno=id(data.trxno),amount=money(data.amount),customer=id(data.customer);
 if(!refid||!trxno||!amount||!customer||data.merchant!==c.merchant||!same(data.token,oneMpayCallbackToken(c.merchant!,amount.decimal,refid,customer,c.secretKey!,trxno)))return ack('UNAUTHORIZED',401);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='1mpay'").bind(refid).first<any>();
 if(!order)return ack('UNKNOWN_ORDER',404);
 if(String(order.amount_minor)!==amount.minor||oneMpayCustomer(order.user_id)!==customer||(order.provider_trade_no&&order.provider_trade_no!==trxno))return ack('REVIEW_REQUIRED',409);
 if(order.status==='credited')return await verifyLedger(c,order)?ack():ack('LEDGER_REVIEW',503);
 try{await settle(c,order,trxno);return ack();}catch{return ack('PENDING',503);}
}
let observedIp:{ip:string;time:number}|null=null;
export async function handleOneMpay(req:Request,c:OneMpayContext):Promise<Response|null>{
 const path=new URL(req.url).pathname;
 if(path===callbackPath&&req.method==='POST')return callback(req,c);
 if(path==='/api/payments/1mpay/status'&&req.method==='GET'){
  const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='1mpay'").first<{status:string}>();
  const programReady=credentials(c),enabled=programReady&&c.enabled==='true'&&channel?.status==='active';
  return json({provider,currency:'MYR',enabled,mode:enabled?'production':'disabled',channelStatus:channel?.status??'closed',programReady,orderReady:enabled,queryReady:enabled,callbacksReady:programReady,realPayments:enabled,liveReady:false,settlementVerified:false});
 }
 if(path==='/api/payments/1mpay/diagnostics'&&req.method==='GET'){
  const bearer=req.headers.get('authorization')??'';
  if(!c.diagnosticToken||c.diagnosticToken.length<32||!bearer.startsWith('Bearer ')||!same(bearer.slice(7),c.diagnosticToken))return json({error:'Access denied'},401);
  if(!observedIp||Date.now()-observedIp.time>300000){try{const r=await(c.fetchImpl??fetch)('https://api64.ipify.org?format=json',{headers:{Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(8000)});const data=JSON.parse(await textBounded(r,1000));if(!r.ok||typeof data.ip!=='string'||!isIP(data.ip))throw Error();observedIp={ip:data.ip,time:Date.now()};}catch{return json({provider,configurationReady:credentials(c),outboundIp:null},503);}}
  return json({provider,configurationReady:credentials(c),source:'payment-application',outboundIp:observedIp.ip,observedAt:new Date(observedIp.time).toISOString(),fixedIpVerified:false});
 }
 return null;
}
export async function createOneMpayOrder(data:Record<string,unknown>,c:OneMpayContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);
 const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='1mpay'").first<{status:string}>();
 if(!credentials(c)||c.enabled!=='true'||channel?.status!=='active')return json({error:'1MPAY_NOT_CONFIGURED'},503);
 const amount=money(data.amount),requestKey=typeof data.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(data.requestKey)?data.requestKey:null;
 if(!amount||!requestKey)return json({error:'Invalid MYR order'},400);
 // 1MPay v1.3 limits refid to 20 characters. Keep the database/order ID
 // identical to the provider refid so callbacks and reconciliation bind to
 // one durable identifier without truncation.
 const customer=oneMpayCustomer(u.id),fingerprint=digest(JSON.stringify({provider,amount:amount.minor,customer,currency:'MYR',merchant:c.merchant})),timestamp=Math.floor(Date.now()/1000),newId='M7'+crypto.randomUUID().replaceAll('-','').slice(0,18);
 await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,'1mpay',?,'MYR','bank','pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(newId,u.id,requestKey,fingerprint,amount.minor,timestamp,timestamp).run();
 const order=await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(u.id,requestKey).first<any>();
 if(!order)return json({error:'Order unavailable'},503);if(order.fingerprint!==fingerprint||order.provider!==provider)return json({error:'IDEMPOTENCY_CONFLICT'},409);
 if(order.status==='created'&&checkoutUrl(order.checkout_url))return json({id:order.id,status:'awaiting_payment',payUrl:order.checkout_url,providerTradeNo:order.provider_trade_no});
 if(order.status!=='pending')return json({id:order.id,status:order.status==='credited'?'credited':'awaiting_confirmation',payUrl:null},202);
 const claimed=await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(timestamp,order.id).first();if(!claimed)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 try{
  const result=await providerJson(c,'/fundtransfer/json',{merchant:c.merchant!,amount:amount.decimal,refid:order.id,customer,currency:'MYR',token:oneMpayOrderToken(c.merchant!,amount.decimal,order.id,customer,c.secretKey!),post_url:c.callbackUrl!,return_url:c.returnUrl!,failed_return_url:c.returnUrl!});
  const trxno=id(result.data?.trxno),url=checkoutUrl(result.redirect_url);if((result.code!==0&&result.code!=='0')||!trxno||!url)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerCode:safeProviderCode(result.code),providerTradeNo:trxno??undefined,checkoutHost:paymentUrlHost(result.redirect_url),missing:[...(!trxno?['providerTradeNo']:[]),...(!url?['checkoutUrl']:[])]});
  await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,updated_at=? WHERE id=? AND status IN ('creating','unknown') AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(trxno,url,Math.floor(Date.now()/1000),order.id,trxno).run();
  const current=await c.db.prepare('SELECT status,provider_trade_no FROM deposit_orders WHERE id=?').bind(order.id).first<{status:string;provider_trade_no:string|null}>();
  if(current?.provider_trade_no!==trxno||!['credited','created'].includes(current.status))return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
  return current?.status==='credited'?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'awaiting_payment',payUrl:url,providerTradeNo:trxno},201);
 }catch(error){
  await c.db.prepare("UPDATE deposit_orders SET status='unknown',updated_at=? WHERE id=? AND status='creating'").bind(Math.floor(Date.now()/1000),order.id).run();
  await recordPaymentDiagnostic(c.db,u.id,provider,order.id,error);
  return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 }
}
export async function refreshOneMpayOrder(data:Record<string,unknown>,c:OneMpayContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member'||!u.approved)return json({error:'Member account required'},403);
 if(!credentials(c))return json({error:'1MPAY_NOT_CONFIGURED'},503);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='1mpay'").bind(id(data.orderId)??'',u.id).first<any>();if(!order)return json({error:'Order not found'},404);
 if(order.status==='credited')return await verifyLedger(c,order)?json({id:order.id,status:'credited'}):json({error:'Ledger review required'},503);
 if(!id(order.provider_trade_no))return json({id:order.id,status:'awaiting_confirmation'},202);
 try{return json({id:order.id,status:await settle(c,order,order.provider_trade_no)?'credited':'awaiting_confirmation'});}catch{return json({id:order.id,status:'awaiting_confirmation'},202);}
}
