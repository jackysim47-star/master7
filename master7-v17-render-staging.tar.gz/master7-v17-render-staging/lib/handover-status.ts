import {getIntegrationContractIntake} from './integration-contracts.ts';

export const OFFICIAL_ENTRY_HOSTS = Object.freeze([
  'https://www.master7.best',
  'https://www.master7.site',
] as const);

type HandoverFlags = Readonly<{
  readOnly?: boolean;
  newDepositsEnabled?: boolean;
  newGameLaunchesEnabled?: boolean;
  newPayoutsEnabled?: boolean;
  transactionsEnabled?: boolean;
  realPayments?: boolean;
}>;

type HandoverInput = Readonly<{
  release: string;
  flags?: HandoverFlags;
}>;

export function getV173HandoverStatus(input: HandoverInput) {
  const flags = input.flags ?? {};
  return Object.freeze({
    release: input.release,
    environment: 'staging' as const,
    entry: Object.freeze({
      mode: 'same_application' as const,
      hosts: OFFICIAL_ENTRY_HOSTS,
      roleResolution: 'authenticated_session' as const,
      targetTopology: 'shared_backend_and_database' as const,
      dnsTlsStatus: 'external_verification_required' as const,
    }),
    roles: Object.freeze(['owner', 'staff', 'member'] as const),
    runtime: Object.freeze({
      readOnly: flags.readOnly ?? true,
      newDepositsEnabled: flags.newDepositsEnabled ?? false,
      newGameLaunchesEnabled: flags.newGameLaunchesEnabled ?? false,
      newPayoutsEnabled: flags.newPayoutsEnabled ?? false,
      transactionsEnabled: flags.transactionsEnabled ?? false,
      realPayments: flags.realPayments ?? false,
    }),
    capabilities: Object.freeze({
      games: Object.freeze({launchReady: false, walletReady: false, recoveryReady: false, liveReady: false}),
      payments: Object.freeze({orderReady: false, callbackReady: false, recoveryReady: false, settlementVerified: false, liveReady: false}),
      payouts: Object.freeze({enabled: false, liveReady: false}),
    }),
    integrations: getIntegrationContractIntake(),
    production: Object.freeze({
      status: 'NO-GO' as const,
      ready: false,
      blockers: Object.freeze([
        'supplier_contract_and_uat_not_verified',
        'game_launch_wallet_recovery_not_accepted',
        'payment_order_callback_settlement_not_accepted',
        'official_dns_tls_not_verified',
        'production_signoff_not_verified',
        'real_money_capabilities_disabled',
      ]),
    }),
  });
}
