import {getGameProviderProfile} from './game-provider-registry.ts';
import {getIntegrationContractIntake} from './integration-contracts.ts';

export type UatPackageKind='game'|'payment';
export type UatEvidenceRecord=Readonly<{reference:string;sha256:string}>;
export type UatPackageTemplate=Readonly<{
 schemaVersion:1;
 kind:UatPackageKind;
 providerProfile:string;
 environment:'uat';
 releaseVersion:string;
 authorizedUat:false;
 officialContactVerified:false;
 whitelistConfirmed:false;
 testFundsType:'provider_test_credit';
 requiredEvidence:readonly string[];
 evidence:Readonly<Record<string,UatEvidenceRecord>>;
}>;

const TOP_LEVEL_FIELDS=new Set(['schemaVersion','kind','providerProfile','environment','releaseVersion','authorizedUat','officialContactVerified','whitelistConfirmed','testFundsType','requiredEvidence','evidence']);
const EVIDENCE_FIELDS=new Set(['reference','sha256']);
const READINESS_ONLY_BLOCKERS=new Set(['official_uat_authorization_required','official_contact_verification_required','whitelist_confirmation_required','test_funds_must_be_provider_credit','unknown_provider_profile','gateway_is_not_a_supplier_profile','profile_outside_primary_myr_scope']);
const identifier=(value:unknown):value is string=>typeof value==='string'&&/^[a-z][a-z0-9_]{1,95}$/.test(value);
const release=(value:unknown):value is string=>typeof value==='string'&&/^17\.0\.0-[A-Za-z0-9.-]{1,100}$/.test(value);
const reference=(value:unknown):value is string=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9._:/#-]{0,199}$/.test(value);
const digest=(value:unknown):value is string=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const object=(value:unknown):value is Record<string,unknown>=>value!==null&&typeof value==='object'&&!Array.isArray(value);

function unique(values:readonly string[]){return [...new Set(values)];}

function contract(kind:UatPackageKind,providerProfile:string){
 const intake=getIntegrationContractIntake();
 if(kind==='payment')return intake.paymentProviders.find(item=>item.providerId===providerProfile)??null;
 return intake.gameProviders.find(item=>item.profileId===providerProfile||item.role==='gateway'&&item.providerId===providerProfile)??null;
}

function requiredEvidence(kind:UatPackageKind,providerProfile:string){
 const selected=contract(kind,providerProfile);if(!selected)return [];
 const required=[...selected.requiredEvidence];
 if(kind==='game'){
  const profile=getGameProviderProfile(providerProfile);
  if(profile?.unitScale===100)required.push('unit_scale_and_rounding_contract');
  if(profile?.balanceClass==='free_credit')required.push('non_cash_wallet_separation_contract','withdrawal_exclusion_contract');
 }
 return unique(required);
}

export function createUatPackageTemplate(input:{kind:UatPackageKind;providerProfile:string;releaseVersion:string}):UatPackageTemplate{
 if(input.kind!=='game'&&input.kind!=='payment')throw new Error('UAT package kind must be game or payment');
 if(!identifier(input.providerProfile))throw new Error('UAT provider profile is invalid');
 if(!release(input.releaseVersion))throw new Error('UAT release version is invalid');
 return Object.freeze({schemaVersion:1,kind:input.kind,providerProfile:input.providerProfile,environment:'uat',releaseVersion:input.releaseVersion,
  authorizedUat:false,officialContactVerified:false,whitelistConfirmed:false,testFundsType:'provider_test_credit',requiredEvidence:Object.freeze(requiredEvidence(input.kind,input.providerProfile)),evidence:Object.freeze({})});
}

export function validateUatPackageManifest(input:unknown){
 const blockers:string[]=[];if(!object(input))return {schemaValid:false,readyForRestrictedUat:false,kind:null,providerProfile:null,requiredEvidence:[],missingEvidence:[],invalidEvidence:[],evidenceCount:0,blockers:['manifest_must_be_object'],accepted:false,live:false,productionReady:false};
 for(const key of Object.keys(input))if(!TOP_LEVEL_FIELDS.has(key))blockers.push(`unexpected_top_level_field:${key}`);
 if(input.schemaVersion!==1)blockers.push('unsupported_schema_version');
 const kind=input.kind==='game'||input.kind==='payment'?input.kind:null;if(!kind)blockers.push('invalid_kind');
 const providerProfile=identifier(input.providerProfile)?input.providerProfile:null;if(!providerProfile)blockers.push('invalid_provider_profile');
 if(input.environment!=='uat')blockers.push('environment_must_be_uat');
 if(!release(input.releaseVersion))blockers.push('invalid_release_version');
 if(input.authorizedUat!==true)blockers.push('official_uat_authorization_required');
 if(input.officialContactVerified!==true)blockers.push('official_contact_verification_required');
 if(input.whitelistConfirmed!==true)blockers.push('whitelist_confirmation_required');
 if(input.testFundsType!=='provider_test_credit')blockers.push('test_funds_must_be_provider_credit');

 const selected=kind&&providerProfile?contract(kind,providerProfile):null;
 if(kind&&providerProfile&&!selected)blockers.push('unknown_provider_profile');
 if(kind==='game'&&selected&&'role' in selected&&selected.role==='gateway')blockers.push('gateway_is_not_a_supplier_profile');
 if(kind==='payment'&&selected&&'acceptanceScope' in selected&&selected.acceptanceScope!=='primary_myr')blockers.push('profile_outside_primary_myr_scope');
 const required=kind&&providerProfile?requiredEvidence(kind,providerProfile):[];
 if(Object.hasOwn(input,'requiredEvidence')&&(!Array.isArray(input.requiredEvidence)||input.requiredEvidence.length!==required.length||input.requiredEvidence.some((value,index)=>value!==required[index])))blockers.push('required_evidence_drift');

 const evidence=object(input.evidence)?input.evidence:{};if(!object(input.evidence))blockers.push('evidence_must_be_object');
 const invalidEvidence:string[]=[];let evidenceCount=0;
 for(const [key,value] of Object.entries(evidence)){
  if(!identifier(key)||!object(value)||Object.keys(value).some(field=>!EVIDENCE_FIELDS.has(field))||!reference(value.reference)||!digest(value.sha256))invalidEvidence.push(key);
  else evidenceCount++;
 }
 for(const key of invalidEvidence)blockers.push(`invalid_evidence:${key}`);
 const missingEvidence=required.filter(key=>!Object.hasOwn(evidence,key)||invalidEvidence.includes(key));
 const schemaValid=blockers.every(item=>READINESS_ONLY_BLOCKERS.has(item)),readyForRestrictedUat=schemaValid&&blockers.length===0&&missingEvidence.length===0;
 return {schemaValid,readyForRestrictedUat,kind,providerProfile,requiredEvidence:required,missingEvidence,invalidEvidence,evidenceCount,blockers,accepted:false,live:false,productionReady:false};
}
