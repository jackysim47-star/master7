export type PaymentCapability={
 implemented:boolean;
 configured:boolean;
 enabled:boolean;
 verified:boolean;
 settlementVerified:boolean;
 submissionEnabled?:boolean;
 blockers:string[];
};

type CapabilityInput={
 implemented:boolean;
 configured?:boolean;
 enabled?:boolean;
 blockers?:string[];
 submissionEnabled?:boolean;
};

export function paymentCapability(input:CapabilityInput):PaymentCapability{
 const configured=input.configured===true,enabled=input.enabled===true;
 return {
  implemented:input.implemented,
  configured,
  enabled,
  verified:false,
  settlementVerified:false,
  ...(input.submissionEnabled===undefined?{}:{submissionEnabled:input.submissionEnabled===true}),
  blockers:[...new Set(input.blockers??[])],
 };
}

export function automaticDepositCapability(input:CapabilityInput,availabilityBasis:'configuration'|'gateway_contract'){
 const capability=paymentCapability(input);
 return {...capability,availabilityMode:'automatic' as const,readOnly:true,availabilityBasis,reason:capability.blockers[0]??(availabilityBasis==='gateway_contract'?'gateway_contract_ready':'provider_configuration_ready')};
}

export function automaticPaymentStatus(deposit:ReturnType<typeof automaticDepositCapability>){
 return {availabilityMode:deposit.availabilityMode,readOnly:true,availabilityBasis:deposit.availabilityBasis,reason:deposit.reason,channelStatus:deposit.enabled?'active':'unavailable'};
}

export function disabledPayoutCapability(reason='provider_payout_adapter_not_implemented'){
 return paymentCapability({implemented:false,configured:false,enabled:false,submissionEnabled:false,blockers:[reason,'submission_disabled']});
}

export function unavailableBalanceCapability(reason='provider_balance_adapter_not_implemented'){
 return paymentCapability({implemented:false,configured:false,enabled:false,blockers:[reason]});
}
