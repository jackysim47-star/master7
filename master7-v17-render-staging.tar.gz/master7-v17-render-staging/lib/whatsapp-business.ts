import {createHmac,timingSafeEqual} from 'node:crypto';

const GRAPH_ORIGIN='https://graph.facebook.com';
const MASTER7_BUSINESS_NUMBER='+601166336686';
const graphVersionPattern=/^v(?:[1-9]|[1-9]\d)\.\d{1,2}$/;
const idPattern=/^\d{6,32}$/;
const tokenPattern=/^[A-Za-z0-9_.~-]{40,4096}$/;
const appSecretPattern=/^[a-f0-9]{32,128}$/i;
const verifyTokenPattern=/^[A-Za-z0-9_.~-]{32,256}$/;
const templatePattern=/^[a-z0-9_]{1,512}$/;
const languagePattern=/^[a-z]{2,3}(?:_[A-Z]{2})?$/;
const mediaIdPattern=/^[A-Za-z0-9_-]{6,256}$/;
// Meta message IDs are opaque. Bound their size and reject control bytes, but
// do not assume a base64 alphabet that could reject a valid provider ID.
const messageIdPattern=/^[^\u0000-\u001f\u007f]{8,512}$/;

export type WhatsAppBusinessContext={
 enabled?:string;
 graphApiVersion?:string;
 phoneNumberId?:string;
 wabaId?:string;
 accessToken?:string;
 appSecret?:string;
 webhookVerifyToken?:string;
 businessNumber?:string;
 templateName?:string;
 templateLanguage?:string;
 fetchImpl?:typeof fetch;
};

export type WhatsAppBusinessStatus={
 configured:boolean;
 enabled:boolean;
 ready:boolean;
 provider:'meta_whatsapp_cloud_api';
 mode:'approved_template_only';
 businessNumber:string;
 templateName:string|null;
 templateLanguage:string|null;
 blockers:string[];
};

export type WhatsAppTemplateInput={
 recipient:string;
 bodyParameters?:string[];
 headerImageId?:string;
};

export type WhatsAppWebhookStatus={
 messageId:string;
 recipient:string;
 status:'sent'|'delivered'|'read'|'failed';
 timestamp:number|null;
 errorCode:number|null;
};

export type WhatsAppWebhookEvent={
 statuses:WhatsAppWebhookStatus[];
 optOuts:string[];
};

function normalizedBusinessNumber(value:unknown){
 if(typeof value!=='string')return null;
 const digits=value.replace(/\D/g,'');
 return digits==='601166336686'?MASTER7_BUSINESS_NUMBER:null;
}

export function malaysiaWhatsAppRecipient(value:unknown){
 if(typeof value!=='string')return null;
 let digits=value.replace(/\D/g,'');
 if(digits.startsWith('60'))digits=digits.slice(2);
 if(digits.startsWith('0'))digits=digits.slice(1);
 return /^1\d{8,9}$/.test(digits)?`+60${digits}`:null;
}

function configured(c:WhatsAppBusinessContext){
 return graphVersionPattern.test(c.graphApiVersion??'')
  &&idPattern.test(c.phoneNumberId??'')
  &&idPattern.test(c.wabaId??'')
  &&tokenPattern.test(c.accessToken??'')
  &&appSecretPattern.test(c.appSecret??'')
  &&verifyTokenPattern.test(c.webhookVerifyToken??'')
  &&normalizedBusinessNumber(c.businessNumber)===MASTER7_BUSINESS_NUMBER
  &&templatePattern.test(c.templateName??'')
  &&languagePattern.test(c.templateLanguage??'');
}

export function whatsappBusinessStatus(c:WhatsAppBusinessContext):WhatsAppBusinessStatus{
 const complete=configured(c),enabled=c.enabled==='true',blockers:string[]=[];
 if(!complete)blockers.push('configuration_incomplete');
 if(!enabled)blockers.push('sending_disabled');
 return {configured:complete,enabled,ready:complete&&enabled,provider:'meta_whatsapp_cloud_api',mode:'approved_template_only',businessNumber:MASTER7_BUSINESS_NUMBER,templateName:templatePattern.test(c.templateName??'')?c.templateName!:null,templateLanguage:languagePattern.test(c.templateLanguage??'')?c.templateLanguage!:null,blockers};
}

async function boundedJson(response:Response,maximum=65536){
 const declared=Number(response.headers.get('content-length')??0);
 if(Number.isFinite(declared)&&declared>maximum)throw new Error('RESPONSE_TOO_LARGE');
 const reader=response.body?.getReader();if(!reader)return null;
 const chunks:Uint8Array[]=[];let size=0;
 for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>maximum){await reader.cancel();throw new Error('RESPONSE_TOO_LARGE');}chunks.push(part.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw new Error('INVALID_JSON');}
}

function templateParameter(value:unknown){
 if(typeof value!=='string')return null;
 const text=value.trim();return text.length>=1&&text.length<=1024&&!/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(text)?text:null;
}

export async function sendWhatsAppTemplate(c:WhatsAppBusinessContext,input:WhatsAppTemplateInput){
 const status=whatsappBusinessStatus(c);if(!status.ready)return {ok:false as const,kind:'not_configured' as const};
 const recipient=malaysiaWhatsAppRecipient(input.recipient);if(!recipient)return {ok:false as const,kind:'invalid_recipient' as const};
 const values=input.bodyParameters??[];if(!Array.isArray(values)||values.length>20)return {ok:false as const,kind:'invalid_template_parameters' as const};
 const parameters=[] as {type:'text';text:string}[];for(const value of values){const text=templateParameter(value);if(!text)return {ok:false as const,kind:'invalid_template_parameters' as const};parameters.push({type:'text',text});}
 if(input.headerImageId!==undefined&&!mediaIdPattern.test(input.headerImageId))return {ok:false as const,kind:'invalid_media_id' as const};
 const components:any[]=[];
 if(input.headerImageId)components.push({type:'header',parameters:[{type:'image',image:{id:input.headerImageId}}]});
 if(parameters.length)components.push({type:'body',parameters});
 const payload={messaging_product:'whatsapp',recipient_type:'individual',to:recipient.slice(1),type:'template',template:{name:c.templateName!,language:{code:c.templateLanguage!},...(components.length?{components}:{})}};
 const endpoint=`${GRAPH_ORIGIN}/${c.graphApiVersion}/${c.phoneNumberId}/messages`,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
 try{
  const response=await(c.fetchImpl??fetch)(endpoint,{method:'POST',redirect:'error',signal:controller.signal,headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${c.accessToken}`},body:JSON.stringify(payload)});
  let value:any;try{value=await boundedJson(response);}catch{return {ok:false as const,kind:'invalid_response' as const,httpStatus:response.status};}
  if(!response.ok)return {ok:false as const,kind:response.status===429?'rate_limited' as const:response.status>=500?'provider_unavailable' as const:'provider_rejected' as const,httpStatus:response.status,retryAfter:response.status===429?Math.max(0,Math.min(3600,Number(response.headers.get('retry-after')??0)||0)):undefined};
  const messageId=value?.messages?.[0]?.id;
  if(typeof messageId!=='string'||!messageIdPattern.test(messageId))return {ok:false as const,kind:'invalid_response' as const,httpStatus:response.status};
  return {ok:true as const,messageId,recipient};
 }catch{return {ok:false as const,kind:'unavailable' as const};}
 finally{clearTimeout(timer);}
}

function safeEqual(a:Buffer,b:Buffer){return a.length===b.length&&timingSafeEqual(a,b);}

export function verifyWhatsAppWebhookSignature(rawBody:Uint8Array|string,signature:unknown,appSecret:unknown){
 if(typeof signature!=='string'||!/^sha256=[a-f0-9]{64}$/i.test(signature)||typeof appSecret!=='string'||!appSecretPattern.test(appSecret))return false;
 const expected=createHmac('sha256',appSecret).update(rawBody).digest(),received=Buffer.from(signature.slice(7),'hex');
 return safeEqual(expected,received);
}

export function verifyWhatsAppWebhookChallenge(search:URLSearchParams,verifyToken:unknown){
 const mode=search.get('hub.mode'),token=search.get('hub.verify_token'),challenge=search.get('hub.challenge');
 if(mode!=='subscribe'||typeof verifyToken!=='string'||!verifyTokenPattern.test(verifyToken)||typeof token!=='string'||!safeEqual(Buffer.from(token),Buffer.from(verifyToken))||challenge===null||challenge.length<1||challenge.length>512)return {ok:false as const};
 return {ok:true as const,challenge};
}

function webhookTimestamp(value:unknown){
 const parsed=typeof value==='string'&&/^\d{1,12}$/.test(value)?Number(value):null;
 return parsed!==null&&Number.isSafeInteger(parsed)&&parsed>=0?parsed:null;
}

function providerErrorCode(value:unknown){
 const parsed=Number(value);return Number.isSafeInteger(parsed)&&parsed>=0&&parsed<=2147483647?parsed:null;
}

function optOutText(value:unknown){
 if(typeof value!=='string')return false;
 return /^(?:stop(?:\s+all)?|unsubscribe|cancel|berhenti|henti|停止|停|退订|取消订阅)$/iu.test(value.trim());
}

export function parseWhatsAppWebhook(value:unknown):WhatsAppWebhookEvent{
 const statuses:WhatsAppWebhookStatus[]=[],optOuts=new Set<string>();
 if(!value||typeof value!=='object'||Array.isArray(value))return {statuses,optOuts:[]};
 const entries=Array.isArray((value as any).entry)?(value as any).entry:[];
 for(const entry of entries.slice(0,100)){
  const changes=Array.isArray(entry?.changes)?entry.changes:[];
  for(const change of changes.slice(0,100)){
   if(change?.field!=='messages'||!change.value||typeof change.value!=='object')continue;
   const rawStatuses=Array.isArray(change.value.statuses)?change.value.statuses:[];
   for(const item of rawStatuses.slice(0,1000)){
    if(!messageIdPattern.test(item?.id??'')||!['sent','delivered','read','failed'].includes(item?.status))continue;
    const recipient=malaysiaWhatsAppRecipient(item?.recipient_id);if(!recipient)continue;
    const errors=Array.isArray(item?.errors)?item.errors:[];
    statuses.push({messageId:item.id,recipient,status:item.status,timestamp:webhookTimestamp(item.timestamp),errorCode:providerErrorCode(errors[0]?.code)});
   }
   const messages=Array.isArray(change.value.messages)?change.value.messages:[];
   for(const message of messages.slice(0,1000)){
    const recipient=malaysiaWhatsAppRecipient(message?.from);
    if(recipient&&message?.type==='text'&&optOutText(message?.text?.body))optOuts.add(recipient);
   }
  }
 }
 return {statuses,optOuts:[...optOuts]};
}
