const DAY=86400;

type FinanceRange={period:string;start:number;end:number;label:string};
type FinanceOptions={generatedAt?:number;settlementVerified?:boolean};
type AggregateRow={orders?:number|string;members?:number|string;amount?:number|string};

const rows=async(db:D1Database,sql:string,...values:(string|number)[])=>((await db.prepare(sql).bind(...values).all()).results??[]) as any[];
const integer=(value:unknown)=>Number(value??0);
const amount=(value:unknown)=>String(value??'0');
const unavailable=(source='not_connected')=>({source,status:'not_connected',recognized:false,amountMinor:null});

function assertRange(range:FinanceRange){
 if(!range||typeof range.period!=='string'||typeof range.label!=='string'||!Number.isSafeInteger(range.start)||!Number.isSafeInteger(range.end)||range.start<0||range.end<=range.start||range.end-range.start>DAY*3660)throw new Error('Invalid finance report range');
}

export async function financeCenterReport(db:D1Database,range:FinanceRange,options:FinanceOptions={}){
 assertRange(range);
 const generatedAt=Number.isSafeInteger(options.generatedAt)&&Number(options.generatedAt)>=0?Number(options.generatedAt):Math.floor(Date.now()/1000),settlementVerified=options.settlementVerified===true;
 const [depositRow,withdrawalRow,depositProviders,withdrawalProviders,manualCredited,manualPending,bankRow,memberLedger,clearingLedger,ledgerOrders,gameLedger,commissionRows]=await Promise.all([
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE currency='MYR' AND status='credited' AND updated_at>=? AND updated_at<?").bind(range.start,range.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM withdrawal_requests WHERE currency='MYR' AND status='paid' AND updated_at>=? AND updated_at<?").bind(range.start,range.end).first<AggregateRow>(),
  rows(db,"SELECT provider,COUNT(*) orders,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amountMinor FROM deposit_orders WHERE currency='MYR' AND status='credited' AND updated_at>=? AND updated_at<? GROUP BY provider ORDER BY provider",range.start,range.end),
  rows(db,"SELECT provider_id provider,COUNT(*) orders,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amountMinor FROM withdrawal_requests WHERE currency='MYR' AND status='paid' AND updated_at>=? AND updated_at<? GROUP BY provider_id ORDER BY provider_id",range.start,range.end),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE currency='MYR' AND provider='manual_bank' AND status='credited' AND updated_at>=? AND updated_at<?").bind(range.start,range.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE currency='MYR' AND provider='manual_bank' AND status='pending'").first<AggregateRow>(),
  db.prepare('SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN enabled=1 THEN 1 ELSE 0 END),0) enabled FROM company_bank_accounts').first<{total:number|string;enabled:number|string}>(),
  db.prepare("SELECT COUNT(*) entries,CAST(COALESCE(SUM(l.amount_minor),0) AS TEXT) amount FROM wallet_ledger l JOIN deposit_orders d ON d.id=l.order_id WHERE l.currency='MYR' AND l.account_code='member' AND d.currency='MYR' AND d.status='credited' AND d.updated_at>=? AND d.updated_at<?").bind(range.start,range.end).first<{entries:number|string;amount:string}>(),
  db.prepare("SELECT COUNT(*) entries,CAST(COALESCE(SUM(l.amount_minor),0) AS TEXT) amount FROM wallet_ledger l JOIN deposit_orders d ON d.id=l.order_id WHERE l.currency='MYR' AND l.account_code='provider_clearing' AND d.currency='MYR' AND d.status='credited' AND d.updated_at>=? AND d.updated_at<?").bind(range.start,range.end).first<{entries:number|string;amount:string}>(),
  db.prepare("SELECT COUNT(DISTINCT CASE WHEN l.account_code='member' THEN l.order_id END) member_orders,COUNT(DISTINCT CASE WHEN l.account_code='provider_clearing' THEN l.order_id END) clearing_orders FROM wallet_ledger l JOIN deposit_orders d ON d.id=l.order_id WHERE d.currency='MYR' AND d.status='credited' AND d.updated_at>=? AND d.updated_at<?").bind(range.start,range.end).first<{member_orders:number|string;clearing_orders:number|string}>(),
  db.prepare("SELECT COUNT(*) sessions,CAST(COALESCE(SUM(l.amount_minor),0) AS TEXT) member_result FROM game_wallet_ledger l JOIN game_wallet_sessions s ON s.id=l.session_id AND s.user_id=l.user_id WHERE s.status='settled' AND s.amount_returned_minor IS NOT NULL AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=s.amount_returned_minor-s.amount_out_minor AND l.created_at>=? AND l.created_at<?").bind(range.start,range.end).first<{sessions:number|string;member_result:string}>(),
  rows(db,"SELECT p.basis,COUNT(DISTINCT p.id) periods,COUNT(e.id) entries,CAST(COALESCE(SUM(e.commission_minor),0) AS TEXT) previewMinor FROM commission_periods p LEFT JOIN commission_entries e ON e.period_id=p.id WHERE p.status='preview' AND p.period_start>=? AND p.period_end<=? GROUP BY p.basis ORDER BY p.basis",range.start,range.end)
 ]);
 const depositMinor=amount(depositRow?.amount),withdrawalMinor=amount(withdrawalRow?.amount),netCashflowMinor=(BigInt(depositMinor)-BigInt(withdrawalMinor)).toString();
 const deposits={source:'deposit_orders',status:'connected',recognized:true,amountMinor:depositMinor,orders:integer(depositRow?.orders),members:integer(depositRow?.members),providers:depositProviders};
 const withdrawals={source:'withdrawal_requests',status:'connected',recognized:true,amountMinor:withdrawalMinor,orders:integer(withdrawalRow?.orders),members:integer(withdrawalRow?.members),providers:withdrawalProviders};
 const banks={source:'company_bank_accounts',status:integer(bankRow?.enabled)>0?'configured':'not_configured',bankConfigured:integer(bankRow?.enabled)>0,totalAccounts:integer(bankRow?.total),enabledAccounts:integer(bankRow?.enabled),receiptUpload:true,reviewWorkflow:'connected',walletPostingOnApproval:true,notificationSource:'/api/admin/financial-events',approval:{path:'/admin',panel:'manualBankAdminPanel'}};
 const manualBank={...banks,source:'manual_deposit_requests+deposit_orders',status:banks.bankConfigured?'connected':'not_configured',recognized:true,amountMinor:amount(manualCredited?.amount),orders:integer(manualCredited?.orders),members:integer(manualCredited?.members),pending:{orders:integer(manualPending?.orders),members:integer(manualPending?.members),amountMinor:amount(manualPending?.amount)}};
 const memberCreditMinor=amount(memberLedger?.amount),clearingMinor=amount(clearingLedger?.amount),depositDifference=(BigInt(memberCreditMinor)-BigInt(depositMinor)).toString(),doubleEntryDifference=(BigInt(memberCreditMinor)+BigInt(clearingMinor)).toString(),depositOrders=integer(depositRow?.orders),memberOrders=integer(ledgerOrders?.member_orders),clearingOrders=integer(ledgerOrders?.clearing_orders),walletMatched=depositDifference==='0'&&doubleEntryDifference==='0'&&memberOrders===depositOrders&&clearingOrders===depositOrders;
 const commissionPreview=new Map(commissionRows.map(item=>[String(item.basis),{periods:integer(item.periods),entries:integer(item.entries),previewAmountMinor:amount(item.previewMinor)}]));
 const previewCategory=(basis:string,source:string)=>({source,status:commissionPreview.has(basis)?'preview_only':'not_connected',recognized:false,amountMinor:null,...(commissionPreview.get(basis)??{previewAmountMinor:null,periods:0,entries:0})});
 const memberResult=amount(gameLedger?.member_result),gameSessions=integer(gameLedger?.sessions),gamePnl=gameSessions?{source:'game_wallet_ledger',status:settlementVerified?'connected':'unverified',recognized:settlementVerified,amountMinor:settlementVerified?(-BigInt(memberResult)).toString():null,observedMemberResultMinor:memberResult,sessions:gameSessions,settlementVerified}:{...unavailable('game_wallet_ledger'),status:'not_connected',observedMemberResultMinor:'0',sessions:0,settlementVerified};
 const categories={
  deposits,withdrawals,manualBank,
  vipBonuses:unavailable(),cashback:unavailable(),
  referralDepositCommission:previewCategory('deposit','commission_entries'),
  referralTurnoverCommission:previewCategory('turnover','commission_entries'),
  companyProfitDividend:previewCategory('company_profit','commission_entries'),
  gamePnl,
  providerSettlement:unavailable(),providerFees:unavailable(),refunds:unavailable(),operatingExpenses:unavailable()
 };
 const missingSources=Object.entries(categories).filter(([,item])=>item.amountMinor===null).map(([key])=>key);
 return {
  currency:'MYR',timezone:'Asia/Kuching',reportType:'finance_center_v1',period:range.period,start:range.start,end:range.end,label:range.label,generatedAt,
  scope:'Recognized cashflow includes credited deposits and paid withdrawals only. Net profit remains unavailable until all required sources and external settlements are verified.',
  categories,
  totals:{recognizedDepositsMinor:depositMinor,recognizedWithdrawalsMinor:withdrawalMinor,netCashflowMinor,netProfitMinor:null,netProfitStatus:'incomplete_sources'},
  bank:banks,
  reconciliation:{
   overall:'incomplete',settlementVerified,
   memberWallet:{source:'wallet_ledger',status:walletMatched?'matched':'mismatch',matched:walletMatched,creditedDepositMinor:depositMinor,memberCreditMinor,providerClearingMinor:clearingMinor,depositDifferenceMinor:depositDifference,doubleEntryDifferenceMinor:doubleEntryDifference,creditedOrders:depositOrders,memberLedgerOrders:memberOrders,clearingLedgerOrders:clearingOrders},
   paymentProvider:{source:'provider_settlement_statement',status:'not_connected',differenceMinor:null},
   bankStatement:{source:'bank_statement',status:'not_connected',differenceMinor:null}
  },
  readiness:{cashflowReady:true,netProfitReady:false,bankConfigured:banks.bankConfigured,manualDepositReviewReady:true,missingSources}
 };
}
