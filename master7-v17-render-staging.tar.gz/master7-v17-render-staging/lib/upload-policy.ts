/**
 * Safe upload approval policy for the V173 staging handover.
 *
 * Asset uploads may become active after server-side validation. Member
 * payment receipts never become wallet credit from an upload or an AI result;
 * they remain a human-review item.
 */

export const UPLOAD_APPROVAL_MODE = 'layered_safe' as const;
export const ASSET_UPLOAD_SCOPES = Object.freeze([
  'company_bank_artwork',
  'supplier_artwork',
  'lobby_advertisement',
  'custom_game_artwork',
] as const);

export type UploadPolicyConfig = Readonly<{
  mode?: string;
  assetAutoApproval?: string;
  receiptAutoApproval?: string;
}>;

export function uploadPolicyStatus(config: UploadPolicyConfig = {}) {
  const configuredMode = typeof config.mode === 'string' && config.mode.trim() !== '' ? config.mode.trim() : UPLOAD_APPROVAL_MODE;
  const modeValid = configuredMode === UPLOAD_APPROVAL_MODE;
  const assetsRequested = config.assetAutoApproval === undefined || config.assetAutoApproval === 'true';
  // This is intentionally hard-coded false. No environment variable or AI
  // output may turn a payment receipt into an automatic wallet credit.
  const receiptAutoApproval = false;
  return Object.freeze({
    mode: UPLOAD_APPROVAL_MODE,
    configuredMode,
    modeValid,
    environmentReady: modeValid,
    assets: Object.freeze({
      autoApproveAfterValidation: modeValid && assetsRequested,
      approvalScope: ASSET_UPLOAD_SCOPES,
      validation: Object.freeze(['owner_or_staff', 'jpg_png_webp', 'max_350_kb', 'valid_image_data'] as const),
    }),
    receipt: Object.freeze({
      autoApprove: receiptAutoApproval,
      humanApprovalRequired: true,
      aiMaySuggest: true,
      walletCreditOnUpload: false,
      endpoint: '/api/admin/manual-bank/review',
    }),
    package: Object.freeze({
      target: 'v173_staging',
      productionAutoDeploy: false,
      transactionSwitchesChanged: false,
    }),
  });
}
