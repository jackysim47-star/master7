export const malaysiaBanks = [
 ['maybank','Maybank'],['cimb','CIMB Bank'],['public_bank','Public Bank'],['rhb','RHB Bank'],
 ['hong_leong','Hong Leong Bank'],['ambank','AmBank'],['bank_islam','Bank Islam'],['bank_rakyat','Bank Rakyat'],
 ['bsn','Bank Simpanan Nasional (BSN)'],['alliance','Alliance Bank'],['affin','Affin Bank'],
 ['ocbc','OCBC Bank Malaysia'],['uob','UOB Malaysia'],['hsbc','HSBC Malaysia'],
 ['standard_chartered','Standard Chartered Malaysia'],['agrobank','Agrobank'],
 ['bank_muamalat','Bank Muamalat'],['mbsb','MBSB Bank'],
] as const;

export type MalaysiaBankCode = typeof malaysiaBanks[number][0];
export const malaysiaBankCodes = malaysiaBanks.map(([id])=>id) as readonly MalaysiaBankCode[];
export const malaysiaBank = (value:unknown)=>malaysiaBanks.find(([id])=>id===value);
