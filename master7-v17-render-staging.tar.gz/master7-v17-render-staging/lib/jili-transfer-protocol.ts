import {createHash,randomBytes} from 'node:crypto';
import {gameAmountToWalletMinor,walletMinorToGameAmount} from './game-unit-conversion.ts';

// Legacy transfer-wallet protocol, isolated from platform ledger writes.
// Unit choices must come from this merchant's accepted account contract.
export type JiliProfile='jili_myr_1to1'|'jili_my1_1to100';
export type JiliAmountUnit='platform_currency'|'game_points';
export type JiliConfig={
 profile:JiliProfile;baseUrl:string;agentId:string;agentKey:string;
 transferAmountUnit:JiliAmountUnit;queryAmountUnit:JiliAmountUnit;
 balanceAmountUnit:JiliAmountUnit;reportAmountUnit:JiliAmountUnit;
 launchOrigins:readonly string[];
};
export type JiliTransfer={playerId:string;transactionId:string;direction:'deposit'|'withdrawal';amountMinor?:string;providerTransactionId?:string};
export type JiliReceipt={state:'confirmed'|'rejected'|'unknown';providerTransactionId?:string;amountMinor?:string;errorCode?:string;requiresLedgerReconciliation:true};
export class JiliProtocolError extends Error{readonly code:string;constructor(code:string){super(code);this.name='JiliProtocolError';this.code=code;}}
const fail=(code:string):never=>{throw new JiliProtocolError(code);};
const md5=(text:string)=>createHash('md5').update(text,'utf8').digest('hex');
const object=(v:unknown):v is Record<string,unknown>=>!!v&&typeof v==='object'&&!Array.isArray(v);
const safeText=(v:unknown,re:RegExp,code='JILI_INPUT_INVALID')=>typeof v==='string'&&re.test(v)?v:fail(code);
const member=(v:unknown)=>safeText(v,/^[A-Za-z0-9_]{1,32}$/);
const serial=(v:unknown)=>safeText(v,/^[A-Za-z0-9]{1,50}$/);
const integer=(v:unknown,max=1_000_000)=>typeof v==='string'&&/^(0|[1-9]\d{0,9})$/.test(v)&&Number(v)<=max?Number(v):fail('JILI_RESPONSE_INVALID');
const decimal=(v:unknown)=>typeof v==='string'&&/^(0|[1-9]\d{0,11})(?:\.\d{1,4})?$/.test(v)?v:fail('JILI_AMOUNT_INVALID');
const units=(v:unknown):v is JiliAmountUnit=>v==='platform_currency'||v==='game_points';
const unknown=(code='JILI_TRANSFER_UNKNOWN'):JiliReceipt=>({state:'unknown',errorCode:code,requiresLedgerReconciliation:true});
function origin(raw:string){
 try{const u=new URL(raw);if(u.origin!==raw||u.protocol!=='https:'||u.username||u.password||u.port) return fail('JILI_ORIGIN_INVALID');return u.origin;}catch{return fail('JILI_ORIGIN_INVALID');}
}
export function jiliDate(epoch:number){
 if(!Number.isSafeInteger(epoch)||epoch<=0)return fail('JILI_CLOCK_INVALID');
 const d=new Date(epoch-4*60*60_000);return `${String(d.getUTCFullYear()).slice(-2)}${String(d.getUTCMonth()+1).padStart(2,'0')}${d.getUTCDate()}`;
}
export function jiliSignature(query:string,agentId:string,agentKey:string,epoch:number,prefix=randomBytes(3).toString('hex'),suffix=randomBytes(3).toString('hex')){
 safeText(prefix,/^[A-Za-z0-9]{6}$/);safeText(suffix,/^[A-Za-z0-9]{6}$/);
 return prefix+md5(query+md5(jiliDate(epoch)+agentId+agentKey))+suffix;
}
export function jiliPlayerId(profile:JiliProfile,userId:string){
 if(!['jili_myr_1to1','jili_my1_1to100'].includes(profile))return fail('JILI_PROFILE_INVALID');
 safeText(userId,/^[A-Za-z0-9_.:-]{1,200}$/);return 'm7'+createHash('sha256').update(`${profile}\0${userId}`).digest('hex').slice(0,28);
}
export function jiliTransactionId(profile:JiliProfile,reference:string,direction:'deposit'|'withdrawal'){
 if(!['jili_myr_1to1','jili_my1_1to100'].includes(profile)||!['deposit','withdrawal'].includes(direction))return fail('JILI_PROFILE_INVALID');
 safeText(reference,/^[A-Za-z0-9_.:-]{1,200}$/);return 'm7'+createHash('sha256').update(`${profile}\0${direction}\0${reference}`).digest('hex').slice(0,44);
}

async function responseObject(response:Response,maximum:number){
 if(!response.ok||response.redirected||!/^application\/json(?:\s*;|\s*$)/i.test(response.headers.get('content-type')??'')||!response.body)return fail('JILI_PROVIDER_UNAVAILABLE');
 const declared=response.headers.get('content-length');if(declared&&(!/^\d+$/.test(declared)||Number(declared)>maximum))return fail('JILI_RESPONSE_INVALID');
 const reader=response.body.getReader(),chunks:Uint8Array[]=[];let size=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>maximum){await reader.cancel().catch(()=>{});return fail('JILI_RESPONSE_INVALID');}chunks.push(value);}}finally{reader.releaseLock();}
 // Preserve Decimal(16,4) and 64-bit wager IDs before JSON.parse can round
 // them. Quoted strings (including escaped quotes) remain untouched.
 const raw=Buffer.concat(chunks).toString('utf8').replace(/("(?:[^"\\]|\\.)*")|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,(token,quoted)=>quoted??JSON.stringify(token));
 let value:unknown;try{value=JSON.parse(raw);}catch{return fail('JILI_RESPONSE_INVALID');}
 if(!object(value))return fail('JILI_RESPONSE_INVALID');
 const code=typeof value.ErrorCode==='string'&&/^\d{1,4}$/.test(value.ErrorCode)?Number(value.ErrorCode):fail('JILI_RESPONSE_INVALID');
 return {code,data:value.Data};
}

export function createJiliProtocolClient(config:JiliConfig,transport:typeof fetch,clock:()=>number=Date.now){
 if(!config||!['jili_myr_1to1','jili_my1_1to100'].includes(config.profile)||typeof transport!=='function')return fail('JILI_CONFIGURATION_INVALID');
 let base:URL;try{base=new URL(config.baseUrl);}catch{return fail('JILI_CONFIGURATION_INVALID');}
 if(base.protocol!=='https:'||base.username||base.password||base.search||base.hash||base.port||!/^\/api1\/?$/.test(base.pathname))return fail('JILI_CONFIGURATION_INVALID');
 const endpoint=base.href.replace(/\/$/,''),profile=config.profile,scale=profile==='jili_my1_1to100'?100:1;
 const agentId=safeText(config.agentId,/^[A-Za-z0-9_]{1,100}$/,'JILI_CONFIGURATION_INVALID'),agentKey=safeText(config.agentKey,/^[A-Za-z0-9]{16,128}$/,'JILI_CONFIGURATION_INVALID');
 if(![config.transferAmountUnit,config.queryAmountUnit,config.balanceAmountUnit,config.reportAmountUnit].every(units)||!Array.isArray(config.launchOrigins)||config.launchOrigins.length>50)return fail('JILI_CONFIGURATION_INVALID');
 const launchOrigins=new Set(config.launchOrigins.map(origin)),unitConfig=Object.freeze({transfer:config.transferAmountUnit,query:config.queryAmountUnit,balance:config.balanceAmountUnit,report:config.reportAmountUnit});
 function cash(raw:unknown,unit:JiliAmountUnit){const converted=gameAmountToWalletMinor(decimal(raw),unit==='game_points'?scale:1);if(BigInt(converted.amountMinor)>99_999_999_900n)return fail('JILI_AMOUNT_INVALID');return converted;}
 function outgoing(raw:unknown){safeText(raw,/^[1-9]\d{0,10}$/);if(BigInt(raw as string)>99_999_999_900n)return fail('JILI_AMOUNT_INVALID');return walletMinorToGameAmount(raw as string,unitConfig.transfer==='game_points'?scale:1);}
 async function request(method:string,fields:readonly (readonly [string,string])[],optional:readonly (readonly [string,string])[]=[],maximum=64*1024){
  const signed=[...fields,['AgentId',agentId] as const],query=signed.map(([key,value])=>`${key}=${value}`).join('&');
  const body=new URLSearchParams([...signed,...optional,['Key',jiliSignature(query,agentId,agentKey,clock())] as const].map(([key,value])=>[key,value])).toString();
  try{return await responseObject(await transport(`${endpoint}/${method}`,{method:'POST',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(12_000),headers:{Accept:'application/json','Content-Type':'application/x-www-form-urlencoded'},body}),maximum);}catch(e){if(e instanceof JiliProtocolError)throw e;return fail('JILI_PROVIDER_UNAVAILABLE');}
 }
 async function player(playerId:string){
  member(playerId);const r=await request('GetMemberInfo',[['Accounts',playerId]]);
  if(r.code!==0||!Array.isArray(r.data)||r.data.length!==1||!object(r.data[0])||r.data[0].Account!==playerId)return fail('JILI_PLAYER_UNVERIFIED');
  const status=integer(r.data[0].Status,3);if(status!==1&&status!==2&&status!==3)return fail('JILI_PLAYER_UNVERIFIED');
  const converted=cash(r.data[0].Balance,unitConfig.balance);return {exists:status!==3,online:status===1,...converted};
 }
 function transferBinding(input:JiliTransfer){
  if(!input||!['deposit','withdrawal'].includes(input.direction))return fail('JILI_TRANSFER_INPUT_INVALID');
  member(input.playerId);serial(input.transactionId);if(input.providerTransactionId!==undefined&&input.providerTransactionId!==input.transactionId)return fail('JILI_TRANSFER_REFERENCE_MISMATCH');
  if(input.amountMinor!==undefined)outgoing(input.amountMinor);
  if(input.direction==='deposit'&&input.amountMinor===undefined)return fail('JILI_TRANSFER_INPUT_INVALID');
 }
 async function queryTransfer(input:JiliTransfer):Promise<JiliReceipt>{
  transferBinding(input);
  let r;try{r=await request('CheckTransferByTransactionId',[['TransactionId',input.transactionId]]);}catch{return unknown();}
  if(r.code!==0||!object(r.data))return unknown();
  const data=r.data;
  if(data.Account!==input.playerId||data.TransactionId!==input.transactionId||data.TransferType!==(input.direction==='deposit'?'2':'1')||data.Status!=='1')return unknown('JILI_TRANSFER_BINDING_MISMATCH');
  let result;try{result=cash(data.Amount,unitConfig.query);}catch{return unknown('JILI_TRANSFER_AMOUNT_REVIEW');}
  if(result.residual||(input.amountMinor!==undefined&&result.amountMinor!==input.amountMinor))return unknown('JILI_TRANSFER_AMOUNT_REVIEW');
  return {state:'confirmed',providerTransactionId:input.transactionId,amountMinor:result.amountMinor,requiresLedgerReconciliation:true};
 }
 async function transfer(input:JiliTransfer):Promise<JiliReceipt>{
  transferBinding(input);
  if(input.direction==='withdrawal'&&input.amountMinor!==undefined)return fail('JILI_SWEEP_AMOUNT_NOT_ALLOWED');
  let r;try{r=await request('ExchangeTransferByAgentId',[['Account',input.playerId],['TransactionId',input.transactionId],['Amount',input.direction==='deposit'?outgoing(input.amountMinor):'0'],['TransferType',input.direction==='deposit'?'2':'1']]);}catch{return unknown();}
  if(r.code===0){if(!object(r.data)||r.data.TransactionId!==input.transactionId||r.data.Status!=='1')return unknown('JILI_TRANSFER_RECEIPT_INVALID');return queryTransfer(input);}
  // Merchant-specific terminal semantics are unverified. Every provider error
  // remains query-only: releasing funds could permit a second transaction
  // while the first transaction's outcome is still uncertain.
  return unknown(`JILI_${r.code}`);
 }
 async function listGames(){
  const r=await request('GetGameList',[],[],2*1024*1024);if(r.code!==0||!Array.isArray(r.data)||r.data.length>5000)return fail('JILI_CATALOGUE_UNAVAILABLE');
  const seen=new Set<string>();return r.data.map(row=>{
   if(!object(row)||!object(row.name))return fail('JILI_RESPONSE_INVALID');const id=String(integer(row.GameId)),category=String(integer(row.GameCategoryId));
   if(id==='0'||seen.has(id)||typeof row.name['en-US']!=='string'||!row.name['en-US'].trim()||row.name['en-US'].length>200)return fail('JILI_RESPONSE_INVALID');seen.add(id);
   return {providerGameId:id,name:row.name['en-US'],category,maintenance:false};
  });
 }
 async function createPlayer(playerId:string){member(playerId);const r=await request('CreateMember',[['Account',playerId]]);if(r.code!==0&&r.code!==101)return fail('JILI_PLAYER_CREATE_UNCONFIRMED');return {created:r.code===0};}
 async function kick(playerId:string){member(playerId);const r=await request('KickMember',[['Account',playerId]]);if(r.code!==0&&r.code!==102)return fail('JILI_SESSION_CLOSURE_UNKNOWN');}
 async function launch(playerId:string,gameId:string,language:'en'|'zh'|'ms',returnUrl:string){
  member(playerId);safeText(gameId,/^[1-9]\d{0,6}$/);const lang={en:'en-US',zh:'zh-CN',ms:'en-US'}[language];if(!lang)return fail('JILI_LANGUAGE_INVALID');
  const r=await request('LoginWithoutRedirect',[['Account',playerId],['GameId',gameId],['Lang',lang]],[['HomeUrl',returnUrl],['platform','web']]);
  if(r.code!==0||typeof r.data!=='string'||r.data.length>4096)return fail('JILI_LAUNCH_UNCONFIRMED');
  let url:URL;try{url=new URL(r.data);}catch{return fail('JILI_LAUNCH_URL_INVALID');}
  if(!launchOrigins.has(url.origin)||url.protocol!=='https:'||url.username||url.password||url.hash)return fail('JILI_LAUNCH_URL_INVALID');return {launchUrl:url.href};
 }
 function reportDate(epoch:number){return new Date(epoch-4*60*60_000).toISOString().slice(0,19);}
 async function wagers(from:number,to:number,cursor?:string){
  if(!Number.isSafeInteger(from)||!Number.isSafeInteger(to)||from%1000!==0||to%1000!==0||from<0||to<=from||to-from>30*60_000||to>clock()-10*60_000)return fail('JILI_REPORT_WINDOW_INVALID');
  const binding=createHash('sha256').update(JSON.stringify([profile,from,to])).digest('hex').slice(0,24),pattern=new RegExp(`^jili:${binding}:([1-9]\\d{0,5})$`),match=cursor===undefined?null:pattern.exec(cursor);
  if(cursor!==undefined&&!match)return fail('JILI_REPORT_CURSOR_INVALID');const page=match?Number(match[1]):1,limit=10000;
  const r=await request('GetBetRecordByTime',[['StartTime',reportDate(from)],['EndTime',reportDate(to)],['Page',String(page)],['PageLimit',String(limit)]],[],8*1024*1024);
  if(r.code!==0||!object(r.data)||!Array.isArray(r.data.Result)||!object(r.data.Pagination))return fail('JILI_REPORT_UNAVAILABLE');
  const p=r.data.Pagination,pages=integer(p.TotalPages),total=integer(p.TotalNumber,100_000_000),current=integer(p.CurrentPage),pageLimit=integer(p.PageLimit,25000),rows=r.data.Result;
  if(current!==page||pageLimit!==limit||pages!==Math.ceil(total/limit)||(total===0?page!==1:page>pages)||rows.length!==Math.min(limit,Math.max(0,total-(page-1)*limit)))return fail('JILI_REPORT_PAGINATION_INVALID');
  const seen=new Set<string>(),items=rows.map(row=>{
   if(!object(row)||row.AgentId!==agentId||!['1','2','3'].includes(String(row.Status)))return fail('JILI_REPORT_BINDING_INVALID');
   const playerId=member(row.Account),gameId=String(integer(row.GameId)),betId=safeText(row.WagersId,/^[1-9]\d{0,19}$/),key=gameId+':'+betId;
   if(seen.has(key))return fail('JILI_REPORT_DUPLICATE');seen.add(key);
   const bet=cash(row.BetAmount,unitConfig.report),win=cash(row.PayoffAmount,unitConfig.report);if(bet.residual||win.residual)return fail('JILI_REPORT_AMOUNT_REVIEW');
   const time=safeText(row.SettlementTime,/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:-04:00)?$/),settledAt=Date.parse(time.endsWith('-04:00')?time:time+'-04:00');
   if(!Number.isFinite(settledAt)||settledAt<from||settledAt>to||new Date(settledAt-4*60*60_000).toISOString().slice(0,19)!==time.slice(0,19))return fail('JILI_REPORT_TIME_REVIEW');
   const round=row.RoundIndex===undefined||row.RoundIndex===null?null:safeText(row.RoundIndex,/^[1-9]\d{0,19}$/);
   return {providerRoundId:round,providerBetId:betId,providerPlayerId:playerId,providerGameId:gameId,betMinor:bet.amountMinor,winMinor:win.amountMinor,currency:'MYR' as const,settledAt,sourceDetails:Object.freeze({settlementTime:time,timeBasis:'GMT-4',amountUnit:unitConfig.report,bet:decimal(row.BetAmount),win:decimal(row.PayoffAmount)})};
  });
  return {items,complete:page>=pages,...(page<pages?{nextCursor:`jili:${binding}:${page+1}`}:{})};
 }
 return Object.freeze({listGames,player,createPlayer,kick,launch,transfer,queryTransfer,wagers});
}
