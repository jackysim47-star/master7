import {createHash,randomUUID} from 'node:crypto';
import {clearStaleReservation,hasProtectedGameReservation,withdrawalWalletState} from './withdrawals.ts';
import {walletGuardStatements,walletGuardedReservation,walletGuardedRiskCheck,walletGuardedMegaLaunch} from './wallet-guard.ts';
import {megaClosureProofSql,validMegaClosureReceipt,MEGA_CLOSURE_EVENT,type MegaSessionCloser,type MegaAcceptanceCapabilities} from './mega-session-closure.ts';

type Member={id:string;username:string;role:string;approved:number};
export type MegaWalletContext={
 db:D1Database;user:Member;gatewayUrl?:string;gameToken?:string;walletToken?:string;
 enabled?:string;liveGamesEnabled?:string;newGameLaunchesEnabled?:string;settlementVerified?:string;fetchImpl?:typeof fetch;
 launchOriginsJson?:string;
 acceptance?:MegaAcceptanceCapabilities;closeSession?:MegaSessionCloser;closureContractVerified?:boolean;
};

type GatewayOutcome=
 |{kind:'success';result:any}
 |{kind:'rejected';code:string}
 |{kind:'unknown'};

const gatewayOrigin='https://master7-integration-gateway.onrender.com';
const openStatuses="'deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review'";
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};

export class MegaWalletError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

const tokenReady=(value?:string)=>typeof value==='string'&&Buffer.byteLength(value)>=32&&Buffer.byteLength(value)<=1024;
export function megaLaunchOrigins(value?:string){
 if(typeof value!=='string'||Buffer.byteLength(value)>4096)return null;
 let raw:unknown;try{raw=JSON.parse(value);}catch{return null;}
 if(!Array.isArray(raw)||raw.length===0||raw.length>50)return null;
 const origins=new Set<string>();
 for(const item of raw){
  if(typeof item!=='string'||item!==item.trim()||Buffer.byteLength(item)>512)return null;
  let url:URL;try{url=new URL(item);}catch{return null;}
  if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash||!url.hostname||url.hostname.includes('*'))return null;
  if(origins.has(url.origin))return null;origins.add(url.origin);
 }
 return origins;
}
export function megaLaunchOriginAllowed(value:string|undefined,url:URL){
 const origins=megaLaunchOrigins(value);
 return origins?.has(url.origin)===true&&url.protocol==='https:'&&!url.username&&!url.password&&!url.hash;
}
export function megaWalletConfigured(c:MegaWalletContext){
 return c.gatewayUrl===gatewayOrigin&&tokenReady(c.gameToken)&&tokenReady(c.walletToken)&&c.gameToken!==c.walletToken;
}
export type MegaWalletCapability={availabilityMode:'automatic';readOnlyAvailability:true;configured:boolean;launchReady:boolean;walletReady:boolean;catalogueVerified:boolean;recoveryVerified:boolean;launchVerified:boolean;walletVerified:boolean;settlementVerified:boolean;capabilitySource:'gateway_configuration';capabilityReason:string};
export async function megaWalletCapabilities(c:MegaWalletContext):Promise<MegaWalletCapability>{
 const result:MegaWalletCapability={availabilityMode:'automatic',readOnlyAvailability:true,configured:megaWalletConfigured(c),launchReady:false,walletReady:false,catalogueVerified:false,recoveryVerified:false,launchVerified:false,walletVerified:false,settlementVerified:false,capabilitySource:'gateway_configuration',capabilityReason:'connection_not_configured'};
 if(!result.configured)return result;
 if(!megaLaunchOrigins(c.launchOriginsJson))return {...result,capabilityReason:'launch_origin_allowlist_unavailable'};
 // This existing endpoint reads gateway configuration only. It never creates a
 // player, launches a game or transfers money, and is not an acceptance test.
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
 try{
  const response=await(c.fetchImpl??fetch)(`${gatewayOrigin}/readiness`,{method:'GET',headers:{Accept:'application/json'},cache:'no-store',redirect:'error',signal:controller.signal});
  if(!response.ok||response.redirected||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')??''))return {...result,capabilityReason:'gateway_capability_unavailable'};
  const raw=await response.text();if(Buffer.byteLength(raw)>65536)return {...result,capabilityReason:'gateway_capability_invalid'};
  const data=JSON.parse(raw),mega=data?.megah5Transfer;
  if(data?.service!=='master7-integration-gateway'||data?.scope!=='configuration_only'||mega?.mode!=='fund_transfer')return {...result,capabilityReason:'gateway_capability_invalid'};
  if(mega.credentialsConfigured!==true||mega.walletTokenConfigured!==true)return {...result,capabilityReason:'gateway_credentials_not_ready'};
  // Recovery and cash-out are required before any new deposit. A gateway
  // reporting only an enabled switch cannot establish these capabilities.
  if(!['status','deposit','withdrawal'].every(name=>mega.channels?.[name]?.configurationReady===true&&Array.isArray(mega.channels[name].blockers)&&mega.channels[name].blockers.length===0))return {...result,capabilityReason:'gateway_wallet_contract_unavailable'};
  const launchVerified=c.acceptance?.launch===true,walletVerified=c.acceptance?.wallet===true,closureReady=c.closureContractVerified===true&&typeof c.closeSession==='function',settlementVerified=closureReady&&c.acceptance?.settlement===true&&c.acceptance?.recovery===true;
  return {...result,launchReady:c.newGameLaunchesEnabled==='true',walletReady:true,catalogueVerified:c.acceptance?.catalogue===true,recoveryVerified:closureReady&&c.acceptance?.recovery===true,launchVerified,walletVerified,settlementVerified,capabilityReason:c.newGameLaunchesEnabled!=='true'?'new_game_launches_paused':!closureReady?'session_closure_contract_unavailable':!launchVerified||!walletVerified||!settlementVerified||c.acceptance?.catalogue!==true?'acceptance_pending':'ready'};
 }catch{return {...result,capabilityReason:'gateway_capability_unavailable'};}finally{clearTimeout(timer);}
}
export async function megaWalletLiveReady(c:MegaWalletContext){return (await megaWalletCapabilities(c)).walletReady;}

export function megaPlayerId(userId:string){return `m7_${createHash('sha256').update(userId).digest('hex').slice(0,32)}`;}
const stamp=()=>Math.floor(Date.now()/1000);
const reference=(prefix:string)=>`${prefix}_${randomUUID().replaceAll('-','')}`;
const money=(minor:bigint)=>`${minor/100n}.${String(minor%100n).padStart(2,'0')}`;

function providerAmount(value:unknown){
 const raw=String(value??'');if(!/^(?:0|[1-9]\d{0,9})(?:\.\d{1,4})?$/.test(raw))return null;
 const [whole,fraction='']=raw.split('.'),digits=fraction.padEnd(4,'0'),minor=BigInt(whole)*100n+BigInt(digits.slice(0,2));
 return {minor,residual:digits.slice(2)!=='00',raw};
}

async function gateway(c:MegaWalletContext,path:string,token:string,payload:Record<string,unknown>):Promise<GatewayOutcome>{
 if(c.gatewayUrl!==gatewayOrigin||!tokenReady(token))return {kind:'rejected',code:'configuration'};
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.fetchImpl??fetch)(`${gatewayOrigin}${path}`,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(payload),redirect:'error',signal:controller.signal});
  if(response.redirected)return {kind:'unknown'};
  const type=response.headers.get('content-type')??'';if(!/^application\/json(?:;|$)/i.test(type))return {kind:'unknown'};
  const raw=await response.text();if(Buffer.byteLength(raw)>65536)return {kind:'unknown'};let data:any;try{data=JSON.parse(raw);}catch{return {kind:'unknown'};}
  const providerStatus=Number(data?.result?.Status);
  if(response.ok&&providerStatus===200){
   // The internal gateway identifies its provider on every successful route.
   // A different or missing provider leaves the financial outcome unknown.
   if(data?.provider!=='megah5')return {kind:'unknown'};
   // The internal transfer routes echo operation and the unique request
   // reference. A different or missing echo cannot prove this movement.
   if(path==='/platform/megah5/deposit'||path==='/platform/megah5/withdraw'){
    const operation=path.endsWith('/deposit')?'deposit':'withdraw';
    if(data.operation!==operation||typeof payload.referenceId!=='string'||data.referenceId!==payload.referenceId)return {kind:'unknown'};
   }
   // The status route has an operation discriminator but does not echo a
   // reference at the gateway envelope; provider response checks follow below.
   if(path==='/platform/megah5/transfer-status'&&data.operation!=='transfer_status')return {kind:'unknown'};
   return {kind:'success',result:data.result};
  }
  // A gateway timeout or upstream 5xx can happen after the provider accepted a
  // money movement. Keep the transfer reserved for status recovery instead of
  // treating an ambiguous response as a safe rejection and releasing funds.
  if(!response.ok){
   if(response.status>=500||response.status===408||response.status===429)return {kind:'unknown'};
   if([400,401,403,404,409,422].includes(response.status)&&typeof data?.error==='string')return {kind:'rejected',code:'gateway_rejected'};
   return {kind:'unknown'};
  }
  if(Number.isFinite(providerStatus))return {kind:'rejected',code:`provider_${providerStatus}`};
  return {kind:'unknown'};
 }catch{return {kind:'unknown'};}finally{clearTimeout(timer);}
}

async function balance(c:MegaWalletContext,playerId:string){
 const result=await gateway(c,'/platform/megah5/balance',c.gameToken!,{playerId});
 if(result.kind!=='success')throw new MegaWalletError(503,'MegaH5 balance check is temporarily unavailable');
 // Older documented responses may omit currency. A supplied currency must
 // match this MYR profile; never treat an explicit foreign value as ringgit.
 if(result.result?.Currency!==undefined&&result.result.Currency!=='MYR')throw new MegaWalletError(409,'MegaH5 currency requires manual reconciliation');
 const parsed=providerAmount(result.result?.CurrentBalance);if(!parsed)throw new MegaWalletError(502,'MegaH5 returned an invalid balance');
 return parsed;
}

async function session(db:D1Database,userId:string,openOnly=true){
 return db.prepare(`SELECT s.*,CAST(l.amount_minor AS TEXT) result_minor,(SELECT o.state FROM megah5_launch_operations o WHERE o.wallet_session_id=s.id) launch_state FROM game_wallet_sessions s LEFT JOIN game_wallet_ledger l ON l.session_id=s.id WHERE s.user_id=? AND s.provider='megah5' ${openOnly?`AND s.status IN (${openStatuses})`:''} ORDER BY s.created_at DESC,s.id DESC LIMIT 1`).bind(userId).first<any>();
}

function memberSession(row:any,closureReady=false){return row?{
 id:row.id,provider:'megah5',gameCode:row.game_code,status:row.status,amountOutMinor:String(row.amount_out_minor),
 amountReturnedMinor:row.amount_returned_minor==null?null:String(row.amount_returned_minor),resultMinor:row.result_minor==null?null:String(row.result_minor),
 launchState:row.launch_state??null,settlementBlocked:row.launch_state!=null&&row.launch_state!=='closed'&&!(closureReady&&['issued','unknown'].includes(row.launch_state)),
 recoveryRequired:['deposit_unknown','withdraw_unknown','manual_review'].includes(row.status),createdAt:Number(row.created_at),updatedAt:Number(row.updated_at),settledAt:row.settled_at==null?null:Number(row.settled_at),
}:null;}

function adminSession(row:any,closureReady=false){return {...memberSession(row,closureReady),userId:row.user_id,username:row.username,playerId:row.player_id,depositReference:row.deposit_reference,withdrawReference:row.withdraw_reference??null,providerResidual:row.provider_residual??''};}

async function audit(c:MegaWalletContext,event:string,target:string){await c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,event,target,stamp()).run();}
const changed=(value:any)=>Number(value?.meta?.changes??value?.changes??0);

// A launch without a new transfer still needs an authorization point after
// taking the same member lock as reconciliation and other wallet changes.
async function authorizeLaunch(c:MegaWalletContext,existing:{id:string;game_code:string}){
 const results=await c.db.batch([
  ...walletGuardStatements(c.db,c.user.id),walletGuardedRiskCheck(c.db,c.user.id),
  c.db.prepare("UPDATE game_wallet_sessions SET updated_at=updated_at WHERE id=? AND user_id=? AND game_code=? AND status='active'").bind(existing.id,c.user.id,existing.game_code),
 ]);
 if(changed(results[2])!==1||changed(results[3])!==1)throw new MegaWalletError(409,'Wallet reconciliation is required before starting a game');
}

export async function memberMegaWalletState(c:MegaWalletContext){
 const current=await session(c.db,c.user.id,false),wallet=await withdrawalWalletState(c.db,c.user.id);
 const capability=await megaWalletCapabilities(c),liveReady=capability.launchReady&&capability.catalogueVerified&&capability.launchVerified&&capability.walletVerified&&capability.settlementVerified&&capability.recoveryVerified;
 return {provider:'megah5',currency:'MYR',...capability,launchReady:liveReady,capabilityReason:capability.launchReady&&!liveReady&&capability.capabilityReason==='ready'?'acceptance_pending':capability.capabilityReason,enabled:liveReady,liveReady,wallet,session:memberSession(current,c.closureContractVerified===true&&typeof c.closeSession==='function')};
}

export async function adminMegaWalletSessions(c:MegaWalletContext){
 const result=await c.db.prepare(`SELECT s.*,u.username,CAST(l.amount_minor AS TEXT) result_minor,(SELECT o.state FROM megah5_launch_operations o WHERE o.wallet_session_id=s.id) launch_state FROM game_wallet_sessions s JOIN users u ON u.id=s.user_id LEFT JOIN game_wallet_ledger l ON l.session_id=s.id WHERE s.provider='megah5' ORDER BY s.created_at DESC,s.id DESC LIMIT 500`).all<any>();
 const capability=await megaWalletCapabilities(c),liveReady=capability.launchReady&&capability.catalogueVerified&&capability.launchVerified&&capability.walletVerified&&capability.settlementVerified&&capability.recoveryVerified;
 return {provider:'megah5',...capability,launchReady:liveReady,capabilityReason:capability.launchReady&&!liveReady&&capability.capabilityReason==='ready'?'acceptance_pending':capability.capabilityReason,enabled:liveReady,liveReady,items:(result.results??[]).map(row=>adminSession(row,c.closureContractVerified===true&&typeof c.closeSession==='function'))};
}

/** Persist the unique in-flight attempt before any provider game request. */
export async function claimMegaLaunch(c:MegaWalletContext,sessionId:string,gameCode:string){
 const id=randomUUID(),created=stamp();
 const result=await c.db.batch([...walletGuardStatements(c.db,c.user.id),walletGuardedMegaLaunch(c.db,{userId:c.user.id,walletSessionId:sessionId,gameCode,operationId:id,createdAt:created})]);
 if(changed(result[2])!==1)throw new MegaWalletError(409,'Game launch is unavailable or requires reconciliation');
 return {id};
}

/** A successful GameLogin still does not prove the provider session is closed. */
export async function markMegaLaunchIssued(c:MegaWalletContext,id:string,sessionId:string){
 const result=await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare(`UPDATE megah5_launch_operations SET state='issued',updated_at=? WHERE id=? AND wallet_session_id=? AND user_id=? AND state='launching' AND EXISTS (SELECT 1 FROM game_wallet_sessions s WHERE s.id=megah5_launch_operations.wallet_session_id AND s.user_id=megah5_launch_operations.user_id AND s.game_code=megah5_launch_operations.game_code AND s.status='active')`).bind(stamp(),id,sessionId,c.user.id)]);
 if(changed(result[2])!==1)throw new MegaWalletError(409,'Game launch requires reconciliation');
}

/** Never infer that an unconfirmed GameLogin was rejected or safely closed. */
export async function markMegaLaunchUnknown(c:MegaWalletContext,id:string,sessionId:string){
 await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE megah5_launch_operations SET state='unknown',last_error='launch_unconfirmed',updated_at=? WHERE id=? AND wallet_session_id=? AND user_id=? AND state='launching'").bind(stamp(),id,sessionId,c.user.id)]);
}

export async function prepareMegaWallet(c:MegaWalletContext,gameCode:string){
 if(c.newGameLaunchesEnabled!=='true')throw new MegaWalletError(503,'New game launches are temporarily unavailable');
 if(!await megaWalletLiveReady(c))throw new MegaWalletError(503,'MegaH5 wallet connection or transfer/recovery capability is unavailable');
 await clearStaleReservation(c.db,c.user.id);
 if(await hasProtectedGameReservation(c.db,c.user.id))throw new MegaWalletError(409,'Finish or recover the existing game wallet before starting another game');
 const existing=await session(c.db,c.user.id,true);
 if(existing){
  if(existing.status==='active'&&existing.game_code===gameCode){await authorizeLaunch(c,existing);return {walletVerified:true,sessionId:existing.id,amountOutMinor:String(existing.amount_out_minor),reused:true};}
  if(existing.status==='active')throw new MegaWalletError(409,'Finish the active MegaH5 game before starting another game');
  throw new MegaWalletError(409,'MegaH5 wallet recovery is required before another game starts');
 }
 const playerId=megaPlayerId(c.user.id),providerBalance=await balance(c,playerId);
 if(providerBalance.minor!==0n||providerBalance.residual)throw new MegaWalletError(409,'MegaH5 provider balance requires reconciliation');
 const wallet=await withdrawalWalletState(c.db,c.user.id);
 if(wallet.reconciliationRequired)throw new MegaWalletError(409,'Wallet reconciliation is required before starting a game');
 const amount=BigInt(wallet.availableMinor);
 // Without a funded transfer there is no durable MegaH5 wallet session to
 // recover or settle any later game balance. Refuse to open an untracked game.
 if(amount===0n)throw new MegaWalletError(409,'Add funds to your wallet before starting this game');
 const id=randomUUID(),depositReference=reference('m7d'),created=stamp();
 try{
  const results=await c.db.batch([
   ...walletGuardStatements(c.db,c.user.id),
   walletGuardedReservation(c.db,{userId:c.user.id,kind:'game',referenceId:id,amountMinor:amount.toString(),createdAt:created}),
   c.db.prepare(`INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at)
    SELECT ?,?,'megah5',?,?,'deposit_pending',?,?,?,? WHERE EXISTS
     (SELECT 1 FROM wallet_reservations WHERE user_id=? AND kind='game' AND reference_id=? AND amount_minor=CAST(? AS BIGINT))`).bind(id,c.user.id,playerId,gameCode,amount.toString(),depositReference,created,created,c.user.id,id,amount.toString()),
  ]);
  if(changed(results[2])!==1||changed(results[3])!==1)throw new MegaWalletError(409,'Wallet balance or reconciliation state changed; retry after review');
 }catch(error:any){if(/unique|duplicate/i.test(String(error?.message??'')))throw new MegaWalletError(409,'A wallet operation is already in progress');throw error;}
 const outcome=await gateway(c,'/platform/megah5/deposit',c.walletToken!,{playerId,amount:money(amount),referenceId:depositReference});
 if(outcome.kind==='success'){
  await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='active',updated_at=? WHERE id=? AND status='deposit_pending'").bind(stamp(),id)]);
  const confirmed=await c.db.prepare("SELECT id FROM game_wallet_sessions WHERE id=? AND user_id=? AND status='active' AND deposit_reference=?").bind(id,c.user.id,depositReference).first();
  if(!confirmed)throw new MegaWalletError(409,'MegaH5 wallet transfer requires reconciliation');
  await audit(c,'megah5_deposit_confirmed',id);
  return {walletVerified:true,sessionId:id,amountOutMinor:amount.toString(),reused:false};
 }
 if(outcome.kind==='rejected'){
  await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='deposit_failed',last_error=?,updated_at=? WHERE id=? AND status='deposit_pending'").bind(outcome.code,stamp(),id),c.db.prepare("DELETE FROM wallet_reservations WHERE kind='game' AND reference_id=? AND EXISTS (SELECT 1 FROM game_wallet_sessions WHERE id=? AND status='deposit_failed')").bind(id,id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,'megah5_deposit_rejected',id,stamp())]);
  throw new MegaWalletError(502,'MegaH5 wallet transfer was rejected');
 }
 await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='deposit_unknown',last_error='transport_unknown',updated_at=? WHERE id=? AND status='deposit_pending'").bind(stamp(),id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,'megah5_deposit_unknown',id,stamp())]);
 throw new MegaWalletError(503,'MegaH5 wallet transfer needs recovery');
}

async function finalize(c:MegaWalletContext,row:any,returned:bigint){
 const launched=await c.db.prepare('SELECT id FROM megah5_launch_operations WHERE wallet_session_id=? AND user_id=?').bind(row.id,c.user.id).first();
 if(launched){const remaining=await balance(c,row.player_id);if(remaining.minor!==0n||remaining.residual)throw new MegaWalletError(409,'MegaH5 provider balance must be zero before final settlement');}
 const updated=stamp(),result=returned-BigInt(row.amount_out_minor);
 await c.db.batch([
  ...walletGuardStatements(c.db,c.user.id),
  c.db.prepare(`UPDATE game_wallet_sessions SET status='settled',amount_returned_minor=?,updated_at=?,settled_at=? WHERE id=? AND status IN ('withdraw_pending','withdraw_unknown') AND NOT EXISTS (SELECT 1 FROM megah5_launch_operations o WHERE o.wallet_session_id=game_wallet_sessions.id AND (o.state<>'closed' OR NOT ${megaClosureProofSql('o')})) AND NOT EXISTS (SELECT 1 FROM game_wallet_ledger l WHERE l.session_id=game_wallet_sessions.id AND (l.user_id<>game_wallet_sessions.user_id OR l.account_code<>'game_result' OR l.currency<>'MYR' OR l.amount_minor<>?))`).bind(returned.toString(),updated,updated,row.id,result.toString()),
  c.db.prepare(`INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'game_result',?,'MYR',? FROM game_wallet_sessions WHERE id=? AND status='settled' AND amount_returned_minor=? AND amount_out_minor=? AND NOT EXISTS (SELECT 1 FROM megah5_launch_operations o WHERE o.wallet_session_id=game_wallet_sessions.id AND (o.state<>'closed' OR NOT ${megaClosureProofSql('o')})) ON CONFLICT(session_id) DO NOTHING`).bind(randomUUID(),result.toString(),updated,row.id,returned.toString(),String(row.amount_out_minor)),
  c.db.prepare(`DELETE FROM wallet_reservations WHERE kind='game' AND reference_id=? AND amount_minor=? AND NOT EXISTS (SELECT 1 FROM megah5_launch_operations o WHERE o.wallet_session_id=wallet_reservations.reference_id AND (o.state<>'closed' OR NOT ${megaClosureProofSql('o')})) AND EXISTS (SELECT 1 FROM game_wallet_sessions s JOIN game_wallet_ledger l ON l.session_id=s.id AND l.user_id=s.user_id WHERE s.id=? AND s.user_id=wallet_reservations.user_id AND s.status='settled' AND s.amount_returned_minor=? AND s.amount_out_minor=? AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=?)`).bind(row.id,String(row.amount_out_minor),row.id,returned.toString(),String(row.amount_out_minor),result.toString()),
 ]);
 const finished=await c.db.prepare(`SELECT s.*,CAST(l.amount_minor AS TEXT) result_minor FROM game_wallet_sessions s JOIN game_wallet_ledger l ON l.session_id=s.id AND l.user_id=s.user_id WHERE s.id=? AND s.user_id=? AND s.status='settled' AND s.amount_returned_minor=? AND s.amount_out_minor=? AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=? AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.kind='game' AND r.reference_id=s.id) AND NOT EXISTS (SELECT 1 FROM megah5_launch_operations o WHERE o.wallet_session_id=s.id AND (o.state<>'closed' OR NOT ${megaClosureProofSql('o')}))`).bind(row.id,c.user.id,returned.toString(),String(row.amount_out_minor),result.toString()).first<any>();
 if(!finished)throw new MegaWalletError(409,'MegaH5 settlement requires reconciliation');
 await audit(c,'megah5_wallet_settled',row.id);
 return memberSession(finished);
}

async function ensureMegaLaunchClosed(c:MegaWalletContext,walletSessionId:string){
 const launch=await c.db.prepare('SELECT o.*,s.player_id,s.status wallet_status FROM megah5_launch_operations o JOIN game_wallet_sessions s ON s.id=o.wallet_session_id AND s.user_id=o.user_id AND s.game_code=o.game_code WHERE o.wallet_session_id=? AND o.user_id=?').bind(walletSessionId,c.user.id).first<any>();
 if(!launch)return;
 const proved=()=>c.db.prepare(`SELECT o.id FROM megah5_launch_operations o WHERE o.id=? AND o.wallet_session_id=? AND o.user_id=? AND o.state='closed' AND ${megaClosureProofSql('o')}`).bind(launch.id,walletSessionId,c.user.id).first();
 if(launch.state==='closed'){if(await proved())return;throw new MegaWalletError(409,'Game session closure evidence is missing');}
 if(!['issued','unknown'].includes(launch.state)||launch.wallet_status!=='active'||c.closureContractVerified!==true||typeof c.closeSession!=='function')throw new MegaWalletError(409,'Game session closure requires reconciliation before settlement');
 const input={walletSessionId,launchOperationId:String(launch.id),providerPlayerId:String(launch.player_id),gameCode:String(launch.game_code)};
 let outcome;try{outcome=await c.closeSession(input);}catch{throw new MegaWalletError(409,'Provider game closure remains unconfirmed');}
 if(outcome?.state!=='closed'||!validMegaClosureReceipt(input,outcome.receipt))throw new MegaWalletError(409,'Provider game closure remains unconfirmed');
 const receipt={...input,providerClosureReference:outcome.receipt.providerClosureReference,allIssuedLaunchesInvalidated:true,pendingRounds:0,lateResultsFinal:true},digest=createHash('sha256').update(JSON.stringify(receipt)).digest('hex'),target=`${walletSessionId}:${launch.id}:${digest}`,at=stamp();
 await c.db.batch([...walletGuardStatements(c.db,c.user.id),
  c.db.prepare("UPDATE megah5_launch_operations SET state='closed',last_error='',updated_at=? WHERE id=? AND wallet_session_id=? AND user_id=? AND state IN ('issued','unknown') AND EXISTS(SELECT 1 FROM game_wallet_sessions s WHERE s.id=megah5_launch_operations.wallet_session_id AND s.user_id=megah5_launch_operations.user_id AND s.status='active')").bind(at,launch.id,walletSessionId,c.user.id),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM megah5_launch_operations WHERE id=? AND wallet_session_id=? AND user_id=? AND state='closed') AND NOT EXISTS(SELECT 1 FROM audit WHERE user_id=? AND event=? AND target=?)").bind(randomUUID(),c.user.id,MEGA_CLOSURE_EVENT,target,at,launch.id,walletSessionId,c.user.id,c.user.id,MEGA_CLOSURE_EVENT,target),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'megah5_session_closure_reference',?,? WHERE EXISTS(SELECT 1 FROM audit WHERE user_id=? AND event=? AND target=?)").bind(randomUUID(),c.user.id,`${walletSessionId}:${launch.id}:${receipt.providerClosureReference}`,at,c.user.id,MEGA_CLOSURE_EVENT,target),
 ]);
 if(!await proved())throw new MegaWalletError(409,'Game session closure changed during reconciliation');
}

export async function settleMegaWallet(c:MegaWalletContext,expectedSessionId?:string){
 if(!megaWalletConfigured(c))throw new MegaWalletError(503,'MegaH5 wallet recovery connection is unavailable');
 let current=await session(c.db,c.user.id,true);if(!current)return {status:'none',session:null};
 if(expectedSessionId&&current.id!==expectedSessionId)throw new MegaWalletError(409,'The requested game session is no longer current');
 if(current.status!=='active')throw new MegaWalletError(409,'MegaH5 wallet recovery is required');
 if(current.launch_state)await ensureMegaLaunchClosed(c,current.id);
 const providerBalance=await balance(c,current.player_id);
 if(providerBalance.residual){await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',provider_residual=?,last_error='fractional_balance',updated_at=? WHERE id=? AND status='active'").bind(providerBalance.raw,stamp(),current.id)]);throw new MegaWalletError(409,'MegaH5 balance requires manual reconciliation');}
 const withdrawalReference=reference('m7w'),expected=providerBalance.minor;
 const claim=await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare(`UPDATE game_wallet_sessions SET status='withdraw_pending',withdraw_reference=?,expected_return_minor=?,updated_at=? WHERE id=? AND user_id=? AND status='active' AND NOT EXISTS (SELECT 1 FROM megah5_launch_operations o WHERE o.wallet_session_id=game_wallet_sessions.id AND (o.state<>'closed' OR NOT ${megaClosureProofSql('o')}))`).bind(withdrawalReference,expected.toString(),stamp(),current.id,c.user.id)]);
 if(changed(claim[2])!==1)throw new MegaWalletError(409,'MegaH5 settlement is already in progress');
 current={...current,status:'withdraw_pending',withdraw_reference:withdrawalReference,expected_return_minor:expected.toString()};
 if(expected===0n)return {status:'settled',session:await finalize(c,current,0n)};
 const outcome=await gateway(c,'/platform/megah5/withdraw',c.walletToken!,{playerId:current.player_id,amount:money(expected),referenceId:withdrawalReference});
 if(outcome.kind==='success')return {status:'settled',session:await finalize(c,current,expected)};
 if(outcome.kind==='rejected'){
  await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',last_error=?,updated_at=? WHERE id=? AND status='withdraw_pending'").bind(outcome.code,stamp(),current.id)]);
  await audit(c,'megah5_withdraw_rejected',current.id);throw new MegaWalletError(502,'MegaH5 settlement was rejected');
 }
 await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='withdraw_unknown',last_error='transport_unknown',updated_at=? WHERE id=? AND status='withdraw_pending'").bind(stamp(),current.id)]);
 await audit(c,'megah5_withdraw_unknown',current.id);throw new MegaWalletError(503,'MegaH5 settlement needs recovery');
}

export async function recoverMegaWallet(c:MegaWalletContext,expectedSessionId?:string){
 if(!megaWalletConfigured(c))throw new MegaWalletError(503,'MegaH5 wallet recovery connection is unavailable');
 const current=await session(c.db,c.user.id,true);if(!current)return {status:'none',session:null};
 if(expectedSessionId&&current.id!==expectedSessionId)throw new MegaWalletError(409,'The requested game session is no longer current');
 if(current.launch_state)await ensureMegaLaunchClosed(c,current.id);
 let transferType:'deposit'|'withdrawal',referenceId:string;
 if(['deposit_pending','deposit_unknown'].includes(current.status)){transferType='deposit';referenceId=current.deposit_reference;}
 else if(['withdraw_pending','withdraw_unknown'].includes(current.status)){transferType='withdrawal';referenceId=current.withdraw_reference;}
 else return {status:current.status,session:memberSession(current)};
 const outcome=await gateway(c,'/platform/megah5/transfer-status',c.walletToken!,{playerId:current.player_id,referenceId,transferType});
 if(outcome.kind!=='success'){
  const result=await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',last_error='status_unconfirmed',updated_at=? WHERE id=? AND status=? AND (CASE WHEN ?='deposit' THEN deposit_reference ELSE withdraw_reference END)=?").bind(stamp(),current.id,current.status,transferType,referenceId)]);
  if(changed(result[2]))await audit(c,'megah5_recovery_unconfirmed',current.id);throw new MegaWalletError(409,'MegaH5 transfer needs manual reconciliation');
 }
 const amount=providerAmount(outcome.result?.Trans?.Amount);
 const expected=BigInt(transferType==='deposit'?current.amount_out_minor:current.expected_return_minor??-1);
 const result=outcome.result,transaction=result?.Trans;
 const currencyMismatch=[result?.Currency,transaction?.Currency].some(value=>value!==undefined&&value!=='MYR');
 // The provider's documented response need not echo these identifiers. If it
 // does, every supplied field must match the signed status-query parameters.
 const expectedType=transferType==='deposit'?'1':'2';
 const bindingMismatch=[result,transaction].some(value=>value&&typeof value==='object'&&(
  value.ReferenceId!==undefined&&value.ReferenceId!==referenceId||
  value.PlayerId!==undefined&&value.PlayerId!==current.player_id||
  value.TransferType!==undefined&&String(value.TransferType)!==expectedType));
 if(!amount||amount.residual||amount.minor!==expected||currencyMismatch||bindingMismatch){
  const result=await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',last_error=?,updated_at=? WHERE id=? AND status=? AND (CASE WHEN ?='deposit' THEN deposit_reference ELSE withdraw_reference END)=?").bind(bindingMismatch?'binding_mismatch':currencyMismatch?'currency_mismatch':'amount_mismatch',stamp(),current.id,current.status,transferType,referenceId)]);
  if(changed(result[2]))await audit(c,'megah5_recovery_mismatch',current.id);throw new MegaWalletError(409,'MegaH5 transfer amount requires manual reconciliation');
 }
 if(transferType==='deposit'){
  await c.db.batch([...walletGuardStatements(c.db,c.user.id),c.db.prepare("UPDATE game_wallet_sessions SET status='active',last_error='',updated_at=? WHERE id=? AND status=? AND deposit_reference=?").bind(stamp(),current.id,current.status,referenceId)]);
  const active=await c.db.prepare("SELECT * FROM game_wallet_sessions WHERE id=? AND user_id=? AND status='active' AND deposit_reference=?").bind(current.id,c.user.id,referenceId).first<any>();
  if(!active)throw new MegaWalletError(409,'MegaH5 wallet transfer requires reconciliation');
  await audit(c,'megah5_deposit_recovered',current.id);return {status:'active',session:memberSession(active)};
 }
 return {status:'settled',session:await finalize(c,current,amount.minor)};
}

export const megaWalletResponseHeaders=headers;
