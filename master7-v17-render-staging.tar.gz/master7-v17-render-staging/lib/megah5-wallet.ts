import {createHash,randomUUID} from 'node:crypto';
import {clearStaleReservation,withdrawalWalletState} from './withdrawals.ts';

type Member={id:string;username:string;role:string;approved:number};
export type MegaWalletContext={
 db:D1Database;user:Member;gatewayUrl?:string;gameToken?:string;walletToken?:string;
 enabled?:string;liveGamesEnabled?:string;settlementVerified?:string;fetchImpl?:typeof fetch;
};

type GatewayOutcome=
 |{kind:'success';result:any}
 |{kind:'rejected';code:string}
 |{kind:'unknown'};

const gatewayOrigin='https://master7-integration-gateway.onrender.com';
const openStatuses="'deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review'";
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};

export class MegaWalletError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

const tokenReady=(value?:string)=>typeof value==='string'&&Buffer.byteLength(value)>=32&&Buffer.byteLength(value)<=1024;
export function megaWalletConfigured(c:MegaWalletContext){
 return c.enabled==='true'&&c.gatewayUrl===gatewayOrigin&&tokenReady(c.gameToken)&&tokenReady(c.walletToken)&&c.gameToken!==c.walletToken;
}
export function megaWalletLiveReady(c:MegaWalletContext){return megaWalletConfigured(c)&&c.liveGamesEnabled==='true'&&c.settlementVerified==='true';}

export function megaPlayerId(userId:string){return `m7_${createHash('sha256').update(userId).digest('hex').slice(0,32)}`;}
const stamp=()=>Math.floor(Date.now()/1000);
const reference=(prefix:string)=>`${prefix}_${randomUUID().replaceAll('-','')}`;
const money=(minor:bigint)=>`${minor/100n}.${String(minor%100n).padStart(2,'0')}`;

function providerAmount(value:unknown){
 const raw=String(value??'');if(!/^(?:0|[1-9]\d{0,9})(?:\.\d{1,4})?$/.test(raw))return null;
 const [whole,fraction='']=raw.split('.'),digits=fraction.padEnd(4,'0'),minor=BigInt(whole)*100n+BigInt(digits.slice(0,2));
 return {minor,residual:digits.slice(2)!=='00',raw};
}

async function gateway(c:MegaWalletContext,path:string,token:string,payload:Record<string,unknown>):Promise<GatewayOutcome>{
 if(c.gatewayUrl!==gatewayOrigin||!tokenReady(token))return {kind:'rejected',code:'configuration'};
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.fetchImpl??fetch)(`${gatewayOrigin}${path}`,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(payload),redirect:'error',signal:controller.signal});
  if(response.redirected)return {kind:'unknown'};
  const type=response.headers.get('content-type')??'';if(!/^application\/json(?:;|$)/i.test(type))return {kind:'unknown'};
  const raw=await response.text();if(Buffer.byteLength(raw)>65536)return {kind:'unknown'};let data:any;try{data=JSON.parse(raw);}catch{return {kind:'unknown'};}
  const providerStatus=Number(data?.result?.Status);
  if(response.ok&&providerStatus===200)return {kind:'success',result:data.result};
  // A gateway timeout or upstream 5xx can happen after the provider accepted a
  // money movement. Keep the transfer reserved for status recovery instead of
  // treating an ambiguous response as a safe rejection and releasing funds.
  if(!response.ok){
   if(response.status>=500||response.status===408||response.status===429)return {kind:'unknown'};
   if([400,401,403,404,409,422].includes(response.status)&&typeof data?.error==='string')return {kind:'rejected',code:'gateway_rejected'};
   return {kind:'unknown'};
  }
  if(Number.isFinite(providerStatus))return {kind:'rejected',code:`provider_${providerStatus}`};
  return {kind:'unknown'};
 }catch{return {kind:'unknown'};}finally{clearTimeout(timer);}
}

async function balance(c:MegaWalletContext,playerId:string){
 const result=await gateway(c,'/platform/megah5/balance',c.gameToken!,{playerId});
 if(result.kind!=='success')throw new MegaWalletError(503,'MegaH5 balance check is temporarily unavailable');
 const parsed=providerAmount(result.result?.CurrentBalance);if(!parsed)throw new MegaWalletError(502,'MegaH5 returned an invalid balance');
 return parsed;
}

async function session(db:D1Database,userId:string,openOnly=true){
 return db.prepare(`SELECT s.*,CAST(l.amount_minor AS TEXT) result_minor FROM game_wallet_sessions s LEFT JOIN game_wallet_ledger l ON l.session_id=s.id WHERE s.user_id=? ${openOnly?`AND s.status IN (${openStatuses})`:''} ORDER BY s.created_at DESC,s.id DESC LIMIT 1`).bind(userId).first<any>();
}

function memberSession(row:any){return row?{
 id:row.id,provider:'megah5',gameCode:row.game_code,status:row.status,amountOutMinor:String(row.amount_out_minor),
 amountReturnedMinor:row.amount_returned_minor==null?null:String(row.amount_returned_minor),resultMinor:row.result_minor==null?null:String(row.result_minor),
 recoveryRequired:['deposit_unknown','withdraw_unknown','manual_review'].includes(row.status),createdAt:Number(row.created_at),updatedAt:Number(row.updated_at),settledAt:row.settled_at==null?null:Number(row.settled_at),
}:null;}

function adminSession(row:any){return {...memberSession(row),userId:row.user_id,username:row.username,playerId:row.player_id,depositReference:row.deposit_reference,withdrawReference:row.withdraw_reference??null,providerResidual:row.provider_residual??''};}

async function audit(c:MegaWalletContext,event:string,target:string){await c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,event,target,stamp()).run();}

export async function memberMegaWalletState(c:MegaWalletContext){
 const current=await session(c.db,c.user.id,false),wallet=await withdrawalWalletState(c.db,c.user.id);
 const configured=megaWalletConfigured(c),liveReady=megaWalletLiveReady(c);
 return {provider:'megah5',currency:'MYR',configured,enabled:liveReady,liveReady,settlementVerified:c.settlementVerified==='true',wallet,session:memberSession(current)};
}

export async function adminMegaWalletSessions(c:MegaWalletContext){
 const result=await c.db.prepare(`SELECT s.*,u.username,CAST(l.amount_minor AS TEXT) result_minor FROM game_wallet_sessions s JOIN users u ON u.id=s.user_id LEFT JOIN game_wallet_ledger l ON l.session_id=s.id ORDER BY s.created_at DESC,s.id DESC LIMIT 500`).all<any>();
 const configured=megaWalletConfigured(c),liveReady=megaWalletLiveReady(c);
 return {provider:'megah5',configured,enabled:liveReady,liveReady,settlementVerified:c.settlementVerified==='true',items:(result.results??[]).map(adminSession)};
}

export async function prepareMegaWallet(c:MegaWalletContext,gameCode:string){
 if(!megaWalletLiveReady(c))throw new MegaWalletError(503,'MegaH5 wallet is awaiting settlement verification and the live-games switch');
 await clearStaleReservation(c.db,c.user.id);
 const existing=await session(c.db,c.user.id,true);
 if(existing){
  if(existing.status==='active'&&existing.game_code===gameCode)return {walletVerified:true,sessionId:existing.id,amountOutMinor:String(existing.amount_out_minor),reused:true};
  if(existing.status==='active')throw new MegaWalletError(409,'Finish the active MegaH5 game before starting another game');
  throw new MegaWalletError(409,'MegaH5 wallet recovery is required before another game starts');
 }
 const playerId=megaPlayerId(c.user.id),providerBalance=await balance(c,playerId);
 if(providerBalance.minor!==0n||providerBalance.residual)throw new MegaWalletError(409,'MegaH5 provider balance requires reconciliation');
 const wallet=await withdrawalWalletState(c.db,c.user.id),amount=BigInt(wallet.availableMinor);
 if(amount===0n)return {walletVerified:true,sessionId:null,amountOutMinor:'0',reused:false};
 const id=randomUUID(),depositReference=reference('m7d'),created=stamp();
 try{await c.db.batch([
  c.db.prepare(`INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES(?,?,'megah5',?,?,'deposit_pending',?,?,?,?)`).bind(id,c.user.id,playerId,gameCode,amount.toString(),depositReference,created,created),
  c.db.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES(?,'game',?,?,?)").bind(c.user.id,id,amount.toString(),created),
 ]);}catch(error:any){if(/unique|duplicate/i.test(String(error?.message??'')))throw new MegaWalletError(409,'A wallet operation is already in progress');throw error;}
 const outcome=await gateway(c,'/platform/megah5/deposit',c.walletToken!,{playerId,amount:money(amount),referenceId:depositReference});
 if(outcome.kind==='success'){
  await c.db.batch([c.db.prepare("UPDATE game_wallet_sessions SET status='active',updated_at=? WHERE id=? AND status='deposit_pending'").bind(stamp(),id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,'megah5_deposit_confirmed',id,stamp())]);
  return {walletVerified:true,sessionId:id,amountOutMinor:amount.toString(),reused:false};
 }
 if(outcome.kind==='rejected'){
  await c.db.batch([c.db.prepare("UPDATE game_wallet_sessions SET status='deposit_failed',last_error=?,updated_at=? WHERE id=? AND status='deposit_pending'").bind(outcome.code,stamp(),id),c.db.prepare("DELETE FROM wallet_reservations WHERE kind='game' AND reference_id=?").bind(id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,'megah5_deposit_rejected',id,stamp())]);
  throw new MegaWalletError(502,'MegaH5 wallet transfer was rejected');
 }
 await c.db.batch([c.db.prepare("UPDATE game_wallet_sessions SET status='deposit_unknown',last_error='transport_unknown',updated_at=? WHERE id=? AND status='deposit_pending'").bind(stamp(),id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,'megah5_deposit_unknown',id,stamp())]);
 throw new MegaWalletError(503,'MegaH5 wallet transfer needs recovery');
}

async function finalize(c:MegaWalletContext,row:any,returned:bigint){
 const updated=stamp(),result=returned-BigInt(row.amount_out_minor);
 await c.db.batch([
  c.db.prepare(`UPDATE game_wallet_sessions SET status='settled',amount_returned_minor=?,updated_at=?,settled_at=? WHERE id=? AND status IN ('withdraw_pending','withdraw_unknown')`).bind(returned.toString(),updated,updated,row.id),
  c.db.prepare("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'game_result',?,'MYR',? FROM game_wallet_sessions WHERE id=? AND status='settled' ON CONFLICT(session_id) DO NOTHING").bind(randomUUID(),result.toString(),updated,row.id),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='game' AND reference_id=?").bind(row.id),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,'megah5_wallet_settled',row.id,updated),
 ]);
 return memberSession(await session(c.db,c.user.id,false));
}

export async function settleMegaWallet(c:MegaWalletContext){
 if(!megaWalletConfigured(c))throw new MegaWalletError(503,'MegaH5 wallet recovery connection is unavailable');
 let current=await session(c.db,c.user.id,true);if(!current)return {status:'none',session:null};
 if(current.status!=='active')throw new MegaWalletError(409,'MegaH5 wallet recovery is required');
 const providerBalance=await balance(c,current.player_id);
 if(providerBalance.residual){await c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',provider_residual=?,last_error='fractional_balance',updated_at=? WHERE id=? AND status='active'").bind(providerBalance.raw,stamp(),current.id).run();throw new MegaWalletError(409,'MegaH5 balance requires manual reconciliation');}
 const withdrawalReference=reference('m7w'),expected=providerBalance.minor,claimed=await c.db.prepare("UPDATE game_wallet_sessions SET status='withdraw_pending',withdraw_reference=?,expected_return_minor=?,updated_at=? WHERE id=? AND status='active' RETURNING *").bind(withdrawalReference,expected.toString(),stamp(),current.id).first<any>();
 if(!claimed)throw new MegaWalletError(409,'MegaH5 settlement is already in progress');current=claimed;
 if(expected===0n)return {status:'settled',session:await finalize(c,current,0n)};
 const outcome=await gateway(c,'/platform/megah5/withdraw',c.walletToken!,{playerId:current.player_id,amount:money(expected),referenceId:withdrawalReference});
 if(outcome.kind==='success')return {status:'settled',session:await finalize(c,current,expected)};
 if(outcome.kind==='rejected'){
  await c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',last_error=?,updated_at=? WHERE id=? AND status='withdraw_pending'").bind(outcome.code,stamp(),current.id).run();
  await audit(c,'megah5_withdraw_rejected',current.id);throw new MegaWalletError(502,'MegaH5 settlement was rejected');
 }
 await c.db.prepare("UPDATE game_wallet_sessions SET status='withdraw_unknown',last_error='transport_unknown',updated_at=? WHERE id=? AND status='withdraw_pending'").bind(stamp(),current.id).run();
 await audit(c,'megah5_withdraw_unknown',current.id);throw new MegaWalletError(503,'MegaH5 settlement needs recovery');
}

export async function recoverMegaWallet(c:MegaWalletContext){
 if(!megaWalletConfigured(c))throw new MegaWalletError(503,'MegaH5 wallet recovery connection is unavailable');
 const current=await session(c.db,c.user.id,true);if(!current)return {status:'none',session:null};
 let transferType:'deposit'|'withdrawal',referenceId:string;
 if(['deposit_pending','deposit_unknown'].includes(current.status)){transferType='deposit';referenceId=current.deposit_reference;}
 else if(['withdraw_pending','withdraw_unknown'].includes(current.status)){transferType='withdrawal';referenceId=current.withdraw_reference;}
 else return {status:current.status,session:memberSession(current)};
 const outcome=await gateway(c,'/platform/megah5/transfer-status',c.walletToken!,{playerId:current.player_id,referenceId,transferType});
 if(outcome.kind!=='success'){
  await c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',last_error='status_unconfirmed',updated_at=? WHERE id=?").bind(stamp(),current.id).run();
  await audit(c,'megah5_recovery_unconfirmed',current.id);throw new MegaWalletError(409,'MegaH5 transfer needs manual reconciliation');
 }
 const amount=providerAmount(outcome.result?.Trans?.Amount);
 const expected=BigInt(transferType==='deposit'?current.amount_out_minor:current.expected_return_minor??-1);
 if(!amount||amount.residual||amount.minor!==expected){
  await c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',last_error='amount_mismatch',updated_at=? WHERE id=?").bind(stamp(),current.id).run();
  await audit(c,'megah5_recovery_mismatch',current.id);throw new MegaWalletError(409,'MegaH5 transfer amount requires manual reconciliation');
 }
 if(transferType==='deposit'){
  await c.db.prepare("UPDATE game_wallet_sessions SET status='active',last_error='',updated_at=? WHERE id=? AND status IN ('deposit_pending','deposit_unknown')").bind(stamp(),current.id).run();
  await audit(c,'megah5_deposit_recovered',current.id);return {status:'active',session:memberSession(await session(c.db,c.user.id,true))};
 }
 return {status:'settled',session:await finalize(c,current,amount.minor)};
}

export const megaWalletResponseHeaders=headers;
