import {createHash,timingSafeEqual} from 'node:crypto';
import {PaymentRequestError,recordPaymentDiagnostic,safeProviderCode} from './payment-diagnostics.ts';
import {paymentCapability,automaticDepositCapability,automaticPaymentStatus} from './payment-capabilities.ts';
import {claimPaymentRecovery,finishPaymentRecovery,recoveryCandidates} from './payment-recovery.ts';
import {malaysiaBankCodes} from './malaysia-banks.ts';
import {decryptWithdrawalValue,withdrawalDataKeyReady} from './withdrawal-secrets.ts';

type Member={id:string;username:string;role:string;approved:number};
export type GSPayContext={db:D1Database;user:Member|null;apiBase?:string;authKey?:string;secretKey?:string;callbackToken?:string;enabled?:string;returnUrl?:string;recoveryEnabled?:string;balanceEnabled?:string;payoutEnabled?:string;payoutIpWhitelistConfirmed?:string;payoutBankTargetsJson?:string;withdrawalDataKey?:string;fetchImpl?:typeof fetch};
export type GSPayPayoutInput={payoutId:string;withdrawalId:string;userId:string;accountHolder:string;accountNumber:string;bankCode:string;amountMinor:string};

const provider='gspay';
const apiOrigin='https://api.thegspay.com';
const gatewayOrigin='https://master7-integration-gateway.onrender.com';
const checkoutOrigin='https://secured.gspay.online';
const paymentCallbackPath='/api/payment/gspay/callback';
const legacyPaymentCallbackPath='/api/payment-callbacks/gspay/payment';
const duitNowCallbackPath='/api/payment/gspay/duitnow/callback';
const payoutCallbackPath='/api/payment/gspay/payout/callback';
const canonicalReturnUrl='https://master7-v17-staging.onrender.com/payment/return';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const ack=(value='ok',status=200)=>new Response(value,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const sha256=(value:string)=>createHash('sha256').update(value).digest('hex');
const md5=(value:string)=>createHash('md5').update(value).digest('hex');
const constantEqual=(left:unknown,right:string)=>typeof left==='string'&&Buffer.byteLength(left)===Buffer.byteLength(right)&&timingSafeEqual(Buffer.from(left),Buffer.from(right));
const transactionId=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(value)?value:null;
const paymentId=(value:unknown)=>{const normalized=typeof value==='bigint'?value.toString():typeof value==='number'&&Number.isSafeInteger(value)?String(value):value;return typeof normalized==='string'&&/^[1-9]\d{0,39}$/.test(normalized)?normalized:null;};
const boolean=(value:unknown)=>value===true||value===1||value==='1';

function money(value:unknown):{minor:string;decimal:string;number:number}|null{
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 if(minor<=0n||minor>10000000n)return null;
 const decimal=`${minor/100n}.${String(minor%100n).padStart(2,'0')}`;
 return {minor:minor.toString(),decimal,number:Number(decimal)};
}
export const gspayPlayerUsername=(userId:string)=>`m7${sha256(userId).slice(0,30)}`;
export const gspayOrderSignature=(id:string,playerUsername:string,amount:string,secret:string)=>md5(id+playerUsername+amount+secret);
export const gspayResultSignature=(id:string,amount:string,transaction:string,secret:string)=>md5(id+amount+transaction+secret);
export const gspayPayoutSignature=(transaction:string,playerUsername:string,amount:string,accountNumber:string,secret:string)=>md5(transaction+playerUsername+amount+accountNumber+secret);
export const gspayPayoutResultSignature=(payoutId:string,accountNumber:string,amount:string,transaction:string,secret:string)=>md5(payoutId+accountNumber+amount+transaction+secret);
const internalToken=(value:unknown)=>typeof value==='string'&&Buffer.byteLength(value)>=32&&Buffer.byteLength(value)<=1024;
const gatewayMode=(c:GSPayContext)=>c.apiBase===gatewayOrigin;
function credentials(c:GSPayContext){const key=(value:unknown)=>typeof value==='string'&&/^[A-Fa-f0-9]{32,128}$/.test(value);return [apiOrigin,gatewayOrigin].includes(c.apiBase??'')&&key(c.authKey)&&key(c.secretKey)&&c.authKey!==c.secretKey&&c.returnUrl===canonicalReturnUrl&&(!gatewayMode(c)||(internalToken(c.callbackToken)&&c.callbackToken!==c.authKey&&c.callbackToken!==c.secretKey));}
export const gspayProgramConfigured=credentials;

function payoutBankTargets(c:GSPayContext){
 if(typeof c.payoutBankTargetsJson!=='string'||Buffer.byteLength(c.payoutBankTargetsJson)>8192)return null;
 let parsed:unknown;try{parsed=JSON.parse(c.payoutBankTargetsJson);}catch{return null;}
 if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))return null;const source=parsed as Record<string,unknown>,result:Record<string,string>={},used=new Set<string>();
 for(const code of malaysiaBankCodes){const value=source[code];if(typeof value!=='string'||!/^[A-Za-z0-9._ -]{1,64}$/.test(value)||used.has(value))return null;result[code]=value;used.add(value);}
 return result;
}
function payoutConfiguration(c:GSPayContext){return c.apiBase===apiOrigin&&credentials(c)&&withdrawalDataKeyReady(c.withdrawalDataKey)&&c.payoutIpWhitelistConfirmed==='true'&&payoutBankTargets(c)!==null;}
export const gspayPayoutConfigured=payoutConfiguration;

export async function gspayPayoutAvailability(c:GSPayContext){
 const [channel,control]=await Promise.all([
  c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='gspay'").first<{status:string}>(),
  c.db.prepare("SELECT submission_enabled FROM provider_payout_controls WHERE provider_id='gspay'").first<{submission_enabled:number}>(),
 ]);
 const configured=payoutConfiguration(c),channelActive=channel?.status==='active',submissionEnabled=Number(control?.submission_enabled)===1,enabled=configured&&c.payoutEnabled==='true'&&channelActive&&submissionEnabled;
 const reason=!credentials(c)?'Provider credentials are incomplete':!withdrawalDataKeyReady(c.withdrawalDataKey)?'Withdrawal security is not configured':c.payoutIpWhitelistConfirmed!=='true'?'Provider server IP whitelist is not confirmed':!payoutBankTargets(c)?'Provider bank targets are not configured':c.payoutEnabled!=='true'?'Payout submission switch is disabled':!channelActive?'Payment channel is not active':!submissionEnabled?'Payout control is disabled':'';
 return {implemented:true,configured,enabled,channelActive,submissionEnabled,reason};
}

export function gspayCapabilitySnapshot(c:GSPayContext,channelActive=false,submissionEnabled=false){
  const configured=credentials(c),ordersEnabled=configured,balanceConfigured=c.apiBase===apiOrigin&&configured;
 const payoutConfigured=payoutConfiguration(c),payoutEnabled=payoutConfigured&&channelActive&&submissionEnabled&&c.payoutEnabled==='true';
 return {
   deposit:automaticDepositCapability({implemented:true,configured,enabled:ordersEnabled,blockers:[...(!configured?['deposit_configuration_incomplete']:[])]},'configuration'),
  payout:paymentCapability({implemented:true,configured:payoutConfigured,enabled:payoutEnabled,submissionEnabled:payoutEnabled,blockers:[...(!credentials(c)?['payout_credentials_incomplete']:[]),...(!withdrawalDataKeyReady(c.withdrawalDataKey)?['withdrawal_security_not_configured']:[]),...(c.payoutIpWhitelistConfirmed!=='true'?['server_ip_whitelist_not_confirmed']:[]),...(!payoutBankTargets(c)?['bank_targets_not_configured']:[]),...(c.payoutEnabled!=='true'?['submission_disabled']:[]),...(!channelActive?['channel_not_active']:[]),...(!submissionEnabled?['payout_control_disabled']:[])]}),
  balance:paymentCapability({implemented:true,configured:balanceConfigured,enabled:balanceConfigured&&c.balanceEnabled==='true',blockers:[...(!balanceConfigured?['balance_configuration_incomplete']:[]),...(c.balanceEnabled!=='true'?['balance_query_disabled']:[])]}),
 };
}

function checkoutUrl(value:unknown,expectedPaymentId:string){
 try{
  const url=new URL(String(value)),keys=[...url.searchParams.keys()].filter(key=>key!=='return').sort(),redirect=url.searchParams.get('return');
  if(url.origin!==checkoutOrigin||url.pathname!=='/channel'||url.username||url.password||url.port||url.hash||keys.join(',')!=='id,key'||url.searchParams.get('id')!==expectedPaymentId||!/^[A-Fa-f0-9]{32}$/.test(url.searchParams.get('key')??'')||(redirect!==null&&redirect!==canonicalReturnUrl))return '';
  url.searchParams.set('return',canonicalReturnUrl);return url.href;
 }catch{return '';}
}
async function boundedText(response:Response,max=65536){
 const reader=response.body?.getReader();if(!reader)throw Error('EMPTY_RESPONSE');let size=0;const parts:Uint8Array[]=[];
 for(;;){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>max){await reader.cancel();throw Error('RESPONSE_TOO_LARGE');}parts.push(next.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}return new TextDecoder().decode(bytes);
}
async function providerJson(c:GSPayContext,path:string,method:'GET'|'POST',payload?:unknown,query?:Record<string,string>){
 const url=new URL(path,c.apiBase);for(const [key,value] of Object.entries(query??{}))url.searchParams.set(key,value);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.fetchImpl??fetch)(url,{method,redirect:'error',signal:controller.signal,headers:{Accept:'application/json',...(payload===undefined?{}:{'Content-Type':'application/json'})},...(payload===undefined?{}:{body:JSON.stringify(payload)})});
  if(response.redirected||(response.url&&response.url!==url.href)){await response.body?.cancel();throw new PaymentRequestError({kind:'PROVIDER_RESPONSE',httpStatus:response.status});}
  const raw=await boundedText(response);let value:unknown;try{value=JSON.parse(raw);}catch{throw new PaymentRequestError({kind:'INVALID_JSON',httpStatus:response.status});}
  if(!response.ok||!value||typeof value!=='object'||Array.isArray(value))throw new PaymentRequestError({kind:'PROVIDER_HTTP',httpStatus:response.status});return value as Record<string,unknown>;
 }finally{clearTimeout(timer);}
}
function providerData(value:Record<string,unknown>,requireCode=true){
 if(requireCode&&value.code!==200&&value.code!=='200')return null;let data:unknown=value.data??value;
 if(typeof data==='string'){if(Buffer.byteLength(data)>32768)return null;try{data=JSON.parse(data);}catch{return null;}}
 if(Array.isArray(data)){if(data.length!==1)return null;data=data[0];}
 return data&&typeof data==='object'&&!Array.isArray(data)?data as Record<string,unknown>:null;
}
const orderEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/payment`;
const queryEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/getpayment`;
const payoutEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/payout`;
const payoutStatusEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/payout/status`;
async function queryPayment(c:GSPayContext,order:any,expectedPaymentId?:string){
 const amount=money(`${BigInt(order.amount_minor)/100n}.${String(BigInt(order.amount_minor)%100n).padStart(2,'0')}`)!;
 const envelope=await providerJson(c,queryEndpoint(c),'GET',undefined,{auth_key:c.authKey!,transaction_id:order.id}),result=providerData(envelope,envelope.code!==undefined);
 const reference=paymentId(result?.payment_id),returnedAmount=money(result?.amount),player=gspayPlayerUsername(order.user_id),signature=typeof result?.signature==='string'?result.signature:'',expectedSignature=reference?gspayResultSignature(reference,amount.decimal,order.id,c.secretKey!):'';
 if(!result||!reference||result.transaction_id!==order.id||result.player_username!==player||returnedAmount?.minor!==amount.minor||!constantEqual(signature,expectedSignature)||(expectedPaymentId&&reference!==expectedPaymentId)||(order.provider_trade_no&&reference!==String(order.provider_trade_no)))throw Error('QUERY_BINDING_MISMATCH');
 return {paymentId:reference,completed:boolean(result.completed),success:boolean(result.success)};
}

const decimalFromMinor=(value:unknown)=>{try{const minor=BigInt(String(value));if(minor<=0n||minor>10000000n)return null;return `${minor/100n}.${String(minor%100n).padStart(2,'0')}`;}catch{return null;}};
const cleanPayoutName=(value:unknown)=>typeof value==='string'&&value.length>=2&&value.length<=80&&!/[\u0000-\u001f\u007f-\u009f]/u.test(value)?value:null;
const cleanPayoutAccount=(value:unknown)=>typeof value==='string'&&/^\d{6,20}$/.test(value)?value:null;
async function payoutRecord(c:GSPayContext,payoutId:string){
 return c.db.prepare(`SELECT p.*,w.user_id,w.status withdrawal_status,w.bank_code,w.account_holder_encrypted,w.account_number_encrypted,w.amount_minor withdrawal_amount_minor
  FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id
  WHERE p.id=? AND p.provider_id='gspay' AND w.provider_id='gspay'`).bind(payoutId).first<any>();
}
function payoutSecrets(c:GSPayContext,payout:any){
 try{
  const accountHolder=cleanPayoutName(decryptWithdrawalValue(String(payout.account_holder_encrypted),c.withdrawalDataKey)),accountNumber=cleanPayoutAccount(decryptWithdrawalValue(String(payout.account_number_encrypted),c.withdrawalDataKey));
  return accountHolder&&accountNumber?{accountHolder,accountNumber}:null;
 }catch{return null;}
}
async function queryPayout(c:GSPayContext,payout:any,expectedPayoutId?:string){
 const amount=decimalFromMinor(payout.amount_minor),secrets=payoutSecrets(c,payout);if(!amount||!secrets)throw Error('PAYOUT_BINDING_MISMATCH');
 const envelope=await providerJson(c,payoutStatusEndpoint(c),'GET',undefined,{auth_key:c.authKey!,transaction_id:payout.id}),result=providerData(envelope,envelope.code!==undefined),reference=paymentId(result?.payout_id),returnedAmount=money(result?.amount),signature=typeof result?.signature==='string'?result.signature:'';
 const expectedSignature=reference?gspayPayoutResultSignature(reference,secrets.accountNumber,amount,payout.id,c.secretKey!):'';
 if(!result||!reference||result.transaction_id!==payout.id||result.account_number!==secrets.accountNumber||result.account_name!==secrets.accountHolder||returnedAmount?.minor!==String(payout.amount_minor)||!constantEqual(signature,expectedSignature)||(expectedPayoutId&&reference!==expectedPayoutId)||(payout.provider_reference&&reference!==String(payout.provider_reference)))throw Error('PAYOUT_BINDING_MISMATCH');
 return {payoutId:reference,completed:boolean(result.completed),success:boolean(result.payout_success)};
}
async function finalizePayout(c:GSPayContext,payout:any,result:{payoutId:string;completed:boolean;success:boolean}){
 const timestamp=Math.floor(Date.now()/1000);
 if(!result.completed){await c.db.batch([
  c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),updated_at=? WHERE id=? AND status IN ('prepared','submitting','processing')").bind(result.payoutId,timestamp,payout.id),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status IN ('pending','approved','processing')").bind(timestamp,payout.withdrawal_id),
 ]);return {status:'processing' as const,providerReference:result.payoutId};}
 const current=await c.db.prepare('SELECT status FROM withdrawal_requests WHERE id=?').bind(payout.withdrawal_id).first<{status:string}>();
 if(result.success&&!['pending','approved','processing','paid'].includes(current?.status??'')){
  await c.db.batch([
   c.db.prepare("UPDATE provider_payouts SET status='review',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),last_error_code='withdrawal_state_conflict',updated_at=? WHERE id=? AND status<>'succeeded'").bind(result.payoutId,timestamp,payout.id),
   c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),payout.user_id,'gspay_payout_review',payout.withdrawal_id,timestamp),
  ]);return {status:'review' as const,providerReference:result.payoutId};
 }
 if(result.success){
  await c.db.batch([
   c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'gspay_payout_paid',?,? WHERE EXISTS (SELECT 1 FROM provider_payouts WHERE id=? AND status<>'succeeded')").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,timestamp,payout.id),
   c.db.prepare("UPDATE provider_payouts SET status='succeeded',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),last_error_code=NULL,updated_at=?,completed_at=COALESCE(completed_at,?) WHERE id=? AND status<>'review'").bind(result.payoutId,timestamp,timestamp,payout.id),
   c.db.prepare("UPDATE withdrawal_requests SET status='paid',updated_at=? WHERE id=? AND status IN ('pending','approved','processing','paid')").bind(timestamp,payout.withdrawal_id),
   c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(payout.withdrawal_id),
  ]);return {status:'succeeded' as const,providerReference:result.payoutId};
 }
 await c.db.batch([
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'gspay_payout_failed',?,? WHERE EXISTS (SELECT 1 FROM provider_payouts WHERE id=? AND status NOT IN ('failed','succeeded'))").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,timestamp,payout.id),
  c.db.prepare("UPDATE provider_payouts SET status='failed',create_outcome='rejected',provider_reference=COALESCE(provider_reference,?),last_error_code='provider_failed',updated_at=?,completed_at=COALESCE(completed_at,?) WHERE id=? AND status NOT IN ('succeeded','review')").bind(result.payoutId,timestamp,timestamp,payout.id),
  c.db.prepare("UPDATE withdrawal_requests SET status='rejected',owner_note='Provider payout failed',updated_at=? WHERE id=? AND status IN ('pending','approved','processing')").bind(timestamp,payout.withdrawal_id),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(payout.withdrawal_id),
 ]);return {status:'failed' as const,providerReference:result.payoutId};
}
async function reconcilePayout(c:GSPayContext,payoutId:string,expectedPayoutId?:string){
 const payout=await payoutRecord(c,payoutId);if(!payout)throw Error('PAYOUT_NOT_FOUND');
 if(payout.status==='succeeded')return {status:'succeeded' as const,providerReference:payout.provider_reference};
 if(payout.status==='failed')return {status:'failed' as const,providerReference:payout.provider_reference};
 if(payout.status==='review')return {status:'review' as const,providerReference:payout.provider_reference};
 try{return await finalizePayout(c,payout,await queryPayout(c,payout,expectedPayoutId));}
 catch(error){if(error instanceof Error&&error.message==='PAYOUT_BINDING_MISMATCH'){await c.db.batch([
  c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code='binding_mismatch',updated_at=? WHERE id=? AND status<>'succeeded'").bind(Math.floor(Date.now()/1000),payout.id),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),payout.user_id,'gspay_payout_binding_review',payout.withdrawal_id,Math.floor(Date.now()/1000)),
 ]);return {status:'review' as const,providerReference:payout.provider_reference};}throw error;}
}

export async function submitGSPayPayout(input:GSPayPayoutInput,c:GSPayContext){
 const availability=await gspayPayoutAvailability(c);if(!availability.enabled)throw Error('GSPAY_PAYOUT_NOT_READY');
 const payout=await payoutRecord(c,input.payoutId),targets=payoutBankTargets(c),amount=decimalFromMinor(input.amountMinor),target=targets?.[input.bankCode];
 if(!payout||payout.withdrawal_id!==input.withdrawalId||payout.user_id!==input.userId||String(payout.amount_minor)!==input.amountMinor||String(payout.withdrawal_amount_minor)!==input.amountMinor||!target||!amount)throw Error('PAYOUT_INPUT_MISMATCH');
 const secrets=payoutSecrets(c,payout);if(!secrets||secrets.accountHolder!==input.accountHolder||secrets.accountNumber!==input.accountNumber)throw Error('PAYOUT_INPUT_MISMATCH');
 if(payout.status!=='prepared')return payout.status==='submitting'&&!payout.provider_reference?{status:'processing' as const,providerReference:null}:reconcilePayout(c,payout.id);
 const timestamp=Math.floor(Date.now()/1000),claimed=await c.db.prepare("UPDATE provider_payouts SET status='submitting',create_outcome='in_flight',updated_at=? WHERE id=? AND status='prepared' RETURNING id").bind(timestamp,payout.id).first<{id:string}>();
 // Only the request that atomically claimed the prepared row may call the
 // provider. A concurrent retry observes an in-flight payout and only polls.
 if(!claimed)return {status:'processing' as const,providerReference:null};
 await c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status='pending'").bind(timestamp,payout.withdrawal_id).run();
 const playerUsername=gspayPlayerUsername(payout.user_id),payload={transaction_id:payout.id,player_username:playerUsername,account_name:secrets.accountHolder,account_number:secrets.accountNumber,amount:Number(amount),trx_description:payout.id,bank_target:target,signature:gspayPayoutSignature(payout.id,playerUsername,amount,secrets.accountNumber,c.secretKey!)};
 try{
  const envelope=await providerJson(c,payoutEndpoint(c),'POST',payload),result=providerData(envelope),reference=paymentId(result?.payout_id),accepted=envelope.code===200||envelope.code==='200';
  await c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome=?,provider_reference=COALESCE(provider_reference,?),last_error_code=NULL,updated_at=? WHERE id=? AND status='submitting'").bind(accepted?'accepted':'unknown',reference,Math.floor(Date.now()/1000),payout.id).run();
  try{return await reconcilePayout(c,payout.id,reference??undefined);}catch{return {status:'processing' as const,providerReference:reference};}
 }catch{
  await c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='unknown',last_error_code='submission_outcome_unknown',updated_at=? WHERE id=? AND status='submitting'").bind(Math.floor(Date.now()/1000),payout.id).run();
  return {status:'processing' as const,providerReference:null};
 }
}

export async function recoverGSPayPayouts(c:GSPayContext,limit=25){
 const summary={provider,enabled:credentials(c)&&withdrawalDataKeyReady(c.withdrawalDataKey),queried:0,succeeded:0,failed:0,processing:0,review:0,errors:0};if(!summary.enabled)return summary;
 const result=await c.db.prepare("SELECT id FROM provider_payouts WHERE provider_id='gspay' AND status IN ('submitting','processing') ORDER BY updated_at,id LIMIT ?").bind(Math.max(1,Math.min(100,limit))).all<{id:string}>();
 for(const row of result.results??[]){summary.queried++;try{const next=await reconcilePayout(c,row.id);if(next.status==='succeeded')summary.succeeded++;else if(next.status==='failed')summary.failed++;else if(next.status==='review')summary.review++;else summary.processing++;}catch{summary.errors++;}}
 return summary;
}

async function verifyLedger(c:GSPayContext,order:any){
 const result=await c.db.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=?').bind(order.id).all<any>(),rows=result.results??[],member=rows.find((row:any)=>row.account_code==='member'),clearing=rows.find((row:any)=>row.account_code==='provider_clearing');
 return rows.length===2&&rows.every((row:any)=>row.currency==='MYR'&&row.user_id===order.user_id)&&String(member?.amount_minor)===String(order.amount_minor)&&BigInt(clearing?.amount_minor??0)===-BigInt(order.amount_minor)&&BigInt(member?.amount_minor??0)+BigInt(clearing?.amount_minor??0)===0n;
}
async function credit(c:GSPayContext,order:any,reference:string){
 const existing=await c.db.prepare('SELECT id FROM wallet_ledger WHERE order_id=?').bind(order.id).all();
 if((existing.results??[]).length&&!await verifyLedger(c,order)){await c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=?").bind(Math.floor(Date.now()/1000),order.id).run();throw Error('LEDGER_REVIEW_REQUIRED');}
 const timestamp=Math.floor(Date.now()/1000);
 await c.db.batch([
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'member',amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='gspay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,reference),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'provider_clearing',-amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='gspay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,reference),
  c.db.prepare("UPDATE deposit_orders SET status='credited',provider_trade_no=?,updated_at=? WHERE id=? AND provider='gspay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(reference,timestamp,order.id,reference),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),order.user_id,'gspay_deposit_credited',order.id,timestamp),
 ]);
 if(!await verifyLedger(c,order))throw Error('LEDGER_REVIEW_REQUIRED');
}
async function reconcile(c:GSPayContext,order:any,expectedPaymentId?:string){
 const timestamp=Math.floor(Date.now()/1000),age=timestamp-Number(order.created_at),reference=expectedPaymentId??paymentId(order.provider_trade_no)??undefined,rejected=order.status==='failed';
 if(order.status==='review')return 'review';
 if(!reference){if(age>=600)await c.db.prepare("UPDATE deposit_orders SET status='failed',updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(timestamp,order.id).run();return age>=600?'expired':'awaiting_confirmation';}
 try{
  const result=await queryPayment(c,order,reference);
  if(result.completed&&result.success){
   if(rejected){await c.db.batch([c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status='failed'").bind(result.paymentId,timestamp,order.id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),order.user_id,'gspay_late_success_review',order.id,timestamp)]);return 'review';}
   const member=await c.db.prepare("SELECT id FROM users WHERE id=? AND role='member' AND approved=1").bind(order.user_id).first<{id:string}>();
   if(!member){await c.db.batch([c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status!='credited'").bind(result.paymentId,timestamp,order.id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),order.user_id,'gspay_member_binding_review',order.id,timestamp)]);return 'review';}
   await credit(c,order,result.paymentId);return 'credited';
  }
  if(result.completed||age>=600){await c.db.prepare("UPDATE deposit_orders SET status='failed',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(reference,timestamp,order.id).run();return result.completed?'failed':'expired';}
  return 'awaiting_confirmation';
 }catch(error){
  if(error instanceof Error&&error.message==='QUERY_BINDING_MISMATCH'){await c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND status!='credited'").bind(timestamp,order.id).run();throw error;}
  if(age>=600){await c.db.prepare("UPDATE deposit_orders SET status='failed',updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(timestamp,order.id).run();return 'expired';}
  throw error;
 }
}
async function callbackBody(req:Request){
 if(!req.headers.get('content-type')?.toLowerCase().startsWith('application/json'))return null;
 const raw=await boundedText(new Response(req.body),16384);let value:unknown;try{value=JSON.parse(raw);}catch{return null;}return value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:null;
}
function callbackKind(path:string){if(path===paymentCallbackPath||path===legacyPaymentCallbackPath)return'payment';if(path===duitNowCallbackPath)return'duitnow';if(path===payoutCallbackPath)return'payout';return'';}
async function payoutCallback(req:Request,c:GSPayContext,url:URL){
 if(!credentials(c)||!withdrawalDataKeyReady(c.withdrawalDataKey))return ack('unavailable',503);
 let data:Record<string,unknown>|null;try{data=await callbackBody(req);}catch{return ack('invalid',400);}if(!data)return ack('invalid',400);
 const queryAuth=url.searchParams.get('auth_key'),bodyAuth=typeof data.auth_key==='string'?data.auth_key:null;if(queryAuth&&bodyAuth&&!constantEqual(queryAuth,bodyAuth))return ack('unauthorized',401);
 const suppliedAuth=queryAuth??bodyAuth;if(!suppliedAuth||!constantEqual(suppliedAuth,c.authKey!))return ack('unauthorized',401);
 const transaction=transactionId(data.transaction_id),reference=paymentId(data.payout_id),amount=money(data.amount),accountNumber=cleanPayoutAccount(data.account_number),signature=typeof data.signature==='string'?data.signature:'';
 if(!transaction||!reference||!amount||!accountNumber||!constantEqual(signature,gspayPayoutResultSignature(reference,accountNumber,amount.decimal,transaction,c.secretKey!)))return ack('unauthorized',401);
 const payout=await payoutRecord(c,transaction),secrets=payout?payoutSecrets(c,payout):null;if(!payout||!secrets)return ack('unknown_order',404);
 if(secrets.accountNumber!==accountNumber||data.account_name!==secrets.accountHolder||String(payout.amount_minor)!==amount.minor||(payout.provider_reference&&String(payout.provider_reference)!==reference)){
  await c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code='callback_binding_mismatch',updated_at=? WHERE id=? AND status<>'succeeded'").bind(Math.floor(Date.now()/1000),payout.id).run();return ack('review_required',409);
 }
 const eventHash=sha256(JSON.stringify({reference,transaction,amount:amount.minor,completed:boolean(data.completed),success:boolean(data.payout_success)}));
 await c.db.prepare("UPDATE provider_payouts SET provider_reference=COALESCE(provider_reference,?),last_event_hash=?,updated_at=? WHERE id=? AND status<>'succeeded'").bind(reference,eventHash,Math.floor(Date.now()/1000),payout.id).run();
 try{const result=await reconcilePayout(c,payout.id,reference);return result.status==='review'?ack('review_required',409):ack();}catch{return ack('pending',503);}
}
export async function handleGSPayCallback(req:Request,c:GSPayContext):Promise<Response|null>{
 const url=new URL(req.url),kind=callbackKind(url.pathname);if(!kind)return null;
 if(req.method==='GET')return json({ok:true,provider,callback:kind,active:kind==='payment'?credentials(c):kind==='payout'?credentials(c)&&withdrawalDataKeyReady(c.withdrawalDataKey):false,settlementVerified:false});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(kind==='payout')return payoutCallback(req,c,url);
 if(kind!=='payment')return json({error:`GSPAY_${kind.toUpperCase()}_DISABLED`,provider,enabled:false},410);
 if(!credentials(c))return ack('unavailable',503);
 if(gatewayMode(c)){
  const authorization=req.headers.get('authorization')??'',given=authorization.startsWith('Bearer ')?authorization.slice(7):'';
  if(!internalToken(c.callbackToken)||!constantEqual(given,c.callbackToken!))return ack('unauthorized',401);
 }
 let data:Record<string,unknown>|null;try{data=await callbackBody(req);}catch{return ack('invalid',400);}if(!data)return ack('invalid',400);
 const queryAuth=url.searchParams.get('auth_key'),bodyAuth=typeof data.auth_key==='string'?data.auth_key:null;
 if(queryAuth&&bodyAuth&&!constantEqual(queryAuth,bodyAuth))return ack('unauthorized',401);
 const suppliedAuth=queryAuth??bodyAuth;if(!suppliedAuth||!constantEqual(suppliedAuth,c.authKey!))return ack('unauthorized',401);
 const orderId=transactionId(data.transaction_id),reference=paymentId(data.payment_id),amount=money(data.amount),signature=typeof data.signature==='string'?data.signature:'';
 if(!orderId||!reference||!amount||!constantEqual(signature,gspayResultSignature(reference,amount.decimal,orderId,c.secretKey!)))return ack('unauthorized',401);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='gspay'").bind(orderId).first<any>();if(!order)return ack('unknown_order',404);
 if(String(order.amount_minor)!==amount.minor||gspayPlayerUsername(order.user_id)!==data.player_username||(order.provider_trade_no&&String(order.provider_trade_no)!==reference))return ack('review_required',409);
 if(order.status==='credited')return await verifyLedger(c,order)?ack():ack('ledger_review',503);
 if(!boolean(data.completed)||!boolean(data.success)){if(boolean(data.completed))await c.db.prepare("UPDATE deposit_orders SET status='failed',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(reference,Math.floor(Date.now()/1000),order.id).run();return ack();}
 try{const status=await reconcile(c,order,reference);return status==='credited'||status==='review'?ack():ack('pending',503);}catch{return ack('pending',503);}
}

export async function handleGSPay(req:Request,c:GSPayContext):Promise<Response|null>{
 const path=new URL(req.url).pathname;if(path!=='/api/payments/gspay/status'||req.method!=='GET')return null;
 const payout=await gspayPayoutAvailability(c),programConfigured=credentials(c),capabilities=gspayCapabilitySnapshot(c,payout.channelActive,payout.submissionEnabled),enabled=capabilities.deposit.enabled;
 return json({provider,currency:'MYR',enabled,mode:enabled?'production':'disabled',...automaticPaymentStatus(capabilities.deposit),programConfigured,createProgramReady:programConfigured,orderReady:enabled,queryReady:programConfigured,callbacksReady:programConfigured,payoutReady:payout.enabled,realPayments:enabled,settlementVerified:false,liveReady:false,capabilities});
}
export async function createGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member')return json({error:'Member account required'},403);if(!user.approved)return json({error:'Account awaiting approval'},403);
 if(!credentials(c))return json({error:'GSPAY_NOT_READY'},503);
 const amount=money(data.amount),requestKey=typeof data.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(data.requestKey)?data.requestKey:null;if(!amount||!requestKey)return json({error:'Invalid MYR order'},400);
 const playerUsername=gspayPlayerUsername(user.id),fingerprint=sha256(JSON.stringify({provider,amount:amount.minor,playerUsername,currency:'MYR',authKey:c.authKey})),timestamp=Math.floor(Date.now()/1000),newId=`G7${crypto.randomUUID().replaceAll('-','').slice(0,30)}`;
 await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,'gspay',?,'MYR','payment','pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(newId,user.id,requestKey,fingerprint,amount.minor,timestamp,timestamp).run();
 const order=await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(user.id,requestKey).first<any>();if(!order)return json({error:'Order unavailable'},503);if(order.fingerprint!==fingerprint||order.provider!==provider)return json({error:'IDEMPOTENCY_CONFLICT'},409);
 if(order.status==='created'&&paymentId(order.provider_trade_no)){const payUrl=checkoutUrl(order.checkout_url,String(order.provider_trade_no)),expiresAt=Number(order.expires_at_raw);if(payUrl&&Number.isSafeInteger(expiresAt)&&expiresAt>timestamp)return json({id:order.id,status:'awaiting_payment',payUrl,providerTradeNo:order.provider_trade_no,expiresAt:String(expiresAt)});return json({id:order.id,status:'awaiting_confirmation',payUrl:null,expiresAt:order.expires_at_raw},202);}
 if(order.status!=='pending')return json({id:order.id,status:order.status==='credited'?'credited':order.status==='failed'?'expired':'awaiting_confirmation',payUrl:null},202);
 const claimed=await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(timestamp,order.id).first();if(!claimed)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 try{
  const payload={transaction_id:order.id,amount:amount.number,player_username:playerUsername,signature:gspayOrderSignature(order.id,playerUsername,amount.decimal,c.secretKey!)};
  const envelope=await providerJson(c,orderEndpoint(c),'POST',payload),result=providerData(envelope),reference=paymentId(result?.payment_id),payUrl=reference?checkoutUrl(result?.payment_url,reference):'';
  if(!result||!reference||!payUrl)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerCode:safeProviderCode(envelope.code),providerTradeNo:reference??undefined,missing:[...(!reference?['providerTradeNo']:[]),...(!payUrl?['checkoutUrl']:[])]});
  const expiresAt=String(timestamp+120);await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,expires_at_raw=?,updated_at=? WHERE id=? AND status='creating'").bind(reference,payUrl,expiresAt,Math.floor(Date.now()/1000),order.id).run();return json({id:order.id,status:'awaiting_payment',payUrl,providerTradeNo:reference,expiresAt},201);
 }catch(error){await c.db.prepare("UPDATE deposit_orders SET status='unknown',updated_at=? WHERE id=? AND status='creating'").bind(Math.floor(Date.now()/1000),order.id).run();await recordPaymentDiagnostic(c.db,user.id,provider,order.id,error);return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);}
}
export async function refreshGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member'||!user.approved)return json({error:'Member account required'},403);if(!credentials(c))return json({error:'GSPAY_NOT_CONFIGURED'},503);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='gspay'").bind(transactionId(data.orderId)??'',user.id).first<any>();if(!order)return json({error:'Order not found'},404);if(order.status==='credited')return await verifyLedger(c,order)?json({id:order.id,status:'credited'}):json({error:'Ledger review required'},503);
 try{const status=await reconcile(c,order);return json({id:order.id,status},status==='credited'?200:status==='review'?409:202);}catch{const current=await c.db.prepare('SELECT status FROM deposit_orders WHERE id=?').bind(order.id).first<{status:string}>();return current?.status==='review'?json({id:order.id,status:'review'},409):json({id:order.id,status:'awaiting_confirmation'},202);}
}

export async function recoverGSPayDeposits(c:GSPayContext,limit=25){
 const summary={provider,enabled:c.recoveryEnabled==='true'&&credentials(c),scanned:0,queried:0,credited:0,review:0,pending:0,errors:0};
 if(!summary.enabled)return summary;
 const candidates=await recoveryCandidates(c.db,'gspay',limit);summary.scanned=candidates.length;
 for(const order of candidates){
  const claim=await claimPaymentRecovery(c.db,'gspay',order.id);if(!claim)continue;
  try{summary.queried++;const status=await reconcile(c,order);if(status==='credited')summary.credited++;else if(status==='review')summary.review++;else summary.pending++;}
  catch{const current=await c.db.prepare('SELECT status FROM deposit_orders WHERE id=?').bind(order.id).first<{status:string}>();if(current?.status==='review')summary.review++;else summary.errors++;}
  finally{await finishPaymentRecovery(c.db,'gspay',order.id,claim);}
 }
 return summary;
}

function balanceDecimal(value:unknown){
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||! /^(?:0|[1-9]\d{0,11})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.');return `${BigInt(whole)}.${fraction.padEnd(2,'0')}`;
}

export async function queryGSPayBalance(c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='owner')return json({error:'Access denied'},403);
 if(!credentials(c)||c.balanceEnabled!=='true')return json({error:'GSPAY_BALANCE_QUERY_DISABLED'},503);
 try{
  const envelope=await providerJson(c,`/v2/integrations/operator/${encodeURIComponent(c.authKey!)}/get/balance`,'GET');
  if(envelope.code!==200&&envelope.code!=='200')throw Error('BALANCE_RESPONSE_INVALID');
  let candidate:unknown=envelope.data;
  if(candidate&&typeof candidate==='object'&&!Array.isArray(candidate)){const record=candidate as Record<string,unknown>;candidate=record.balance??record.operator_balance;}
  const balance=balanceDecimal(candidate);if(!balance)throw Error('BALANCE_RESPONSE_INVALID');
  return json({provider,currency:'MYR',balance,readOnly:true,verified:false,settlementVerified:false});
 }catch{return json({error:'GSPAY_BALANCE_UNAVAILABLE'},502);}
}
