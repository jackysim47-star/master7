import {createHash} from 'node:crypto';
import {PaymentRequestError,recordPaymentDiagnostic,paymentUrlHost} from './payment-diagnostics.ts';

type Member={id:string;username:string;role:string;approved:number};
export type GSPayContext={db:D1Database;user:Member|null;gatewayUrl?:string;orderToken?:string;queryToken?:string;callbackToken?:string;enabled?:string;mode?:string;fetchImpl?:typeof fetch};

const provider='gspay';
const gatewayOrigin='https://master7-integration-gateway.onrender.com';
const checkoutOrigin='https://secured.gspay.online';
const createContract='gspay-myr-create-v1';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const digest=(value:string)=>createHash('sha256').update(value).digest('hex');
const token=(value:unknown)=>typeof value==='string'&&Buffer.byteLength(value)>=32&&Buffer.byteLength(value)<=1024&&!/[\u0000-\u0020\u007f-\u009f]/u.test(value);
const transaction=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(value)?value:null;
const paymentId=(value:unknown)=>typeof value==='string'&&/^[1-9]\d{0,39}$/.test(value)?value:null;

function configuration(c:GSPayContext){
 return c.gatewayUrl===gatewayOrigin&&token(c.orderToken)&&token(c.queryToken)&&token(c.callbackToken)
  &&c.orderToken!==c.queryToken&&c.orderToken!==c.callbackToken&&c.queryToken!==c.callbackToken
  &&['uat','production'].includes(String(c.mode));
}
export const gspayProgramConfigured=configuration;

function money(value:unknown):{minor:string;decimal:string}|null{
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 return minor>0n&&minor<=10000000n?{minor:minor.toString(),decimal:`${minor/100n}.${String(minor%100n).padStart(2,'0')}`}:null;
}

export const gspayPlayerUsername=(userId:string)=>'m7'+digest(userId).slice(0,30);

function safeCheckout(value:unknown,expectedId?:string){
 try{
  const url=new URL(String(value)),keys=[...url.searchParams.keys()].sort();
  return url.origin===checkoutOrigin&&url.pathname==='/channel'&&!url.username&&!url.password&&!url.port&&!url.hash
   &&keys.length===2&&keys[0]==='id'&&keys[1]==='key'&&(!expectedId||url.searchParams.get('id')===expectedId)
   &&/^[a-f0-9]{32}$/i.test(url.searchParams.get('key')??'')?url.href:'';
 }catch{return '';}
}

async function gatewayJson(c:GSPayContext,path:string,credential:string,method='GET',body?:unknown){
 const url=new URL(path,gatewayOrigin),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
 try{
  const response=await(c.fetchImpl??fetch)(url,{method,redirect:'error',signal:controller.signal,headers:{Accept:'application/json',Authorization:`Bearer ${credential}`,...(body===undefined?{}:{'Content-Type':'application/json'})},...(body===undefined?{}:{body:JSON.stringify(body)})});
  if(response.redirected||(response.url&&response.url!==url.href)||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')??'')){await response.body?.cancel();throw new PaymentRequestError({kind:'GATEWAY_RESPONSE',httpStatus:response.status});}
  const raw=await response.text();if(Buffer.byteLength(raw)>65536)throw new PaymentRequestError({kind:'GATEWAY_RESPONSE',httpStatus:response.status});
  let value:any;try{value=JSON.parse(raw);}catch{throw new PaymentRequestError({kind:'GATEWAY_RESPONSE',httpStatus:response.status});}
  if(!value||typeof value!=='object'||Array.isArray(value))throw new PaymentRequestError({kind:'GATEWAY_RESPONSE',httpStatus:response.status});
  if(!response.ok){const upstream=Number(value.upstreamStatus);throw new PaymentRequestError({kind:'GATEWAY_HTTP',httpStatus:response.status,...(Number.isInteger(upstream)&&upstream>=100&&upstream<600?{upstreamStatus:upstream}:{})});}
  return value;
 }finally{clearTimeout(timer);}
}

function gatewayConfiguration(value:any,c:GSPayContext){
 if(value?.provider!=='gspay'||value.currency!=='MYR'||value.mode!==c.mode||value.providerBase!=='https://api.thegspay.com')return null;
 return {createProgramReady:value.createProgramReady===true,orderReady:value.orderReady===true,queryReady:value.queryReady===true,callbacksReady:value.callbacksReady===true,transactionRoutesActive:value.transactionRoutesActive===true};
}

export async function handleGSPay(req:Request,c:GSPayContext):Promise<Response|null>{
 const path=new URL(req.url).pathname;
 if(path==='/api/payments/gspay/status'&&req.method==='GET'){
  const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='gspay'").first<{status:string}>(),channelStatus=channel?.status??'closed';
  if(!configuration(c)||c.enabled!=='true'||channelStatus!=='active')return json({provider,currency:'MYR',enabled:false,mode:'disabled',channelStatus,createProgramReady:configuration(c),orderReady:false,queryReady:false,callbacksReady:false,settlementVerified:false,liveReady:false});
  try{
   const config=gatewayConfiguration(await gatewayJson(c,'/platform/gspay/config',c.queryToken!),c);
   const settlementReady=!!config?.orderReady&&!!config?.queryReady&&!!config?.callbacksReady;
   return json({provider,currency:'MYR',enabled:settlementReady,mode:settlementReady?c.mode:'disabled',channelStatus,createProgramReady:!!config?.createProgramReady,orderReady:!!config?.orderReady,queryReady:!!config?.queryReady,callbacksReady:!!config?.callbacksReady,settlementVerified:false,liveReady:false});
  }catch{return json({provider,currency:'MYR',enabled:false,mode:'disabled',channelStatus,createProgramReady:true,orderReady:false,queryReady:false,callbacksReady:false,settlementVerified:false,liveReady:false});}
 }
 return null;
}

export async function createGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member')return json({error:'Member account required'},403);if(!user.approved)return json({error:'Account awaiting approval'},403);
 const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='gspay'").first<{status:string}>();
 if(!configuration(c)||c.enabled!=='true'||channel?.status!=='active')return json({error:'GSPAY_NOT_READY'},503);
 const amount=money(data.amount),requestKey=typeof data.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(data.requestKey)?data.requestKey:null;
 if(!amount||!requestKey)return json({error:'Invalid MYR order'},400);
 const config=gatewayConfiguration(await gatewayJson(c,'/platform/gspay/config',c.queryToken!),c);
 // A checkout is never opened until the same gateway can independently query
 // the result and safely process callbacks. The supplier has confirmed create,
 // but these settlement contracts are still awaiting acceptance.
 if(!config?.orderReady||!config.queryReady||!config.callbacksReady)return json({error:'GSPAY_SETTLEMENT_NOT_READY'},503);
 const playerUsername=gspayPlayerUsername(user.id),fingerprint=digest(JSON.stringify({provider,amount:amount.minor,playerUsername,currency:'MYR',mode:c.mode})),timestamp=Math.floor(Date.now()/1000),newId='G7'+crypto.randomUUID().replaceAll('-','').slice(0,30);
 await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,'gspay',?,'MYR','payment','pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(newId,user.id,requestKey,fingerprint,amount.minor,timestamp,timestamp).run();
 const order=await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(user.id,requestKey).first<any>();
 if(!order)return json({error:'Order unavailable'},503);if(order.fingerprint!==fingerprint||order.provider!==provider)return json({error:'IDEMPOTENCY_CONFLICT'},409);
 if(order.status==='created'&&safeCheckout(order.checkout_url,order.provider_trade_no))return json({id:order.id,status:'awaiting_payment',payUrl:order.checkout_url,providerTradeNo:order.provider_trade_no,expiresAt:order.expires_at_raw});
 if(order.status!=='pending')return json({id:order.id,status:order.status==='credited'?'credited':'awaiting_confirmation',payUrl:null},202);
 const claimed=await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(timestamp,order.id).first();if(!claimed)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 try{
  const response=await gatewayJson(c,'/platform/gspay/order',c.orderToken!,'POST',{transactionId:order.id,playerUsername,amount:amount.decimal,currency:'MYR',contract:createContract}),result=response?.result;
  const reference=paymentId(result?.paymentId),payUrl=reference?safeCheckout(result?.paymentUrl,reference):'';
  const valid=response?.provider==='gspay_myr'&&response.contract===createContract&&response.upstreamStatus===200&&result?.transactionId===order.id&&result?.playerUsername===playerUsername&&result?.currency==='MYR'&&money(result?.amount)?.minor===amount.minor&&result?.responseSchemaVerified===true&&result?.fundsProcessed===false;
  if(!valid||!reference||!payUrl)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerTradeNo:reference??undefined,checkoutHost:paymentUrlHost(result?.paymentUrl),missing:[...(!reference?['providerTradeNo']:[]),...(!payUrl?['checkoutUrl']:[]),...(!valid?['verifiedOrderBinding']:[])]});
  const expiresAt=String(timestamp+120);
  await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,expires_at_raw=?,updated_at=? WHERE id=? AND status='creating'").bind(reference,payUrl,expiresAt,Math.floor(Date.now()/1000),order.id).run();
  return json({id:order.id,status:'awaiting_payment',payUrl,providerTradeNo:reference,expiresAt},201);
 }catch(error){
  await c.db.prepare("UPDATE deposit_orders SET status='unknown',updated_at=? WHERE id=? AND status='creating'").bind(Math.floor(Date.now()/1000),order.id).run();
  await recordPaymentDiagnostic(c.db,user.id,provider,order.id,error);return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 }
}

export async function refreshGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member'||!user.approved)return json({error:'Member account required'},403);
 const order=await c.db.prepare("SELECT id,status FROM deposit_orders WHERE id=? AND user_id=? AND provider='gspay'").bind(transaction(data.orderId)??'',user.id).first<{id:string;status:string}>();
 if(!order)return json({error:'Order not found'},404);if(order.status==='credited')return json({id:order.id,status:'credited'});
 return json({id:order.id,status:'awaiting_confirmation',queryReady:false,error:'GSPAY_QUERY_CONTRACT_PENDING'},503);
}
