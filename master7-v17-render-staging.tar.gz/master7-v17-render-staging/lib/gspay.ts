import {createHash,timingSafeEqual} from 'node:crypto';
import {PaymentRequestError,recordPaymentDiagnostic,safeProviderCode} from './payment-diagnostics.ts';

type Member={id:string;username:string;role:string;approved:number};
export type GSPayContext={db:D1Database;user:Member|null;apiBase?:string;authKey?:string;secretKey?:string;enabled?:string;returnUrl?:string;fetchImpl?:typeof fetch};

const provider='gspay';
const apiOrigin='https://api.thegspay.com';
const checkoutOrigin='https://secured.gspay.online';
const paymentCallbackPath='/api/payment/gspay/callback';
const legacyPaymentCallbackPath='/api/payment-callbacks/gspay/payment';
const duitNowCallbackPath='/api/payment/gspay/duitnow/callback';
const payoutCallbackPath='/api/payment/gspay/payout/callback';
const canonicalReturnUrl='https://master7.best/payment/return';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const ack=(value='ok',status=200)=>new Response(value,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const sha256=(value:string)=>createHash('sha256').update(value).digest('hex');
const md5=(value:string)=>createHash('md5').update(value).digest('hex');
const constantEqual=(left:unknown,right:string)=>typeof left==='string'&&Buffer.byteLength(left)===Buffer.byteLength(right)&&timingSafeEqual(Buffer.from(left),Buffer.from(right));
const transactionId=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(value)?value:null;
const paymentId=(value:unknown)=>{const normalized=typeof value==='bigint'?value.toString():typeof value==='number'&&Number.isSafeInteger(value)?String(value):value;return typeof normalized==='string'&&/^[1-9]\d{0,39}$/.test(normalized)?normalized:null;};
const boolean=(value:unknown)=>value===true||value===1||value==='1';

function money(value:unknown):{minor:string;decimal:string;number:number}|null{
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 if(minor<=0n||minor>10000000n)return null;
 const decimal=`${minor/100n}.${String(minor%100n).padStart(2,'0')}`;
 return {minor:minor.toString(),decimal,number:Number(decimal)};
}
export const gspayPlayerUsername=(userId:string)=>`m7${sha256(userId).slice(0,30)}`;
export const gspayOrderSignature=(id:string,playerUsername:string,amount:string,secret:string)=>md5(id+playerUsername+amount+secret);
export const gspayResultSignature=(id:string,amount:string,transaction:string,secret:string)=>md5(id+amount+transaction+secret);
function credentials(c:GSPayContext){const key=(value:unknown)=>typeof value==='string'&&/^[A-Fa-f0-9]{32,128}$/.test(value);return c.apiBase===apiOrigin&&key(c.authKey)&&key(c.secretKey)&&c.returnUrl===canonicalReturnUrl;}
export const gspayProgramConfigured=credentials;

function checkoutUrl(value:unknown,expectedPaymentId:string){
 try{
  const url=new URL(String(value)),keys=[...url.searchParams.keys()].filter(key=>key!=='return').sort(),redirect=url.searchParams.get('return');
  if(url.origin!==checkoutOrigin||url.pathname!=='/channel'||url.username||url.password||url.port||url.hash||keys.join(',')!=='id,key'||url.searchParams.get('id')!==expectedPaymentId||!/^[A-Fa-f0-9]{32}$/.test(url.searchParams.get('key')??'')||(redirect!==null&&redirect!==canonicalReturnUrl))return '';
  url.searchParams.set('return',canonicalReturnUrl);return url.href;
 }catch{return '';}
}
async function boundedText(response:Response,max=65536){
 const reader=response.body?.getReader();if(!reader)throw Error('EMPTY_RESPONSE');let size=0;const parts:Uint8Array[]=[];
 for(;;){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>max){await reader.cancel();throw Error('RESPONSE_TOO_LARGE');}parts.push(next.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}return new TextDecoder().decode(bytes);
}
async function providerJson(c:GSPayContext,path:string,method:'GET'|'POST',payload?:unknown,query?:Record<string,string>){
 const url=new URL(path,apiOrigin);for(const [key,value] of Object.entries(query??{}))url.searchParams.set(key,value);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.fetchImpl??fetch)(url,{method,redirect:'error',signal:controller.signal,headers:{Accept:'application/json',...(payload===undefined?{}:{'Content-Type':'application/json'})},...(payload===undefined?{}:{body:JSON.stringify(payload)})});
  if(response.redirected||(response.url&&response.url!==url.href)){await response.body?.cancel();throw new PaymentRequestError({kind:'PROVIDER_RESPONSE',httpStatus:response.status});}
  const raw=await boundedText(response);let value:unknown;try{value=JSON.parse(raw);}catch{throw new PaymentRequestError({kind:'INVALID_JSON',httpStatus:response.status});}
  if(!response.ok||!value||typeof value!=='object'||Array.isArray(value))throw new PaymentRequestError({kind:'PROVIDER_HTTP',httpStatus:response.status});return value as Record<string,unknown>;
 }finally{clearTimeout(timer);}
}
function providerData(value:Record<string,unknown>,requireCode=true){
 if(requireCode&&value.code!==200&&value.code!=='200')return null;let data:unknown=value.data??value;
 if(typeof data==='string'){if(Buffer.byteLength(data)>32768)return null;try{data=JSON.parse(data);}catch{return null;}}
 if(Array.isArray(data)){if(data.length!==1)return null;data=data[0];}
 return data&&typeof data==='object'&&!Array.isArray(data)?data as Record<string,unknown>:null;
}
const orderEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/payment`;
const queryEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/getpayment`;
async function queryPayment(c:GSPayContext,order:any,expectedPaymentId?:string){
 const amount=money(`${BigInt(order.amount_minor)/100n}.${String(BigInt(order.amount_minor)%100n).padStart(2,'0')}`)!;
 const envelope=await providerJson(c,queryEndpoint(c),'GET',undefined,{auth_key:c.authKey!,transaction_id:order.id}),result=providerData(envelope,envelope.code!==undefined);
 const reference=paymentId(result?.payment_id),returnedAmount=money(result?.amount),player=gspayPlayerUsername(order.user_id),signature=typeof result?.signature==='string'?result.signature:'',expectedSignature=reference?gspayResultSignature(reference,amount.decimal,order.id,c.secretKey!):'';
 if(!result||!reference||result.transaction_id!==order.id||result.player_username!==player||returnedAmount?.minor!==amount.minor||!constantEqual(signature,expectedSignature)||(expectedPaymentId&&reference!==expectedPaymentId)||(order.provider_trade_no&&reference!==String(order.provider_trade_no)))throw Error('QUERY_BINDING_MISMATCH');
 return {paymentId:reference,completed:boolean(result.completed),success:boolean(result.success)};
}

async function verifyLedger(c:GSPayContext,order:any){
 const result=await c.db.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=?').bind(order.id).all<any>(),rows=result.results??[],member=rows.find((row:any)=>row.account_code==='member'),clearing=rows.find((row:any)=>row.account_code==='provider_clearing');
 return rows.length===2&&rows.every((row:any)=>row.currency==='MYR'&&row.user_id===order.user_id)&&String(member?.amount_minor)===String(order.amount_minor)&&BigInt(clearing?.amount_minor??0)===-BigInt(order.amount_minor)&&BigInt(member?.amount_minor??0)+BigInt(clearing?.amount_minor??0)===0n;
}
async function credit(c:GSPayContext,order:any,reference:string){
 const existing=await c.db.prepare('SELECT id FROM wallet_ledger WHERE order_id=?').bind(order.id).all();
 if((existing.results??[]).length&&!await verifyLedger(c,order)){await c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=?").bind(Math.floor(Date.now()/1000),order.id).run();throw Error('LEDGER_REVIEW_REQUIRED');}
 const timestamp=Math.floor(Date.now()/1000);
 await c.db.batch([
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'member',amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='gspay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,reference),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'provider_clearing',-amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='gspay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,reference),
  c.db.prepare("UPDATE deposit_orders SET status='credited',provider_trade_no=?,updated_at=? WHERE id=? AND provider='gspay' AND status!='review' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(reference,timestamp,order.id,reference),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),order.user_id,'gspay_deposit_credited',order.id,timestamp),
 ]);
 if(!await verifyLedger(c,order))throw Error('LEDGER_REVIEW_REQUIRED');
}
async function reconcile(c:GSPayContext,order:any,expectedPaymentId?:string){
 const timestamp=Math.floor(Date.now()/1000),age=timestamp-Number(order.created_at),reference=expectedPaymentId??paymentId(order.provider_trade_no)??undefined,rejected=order.status==='failed';
 if(order.status==='review')return 'review';
 if(!reference){if(age>=600)await c.db.prepare("UPDATE deposit_orders SET status='failed',updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(timestamp,order.id).run();return age>=600?'expired':'awaiting_confirmation';}
 try{
  const result=await queryPayment(c,order,reference);
  if(result.completed&&result.success){
   if(rejected){await c.db.batch([c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status='failed'").bind(result.paymentId,timestamp,order.id),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),order.user_id,'gspay_late_success_review',order.id,timestamp)]);return 'review';}
   await credit(c,order,result.paymentId);return 'credited';
  }
  if(result.completed||age>=600){await c.db.prepare("UPDATE deposit_orders SET status='failed',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(reference,timestamp,order.id).run();return result.completed?'failed':'expired';}
  return 'awaiting_confirmation';
 }catch(error){
  if(error instanceof Error&&error.message==='QUERY_BINDING_MISMATCH'){await c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND status!='credited'").bind(timestamp,order.id).run();throw error;}
  if(age>=600){await c.db.prepare("UPDATE deposit_orders SET status='failed',updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(timestamp,order.id).run();return 'expired';}
  throw error;
 }
}
async function callbackBody(req:Request){
 if(!req.headers.get('content-type')?.toLowerCase().startsWith('application/json'))return null;
 const raw=await boundedText(new Response(req.body),16384);let value:unknown;try{value=JSON.parse(raw);}catch{return null;}return value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:null;
}
function callbackKind(path:string){if(path===paymentCallbackPath||path===legacyPaymentCallbackPath)return'payment';if(path===duitNowCallbackPath)return'duitnow';if(path===payoutCallbackPath)return'payout';return'';}
export async function handleGSPayCallback(req:Request,c:GSPayContext):Promise<Response|null>{
 const url=new URL(req.url),kind=callbackKind(url.pathname);if(!kind)return null;
 if(req.method==='GET')return json({ok:true,provider,callback:kind,active:kind==='payment'&&credentials(c),settlementVerified:false});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(kind!=='payment')return json({error:`GSPAY_${kind.toUpperCase()}_DISABLED`,provider,enabled:false},410);
 if(!credentials(c))return ack('unavailable',503);
 let data:Record<string,unknown>|null;try{data=await callbackBody(req);}catch{return ack('invalid',400);}if(!data)return ack('invalid',400);
 const queryAuth=url.searchParams.get('auth_key'),bodyAuth=typeof data.auth_key==='string'?data.auth_key:null;
 if(queryAuth&&bodyAuth&&!constantEqual(queryAuth,bodyAuth))return ack('unauthorized',401);
 const suppliedAuth=queryAuth??bodyAuth;if(!suppliedAuth||!constantEqual(suppliedAuth,c.authKey!))return ack('unauthorized',401);
 const orderId=transactionId(data.transaction_id),reference=paymentId(data.payment_id),amount=money(data.amount),signature=typeof data.signature==='string'?data.signature:'';
 if(!orderId||!reference||!amount||!constantEqual(signature,gspayResultSignature(reference,amount.decimal,orderId,c.secretKey!)))return ack('unauthorized',401);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='gspay'").bind(orderId).first<any>();if(!order)return ack('unknown_order',404);
 if(String(order.amount_minor)!==amount.minor||gspayPlayerUsername(order.user_id)!==data.player_username||(order.provider_trade_no&&String(order.provider_trade_no)!==reference))return ack('review_required',409);
 if(order.status==='credited')return await verifyLedger(c,order)?ack():ack('ledger_review',503);
 if(!boolean(data.completed)||!boolean(data.success)){if(boolean(data.completed))await c.db.prepare("UPDATE deposit_orders SET status='failed',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status NOT IN ('credited','review')").bind(reference,Math.floor(Date.now()/1000),order.id).run();return ack();}
 try{const status=await reconcile(c,order,reference);return status==='credited'||status==='review'?ack():ack('pending',503);}catch{return ack('pending',503);}
}

export async function handleGSPay(req:Request,c:GSPayContext):Promise<Response|null>{
 const path=new URL(req.url).pathname;if(path!=='/api/payments/gspay/status'||req.method!=='GET')return null;
 const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='gspay'").first<{status:string}>(),channelStatus=channel?.status??'closed',programConfigured=credentials(c),enabled=programConfigured&&c.enabled==='true'&&channelStatus==='active';
 return json({provider,currency:'MYR',enabled,mode:enabled?'production':'disabled',channelStatus,programConfigured,createProgramReady:programConfigured,orderReady:enabled,queryReady:programConfigured,callbacksReady:programConfigured,realPayments:enabled,settlementVerified:false,liveReady:false});
}
export async function createGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member')return json({error:'Member account required'},403);if(!user.approved)return json({error:'Account awaiting approval'},403);
 const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='gspay'").first<{status:string}>();if(!credentials(c)||c.enabled!=='true'||channel?.status!=='active')return json({error:'GSPAY_NOT_READY'},503);
 const amount=money(data.amount),requestKey=typeof data.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(data.requestKey)?data.requestKey:null;if(!amount||!requestKey)return json({error:'Invalid MYR order'},400);
 const playerUsername=gspayPlayerUsername(user.id),fingerprint=sha256(JSON.stringify({provider,amount:amount.minor,playerUsername,currency:'MYR',authKey:c.authKey})),timestamp=Math.floor(Date.now()/1000),newId=`G7${crypto.randomUUID().replaceAll('-','').slice(0,30)}`;
 await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,'gspay',?,'MYR','payment','pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(newId,user.id,requestKey,fingerprint,amount.minor,timestamp,timestamp).run();
 const order=await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(user.id,requestKey).first<any>();if(!order)return json({error:'Order unavailable'},503);if(order.fingerprint!==fingerprint||order.provider!==provider)return json({error:'IDEMPOTENCY_CONFLICT'},409);
 if(order.status==='created'&&paymentId(order.provider_trade_no)){const payUrl=checkoutUrl(order.checkout_url,String(order.provider_trade_no)),expiresAt=Number(order.expires_at_raw);if(payUrl&&Number.isSafeInteger(expiresAt)&&expiresAt>timestamp)return json({id:order.id,status:'awaiting_payment',payUrl,providerTradeNo:order.provider_trade_no,expiresAt:String(expiresAt)});return json({id:order.id,status:'awaiting_confirmation',payUrl:null,expiresAt:order.expires_at_raw},202);}
 if(order.status!=='pending')return json({id:order.id,status:order.status==='credited'?'credited':order.status==='failed'?'expired':'awaiting_confirmation',payUrl:null},202);
 const claimed=await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(timestamp,order.id).first();if(!claimed)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 try{
  const payload={transaction_id:order.id,amount:amount.number,player_username:playerUsername,signature:gspayOrderSignature(order.id,playerUsername,amount.decimal,c.secretKey!)};
  const envelope=await providerJson(c,orderEndpoint(c),'POST',payload),result=providerData(envelope),reference=paymentId(result?.payment_id),payUrl=reference?checkoutUrl(result?.payment_url,reference):'';
  if(!result||!reference||!payUrl)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerCode:safeProviderCode(envelope.code),providerTradeNo:reference??undefined,missing:[...(!reference?['providerTradeNo']:[]),...(!payUrl?['checkoutUrl']:[])]});
  const expiresAt=String(timestamp+120);await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,expires_at_raw=?,updated_at=? WHERE id=? AND status='creating'").bind(reference,payUrl,expiresAt,Math.floor(Date.now()/1000),order.id).run();return json({id:order.id,status:'awaiting_payment',payUrl,providerTradeNo:reference,expiresAt},201);
 }catch(error){await c.db.prepare("UPDATE deposit_orders SET status='unknown',updated_at=? WHERE id=? AND status='creating'").bind(Math.floor(Date.now()/1000),order.id).run();await recordPaymentDiagnostic(c.db,user.id,provider,order.id,error);return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);}
}
export async function refreshGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member'||!user.approved)return json({error:'Member account required'},403);if(!credentials(c))return json({error:'GSPAY_NOT_CONFIGURED'},503);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='gspay'").bind(transactionId(data.orderId)??'',user.id).first<any>();if(!order)return json({error:'Order not found'},404);if(order.status==='credited')return await verifyLedger(c,order)?json({id:order.id,status:'credited'}):json({error:'Ledger review required'},503);
 try{const status=await reconcile(c,order);return json({id:order.id,status},status==='credited'?200:202);}catch{return json({id:order.id,status:'awaiting_confirmation'},202);}
}
