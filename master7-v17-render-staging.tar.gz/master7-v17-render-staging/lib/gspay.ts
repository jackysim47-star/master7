import {createHash,timingSafeEqual} from 'node:crypto';
import {PaymentRequestError,recordPaymentDiagnostic,safeProviderCode} from './payment-diagnostics.ts';
import {paymentCapability,automaticDepositCapability,automaticPaymentStatus} from './payment-capabilities.ts';
import {claimPaymentRecovery,escalateExhaustedPaymentRecoveries,finishPaymentRecovery,recoveryCandidates} from './payment-recovery.ts';
import {malaysiaBankCodes} from './malaysia-banks.ts';
import {decryptWithdrawalValue,withdrawalDataKeyReady} from './withdrawal-secrets.ts';
import {walletGuardStatements,walletRiskFreeSql,walletAvailableSql} from './wallet-guard.ts';
import {matchesCustomerPortalEndpoint} from './portal-origin.mjs';

type Member={id:string;username:string;role:string;approved:number};
export type GSPayContext={db:D1Database;user:Member|null;apiBase?:string;authKey?:string;secretKey?:string;callbackToken?:string;enabled?:string;newDepositsEnabled?:string;portalOrigins?:string[];returnUrl?:string;recoveryEnabled?:string;balanceEnabled?:string;payoutEnabled?:string;newPayoutsEnabled?:string;payoutIpWhitelistConfirmed?:string;payoutBankTargetsJson?:string;withdrawalDataKey?:string;acceptance?:{realPaymentVerified:boolean;settlementVerified:boolean};fetchImpl?:typeof fetch};
export type GSPayPayoutInput={payoutId:string;withdrawalId:string;userId:string;accountHolder:string;accountNumber:string;bankCode:string;amountMinor:string};

// Guard the member before changing any payout status, so a risk transition
// serializes with a new reservation. Network requests run outside this batch.
async function memberBatch(c:GSPayContext,userId:string,statements:D1PreparedStatement[]){
 const results=await c.db.batch([...walletGuardStatements(c.db,userId),...statements]);
 return results.slice(2);
}
function changeCount(result:unknown){const r=result as {meta?:{changes?:number};changes?:number}|undefined;return Number(r?.meta?.changes??r?.changes??0);}

const provider='gspay';
const apiOrigin='https://api.thegspay.com';
const gatewayOrigin='https://master7-integration-gateway.onrender.com';
const checkoutOrigin='https://secured.gspay.online';
const paymentCallbackPath='/api/payment/gspay/callback';
const legacyPaymentCallbackPath='/api/payment-callbacks/gspay/payment';
const duitNowCallbackPath='/api/payment/gspay/duitnow/callback';
const payoutCallbackPath='/api/payment/gspay/payout/callback';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const ack=(value='ok',status=200)=>new Response(value,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const sha256=(value:string)=>createHash('sha256').update(value).digest('hex');
const md5=(value:string)=>createHash('md5').update(value).digest('hex');
const constantEqual=(left:unknown,right:string)=>typeof left==='string'&&Buffer.byteLength(left)===Buffer.byteLength(right)&&timingSafeEqual(Buffer.from(left),Buffer.from(right));
const transactionId=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(value)?value:null;
const paymentId=(value:unknown)=>{const normalized=typeof value==='bigint'?value.toString():typeof value==='number'&&Number.isSafeInteger(value)?String(value):value;return typeof normalized==='string'&&/^[1-9]\d{0,39}$/.test(normalized)?normalized:null;};
const boolean=(value:unknown)=>value===true||value===1||value==='1';

function money(value:unknown):{minor:string;decimal:string;number:number}|null{
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 if(minor<=0n||minor>10000000n)return null;
 const decimal=`${minor/100n}.${String(minor%100n).padStart(2,'0')}`;
 return {minor:minor.toString(),decimal,number:Number(decimal)};
}
export const gspayPlayerUsername=(userId:string)=>`m7${sha256(userId).slice(0,30)}`;
export const gspayOrderSignature=(id:string,playerUsername:string,amount:string,secret:string)=>md5(id+playerUsername+amount+secret);
export const gspayResultSignature=(id:string,amount:string,transaction:string,secret:string)=>md5(id+amount+transaction+secret);
export const gspayPayoutSignature=(transaction:string,playerUsername:string,amount:string,accountNumber:string,secret:string)=>md5(transaction+playerUsername+amount+accountNumber+secret);
export const gspayPayoutResultSignature=(payoutId:string,accountNumber:string,amount:string,transaction:string,secret:string)=>md5(payoutId+accountNumber+amount+transaction+secret);
const internalToken=(value:unknown)=>typeof value==='string'&&Buffer.byteLength(value)>=32&&Buffer.byteLength(value)<=1024;
const gatewayMode=(c:GSPayContext)=>c.apiBase===gatewayOrigin;
function credentials(c:GSPayContext){const key=(value:unknown)=>typeof value==='string'&&/^[A-Fa-f0-9]{32,128}$/.test(value);return [apiOrigin,gatewayOrigin].includes(c.apiBase??'')&&key(c.authKey)&&key(c.secretKey)&&c.authKey!==c.secretKey&&matchesCustomerPortalEndpoint(c.returnUrl,c.portalOrigins,'/payment/return')&&(!gatewayMode(c)||(internalToken(c.callbackToken)&&c.callbackToken!==c.authKey&&c.callbackToken!==c.secretKey));}
export const gspayProgramConfigured=credentials;

function payoutBankTargets(c:GSPayContext){
 if(typeof c.payoutBankTargetsJson!=='string'||Buffer.byteLength(c.payoutBankTargetsJson)>8192)return null;
 let parsed:unknown;try{parsed=JSON.parse(c.payoutBankTargetsJson);}catch{return null;}
 if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))return null;const source=parsed as Record<string,unknown>,result:Record<string,string>={},used=new Set<string>();
 for(const code of malaysiaBankCodes){const value=source[code];if(typeof value!=='string'||!/^[A-Za-z0-9._ -]{1,64}$/.test(value)||used.has(value))return null;result[code]=value;used.add(value);}
 return result;
}
function payoutConfiguration(c:GSPayContext){return c.apiBase===apiOrigin&&credentials(c)&&withdrawalDataKeyReady(c.withdrawalDataKey)&&c.payoutIpWhitelistConfirmed==='true'&&payoutBankTargets(c)!==null;}
export const gspayPayoutConfigured=payoutConfiguration;

export async function gspayPayoutAvailability(c:GSPayContext){
 const [channel,control]=await Promise.all([
  c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='gspay'").first<{status:string}>(),
  c.db.prepare("SELECT submission_enabled FROM provider_payout_controls WHERE provider_id='gspay'").first<{submission_enabled:number}>(),
 ]);
 const configured=payoutConfiguration(c),channelActive=channel?.status==='active',submissionEnabled=Number(control?.submission_enabled)===1,enabled=configured&&c.payoutEnabled==='true'&&c.newPayoutsEnabled==='true'&&channelActive&&submissionEnabled;
 const reason=!credentials(c)?'Provider credentials are incomplete':!withdrawalDataKeyReady(c.withdrawalDataKey)?'Withdrawal security is not configured':c.payoutIpWhitelistConfirmed!=='true'?'Provider server IP whitelist is not confirmed':!payoutBankTargets(c)?'Provider bank targets are not configured':c.payoutEnabled!=='true'?'Payout submission switch is disabled':c.newPayoutsEnabled!=='true'?'New payouts are temporarily paused':!channelActive?'Payment channel is not active':!submissionEnabled?'Payout control is disabled':'';
 return {implemented:true,configured,enabled,channelActive,submissionEnabled,reason};
}

export function gspayCapabilitySnapshot(c:GSPayContext,channelActive=false,submissionEnabled=false){
  const configured=credentials(c),ordersEnabled=configured&&c.enabled==='true'&&c.newDepositsEnabled==='true',balanceConfigured=c.apiBase===apiOrigin&&configured;
 const payoutConfigured=payoutConfiguration(c),payoutEnabled=payoutConfigured&&channelActive&&submissionEnabled&&c.payoutEnabled==='true'&&c.newPayoutsEnabled==='true';
 return {
   deposit:automaticDepositCapability({implemented:true,configured,enabled:ordersEnabled,blockers:[...(!configured?['deposit_configuration_incomplete']:[]),...(c.newDepositsEnabled!=='true'?['new_deposits_paused']:[]),...(c.enabled!=='true'?['profile_orders_disabled']:[])]},'configuration'),
  payout:paymentCapability({implemented:true,configured:payoutConfigured,enabled:payoutEnabled,submissionEnabled:payoutEnabled,blockers:[...(!credentials(c)?['payout_credentials_incomplete']:[]),...(!withdrawalDataKeyReady(c.withdrawalDataKey)?['withdrawal_security_not_configured']:[]),...(c.payoutIpWhitelistConfirmed!=='true'?['server_ip_whitelist_not_confirmed']:[]),...(!payoutBankTargets(c)?['bank_targets_not_configured']:[]),...(c.payoutEnabled!=='true'?['submission_disabled']:[]),...(c.newPayoutsEnabled!=='true'?['new_payouts_paused']:[]),...(!channelActive?['channel_not_active']:[]),...(!submissionEnabled?['payout_control_disabled']:[])]}),
  balance:paymentCapability({implemented:true,configured:balanceConfigured,enabled:balanceConfigured&&c.balanceEnabled==='true',blockers:[...(!balanceConfigured?['balance_configuration_incomplete']:[]),...(c.balanceEnabled!=='true'?['balance_query_disabled']:[])]}),
 };
}

function checkoutUrl(value:unknown,expectedPaymentId:string,returnUrl:string){
 try{
  const url=new URL(String(value)),keys=[...url.searchParams.keys()].filter(key=>key!=='return').sort(),redirect=url.searchParams.get('return');
  if(url.origin!==checkoutOrigin||url.pathname!=='/channel'||url.username||url.password||url.port||url.hash||keys.join(',')!=='id,key'||url.searchParams.get('id')!==expectedPaymentId||!/^[A-Fa-f0-9]{32}$/.test(url.searchParams.get('key')??'')||(redirect!==null&&redirect!==returnUrl))return '';
  url.searchParams.set('return',returnUrl);return url.href;
 }catch{return '';}
}
async function boundedText(response:Response,max=65536){
 const reader=response.body?.getReader();if(!reader)throw Error('EMPTY_RESPONSE');let size=0;const parts:Uint8Array[]=[];
 for(;;){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>max){await reader.cancel();throw Error('RESPONSE_TOO_LARGE');}parts.push(next.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}return new TextDecoder().decode(bytes);
}
async function providerJson(c:GSPayContext,path:string,method:'GET'|'POST',payload?:unknown,query?:Record<string,string>){
 const url=new URL(path,c.apiBase);for(const [key,value] of Object.entries(query??{}))url.searchParams.set(key,value);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.fetchImpl??fetch)(url,{method,redirect:'error',signal:controller.signal,headers:{Accept:'application/json',...(payload===undefined?{}:{'Content-Type':'application/json'})},...(payload===undefined?{}:{body:JSON.stringify(payload)})});
  if(response.redirected||(response.url&&response.url!==url.href)){await response.body?.cancel();throw new PaymentRequestError({kind:'PROVIDER_RESPONSE',httpStatus:response.status});}
  const raw=await boundedText(response);let value:unknown;try{value=JSON.parse(raw);}catch{throw new PaymentRequestError({kind:'INVALID_JSON',httpStatus:response.status});}
  if(!response.ok||!value||typeof value!=='object'||Array.isArray(value))throw new PaymentRequestError({kind:'PROVIDER_HTTP',httpStatus:response.status});return value as Record<string,unknown>;
 }finally{clearTimeout(timer);}
}
function providerData(value:Record<string,unknown>,requireCode=true){
 if(requireCode&&value.code!==200&&value.code!=='200')return null;let data:unknown=value.data??value;
 if(typeof data==='string'){if(Buffer.byteLength(data)>32768)return null;try{data=JSON.parse(data);}catch{return null;}}
 if(Array.isArray(data)){if(data.length!==1)return null;data=data[0];}
 return data&&typeof data==='object'&&!Array.isArray(data)?data as Record<string,unknown>:null;
}
const orderEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/payment`;
const queryEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/getpayment`;
const payoutEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/payout`;
const payoutStatusEndpoint=(c:GSPayContext)=>`/v2/integrations/operators/${encodeURIComponent(c.authKey!)}/payout/status`;
const queryBoolean=(value:unknown)=>value===true||value===1||value==='1'?true:value===false||value===0||value==='0'?false:null;
async function queryPayment(c:GSPayContext,order:any,expectedPaymentId?:string){
 if(order.currency!=='MYR')throw Error('QUERY_BINDING_MISMATCH');
 const amount=money(`${BigInt(order.amount_minor)/100n}.${String(BigInt(order.amount_minor)%100n).padStart(2,'0')}`)!;
 const envelope=await providerJson(c,queryEndpoint(c),'GET',undefined,{auth_key:c.authKey!,transaction_id:order.id}),result=providerData(envelope,envelope.code!==undefined);
 const reference=paymentId(result?.payment_id),returnedAmount=money(result?.amount),player=gspayPlayerUsername(order.user_id),signature=typeof result?.signature==='string'?result.signature:'',expectedSignature=reference?gspayResultSignature(reference,amount.decimal,order.id,c.secretKey!):'';
 if(!result||!reference||typeof result.transaction_id!=='string'||!result.transaction_id||typeof result.player_username!=='string'||!result.player_username||!returnedAmount||!signature)throw Error('QUERY_RESPONSE_UNCONFIRMED');
 if(result.transaction_id!==order.id||result.player_username!==player||returnedAmount.minor!==amount.minor||!constantEqual(signature,expectedSignature)||(result.currency!==undefined&&result.currency!=='MYR')||(expectedPaymentId&&reference!==expectedPaymentId)||(order.provider_trade_no&&reference!==String(order.provider_trade_no)))throw Error('QUERY_BINDING_MISMATCH');
 const completed=queryBoolean(result.completed),success=queryBoolean(result.success);if(completed===null||success===null||success&&!completed)throw Error('QUERY_STATUS_UNCONFIRMED');
 return {paymentId:reference,completed,success};
}

const decimalFromMinor=(value:unknown)=>{try{const minor=BigInt(String(value));if(minor<=0n||minor>10000000n)return null;return `${minor/100n}.${String(minor%100n).padStart(2,'0')}`;}catch{return null;}};
const cleanPayoutName=(value:unknown)=>typeof value==='string'&&value.length>=2&&value.length<=80&&!/[\u0000-\u001f\u007f-\u009f]/u.test(value)?value:null;
const cleanPayoutAccount=(value:unknown)=>typeof value==='string'&&/^\d{6,20}$/.test(value)?value:null;
async function payoutRecord(c:GSPayContext,payoutId:string){
 return c.db.prepare(`SELECT p.*,w.user_id,w.status withdrawal_status,w.bank_code,w.account_holder_encrypted,w.account_number_encrypted,w.amount_minor withdrawal_amount_minor,w.currency withdrawal_currency,w.request_key withdrawal_request_key,w.updated_by approver_id,cr.version compliance_version,cr.identity_status,cr.aml_status
  FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id LEFT JOIN manual_compliance_reviews cr ON cr.user_id=w.user_id
  WHERE p.id=? AND p.provider_id='gspay' AND w.provider_id='gspay'`).bind(payoutId).first<any>();
}
function payoutSecrets(c:GSPayContext,payout:any){
 try{
  const accountHolder=cleanPayoutName(decryptWithdrawalValue(String(payout.account_holder_encrypted),c.withdrawalDataKey)),accountNumber=cleanPayoutAccount(decryptWithdrawalValue(String(payout.account_number_encrypted),c.withdrawalDataKey));
  return accountHolder&&accountNumber?{accountHolder,accountNumber}:null;
 }catch{return null;}
}
function payoutBindingValid(c:GSPayContext,payout:any){
 const bound=payoutSecrets(c,payout);
 const fingerprint=bound?sha256(JSON.stringify({provider:'gspay',userId:payout.user_id,amount:String(payout.amount_minor),bank:payout.bank_code,account:sha256(bound.accountNumber)})):'';
 return !!bound&&payout.fingerprint===fingerprint&&payout.request_key===payout.withdrawal_request_key&&String(payout.withdrawal_amount_minor)===String(payout.amount_minor)&&payout.withdrawal_currency==='MYR'&&payout.currency==='MYR'&&(payout.provider_reference==null||!!paymentId(payout.provider_reference));
}
async function queryPayout(c:GSPayContext,payout:any,expectedPayoutId?:string){
 const amount=decimalFromMinor(payout.amount_minor),secrets=payoutSecrets(c,payout);if(!amount||!secrets||!payoutBindingValid(c,payout))throw Error('PAYOUT_BINDING_MISMATCH');
 const envelope=await providerJson(c,payoutStatusEndpoint(c),'GET',undefined,{auth_key:c.authKey!,transaction_id:payout.id}),result=providerData(envelope,envelope.code!==undefined),reference=paymentId(result?.payout_id),returnedAmount=money(result?.amount),signature=typeof result?.signature==='string'?result.signature:'';
 const expectedSignature=reference?gspayPayoutResultSignature(reference,secrets.accountNumber,amount,payout.id,c.secretKey!):'';
 if(!result||!reference||result.transaction_id!==payout.id||result.account_number!==secrets.accountNumber||result.account_name!==secrets.accountHolder||returnedAmount?.minor!==String(payout.amount_minor)||!constantEqual(signature,expectedSignature)||(expectedPayoutId&&reference!==expectedPayoutId)||(payout.provider_reference&&reference!==String(payout.provider_reference)))throw Error('PAYOUT_BINDING_MISMATCH');
 const completed=queryBoolean(result.completed),success=queryBoolean(result.payout_success);
 if(completed===null||success===null||success&&!completed)throw Error('PAYOUT_STATUS_UNCONFIRMED');
 if(result.currency!==undefined&&result.currency!=='MYR')throw Error('PAYOUT_BINDING_MISMATCH');
 return {payoutId:reference,completed,success};
}
// Resolve responses from committed state, never from an earlier query snapshot.
async function storedPayoutResult(c:GSPayContext,payoutId:string){
 const row=await payoutRecord(c,payoutId);if(!row)throw Error('PAYOUT_NOT_FOUND');
 if(row.status==='succeeded'&&row.withdrawal_status==='paid'&&row.currency==='MYR'&&row.withdrawal_currency==='MYR'&&row.create_outcome==='accepted'&&row.last_error_code==null&&paymentId(row.provider_reference)&&payoutBindingValid(c,row)){
  const hold=await c.db.prepare("SELECT 1 FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(row.withdrawal_id).first();
  if(!hold)return {status:'succeeded' as const,providerReference:row.provider_reference};
  return {status:'review' as const,providerReference:row.provider_reference};
 }
 if(row.status==='failed'){
  const cancelled=['rejected','cancelled'].includes(row.withdrawal_status)&&row.create_outcome==='not_submitted'&&row.provider_reference==null&&typeof row.last_error_code==='string'&&row.last_error_code.startsWith('owner_cancel_')&&payoutBindingValid(c,row);
  const hold=await c.db.prepare("SELECT 1 FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(row.withdrawal_id).first();
  return {status:cancelled&&!hold?'failed' as const:'review' as const,providerReference:row.provider_reference};
 }
 if(!payoutBindingValid(c,row)||row.status==='review'||row.status==='succeeded'||!['pending','approved','processing'].includes(row.withdrawal_status))return {status:'review' as const,providerReference:row.provider_reference};
 return {status:'processing' as const,providerReference:row.provider_reference};
}
async function payoutToReview(c:GSPayContext,payout:any,reason:string,reference?:string){
 const now=Math.floor(Date.now()/1000),marker=`gspay_review_${crypto.randomUUID()}`;
 // The original withdrawal and reservation stay open. A failure result may
 // race a later success; funds must not be released on that observation.
 const [changed]=await memberBatch(c,payout.user_id,[
  c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code=?,provider_reference=COALESCE(provider_reference,?),updated_at=? WHERE id=? AND status IN ('prepared','submitting','processing','succeeded') AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(marker,reference??null,now,payout.id,payout.user_id),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'gspay_payout_review',?,? WHERE EXISTS (SELECT 1 FROM provider_payouts WHERE id=? AND status='review' AND last_error_code=?)").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,now,payout.id,marker),
  c.db.prepare("UPDATE provider_payouts SET last_error_code=? WHERE id=? AND status='review' AND last_error_code=?").bind(reason,payout.id,marker),
 ]);
 if(changeCount(changed))return storedPayoutResult(c,payout.id);
 const stored=await storedPayoutResult(c,payout.id);
 if(stored.status==='succeeded'){
  // Preserve the paid withdrawal while recording the contradictory later
  // provider observation for staff investigation; never report it as failed.
  await c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'gspay_payout_conflicting_observation',?,? WHERE NOT EXISTS (SELECT 1 FROM audit WHERE event='gspay_payout_conflicting_observation' AND target=?)").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,now,payout.withdrawal_id).run();
  return {status:'review' as const,providerReference:stored.providerReference};
 }
 return stored;
}
async function finalizePayout(c:GSPayContext,payout:any,result:{payoutId:string;completed:boolean;success:boolean}){
 const timestamp=Math.floor(Date.now()/1000);
 if(!result.completed){await memberBatch(c,payout.user_id,[
  c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),updated_at=? WHERE id=? AND status IN ('prepared','submitting','processing') AND (provider_reference IS NULL OR provider_reference=?) AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(result.payoutId,timestamp,payout.id,result.payoutId,payout.user_id),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND user_id=? AND status IN ('pending','approved','processing') AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.withdrawal_id=withdrawal_requests.id AND p.status='processing' AND p.provider_reference=?)").bind(timestamp,payout.withdrawal_id,payout.user_id,payout.id,result.payoutId),
 ]);return storedPayoutResult(c,payout.id);}
 if(!result.success)return payoutToReview(c,payout,'provider_failed',result.payoutId);
 // The transaction-local marker binds every side effect to this update, not
 // an older succeeded row with a partially processed withdrawal.
 const marker=`gspay_finalize_${crypto.randomUUID()}`;
 await memberBatch(c,payout.user_id,[
  c.db.prepare("UPDATE provider_payouts SET status='succeeded',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),last_error_code=?,updated_at=?,completed_at=COALESCE(completed_at,?) WHERE id=? AND status IN ('submitting','processing') AND (provider_reference IS NULL OR provider_reference=?) AND currency='MYR' AND EXISTS (SELECT 1 FROM withdrawal_requests w JOIN wallet_reservations r ON r.user_id=w.user_id AND r.kind='withdrawal' AND r.reference_id=w.id AND r.amount_minor=w.amount_minor WHERE w.id=provider_payouts.withdrawal_id AND w.provider_id='gspay' AND w.currency='MYR' AND w.amount_minor=provider_payouts.amount_minor AND provider_payouts.amount_minor=? AND w.user_id=? AND w.bank_code=? AND w.account_holder_encrypted=? AND w.account_number_encrypted=? AND w.request_key=? AND provider_payouts.request_key=? AND provider_payouts.fingerprint=? AND w.status IN ('pending','approved','processing'))").bind(result.payoutId,marker,timestamp,timestamp,payout.id,result.payoutId,String(payout.amount_minor),payout.user_id,payout.bank_code,payout.account_holder_encrypted,payout.account_number_encrypted,payout.withdrawal_request_key,payout.request_key,payout.fingerprint),
  c.db.prepare("UPDATE withdrawal_requests SET status='paid',updated_at=? WHERE id=? AND status IN ('pending','approved','processing') AND EXISTS (SELECT 1 FROM provider_payouts p JOIN wallet_reservations r ON r.reference_id=p.withdrawal_id AND r.kind='withdrawal' WHERE p.id=? AND p.withdrawal_id=withdrawal_requests.id AND p.status='succeeded' AND p.last_error_code=? AND p.provider_reference=? AND p.amount_minor=withdrawal_requests.amount_minor AND r.user_id=withdrawal_requests.user_id AND r.amount_minor=withdrawal_requests.amount_minor)").bind(timestamp,payout.withdrawal_id,payout.id,marker,result.payoutId),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=? AND EXISTS (SELECT 1 FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id WHERE p.id=? AND p.status='succeeded' AND p.last_error_code=? AND p.provider_reference=? AND w.status='paid' AND w.user_id=wallet_reservations.user_id AND w.amount_minor=wallet_reservations.amount_minor AND p.amount_minor=w.amount_minor)").bind(payout.withdrawal_id,payout.id,marker,result.payoutId),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'gspay_payout_paid',?,? WHERE EXISTS (SELECT 1 FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id WHERE p.id=? AND p.status='succeeded' AND p.last_error_code=? AND w.status='paid' AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.kind='withdrawal' AND r.reference_id=w.id))").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,timestamp,payout.id,marker),
  c.db.prepare("UPDATE provider_payouts SET last_error_code=NULL WHERE id=? AND status='succeeded' AND last_error_code=? AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.status='paid' AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.kind='withdrawal' AND r.reference_id=w.id))").bind(payout.id,marker),
 ]);
 const stored=await storedPayoutResult(c,payout.id);
 if(stored.status!=='succeeded'&&payout.status!=='succeeded')return payoutToReview(c,payout,'withdrawal_state_conflict',result.payoutId);
 return stored;
}
async function reconcilePayout(c:GSPayContext,payoutId:string,expectedPayoutId?:string){
 const payout=await payoutRecord(c,payoutId);if(!payout)throw Error('PAYOUT_NOT_FOUND');
 if(['failed','review'].includes(payout.status))return storedPayoutResult(c,payout.id);
 try{return await finalizePayout(c,payout,await queryPayout(c,payout,expectedPayoutId));}
 catch(error){if(error instanceof Error&&error.message==='PAYOUT_BINDING_MISMATCH')return payoutToReview(c,payout,'binding_mismatch');throw error;}
}

export async function submitGSPayPayout(input:GSPayPayoutInput,c:GSPayContext){
 const availability=await gspayPayoutAvailability(c);if(!availability.enabled)throw Error('GSPAY_PAYOUT_NOT_READY');
 const payout=await payoutRecord(c,input.payoutId),targets=payoutBankTargets(c),amount=decimalFromMinor(input.amountMinor),target=targets?.[input.bankCode];
 if(!payout||payout.withdrawal_id!==input.withdrawalId||payout.user_id!==input.userId||String(payout.amount_minor)!==input.amountMinor||String(payout.withdrawal_amount_minor)!==input.amountMinor||!target||!amount)throw Error('PAYOUT_INPUT_MISMATCH');
 const secrets=payoutSecrets(c,payout);if(!secrets||payout.bank_code!==input.bankCode||secrets.accountHolder!==input.accountHolder||secrets.accountNumber!==input.accountNumber)throw Error('PAYOUT_INPUT_MISMATCH');
 if(payout.status!=='prepared')return payout.status==='submitting'&&!payout.provider_reference?{status:'processing' as const,providerReference:null}:reconcilePayout(c,payout.id);
 if(!payoutBindingValid(c,payout)||payout.identity_status!=='passed'||payout.aml_status!=='passed'||!payout.compliance_version)return {status:'review' as const};
 const snapshot=[payout.withdrawal_id,payout.id,payout.user_id,payout.provider_id,payout.request_key,String(payout.amount_minor),payout.currency,payout.bank_code,payout.account_holder_encrypted,payout.account_number_encrypted,payout.fingerprint,String(payout.compliance_version)];
 const claimMarker=`claim_${crypto.randomUUID()}`;
 const timestamp=Math.floor(Date.now()/1000),[memberLocked,ownerLocked,locked,complianceLocked,claimed,processing,cleared]=await memberBatch(c,payout.user_id,[
  // Lock the withdrawal row as well as the member before checking approval.
  c.db.prepare("UPDATE users SET approved=approved WHERE id=? AND approved=1 AND role='member'").bind(payout.user_id),
  c.db.prepare("UPDATE users SET approved=approved WHERE id=? AND approved=1 AND role='owner'").bind(payout.approver_id),
  c.db.prepare("UPDATE withdrawal_requests SET updated_at=updated_at WHERE id=? AND user_id=? AND status='approved'").bind(payout.withdrawal_id,payout.user_id),
  c.db.prepare("UPDATE manual_compliance_reviews SET updated_at=updated_at WHERE user_id=? AND version=? AND identity_status='passed' AND aml_status='passed'").bind(payout.user_id,payout.compliance_version),
  c.db.prepare(`UPDATE provider_payouts SET status='submitting',create_outcome='in_flight',last_error_code=?,updated_at=?
   WHERE id=? AND withdrawal_id=? AND provider_id=? AND status='prepared' AND create_outcome='not_submitted' AND provider_reference IS NULL
   AND request_key=? AND fingerprint=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'
   AND EXISTS (SELECT 1 FROM withdrawal_requests w
    JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.kind='withdrawal' AND r.amount_minor=w.amount_minor
    JOIN audit requested ON requested.id=('withdrawal_request_v1_' || w.id) AND requested.event='withdrawal_requested_v1' AND requested.target=w.id AND requested.user_id=w.user_id
    JOIN audit approved ON approved.id=('withdrawal_approved_v1_' || w.id) AND approved.event='withdrawal_approved_v1' AND approved.target=w.id AND approved.user_id=w.updated_by AND approved.user_id=?
    JOIN audit binding ON binding.id=? AND binding.event='withdrawal_approval_binding_v1' AND binding.target=w.id AND binding.user_id=w.updated_by
    JOIN users member ON member.id=w.user_id AND member.role='member' AND member.approved=1
    JOIN users owner ON owner.id=approved.user_id AND owner.role='owner' AND owner.approved=1
    JOIN manual_compliance_reviews cr ON cr.user_id=w.user_id AND cr.version=? AND cr.identity_status='passed' AND cr.aml_status='passed'
    WHERE w.id=provider_payouts.withdrawal_id AND w.status='approved' AND w.user_id=? AND w.provider_id=provider_payouts.provider_id
     AND w.request_key=provider_payouts.request_key AND w.amount_minor=provider_payouts.amount_minor AND w.currency=provider_payouts.currency
     AND w.bank_code=? AND w.account_holder_encrypted=? AND w.account_number_encrypted=?
     AND EXISTS (SELECT 1 FROM (SELECT w.user_id AS id) m WHERE ${walletRiskFreeSql} AND ${walletAvailableSql}>=0))`).bind(claimMarker,timestamp,payout.id,payout.withdrawal_id,payout.provider_id,payout.request_key,payout.fingerprint,String(payout.amount_minor),payout.approver_id,`withdrawal_approval_binding_v1_${payout.withdrawal_id}_${sha256(JSON.stringify(snapshot))}`,payout.compliance_version,payout.user_id,payout.bank_code,payout.account_holder_encrypted,payout.account_number_encrypted),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND user_id=? AND status='approved' AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.withdrawal_id=withdrawal_requests.id AND p.status='submitting' AND p.create_outcome='in_flight' AND p.last_error_code=?)").bind(timestamp,payout.withdrawal_id,payout.user_id,payout.id,claimMarker),
  c.db.prepare("UPDATE provider_payouts SET last_error_code=NULL WHERE id=? AND status='submitting' AND last_error_code=? AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=? AND w.status='processing')").bind(payout.id,claimMarker,payout.user_id),
 ]);
 // Never submit unless both the payout claim and withdrawal transition succeed.
 if(!changeCount(memberLocked)||!changeCount(ownerLocked)||!changeCount(locked)||!changeCount(complianceLocked)||!changeCount(claimed))return storedPayoutResult(c,payout.id);
 if(!changeCount(processing)||!changeCount(cleared))return {status:'review' as const};
 const playerUsername=gspayPlayerUsername(payout.user_id),payload={transaction_id:payout.id,player_username:playerUsername,account_name:secrets.accountHolder,account_number:secrets.accountNumber,amount:Number(amount),trx_description:payout.id,bank_target:target,signature:gspayPayoutSignature(payout.id,playerUsername,amount,secrets.accountNumber,c.secretKey!)};
 try{
  const envelope=await providerJson(c,payoutEndpoint(c),'POST',payload),result=providerData(envelope),reference=paymentId(result?.payout_id),accepted=envelope.code===200||envelope.code==='200';
  await memberBatch(c,payout.user_id,[c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome=?,provider_reference=COALESCE(provider_reference,?),last_error_code=NULL,updated_at=? WHERE id=? AND status='submitting' AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(accepted?'accepted':'unknown',reference,Math.floor(Date.now()/1000),payout.id,payout.user_id)]);
  try{return await reconcilePayout(c,payout.id,reference??undefined);}catch{return {status:'processing' as const,providerReference:reference};}
 }catch{
  await memberBatch(c,payout.user_id,[c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='unknown',last_error_code='submission_outcome_unknown',updated_at=? WHERE id=? AND status='submitting' AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(Math.floor(Date.now()/1000),payout.id,payout.user_id)]);
  return {status:'processing' as const,providerReference:null};
 }
}

export async function recoverGSPayPayouts(c:GSPayContext,limit=25){
 const summary={provider,enabled:credentials(c)&&withdrawalDataKeyReady(c.withdrawalDataKey),queried:0,succeeded:0,failed:0,processing:0,review:0,errors:0};if(!summary.enabled)return summary;
 const result=await c.db.prepare("SELECT id FROM provider_payouts WHERE provider_id='gspay' AND status IN ('submitting','processing') ORDER BY updated_at,id LIMIT ?").bind(Math.max(1,Math.min(100,limit))).all<{id:string}>();
 for(const row of result.results??[]){summary.queried++;try{const next=await reconcilePayout(c,row.id);if(next.status==='succeeded')summary.succeeded++;else if(next.status==='failed')summary.failed++;else if(next.status==='review')summary.review++;else summary.processing++;}catch{summary.errors++;}}
 return summary;
}

async function verifyLedger(c:GSPayContext,order:any){
 const result=await c.db.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=?').bind(order.id).all<any>(),rows=result.results??[],member=rows.find((row:any)=>row.account_code==='member'),clearing=rows.find((row:any)=>row.account_code==='provider_clearing');
 return rows.length===2&&rows.every((row:any)=>row.currency==='MYR'&&row.user_id===order.user_id)&&String(member?.amount_minor)===String(order.amount_minor)&&BigInt(clearing?.amount_minor??0)===-BigInt(order.amount_minor)&&BigInt(member?.amount_minor??0)+BigInt(clearing?.amount_minor??0)===0n;
}
// A single snapshot must bind the current order and both balanced ledger legs.
// A prior order or ledger read alone cannot prove the member has been credited.
async function confirmedCredit(c:GSPayContext,order:any,reference:string){
 return !!await c.db.prepare(`SELECT o.id FROM deposit_orders o
  JOIN wallet_ledger m ON m.order_id=o.id AND m.account_code='member'
  JOIN wallet_ledger p ON p.order_id=o.id AND p.account_code='provider_clearing'
  WHERE o.id=? AND o.provider='gspay' AND o.user_id=? AND o.currency='MYR'
   AND o.amount_minor=CAST(? AS BIGINT) AND o.status='credited' AND o.provider_trade_no=?
   AND m.user_id=o.user_id AND p.user_id=o.user_id AND m.currency='MYR' AND p.currency='MYR'
   AND m.amount_minor=o.amount_minor AND p.amount_minor=-o.amount_minor
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=o.id)=2`).bind(order.id,order.user_id,String(order.amount_minor),reference).first();
}
async function credit(c:GSPayContext,order:any,reference:string){
 const existing=await c.db.prepare('SELECT id FROM wallet_ledger WHERE order_id=?').bind(order.id).all();
 if((existing.results??[]).length&&!await verifyLedger(c,order)){await memberBatch(c,order.user_id,[c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay'").bind(Math.floor(Date.now()/1000),order.id,order.user_id,String(order.amount_minor))]);throw Error('LEDGER_REVIEW_REQUIRED');}
 const timestamp=Math.floor(Date.now()/1000);
 await memberBatch(c,order.user_id,[
  // Hold the order row lock for the whole batch so a concurrent terminal result cannot split the accounting decision.
  c.db.prepare("UPDATE deposit_orders SET updated_at=updated_at WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay'").bind(order.id,order.user_id,String(order.amount_minor)),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_late_success_review',id,? FROM deposit_orders WHERE id=? AND provider='gspay' AND status='failed' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='gspay' AND status='failed' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(reference,timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  // Recheck under the member and order locks before inserting either leg.
  // Never auto-complete a historical or concurrently created partial journal.
  c.db.prepare(`UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='gspay' AND currency='MYR' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) AND EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)
   AND NOT ((SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2 AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor))`).bind(reference,timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'member',amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='gspay' AND currency='MYR' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'provider_clearing',-amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='gspay' AND currency='MYR' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  // The journal may have changed since the preliminary read. Only commit
  // credited when BOTH ledger legs match the locked order in this transaction.
  c.db.prepare(`UPDATE deposit_orders SET status='credited',provider_trade_no=?,updated_at=? WHERE id=? AND provider='gspay' AND currency='MYR' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?)
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
   AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor)`).bind(reference,timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_deposit_credited',id,? FROM deposit_orders WHERE id=? AND provider='gspay' AND currency='MYR' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND status='credited' AND provider_trade_no=? AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2 AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor) AND NOT EXISTS (SELECT 1 FROM audit a WHERE a.event='gspay_deposit_credited' AND a.target=deposit_orders.id) ON CONFLICT(id) DO NOTHING").bind('gspay-credit-'+sha256(String(order.id)).slice(0,48),timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='gspay' AND currency='MYR' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) AND EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)").bind(reference,timestamp,order.id,order.user_id,String(order.amount_minor),reference),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_partial_ledger_review',id,? FROM deposit_orders WHERE id=? AND provider='gspay' AND currency='MYR' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND status='review' AND provider_trade_no=? AND NOT EXISTS (SELECT 1 FROM audit a WHERE a.event='gspay_partial_ledger_review' AND a.target=deposit_orders.id) ON CONFLICT(id) DO NOTHING").bind('gspay-partial-'+sha256(String(order.id)).slice(0,48),timestamp,order.id,order.user_id,String(order.amount_minor),reference),
 ]);
 const current=await c.db.prepare("SELECT status FROM deposit_orders WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(order.id,order.user_id,String(order.amount_minor),reference).first<{status:string}>();
 if(current?.status==='review')return 'review';
 if(current?.status!=='credited'||!await confirmedCredit(c,order,reference))throw Error('LEDGER_REVIEW_REQUIRED');
 return 'credited';
}
async function reconcile(c:GSPayContext,order:any,expectedPaymentId?:string){
 const timestamp=Math.floor(Date.now()/1000),reference=expectedPaymentId??paymentId(order.provider_trade_no)??undefined,rejected=order.status==='failed';
 if(order.status==='review')return 'review';
 try{
  const result=await queryPayment(c,order,reference);
  if(result.completed&&result.success){
   if(rejected){await memberBatch(c,order.user_id,[c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay' AND status='failed' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(result.paymentId,timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_late_success_review',id,? FROM deposit_orders WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay' AND status='review' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId)]);return 'review';}
   const member=await c.db.prepare("SELECT id FROM users WHERE id=? AND role='member' AND approved=1").bind(order.user_id).first<{id:string}>();
   if(!member){await memberBatch(c,order.user_id,[c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay' AND status!='credited' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(result.paymentId,timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_member_binding_review',id,? FROM deposit_orders WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay' AND status='review' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId)]);return 'review';}
   return await credit(c,order,result.paymentId);
  }
  if(result.completed){
   // A historical non-credited order may already have an incomplete journal.
   // Keep that anomaly in review under the member lock, never call it failed
   // or let it race a new wallet reservation.
   await memberBatch(c,order.user_id,[
    c.db.prepare("UPDATE deposit_orders SET updated_at=updated_at WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'").bind(order.id,order.user_id,String(order.amount_minor)),
    // A failure observed after success is a provider-state conflict; keep
    // both ledger legs and freeze the member for reconciliation.
    c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_paid_status_conflict_review',id,? FROM deposit_orders WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=?").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),
    c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=?").bind(timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),
    c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_failed_partial_ledger_review',id,? FROM deposit_orders WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('credited','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) AND EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),
    c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('credited','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) AND EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)").bind(result.paymentId,timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),
    c.db.prepare("UPDATE deposit_orders SET status='failed',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('credited','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) AND NOT EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)").bind(result.paymentId,timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),
   ]);
   const current=await c.db.prepare("SELECT status FROM deposit_orders WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay' AND provider_trade_no=?").bind(order.id,order.user_id,String(order.amount_minor),result.paymentId).first<{status:string}>();
   if(current?.status==='failed')return 'failed';
   if(current?.status==='review')return 'review';
   if(await confirmedCredit(c,order,result.paymentId))return 'credited';
   return 'awaiting_confirmation';
  }
  // A nonterminal result cannot be reconciled with a previously credited
  // order. Recheck under the same member guard and preserve the journal;
  // a concurrent new credit must not become spendable on stale evidence.
  await memberBatch(c,order.user_id,[
   c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_paid_status_conflict_review',id,? FROM deposit_orders WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=? ON CONFLICT(id) DO NOTHING").bind('gspay-nonterminal-'+sha256(String(order.id)).slice(0,48),timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),
   c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=?").bind(timestamp,order.id,order.user_id,String(order.amount_minor),result.paymentId),
  ]);
  const current=await c.db.prepare("SELECT status FROM deposit_orders WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider_trade_no=?").bind(order.id,order.user_id,String(order.amount_minor),result.paymentId).first<{status:string}>();
  return current?.status==='review'?'review':'awaiting_confirmation';
 }catch(error){
  if(error instanceof Error&&error.message==='QUERY_BINDING_MISMATCH'){
   if(order.status==='credited'&&reference){
    // Only the same credited snapshot may be held: a stale query must not
    // freeze a concurrently rebound order or another member's money.
    await memberBatch(c,order.user_id,[
     c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'gspay_paid_binding_conflict_review',id,? FROM deposit_orders WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=? ON CONFLICT(id) DO NOTHING").bind('gspay-binding-'+sha256(String(order.id)).slice(0,48),timestamp,order.id,order.user_id,String(order.amount_minor),reference),
     c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='gspay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=?").bind(timestamp,order.id,order.user_id,String(order.amount_minor),reference),
    ]);
   }else await memberBatch(c,order.user_id,[c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND provider='gspay' AND status!='credited'").bind(timestamp,order.id,order.user_id,String(order.amount_minor))]);
   throw error;
  }
  throw error;
 }
}
async function callbackBody(req:Request){
 if(!req.headers.get('content-type')?.toLowerCase().startsWith('application/json'))return null;
 const raw=await boundedText(new Response(req.body),16384);let value:unknown;try{value=JSON.parse(raw);}catch{return null;}return value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:null;
}
function callbackKind(path:string){if(path===paymentCallbackPath||path===legacyPaymentCallbackPath)return'payment';if(path===duitNowCallbackPath)return'duitnow';if(path===payoutCallbackPath)return'payout';return'';}
async function payoutCallback(req:Request,c:GSPayContext,url:URL){
 if(!credentials(c)||!withdrawalDataKeyReady(c.withdrawalDataKey))return ack('unavailable',503);
 let data:Record<string,unknown>|null;try{data=await callbackBody(req);}catch{return ack('invalid',400);}if(!data)return ack('invalid',400);
 const queryAuth=url.searchParams.get('auth_key'),bodyAuth=typeof data.auth_key==='string'?data.auth_key:null;if(queryAuth&&bodyAuth&&!constantEqual(queryAuth,bodyAuth))return ack('unauthorized',401);
 const suppliedAuth=queryAuth??bodyAuth;if(!suppliedAuth||!constantEqual(suppliedAuth,c.authKey!))return ack('unauthorized',401);
 const transaction=transactionId(data.transaction_id),reference=paymentId(data.payout_id),amount=money(data.amount),accountNumber=cleanPayoutAccount(data.account_number),signature=typeof data.signature==='string'?data.signature:'';
 if(!transaction||!reference||!amount||!accountNumber||!constantEqual(signature,gspayPayoutResultSignature(reference,accountNumber,amount.decimal,transaction,c.secretKey!)))return ack('unauthorized',401);
 const payout=await payoutRecord(c,transaction),secrets=payout?payoutSecrets(c,payout):null;if(!payout||!secrets)return ack('unknown_order',404);
 if(secrets.accountNumber!==accountNumber||data.account_name!==secrets.accountHolder||String(payout.amount_minor)!==amount.minor||(payout.provider_reference&&String(payout.provider_reference)!==reference)){
  await memberBatch(c,payout.user_id,[c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code='callback_binding_mismatch',updated_at=? WHERE id=? AND status<>'succeeded' AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(Math.floor(Date.now()/1000),payout.id,payout.user_id)]);return ack('review_required',409);
 }
 const eventHash=sha256(JSON.stringify({reference,transaction,amount:amount.minor,completed:boolean(data.completed),success:boolean(data.payout_success)}));
 await memberBatch(c,payout.user_id,[c.db.prepare("UPDATE provider_payouts SET provider_reference=COALESCE(provider_reference,?),last_event_hash=?,updated_at=? WHERE id=? AND status<>'succeeded' AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(reference,eventHash,Math.floor(Date.now()/1000),payout.id,payout.user_id)]);
 try{const result=await reconcilePayout(c,payout.id,reference);return result.status==='review'?ack('review_required',409):ack();}catch{return ack('pending',503);}
}
export async function handleGSPayCallback(req:Request,c:GSPayContext):Promise<Response|null>{
 const url=new URL(req.url),kind=callbackKind(url.pathname);if(!kind)return null;
 if(req.method==='GET')return json({ok:true,provider,callback:kind,active:kind==='payment'?credentials(c):kind==='payout'?credentials(c)&&withdrawalDataKeyReady(c.withdrawalDataKey):false,settlementVerified:false});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(kind==='payout')return payoutCallback(req,c,url);
 if(kind!=='payment')return json({error:`GSPAY_${kind.toUpperCase()}_DISABLED`,provider,enabled:false},410);
 if(!credentials(c))return ack('unavailable',503);
 if(gatewayMode(c)){
  const authorization=req.headers.get('authorization')??'',given=authorization.startsWith('Bearer ')?authorization.slice(7):'';
  if(!internalToken(c.callbackToken)||!constantEqual(given,c.callbackToken!))return ack('unauthorized',401);
 }
 let data:Record<string,unknown>|null;try{data=await callbackBody(req);}catch{return ack('invalid',400);}if(!data)return ack('invalid',400);
 const queryAuth=url.searchParams.get('auth_key'),bodyAuth=typeof data.auth_key==='string'?data.auth_key:null;
 if(queryAuth&&bodyAuth&&!constantEqual(queryAuth,bodyAuth))return ack('unauthorized',401);
 const suppliedAuth=queryAuth??bodyAuth;if(!suppliedAuth||!constantEqual(suppliedAuth,c.authKey!))return ack('unauthorized',401);
 const orderId=transactionId(data.transaction_id),reference=paymentId(data.payment_id),amount=money(data.amount),signature=typeof data.signature==='string'?data.signature:'';
 if(!orderId||!reference||!amount||!constantEqual(signature,gspayResultSignature(reference,amount.decimal,orderId,c.secretKey!)))return ack('unauthorized',401);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='gspay'").bind(orderId).first<any>();if(!order)return ack('unknown_order',404);
 if(String(order.amount_minor)!==amount.minor||gspayPlayerUsername(order.user_id)!==data.player_username||(order.provider_trade_no&&String(order.provider_trade_no)!==reference))return ack('review_required',409);
 if(order.status==='credited'){
  if(!await confirmedCredit(c,order,reference))return ack('ledger_review',503);
  // Provider status is not covered by the documented signature. A later
  // contradictory or incomplete notice must be independently queried before
  // acknowledging it or changing a previously credited financial record.
  if(queryBoolean(data.completed)===true&&queryBoolean(data.success)===true)return ack();
  try{const status=await reconcile(c,order,reference);return status==='credited'?ack():status==='review'?ack('review_required',409):ack('pending',503);}catch{return ack('pending',503);}
 }
 // Callback MD5 binds the payment, amount and order, but not completed/success.
 // Only an independently bound GetPayment result can decide either terminal outcome.
 try{const status=await reconcile(c,order,reference);return status==='credited'||status==='failed'?ack():status==='review'?ack('review_required',409):ack('pending',503);}catch{return ack('pending',503);}
}

export async function handleGSPay(req:Request,c:GSPayContext):Promise<Response|null>{
 const path=new URL(req.url).pathname;if(path!=='/api/payments/gspay/status'||req.method!=='GET')return null;
 const payout=await gspayPayoutAvailability(c),programConfigured=credentials(c),capabilities=gspayCapabilitySnapshot(c,payout.channelActive,payout.submissionEnabled),enabled=capabilities.deposit.enabled;
 const realPaymentVerified=c.acceptance?.realPaymentVerified===true,settlementVerified=c.acceptance?.settlementVerified===true;
 return json({provider,profileId:'gspay_myr',currency:'MYR',enabled,mode:enabled?'production':'disabled',...automaticPaymentStatus(capabilities.deposit),programConfigured,createProgramReady:programConfigured,orderReady:enabled,queryReady:programConfigured,callbacksReady:programConfigured,payoutReady:payout.enabled,realPayments:enabled,realPaymentVerified,settlementVerified,liveReady:enabled&&realPaymentVerified&&settlementVerified,capabilities});
}
export async function createGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member')return json({error:'Member account required'},403);if(!user.approved)return json({error:'Account awaiting approval'},403);
 if(c.newDepositsEnabled!=='true')return json({error:'New deposits are temporarily unavailable',code:'DEPOSITS_MAINTENANCE'},503);
 if(c.enabled!=='true')return json({error:'GSPAY+ MYR new orders are disabled',code:'PROVIDER_ORDERS_DISABLED'},503);
 if(!credentials(c))return json({error:'GSPAY_NOT_READY'},503);
 const amount=money(data.amount),requestKey=typeof data.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(data.requestKey)?data.requestKey:null;if(!amount||!requestKey)return json({error:'Invalid MYR order'},400);
 const playerUsername=gspayPlayerUsername(user.id),fingerprint=sha256(JSON.stringify({provider,amount:amount.minor,playerUsername,currency:'MYR',authKey:c.authKey})),timestamp=Math.floor(Date.now()/1000),newId=`G7${crypto.randomUUID().replaceAll('-','').slice(0,30)}`;
 await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,'gspay',?,'MYR','payment','pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(newId,user.id,requestKey,fingerprint,amount.minor,timestamp,timestamp).run();
 const order=await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(user.id,requestKey).first<any>();if(!order)return json({error:'Order unavailable'},503);if(order.fingerprint!==fingerprint||order.provider!==provider)return json({error:'IDEMPOTENCY_CONFLICT'},409);
 if(order.status==='created'&&paymentId(order.provider_trade_no)&&order.currency==='MYR'&&String(order.amount_minor)===amount.minor){const payUrl=checkoutUrl(order.checkout_url,String(order.provider_trade_no),c.returnUrl!),expiresAt=Number(order.expires_at_raw);if(payUrl&&Number.isSafeInteger(expiresAt)&&expiresAt>timestamp)return json({id:order.id,status:'awaiting_payment',payUrl,providerTradeNo:order.provider_trade_no,expiresAt:String(expiresAt)});return json({id:order.id,status:'awaiting_confirmation',payUrl:null,expiresAt:order.expires_at_raw},202);}
 if(order.status==='credited'){const reference=paymentId(order.provider_trade_no);return reference&&order.currency==='MYR'&&String(order.amount_minor)===amount.minor&&await confirmedCredit(c,order,reference)?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'review',payUrl:null},409);}
 if(order.status!=='pending')return json({id:order.id,status:order.status==='failed'?'expired':'awaiting_confirmation',payUrl:null},202);
 const claimed=await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND fingerprint=? AND provider='gspay' AND status='pending' RETURNING id").bind(timestamp,order.id,user.id,amount.minor,fingerprint).first();if(!claimed)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 try{
  const payload={transaction_id:order.id,amount:amount.number,player_username:playerUsername,signature:gspayOrderSignature(order.id,playerUsername,amount.decimal,c.secretKey!)};
  const envelope=await providerJson(c,orderEndpoint(c),'POST',payload),result=providerData(envelope),reference=paymentId(result?.payment_id),payUrl=reference?checkoutUrl(result?.payment_url,reference,c.returnUrl!):'';
  if(!result||!reference||!payUrl)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerCode:safeProviderCode(envelope.code),providerTradeNo:reference??undefined,missing:[...(!reference?['providerTradeNo']:[]),...(!payUrl?['checkoutUrl']:[])]});
  const expiresAt=String(timestamp+120);
  await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,expires_at_raw=?,updated_at=? WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND fingerprint=? AND provider='gspay' AND status='creating' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(reference,payUrl,expiresAt,Math.floor(Date.now()/1000),order.id,user.id,amount.minor,fingerprint,reference).run();
  // A callback or recovery may have finalized the order before the create response arrived.
  const current=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='gspay'").bind(order.id,user.id).first<any>();
  if(current?.status==='created'&&current.fingerprint===fingerprint&&String(current.amount_minor)===amount.minor&&current.currency==='MYR'&&current.provider_trade_no===reference&&current.checkout_url===payUrl&&String(current.expires_at_raw)===expiresAt&&Number(expiresAt)>Math.floor(Date.now()/1000))return json({id:order.id,status:'awaiting_payment',payUrl,providerTradeNo:reference,expiresAt},201);
  if(current?.status==='credited'&&current.fingerprint===fingerprint&&String(current.amount_minor)===amount.minor&&current.currency==='MYR'&&current.provider_trade_no===reference&&await confirmedCredit(c,current,reference))return json({id:order.id,status:'credited',payUrl:null});
  return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
 }catch(error){await c.db.prepare("UPDATE deposit_orders SET status='unknown',updated_at=? WHERE id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND fingerprint=? AND provider='gspay' AND status='creating'").bind(Math.floor(Date.now()/1000),order.id,user.id,amount.minor,fingerprint).run();await recordPaymentDiagnostic(c.db,user.id,provider,order.id,error);return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);}
}
export async function refreshGSPayOrder(data:Record<string,unknown>,c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='member'||!user.approved)return json({error:'Member account required'},403);if(!credentials(c))return json({error:'GSPAY_NOT_CONFIGURED'},503);
 const order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='gspay'").bind(transactionId(data.orderId)??'',user.id).first<any>();if(!order)return json({error:'Order not found'},404);if(order.currency!=='MYR')return json({id:order.id,status:'review'},409);if(order.status==='credited'){const reference=paymentId(order.provider_trade_no);if(!reference||!await confirmedCredit(c,order,reference))return json({id:order.id,status:'review'},409);}
 try{const status=await reconcile(c,order);return json({id:order.id,status},status==='credited'?200:status==='review'?409:202);}catch{const current=await c.db.prepare('SELECT status FROM deposit_orders WHERE id=?').bind(order.id).first<{status:string}>();return current?.status==='review'?json({id:order.id,status:'review'},409):json({id:order.id,status:'awaiting_confirmation'},202);}
}

export async function recoverGSPayDeposits(c:GSPayContext,limit=25){
 const summary={provider,enabled:c.recoveryEnabled==='true'&&credentials(c),scanned:0,queried:0,credited:0,review:0,escalated:0,pending:0,errors:0};
 summary.escalated=await escalateExhaustedPaymentRecoveries(c.db,'gspay');
 if(!summary.enabled)return summary;
 const candidates=await recoveryCandidates(c.db,'gspay',limit);summary.scanned=candidates.length;
 for(const order of candidates){
  const claim=await claimPaymentRecovery(c.db,'gspay',order.id);if(!claim)continue;
  try{summary.queried++;const status=await reconcile(c,order);if(status==='credited')summary.credited++;else if(status==='review')summary.review++;else summary.pending++;}
  catch{const current=await c.db.prepare('SELECT status FROM deposit_orders WHERE id=?').bind(order.id).first<{status:string}>();if(current?.status==='review')summary.review++;else summary.errors++;}
  finally{await finishPaymentRecovery(c.db,'gspay',order.id,claim);}
 }
 return summary;
}

function balanceDecimal(value:unknown){
 if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
 if(typeof value!=='string'||! /^(?:0|[1-9]\d{0,11})(?:\.\d{1,2})?$/.test(value))return null;
 const [whole,fraction='']=value.split('.');return `${BigInt(whole)}.${fraction.padEnd(2,'0')}`;
}

export async function queryGSPayBalance(c:GSPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='owner')return json({error:'Access denied'},403);
 if(!credentials(c)||c.balanceEnabled!=='true')return json({error:'GSPAY_BALANCE_QUERY_DISABLED'},503);
 try{
  const envelope=await providerJson(c,`/v2/integrations/operator/${encodeURIComponent(c.authKey!)}/get/balance`,'GET');
  if(envelope.code!==200&&envelope.code!=='200')throw Error('BALANCE_RESPONSE_INVALID');
  let candidate:unknown=envelope.data;
  if(candidate&&typeof candidate==='object'&&!Array.isArray(candidate)){const record=candidate as Record<string,unknown>;candidate=record.balance??record.operator_balance;}
  const balance=balanceDecimal(candidate);if(!balance)throw Error('BALANCE_RESPONSE_INVALID');
  return json({provider,currency:'MYR',balance,readOnly:true,verified:false,settlementVerified:false});
 }catch{return json({error:'GSPAY_BALANCE_UNAVAILABLE'},502);}
}
