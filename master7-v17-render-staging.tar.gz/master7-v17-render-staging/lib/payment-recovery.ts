const token=()=>crypto.randomUUID();

export async function claimPaymentRecovery(db:D1Database,provider:'vpay'|'gspay',orderId:string,at=Math.floor(Date.now()/1000),leaseSeconds=120){
 const claim=token(),row=await db.prepare(`INSERT INTO payment_recovery_leases(provider,order_id,claim_token,locked_until,last_checked_at,attempts)
  VALUES(?,?,?,?,0,1)
  ON CONFLICT(provider,order_id) DO UPDATE SET claim_token=excluded.claim_token,locked_until=excluded.locked_until,attempts=payment_recovery_leases.attempts+1
  WHERE payment_recovery_leases.locked_until<?
  RETURNING claim_token`).bind(provider,orderId,claim,at+leaseSeconds,at).first<{claim_token:string}>();
 return row?.claim_token===claim?claim:null;
}

export async function finishPaymentRecovery(db:D1Database,provider:'vpay'|'gspay',orderId:string,claim:string,at=Math.floor(Date.now()/1000)){
 await db.prepare('UPDATE payment_recovery_leases SET locked_until=0,last_checked_at=? WHERE provider=? AND order_id=? AND claim_token=?').bind(at,provider,orderId,claim).run();
}

export async function recoveryCandidates(db:D1Database,provider:'vpay'|'gspay',limit=25,at=Math.floor(Date.now()/1000)){
 const safeLimit=Math.max(1,Math.min(25,Math.trunc(limit))),result=await db.prepare(`SELECT d.* FROM deposit_orders d
  LEFT JOIN payment_recovery_leases r ON r.provider=d.provider AND r.order_id=d.id
  WHERE d.provider=? AND d.provider_trade_no IS NOT NULL AND d.status IN ('created','unknown','failed')
    AND (r.locked_until IS NULL OR r.locked_until<?)
    AND (r.last_checked_at IS NULL OR r.last_checked_at<=?)
  ORDER BY d.updated_at ASC,d.id ASC LIMIT ?`).bind(provider,at,at-60,safeLimit).all<any>();
 return result.results??[];
}
