const token=()=>crypto.randomUUID();

// Automatic recovery is deliberately finite. The first retries are close
// together so a short provider outage heals quickly, then the interval grows
// to six hours. After about one day the order is surfaced for manual review
// while its original status remains unchanged, so a later verified callback
// can still settle it exactly once.
export const PAYMENT_RECOVERY_MAX_ATTEMPTS=12;
export const paymentRecoveryBackoffSeconds=(attempts:number)=>{
 const value=Math.max(0,Math.trunc(Number.isFinite(attempts)?attempts:0));
 return Math.min(6*60*60,60*(2**Math.min(value,9)));
};
const backoffSql=(column:string)=>`CASE
 WHEN ${column}<=0 THEN 60 WHEN ${column}=1 THEN 120 WHEN ${column}=2 THEN 240
 WHEN ${column}=3 THEN 480 WHEN ${column}=4 THEN 960 WHEN ${column}=5 THEN 1920
 WHEN ${column}=6 THEN 3840 WHEN ${column}=7 THEN 7680 WHEN ${column}=8 THEN 15360
 ELSE 21600 END`;
const recoverable=`(
 (d.provider_trade_no IS NOT NULL AND d.status IN ('created','unknown','failed'))
 OR (d.provider_trade_no IS NOT NULL AND d.status='creating' AND d.updated_at<=?)
 OR (d.provider IN ('gspay','vpay') AND d.provider_trade_no IS NULL AND d.status IN ('unknown','creating') AND d.updated_at<=?)
)`;

export async function claimPaymentRecovery(db:D1Database,provider:'vpay'|'gspay',orderId:string,at=Math.floor(Date.now()/1000),leaseSeconds=120){
 const claim=token(),row=await db.prepare(`INSERT INTO payment_recovery_leases(provider,order_id,claim_token,locked_until,last_checked_at,attempts)
  VALUES(?,?,?,?,0,1)
  ON CONFLICT(provider,order_id) DO UPDATE SET claim_token=excluded.claim_token,locked_until=excluded.locked_until,attempts=payment_recovery_leases.attempts+1
  WHERE payment_recovery_leases.locked_until<? AND payment_recovery_leases.attempts<?
   AND payment_recovery_leases.last_checked_at<=?-${backoffSql('payment_recovery_leases.attempts')}
  RETURNING claim_token`).bind(provider,orderId,claim,at+leaseSeconds,at,PAYMENT_RECOVERY_MAX_ATTEMPTS,at).first<{claim_token:string}>();
 return row?.claim_token===claim?claim:null;
}

export async function finishPaymentRecovery(db:D1Database,provider:'vpay'|'gspay',orderId:string,claim:string,at=Math.floor(Date.now()/1000)){
 await db.prepare('UPDATE payment_recovery_leases SET locked_until=0,last_checked_at=? WHERE provider=? AND order_id=? AND claim_token=?').bind(at,provider,orderId,claim).run();
}

export async function escalateExhaustedPaymentRecoveries(db:D1Database,provider:'vpay'|'gspay',at=Math.floor(Date.now()/1000)){
 const result=await db.prepare(`INSERT INTO audit(id,user_id,event,target,created_at)
  SELECT 'payment-recovery-manual-review:'||d.provider||':'||d.id,d.user_id,'payment_recovery_manual_review',d.id,?
  FROM payment_recovery_leases r JOIN deposit_orders d ON d.provider=r.provider AND d.id=r.order_id
  WHERE r.provider=? AND r.attempts>=? AND d.currency='MYR' AND ${recoverable}
  ON CONFLICT(id) DO NOTHING RETURNING id`).bind(at,provider,PAYMENT_RECOVERY_MAX_ATTEMPTS,at-60,at-60).all<{id:string}>();
 return (result.results??[]).length;
}

export async function recoveryCandidates(db:D1Database,provider:'vpay'|'gspay',limit=25,at=Math.floor(Date.now()/1000)){
 const safeLimit=Math.max(1,Math.min(25,Math.trunc(limit))),result=await db.prepare(`SELECT d.* FROM deposit_orders d
  LEFT JOIN payment_recovery_leases r ON r.provider=d.provider AND r.order_id=d.id
  WHERE d.provider=? AND d.currency='MYR' AND ${recoverable}
    AND (r.locked_until IS NULL OR r.locked_until<?)
    AND (r.attempts IS NULL OR r.attempts<?)
    AND (r.last_checked_at IS NULL OR r.last_checked_at<=?-${backoffSql('r.attempts')})
  ORDER BY d.updated_at ASC,d.id ASC LIMIT ?`).bind(provider,at-60,at-60,at,PAYMENT_RECOVERY_MAX_ATTEMPTS,at,safeLimit).all<any>();
 return result.results??[];
}
