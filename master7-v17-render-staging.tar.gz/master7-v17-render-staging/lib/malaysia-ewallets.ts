export const malaysiaEwallets=[
 ['touch_n_go',"Touch 'n Go eWallet"],
 ['grabpay','GrabPay'],
 ['boost','Boost'],
 ['shopeepay','ShopeePay'],
] as const;

export type MalaysiaEwalletCode=(typeof malaysiaEwallets)[number][0];

export function malaysiaEwallet(value:unknown){
 return malaysiaEwallets.find(([code])=>code===value)??null;
}

export function malaysiaMemberPhone(value:unknown){
 if(typeof value!=='string'||value.length>32)return null;
 let digits=value.replace(/[^0-9]/g,'');
 if(digits.startsWith('0'))digits=`60${digits.slice(1)}`;
 else if(!digits.startsWith('60'))digits=`60${digits}`;
 return /^601\d{8,9}$/.test(digits)?`+${digits}`:null;
}

export function maskMalaysiaPhone(value:unknown){
 const phone=malaysiaMemberPhone(value);
 return phone?`+60 ••• ••• ${phone.slice(-4)}`:null;
}
