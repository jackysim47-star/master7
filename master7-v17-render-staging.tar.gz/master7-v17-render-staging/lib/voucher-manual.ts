export class VoucherManualError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

type Actor={id:string;role:string};

const now=()=>Math.floor(Date.now()/1000);
const cleanId=(value:unknown)=>{
 if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))throw new VoucherManualError(400,'Invalid Voucher request');
 return value;
};
const cleanReference=(value:unknown,label:string,max=160)=>{
 if(typeof value!=='string'||value.trim().length<2||value.trim().length>max)throw new VoucherManualError(400,`${label} is required`);
 return value.trim();
};
const amountMinor=(value:unknown,label:string)=>{
 const number=typeof value==='number'?value:Number(value);
 if(!Number.isFinite(number)||number<=0||number>1_000_000)throw new VoucherManualError(400,`Invalid ${label}`);
 return Math.round(number*100);
};
const parseRules=(value:string)=>{try{return JSON.parse(value);}catch{throw new VoucherManualError(409,'Voucher rules are invalid');}};
const manualRules=(rules:any)=>rules?.campaignKey==='new_member_rm88_sponsored_v1'&&rules?.stopFreeChancesOnFirstWin===true&&Number.isInteger(Number(rules?.freeChances));
const audit=(db:D1Database,actor:Actor,event:string,target:string)=>db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),actor.id,event,target,now());

async function claimForAction(db:D1Database,claimId:string){
 const claim=await db.prepare("SELECT c.id,c.status,c.rules_snapshot_json,c.turnover_required_minor,u.username FROM benefit_claims c JOIN users u ON u.id=c.user_id WHERE c.id=?").bind(claimId).first<any>();
 if(!claim)throw new VoucherManualError(404,'Voucher request not found');
 const rules=parseRules(String(claim.rules_snapshot_json));
 if(!manualRules(rules))throw new VoucherManualError(409,'This request is not a manual RM88 Voucher');
 return {claim,rules};
}

export async function listManualVoucherWorkflows(db:D1Database){
 const result=await db.prepare(`SELECT c.id claim_id,c.status claim_status,c.rules_snapshot_json,c.turnover_required_minor,c.reward_minor,c.created_at,
   r.status workflow_status,r.max_plays,r.plays_used,r.won_once,r.provider_credit_reference,r.turnover_verified_minor,
   r.turnover_evidence_reference,r.payout_cap_minor,r.payout_minor,r.payout_reference,r.approved_at,r.paid_at,r.updated_at
   FROM benefit_claims c LEFT JOIN voucher_manual_reviews r ON r.claim_id=c.id
   ORDER BY c.created_at DESC,c.id DESC LIMIT 100`).all<any>();
 const items=[] as any[];
 for(const row of result.results??[]){
  let rules:any;try{rules=JSON.parse(String(row.rules_snapshot_json));}catch{continue;}
  if(!manualRules(rules))continue;
  const plays=(await db.prepare('SELECT id,play_number,outcome,evidence_reference,created_at FROM voucher_manual_play_events WHERE claim_id=? ORDER BY play_number,id').bind(row.claim_id).all<any>()).results??[];
  items.push({claimId:String(row.claim_id),manualEligible:true,mode:'company_manual',automaticCredit:false,automaticPlayTracking:false,automaticPayout:false,status:row.workflow_status??'awaiting_review',maxPlays:Number(row.max_plays??rules.freeChances),playsUsed:Number(row.plays_used??0),remainingPlays:Math.max(0,Number(row.max_plays??rules.freeChances)-Number(row.plays_used??0)),wonOnce:Boolean(Number(row.won_once??0)),providerCreditReference:row.provider_credit_reference??'',turnoverRequiredMinor:String(row.turnover_required_minor),turnoverVerifiedMinor:String(row.turnover_verified_minor??0),turnoverEvidenceReference:row.turnover_evidence_reference??'',payoutCapMinor:String(row.payout_cap_minor??Math.round(Number(rules.withdrawalCapMYR??0)*100)),payoutMinor:String(row.payout_minor??0),payoutReference:row.payout_reference??'',approvedAt:row.approved_at===null||row.approved_at===undefined?null:Number(row.approved_at),paidAt:row.paid_at===null||row.paid_at===undefined?null:Number(row.paid_at),updatedAt:Number(row.updated_at??row.created_at),plays:plays.map((play:any)=>({id:String(play.id),playNumber:Number(play.play_number),outcome:String(play.outcome),evidenceReference:String(play.evidence_reference),createdAt:Number(play.created_at)}))});
 }
 return items;
}

export async function applyManualVoucherAction(db:D1Database,actor:Actor,input:Record<string,unknown>){
 if(actor.role!=='owner')throw new VoucherManualError(403,'Owner approval required');
 const action=typeof input.action==='string'?input.action:'',claimId=cleanId(input.claimId),{claim,rules}=await claimForAction(db,claimId),stamp=now();
 const review=await db.prepare('SELECT * FROM voucher_manual_reviews WHERE claim_id=?').bind(claimId).first<any>();
 if(action==='approve'){
  if(claim.status!=='awaiting_acceptance'||review)throw new VoucherManualError(409,'Voucher request has already been reviewed');
  const creditReference=cleanReference(input.providerCreditReference,'Manual provider credit reference'),maxPlays=Number(rules.freeChances),payoutCapMinor=Math.round(Number(rules.withdrawalCapMYR??0)*100);
  if(!Number.isInteger(maxPlays)||maxPlays<1||maxPlays>100||payoutCapMinor<1)throw new VoucherManualError(409,'Voucher play or payout rules are invalid');
  await db.batch([
   db.prepare("INSERT INTO voucher_manual_reviews(claim_id,status,max_plays,plays_used,won_once,provider_credit_reference,turnover_required_minor,turnover_verified_minor,turnover_evidence_reference,payout_cap_minor,payout_minor,payout_reference,approved_by,approved_at,paid_by,paid_at,created_at,updated_at) VALUES(?,'approved',?,0,0,?,?,0,'',?,0,'',?,?,NULL,NULL,?,?)").bind(claimId,maxPlays,creditReference,String(claim.turnover_required_minor),String(payoutCapMinor),actor.id,stamp,stamp,stamp),
   audit(db,actor,'voucher_manual_approved',JSON.stringify({claimId,maxPlays,providerCreditReference:creditReference}))
  ]);
 }else if(action==='reject'){
  if(claim.status!=='awaiting_acceptance'||review)throw new VoucherManualError(409,'Voucher request has already been reviewed');
  const note=cleanReference(input.note,'Rejection reason',300);
  await db.batch([
   db.prepare("INSERT INTO voucher_manual_reviews(claim_id,status,max_plays,plays_used,won_once,provider_credit_reference,turnover_required_minor,turnover_verified_minor,turnover_evidence_reference,payout_cap_minor,payout_minor,payout_reference,approved_by,approved_at,paid_by,paid_at,created_at,updated_at) VALUES(?,'rejected',?,0,0,?, ?,0,'',?,0,'',?,NULL,NULL,NULL,?,?)").bind(claimId,Number(rules.freeChances),`REJECTED: ${note}`,String(claim.turnover_required_minor),String(Math.round(Number(rules.withdrawalCapMYR??0)*100)),actor.id,stamp,stamp),
   db.prepare("UPDATE benefit_claims SET status='rejected',updated_at=? WHERE id=? AND status='awaiting_acceptance'").bind(stamp,claimId),
   audit(db,actor,'voucher_manual_rejected',JSON.stringify({claimId,note}))
  ]);
 }else if(action==='record_play'){
  if(!review||review.status!=='approved'||Number(review.won_once)!==0||Number(review.plays_used)>=Number(review.max_plays))throw new VoucherManualError(409,'No Voucher play remains available');
  const outcome=input.outcome;if(outcome!=='win'&&outcome!=='loss')throw new VoucherManualError(400,'Choose win or loss');
  const evidence=cleanReference(input.evidenceReference,'Play evidence reference'),playNumber=Number(review.plays_used)+1,nextStatus=outcome==='win'?'turnover_review':playNumber>=Number(review.max_plays)?'closed_no_win':'approved';
  await db.batch([
   db.prepare('INSERT INTO voucher_manual_play_events(id,claim_id,play_number,outcome,evidence_reference,recorded_by,created_at) VALUES(?,?,?,?,?,?,?)').bind(crypto.randomUUID(),claimId,playNumber,outcome,evidence,actor.id,stamp),
   db.prepare('UPDATE voucher_manual_reviews SET status=?,plays_used=?,won_once=?,updated_at=? WHERE claim_id=?').bind(nextStatus,playNumber,outcome==='win'?1:0,stamp,claimId),
   audit(db,actor,'voucher_manual_play_recorded',JSON.stringify({claimId,playNumber,outcome,evidenceReference:evidence}))
  ]);
 }else if(action==='verify_turnover'){
  if(!review||review.status!=='turnover_review'||Number(review.won_once)!==1)throw new VoucherManualError(409,'A recorded win is required before turnover review');
  const verifiedMinor=amountMinor(input.verifiedTurnoverMYR,'verified turnover'),requiredMinor=Number(review.turnover_required_minor),evidence=cleanReference(input.evidenceReference,'Turnover evidence reference');
  if(verifiedMinor<requiredMinor)throw new VoucherManualError(409,'Verified turnover has not reached the required amount');
  await db.batch([
   db.prepare("UPDATE voucher_manual_reviews SET status='eligible_for_payout',turnover_verified_minor=?,turnover_evidence_reference=?,updated_at=? WHERE claim_id=?").bind(String(verifiedMinor),evidence,stamp,claimId),
   audit(db,actor,'voucher_manual_turnover_verified',JSON.stringify({claimId,verifiedMinor,evidenceReference:evidence}))
  ]);
 }else if(action==='record_payout'){
  if(!review||review.status!=='eligible_for_payout')throw new VoucherManualError(409,'Turnover must be verified before company payout');
  const payoutMinor=amountMinor(input.payoutMYR,'payout amount'),capMinor=Number(review.payout_cap_minor),reference=cleanReference(input.payoutReference,'Company transfer reference');
  if(payoutMinor>capMinor)throw new VoucherManualError(409,'Company payout exceeds the Voucher cap');
  await db.batch([
   db.prepare("UPDATE voucher_manual_reviews SET status='paid',payout_minor=?,payout_reference=?,paid_by=?,paid_at=?,updated_at=? WHERE claim_id=?").bind(String(payoutMinor),reference,actor.id,stamp,stamp,claimId),
   audit(db,actor,'voucher_manual_company_payout_recorded',JSON.stringify({claimId,payoutMinor,payoutReference:reference,automaticTransfer:false}))
  ]);
 }else throw new VoucherManualError(400,'Invalid manual Voucher action');
 const items=await listManualVoucherWorkflows(db);
 return {status:'ok',mode:'company_manual',automaticTransfer:false,workflow:items.find(item=>item.claimId===claimId)??null};
}
