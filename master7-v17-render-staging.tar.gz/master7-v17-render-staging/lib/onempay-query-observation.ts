import {createHash} from 'node:crypto';

export const ONE_MPAY_QUERY_EVENT='1mpay_query_observed';
const statuses=new Set(['pending','fail','failed','timeout','unrecognized']);
const digest=(value:string)=>createHash('sha256').update(value).digest('hex');

/** A bound HTTPS query observation is not a terminal provider decision. */
export function createOneMpayQueryObservation(orderId:string,reference:string,value:unknown){
 const normalized=String(value).trim().toLowerCase();
 const providerStatus=statuses.has(normalized)?normalized:'unrecognized';
 return {
  auditId:'1mpay-query-observed-'+digest(`${orderId}:${reference}:${providerStatus}`).slice(0,40),
  detail:{provider:'1mpay',orderId,providerStatus,providerReferenceSha256:digest(reference),finalityVerified:false},
 };
}

export function readOneMpayQueryObservation(value:unknown,order:{id:string;provider:string;provider_trade_no:string|null}){
 if(!value||typeof value!=='object'||Array.isArray(value)||order.provider!=='1mpay'||!order.provider_trade_no)return null;
 const data=value as Record<string,unknown>;
 if(data.provider!=='1mpay'||data.orderId!==order.id||data.finalityVerified!==false
  ||typeof data.providerStatus!=='string'||!statuses.has(data.providerStatus)
  ||data.providerReferenceSha256!==digest(order.provider_trade_no))return null;
 return {providerStatus:data.providerStatus,finalityVerified:false,requiresReconciliation:true};
}
