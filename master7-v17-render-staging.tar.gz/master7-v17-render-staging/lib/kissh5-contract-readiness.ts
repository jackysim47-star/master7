export const KISS_H5_PROFILE_IDS = Object.freeze([
  '918kiss_normal_myr',
  '918kiss_normal_my1_1to100',
  '918kiss_free_myr',
] as const);

export type KissH5ProfileId = typeof KISS_H5_PROFILE_IDS[number];

type FieldKind = 'string' | 'string_list' | 'positive_integer' | 'sha256' | 'ratio';

export type KissH5ContractRequirement = Readonly<{
  field: string;
  kind: FieldKind;
  purpose: string;
  expected?: readonly string[];
}>;

const field = (
  name: string,
  kind: FieldKind,
  purpose: string,
  expected?: readonly string[],
): KissH5ContractRequirement => Object.freeze({field: name, kind, purpose, ...(expected ? {expected} : {})});

/**
 * These are documentation fields, not runtime configuration fields. Values are
 * deliberately never returned by the validator so a submitted credential or
 * secret cannot be reflected into an API response or log.
 */
export const KISS_H5_COMMON_VENDOR_FIELDS: readonly KissH5ContractRequirement[] = Object.freeze([
  field('document.document_id', 'string', 'Identify the authoritative supplier document.'),
  field('document.api_version', 'string', 'Bind every operation to an exact API version.'),
  field('document.environment', 'string', 'Identify UAT or production scope.', ['uat', 'production']),
  field('document.merchant_scope', 'string', 'Identify the merchant/account scope covered by the document.'),
  field('document.base_urls', 'string_list', 'List authoritative API bases for the named environment.'),
  field('document.operation_names', 'string_list', 'List official operation names for the runtime contract.'),
  field('document.ip_allowlist_rule', 'string', 'Define inbound and outbound IP allowlist requirements.'),
  field('document.sha256', 'sha256', 'Bind review evidence to immutable document bytes.'),

  field('authentication.scheme', 'string', 'Define the authentication scheme.'),
  field('authentication.credential_fields', 'string_list', 'Name credential identifiers without supplying credential values.'),
  field('authentication.signature_algorithm', 'string', 'Define the signature/MAC algorithm.'),
  field('authentication.canonical_request_rule', 'string', 'Define field ordering, encoding and canonicalization.'),
  field('authentication.signed_fields', 'string_list', 'List fields covered by the signature.'),
  field('authentication.timestamp_field', 'string', 'Define the timestamp field and format.'),
  field('authentication.clock_skew_seconds', 'positive_integer', 'Define the accepted clock window.'),
  field('authentication.nonce_or_replay_rule', 'string', 'Define replay protection.'),
  field('authentication.test_vectors', 'string_list', 'Provide non-secret official signing test vectors.'),

  field('player.create.endpoint', 'string', 'Define player registration/mapping endpoint.'),
  field('player.create.method', 'string', 'Define player registration HTTP method.'),
  field('player.create.required_fields', 'string_list', 'List required player registration fields.'),
  field('player.create.success_codes', 'string_list', 'List successful player registration results.'),
  field('player.create.error_codes', 'string_list', 'List player registration error results.'),
  field('player.create.idempotency_rule', 'string', 'Define repeat player-registration behavior.'),
  field('player.lookup.endpoint', 'string', 'Define player lookup endpoint.'),
  field('player.lookup.method', 'string', 'Define player lookup HTTP method.'),
  field('player.lookup.required_fields', 'string_list', 'List required player lookup fields.'),
  field('player.namespace_rule', 'string', 'Define uniqueness and isolation of supplier player IDs.'),

  field('launch.endpoint', 'string', 'Define the game launch/login endpoint.'),
  field('launch.method', 'string', 'Define launch HTTP method.'),
  field('launch.required_fields', 'string_list', 'List required launch fields.'),
  field('launch.response_url_field', 'string', 'Identify the successful launch URL field.'),
  field('launch.url_ttl_seconds', 'positive_integer', 'Define launch URL lifetime.'),
  field('launch.return_url_field', 'string', 'Identify the member return URL field.'),
  field('launch.game_id_field', 'string', 'Identify the supplier game ID field.'),
  field('launch.session_id_field', 'string', 'Identify the supplier session ID field.'),
  field('launch.delivery_modes', 'string_list', 'Define supported H5, redirect or APK delivery modes.'),
  field('launch.token_field', 'string', 'Identify the issued launch token field.'),
  field('launch.token_expiry_rule', 'string', 'Define launch token expiry.'),
  field('launch.token_revocation_rule', 'string', 'Define launch token revocation.'),
  field('launch.success_codes', 'string_list', 'List successful launch results.'),
  field('launch.error_codes', 'string_list', 'List launch error results.'),

  field('wallet.mode', 'string', 'Confirm transfer or seamless wallet mode.', ['transfer', 'seamless']),
  field('wallet.balance.endpoint', 'string', 'Define the provider balance endpoint.'),
  field('wallet.balance.method', 'string', 'Define balance HTTP method.'),
  field('wallet.balance.required_fields', 'string_list', 'List required balance fields.'),
  field('wallet.balance.amount_field', 'string', 'Identify the balance amount field.'),
  field('wallet.balance.currency_field', 'string', 'Identify the balance currency field.'),
  field('wallet.funds_flow.operations', 'string_list', 'List transfer operations or seamless wager/settle/cancel callbacks.'),
  field('wallet.funds_flow.required_fields', 'string_list', 'List required fields for every funds operation.'),
  field('wallet.funds_flow.transaction_id_field', 'string', 'Identify the immutable provider transaction ID.'),
  field('wallet.funds_flow.idempotency_field', 'string', 'Identify the idempotency key.'),
  field('wallet.funds_flow.duplicate_rule', 'string', 'Define duplicate request behavior.'),
  field('wallet.funds_flow.success_codes', 'string_list', 'List successful funds-operation results.'),
  field('wallet.funds_flow.error_codes', 'string_list', 'List funds-operation error results.'),

  field('wallet.transaction_query.endpoint', 'string', 'Define transaction-status query endpoint.'),
  field('wallet.transaction_query.method', 'string', 'Define transaction-status query HTTP method.'),
  field('wallet.transaction_query.required_fields', 'string_list', 'List transaction query fields.'),
  field('wallet.transaction_query.pending_statuses', 'string_list', 'List non-terminal statuses.'),
  field('wallet.transaction_query.terminal_success_statuses', 'string_list', 'List successful terminal statuses.'),
  field('wallet.transaction_query.terminal_failure_statuses', 'string_list', 'List failed terminal statuses.'),
  field('wallet.transaction_query.not_found_rule', 'string', 'Define unknown/not-found transaction handling.'),
  field('wallet.transaction_query.late_success_rule', 'string', 'Define a success observed after timeout or earlier failure.'),
  field('wallet.transaction_query.binding_fields', 'string_list', 'Bind player, direction, amount, currency and transaction IDs.'),

  field('reports.endpoint', 'string', 'Define bet/round/report retrieval or callback endpoint.'),
  field('reports.method', 'string', 'Define report/callback HTTP method.'),
  field('reports.required_fields', 'string_list', 'List required report/callback fields.'),
  field('reports.round_id_field', 'string', 'Identify the immutable round ID.'),
  field('reports.bet_id_field', 'string', 'Identify the immutable bet ID.'),
  field('reports.transaction_id_field', 'string', 'Identify the immutable report transaction ID.'),
  field('reports.signed_fields', 'string_list', 'List signed report/callback fields.'),
  field('reports.source_ip_rule', 'string', 'Define trusted report/callback source IPs.'),
  field('reports.ack_schema', 'string', 'Define the required acknowledgement.'),
  field('reports.retry_policy', 'string', 'Define supplier report/callback retries.'),
  field('reports.deduplication_field', 'string', 'Identify the report/callback deduplication key.'),
  field('reports.replay_window_seconds', 'positive_integer', 'Define the accepted report replay window.'),
  field('reports.pagination_rule', 'string', 'Define report pagination and cursors.'),
  field('reports.ordering_rule', 'string', 'Define stable report ordering.'),

  field('session.exit.endpoint', 'string', 'Define explicit session/game exit endpoint.'),
  field('session.exit.method', 'string', 'Define exit HTTP method.'),
  field('session.exit.required_fields', 'string_list', 'List required exit fields.'),
  field('session.exit.final_status_field', 'string', 'Identify final session status.'),
  field('session.exit.success_codes', 'string_list', 'List successful exit results.'),
  field('session.exit.error_codes', 'string_list', 'List exit error results.'),
  field('session.return_url_rule', 'string', 'Define browser return-to-lobby behavior.'),
  field('session.disconnect_rule', 'string', 'Define abandoned/disconnected session closure.'),
  field('session.duplicate_exit_rule', 'string', 'Define duplicate exit behavior.'),
  field('session.kick.endpoint', 'string', 'Define forced logout/kick endpoint.'),
  field('session.kick.method', 'string', 'Define forced logout/kick HTTP method.'),
  field('session.kick.required_fields', 'string_list', 'List forced logout/kick fields.'),
  field('session.offline_status.endpoint', 'string', 'Define player/session online-status endpoint.'),
  field('session.offline_status.method', 'string', 'Define online-status HTTP method.'),
  field('session.offline_status.required_fields', 'string_list', 'List online-status query fields.'),
  field('session.unfinished_rounds.endpoint', 'string', 'Define unfinished-round query endpoint.'),
  field('session.unfinished_rounds.method', 'string', 'Define unfinished-round HTTP method.'),
  field('session.unfinished_rounds.required_fields', 'string_list', 'List unfinished-round query fields.'),
  field('session.issued_token_invalidation_rule', 'string', 'Define whether all issued launch tokens are invalidated.'),
  field('session.late_result_finality_rule', 'string', 'Define when late results can no longer arrive.'),

  field('settlement.finality_rule', 'string', 'Define when wallet movement is final.'),
  field('settlement.reversal_rule', 'string', 'Define cancellation/rollback behavior.'),
  field('settlement.reconciliation_fields', 'string_list', 'List fields needed for provider reconciliation.'),
  field('recovery.timeout_rule', 'string', 'Define ambiguous timeout handling.'),
  field('recovery.retry_policy', 'string', 'Define safe retries and retry limits.'),
  field('recovery.polling_policy', 'string', 'Define transaction/session recovery polling.'),
  field('limits.request_rate_rule', 'string', 'Define API rate and concurrency limits.'),
  field('limits.amount_bounds_rule', 'string', 'Define minimum and maximum wallet amounts.'),
  field('maintenance.status_endpoint', 'string', 'Define maintenance/status discovery endpoint.'),
  field('maintenance.behavior', 'string', 'Define runtime behavior during supplier maintenance.'),
  field('acceptance.uat_account_scope', 'string', 'Identify the authorized UAT account scope.'),
  field('acceptance.uat_test_cases', 'string_list', 'Provide supplier-approved UAT cases.'),
  field('acceptance.production_vectors', 'string_list', 'Provide production acceptance vectors without secrets.'),

  field('profile.profile_id', 'string', 'Bind evidence to one portal profile.'),
  field('profile.account_variant', 'string', 'Bind evidence to one supplier account variant.'),
  field('profile.provider_account_scope', 'string', 'Identify the applicable supplier account without recording its secret.'),
  field('profile.provider_currency', 'string', 'Confirm provider-side currency code.'),
  field('profile.settlement_currency', 'string', 'Confirm settlement currency.'),
  field('profile.amount_unit', 'string', 'Define whether amounts are major units, minor units or points.'),
  field('profile.amount_precision', 'positive_integer', 'Define accepted decimal precision.'),
  field('profile.conversion_ratio', 'ratio', 'Define provider units to MYR conversion.'),
  field('profile.rounding_rule', 'string', 'Define conversion rounding and residual handling.'),
  field('profile.balance_class', 'string', 'Confirm cash or free-credit balance.', ['cash', 'free_credit']),
  field('profile.game_scope', 'string_list', 'Identify games authorized for this account.'),
]);

const PROFILE_FIELDS: Readonly<Record<KissH5ProfileId, readonly KissH5ContractRequirement[]>> = Object.freeze({
  '918kiss_normal_myr': Object.freeze([]),
  '918kiss_normal_my1_1to100': Object.freeze([
    field('profile.my1_definition', 'string', 'Define the supplier meaning of MY1.'),
    field('profile.my1_to_myr_ratio', 'ratio', 'Confirm the supplier-approved MY1 to MYR ratio.'),
    field('profile.conversion_direction', 'string', 'Define both wallet-to-game and game-to-wallet conversion direction.'),
    field('profile.conversion_rounding_rule', 'string', 'Define MY1 conversion rounding and residual handling.'),
  ]),
  '918kiss_free_myr': Object.freeze([
    field('profile.free_credit_source', 'string', 'Define how free credit is funded.'),
    field('profile.free_credit_spend_rule', 'string', 'Define where free credit may be spent.'),
    field('profile.free_credit_cash_conversion_rule', 'string', 'Define whether and when free credit may become cash.'),
    field('profile.free_credit_expiry_rule', 'string', 'Define expiry and forfeiture.'),
    field('profile.free_credit_settlement_rule', 'string', 'Define result settlement for free-credit sessions.'),
  ]),
});

const PROFILE_EXPECTATIONS: Readonly<Record<KissH5ProfileId, Readonly<Record<string, readonly string[]>>>> = Object.freeze({
  '918kiss_normal_myr': Object.freeze({
    'profile.profile_id': ['918kiss_normal_myr'],
    'profile.account_variant': ['normal'],
    'profile.provider_currency': ['MYR'],
    'profile.settlement_currency': ['MYR'],
    'profile.balance_class': ['cash'],
  }),
  '918kiss_normal_my1_1to100': Object.freeze({
    'profile.profile_id': ['918kiss_normal_my1_1to100'],
    'profile.account_variant': ['my1'],
    'profile.provider_currency': ['MY1'],
    'profile.settlement_currency': ['MYR'],
    'profile.amount_unit': ['points'],
    // Ratios are provider units : settlement major units.  This profile means
    // 100 MY1 points = MYR 1.00, so the reverse transfer divides by 100.
    'profile.conversion_ratio': ['100:1'],
    'profile.my1_to_myr_ratio': ['100:1'],
    'profile.conversion_direction': ['MYR_TO_MY1_MULTIPLY_100;MY1_TO_MYR_DIVIDE_100'],
    'profile.balance_class': ['cash'],
  }),
  '918kiss_free_myr': Object.freeze({
    'profile.profile_id': ['918kiss_free_myr'],
    'profile.account_variant': ['free'],
    'profile.provider_currency': ['MYR'],
    'profile.settlement_currency': ['MYR'],
    'profile.balance_class': ['free_credit'],
  }),
});

function isProfileId(value: string): value is KissH5ProfileId {
  return (KISS_H5_PROFILE_IDS as readonly string[]).includes(value);
}

function readPath(input: unknown, path: string): unknown {
  let current: unknown = input;
  for (const segment of path.split('.')) {
    if (!current || typeof current !== 'object' || Array.isArray(current)) return undefined;
    current = (current as Record<string, unknown>)[segment];
  }
  return current;
}

function validateValue(value: unknown, requirement: KissH5ContractRequirement, expected?: readonly string[]): string | null {
  if (requirement.kind === 'string') {
    if (typeof value !== 'string' || !value.trim() || value.length > 2000 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value)) return 'invalid_string';
    const allowed = expected ?? requirement.expected;
    if (allowed && !allowed.includes(value.trim())) return 'unexpected_value';
    return null;
  }
  if (requirement.kind === 'string_list') {
    if (!Array.isArray(value) || value.length === 0 || value.length > 100 || value.some(item => typeof item !== 'string' || !item.trim() || item.length > 256)) return 'invalid_string_list';
    return null;
  }
  if (requirement.kind === 'positive_integer') return Number.isSafeInteger(value) && Number(value) >= 0 ? null : 'invalid_nonnegative_integer';
  if (requirement.kind === 'sha256') return typeof value === 'string' && /^[a-f0-9]{64}$/.test(value) ? null : 'invalid_sha256';
  if (requirement.kind === 'ratio') {
    if (typeof value !== 'string' || !/^[1-9]\d{0,8}:[1-9]\d{0,8}$/.test(value)) return 'invalid_ratio';
    if (expected && !expected.includes(value)) return 'unexpected_value';
    return null;
  }
  return 'invalid_value';
}

export function getKissH5ContractRequirements(profileId: string): readonly KissH5ContractRequirement[] {
  if (!isProfileId(profileId)) return Object.freeze([]);
  return Object.freeze([...KISS_H5_COMMON_VENDOR_FIELDS, ...PROFILE_FIELDS[profileId]]);
}

export type KissH5ContractDiagnostic = Readonly<{
  profileId: string;
  knownProfile: boolean;
  manifestComplete: boolean;
  missingVendorFields: readonly string[];
  invalidVendorFields: readonly Readonly<{field: string; reason: string}>[];
  documentationOnly: true;
  adapterImplemented: false;
  launchAllowed: false;
  walletAllowed: false;
  playAllowed: false;
}>;

/**
 * Performs syntax and scope validation only. A complete manifest still cannot
 * enable an adapter, wallet movement, game launch or Play button. Supplier
 * documents must be reviewed and an independently tested adapter implemented.
 */
export function inspectKissH5ContractManifest(profileId: string, manifest: unknown = {}): KissH5ContractDiagnostic {
  const knownProfile = isProfileId(profileId);
  const requirements = getKissH5ContractRequirements(profileId);
  const missingVendorFields: string[] = [];
  const invalidVendorFields: Array<{field: string; reason: string}> = [];
  if (knownProfile) {
    for (const requirement of requirements) {
      const value = readPath(manifest, requirement.field);
      if (value === undefined || value === null || value === '') {
        missingVendorFields.push(requirement.field);
        continue;
      }
      const reason = validateValue(value, requirement, PROFILE_EXPECTATIONS[profileId][requirement.field]);
      if (reason) invalidVendorFields.push({field: requirement.field, reason});
    }
  }
  return Object.freeze({
    profileId,
    knownProfile,
    manifestComplete: knownProfile && missingVendorFields.length === 0 && invalidVendorFields.length === 0,
    missingVendorFields: Object.freeze(missingVendorFields),
    invalidVendorFields: Object.freeze(invalidVendorFields.map(item => Object.freeze(item))),
    documentationOnly: true,
    adapterImplemented: false,
    launchAllowed: false,
    walletAllowed: false,
    playAllowed: false,
  });
}

