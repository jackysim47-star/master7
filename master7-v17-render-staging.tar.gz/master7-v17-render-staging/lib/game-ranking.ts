export class GameRankingError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

export const GAME_PROVIDER_IDS=['megah5','jili','918kissh5','gameplay','lionking','suncity','pgsoft','gfg','sagaming','ps9','dragoonsoft','jdb','bg','allbet','quickspin','astar','metagaming','fuma','yl','funky','gamitech','spadegaming','turbo','ct855','pragmaticplay','joker','cg','atg','rectangle','m8bet','awc','evo888h5','cosmoplay','geminiupdown','epicwin','venus','clotplay'] as const;
export const GAME_PROVIDER_NAMES:Record<string,string>={megah5:'MegaH5',jili:'JILI','918kissh5':'918KISS H5',gameplay:'GAMEPLAY INTERACTIVE',lionking:'LION KING',suncity:'SUNCITY',pgsoft:'PGSOFT',gfg:'GFG / G4',sagaming:'SA GAMING',ps9:'PS9',dragoonsoft:'DRAGOONSOFT',jdb:'JDB',bg:'BG',allbet:'ALLBET',quickspin:'QUICKSPIN',astar:'ASTAR',metagaming:'META GAMING',fuma:'FUMA',yl:'YL',funky:'FUNKY',gamitech:'GAMITECH',spadegaming:'SPADE GAMING',turbo:'TURBO',ct855:'CT855',pragmaticplay:'PRAGMATIC PLAY',joker:'JOKER',cg:'CG',atg:'ATG',rectangle:'RECTANGLE',m8bet:'M8BET',awc:'AWC',evo888h5:'EVO888H5',cosmoplay:'COSMOPLAY',geminiupdown:'GEMINI UPDOWN',epicwin:'EPICWIN',venus:'VENUS GAMING',clotplay:'CLOTPLAY'};
export const GAME_RANKING_CATEGORIES=['HOT','SLOT','LIVE','FISH','COCK','SPORT'] as const;
export type GameRankingCategory=typeof GAME_RANKING_CATEGORIES[number];
export const GAME_PROVIDER_CATEGORY_IDS:Record<GameRankingCategory,readonly string[]>={
 HOT:GAME_PROVIDER_IDS,
 SLOT:['megah5','jili','918kissh5','suncity','dragoonsoft','jdb','astar','metagaming','spadegaming','pragmaticplay','joker','evo888h5','epicwin','clotplay'],
 LIVE:['gameplay','sagaming','bg','allbet','ct855','pragmaticplay','awc'],
 FISH:['jili','jdb','yl','spadegaming','joker'],
 COCK:[],
 SPORT:['m8bet'],
};
const LEGACY_GAME_PROVIDER_CATEGORY_IDS:Record<GameRankingCategory,readonly string[]>={
 HOT:GAME_PROVIDER_IDS.slice(0,34),
 SLOT:GAME_PROVIDER_CATEGORY_IDS.SLOT.slice(0,12),
 LIVE:GAME_PROVIDER_CATEGORY_IDS.LIVE,
 FISH:GAME_PROVIDER_CATEGORY_IDS.FISH,
 COCK:GAME_PROVIDER_CATEGORY_IDS.COCK,
 SPORT:GAME_PROVIDER_CATEGORY_IDS.SPORT,
};

export type GameRanking={version:1;mode:'owner_curated';categories:Record<GameRankingCategory,string[]>};
type StoredGameRanking=GameRanking&{updatedAt:number;updatedBy:string};
const SETTING_ID='game_provider_ranking_v1';

function object(value:unknown,label:string):Record<string,unknown>{if(!value||typeof value!=='object'||Array.isArray(value))throw new GameRankingError(400,`Invalid ${label}`);return value as Record<string,unknown>;}
function exactKeys(value:Record<string,unknown>,keys:readonly string[],label:string){const allowed=new Set(keys),unknown=Object.keys(value).find(key=>!allowed.has(key)),missing=keys.find(key=>!Object.hasOwn(value,key));if(unknown)throw new GameRankingError(400,`Unknown ${label} field: ${unknown}`);if(missing)throw new GameRankingError(400,`Missing ${label} field: ${missing}`);}
function validateOrder(value:unknown,category:GameRankingCategory){
 if(!Array.isArray(value)||value.some(item=>typeof item!=='string'))throw new GameRankingError(400,`Invalid ${category} ranking`);
 const expected=GAME_PROVIDER_CATEGORY_IDS[category],received=value as string[];
 if(received.length!==expected.length||new Set(received).size!==received.length)throw new GameRankingError(400,`${category} ranking must contain each assigned platform once`);
 const expectedSet=new Set(expected);if(received.some(id=>!expectedSet.has(id)))throw new GameRankingError(400,`${category} ranking contains an unknown or unassigned platform`);
 return [...received];
}
function loadStoredOrder(value:unknown,category:GameRankingCategory){
 try{return validateOrder(value,category);}catch(error){
  if(!Array.isArray(value)||value.some(item=>typeof item!=='string'))throw error;
  const received=value as string[],legacy=LEGACY_GAME_PROVIDER_CATEGORY_IDS[category],legacySet=new Set(legacy);
  if(received.length!==legacy.length||new Set(received).size!==received.length||received.some(id=>!legacySet.has(id)))throw error;
  const receivedSet=new Set(received);return [...received,...GAME_PROVIDER_CATEGORY_IDS[category].filter(id=>!receivedSet.has(id))];
 }
}
export function defaultGameRanking():GameRanking{return {version:1,mode:'owner_curated',categories:Object.fromEntries(GAME_RANKING_CATEGORIES.map(category=>[category,[...GAME_PROVIDER_CATEGORY_IDS[category]]])) as Record<GameRankingCategory,string[]>};}
export function validateGameRanking(input:unknown):GameRanking{
 const value=object(input,'game ranking');exactKeys(value,['version','mode','categories'],'game ranking');
 if(value.version!==1||value.mode!=='owner_curated')throw new GameRankingError(400,'Unsupported game ranking version or mode');
 const categories=object(value.categories,'game ranking categories');exactKeys(categories,GAME_RANKING_CATEGORIES,'game ranking categories');
 return {version:1,mode:'owner_curated',categories:Object.fromEntries(GAME_RANKING_CATEGORIES.map(category=>[category,validateOrder(categories[category],category)])) as Record<GameRankingCategory,string[]>};
}
export async function loadGameRanking(db:D1Database):Promise<{configured:boolean;ranking:GameRanking;updatedAt:number|null;updatedBy:string|null}>{
 const row=await db.prepare('SELECT value FROM settings WHERE id=?').bind(SETTING_ID).first<{value:string}>();if(!row)return {configured:false,ranking:defaultGameRanking(),updatedAt:null,updatedBy:null};
 let stored:Record<string,unknown>;try{stored=object(JSON.parse(row.value),'stored game ranking');}catch{throw new GameRankingError(503,'Stored game ranking is invalid');}
 const allowed=['version','mode','categories','updatedAt','updatedBy'];if(Object.keys(stored).some(key=>!allowed.includes(key)))throw new GameRankingError(503,'Stored game ranking is invalid');
 let ranking:GameRanking;try{
  if(stored.version!==1||stored.mode!=='owner_curated')throw Error('unsupported');
  const categories=object(stored.categories,'stored game ranking categories');exactKeys(categories,GAME_RANKING_CATEGORIES,'stored game ranking categories');
  ranking={version:1,mode:'owner_curated',categories:Object.fromEntries(GAME_RANKING_CATEGORIES.map(category=>[category,loadStoredOrder(categories[category],category)])) as Record<GameRankingCategory,string[]>};
 }catch{throw new GameRankingError(503,'Stored game ranking is invalid');}
 if(!Number.isSafeInteger(stored.updatedAt)||Number(stored.updatedAt)<0||typeof stored.updatedBy!=='string'||stored.updatedBy.length<1||stored.updatedBy.length>128)throw new GameRankingError(503,'Stored game ranking is invalid');
 return {configured:true,ranking,updatedAt:Number(stored.updatedAt),updatedBy:stored.updatedBy};
}
function response(loaded:Awaited<ReturnType<typeof loadGameRanking>>){return {...loaded,storage:SETTING_ID,source:'owner_curated',automaticRanking:false,internalGamesRanked:false,platformCount:GAME_PROVIDER_IDS.length,providers:GAME_PROVIDER_IDS.map(id=>({id,name:GAME_PROVIDER_NAMES[id]})),categoryCounts:Object.fromEntries(GAME_RANKING_CATEGORIES.map(category=>[category,loaded.ranking.categories[category].length]))};}
export async function getGameRanking(db:D1Database){return response(await loadGameRanking(db));}
export async function getPublicGameRanking(db:D1Database){
 const loaded=await loadGameRanking(db);return {configured:loaded.configured,ranking:loaded.ranking,source:'owner_curated',automaticRanking:false,internalGamesRanked:false,platformCount:GAME_PROVIDER_IDS.length,categoryCounts:Object.fromEntries(GAME_RANKING_CATEGORIES.map(category=>[category,loaded.ranking.categories[category].length]))};
}
export async function saveGameRanking(db:D1Database,ownerId:string,input:unknown,at=Math.floor(Date.now()/1000)){
 const outer=object(input,'game ranking request'),candidate=Object.hasOwn(outer,'ranking')?(()=>{exactKeys(outer,['ranking'],'game ranking request');return outer.ranking;})():outer,ranking=validateGameRanking(candidate),stored:StoredGameRanking={...ranking,updatedAt:at,updatedBy:ownerId};
 await db.batch([
  db.prepare('INSERT INTO settings(id,value) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind(SETTING_ID,JSON.stringify(stored)),
  db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),ownerId,'game_provider_ranking_updated',JSON.stringify({version:1,mode:'owner_curated',categories:Object.fromEntries(GAME_RANKING_CATEGORIES.map(category=>[category,ranking.categories[category].length]))}),at),
 ]);
 return {status:'ok',...response({configured:true,ranking,updatedAt:at,updatedBy:ownerId})};
}
export function rankPlatforms<T extends {id:string}>(items:T[],ranking:GameRanking,category:GameRankingCategory='HOT'){
 const byId=new Map(items.map(item=>[item.id,item] as const));return ranking.categories[category].map((id,index)=>{const item=byId.get(id);return item?{...item,position:index+1,rankingCategory:category,rankingSource:'owner_curated' as const}:null;}).filter((item):item is T&{position:number;rankingCategory:GameRankingCategory;rankingSource:'owner_curated'}=>item!==null);
}
