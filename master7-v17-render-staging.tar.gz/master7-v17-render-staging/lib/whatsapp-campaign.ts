import {createHash,randomUUID,timingSafeEqual} from 'node:crypto';
import {parseWhatsAppWebhook,sendWhatsAppTemplate,verifyWhatsAppWebhookChallenge,verifyWhatsAppWebhookSignature,whatsappBusinessStatus,type WhatsAppBusinessContext} from './whatsapp-business.ts';
import {responsiblePlayMarketingAllowedSql,suppressResponsiblePlayMarketing} from './responsible-play.ts';

const CUSTOMER_ORIGIN='https://master7.best';
const MAX_CONTACTS=1_000_000;
const TEMPLATE_PARAMETER_ORDER=['message','benefit','registration_link','unsubscribe_link'] as const;
const terminalStatuses=new Set(['sent','delivered','read','failed','opted_out']);
const VERIFIED_CONSENT="consent_status='opted_in' AND consented_at IS NOT NULL AND TRIM(consent_source)<>'' AND TRIM(consent_proof)<>'' AND unsubscribe_token IS NOT NULL AND TRIM(unsubscribe_token)<>''";

export class WhatsAppCampaignError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

export type WhatsAppCampaignContext={
 db:D1Database;
 provider:WhatsAppBusinessContext;
 recipientLimit?:string|number;
 workerToken?:string;
 workerBatchSize?:string|number;
};

function epoch(){return Math.floor(Date.now()/1000);}
function safeToken(given:string,expected:string){const a=Buffer.from(given),b=Buffer.from(expected);return a.length===b.length&&a.length>=32&&a.length<=1024&&timingSafeEqual(a,b);}
function recipientLimit(value:unknown){const parsed=Number(value);return Number.isSafeInteger(parsed)&&parsed>=1&&parsed<=MAX_CONTACTS?parsed:0;}
function batchSize(value:unknown){const parsed=Number(value);return Number.isSafeInteger(parsed)&&parsed>=1&&parsed<=100?parsed:10;}
function hash(value:string|Uint8Array){return createHash('sha256').update(value).digest('hex');}

export function whatsappCampaignStatus(c:WhatsAppCampaignContext){
 const provider=whatsappBusinessStatus(c.provider),limit=recipientLimit(c.recipientLimit),blockers=[...provider.blockers];
 if(!limit)blockers.push('recipient_limit_unverified');
 return {...provider,ready:provider.ready&&limit>0,recipientLimit:limit,maximumContacts:MAX_CONTACTS,blockers:[...new Set(blockers)],parameterOrder:TEMPLATE_PARAMETER_ORDER};
}

export async function launchWhatsAppCampaign(c:WhatsAppCampaignContext,campaignId:string,actorId:string){
 if(!/^[A-Za-z0-9_-]{1,128}$/.test(campaignId))throw new WhatsAppCampaignError(400,'Invalid campaign ID');
 const status=whatsappCampaignStatus(c);if(!status.ready)throw new WhatsAppCampaignError(409,'WhatsApp Business is waiting for verified Meta credentials, template and recipient limit');
 const campaign=await c.db.prepare("SELECT id,channel,status FROM marketing_campaigns WHERE id=?").bind(campaignId).first<{id:string;channel:string;status:string}>();
 if(!campaign)throw new WhatsAppCampaignError(404,'Campaign not found');
 if(campaign.channel!=='whatsapp')throw new WhatsAppCampaignError(409,'Choose the WhatsApp channel for this campaign');
 if(campaign.status==='sending')return {status:'sending',campaignId,idempotent:true};
 if(campaign.status==='completed')throw new WhatsAppCampaignError(409,'Completed campaigns cannot be launched again');
 if(campaign.status!=='ready')throw new WhatsAppCampaignError(409,'Only ready campaigns can be launched');
 const stamp=epoch(),eligibleConsent=`${VERIFIED_CONSENT} AND ${responsiblePlayMarketingAllowedSql('marketing_contacts',stamp)}`;
 const count=await c.db.prepare(`SELECT COUNT(*) count FROM marketing_contacts WHERE ${eligibleConsent}`).first<{count:number}>(),audience=Number(count?.count??0);
 if(!audience)throw new WhatsAppCampaignError(409,'No contacts have verified marketing consent');
 if(audience>status.recipientLimit)throw new WhatsAppCampaignError(409,`Verified Meta recipient limit is ${status.recipientLimit}; this campaign has ${audience} opted-in contacts`);
 const launchToken=randomUUID(),snapshot=JSON.stringify({order:TEMPLATE_PARAMETER_ORDER,launchToken});
 const results:any=await c.db.batch([
  c.db.prepare(`UPDATE marketing_campaigns SET provider='meta_whatsapp_cloud_api',template_name=?,template_language=?,template_params_json=?,audience_count=(SELECT COUNT(*) FROM marketing_contacts WHERE ${eligibleConsent}),status='sending',started_at=COALESCE(started_at,?),completed_at=NULL,updated_at=? WHERE id=? AND status='ready' AND (SELECT COUNT(*) FROM marketing_contacts WHERE ${eligibleConsent}) BETWEEN 1 AND ? RETURNING id,audience_count`).bind(status.templateName,status.templateLanguage,snapshot,stamp,stamp,campaignId,status.recipientLimit),
  c.db.prepare(`INSERT INTO marketing_deliveries(campaign_id,contact_id,status,attempts,locked_until,next_attempt_at,updated_at) SELECT ?,id,'queued',0,0,0,? FROM marketing_contacts WHERE ${eligibleConsent} AND EXISTS(SELECT 1 FROM marketing_campaigns WHERE id=? AND status='sending' AND template_params_json=?) ORDER BY id LIMIT (SELECT audience_count FROM marketing_campaigns WHERE id=? AND status='sending' AND template_params_json=?) ON CONFLICT(campaign_id,contact_id) DO NOTHING`).bind(campaignId,stamp,campaignId,snapshot,campaignId,snapshot),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM marketing_campaigns WHERE id=? AND status='sending' AND template_params_json=?)").bind(randomUUID(),actorId,'whatsapp_campaign_launched',`${campaignId}:${audience}`,stamp,campaignId,snapshot)
 ]);
 const launched=results?.[0]?.results?.[0];
 if(!launched){
  const latest=await c.db.prepare('SELECT status FROM marketing_campaigns WHERE id=?').bind(campaignId).first<{status:string}>();
  if(latest?.status==='sending')return {status:'sending',campaignId,idempotent:true};
  const current=await c.db.prepare(`SELECT COUNT(*) count FROM marketing_contacts WHERE ${eligibleConsent}`).first<{count:number}>(),currentAudience=Number(current?.count??0);
  if(!currentAudience)throw new WhatsAppCampaignError(409,'No contacts have verified marketing consent');
  if(currentAudience>status.recipientLimit)throw new WhatsAppCampaignError(409,`Verified Meta recipient limit is ${status.recipientLimit}; this campaign has ${currentAudience} opted-in contacts`);
  throw new WhatsAppCampaignError(409,'Only ready campaigns can be launched');
 }
 return {status:'sending',campaignId,audience:Number(launched.audience_count),recipientLimit:status.recipientLimit,idempotent:false};
}

function retryDelay(attempts:number,retryAfter?:number){return Math.max(5,Math.min(3600,retryAfter||Math.min(900,5*2**Math.min(8,attempts))));}

export async function dispatchWhatsAppCampaigns(c:WhatsAppCampaignContext){
 const status=whatsappCampaignStatus(c);if(!status.ready)throw new WhatsAppCampaignError(503,'WhatsApp Business is not ready');
 const stamp=epoch(),limit=batchSize(c.workerBatchSize),summary={claimed:0,sent:0,retried:0,unknown:0,failed:0,optedOut:0,suppressed:0},allowedContact=responsiblePlayMarketingAllowedSql('c',stamp);
 await c.db.prepare("UPDATE marketing_deliveries SET status='unknown',claim_token=NULL,provider_error_code='lease_expired',updated_at=? WHERE status='submitting' AND locked_until<?").bind(stamp,stamp).run();
 summary.suppressed+=await suppressResponsiblePlayMarketing(c.db,stamp);
 await c.db.prepare('DELETE FROM rate_limits WHERE expires_at<?').bind(stamp).run();
 const candidates=await c.db.prepare(`SELECT d.campaign_id,d.contact_id,d.attempts,m.message,m.benefit_text,m.referral_code,m.send_rate_per_minute,m.template_name,m.template_language,c.phone,c.name,c.unsubscribe_token,c.consent_status,c.consented_at,c.consent_source,c.consent_proof FROM marketing_deliveries d JOIN marketing_campaigns m ON m.id=d.campaign_id JOIN marketing_contacts c ON c.id=d.contact_id WHERE m.status='sending' AND (m.scheduled_at IS NULL OR m.scheduled_at<=?) AND d.status='queued' AND d.next_attempt_at<=? AND c.consent_status='opted_in' AND c.consented_at IS NOT NULL AND TRIM(c.consent_source)<>'' AND TRIM(c.consent_proof)<>'' AND c.unsubscribe_token IS NOT NULL AND TRIM(c.unsubscribe_token)<>'' AND ${allowedContact} ORDER BY d.updated_at,d.campaign_id,d.contact_id LIMIT ?`).bind(stamp,stamp,limit*4).all<any>();
 for(const item of candidates.results??[]){
  if(summary.claimed>=limit)break;
  const rate=Math.max(1,Math.min(10000,Number(item.send_rate_per_minute)||30)),bucket=Math.floor(stamp/60),rateKey=`wa:${item.campaign_id}:${bucket}`,rateRow=await c.db.prepare("INSERT INTO rate_limits(id,count,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=rate_limits.count+1 RETURNING count").bind(rateKey,(bucket+2)*60).first<{count:number}>();
  if(Number(rateRow?.count??rate+1)>rate)continue;
  const claim=randomUUID(),claimed=await c.db.prepare(`UPDATE marketing_deliveries SET status='submitting',claim_token=?,locked_until=?,attempts=attempts+1,submitted_at=?,updated_at=? WHERE campaign_id=? AND contact_id=? AND status='queued' AND next_attempt_at<=? AND EXISTS(SELECT 1 FROM marketing_contacts c WHERE c.id=marketing_deliveries.contact_id AND c.consent_status='opted_in' AND c.consented_at IS NOT NULL AND TRIM(c.consent_source)<>'' AND TRIM(c.consent_proof)<>'' AND c.unsubscribe_token IS NOT NULL AND TRIM(c.unsubscribe_token)<>'' AND ${allowedContact}) RETURNING attempts`).bind(claim,stamp+120,stamp,stamp,item.campaign_id,item.contact_id,stamp).first<{attempts:number}>();
  if(!claimed)continue;summary.claimed++;
  const current=await c.db.prepare("SELECT consent_status,consented_at,consent_source,consent_proof,unsubscribe_token FROM marketing_contacts WHERE id=?").bind(item.contact_id).first<any>();
  if(!current||current.consent_status!=='opted_in'||current.consented_at===null||typeof current.consent_source!=='string'||!current.consent_source.trim()||typeof current.consent_proof!=='string'||!current.consent_proof.trim()||typeof current.unsubscribe_token!=='string'||!current.unsubscribe_token.trim()){await c.db.prepare("UPDATE marketing_deliveries SET status='opted_out',claim_token=NULL,locked_until=0,updated_at=? WHERE campaign_id=? AND contact_id=? AND claim_token=?").bind(stamp,item.campaign_id,item.contact_id,claim).run();summary.optedOut++;continue;}
  const restricted=await c.db.prepare(`SELECT 1 blocked FROM marketing_contacts c WHERE c.id=? AND NOT (${responsiblePlayMarketingAllowedSql('c',epoch())})`).bind(item.contact_id).first<{blocked:number}>();
  if(restricted){await c.db.prepare("UPDATE marketing_deliveries SET status='failed',claim_token=NULL,locked_until=0,provider_error_code='responsible_play_suppressed',failed_at=COALESCE(failed_at,?),updated_at=? WHERE campaign_id=? AND contact_id=? AND claim_token=?").bind(stamp,stamp,item.campaign_id,item.contact_id,claim).run();summary.suppressed++;continue;}
  const registration=item.referral_code?`${CUSTOMER_ORIGIN}/register?ref=${encodeURIComponent(item.referral_code)}`:`${CUSTOMER_ORIGIN}/register`,unsubscribe=`${CUSTOMER_ORIGIN}/unsubscribe?token=${encodeURIComponent(item.unsubscribe_token)}`,parameters=[String(item.message),String(item.benefit_text||'-'),registration,unsubscribe];
  const result=await sendWhatsAppTemplate({...c.provider,templateName:item.template_name,templateLanguage:item.template_language},{recipient:item.phone,bodyParameters:parameters});
  if(result.ok){await c.db.prepare("UPDATE marketing_deliveries SET status='sent',provider_message_id=?,claim_token=NULL,locked_until=0,provider_error_code=NULL,sent_at=?,updated_at=? WHERE campaign_id=? AND contact_id=? AND claim_token=?").bind(result.messageId,stamp,stamp,item.campaign_id,item.contact_id,claim).run();summary.sent++;}
  else if(result.kind==='rate_limited'||result.kind==='provider_unavailable'){
   const next=stamp+retryDelay(Number(claimed.attempts),result.retryAfter);await c.db.prepare("UPDATE marketing_deliveries SET status='queued',claim_token=NULL,locked_until=0,next_attempt_at=?,provider_error_code=?,updated_at=? WHERE campaign_id=? AND contact_id=? AND claim_token=?").bind(next,result.kind,stamp,item.campaign_id,item.contact_id,claim).run();summary.retried++;
  }else if(result.kind==='unavailable'||result.kind==='invalid_response'){
   await c.db.prepare("UPDATE marketing_deliveries SET status='unknown',claim_token=NULL,locked_until=0,provider_error_code=?,updated_at=? WHERE campaign_id=? AND contact_id=? AND claim_token=?").bind(result.kind,stamp,item.campaign_id,item.contact_id,claim).run();summary.unknown++;
  }else{
   await c.db.prepare("UPDATE marketing_deliveries SET status='failed',claim_token=NULL,locked_until=0,provider_error_code=?,failed_at=?,updated_at=? WHERE campaign_id=? AND contact_id=? AND claim_token=?").bind(result.kind,stamp,stamp,item.campaign_id,item.contact_id,claim).run();summary.failed++;
  }
 }
 const active=await c.db.prepare("SELECT id FROM marketing_campaigns WHERE status='sending'").all<{id:string}>();
 for(const campaign of active.results??[]){const pending=await c.db.prepare("SELECT COUNT(*) count FROM marketing_deliveries WHERE campaign_id=? AND status IN ('queued','submitting','unknown')").bind(campaign.id).first<{count:number}>();if(Number(pending?.count??0)===0)await c.db.prepare("UPDATE marketing_campaigns SET status='completed',completed_at=?,updated_at=? WHERE id=? AND status='sending'").bind(stamp,stamp,campaign.id).run();}
 return summary;
}

export function authorizeWhatsAppWorker(authorization:unknown,c:WhatsAppCampaignContext){const expected=typeof c.workerToken==='string'?c.workerToken:'',given=typeof authorization==='string'&&authorization.startsWith('Bearer ')?authorization.slice(7):'';return safeToken(given,expected);}

export function whatsappWebhookChallenge(url:string,c:WhatsAppCampaignContext){return verifyWhatsAppWebhookChallenge(new URL(url).searchParams,c.provider.webhookVerifyToken);}

export async function applyWhatsAppWebhook(c:WhatsAppCampaignContext,rawBody:Uint8Array,signature:unknown){
 if(!verifyWhatsAppWebhookSignature(rawBody,signature,c.provider.appSecret))throw new WhatsAppCampaignError(401,'Invalid WhatsApp webhook signature');
 let payload:unknown;try{payload=JSON.parse(new TextDecoder().decode(rawBody));}catch{throw new WhatsAppCampaignError(400,'Invalid WhatsApp webhook JSON');}
 const parsed=parseWhatsAppWebhook(payload),payloadHash=hash(rawBody),stamp=epoch(),summary={statuses:0,optOuts:0,duplicates:0};
 const rank:Record<string,number>={sent:1,delivered:2,read:3};
 for(const item of parsed.statuses){
  const eventKey=hash(`status|${item.messageId}|${item.status}|${item.timestamp??''}|${item.errorCode??''}`),inserted=await c.db.prepare("INSERT INTO marketing_webhook_events(event_key,provider_message_id,event_type,status,payload_hash,received_at) VALUES(?,?,?,?,?,?) ON CONFLICT(event_key) DO NOTHING RETURNING event_key").bind(eventKey,item.messageId,'status',item.status,payloadHash,stamp).first<{event_key:string}>();
  if(!inserted){summary.duplicates++;continue;}
  const delivery=await c.db.prepare("SELECT status FROM marketing_deliveries WHERE provider_message_id=?").bind(item.messageId).first<{status:string}>();if(!delivery)continue;
  if(item.status==='failed'){
   if(!['failed','delivered','read','opted_out'].includes(delivery.status))await c.db.prepare("UPDATE marketing_deliveries SET status='failed',provider_error_code=?,failed_at=COALESCE(failed_at,?),updated_at=? WHERE provider_message_id=?").bind(item.errorCode===null?'provider_failed':String(item.errorCode),item.timestamp??stamp,stamp,item.messageId).run();
  }else if(!['failed','opted_out'].includes(delivery.status)&&(rank[item.status]??0)>(rank[delivery.status]??0)){
   const column=item.status==='sent'?'sent_at':item.status==='delivered'?'delivered_at':'read_at';await c.db.prepare(`UPDATE marketing_deliveries SET status=?,${column}=COALESCE(${column},?),updated_at=? WHERE provider_message_id=?`).bind(item.status,item.timestamp??stamp,stamp,item.messageId).run();
  }
  summary.statuses++;
 }
 for(const phone of parsed.optOuts){
  const eventKey=hash(`optout|${phone}|${payloadHash}`),inserted=await c.db.prepare("INSERT INTO marketing_webhook_events(event_key,provider_message_id,event_type,status,payload_hash,received_at) VALUES(?,NULL,'opt_out','opted_out',?,?) ON CONFLICT(event_key) DO NOTHING RETURNING event_key").bind(eventKey,payloadHash,stamp).first<{event_key:string}>();if(!inserted){summary.duplicates++;continue;}
  const contact=await c.db.prepare("SELECT id FROM marketing_contacts WHERE phone=?").bind(phone).first<{id:string}>();if(!contact)continue;
  await c.db.batch([
   c.db.prepare("UPDATE marketing_contacts SET consent_status='opted_out',consented_at=NULL,consent_source='whatsapp_inbound_opt_out',consent_proof='Recipient sent an opt-out keyword',updated_at=? WHERE id=?").bind(stamp,contact.id),
   c.db.prepare("UPDATE marketing_deliveries SET status='opted_out',claim_token=NULL,locked_until=0,updated_at=? WHERE contact_id=? AND status IN ('queued','submitting','unknown','failed')").bind(stamp,contact.id),
   c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)").bind(randomUUID(),'whatsapp-webhook','marketing_contact_opted_out',phone.slice(-4),stamp)
  ]);summary.optOuts++;
 }
 return summary;
}

export const whatsappTemplateParameterOrder=TEMPLATE_PARAMETER_ORDER;
export const whatsappTerminalStatuses=terminalStatuses;
