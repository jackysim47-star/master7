export class VipError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

export type VipCashbackPercent={slot:number;live:number;fish:number;sport:number;fastGame:number};
export type VipTier={
 level:number;
 name:string;
 color:string;
 active:boolean;
 cumulativeDepositMYR:number;
 turnoverThresholdMYR:number;
 retentionPeriodDays:number;
 retentionDepositMYR:number;
 retentionTurnoverMYR:number;
 upgradeBonusMYR:number;
 birthdayBonusMYR:number;
 dailyBonusMYR:number;
 weeklyBonusMYR:number;
 monthlyBonusMYR:number;
 dividendPercent:number;
 cashbackPercent:VipCashbackPercent;
 rewardTurnoverMultiplier:number;
 withdrawalLimitMYR:number|null;
 claimLimit:number;
 validityDays:number;
};
export type VipProgram={version:1;name:string;enabled:boolean;tiers:VipTier[]};
type StoredVipProgram=VipProgram&{updatedAt:number;updatedBy:string};
type ReferralSettings={
 configured?:boolean;
 enabled?:boolean;
 basis?:string;
 maxLevels?:number;
 claimMode?:string;
 tierRatesPercent?:unknown;
 minQualifyingMYR?:number;
 holdDays?:number;
 dailyCapMYR?:number;
 monthlyCapMYR?:number;
};

const SETTING_ID='vip_program_v1';
const TIER_NAMES=['Bronze','Silver','Gold','Platinum','Diamond','Royal','Crown','Master'] as const;
const TIER_COLORS=['#CD7F32','#C0C0C0','#D4AF37','#E5E4E2','#7FDBFF','#7B61FF','#F4C542','#00D7C7'] as const;
const TIER_KEYS=['level','name','color','active','cumulativeDepositMYR','turnoverThresholdMYR','retentionPeriodDays','retentionDepositMYR','retentionTurnoverMYR','upgradeBonusMYR','birthdayBonusMYR','dailyBonusMYR','weeklyBonusMYR','monthlyBonusMYR','dividendPercent','cashbackPercent','rewardTurnoverMultiplier','withdrawalLimitMYR','claimLimit','validityDays'] as const;
const CASHBACK_KEYS=['slot','live','fish','sport','fastGame'] as const;
const AUTOMATION={walletCredit:false,cashbackAutomation:false,dividendAutomation:false,turnoverEnforcement:false} as const;

function record(value:unknown,label:string):Record<string,unknown>{
 if(!value||typeof value!=='object'||Array.isArray(value))throw new VipError(400,`Invalid ${label}`);
 return value as Record<string,unknown>;
}
function exactKeys(value:Record<string,unknown>,allowed:readonly string[],label:string){
 const found=Object.keys(value),allowedSet=new Set(allowed),unknown=found.find(key=>!allowedSet.has(key)),missing=allowed.find(key=>!Object.hasOwn(value,key));
 if(unknown)throw new VipError(400,`Unknown ${label} field: ${unknown}`);
 if(missing)throw new VipError(400,`Missing ${label} field: ${missing}`);
}
function finite(value:unknown,label:string,min:number,max:number,integer=false){
 if(typeof value!=='number'||!Number.isFinite(value)||value<min||value>max)throw new VipError(400,`Invalid ${label}`);
 if(integer&&!Number.isInteger(value))throw new VipError(400,`Invalid ${label}`);
 if(!integer&&Math.abs(Math.round(value*100)-value*100)>1e-7)throw new VipError(400,`${label} supports at most two decimal places`);
 return value;
}
function money(value:unknown,label:string){return finite(value,label,0,1_000_000_000);}
function percent(value:unknown,label:string){return finite(value,label,0,100);}
function stringValue(value:unknown,label:string,min:number,max:number){
 if(typeof value!=='string'||value.trim()!==value||value.length<min||value.length>max)throw new VipError(400,`Invalid ${label}`);
 return value;
}
function parseTier(input:unknown,index:number):VipTier{
 const value=record(input,`tier ${index+1}`);exactKeys(value,TIER_KEYS,`tier ${index+1}`);
 const level=finite(value.level,`tier ${index+1} level`,1,8,true);
 if(level!==index+1)throw new VipError(400,'VIP levels must be ordered from 1 to 8');
 const name=stringValue(value.name,`tier ${level} name`,2,40),color=stringValue(value.color,`tier ${level} color`,7,7);
 if(!/^#[0-9A-Fa-f]{6}$/.test(color))throw new VipError(400,`Invalid tier ${level} color`);
 if(typeof value.active!=='boolean')throw new VipError(400,`Invalid tier ${level} active state`);
 const cashback=record(value.cashbackPercent,`tier ${level} cashback`);exactKeys(cashback,CASHBACK_KEYS,`tier ${level} cashback`);
 const withdrawalLimit=value.withdrawalLimitMYR===null?null:money(value.withdrawalLimitMYR,`tier ${level} withdrawal limit`);
 if(withdrawalLimit===0)throw new VipError(400,`Tier ${level} withdrawal limit must be null or positive`);
 const result:VipTier={
  level,name,color,active:value.active,
  cumulativeDepositMYR:money(value.cumulativeDepositMYR,`tier ${level} cumulative deposit threshold`),
  turnoverThresholdMYR:money(value.turnoverThresholdMYR,`tier ${level} turnover threshold`),
  retentionPeriodDays:finite(value.retentionPeriodDays,`tier ${level} retention period`,0,3650,true),
  retentionDepositMYR:money(value.retentionDepositMYR,`tier ${level} retention deposit threshold`),
  retentionTurnoverMYR:money(value.retentionTurnoverMYR,`tier ${level} retention turnover threshold`),
  upgradeBonusMYR:money(value.upgradeBonusMYR,`tier ${level} upgrade bonus`),
  birthdayBonusMYR:money(value.birthdayBonusMYR,`tier ${level} birthday bonus`),
  dailyBonusMYR:money(value.dailyBonusMYR,`tier ${level} daily bonus`),
  weeklyBonusMYR:money(value.weeklyBonusMYR,`tier ${level} weekly bonus`),
  monthlyBonusMYR:money(value.monthlyBonusMYR,`tier ${level} monthly bonus`),
  dividendPercent:percent(value.dividendPercent,`tier ${level} dividend`),
  cashbackPercent:{slot:percent(cashback.slot,`tier ${level} slot cashback`),live:percent(cashback.live,`tier ${level} live cashback`),fish:percent(cashback.fish,`tier ${level} fish cashback`),sport:percent(cashback.sport,`tier ${level} sport cashback`),fastGame:percent(cashback.fastGame,`tier ${level} fast game cashback`)},
  rewardTurnoverMultiplier:finite(value.rewardTurnoverMultiplier,`tier ${level} reward turnover multiplier`,0,1000),
  withdrawalLimitMYR:withdrawalLimit,
  claimLimit:finite(value.claimLimit,`tier ${level} claim limit`,0,1_000_000,true),
  validityDays:finite(value.validityDays,`tier ${level} validity`,0,3650,true),
 };
 if(result.retentionPeriodDays===0&&(result.retentionDepositMYR!==0||result.retentionTurnoverMYR!==0))throw new VipError(400,`Tier ${level} retention thresholds require a retention period`);
 const claimable=result.upgradeBonusMYR+result.birthdayBonusMYR+result.dailyBonusMYR+result.weeklyBonusMYR+result.monthlyBonusMYR>0||result.dividendPercent>0||Object.values(result.cashbackPercent).some(rate=>rate>0);
 if(result.active&&claimable&&(result.claimLimit===0||result.validityDays===0))throw new VipError(400,`Tier ${level} rewards require a claim limit and validity period`);
 return result;
}

export function validateVipProgram(input:unknown):VipProgram{
 const value=record(input,'VIP program');exactKeys(value,['version','name','enabled','tiers'],'VIP program');
 if(value.version!==1)throw new VipError(400,'Unsupported VIP program version');
 const name=stringValue(value.name,'VIP program name',2,60);
 if(typeof value.enabled!=='boolean')throw new VipError(400,'Invalid VIP program state');
 if(!Array.isArray(value.tiers)||value.tiers.length!==8)throw new VipError(400,'VIP program requires exactly eight tiers');
 const tiers=value.tiers.map(parseTier),names=new Set<string>();
 for(const item of tiers){const key=item.name.toLocaleLowerCase('en-US');if(names.has(key))throw new VipError(400,'VIP tier names must be unique');names.add(key);}
 const active=tiers.filter(item=>item.active);
 if(active.length){
  if(!tiers[0].active||tiers[0].cumulativeDepositMYR!==0)throw new VipError(400,'Active VIP programs must start with a zero-threshold level 1 tier');
  const highest=active.at(-1)!.level;
  for(let index=0;index<highest;index++)if(!tiers[index].active)throw new VipError(400,'Active VIP tiers must be contiguous');
  for(let index=1;index<highest;index++)if(tiers[index].cumulativeDepositMYR<=tiers[index-1].cumulativeDepositMYR)throw new VipError(400,'Active VIP deposit thresholds must increase by level');
 }
 if(value.enabled&&!active.length)throw new VipError(400,'Enable at least the level 1 VIP tier before enabling the program');
 return {version:1,name,enabled:value.enabled,tiers};
}

function defaultTier(level:number):VipTier{
 return {level,name:TIER_NAMES[level-1],color:TIER_COLORS[level-1],active:level===1,cumulativeDepositMYR:0,turnoverThresholdMYR:0,retentionPeriodDays:0,retentionDepositMYR:0,retentionTurnoverMYR:0,upgradeBonusMYR:0,birthdayBonusMYR:0,dailyBonusMYR:0,weeklyBonusMYR:0,monthlyBonusMYR:0,dividendPercent:0,cashbackPercent:{slot:0,live:0,fish:0,sport:0,fastGame:0},rewardTurnoverMultiplier:0,withdrawalLimitMYR:null,claimLimit:0,validityDays:0};
}
export function defaultVipProgram():VipProgram{return {version:1,name:'MASTER7 VIP',enabled:false,tiers:Array.from({length:8},(_,index)=>defaultTier(index+1))};}

async function loadVipProgram(db:D1Database):Promise<{configured:boolean;program:VipProgram;updatedAt:number|null;updatedBy:string|null}>{
 const row=await db.prepare('SELECT value FROM settings WHERE id=?').bind(SETTING_ID).first<{value:string}>();
 if(!row)return {configured:false,program:defaultVipProgram(),updatedAt:null,updatedBy:null};
 let raw:Record<string,unknown>;try{raw=record(JSON.parse(row.value),'stored VIP program');}catch{throw new VipError(503,'Stored VIP program is invalid');}
 const allowed=['version','name','enabled','tiers','updatedAt','updatedBy'];if(Object.keys(raw).some(key=>!allowed.includes(key)))throw new VipError(503,'Stored VIP program is invalid');
 let program:VipProgram;try{program=validateVipProgram({version:raw.version,name:raw.name,enabled:raw.enabled,tiers:raw.tiers});}catch{throw new VipError(503,'Stored VIP program is invalid');}
 if(!Number.isSafeInteger(raw.updatedAt)||Number(raw.updatedAt)<0||typeof raw.updatedBy!=='string'||raw.updatedBy.length<1||raw.updatedBy.length>128)throw new VipError(503,'Stored VIP program is invalid');
 return {configured:true,program,updatedAt:Number(raw.updatedAt),updatedBy:raw.updatedBy};
}

function safeNumber(value:unknown,fallback=0){const parsed=Number(value);return Number.isFinite(parsed)&&parsed>=0?parsed:fallback;}
function rates(value:unknown):[number,number,number]{const input=Array.isArray(value)?value:[];return [0,1,2].map(index=>{const rate=Number(input[index]);return Number.isFinite(rate)&&rate>=0&&rate<=100?Math.round(rate*100)/100:0;}) as [number,number,number];}
export function vipCommissionCapabilities(settings:ReferralSettings={}){
 const selected=['deposit','turnover','company_profit'].includes(settings.basis??'')?settings.basis:'deposit',configured=settings.configured===true,requested=settings.enabled===true,configuredRates=rates(settings.tierRatesPercent),inactiveRates={L1:0,L2:0,L3:0},rateMap=configured?{L1:configuredRates[0],L2:configuredRates[1],L3:configuredRates[2]}:inactiveRates,common={maxLevels:Math.min(3,Math.max(1,Math.round(safeNumber(settings.maxLevels,3)))),minDepositMYR:configured?safeNumber(settings.minQualifyingMYR):0,firstDepositOnly:false,firstDepositOnlySupported:false,holdDays:configured?Math.round(safeNumber(settings.holdDays)):0,dailyCapMYR:configured?safeNumber(settings.dailyCapMYR):0,monthlyCapMYR:configured?safeNumber(settings.monthlyCapMYR):0,claimMode:configured&&settings.claimMode==='automatic'?'automatic':'manual',claimAutomation:false,walletCredit:false};
 return {
  depositCommission:{...common,ratesPercent:selected==='deposit'?rateMap:inactiveRates,configured:configured&&selected==='deposit',requestedEnabled:requested&&selected==='deposit',enabled:requested&&configured&&selected==='deposit',basis:'credited_deposit',source:'deposit_orders',includedStatuses:['credited'],excludedStatuses:['pending','creating','created','unknown','review','failed'],ledger:'commission_entries_preview',settlement:'preview_only'},
  turnoverCommission:{...common,ratesPercent:selected==='turnover'?rateMap:inactiveRates,configured:configured&&selected==='turnover',requestedEnabled:requested&&selected==='turnover',enabled:false,basis:'turnover',source:'not_connected',ledger:'not_connected',settlement:'disabled'},
  companyProfitDividend:{...common,ratesPercent:selected==='company_profit'?rateMap:inactiveRates,configured:configured&&selected==='company_profit',requestedEnabled:requested&&selected==='company_profit',enabled:false,basis:'company_profit',source:'not_connected',ledger:'not_connected',settlement:'disabled'},
  availableBases:['deposit','turnover','company_profit'],configurationMode:'single_basis',independentLedgers:true,duplicateCommissionPolicy:'one_source_event_one_program',walletCredit:false,automation:false,
 };
}

function capabilities(){return {gameScope:'all_34_platforms',cashbackCategories:['slot','live','fish','sport','fastGame'],providerExclusionsSupported:false,creditedDepositTiering:true,turnoverTiering:false,wagerSource:'not_connected',turnoverSource:'not_connected',rewardCalculation:'configuration_only',...AUTOMATION};}
function baseResponse(loaded:Awaited<ReturnType<typeof loadVipProgram>>,referral:ReferralSettings){const commissions=vipCommissionCapabilities(referral);return {configured:loaded.configured,program:loaded.program,member:null,capabilities:capabilities(),commissionCapabilities:commissions,referral:{depositCommission:commissions.depositCommission},turnoverSource:'not_connected',...AUTOMATION};}
export async function getAdminVip(db:D1Database,referral:ReferralSettings={}){const loaded=await loadVipProgram(db);return {...baseResponse(loaded,referral),updatedAt:loaded.updatedAt,updatedBy:loaded.updatedBy,storage:SETTING_ID};}

function amountMinor(value:number){return BigInt(Math.round(value*100));}
function amountMYR(value:bigint){const sign=value<0n?'-':'',absolute=value<0n?-value:value;return `${sign}${absolute/100n}.${(absolute%100n).toString().padStart(2,'0')}`;}
function memberProgress(program:VipProgram,creditedMinor:bigint){
 const active=program.tiers.filter(item=>item.active),eligible=active.filter(item=>amountMinor(item.cumulativeDepositMYR)<=creditedMinor),previewCurrent=eligible.at(-1)??null,next=previewCurrent?active.find(item=>item.level>previewCurrent.level)??null:active[0]??null,threshold=next?amountMinor(next.cumulativeDepositMYR):null,remaining=threshold===null?null:threshold>creditedMinor?threshold-creditedMinor:0n,progressPercent=threshold===null?100:threshold===0n?100:Math.min(100,Math.round(Number(creditedMinor*10000n/threshold)/100));
 return {assignmentActive:program.enabled,currentTier:program.enabled?previewCurrent:null,previewCurrentTier:previewCurrent,nextTier:next,nextTierProgress:next?{creditedDepositMinor:creditedMinor.toString(),creditedDepositMYR:amountMYR(creditedMinor),requiredDepositMinor:threshold!.toString(),requiredDepositMYR:amountMYR(threshold!),remainingDepositMinor:remaining!.toString(),remainingDepositMYR:amountMYR(remaining!),percent:progressPercent}:null,eligibilityBasis:'credited_deposit_only',turnoverSource:'not_connected',turnoverApplied:false,state:program.enabled?'active':'program_disabled'};
}
export async function getPublicVip(db:D1Database,memberId:string|null,referral:ReferralSettings={}){
 const loaded=await loadVipProgram(db),response=baseResponse(loaded,referral);
 if(!memberId)return response;
 const row=await db.prepare("SELECT CAST(COALESCE(SUM(amount_minor),0) AS TEXT) credited_minor FROM deposit_orders WHERE user_id=? AND status='credited' AND currency='MYR'").bind(memberId).first<{credited_minor:string}>(),credited=BigInt(String(row?.credited_minor??'0'));
 return {...response,member:{creditedDeposits:{amountMinor:credited.toString(),amountMYR:amountMYR(credited),currency:'MYR',source:'deposit_orders',status:'credited'},...memberProgress(loaded.program,credited)}};
}

export async function saveVipProgram(db:D1Database,ownerId:string,input:unknown,at=Math.floor(Date.now()/1000)){
 const outer=record(input,'VIP request'),candidate=Object.hasOwn(outer,'program')?(()=>{exactKeys(outer,['program'],'VIP request');return outer.program;})():outer,program=validateVipProgram(candidate),stored:StoredVipProgram={...program,updatedAt:at,updatedBy:ownerId},activeLevels=program.tiers.filter(item=>item.active).map(item=>item.level);
 await db.batch([
  db.prepare('INSERT INTO settings(id,value) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind(SETTING_ID,JSON.stringify(stored)),
  db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),ownerId,'vip_program_updated',JSON.stringify({version:1,enabled:program.enabled,activeLevels}),at),
 ]);
 return {status:'ok',configured:true,program,updatedAt:at,updatedBy:ownerId,storage:SETTING_ID,capabilities:capabilities(),turnoverSource:'not_connected',...AUTOMATION};
}

export async function vipProgramStatus(db:D1Database){const loaded=await loadVipProgram(db);return {configured:loaded.configured,enabled:loaded.program.enabled,activeTiers:loaded.program.tiers.filter(item=>item.active).length};}
