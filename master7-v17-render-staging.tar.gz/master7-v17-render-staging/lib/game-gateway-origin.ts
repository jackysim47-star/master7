export const dedicatedGameGatewayOrigin = 'https://master7-game-gateway.onrender.com';
export const legacyGameGatewayOrigin = 'https://master7-integration-gateway.onrender.com';

export function approvedGameGatewayOrigin(value?: string): string | null {
 return value === dedicatedGameGatewayOrigin || value === legacyGameGatewayOrigin ? value : null;
}
