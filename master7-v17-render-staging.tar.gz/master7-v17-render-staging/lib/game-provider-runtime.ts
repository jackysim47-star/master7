import {jdbProfileRuntime} from './jdb-profile-runtime.ts';
import {jiliProfileRuntime} from './jili-profile-runtime.ts';
import {getGameProviderProfile,type RegisteredGameProviderProfile} from './game-provider-registry.ts';
import {registeredCashProfileUnits} from './game-profile-units.ts';
import type {GameProviderAdapter} from './game-provider-adapter.ts';

export type TransferRuntimeSettings={jdbTransferProfilesJson?:string;gameTransferProfilesJson?:string;providerTransferFetch?:typeof fetch};
export type GameTransferRuntime={profile:RegisteredGameProviderProfile;adapter:GameProviderAdapter;launchAuthorized:boolean;recoveryEnabled:boolean;mode:'closed'|'qa'|'production';environment:'production'};
type Factory=(settings:TransferRuntimeSettings,profileId:string,userId:string,productionAccepted:boolean)=>GameTransferRuntime|null;

function profileDocument(settings:TransferRuntimeSettings,profileId:string){
 if(!settings.gameTransferProfilesJson)return settings.jdbTransferProfilesJson;
 try{
  if(Buffer.byteLength(settings.gameTransferProfilesJson)>262_144)return undefined;
  const document=JSON.parse(settings.gameTransferProfilesJson);
  if(!document||typeof document!=='object'||!document.profiles||typeof document.profiles!=='object'||Array.isArray(document.profiles))return undefined;
  return Object.hasOwn(document.profiles,profileId)?JSON.stringify({profiles:{[profileId]:document.profiles[profileId]}}):settings.jdbTransferProfilesJson;
 }catch{return undefined;}
}

// Registration is compiled server code. Browser fields and secret JSON cannot
// install executable adapters or select an arbitrary provider protocol.
const factories:Readonly<Record<string,Factory>>=Object.freeze({
 jdb:(settings,profileId,userId,productionAccepted)=>jdbProfileRuntime(profileDocument(settings,profileId),profileId,userId,{fetchImpl:settings.providerTransferFetch,productionAccepted}),
 jili:(settings,profileId,userId,productionAccepted)=>jiliProfileRuntime(profileDocument(settings,profileId),profileId,userId,{fetchImpl:settings.providerTransferFetch,productionAccepted}),
});

export function transferProfileSupported(profile:RegisteredGameProviderProfile){
 return profile.listedInLobby&&profile.implemented&&profile.walletMode==='transfer'&&profile.providerId!=='megah5'&&typeof factories[profile.adapterKey]==='function';
}

export function gameTransferRuntime(settings:TransferRuntimeSettings,profileId:string,userId:string,productionAccepted=false):GameTransferRuntime|null{
 const profile=getGameProviderProfile(profileId);if(!profile||!transferProfileSupported(profile))return null;
 try{
  const runtime=factories[profile.adapterKey](settings,profileId,userId,productionAccepted);
  if(!runtime||runtime.profile.profileId!==profileId||runtime.profile.providerId!==profile.providerId||runtime.adapter.key!==profile.adapterKey||runtime.adapter.executable!==true)return null;
  return {...runtime,profile};
 }catch{return null;}
}

export async function seedTransferProfile(db:D1Database,runtime:GameTransferRuntime){
 const p=runtime.profile,units=registeredCashProfileUnits(p.profileId),at=Math.floor(Date.now()/1000);
 if(!units||units.providerId!==p.providerId||units.unitScale!==p.unitScale||p.walletMode!=='transfer')return false;
 await db.prepare("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES(?,?,?,?,'transfer','cash','MYR',?,1,'production',?,?,?) ON CONFLICT(id) DO NOTHING")
  .bind(p.profileId,p.providerId,p.displayName,p.adapterKey,units.numerator,runtime.mode==='qa'?'uat':runtime.mode==='production'&&runtime.launchAuthorized?'active':'closed',at,at).run();
 const stored=await db.prepare('SELECT provider_id,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment FROM game_provider_profiles WHERE id=?').bind(p.profileId).first<Record<string,unknown>>();
 return !!stored&&stored.environment==='production'&&stored.provider_id===p.providerId&&stored.adapter_key===p.adapterKey&&stored.wallet_mode==='transfer'&&stored.balance_class==='cash'&&stored.currency==='MYR'&&String(stored.unit_numerator)===String(units.numerator)&&String(stored.unit_denominator)==='1';
}
