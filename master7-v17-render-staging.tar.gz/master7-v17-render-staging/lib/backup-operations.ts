import {createHash} from 'node:crypto';
import {BACKUP_FORMAT,BACKUP_SCHEMA_SHA256,BACKUP_SCHEMA_VERSION,BACKUP_TABLES,createEncryptedPortalBackup} from './encrypted-backup.ts';
import {BACKUP_PUBLIC_KEY_SHA256} from './backup-public-key.ts';

export class BackupOperationsError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

const now=()=>Math.floor(Date.now()/1000);
const uuid=()=>crypto.randomUUID();
const sha256Hex=(value:string|Uint8Array)=>createHash('sha256').update(value).digest('hex');
const validSha256=(value:unknown)=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const freshIso=(value:unknown,maxAgeSeconds:number,timestamp=now())=>{if(typeof value!=='string')return false;const epoch=Math.floor(Date.parse(value)/1000);return Number.isFinite(epoch)&&epoch<=timestamp+300&&epoch>=timestamp-maxAgeSeconds;};
const restoreTarget=(value:unknown)=>{if(typeof value!=='string'||value.length>500)return null;const match=value.match(/^isolated PostgreSQL transaction on ([A-Za-z0-9.-]{1,253})\/([A-Za-z0-9_-]{1,128})$/);return match&&/(?:^|[_-])(restore|rehearsal|sandbox|test)(?:$|[_-])/i.test(match[2])?value:null;};
const audit=(db:D1Database,actorId:string,event:string,target:string)=>db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(uuid(),actorId,event,target,now());

async function locked<T>(db:D1Database,operation:()=>Promise<T>){
 const lockId='internal:backup_job',claim=Number.parseInt(sha256Hex(uuid()).slice(0,8),16),expiresAt=now()+1800;
 const acquired=await db.prepare('INSERT INTO rate_limits(id,count,expires_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET count=excluded.count,expires_at=excluded.expires_at WHERE rate_limits.expires_at<=? RETURNING count').bind(lockId,claim,expiresAt,now()).first<{count:number}>();
 if(Number(acquired?.count)!==claim)throw new BackupOperationsError(409,'A backup operation is already running');
 try{return await operation();}
 finally{try{await db.prepare('DELETE FROM rate_limits WHERE id=? AND count=? AND expires_at=?').bind(lockId,claim,expiresAt).run();}catch{}}
}

export async function latestEncryptedBackupAudit(db:D1Database){
 const result=await db.prepare("SELECT target,created_at FROM audit WHERE event='encrypted_backup_created' AND created_at=(SELECT MAX(created_at) FROM audit WHERE event='encrypted_backup_created')").all<{target:string;created_at:number}>();let latest:{metadata:any;created_at:number}|null=null;
 for(const row of result.results??[]){let metadata:any=null;try{metadata=JSON.parse(row.target);}catch{}if(!metadata||!freshIso(metadata.createdAt,30*86400))continue;if(!latest||Date.parse(metadata.createdAt)>Date.parse(latest.metadata.createdAt))latest={metadata,created_at:Number(row.created_at)};}
 return latest;
}

export async function createPortalBackup(db:D1Database,release:string,actorId:string){
 return locked(db,async()=>{const {envelope,metadata}=await createEncryptedPortalBackup(db,release),serialized=JSON.stringify(envelope),evidence={format:BACKUP_FORMAT,...metadata,backupSha256:sha256Hex(serialized),plaintextSha256:envelope.plaintextSha256};await audit(db,actorId,'encrypted_backup_created',JSON.stringify(evidence)).run();return {serialized,metadata,filename:`master7-encrypted-backup-${metadata.createdAt.replace(/[:.]/g,'-')}.json`};});
}

export async function recordPortalRestoreRehearsal(db:D1Database,release:string,actorId:string,d:any){
 return locked(db,async()=>{
  const latest=await latestEncryptedBackupAudit(db),evidence=latest?.metadata??null,tableCount=Number(d.tableCount),totalRecords=Number(d.totalRecords),foreignKeyViolations=Number(d.foreignKeyViolations),verifiedAt=typeof d.verifiedAt==='string'?d.verifiedAt:'',createdAt=typeof d.createdAt==='string'?d.createdAt:'',target=restoreTarget(d.restoreTarget),createdEpoch=Date.parse(createdAt),verifiedEpoch=Date.parse(verifiedAt);
  const matches=!!evidence&&evidence.format===BACKUP_FORMAT&&evidence.release===release&&evidence.schemaVersion===BACKUP_SCHEMA_VERSION&&evidence.schemaSha256===BACKUP_SCHEMA_SHA256&&evidence.publicKeySha256===BACKUP_PUBLIC_KEY_SHA256&&evidence.readConsistency==='transaction_snapshot'&&evidence.tableCount===BACKUP_TABLES.length&&Number.isSafeInteger(evidence.totalRecords)&&evidence.totalRecords>=0&&validSha256(evidence.backupSha256)&&validSha256(evidence.plaintextSha256)&&validSha256(evidence.ciphertextSha256)&&freshIso(evidence.createdAt,7*86400)&&Number(latest?.created_at??0)>=now()-7*86400&&createdAt===evidence.createdAt&&d.backupSha256===evidence.backupSha256&&d.plaintextSha256===evidence.plaintextSha256&&totalRecords===evidence.totalRecords;
  if(d.status!=='verified'||d.format!==BACKUP_FORMAT||d.release!==release||d.schemaVersion!==BACKUP_SCHEMA_VERSION||d.schemaSha256!==BACKUP_SCHEMA_SHA256||d.publicKeySha256!==BACKUP_PUBLIC_KEY_SHA256||d.coverageComplete!==true||!Array.isArray(d.missingTables)||d.missingTables.length!==0||d.readConsistency!=='transaction_snapshot'||d.persistentWrites!==false||!target||tableCount!==BACKUP_TABLES.length||!Number.isSafeInteger(totalRecords)||totalRecords<0||foreignKeyViolations!==0||!freshIso(createdAt,30*86400)||!freshIso(verifiedAt,30*86400)||!Number.isFinite(createdEpoch)||!Number.isFinite(verifiedEpoch)||verifiedEpoch<createdEpoch||!matches)throw new BackupOperationsError(400,'Invalid recovery rehearsal receipt');
  const receipt={status:'verified',format:BACKUP_FORMAT,release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,backupSha256:evidence.backupSha256,plaintextSha256:evidence.plaintextSha256,publicKeySha256:BACKUP_PUBLIC_KEY_SHA256,tableCount,totalRecords,foreignKeyViolations:0,coverageComplete:true,missingTables:[],readConsistency:'transaction_snapshot',persistentWrites:false,restoreTargetKind:'isolated_postgresql_transaction',restoreTargetSha256:sha256Hex(target),createdAt,verifiedAt,recordedAt:new Date().toISOString()};
  const current=await db.prepare("SELECT value FROM settings WHERE id='backup_restore_rehearsal'").first<{value:string}>();if(current?.value){try{const existing=JSON.parse(current.value);if(existing.backupSha256===receipt.backupSha256&&existing.plaintextSha256===receipt.plaintextSha256&&existing.restoreTargetSha256===receipt.restoreTargetSha256&&existing.verifiedAt===receipt.verifiedAt)return {receipt:existing,idempotent:true};}catch{}}
  await db.batch([db.prepare("INSERT INTO settings(id,value) VALUES('backup_restore_rehearsal',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(JSON.stringify(receipt)),audit(db,actorId,'backup_restore_rehearsal',JSON.stringify({verifiedAt,tableCount,totalRecords,backupSha256:evidence.backupSha256,restoreTargetSha256:receipt.restoreTargetSha256}))]);return {receipt,idempotent:false};
 });
}
