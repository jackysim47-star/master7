type Facts={kind:string;httpStatus?:number;upstreamStatus?:number;providerCode?:number;providerTradeNo?:string;checkoutHost?:string;missing?:string[];gatewayError?:string};
export class PaymentRequestError extends Error{facts:Facts;constructor(facts:Facts){super('PAYMENT_REQUEST_UNCONFIRMED');this.facts=facts;}}
export const safeProviderCode=(value:unknown)=>typeof value==='number'&&Number.isInteger(value)&&Math.abs(value)<=999999?value:typeof value==='string'&&/^-?\d{1,6}$/.test(value)?Number(value):undefined;
export function paymentUrlHost(value:unknown){try{const u=new URL(String(value));return u.protocol==='https:'&&/^[a-z0-9.-]{1,128}$/.test(u.hostname)?u.hostname:undefined;}catch{return undefined;}}
// A business rejection is safe to retry only when the provider completed the
// request and explicitly rejected it before issuing either a provider order
// reference or checkout destination. Transport failures and malformed replies
// remain ambiguous because the provider may have created an order even though
// this application did not receive the response.
export function definitivePaymentRejectionFacts(value:unknown){
 if(!value||typeof value!=='object'||Array.isArray(value))return false;
 const facts=value as Partial<Facts>,explicitCode=typeof facts.providerCode==='number'&&Number.isInteger(facts.providerCode)&&facts.providerCode!==0;
 const noProviderOrder=!facts.providerTradeNo&&!facts.checkoutHost;
 if(!explicitCode||!noProviderOrder)return false;
 if(facts.kind==='ORDER_RESPONSE')return true;
 return facts.kind==='GATEWAY_HTTP'&&facts.upstreamStatus!==undefined&&facts.upstreamStatus>=200&&facts.upstreamStatus<300;
}
export function definitivePaymentRejection(error:unknown){return error instanceof PaymentRequestError&&definitivePaymentRejectionFacts(error.facts);}
// Older releases stored every provider rejection as `unknown`. Reconcile only
// the signed-in member's recent orders whose sanitized diagnostic proves an
// explicit business rejection and whose database row still has no provider
// reference or checkout URL. Ambiguous historical orders remain untouched.
export async function reconcileHistoricalPaymentRejections(db:D1Database,userId:string){
 const audit=await db.prepare("SELECT target FROM audit WHERE user_id=? AND event='payment_order_diagnostic' ORDER BY created_at DESC,id DESC LIMIT 100").bind(userId).all<{target:string}>();
 let updated=0;
 for(const row of audit.results??[]){
  let value:unknown;try{value=JSON.parse(row.target);}catch{continue;}
  if(!value||typeof value!=='object'||Array.isArray(value))continue;
  const facts=value as Record<string,unknown>,provider=typeof facts.provider==='string'?facts.provider:'',orderId=typeof facts.orderId==='string'?facts.orderId:'';
  if(!['vpay','1mpay'].includes(provider)||!/^[A-Za-z0-9_-]{1,50}$/.test(orderId)||!definitivePaymentRejectionFacts(facts))continue;
  await db.prepare("UPDATE deposit_orders SET status='failed',updated_at=? WHERE id=? AND user_id=? AND provider=? AND status='unknown' AND provider_trade_no IS NULL AND checkout_url IS NULL").bind(Math.floor(Date.now()/1000),orderId,userId,provider).run();
  const order=await db.prepare('SELECT status FROM deposit_orders WHERE id=? AND user_id=? AND provider=?').bind(orderId,userId,provider).first<{status:string}>();
  if(order?.status==='failed')updated++;
 }
 return updated;
}
export async function recordPaymentDiagnostic(db:D1Database,userId:string,provider:string,orderId:string,error:unknown){
 const facts=error instanceof PaymentRequestError?error.facts:{kind:error instanceof Error&&['AbortError','TimeoutError'].includes(error.name)?'TIMEOUT':'REQUEST_UNCONFIRMED'};
 // Never record raw bodies, signing inputs, keys, bank details, bearer tokens
 // or checkout queries. The audit remains visible to the owner only.
 await db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),userId,'payment_order_diagnostic',JSON.stringify({provider,orderId,...facts}),Math.floor(Date.now()/1000)).run();
}
