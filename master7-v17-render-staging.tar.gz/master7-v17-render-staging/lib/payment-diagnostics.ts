type Facts={kind:string;httpStatus?:number;upstreamStatus?:number;providerCode?:number;providerTradeNo?:string;checkoutHost?:string;missing?:string[];gatewayError?:string};
export class PaymentRequestError extends Error{facts:Facts;constructor(facts:Facts){super('PAYMENT_REQUEST_UNCONFIRMED');this.facts=facts;}}
export const safeProviderCode=(value:unknown)=>typeof value==='number'&&Number.isInteger(value)&&Math.abs(value)<=999999?value:typeof value==='string'&&/^-?\d{1,6}$/.test(value)?Number(value):undefined;
export function paymentUrlHost(value:unknown){try{const u=new URL(String(value));return u.protocol==='https:'&&/^[a-z0-9.-]{1,128}$/.test(u.hostname)?u.hostname:undefined;}catch{return undefined;}}
export async function recordPaymentDiagnostic(db:D1Database,userId:string,provider:string,orderId:string,error:unknown){
 const facts=error instanceof PaymentRequestError?error.facts:{kind:error instanceof Error&&['AbortError','TimeoutError'].includes(error.name)?'TIMEOUT':'REQUEST_UNCONFIRMED'};
 // Never record raw bodies, signing inputs, keys, bank details, bearer tokens
 // or checkout queries. The audit remains visible to the owner only.
 await db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),userId,'payment_order_diagnostic',JSON.stringify({provider,orderId,...facts}),Math.floor(Date.now()/1000)).run();
}
