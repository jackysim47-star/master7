import {createHash} from 'node:crypto';

export const BONUS_RISK_SETTING_ID='bonus_risk_v1';

export type BonusRiskSeverity='low'|'medium'|'high';
export type BonusRiskThresholds={
 depositAttempts:number;
 failedOrUnknownDeposits:number;
 referralFanout:number;
 benefitClaims:number;
 benefitClaimsPerDeposit:number;
 writeRateLimits:number;
};

export type BonusRiskConfig={
 version:1;
 mode:'monitor_only';
 thresholds:BonusRiskThresholds;
};

export type BonusRiskOptions={
 now?:number;
 hours?:number;
 limit?:number;
 severity?:BonusRiskSeverity|null;
};

export class BonusRiskError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

export const DEFAULT_BONUS_RISK_CONFIG:BonusRiskConfig={
 version:1,
 mode:'monitor_only',
 thresholds:{
  depositAttempts:8,
  failedOrUnknownDeposits:4,
  referralFanout:20,
  benefitClaims:6,
  benefitClaimsPerDeposit:2,
  writeRateLimits:3
 }
};

type Row=Record<string,unknown>;
type RiskCase={
 id:string;
 ruleId:string;
 module:string;
 severity:BonusRiskSeverity;
 reason:string;
 member:{id:string;username:string};
 evidence:{count:number;firstObservedAt:number;lastObservedAt:number;metrics:Record<string,number>};
 reviewStatus:'unreviewed';
 disposition:'manual_review';
 automaticAction:false;
};

const integer=(value:unknown)=>Number.isSafeInteger(Number(value))?Number(value):0;
const text=(value:unknown)=>typeof value==='string'?value:String(value??'');
const clampInteger=(value:unknown,min:number,max:number,name:string)=>{
 const parsed=typeof value==='number'?value:Number(value);
 if(!Number.isSafeInteger(parsed)||parsed<min||parsed>max)throw new BonusRiskError(400,`Invalid ${name}`);
 return parsed;
};
const caseId=(ruleId:string,memberId:string,anchor:number)=>'br_'+createHash('sha256').update(`${ruleId}\u0000${memberId}\u0000${anchor}`).digest('hex').slice(0,24);
const severityWeight:Record<BonusRiskSeverity,number>={high:3,medium:2,low:1};

function normalizeThresholds(value:unknown):BonusRiskThresholds{
 const source=value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:{};
 return {
  depositAttempts:clampInteger(source.depositAttempts??DEFAULT_BONUS_RISK_CONFIG.thresholds.depositAttempts,2,1000,'depositAttempts threshold'),
  failedOrUnknownDeposits:clampInteger(source.failedOrUnknownDeposits??DEFAULT_BONUS_RISK_CONFIG.thresholds.failedOrUnknownDeposits,2,1000,'failedOrUnknownDeposits threshold'),
  referralFanout:clampInteger(source.referralFanout??DEFAULT_BONUS_RISK_CONFIG.thresholds.referralFanout,2,1000,'referralFanout threshold'),
  benefitClaims:clampInteger(source.benefitClaims??DEFAULT_BONUS_RISK_CONFIG.thresholds.benefitClaims,2,1000,'benefitClaims threshold'),
  benefitClaimsPerDeposit:clampInteger(source.benefitClaimsPerDeposit??DEFAULT_BONUS_RISK_CONFIG.thresholds.benefitClaimsPerDeposit,2,100,'benefitClaimsPerDeposit threshold'),
  writeRateLimits:clampInteger(source.writeRateLimits??DEFAULT_BONUS_RISK_CONFIG.thresholds.writeRateLimits,1,1000,'writeRateLimits threshold')
 };
}

export function normalizeBonusRiskConfig(value:unknown):BonusRiskConfig{
 const source=value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:{};
 if(source.mode!==undefined&&source.mode!=='monitor_only')throw new BonusRiskError(400,'Bonus risk mode must remain monitor_only');
 if(source.version!==undefined&&source.version!==1)throw new BonusRiskError(400,'Unsupported bonus risk settings version');
 return {version:1,mode:'monitor_only',thresholds:normalizeThresholds(source.thresholds)};
}

export async function loadBonusRiskConfig(db:D1Database):Promise<BonusRiskConfig>{
 const row=await db.prepare('SELECT value FROM settings WHERE id=?').bind(BONUS_RISK_SETTING_ID).first<{value:string}>();
 if(!row?.value)return structuredClone(DEFAULT_BONUS_RISK_CONFIG);
 try{return normalizeBonusRiskConfig(JSON.parse(row.value));}catch{return structuredClone(DEFAULT_BONUS_RISK_CONFIG);}
}

export async function saveBonusRiskConfig(db:D1Database,value:unknown):Promise<BonusRiskConfig>{
 const config=normalizeBonusRiskConfig(value);
 await db.prepare('INSERT INTO settings(id,value) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind(BONUS_RISK_SETTING_ID,JSON.stringify(config)).run();
 return config;
}

async function rows(db:D1Database,sql:string,...values:(string|number)[]){
 return ((await db.prepare(sql).bind(...values).all()).results??[]) as Row[];
}

function memberCase(input:{ruleId:string;module:string;severity:BonusRiskSeverity;reason:string;memberId:unknown;username:unknown;count:unknown;firstAt:unknown;lastAt:unknown;metrics?:Record<string,number>}):RiskCase{
 const firstAt=integer(input.firstAt),lastAt=integer(input.lastAt),memberId=text(input.memberId),username=text(input.username);
 return {id:caseId(input.ruleId,memberId,lastAt||firstAt),ruleId:input.ruleId,module:input.module,severity:input.severity,reason:input.reason,member:{id:memberId,username},evidence:{count:integer(input.count),firstObservedAt:firstAt,lastObservedAt:lastAt,metrics:input.metrics??{}},reviewStatus:'unreviewed',disposition:'manual_review',automaticAction:false};
}

function readiness(){
 const unavailable=(id:string,label:string,missing:string[])=>({id,label,status:'not_connected',source:'not_connected',caseGeneration:false,missing});
 return [
  {id:'bonus_abuse',label:'Bonus abuse',status:'connected_limited',source:'benefit_claims+deposit_orders',caseGeneration:true,limitations:['benefit claims are preview-only','verified wagering and settled bonus credit are not connected']},
  unavailable('multi_account','Multi-account',['device fingerprint','verified IP identity','shared bank identity link']),
  {id:'deposit_fraud',label:'Deposit fraud',status:'connected_limited',source:'deposit_orders',caseGeneration:true,limitations:['persisted receipt hash is not connected','provider references are protected by a uniqueness constraint but are not scored']},
  unavailable('withdrawal_risk','Withdrawal risk',['verified turnover','provider risk outcome','trusted bank identity match']),
  unavailable('turnover_compliance','Turnover compliance',['verified wager feed','accepted turnover obligations']),
  {id:'referral_fraud',label:'Referral fraud',status:'connected_limited',source:'referral_relationships',caseGeneration:true,limitations:['fanout is a review signal only','identity linkage is not connected']},
  {id:'bonus_stacking',label:'Bonus stacking',status:'connected_limited',source:'benefit_claims',caseGeneration:true,limitations:['claims are preview-only','wallet bonus posting is disabled']},
  unavailable('game_pattern','Game pattern',['verified wager feed','game risk classification','low-risk game model']),
  {id:'account_security',label:'Account security',status:'connected_limited',source:'audit',caseGeneration:true,limitations:['only persisted write rate-limit events are available','login and device telemetry are not connected']},
  unavailable('provider_reconciliation','Provider reconciliation',['provider settlement statement']),
  unavailable('bank_reconciliation','Bank reconciliation',['bank statement feed','persisted receipt hash']),
  unavailable('chargeback_refund','Chargeback / refund',['chargeback feed','refund ledger']),
  unavailable('case_management','Case management',['persisted review decisions','review assignment workflow']),
  unavailable('real_time_alert','Real-time alert',['event stream','alert delivery acknowledgement'])
 ];
}

export async function bonusRiskReport(db:D1Database,options:BonusRiskOptions={}){
 const generatedAt=options.now===undefined?Math.floor(Date.now()/1000):clampInteger(options.now,0,Number.MAX_SAFE_INTEGER,'current time');
 const hours=options.hours===undefined?24:clampInteger(options.hours,1,720,'hours');
 const limit=options.limit===undefined?100:clampInteger(options.limit,1,200,'limit');
 if(options.severity!==undefined&&options.severity!==null&&!['low','medium','high'].includes(options.severity))throw new BonusRiskError(400,'Invalid severity');
 const start=generatedAt-hours*3600,end=generatedAt+1,config=await loadBonusRiskConfig(db),thresholds=config.thresholds,queryLimit=Math.min(1000,Math.max(limit*4,200)),scanLimit=Math.min(20000,Math.max(queryLimit*25,5000)),cycleSeedLimit=Math.min(1000,queryLimit*2);
 const [depositRows,fanoutRows,claimVelocityRows,stackRows,rateRows,cycleRows]=await Promise.all([
  rows(db,`WITH recent_deposits AS (SELECT user_id,status,created_at FROM deposit_orders WHERE created_at>=? AND created_at<? ORDER BY created_at DESC LIMIT ?) SELECT d.user_id,u.username,COUNT(*) attempt_count,SUM(CASE WHEN d.status IN ('failed','unknown') THEN 1 ELSE 0 END) failed_unknown_count,MIN(d.created_at) first_at,MAX(d.created_at) last_at FROM recent_deposits d JOIN users u ON u.id=d.user_id AND u.role='member' GROUP BY d.user_id,u.username HAVING COUNT(*)>=? OR SUM(CASE WHEN d.status IN ('failed','unknown') THEN 1 ELSE 0 END)>=? ORDER BY failed_unknown_count DESC,attempt_count DESC,last_at DESC LIMIT ?`,start,end,scanLimit,thresholds.depositAttempts,thresholds.failedOrUnknownDeposits,queryLimit),
  rows(db,`WITH recent_referrals AS (SELECT referrer_id,created_at FROM referral_relationships WHERE created_at>=? AND created_at<? ORDER BY created_at DESC LIMIT ?) SELECT r.referrer_id user_id,u.username,COUNT(*) referral_count,MIN(r.created_at) first_at,MAX(r.created_at) last_at FROM recent_referrals r JOIN users u ON u.id=r.referrer_id AND u.role='member' GROUP BY r.referrer_id,u.username HAVING COUNT(*)>=? ORDER BY referral_count DESC,last_at DESC LIMIT ?`,start,end,scanLimit,thresholds.referralFanout,queryLimit),
  rows(db,`WITH recent_claims AS (SELECT user_id,created_at FROM benefit_claims WHERE created_at>=? AND created_at<? ORDER BY created_at DESC LIMIT ?) SELECT c.user_id,u.username,COUNT(*) claim_count,MIN(c.created_at) first_at,MAX(c.created_at) last_at FROM recent_claims c JOIN users u ON u.id=c.user_id AND u.role='member' GROUP BY c.user_id,u.username HAVING COUNT(*)>=? ORDER BY claim_count DESC,last_at DESC LIMIT ?`,start,end,scanLimit,thresholds.benefitClaims,queryLimit),
  rows(db,`WITH recent_claims AS (SELECT user_id,benefit_rule_id,deposit_order_id,created_at FROM benefit_claims WHERE deposit_order_id IS NOT NULL AND created_at>=? AND created_at<? ORDER BY created_at DESC LIMIT ?) SELECT c.user_id,u.username,c.deposit_order_id,COUNT(DISTINCT c.benefit_rule_id) rule_count,MIN(c.created_at) first_at,MAX(c.created_at) last_at FROM recent_claims c JOIN users u ON u.id=c.user_id AND u.role='member' GROUP BY c.user_id,u.username,c.deposit_order_id HAVING COUNT(DISTINCT c.benefit_rule_id)>=? ORDER BY rule_count DESC,last_at DESC LIMIT ?`,start,end,scanLimit,thresholds.benefitClaimsPerDeposit,queryLimit),
  rows(db,`WITH recent_events AS (SELECT user_id,created_at FROM audit WHERE event='write_rate_limited' AND created_at>=? AND created_at<? ORDER BY created_at DESC LIMIT ?) SELECT a.user_id,u.username,COUNT(*) event_count,MIN(a.created_at) first_at,MAX(a.created_at) last_at FROM recent_events a JOIN users u ON u.id=a.user_id AND u.role='member' GROUP BY a.user_id,u.username HAVING COUNT(*)>=? ORDER BY event_count DESC,last_at DESC LIMIT ?`,start,end,scanLimit,thresholds.writeRateLimits,queryLimit),
  rows(db,`WITH RECURSIVE recent_referrals AS (SELECT member_id,referrer_id,created_at FROM referral_relationships WHERE created_at>=? AND created_at<? ORDER BY created_at DESC LIMIT ?),referral_path(origin,node_id,depth,first_at,last_at) AS (SELECT member_id,referrer_id,1,created_at,created_at FROM recent_referrals UNION ALL SELECT p.origin,r.referrer_id,p.depth+1,CASE WHEN p.first_at<r.created_at THEN p.first_at ELSE r.created_at END,CASE WHEN p.last_at>r.created_at THEN p.last_at ELSE r.created_at END FROM referral_path p JOIN referral_relationships r ON r.member_id=p.node_id WHERE p.depth<20) SELECT p.origin user_id,u.username,MIN(p.depth) cycle_length,MIN(p.first_at) first_at,MAX(p.last_at) last_at FROM referral_path p JOIN users u ON u.id=p.origin AND u.role='member' WHERE p.node_id=p.origin GROUP BY p.origin,u.username ORDER BY last_at DESC,p.origin LIMIT ?`,start,end,cycleSeedLimit,queryLimit)
 ]);
 const cases:RiskCase[]=[];
 for(const row of depositRows){
  const attempts=integer(row.attempt_count),bad=integer(row.failed_unknown_count),first=integer(row.first_at),last=integer(row.last_at);
  if(bad>=thresholds.failedOrUnknownDeposits)cases.push(memberCase({ruleId:'deposit_failed_unknown_velocity',module:'deposit_fraud',severity:bad>=thresholds.failedOrUnknownDeposits*2?'high':'medium',reason:`${bad} failed or unknown deposit attempts were recorded within ${hours} hours. Review the payment attempts manually; no payment was rejected by this monitor.`,memberId:row.user_id,username:row.username,count:bad,firstAt:first,lastAt:last,metrics:{failedOrUnknown:bad,totalAttempts:attempts}}));
  if(attempts>=thresholds.depositAttempts)cases.push(memberCase({ruleId:'deposit_attempt_velocity',module:'bonus_abuse',severity:attempts>=thresholds.depositAttempts*2?'medium':'low',reason:`${attempts} deposit attempts were recorded within ${hours} hours. This is an activity signal for manual review only.`,memberId:row.user_id,username:row.username,count:attempts,firstAt:first,lastAt:last,metrics:{totalAttempts:attempts,failedOrUnknown:bad}}));
 }
 for(const row of fanoutRows){const count=integer(row.referral_count);cases.push(memberCase({ruleId:'referral_fanout_velocity',module:'referral_fraud',severity:count>=thresholds.referralFanout*2?'medium':'low',reason:`${count} new referral relationships were recorded within ${hours} hours. High fanout alone does not prove abuse and requires manual review.`,memberId:row.user_id,username:row.username,count,firstAt:row.first_at,lastAt:row.last_at,metrics:{newReferrals:count}}));}
 for(const row of cycleRows){const depth=integer(row.cycle_length);cases.push(memberCase({ruleId:'referral_cycle',module:'referral_fraud',severity:'medium',reason:`A referral path returned to the same member within ${depth} relationship(s). Review the referral ownership data manually.`,memberId:row.user_id,username:row.username,count:depth,firstAt:row.first_at,lastAt:row.last_at,metrics:{cycleLength:depth}}));}
 for(const row of claimVelocityRows){const count=integer(row.claim_count);cases.push(memberCase({ruleId:'benefit_claim_velocity',module:'bonus_abuse',severity:count>=thresholds.benefitClaims*2?'medium':'low',reason:`${count} benefit claim intents were recorded within ${hours} hours. Claims are preview-only and this monitor takes no wallet action.`,memberId:row.user_id,username:row.username,count,firstAt:row.first_at,lastAt:row.last_at,metrics:{claimIntents:count}}));}
 for(const row of stackRows){const count=integer(row.rule_count);cases.push(memberCase({ruleId:'benefit_same_deposit_stacking',module:'bonus_stacking',severity:count>=Math.max(3,thresholds.benefitClaimsPerDeposit+1)?'medium':'low',reason:`The same deposit was referenced by ${count} distinct benefit claim intents. Review eligibility manually; claims and wallet credit remain disabled.`,memberId:row.user_id,username:row.username,count,firstAt:row.first_at,lastAt:row.last_at,metrics:{distinctBenefitRules:count}}));}
 for(const row of rateRows){const count=integer(row.event_count);cases.push(memberCase({ruleId:'write_rate_limit_velocity',module:'account_security',severity:count>=thresholds.writeRateLimits*2?'medium':'low',reason:`${count} persisted write rate-limit events were recorded within ${hours} hours. Review the account activity manually.`,memberId:row.user_id,username:row.username,count,firstAt:row.first_at,lastAt:row.last_at,metrics:{rateLimitEvents:count}}));}
 const filtered=cases.filter(item=>!options.severity||item.severity===options.severity).sort((a,b)=>severityWeight[b.severity]-severityWeight[a.severity]||b.evidence.lastObservedAt-a.evidence.lastObservedAt||a.id.localeCompare(b.id)),items=filtered.slice(0,limit);
 return {
  reportType:'bonus_hunter_monitor_v1',
  mode:'monitor_only',
  readOnly:true,
  generatedAt,
  window:{start,end,hours},
  filters:{severity:options.severity??'all',limit},
  config,
  enforcement:{automaticAction:false,autoBan:false,autoFreeze:false,autoDeduct:false,autoReject:false,autoPayoutHold:false},
  review:{required:'manual',caseStatePersistence:'not_connected',defaultStatus:'unreviewed'},
  counts:{returned:items.length,total:filtered.length,availableBeforeLimit:filtered.length,high:filtered.filter(item=>item.severity==='high').length,medium:filtered.filter(item=>item.severity==='medium').length,low:filtered.filter(item=>item.severity==='low').length},
  cases:items,
  readiness:readiness(),
  evidenceSources:{connected:['deposit_orders','benefit_claims','referral_relationships','audit'],notConnected:['device_fingerprint','verified_ip_identity','wager_feed','game_risk_classification','provider_settlement_statement','bank_statement','chargeback_feed','refund_ledger','persisted_receipt_hash','case_review_store','real_time_event_stream']},
  coverage:{strategy:'bounded_latest_rows',exhaustive:false,maxRowsPerConnectedSource:scanLimit,referralCycleSeedLimit:cycleSeedLimit,maxReferralDepth:20,note:'The monitor scans a bounded set of the latest connected records in the selected window. No result means no matching signal was found in that bounded scan; it is not proof that risk is absent.'},
  notice:'Signals are explainable review prompts only. The monitor never bans accounts, freezes funds, deducts balances, rejects payments, blocks withdrawals, or changes rewards.'
 };
}
