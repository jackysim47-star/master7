import {createHash,randomUUID} from 'node:crypto';
import type {GameProviderAdapter,GameProviderProfile,GameProviderContext,GameProviderTransferResult} from './game-provider-adapter.ts';
import {walletGuardStatements,walletGuardedReservation,walletRiskFreeSql} from './wallet-guard.ts';
import {withdrawalWalletState,clearStaleReservation} from './withdrawals.ts';

export type ProviderTransferContext={db:D1Database;user:{id:string;username:string;role:string;approved:number};profile:GameProviderProfile;adapter:GameProviderAdapter;newGameLaunchesEnabled?:string;launchAuthorized:boolean;manualComplianceEnforced?:boolean};
export class ProviderTransferError extends Error{readonly status:number;readonly code:string;constructor(status:number,code:string){super(code==='GAMES_MAINTENANCE'?'New game launches are temporarily unavailable':code.includes('UNKNOWN')?'Game funds are reserved. Check game wallet recovery.':code==='GAME_PROVIDER_STILL_OPEN'?'The provider has not confirmed game closure.':'Game wallet verification is required before continuing');this.name='ProviderTransferError';this.status=status;this.code=code;}}
const fail=(status:number,code:string):never=>{throw new ProviderTransferError(status,code);};
const stamp=()=>Math.floor(Date.now()/1000),hash=(value:string)=>createHash('sha256').update(value).digest('hex');
const open="'deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review'";
const changed=(result:any)=>Number(result?.meta?.changes??result?.changes??0);
const recordId=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_.:-]{1,200}$/.test(value);
const amount=(value:unknown)=>typeof value==='string'&&/^(0|[1-9]\d{0,10})$/.test(value)&&BigInt(value)<=99_999_999_900n;
const apiContext=(c:ProviderTransferContext):GameProviderContext=>({profile:c.profile});
function currentGameEligibilitySql(c:ProviderTransferContext){
 const at=stamp();return `EXISTS(SELECT 1 FROM users member WHERE member.id=provider_wallet_operations.user_id AND member.role='member' AND member.approved=1)
 AND NOT EXISTS(SELECT 1 FROM responsible_play_profiles rp WHERE rp.user_id=provider_wallet_operations.user_id AND (rp.self_excluded_until>${at} OR rp.cooling_off_until>${at}))
 ${c.manualComplianceEnforced===true?"AND EXISTS(SELECT 1 FROM manual_compliance_reviews review WHERE review.user_id=provider_wallet_operations.user_id AND review.identity_status='passed' AND review.aml_status='passed')":''}`;
}

function context(c:ProviderTransferContext){
 const p=c.profile;
 if(c.user.role!=='member'||!recordId(c.user.id))return fail(403,'GAME_MEMBER_REQUIRED');
 if(!p||p.providerId==='megah5'||p.walletMode!=='transfer'||p.currency!=='MYR'||p.unitScale!==1||p.playerNamespace!==p.profileId||p.ledgerNamespace!==p.profileId||!c.adapter?.executable||!c.adapter.closeGame)return fail(503,'GAME_TRANSFER_PROFILE_UNAVAILABLE');
}
async function profileRow(c:ProviderTransferContext,launch=false){
 context(c);const p=await c.db.prepare('SELECT * FROM game_provider_profiles WHERE id=?').bind(c.profile.profileId).first<any>();
 if(!p||p.provider_id!==c.profile.providerId||p.adapter_key!==c.profile.adapterKey||p.wallet_mode!=='transfer'||p.balance_class!=='cash'||p.currency!=='MYR'||String(p.unit_numerator)!==String(p.unit_denominator))return fail(409,'GAME_PROFILE_RECONCILIATION_REQUIRED');
 if(launch&&!['uat','active'].includes(p.status))return fail(503,'GAME_PROFILE_CLOSED');
 return p;
}
const rowSelect=`SELECT s.*,o.user_id operation_user_id,o.profile_id operation_profile_id,o.request_key,o.request_fingerprint,o.deposit_state,o.deposit_attempts,o.deposit_provider_reference,o.withdrawal_state,o.withdrawal_attempts,o.withdrawal_provider_reference,o.launch_state,o.closure_state,o.closure_evidence,o.zero_balance_verified,o.last_error_code,CAST(l.amount_minor AS TEXT) result_minor FROM game_wallet_sessions s LEFT JOIN provider_wallet_operations o ON o.session_id=s.id LEFT JOIN game_wallet_ledger l ON l.session_id=s.id`;
async function row(c:Pick<ProviderTransferContext,'db'|'profile'>&{user:{id:string}},id?:string){
 const found=await c.db.prepare(`${rowSelect} WHERE s.user_id=? AND s.profile_id=? ${id?'AND s.id=?':''} ORDER BY CASE WHEN s.status IN (${open}) THEN 0 ELSE 1 END,s.created_at DESC,s.id DESC LIMIT 1`).bind(c.user.id,c.profile.profileId,...(id?[id]:[])).first<any>();
 if(found&&(found.provider!==c.profile.providerId||found.operation_user_id!==c.user.id||found.operation_profile_id!==c.profile.profileId))return fail(409,'GAME_SESSION_BINDING_REVIEW');
 return found;
}
function memberSession(s:any){return s?{id:s.id,profileId:s.profile_id,providerId:s.provider,gameCode:s.game_code,status:s.status,amountOutMinor:String(s.amount_out_minor),amountReturnedMinor:s.amount_returned_minor===null?null:String(s.amount_returned_minor),expectedReturnMinor:s.expected_return_minor===null?null:String(s.expected_return_minor),resultMinor:s.result_minor===null?null:String(s.result_minor),launchState:s.launch_state,settlementBlocked:['launching','unknown'].includes(s.launch_state)||s.status==='manual_review',createdAt:Number(s.created_at),updatedAt:Number(s.updated_at),settledAt:s.settled_at===null?null:Number(s.settled_at)}:null;}
async function boundSession(c:ProviderTransferContext,id:string){
 await profileRow(c);if(!recordId(id))return fail(400,'GAME_SESSION_INVALID');const s=await row(c,id);if(!s)return fail(404,'GAME_SESSION_NOT_FOUND');
 const player=await c.db.prepare("SELECT provider_player_id,status FROM game_provider_players WHERE profile_id=? AND user_id=?").bind(c.profile.profileId,c.user.id).first<any>();
 if(!player||player.status!=='verified'||player.provider_player_id!==s.player_id)return fail(409,'GAME_PLAYER_BINDING_REVIEW');return s;
}
async function write(c:ProviderTransferContext,statements:D1PreparedStatement[]){return c.db.batch([...walletGuardStatements(c.db,c.user.id),...statements]);}
function audit(c:ProviderTransferContext,event:string,id:string){return c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(randomUUID(),c.user.id,event,id,stamp());}
async function balance(c:ProviderTransferContext,s:any){
 let b;try{b=await c.adapter.queryBalance(apiContext(c),{userId:c.user.id,providerPlayerId:s.player_id});}catch{return fail(503,'GAME_BALANCE_QUERY_UNAVAILABLE');}
 if(b.currency!=='MYR'||!amount(b.amountMinor)||b.residual){
  await write(c,[c.db.prepare("UPDATE game_wallet_sessions SET status='manual_review',last_error='provider_balance_review',updated_at=? WHERE id=? AND user_id=? AND status NOT IN ('settled','deposit_failed')").bind(stamp(),s.id,c.user.id),audit(c,'provider_wallet_balance_review',s.id)]);return fail(409,'GAME_BALANCE_RECONCILIATION_REQUIRED');
 }return b.amountMinor;
}
function transferInput(c:ProviderTransferContext,s:any,direction:'deposit'|'withdrawal'){
 const a=String(direction==='deposit'?s.amount_out_minor:s.expected_return_minor),reference=direction==='deposit'?s.deposit_reference:s.withdraw_reference;
 if(!amount(a)||a==='0'||!recordId(reference))return fail(409,'GAME_TRANSFER_BINDING_REVIEW');
 return {userId:c.user.id,providerPlayerId:s.player_id,platformTransactionId:reference,amountMinor:a,currency:'MYR' as const};
}
async function transferOutcome(c:ProviderTransferContext,s:any,direction:'deposit'|'withdrawal',outcome:GameProviderTransferResult,queried=false){
 const deposit=direction==='deposit',field=deposit?'deposit':'withdrawal',pending=deposit?'deposit_pending':'withdraw_pending',unknown=deposit?'deposit_unknown':'withdraw_unknown';
 const confirmed=outcome?.state==='confirmed'&&recordId(outcome.providerTransactionId);
 if(confirmed){
  await write(c,[c.db.prepare(`UPDATE provider_wallet_operations SET ${field}_state='confirmed',${field}_provider_reference=?,last_error_code='',updated_at=? WHERE session_id=? AND user_id=? AND ${field}_attempts=1 AND ${field}_state IN ('submitting','unknown','confirmed') AND (${field}_provider_reference IS NULL OR ${field}_provider_reference=?)`).bind(outcome.providerTransactionId!,stamp(),s.id,c.user.id,outcome.providerTransactionId!),
   ...(deposit?[c.db.prepare("UPDATE game_wallet_sessions SET status='active',last_error='',updated_at=? WHERE id=? AND user_id=? AND status IN ('deposit_pending','deposit_unknown') AND EXISTS(SELECT 1 FROM provider_wallet_operations o WHERE o.session_id=game_wallet_sessions.id AND o.deposit_state='confirmed' AND o.deposit_provider_reference=?)").bind(stamp(),s.id,c.user.id,outcome.providerTransactionId!)]:[]),audit(c,`provider_wallet_${field}_receipt`,s.id)]);
 }else if(deposit&&!queried&&outcome?.state==='rejected'){
  // Only a definitive submission rejection can release a new reservation.
  // A query saying not found/rejected cannot prove a timed-out submit failed.
  await write(c,[c.db.prepare("UPDATE provider_wallet_operations SET deposit_state='rejected',last_error_code='deposit_rejected',updated_at=? WHERE session_id=? AND user_id=? AND deposit_state='submitting' AND deposit_attempts=1").bind(stamp(),s.id,c.user.id),
   c.db.prepare("UPDATE game_wallet_sessions SET status='deposit_failed',last_error='deposit_rejected',updated_at=? WHERE id=? AND user_id=? AND status='deposit_pending' AND EXISTS(SELECT 1 FROM provider_wallet_operations o WHERE o.session_id=game_wallet_sessions.id AND o.deposit_state='rejected')").bind(stamp(),s.id,c.user.id),
   c.db.prepare("DELETE FROM wallet_reservations WHERE user_id=? AND kind='game' AND reference_id=? AND EXISTS(SELECT 1 FROM game_wallet_sessions s WHERE s.id=? AND s.user_id=wallet_reservations.user_id AND s.status='deposit_failed')").bind(c.user.id,s.id,s.id),audit(c,'provider_wallet_deposit_rejected',s.id)]);
 }else{
  await write(c,[c.db.prepare(`UPDATE provider_wallet_operations SET ${field}_state='unknown',last_error_code='transfer_unknown',updated_at=? WHERE session_id=? AND user_id=? AND ${field}_state IN ('submitting','unknown') AND ${field}_attempts=1`).bind(stamp(),s.id,c.user.id),
   c.db.prepare(`UPDATE game_wallet_sessions SET status=?,last_error='transfer_unknown',updated_at=? WHERE id=? AND user_id=? AND status IN (?,?) AND EXISTS(SELECT 1 FROM provider_wallet_operations o WHERE o.session_id=game_wallet_sessions.id AND o.${field}_state='unknown')`).bind(unknown,stamp(),s.id,c.user.id,pending,unknown),audit(c,`provider_wallet_${field}_unknown`,s.id)]);
 }
 return (await row(c,s.id))!;
}

export async function readMemberTransferWallet(db:D1Database,userId:string,profile:GameProviderProfile,recoveryReady=false){
 const s=await row({db,user:{id:userId},profile});return {profileId:profile.profileId,providerId:profile.providerId,provider:profile.providerId,currency:'MYR',walletMode:'transfer',session:memberSession(s),wallet:await withdrawalWalletState(db,userId),supportsSettlement:recoveryReady,supportsRecovery:recoveryReady,launchVerified:false,walletVerified:false,settlementVerified:false,launchReady:false,walletReady:recoveryReady,liveReady:false,capabilityReason:recoveryReady?'production_acceptance_pending':'transfer_connection_unavailable'};
}
export async function memberTransferWallet(c:ProviderTransferContext){await profileRow(c);return readMemberTransferWallet(c.db,c.user.id,c.profile,true);}

export async function adminTransferWalletRecords(db:D1Database){
 const select=rowSelect.replace('s.*,','s.*,u.username,p.display_name,CAST(r.amount_minor AS TEXT) reserved_minor,');
 const result=await db.prepare(`${select} LEFT JOIN users u ON u.id=s.user_id LEFT JOIN game_provider_profiles p ON p.id=s.profile_id LEFT JOIN wallet_reservations r ON r.user_id=s.user_id AND r.kind='game' AND r.reference_id=s.id WHERE s.provider<>'megah5' ORDER BY s.updated_at DESC,s.id DESC LIMIT 500`).all<any>();
 return (result.results??[]).map(s=>{const withdrawal=s.withdrawal_state!=='none';return {...memberSession(s),userId:s.user_id,username:s.username??'',displayName:s.display_name??s.profile_id,reservedMinor:s.reserved_minor===null?null:String(s.reserved_minor),lastTransfer:{id:withdrawal?s.withdraw_reference:s.deposit_reference,direction:withdrawal?'withdrawal':'deposit',status:withdrawal?s.withdrawal_state:s.deposit_state,amountMinor:String(withdrawal?s.expected_return_minor??'0':s.amount_out_minor),currency:'MYR',providerReference:withdrawal?s.withdrawal_provider_reference:s.deposit_provider_reference}};});
}

export async function launchTransferWallet(c:ProviderTransferContext,input:{gameCode:string;requestKey:string;language:'en'|'zh'|'ms';ip:string;returnUrl:string}){
 context(c);if(c.newGameLaunchesEnabled!=='true')return fail(503,'GAMES_MAINTENANCE');
 if(c.launchAuthorized!==true||c.user.approved!==1)return fail(503,'GAME_ACCEPTANCE_REQUIRED');await profileRow(c,true);
 if(!recordId(input.requestKey)||!recordId(input.gameCode)||!['en','zh','ms'].includes(input.language))return fail(400,'GAME_LAUNCH_INPUT_INVALID');
 const fingerprint=hash(JSON.stringify([c.profile.profileId,c.user.id,input.gameCode,input.language,input.returnUrl]));
 const old=await c.db.prepare('SELECT session_id,user_id,request_fingerprint FROM provider_wallet_operations WHERE profile_id=? AND request_key=?').bind(c.profile.profileId,input.requestKey).first<any>();
 if(old){if(old.user_id!==c.user.id||old.request_fingerprint!==fingerprint)return fail(409,'GAME_REQUEST_KEY_CONFLICT');return fail(409,'GAME_REQUEST_ALREADY_CLAIMED');}
 const games=await c.adapter.listGames(apiContext(c)),game=games.find(g=>g.providerGameId===input.gameCode&&!g.maintenance);if(!game)return fail(409,'GAME_UNAVAILABLE');
 await clearStaleReservation(c.db,c.user.id);
 const wallet=await withdrawalWalletState(c.db,c.user.id);if(wallet.reconciliationRequired||!amount(wallet.availableMinor)||wallet.availableMinor==='0')return fail(409,'GAME_WALLET_UNAVAILABLE');
 const verified=await c.adapter.createOrVerifyPlayer(apiContext(c),{userId:c.user.id,username:c.user.username});if(!recordId(verified.providerPlayerId))return fail(502,'GAME_PLAYER_INVALID');
 const player=await c.db.prepare('SELECT * FROM game_provider_players WHERE profile_id=? AND user_id=?').bind(c.profile.profileId,c.user.id).first<any>();
 if(player&&(player.provider_player_id!==verified.providerPlayerId||player.status!=='verified'))return fail(409,'GAME_PLAYER_BINDING_REVIEW');
 await write(c,[c.db.prepare("INSERT INTO game_provider_players(profile_id,user_id,provider_player_id,status,created_at,updated_at,verified_at) VALUES(?,?,?,'verified',?,?,?) ON CONFLICT(profile_id,user_id) DO NOTHING").bind(c.profile.profileId,c.user.id,verified.providerPlayerId,stamp(),stamp(),stamp())]);
 const fresh=await c.db.prepare("SELECT provider_player_id,status FROM game_provider_players WHERE profile_id=? AND user_id=?").bind(c.profile.profileId,c.user.id).first<any>();if(fresh?.provider_player_id!==verified.providerPlayerId||fresh?.status!=='verified')return fail(409,'GAME_PLAYER_BINDING_REVIEW');
 const pre=await c.adapter.queryBalance(apiContext(c),{userId:c.user.id,providerPlayerId:verified.providerPlayerId});
 if(pre.currency!=='MYR'||pre.residual||pre.amountMinor!=='0')return fail(409,'GAME_PROVIDER_BALANCE_REVIEW');
 const closed=await c.adapter.closeGame!(apiContext(c),{userId:c.user.id,providerPlayerId:verified.providerPlayerId,requestClosure:false});if(closed.state!=='closed')return fail(409,'GAME_PROVIDER_SESSION_REVIEW');
 const id=randomUUID(),depositReference=`m7d_${randomUUID()}`,created=stamp();
 try{
  const results=await write(c,[walletGuardedReservation(c.db,{userId:c.user.id,kind:'game',referenceId:id,amountMinor:wallet.availableMinor,createdAt:created}),
   c.db.prepare("INSERT INTO game_wallet_sessions(id,user_id,provider,profile_id,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) SELECT ?,?,?,?,?,?,'deposit_pending',?,?,?,? WHERE EXISTS(SELECT 1 FROM wallet_reservations r WHERE r.user_id=? AND r.kind='game' AND r.reference_id=? AND r.amount_minor=CAST(? AS BIGINT))").bind(id,c.user.id,c.profile.providerId,c.profile.profileId,verified.providerPlayerId,input.gameCode,wallet.availableMinor,depositReference,created,created,c.user.id,id,wallet.availableMinor),
   c.db.prepare("INSERT INTO provider_wallet_operations(session_id,profile_id,user_id,request_key,request_fingerprint,deposit_state,created_at,updated_at) SELECT ?,?,?,?,?,'prepared',?,? WHERE EXISTS(SELECT 1 FROM game_wallet_sessions s WHERE s.id=? AND s.user_id=? AND s.profile_id=?)").bind(id,c.profile.profileId,c.user.id,input.requestKey,fingerprint,created,created,id,c.user.id,c.profile.profileId),audit(c,'provider_wallet_reserved',id)]);
  if(changed(results[2])!==1||changed(results[3])!==1||changed(results[4])!==1)return fail(409,'GAME_WALLET_ALREADY_RESERVED');
 }catch(error){if(error instanceof ProviderTransferError)throw error;return fail(409,'GAME_REQUEST_CONCURRENT_REVIEW');}
 let s=(await row(c,id))!;
 const claim=await write(c,[c.db.prepare(`UPDATE provider_wallet_operations SET deposit_state='submitting',deposit_attempts=1,updated_at=? WHERE session_id=? AND user_id=? AND deposit_state='prepared' AND deposit_attempts=0 AND ${currentGameEligibilitySql(c)}`).bind(stamp(),id,c.user.id)]);
 if(changed(claim[2])!==1){const unsubmitted=await row(c,id);if(unsubmitted?.deposit_state==='prepared'&&Number(unsubmitted.deposit_attempts)===0)await recoverTransferWallet(c,id);return fail(403,'GAME_ACCESS_CHANGED');}
 let outcome:GameProviderTransferResult;try{outcome=await c.adapter.depositToGame(apiContext(c),transferInput(c,s,'deposit'));}catch{outcome={state:'unknown'};}
 s=await transferOutcome(c,s,'deposit',outcome);if(s.status!=='active')return fail(s.status==='deposit_failed'?502:503,s.status==='deposit_failed'?'GAME_DEPOSIT_REJECTED':'GAME_DEPOSIT_UNKNOWN');
 const launch=await write(c,[c.db.prepare(`UPDATE provider_wallet_operations SET launch_state='launching',updated_at=? WHERE session_id=? AND user_id=? AND deposit_state='confirmed' AND launch_state='prepared' AND closure_state='unknown' AND EXISTS(SELECT 1 FROM game_wallet_sessions s WHERE s.id=provider_wallet_operations.session_id AND s.status='active') AND ${currentGameEligibilitySql(c)}`).bind(stamp(),id,c.user.id)]);
 if(changed(launch[2])!==1){const notLaunched=await row(c,id);if(notLaunched?.status==='active'&&notLaunched.launch_state==='prepared'){try{await settleTransferWallet(c,id);}catch{/* Keep any unconfirmed return reserved for the existing recovery route. */}}return fail(403,'GAME_ACCESS_CHANGED');}
 try{
  const result=await c.adapter.launchGame(apiContext(c),{userId:c.user.id,providerPlayerId:s.player_id,providerGameId:input.gameCode,language:input.language,ip:input.ip,returnUrl:input.returnUrl});
  const url=new URL(result.launchUrl);if(url.protocol!=='https:'||url.username||url.password||url.hash)return fail(502,'GAME_LAUNCH_URL_INVALID');
  const issued=await write(c,[c.db.prepare("UPDATE provider_wallet_operations SET launch_state='issued',updated_at=? WHERE session_id=? AND user_id=? AND launch_state='launching'").bind(stamp(),id,c.user.id),audit(c,'provider_game_launch_issued',id)]);
  if(changed(issued[2])!==1)return fail(409,'GAME_LAUNCH_RESULT_REVIEW');return {profileId:c.profile.profileId,providerId:c.profile.providerId,walletSessionId:id,launchUrl:url.href};
 }catch{
  await write(c,[c.db.prepare("UPDATE provider_wallet_operations SET launch_state='unknown',last_error_code='launch_unknown',updated_at=? WHERE session_id=? AND user_id=? AND launch_state='launching'").bind(stamp(),id,c.user.id),audit(c,'provider_game_launch_unknown',id)]);return fail(503,'GAME_LAUNCH_UNKNOWN');
 }
}

async function finalize(c:ProviderTransferContext,s:any){
 const returned=String(s.expected_return_minor);if(!amount(returned))return fail(409,'GAME_RETURN_AMOUNT_REVIEW');
 const residual=await balance(c,s);if(residual!=='0')return fail(409,'GAME_RETURN_NOT_ZERO');
 const updated=stamp(),result=(BigInt(returned)-BigInt(s.amount_out_minor)).toString();
 await write(c,[c.db.prepare("UPDATE provider_wallet_operations SET zero_balance_verified=1,updated_at=? WHERE session_id=? AND user_id=? AND deposit_state='confirmed' AND withdrawal_state='confirmed' AND closure_state='confirmed' AND launch_state='closed'").bind(updated,s.id,c.user.id),
  c.db.prepare(`UPDATE game_wallet_sessions SET status='settled',amount_returned_minor=expected_return_minor,settled_at=?,updated_at=?,last_error='' WHERE id=? AND user_id=? AND profile_id=? AND status IN ('withdraw_pending','withdraw_unknown') AND expected_return_minor=CAST(? AS BIGINT) AND EXISTS(SELECT 1 FROM provider_wallet_operations o WHERE o.session_id=game_wallet_sessions.id AND o.user_id=game_wallet_sessions.user_id AND o.profile_id=game_wallet_sessions.profile_id AND o.deposit_state='confirmed' AND o.withdrawal_state='confirmed' AND o.closure_state='confirmed' AND LENGTH(o.closure_evidence)=64 AND o.launch_state='closed' AND o.zero_balance_verified=1) AND EXISTS(SELECT 1 FROM (SELECT ? AS id) m WHERE ${walletRiskFreeSql})`).bind(updated,updated,s.id,c.user.id,c.profile.profileId,returned,c.user.id),
  c.db.prepare("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,s.id,s.user_id,'game_result',s.amount_returned_minor-s.amount_out_minor,'MYR',? FROM game_wallet_sessions s WHERE s.id=? AND s.user_id=? AND s.profile_id=? AND s.status='settled' AND s.amount_returned_minor=CAST(? AS BIGINT) ON CONFLICT(session_id) DO NOTHING").bind(randomUUID(),updated,s.id,c.user.id,c.profile.profileId,returned),
  c.db.prepare("DELETE FROM wallet_reservations WHERE user_id=? AND kind='game' AND reference_id=? AND EXISTS(SELECT 1 FROM game_wallet_sessions s JOIN game_wallet_ledger l ON l.session_id=s.id AND l.user_id=s.user_id WHERE s.id=? AND s.user_id=wallet_reservations.user_id AND s.profile_id=? AND s.status='settled' AND s.amount_returned_minor=CAST(? AS BIGINT) AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=CAST(? AS BIGINT))").bind(c.user.id,s.id,s.id,c.profile.profileId,returned,result),audit(c,'provider_wallet_settlement_recorded',s.id)]);
 const done=await row(c,s.id);if(done?.status!=='settled'||String(done.result_minor)!==result)return fail(409,'GAME_SETTLEMENT_RECONCILIATION_REQUIRED');return {status:'settled',session:memberSession(done)};
}

export async function settleTransferWallet(c:ProviderTransferContext,id:string){
 let s=await boundSession(c,id);if(s.status==='settled')return {status:'settled',session:memberSession(s)};
 if(s.status!=='active'||s.deposit_state!=='confirmed')return fail(409,'GAME_RECOVERY_REQUIRED');
 // An unconfirmed launch can still be accepted after a timeout. A point-in-time
 // offline check cannot establish that its unknown token has been invalidated.
 if(!['prepared','issued'].includes(s.launch_state))return fail(409,'GAME_LAUNCH_CLOSURE_REVIEW');
 const closed=await c.adapter.closeGame!(apiContext(c),{userId:c.user.id,providerPlayerId:s.player_id,requestClosure:true});
 if(closed.state!=='closed'||!recordId(closed.evidenceCode))return fail(409,'GAME_PROVIDER_STILL_OPEN');
 const returned=await balance(c,s),withdrawReference=returned==='0'?null:`m7w_${randomUUID()}`,proof=hash(JSON.stringify([c.profile.profileId,c.user.id,s.id,closed.evidenceCode]));
 const claim=await write(c,[c.db.prepare("UPDATE provider_wallet_operations SET closure_state='confirmed',closure_evidence=?,launch_state='closed',withdrawal_state=?,updated_at=? WHERE session_id=? AND user_id=? AND deposit_state='confirmed' AND withdrawal_state='none' AND launch_state IN ('prepared','issued')").bind(proof,returned==='0'?'confirmed':'prepared',stamp(),s.id,c.user.id),
  c.db.prepare("UPDATE game_wallet_sessions SET status='withdraw_pending',withdraw_reference=?,expected_return_minor=?,updated_at=? WHERE id=? AND user_id=? AND status='active' AND EXISTS(SELECT 1 FROM provider_wallet_operations o WHERE o.session_id=game_wallet_sessions.id AND o.closure_state='confirmed' AND o.launch_state='closed' AND o.withdrawal_state IN ('prepared','confirmed'))").bind(withdrawReference,returned,stamp(),s.id,c.user.id)]);
 if(changed(claim[2])!==1||changed(claim[3])!==1)return fail(409,'GAME_SETTLEMENT_ALREADY_CLAIMED');
 s=(await row(c,id))!;if(returned==='0')return finalize(c,s);
 return submitReturn(c,s);
}

async function submitReturn(c:ProviderTransferContext,s:any){
 const submit=await write(c,[c.db.prepare("UPDATE provider_wallet_operations SET withdrawal_state='submitting',withdrawal_attempts=1,updated_at=? WHERE session_id=? AND user_id=? AND withdrawal_state='prepared' AND withdrawal_attempts=0 AND closure_state='confirmed'").bind(stamp(),s.id,c.user.id)]);
 if(changed(submit[2])!==1)return fail(409,'GAME_RETURN_ALREADY_CLAIMED');
 let outcome:GameProviderTransferResult;try{outcome=await c.adapter.withdrawFromGame(apiContext(c),transferInput(c,s,'withdrawal'));}catch{outcome={state:'unknown'};}
 s=await transferOutcome(c,s,'withdrawal',outcome);if(s.withdrawal_state!=='confirmed')return fail(503,'GAME_WITHDRAWAL_UNKNOWN');return finalize(c,s);
}

export async function recoverTransferWallet(c:ProviderTransferContext,id:string){
 let s=await boundSession(c,id);if(s.status==='settled'||s.status==='deposit_failed')return {status:s.status,session:memberSession(s)};
 const direction=['deposit_pending','deposit_unknown'].includes(s.status)?'deposit':['withdraw_pending','withdraw_unknown'].includes(s.status)?'withdrawal':null;
 if(!direction)return {status:s.status,session:memberSession(s)};
 const field=direction==='deposit'?'deposit':'withdrawal';
 if(direction==='deposit'&&s.deposit_state==='prepared'&&Number(s.deposit_attempts)===0){
  await write(c,[c.db.prepare("UPDATE provider_wallet_operations SET deposit_state='rejected',last_error_code='cancelled_before_submit',updated_at=? WHERE session_id=? AND user_id=? AND deposit_state='prepared' AND deposit_attempts=0").bind(stamp(),s.id,c.user.id),
   c.db.prepare("UPDATE game_wallet_sessions SET status='deposit_failed',last_error='cancelled_before_submit',updated_at=? WHERE id=? AND user_id=? AND status='deposit_pending' AND EXISTS(SELECT 1 FROM provider_wallet_operations o WHERE o.session_id=game_wallet_sessions.id AND o.deposit_state='rejected' AND o.deposit_attempts=0)").bind(stamp(),s.id,c.user.id),
   c.db.prepare("DELETE FROM wallet_reservations WHERE user_id=? AND kind='game' AND reference_id=? AND EXISTS(SELECT 1 FROM game_wallet_sessions s WHERE s.id=? AND s.user_id=wallet_reservations.user_id AND s.status='deposit_failed')").bind(c.user.id,s.id,s.id),audit(c,'provider_wallet_cancelled_before_submit',s.id)]);
  s=(await row(c,id))!;return {status:s.status,session:memberSession(s)};
 }
 if(direction==='withdrawal'&&s.closure_state==='confirmed'&&s.launch_state==='closed'&&Number(s.withdrawal_attempts)===0){
  if(s.withdrawal_state==='confirmed'&&String(s.expected_return_minor)==='0')return finalize(c,s);
  if(s.withdrawal_state==='prepared'&&BigInt(s.expected_return_minor)>0n)return submitReturn(c,s);
 }

 // Claimed/unknown transfers are queried only with their original bindings;
 // never infer their success from a supplier balance alone.
 if(Number(s[`${field}_attempts`])!==1)return fail(409,'GAME_TRANSFER_NOT_SUBMITTED_REVIEW');
 let outcome:GameProviderTransferResult;
 try{outcome=await c.adapter.queryTransfer(apiContext(c),{...transferInput(c,s,direction),direction,...(s[`${field}_provider_reference`]?{providerTransactionId:s[`${field}_provider_reference`]}:{})});}catch{outcome={state:'unknown'};}
 s=await transferOutcome(c,s,direction,outcome,true);
 if(direction==='withdrawal'&&s.withdrawal_state==='confirmed')return finalize(c,s);
 return {status:s.status,session:memberSession(s)};
}
