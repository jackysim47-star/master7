import {createHash} from 'node:crypto';

// Canonical input only. Supplier-specific exports must be mapped by a separately
// verified mapper. This module has no database, network or money-command handle.
export type ReconciliationDomain='payment'|'bank'|'game_provider';
export type ReconciliationRecord={
 id:string;domain:ReconciliationDomain;provider:string;account:string;reference:string;
 amountMinor:string;currency:string;status:'succeeded'|'failed'|'pending';
 direction:'credit'|'debit'|'deposit'|'withdrawal'|'result';
 balanceClass:'cash'|'free_credit';occurredAt:string;evidenceReference:string;
 transactionId?:string;memberId?:string;profileId?:string;playerId?:string;
 unitNumerator?:string;unitDenominator?:string;
 ledger?:{memberMinor:string;clearingMinor:string;memberEntries?:number;clearingEntries?:number;memberId?:string};
 result?:{outMinor:string;returnedMinor:string;closureEvidenceReference:string};
};
export type ReconciliationCoverage={
 domain:ReconciliationDomain;provider:string;account:string;profileId?:string;
 balanceClass:'cash'|'free_credit';complete:boolean;evidenceReference:string;
};
export type ReconciliationInput={
 schemaVersion:'master7-reconciliation-v1';mappingVersion:string;ruleVersion:string;
 sourceCommit:string;internalSnapshotId:string;
 period:{startUtc:string;endUtcExclusive:string};
 internalRecords:ReconciliationRecord[];externalRecords:ReconciliationRecord[];
 coverage:ReconciliationCoverage[];
};
export type DiscrepancyKind='missing_internal'|'missing_external'|'duplicate'
 |'binding_mismatch'|'amount_mismatch'|'currency_mismatch'|'status_mismatch'
 |'ledger_mismatch'|'unverifiable'|'outstanding'|'coverage_incomplete';
export type ReconciliationDiscrepancy={
 domain:ReconciliationDomain;scope:string;classification:DiscrepancyKind;
 internalReferences:string[];externalReferences:string[];
 amountDifferenceMinor:string|null;reasonCode:string;
 evidenceReferences:string[];reviewStatus:'pending';
};
const domains:ReconciliationDomain[]=['payment','bank','game_provider'];
const kinds=['credit','debit','deposit','withdrawal','result'];
const maxRecords=10_000,maxMinor=9_223_372_036_854_775_807n;
const text=(v:unknown,max=200):v is string=>typeof v==='string'&&v.length>0&&v.length<=max&&!/[\u0000-\u001f\u007f]/u.test(v);
const evidence=(v:unknown):v is string=>text(v)&&/^[A-Za-z0-9_.:/-]+$/.test(v);
const minor=(v:unknown,signed=false):v is string=>typeof v==='string'&&(signed?/^(0|-?[1-9]\d{0,18})$/:/^(0|[1-9]\d{0,18})$/).test(v)&&BigInt(v)>=-maxMinor&&BigInt(v)<=maxMinor;
const utc=(v:unknown)=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString()===v.replace(/Z$/,v.includes('.')?'Z':'.000Z');
const hash=(v:string)=>createHash('sha256').update(v).digest('hex');
function object(v:unknown):v is Record<string,unknown>{return v!==null&&typeof v==='object'&&!Array.isArray(v);}
function invalid(reason:string):never{throw new Error('RECONCILIATION_INPUT_INVALID: '+reason);}
function onlyKeys(v:Record<string,unknown>,keys:string[]){if(Object.keys(v).some(k=>!keys.includes(k)))invalid('unknown fields');}
function stable(value:unknown):string{
 if(Array.isArray(value))return '['+value.map(stable).join(',')+']';
 if(object(value))return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+stable(value[k])).join(',')+'}';
 return JSON.stringify(value);
}
function validateRecord(v:unknown):asserts v is ReconciliationRecord{
 if(!object(v)||!domains.includes(v.domain as ReconciliationDomain)||!text(v.id)||!text(v.provider)||!text(v.account)||!text(v.reference)||!evidence(v.evidenceReference)||!utc(v.occurredAt))invalid('record identity or evidence');
 onlyKeys(v,['id','domain','provider','account','reference','amountMinor','currency','status','direction','balanceClass','occurredAt','evidenceReference','transactionId','memberId','profileId','playerId','unitNumerator','unitDenominator','ledger','result']);
 if(!['cash','free_credit'].includes(String(v.balanceClass))||!kinds.includes(String(v.direction))||!['succeeded','failed','pending'].includes(String(v.status))||typeof v.currency!=='string'||!/^[A-Z]{3,8}$/.test(v.currency)||!minor(v.amountMinor,v.direction==='result'))invalid('record amount or status');
 for(const k of ['transactionId','memberId','profileId','playerId'])if(v[k]!==undefined&&!text(v[k]))invalid('record binding');
 if(v.domain==='payment'&&(!['vpay','gspay','1mpay'].includes(String(v.provider))||v.balanceClass!=='cash'||v.direction!=='credit'))invalid('payment scope');
 if(v.domain==='bank'&&(v.balanceClass!=='cash'||!['credit','debit'].includes(String(v.direction))))invalid('bank scope');
 if(v.domain==='game_provider'&&(!text(v.profileId)||!text(v.playerId)||!text(v.transactionId)||!minor(v.unitNumerator)||v.unitNumerator==='0'||!minor(v.unitDenominator)||v.unitDenominator==='0'||!['deposit','withdrawal','result'].includes(String(v.direction))))invalid('game binding or units');
 if(v.ledger!==undefined&&(!object(v.ledger)||!minor(v.ledger.memberMinor,true)||!minor(v.ledger.clearingMinor,true)))invalid('ledger shape');
 if(object(v.ledger)){
  onlyKeys(v.ledger,['memberMinor','clearingMinor','memberEntries','clearingEntries','memberId']);
  for(const k of ['memberEntries','clearingEntries'])if(v.ledger[k]!==undefined&&(!Number.isSafeInteger(v.ledger[k])||Number(v.ledger[k])<0))invalid('ledger count');
  if(v.ledger.memberId!==undefined&&!text(v.ledger.memberId))invalid('ledger member');
 }
 if(v.result!==undefined&&(!object(v.result)||!minor(v.result.outMinor)||!minor(v.result.returnedMinor)||!evidence(v.result.closureEvidenceReference)))invalid('result evidence shape');
 if(object(v.result))onlyKeys(v.result,['outMinor','returnedMinor','closureEvidenceReference']);
}
export function validateReconciliationInput(v:unknown):asserts v is ReconciliationInput{
 if(!object(v)||v.schemaVersion!=='master7-reconciliation-v1'||!text(v.mappingVersion)||!text(v.ruleVersion)||!text(v.internalSnapshotId)||typeof v.sourceCommit!=='string'||!/^[a-f0-9]{40}$/.test(v.sourceCommit))invalid('manifest');
 onlyKeys(v,['schemaVersion','mappingVersion','ruleVersion','sourceCommit','internalSnapshotId','period','internalRecords','externalRecords','coverage']);
 if(!object(v.period)||!utc(v.period.startUtc)||!utc(v.period.endUtcExclusive)||Date.parse(String(v.period.endUtcExclusive))<=Date.parse(String(v.period.startUtc)))invalid('period');
 onlyKeys(v.period,['startUtc','endUtcExclusive']);
 if(!Array.isArray(v.internalRecords)||!Array.isArray(v.externalRecords)||v.internalRecords.length>maxRecords||v.externalRecords.length>maxRecords||!Array.isArray(v.coverage)||v.coverage.length>maxRecords)invalid('record limit');
 for(const record of [...v.internalRecords,...v.externalRecords])validateRecord(record);
 const seen=new Set<string>();
 for(const c of v.coverage){
  if(!object(c)||!domains.includes(c.domain as ReconciliationDomain)||!text(c.provider)||!text(c.account)||!['cash','free_credit'].includes(String(c.balanceClass))||typeof c.complete!=='boolean'||!evidence(c.evidenceReference)||(c.profileId!==undefined&&!text(c.profileId))||(c.domain==='game_provider'&&!text(c.profileId)))invalid('coverage');
  onlyKeys(c,['domain','provider','account','profileId','balanceClass','complete','evidenceReference']);
  const key=scopeKey(c as unknown as ReconciliationCoverage);
  if(seen.has(key))invalid('duplicate coverage scope');seen.add(key);
 }
}
function scopeKey(r:Pick<ReconciliationRecord,'domain'|'provider'|'account'|'profileId'|'balanceClass'>){
 return JSON.stringify([r.domain,r.provider,r.account,r.profileId??null,r.balanceClass]);
}
function matchKey(r:ReconciliationRecord){return JSON.stringify([scopeKey(r),r.reference]);}
function group(records:ReconciliationRecord[]){
 const out=new Map<string,ReconciliationRecord[]>();
 for(const r of records){const k=matchKey(r),rows=out.get(k);if(rows)rows.push(r);else out.set(k,[r]);}
 return out;
}
function reusedIdentities(records:ReconciliationRecord[]){
 const counts=new Map<string,number>();
 const identities=(r:ReconciliationRecord)=>[JSON.stringify([scopeKey(r),'row',r.id]),...(r.transactionId?[JSON.stringify([scopeKey(r),'transaction',r.transactionId])]:[])];
 for(const r of records)for(const k of identities(r))counts.set(k,(counts.get(k)??0)+1);
 return new Set(records.filter(r=>identities(r).some(k=>counts.get(k)!==1)).map(matchKey));
}
function integrity(r:ReconciliationRecord,internal:boolean){
 if(r.domain==='payment'&&r.status==='succeeded'&&!r.transactionId)return 'PAYMENT_TRANSACTION_IDENTITY_MISSING';
 if(r.domain==='payment'&&internal&&r.status==='succeeded'){
  if(!r.ledger||r.ledger.memberEntries===undefined||r.ledger.clearingEntries===undefined||!r.ledger.memberId||!r.memberId)return 'PAYMENT_LEDGER_EVIDENCE_MISSING';
  if(r.ledger.memberEntries!==1||r.ledger.clearingEntries!==1||r.ledger.memberId!==r.memberId)return 'PAYMENT_LEDGER_MISMATCH';
  if(BigInt(r.ledger.memberMinor)!==BigInt(r.amountMinor)||BigInt(r.ledger.clearingMinor)!==-BigInt(r.amountMinor))return 'PAYMENT_LEDGER_MISMATCH';
 }
 if(r.domain==='payment'&&internal&&r.status!=='succeeded'&&r.ledger&&(BigInt(r.ledger.memberMinor)!==0n||BigInt(r.ledger.clearingMinor)!==0n))return 'PAYMENT_NONFINAL_LEDGER_MISMATCH';
 if(r.domain==='game_provider'&&r.direction==='result'&&r.status==='succeeded'){
  if(!r.result)return 'GAME_CLOSURE_OR_RESULT_EVIDENCE_MISSING';
  if(BigInt(r.result.returnedMinor)-BigInt(r.result.outMinor)!==BigInt(r.amountMinor))return 'GAME_NET_RESULT_MISMATCH';
 }
 return null;
}
export function reconcileStatements(value:unknown){
 validateReconciliationInput(value);const input=value;
 const coverage=new Map(input.coverage.map(c=>[scopeKey(c),c]));
 const left=group(input.internalRecords),right=group(input.externalRecords);
 const ambiguous=new Set([...reusedIdentities(input.internalRecords),...reusedIdentities(input.externalRecords)]);
 const discrepancies:ReconciliationDiscrepancy[]=[],matches:{domain:ReconciliationDomain;scope:string;internalReference:string;externalReference:string;evidenceReferences:string[]}[]=[];
 function issue(r:ReconciliationRecord|ReconciliationCoverage,kind:DiscrepancyKind,reason:string,a:ReconciliationRecord[]=[],b:ReconciliationRecord[]=[],difference:string|null=null){
  discrepancies.push({domain:r.domain,scope:'scope:'+hash(scopeKey(r)),classification:kind,reasonCode:reason,
   internalReferences:a.map(x=>x.id).sort(),externalReferences:b.map(x=>x.id).sort(),
   amountDifferenceMinor:difference,evidenceReferences:[...new Set([...a,...b].map(x=>x.evidenceReference).concat('complete'in r?[r.evidenceReference]:[]))].sort(),reviewStatus:'pending'});
 }
 const scopes=new Map<string,ReconciliationRecord|ReconciliationCoverage>([...input.internalRecords,...input.externalRecords,...input.coverage].map(r=>[scopeKey(r),r]));
 for(const [scope,r] of [...scopes].sort(([a],[b])=>a.localeCompare(b)))if(coverage.get(scope)?.complete!==true)issue(r,'coverage_incomplete','EXTERNAL_SCOPE_COVERAGE_UNVERIFIED');
 for(const key of [...new Set([...left.keys(),...right.keys()])].sort()){
  const a=left.get(key)??[],b=right.get(key)??[],r=a[0]??b[0];
  if(a.length>1||b.length>1){issue(r,'duplicate','MATCH_KEY_NOT_UNIQUE',a,b);continue;}
  if(ambiguous.has(key)){issue(r,'duplicate','TRANSACTION_OR_SOURCE_ROW_REUSED',a,b);continue;}
  if(!a.length||!b.length){issue(r,a.length?'missing_external':'missing_internal','REFERENCE_NOT_FOUND',a,b);continue;}
  const x=a[0],y=b[0];
  if([x,y].some(z=>Date.parse(z.occurredAt)<Date.parse(input.period.startUtc)||Date.parse(z.occurredAt)>=Date.parse(input.period.endUtcExclusive))){issue(r,'outstanding','RECORD_OUTSIDE_DECLARED_PERIOD',a,b);continue;}
  const reason=integrity(x,true)??integrity(y,false);
  if(reason){issue(r,reason.endsWith('_MISMATCH')?'ledger_mismatch':'unverifiable',reason,a,b);continue;}
  const binding=['direction','balanceClass','profileId','playerId','unitNumerator','unitDenominator'] as const;
  if(binding.some(k=>x[k]!==y[k])||(x.transactionId!==undefined&&y.transactionId!==undefined&&x.transactionId!==y.transactionId)||(y.memberId!==undefined&&x.memberId!==y.memberId)){issue(r,'binding_mismatch','RECORD_BINDING_MISMATCH',a,b);continue;}
  if(x.result&&y.result&&(x.result.outMinor!==y.result.outMinor||x.result.returnedMinor!==y.result.returnedMinor)){issue(r,'binding_mismatch','GAME_RESULT_COMPONENT_MISMATCH',a,b);continue;}
  if(x.currency!==y.currency){issue(r,'currency_mismatch','CURRENCY_MISMATCH',a,b);continue;}
  if(BigInt(x.amountMinor)!==BigInt(y.amountMinor)){issue(r,'amount_mismatch','AMOUNT_MISMATCH',a,b,(BigInt(x.amountMinor)-BigInt(y.amountMinor)).toString());continue;}
  if(x.status!==y.status){issue(r,'status_mismatch','STATUS_MISMATCH',a,b);continue;}
  if(x.status==='pending'){issue(r,'outstanding','TRANSACTION_NOT_FINAL',a,b);continue;}
  matches.push({domain:r.domain,scope:'scope:'+hash(scopeKey(r)),internalReference:x.id,externalReference:y.id,evidenceReferences:[x.evidenceReference,y.evidenceReference].sort()});
 }
 // Identical snapshots/rules yield identical business output. No clock or
 // caller-provided "approved" field can turn this report into authorization.
 const canonical={...input,internalRecords:[...input.internalRecords].sort((a,b)=>stable(a).localeCompare(stable(b))),externalRecords:[...input.externalRecords].sort((a,b)=>stable(a).localeCompare(stable(b))),coverage:[...input.coverage].sort((a,b)=>scopeKey(a).localeCompare(scopeKey(b)))};
 return {schemaVersion:'master7-reconciliation-report-v1',runId:hash(stable(canonical)),
  sourceCommit:input.sourceCommit,ruleVersion:input.ruleVersion,mappingVersion:input.mappingVersion,
  internalSnapshotId:input.internalSnapshotId,period:{...input.period},
  result:scopes.size===0||discrepancies.some(d=>d.classification==='coverage_incomplete')?'incomplete':discrepancies.length?'differences_found':'matched_inputs',
  scope:'canonical_input_comparison_only',financialActions:[] as never[],ownerReview:'pending' as const,
  counts:{internal:input.internalRecords.length,external:input.externalRecords.length,matched:matches.length,discrepancies:discrepancies.length},
  matches,discrepancies};
}
