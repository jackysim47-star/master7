export const EPICWIN_PROFILE_IDS = Object.freeze([
  'epicwin_normal_myr',
  'epicwin_free_myr',
] as const);

export type EpicwinProfileId = typeof EPICWIN_PROFILE_IDS[number];
type FieldKind = 'string'|'string_list'|'nonnegative_integer'|'sha256'|'ratio';

export type EpicwinContractRequirement = Readonly<{
  field:string;
  kind:FieldKind;
  purpose:string;
  expected?:readonly string[];
}>;

const field=(name:string,kind:FieldKind,purpose:string,expected?:readonly string[]):EpicwinContractRequirement=>
  Object.freeze({field:name,kind,purpose,...(expected?{expected}:{})});

/**
 * Documentation requirements only. Values are never returned, persisted or
 * used as runtime configuration by this validator.
 */
export const EPICWIN_COMMON_VENDOR_FIELDS:readonly EpicwinContractRequirement[]=Object.freeze([
  field('document.document_id','string','Identify the authoritative supplier document.'),
  field('document.api_version','string','Bind operations to an exact API version.'),
  field('document.environment','string','Identify UAT or production scope.',['uat','production']),
  field('document.merchant_scope','string','Identify the merchant scope covered by the document.'),
  field('document.base_urls','string_list','List authoritative API bases.'),
  field('document.operation_names','string_list','List official operation names.'),
  field('document.sha256','sha256','Bind review to immutable document bytes.'),

  field('network.outbound_ip_allowlist_rule','string','Define supplier allowlisting for portal egress.'),
  field('network.callback_source_ips','string_list','List trusted callback source ranges.'),
  field('network.waf_requirements','string','Define WAF, User-Agent and transport requirements.'),

  field('authentication.scheme','string','Define the authentication scheme.'),
  field('authentication.credential_fields','string_list','Name credential fields without their values.'),
  field('authentication.signature_algorithm','string','Define signature or MAC algorithm.'),
  field('authentication.canonical_request_rule','string','Define ordering, encoding and canonicalization.'),
  field('authentication.signed_fields','string_list','List fields covered by the signature.'),
  field('authentication.timestamp_rule','string','Define timestamp format and accepted skew.'),
  field('authentication.nonce_or_replay_rule','string','Define replay protection.'),
  field('authentication.test_vectors','string_list','Provide non-secret official signing vectors.'),

  field('catalogue.endpoint','string','Define catalogue endpoint.'),
  field('catalogue.method','string','Define catalogue HTTP method.'),
  field('catalogue.required_fields','string_list','List catalogue request fields.'),
  field('catalogue.game_id_field','string','Identify immutable game ID.'),
  field('catalogue.availability_field','string','Identify per-title availability.'),
  field('catalogue.pagination_rule','string','Define complete catalogue pagination.'),

  field('player.create.endpoint','string','Define player creation endpoint.'),
  field('player.create.method','string','Define player creation HTTP method.'),
  field('player.create.required_fields','string_list','List player creation fields.'),
  field('player.create.idempotency_rule','string','Define duplicate player creation behavior.'),
  field('player.lookup.endpoint','string','Define player lookup endpoint.'),
  field('player.lookup.method','string','Define player lookup HTTP method.'),
  field('player.namespace_rule','string','Define player ID isolation.'),

  field('launch.endpoint','string','Define game launch endpoint.'),
  field('launch.method','string','Define launch HTTP method.'),
  field('launch.required_fields','string_list','List launch request fields.'),
  field('launch.game_id_field','string','Identify the launch game field.'),
  field('launch.url_field','string','Identify the successful launch URL.'),
  field('launch.session_id_field','string','Identify supplier session ID.'),
  field('launch.url_ttl_rule','string','Define launch URL or token lifetime.'),
  field('launch.return_url_rule','string','Define return-to-lobby behavior.'),
  field('launch.success_codes','string_list','List successful launch results.'),
  field('launch.error_codes','string_list','List launch error results.'),

  field('wallet.mode','string','Confirm transfer or seamless wallet mode.',['transfer','seamless']),
  field('wallet.balance.endpoint','string','Define balance endpoint.'),
  field('wallet.balance.method','string','Define balance HTTP method.'),
  field('wallet.balance.amount_field','string','Identify balance amount.'),
  field('wallet.balance.currency_field','string','Identify balance currency.'),
  field('wallet.funds_flow.operations','string_list','List transfer or seamless wallet operations.'),
  field('wallet.funds_flow.required_fields','string_list','List required fields for every funds operation.'),
  field('wallet.funds_flow.transaction_id_field','string','Identify immutable transaction ID.'),
  field('wallet.funds_flow.idempotency_field','string','Identify idempotency key.'),
  field('wallet.funds_flow.duplicate_rule','string','Define duplicate request behavior.'),
  field('wallet.funds_flow.success_codes','string_list','List successful wallet results.'),
  field('wallet.funds_flow.error_codes','string_list','List wallet error results.'),
  field('wallet.transaction_query.endpoint','string','Define transaction query endpoint.'),
  field('wallet.transaction_query.method','string','Define transaction query HTTP method.'),
  field('wallet.transaction_query.binding_fields','string_list','Bind player, amount, currency, direction and IDs.'),
  field('wallet.transaction_query.pending_statuses','string_list','List non-terminal statuses.'),
  field('wallet.transaction_query.terminal_success_statuses','string_list','List successful terminal statuses.'),
  field('wallet.transaction_query.terminal_failure_statuses','string_list','List failed terminal statuses.'),
  field('wallet.transaction_query.not_found_rule','string','Define transaction-not-found behavior.'),
  field('wallet.transaction_query.late_success_rule','string','Define late success after an ambiguous timeout.'),

  field('reports.endpoint','string','Define bet and round report endpoint or callback.'),
  field('reports.method','string','Define report HTTP method.'),
  field('reports.required_fields','string_list','List report fields.'),
  field('reports.round_id_field','string','Identify immutable round ID.'),
  field('reports.bet_id_field','string','Identify immutable bet ID.'),
  field('reports.transaction_id_field','string','Identify immutable result transaction ID.'),
  field('reports.amount_fields','string_list','Identify bet, win, refund and adjustment amounts.'),
  field('reports.currency_field','string','Identify report currency.'),
  field('reports.finality_rule','string','Define result finality.'),
  field('reports.pagination_rule','string','Define stable report pagination.'),
  field('callbacks.signature_rule','string','Define callback signature validation.'),
  field('callbacks.source_ip_rule','string','Define trusted callback source IPs.'),
  field('callbacks.deduplication_field','string','Identify callback deduplication key.'),
  field('callbacks.retry_policy','string','Define callback retry schedule.'),
  field('callbacks.ack_schema','string','Define callback acknowledgement.'),

  field('session.exit.endpoint','string','Define explicit session exit endpoint.'),
  field('session.exit.method','string','Define exit HTTP method.'),
  field('session.kick.endpoint','string','Define forced logout endpoint.'),
  field('session.kick.method','string','Define forced logout HTTP method.'),
  field('session.offline_status.endpoint','string','Define online-status endpoint.'),
  field('session.unfinished_rounds.endpoint','string','Define unfinished-round endpoint.'),
  field('session.issued_token_invalidation_rule','string','Define launch-token invalidation.'),
  field('session.late_result_finality_rule','string','Define when late results can no longer arrive.'),

  field('settlement.reversal_rule','string','Define refund, void and cancel behavior.'),
  field('settlement.reconciliation_fields','string_list','List provider reconciliation keys.'),
  field('recovery.timeout_rule','string','Define ambiguous timeout handling.'),
  field('recovery.retry_policy','string','Define bounded safe retries.'),
  field('recovery.polling_policy','string','Define status and session recovery polling.'),
  field('maintenance.status_endpoint','string','Define supplier maintenance endpoint.'),
  field('maintenance.behavior','string','Define behavior during maintenance.'),
  field('limits.request_rate_rule','string','Define rate and concurrency limits.'),
  field('limits.amount_bounds_rule','string','Define wallet amount bounds.'),
  field('acceptance.uat_account_scope','string','Identify authorized UAT account scope.'),
  field('acceptance.uat_test_cases','string_list','List supplier-approved UAT cases.'),

  field('profile.profile_id','string','Bind evidence to one portal profile.'),
  field('profile.account_variant','string','Bind evidence to one supplier account variant.'),
  field('profile.provider_account_scope','string','Identify supplier account scope without a secret.'),
  field('profile.provider_currency','string','Confirm provider currency.'),
  field('profile.settlement_currency','string','Confirm settlement currency.'),
  field('profile.amount_unit','string','Define major, minor or point units.'),
  field('profile.amount_precision','nonnegative_integer','Define decimal precision.'),
  field('profile.conversion_ratio','ratio','Define provider units to MYR conversion.'),
  field('profile.rounding_rule','string','Define rounding and residual handling.'),
  field('profile.balance_class','string','Confirm cash or free-credit balance.',['cash','free_credit']),
  field('profile.game_scope','string_list','Identify authorized games.'),
]);

const PROFILE_FIELDS:Readonly<Record<EpicwinProfileId,readonly EpicwinContractRequirement[]>>=Object.freeze({
  epicwin_normal_myr:Object.freeze([]),
  epicwin_free_myr:Object.freeze([
    field('profile.free_credit_source','string','Define how free credit is funded.'),
    field('profile.free_credit_spend_rule','string','Define allowed free-credit use.'),
    field('profile.free_credit_cash_conversion_rule','string','Define whether free credit can become cash.'),
    field('profile.free_credit_expiry_rule','string','Define expiry and forfeiture.'),
    field('profile.free_credit_settlement_rule','string','Define free-credit result settlement.'),
    field('profile.free_credit_withdrawal_rule','string','Prohibit or define withdrawal behavior.'),
  ]),
});

const PROFILE_EXPECTATIONS:Readonly<Record<EpicwinProfileId,Readonly<Record<string,readonly string[]>>>>=Object.freeze({
  epicwin_normal_myr:Object.freeze({
    'profile.profile_id':['epicwin_normal_myr'],'profile.account_variant':['normal'],
    'profile.provider_currency':['MYR'],'profile.settlement_currency':['MYR'],
    'profile.conversion_ratio':['1:1'],'profile.balance_class':['cash'],
  }),
  epicwin_free_myr:Object.freeze({
    'profile.profile_id':['epicwin_free_myr'],'profile.account_variant':['free'],
    'profile.provider_currency':['MYR'],'profile.settlement_currency':['MYR'],
    'profile.conversion_ratio':['1:1'],'profile.balance_class':['free_credit'],
  }),
});

function isProfileId(value:string):value is EpicwinProfileId{return (EPICWIN_PROFILE_IDS as readonly string[]).includes(value);}
function readPath(input:unknown,path:string):unknown{
 let current=input;
 for(const segment of path.split('.')){
  if(!current||typeof current!=='object'||Array.isArray(current))return undefined;
  current=(current as Record<string,unknown>)[segment];
 }
 return current;
}

function validateValue(value:unknown,requirement:EpicwinContractRequirement,expected?:readonly string[]):string|null{
 if(requirement.kind==='string'){
  if(typeof value!=='string'||!value.trim()||value.length>2000||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value))return 'invalid_string';
  const allowed=expected??requirement.expected;if(allowed&&!allowed.includes(value.trim()))return 'unexpected_value';return null;
 }
 if(requirement.kind==='string_list')return !Array.isArray(value)||value.length===0||value.length>100||value.some(item=>typeof item!=='string'||!item.trim()||item.length>256)?'invalid_string_list':null;
 if(requirement.kind==='nonnegative_integer')return Number.isSafeInteger(value)&&Number(value)>=0?null:'invalid_nonnegative_integer';
 if(requirement.kind==='sha256')return typeof value==='string'&&/^[a-f0-9]{64}$/.test(value)?null:'invalid_sha256';
 if(requirement.kind==='ratio'){
  if(typeof value!=='string'||!/^[1-9]\d{0,8}:[1-9]\d{0,8}$/.test(value))return 'invalid_ratio';
  return expected&&!expected.includes(value)?'unexpected_value':null;
 }
 return 'invalid_value';
}

export function getEpicwinContractRequirements(profileId:string):readonly EpicwinContractRequirement[]{
 return isProfileId(profileId)?Object.freeze([...EPICWIN_COMMON_VENDOR_FIELDS,...PROFILE_FIELDS[profileId]]):Object.freeze([]);
}

export type EpicwinContractDiagnostic=Readonly<{
 profileId:string;knownProfile:boolean;manifestComplete:boolean;missingVendorFields:readonly string[];
 invalidVendorFields:readonly Readonly<{field:string;reason:string}>[];documentationOnly:true;
 adapterImplemented:false;catalogueAllowed:false;launchAllowed:false;walletAllowed:false;
 settlementAllowed:false;recoveryAllowed:false;playAllowed:false;
}>;

/**
 * Validates document shape and exact profile scope only. Even a complete
 * manifest cannot enable catalogue, launch, funds movement or Play.
 */
export function inspectEpicwinContractManifest(profileId:string,manifest:unknown={}):EpicwinContractDiagnostic{
 const knownProfile=isProfileId(profileId),requirements=getEpicwinContractRequirements(profileId);
 const missingVendorFields:string[]=[],invalidVendorFields:Array<{field:string;reason:string}>=[];
 if(knownProfile)for(const requirement of requirements){
  const value=readPath(manifest,requirement.field);
  if(value===undefined||value===null||value===''){missingVendorFields.push(requirement.field);continue;}
  const reason=validateValue(value,requirement,PROFILE_EXPECTATIONS[profileId][requirement.field]);
  if(reason)invalidVendorFields.push({field:requirement.field,reason});
 }
 return Object.freeze({profileId,knownProfile,manifestComplete:knownProfile&&missingVendorFields.length===0&&invalidVendorFields.length===0,
  missingVendorFields:Object.freeze(missingVendorFields),invalidVendorFields:Object.freeze(invalidVendorFields.map(item=>Object.freeze(item))),
  documentationOnly:true,adapterImplemented:false,catalogueAllowed:false,launchAllowed:false,walletAllowed:false,
  settlementAllowed:false,recoveryAllowed:false,playAllowed:false});
}
