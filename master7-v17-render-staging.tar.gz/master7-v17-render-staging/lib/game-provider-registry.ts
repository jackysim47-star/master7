import {GAME_PROVIDER_IDS, GAME_PROVIDER_NAMES} from './game-ranking.ts';
import {
  createFailClosedGameProviderAdapter,
  type GameProviderAdapter,
  type GameProviderBlocker,
  type GameProviderProfile,
  type GameWalletMode,
} from './game-provider-adapter.ts';

export type GameProviderId = typeof GAME_PROVIDER_IDS[number];
export type GameProviderContractStatus = 'documented' | 'incomplete' | 'missing';
export type GameProviderAdapterStatus = 'implemented' | 'adapter_unimplemented' | 'contract_missing';
export type RegisteredGameProviderProfile = GameProviderProfile & {
  providerId: GameProviderId | 'spribe';
  contractStatus: GameProviderContractStatus;
  adapterStatus: GameProviderAdapterStatus;
  implemented: boolean;
  enabled: false;
  launchVerified: false;
  walletVerified: false;
  settlementVerified: false;
};

export const GAME_PROVIDER_BRANDS = Object.freeze(GAME_PROVIDER_IDS.map(providerId => Object.freeze({
  providerId,
  displayName: GAME_PROVIDER_NAMES[providerId],
})));

type ProfileInput = {
  profileId: string;
  providerId: GameProviderId | 'spribe';
  displayName: string;
  walletMode?: GameWalletMode;
  balanceClass?: 'cash' | 'free_credit';
  unitScale?: 1 | 100;
  adapterKey?: string;
  envPrefix?: string;
  listedInLobby?: boolean;
  adapterStatus?: GameProviderAdapterStatus;
};

const profile = (input: ProfileInput): RegisteredGameProviderProfile => {
  const adapterStatus = input.adapterStatus ?? 'contract_missing';
  const contractStatus: GameProviderContractStatus = adapterStatus === 'implemented' ? 'documented' : adapterStatus === 'adapter_unimplemented' ? 'incomplete' : 'missing';
  return Object.freeze({
    profileId: input.profileId,
    providerId: input.providerId,
    displayName: input.displayName,
    walletMode: input.walletMode ?? 'unknown',
    balanceClass: input.balanceClass ?? (input.profileId.includes('_free_') ? 'free_credit' : 'cash'),
    currency: 'MYR' as const,
    unitScale: input.unitScale ?? 1,
    adapterKey: input.adapterKey ?? input.providerId,
    envPrefix: input.envPrefix ?? `GAME_${input.profileId.toUpperCase().replace(/[^A-Z0-9]+/g, '_')}`,
    playerNamespace: input.profileId,
    ledgerNamespace: input.profileId,
    listedInLobby: input.listedInLobby ?? true,
    contractStatus,
    adapterStatus,
    implemented: adapterStatus === 'implemented',
    enabled: false as const,
    launchVerified: false as const,
    walletVerified: false as const,
    settlementVerified: false as const,
  });
};

const transferProviders = new Set<GameProviderId>(['jdb', 'fuma', 'gamitech', 'spadegaming', 'cg', 'rectangle', 'evo888h5', 'venus', 'clotplay']);
const specializedProviders = new Set<GameProviderId>(['megah5', 'jili', '918kissh5', 'epicwin']);

const baselineProfiles = GAME_PROVIDER_IDS
  .filter(providerId => !specializedProviders.has(providerId))
  .map(providerId => profile({
    profileId: `${providerId}_myr`,
    providerId,
    displayName: `${GAME_PROVIDER_NAMES[providerId]} · MYR`,
    walletMode: transferProviders.has(providerId) ? 'transfer' : 'unknown',
    adapterStatus:providerId==='jdb'?'implemented':undefined,
  }));

const independentProfiles = [
  profile({profileId: 'megah5_myr', providerId: 'megah5', displayName: 'MegaH5 · MYR', walletMode: 'transfer', adapterStatus: 'implemented'}),
  profile({profileId: 'jili_myr_1to1', providerId: 'jili', displayName: 'JILI · MYR 1:1', adapterStatus: 'adapter_unimplemented'}),
  profile({profileId: 'jili_my1_1to100', providerId: 'jili', displayName: 'JILI · MY1 1:100', unitScale: 100, adapterStatus: 'adapter_unimplemented'}),
  profile({profileId: '918kiss_normal_myr', providerId: '918kissh5', displayName: '918KISS H5 · Normal MYR', adapterStatus: 'adapter_unimplemented'}),
  profile({profileId: '918kiss_normal_my1_1to100', providerId: '918kissh5', displayName: '918KISS H5 · Normal MY1 1:100', unitScale: 100, adapterStatus: 'adapter_unimplemented'}),
  profile({profileId: '918kiss_free_myr', providerId: '918kissh5', displayName: '918KISS H5 · Free Credit MYR', adapterStatus: 'adapter_unimplemented'}),
  profile({profileId: 'epicwin_normal_myr', providerId: 'epicwin', displayName: 'EPICWIN · Normal MYR', adapterStatus: 'adapter_unimplemented'}),
  profile({profileId: 'epicwin_free_myr', providerId: 'epicwin', displayName: 'EPICWIN · Free Credit MYR', adapterStatus: 'adapter_unimplemented'}),
  // SPRIBE must never reuse JDB's player or ledger namespace even if its future
  // transport adapter reuses the same protocol family.
  profile({profileId: 'spribe_myr', providerId: 'spribe', displayName: 'SPRIBE · MYR', walletMode: 'transfer', adapterKey: 'jdb', listedInLobby: false}),
];

export const GAME_PROVIDER_PROFILES: readonly RegisteredGameProviderProfile[] = Object.freeze([
  ...independentProfiles,
  ...baselineProfiles,
]);

const profilesById = new Map(GAME_PROVIDER_PROFILES.map(entry => [entry.profileId, entry]));

export function getGameProviderProfile(profileId: string): RegisteredGameProviderProfile | null {
  return profilesById.get(profileId) ?? null;
}

export function getGameProviderProfiles(providerId: string): readonly RegisteredGameProviderProfile[] {
  return GAME_PROVIDER_PROFILES.filter(entry => entry.providerId === providerId);
}

function unregisteredProfile(profileId: string): GameProviderProfile {
  return {
    profileId,
    providerId: 'unregistered',
    displayName: profileId,
    walletMode: 'unknown',
    currency: 'MYR',
    unitScale: 1,
    adapterKey: 'unregistered',
    envPrefix: 'GAME_UNREGISTERED',
    playerNamespace: profileId,
    ledgerNamespace: profileId,
    listedInLobby: false,
  };
}

export function resolveGameProviderAdapter(
  profileId: string,
  adapters: Readonly<Record<string, GameProviderAdapter | undefined>> = {},
): GameProviderAdapter {
  const entry = getGameProviderProfile(profileId);
  if (!entry) return createFailClosedGameProviderAdapter(unregisteredProfile(profileId), 'contract_missing');
  if (!entry.implemented) {
    const reason: GameProviderBlocker = entry.adapterStatus === 'adapter_unimplemented' ? 'adapter_unimplemented' : 'contract_missing';
    return createFailClosedGameProviderAdapter(entry, reason);
  }
  const adapter = adapters[entry.adapterKey];
  return adapter?.executable === true
    ? adapter
    : createFailClosedGameProviderAdapter(entry, 'adapter_unimplemented');
}
