import {createCipheriv, createHash} from 'node:crypto';

// This is an isolated protocol client. It is not registered in the portal and
// does not reserve, debit, credit, or settle the MASTER7 wallet.
export type JdbProfile = 'jdb_myr' | 'spribe_myr';
export type JdbPadding = 'space' | 'zero';
export type JdbDirection = 'deposit' | 'withdraw';
export type JdbConfig = {
  profile: JdbProfile;
  baseUrl: string;
  dc: string;
  parent: string;
  aesKey: string;
  aesIv: string;
  padding: JdbPadding;
  envelopeParent?: string;
  launchOrigins: readonly string[];
  reportUtcOffsetMinutes?: number;
};
export type JdbTransfer = {
  playerId: string;
  serialNo: string;
  direction: JdbDirection;
  amountMinor: string;
};
export type JdbTransferResult =
  | {state: 'matched'; providerTransactionId: string; requiresLedgerReconciliation: true}
  | {state: 'rejected'; providerCode: string; requiresLedgerReconciliation: true}
  | {state: 'unknown'; providerCode?: string; requiresLedgerReconciliation: true};

export class JdbProtocolError extends Error {
  readonly code: string;
  constructor(code: string) {
    super(code);
    this.name = 'JdbProtocolError';
    this.code = code;
  }
}

const error = (code: string): never => { throw new JdbProtocolError(code); };
const id = (value: unknown, pattern: RegExp, code: string): string =>
  typeof value === 'string' && pattern.test(value) ? value : error(code);
const playerId = (value: unknown) => id(value, /^[a-z0-9_-]{1,50}$/, 'invalid_player');
const serial = (value: unknown) => id(value, /^[A-Za-z0-9]{1,50}$/, 'invalid_serial');
const agent = (value: unknown) => id(value, /^[A-Za-z0-9_.-]{1,50}$/, 'invalid_configuration');
const text = (value: unknown, maximum: number) => typeof value === 'string' && value.length > 0 && value.length <= maximum && !/[\u0000-\u001f\u007f]/.test(value) ? value : error('invalid_provider_response');
const isObject = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);

function parseDecimal(value: unknown, fractionDigits: number, signed: boolean): {negative: boolean; units: bigint; raw: string} {
  if (typeof value !== 'string' && typeof value !== 'number') return error('invalid_provider_amount');
  if (typeof value === 'number' && (!Number.isFinite(value) || Math.abs(value) >= 1_000_000_000)) return error('invalid_provider_amount');
  const raw = String(value), expression = new RegExp(`^(${signed ? '-?' : ''})(0|[1-9]\\d{0,8})(?:\\.(\\d{1,${fractionDigits}}))?$`), match = expression.exec(raw);
  if (!match) return error('invalid_provider_amount');
  const units = BigInt(match[2]) * 10n ** BigInt(fractionDigits) + BigInt((match[3] ?? '').padEnd(fractionDigits, '0') || '0');
  return {negative: match[1] === '-' && units !== 0n, units, raw};
}

function minorAmount(value: unknown): bigint {
  const raw = id(value, /^[1-9]\d{0,10}$/, 'invalid_amount');
  const amount = BigInt(raw);
  if (amount > 99_999_999_900n) return error('invalid_amount');
  return amount;
}

function providerAmount(value: unknown): {minor: bigint; residual: boolean; raw: string; negative: boolean} {
  const amount = parseDecimal(value, 3, true);
  return {minor: amount.units / 10n, residual: amount.units % 10n !== 0n, raw: amount.raw, negative: amount.negative};
}

function origin(value: string): string {
  let url: URL;
  try { url = new URL(value); } catch { return error('invalid_configuration'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || !['', '/'].includes(url.pathname) || (url.port && url.port !== '443')) return error('invalid_configuration');
  return url.origin;
}

export function jdbPlayerId(profile: JdbProfile, userId: string): string {
  if (!['jdb_myr', 'spribe_myr'].includes(profile) || typeof userId !== 'string' || userId.length < 1 || userId.length > 200) return error('invalid_player');
  return `m7${createHash('sha256').update(`${profile}\0${userId}`).digest('hex').slice(0, 38)}`;
}

export function jdbSerialNo(profile: JdbProfile, transactionId: string, direction: JdbDirection): string {
  if (!['jdb_myr', 'spribe_myr'].includes(profile) || !['deposit', 'withdraw'].includes(direction) || typeof transactionId !== 'string' || transactionId.length < 1 || transactionId.length > 200) return error('invalid_serial');
  return `m7${createHash('sha256').update(`${profile}\0${direction}\0${transactionId}`).digest('hex').slice(0, 44)}`;
}

export function encryptJdbPayload(payload: string, key: string, iv: string, padding: JdbPadding): string {
  if (typeof payload !== 'string' || typeof key !== 'string' || typeof iv !== 'string') return error('invalid_configuration');
  const keyBytes = Buffer.from(key, 'utf8'), ivBytes = Buffer.from(iv, 'utf8');
  if (keyBytes.length !== 16 || ivBytes.length !== 16 || !['space', 'zero'].includes(padding)) return error('invalid_configuration');
  const input = Buffer.from(payload.trim(), 'utf8');
  if (!input.length || input.length > 64 * 1024) return error('invalid_payload');
  const fill = (16 - input.length % 16) % 16;
  const bytes = fill ? Buffer.concat([input, Buffer.alloc(fill, padding === 'space' ? 0x20 : 0)]) : input;
  const cipher = createCipheriv('aes-128-cbc', keyBytes, ivBytes);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(bytes), cipher.final()]).toString('base64url');
}

async function responseJson(response: Response, maxBytes: number): Promise<Record<string, unknown>> {
  if (!response.ok || response.redirected || !/^application\/json(?:\s*;|\s*$)/i.test(response.headers.get('content-type') ?? '') || !response.body) return error('provider_unavailable');
  const declared = response.headers.get('content-length');
  if (declared && (!/^\d+$/.test(declared) || Number(declared) > maxBytes)) return error('invalid_provider_response');
  const reader = response.body.getReader(), chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) { await reader.cancel().catch(() => {}); return error('invalid_provider_response'); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  let result: unknown;
  try { result = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return error('invalid_provider_response'); }
  if (!isObject(result) || typeof result.status !== 'string' || !/^\d{4}$/.test(result.status)) return error('invalid_provider_response');
  return result;
}

function providerId(value: unknown): string | null {
  if (typeof value === 'number' && Number.isSafeInteger(value) && value > 0) return String(value);
  if (typeof value === 'string' && /^[1-9]\d{0,19}$/.test(value)) return value;
  return null;
}

function requireSuccess(result: Record<string, unknown>): void {
  if (result.status !== '0000') error('provider_rejected');
}

function reportDate(epoch: number, offset: number): string {
  const d = new Date(epoch + offset * 60_000);
  const two = (n: number) => String(n).padStart(2, '0');
  return `${two(d.getUTCDate())}-${two(d.getUTCMonth() + 1)}-${d.getUTCFullYear()} ${two(d.getUTCHours())}:${two(d.getUTCMinutes())}:00`;
}

export function createJdbProtocolClient(config: JdbConfig, transport: typeof fetch, clock: () => number = Date.now) {
  if (!['jdb_myr', 'spribe_myr'].includes(config.profile) || typeof transport !== 'function') return error('invalid_configuration');
  const base = origin(config.baseUrl), dc = id(config.dc, /^[A-Za-z0-9_-]{1,32}$/, 'invalid_configuration'), parent = agent(config.parent);
  if (config.envelopeParent !== undefined) agent(config.envelopeParent);
  if (!Array.isArray(config.launchOrigins) || config.launchOrigins.length > 50) return error('invalid_configuration');
  const launchOrigins = new Set(config.launchOrigins.map(origin));
  if (config.reportUtcOffsetMinutes !== undefined && (!Number.isInteger(config.reportUtcOffsetMinutes) || config.reportUtcOffsetMinutes < -720 || config.reportUtcOffsetMinutes > 840)) return error('invalid_configuration');
  const {profile, aesKey, aesIv, padding, envelopeParent, reportUtcOffsetMinutes} = config;
  // Validate both the explicit padding choice and AES key sizes before any request.
  encryptJdbPayload('{}', aesKey, aesIv, padding);
  const timestamp = () => { const now = clock(); return Number.isSafeInteger(now) && now > 0 ? now : error('invalid_clock'); };

  async function request(action: number, fields: Record<string, unknown>, maxBytes = 64 * 1024): Promise<Record<string, unknown>> {
    const payload = JSON.stringify({action, ts: timestamp(), ...fields});
    const x = encryptJdbPayload(payload, aesKey, aesIv, padding);
    const body = JSON.stringify({dc, x, ...(envelopeParent === undefined ? {} : {parent: envelopeParent})});
    try {
      const response = await transport(`${base}/apiRequest.do`, {method: 'POST', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(12_000), headers: {'Accept': 'application/json', 'Content-Type': 'application/json'}, body});
      return await responseJson(response, maxBytes);
    } catch (caught) {
      if (caught instanceof JdbProtocolError) throw caught;
      return error('provider_unavailable');
    }
  }

  function transferInput(input: JdbTransfer) {
    if (!input || !['deposit', 'withdraw'].includes(input.direction)) return error('invalid_transfer');
    return {uid: playerId(input.playerId), serialNo: serial(input.serialNo), amount: minorAmount(input.amountMinor), direction: input.direction};
  }

  async function listGames() {
    const result = await request(49, {parent, lang: 'en'}, 2 * 1024 * 1024);
    requireSuccess(result);
    if (!Array.isArray(result.data) || result.data.length > 1000) return error('invalid_provider_response');
    const games: {providerGameId: string; name: string; maintenance: boolean}[] = [], seen = new Set<string>();
    for (const group of result.data) {
      if (!isObject(group) || !Number.isInteger(group.gType) || Number(group.gType) < 0 || Number(group.gType) > 999 || !Array.isArray(group.list)) return error('invalid_provider_response');
      for (const row of group.list) {
        if (!isObject(row) || games.length >= 10000) return error('invalid_provider_response');
        const machine = row.mType ?? row.mtype;
        if (!(typeof machine === 'number' && Number.isSafeInteger(machine) && machine >= 0 && machine <= 999999) && !(typeof machine === 'string' && /^\d{1,6}$/.test(machine))) return error('invalid_provider_response');
        if (row.maintenance !== undefined && typeof row.maintenance !== 'boolean') return error('invalid_provider_response');
        const gameId = `${group.gType}:${Number(machine)}`;
        if (seen.has(gameId)) return error('invalid_provider_response');
        seen.add(gameId);
        games.push({providerGameId: gameId, name: text(row.name, 512), maintenance: row.maintenance !== false});
      }
    }
    return games;
  }

  async function createPlayer(uid: string): Promise<{state: 'created' | 'exists_unverified' | 'unknown'}> {
    uid = playerId(uid);
    try {
      const result = await request(12, {parent, uid, name: uid, credit_allocated: 0});
      return {state: result.status === '0000' ? 'created' : result.status === '7602' ? 'exists_unverified' : 'unknown'};
    } catch { return {state: 'unknown'}; }
  }

  async function verifyPlayer(uid: string) {
    uid = playerId(uid);
    const result = await request(15, {parent, uid});
    requireSuccess(result);
    if (!Array.isArray(result.data) || result.data.length !== 1 || !isObject(result.data[0])) return error('invalid_provider_response');
    const row = result.data[0];
    if (row.uid !== uid || row.parent !== parent || row.currency !== 'RM' || row.lvl !== 0 || ![0, 1, 2, 3].includes(row.locked as number) || ![0, 1].includes(row.closed as number)) return error('player_identity_mismatch');
    const amount = providerAmount(row.balance);
    if (amount.negative) return error('invalid_provider_amount');
    return {playerId: uid, currency: 'MYR' as const, amountMinor: amount.minor.toString(), residual: amount.residual, providerAmount: amount.raw, active: row.locked === 0 && row.closed === 0};
  }

  async function launch(uid: string, gameId: string, language: 'en' | 'zh' | 'ms', lobbyUrl: string) {
    uid = playerId(uid);
    const parts = /^(\d{1,3}):(\d{1,6})$/.exec(gameId);
    if (!parts || !['en', 'zh', 'ms'].includes(language) || launchOrigins.size === 0) return error('invalid_launch');
    let lobby: URL;
    try { lobby = new URL(lobbyUrl); } catch { return error('invalid_launch'); }
    if (lobby.protocol !== 'https:' || lobby.username || lobby.password || lobby.hash || lobby.href.length > 100) return error('invalid_launch');
    const result = await request(11, {uid, lang: language === 'zh' ? 'cn' : 'en', gType: parts[1], mType: parts[2], windowMode: '2', lobbyURL: lobby.href});
    requireSuccess(result);
    const path = text(result.path, 2048);
    let url: URL;
    try { url = new URL(path); } catch { return error('invalid_provider_response'); }
    if (url.protocol !== 'https:' || url.username || url.password || url.hash || !launchOrigins.has(url.origin)) return error('invalid_provider_response');
    return {launchUrl: url.href};
  }

  async function transfer(input: JdbTransfer): Promise<JdbTransferResult> {
    const t = transferInput(input);
    const decimal = Number(`${t.amount / 100n}.${String(t.amount % 100n).padStart(2, '0')}`);
    try {
      const result = await request(19, {parent, uid: t.uid, serialNo: t.serialNo, allCashOutFlag: '0', amount: t.direction === 'deposit' ? decimal : -decimal});
      if (result.status !== '0000') {
        const code = String(result.status);
        if (['6009', '6010', '6901'].includes(code)) return {state: 'rejected', providerCode: code, requiresLedgerReconciliation: true};
        return {state: 'unknown', providerCode: code, requiresLedgerReconciliation: true};
      }
      const amount = providerAmount(result.amount), pid = providerId(result.pid);
      if (result.serialNo !== t.serialNo || amount.residual || amount.minor !== t.amount || (t.direction === 'deposit' && amount.negative) || !pid) return {state: 'unknown', requiresLedgerReconciliation: true};
      return {state: 'matched', providerTransactionId: pid, requiresLedgerReconciliation: true};
    } catch { return {state: 'unknown', requiresLedgerReconciliation: true}; }
  }

  async function queryTransfer(input: JdbTransfer): Promise<JdbTransferResult> {
    const t = transferInput(input);
    try {
      const result = await request(55, {parent, serialNo: t.serialNo});
      if (result.status !== '0000') return {state: 'unknown', providerCode: String(result.status), requiresLedgerReconciliation: true};
      if (!Array.isArray(result.data) || result.data.length !== 1 || !isObject(result.data[0])) return {state: 'unknown', requiresLedgerReconciliation: true};
      const row = result.data[0], amount = providerAmount(row.amount), pid = providerId(row.pid);
      if (row.uid !== t.uid || row.action !== t.direction || amount.residual || amount.minor !== t.amount || (t.direction === 'deposit' && amount.negative) || !pid) return {state: 'unknown', requiresLedgerReconciliation: true};
      // Action 55 does not return a currency or serial number. The caller must
      // independently verify the player currency and reconcile the local ledger.
      return {state: 'matched', providerTransactionId: pid, requiresLedgerReconciliation: true};
    } catch { return {state: 'unknown', requiresLedgerReconciliation: true}; }
  }

  async function fetchWagers(mode: 'recent' | 'old', from: number, to: number) {
    const offset = reportUtcOffsetMinutes, now = timestamp(), minute = 60_000;
    if (offset === undefined || !['recent', 'old'].includes(mode) || !Number.isSafeInteger(from) || !Number.isSafeInteger(to) || from % minute !== 0 || to % minute !== 0 || from >= to) return error('invalid_report_window');
    if (mode === 'recent' && (to - from > 15 * minute || from < now - 2 * 60 * minute || to > now - 3 * minute)) return error('invalid_report_window');
    if (mode === 'old' && (to - from > 5 * minute || from < now - 60 * 24 * 60 * minute || to > now - 60 * minute)) return error('invalid_report_window');
    const result = await request(mode === 'recent' ? 29 : 64, {parent, starttime: reportDate(from, offset), endtime: reportDate(to, offset)}, 2 * 1024 * 1024);
    requireSuccess(result);
    if (!Array.isArray(result.data) || result.data.length > 10000) return error('invalid_provider_response');
    const records = result.data.map(row => {
      if (!isObject(row) || row.currency !== 'RM' || !Number.isInteger(row.gType) || Number(row.gType) < 0 || Number(row.gType) > 999 || !Number.isInteger(row.mtype) || Number(row.mtype) < 0 || Number(row.mtype) > 999999) return error('invalid_provider_response');
      const rawAmount = (value: unknown) => parseDecimal(value, 6, true).raw;
      if (typeof row.roundSeqNo === 'number' && !Number.isSafeInteger(row.roundSeqNo)) return error('invalid_provider_response');
      return {historyId: text(row.historyId, 200), playerId: playerId(row.playerId), providerGameId: `${row.gType}:${row.mtype}`, roundSeqNo: row.roundSeqNo === undefined ? null : text(String(row.roundSeqNo), 200), gameDate: text(row.gameDate, 19), lastModifyTime: text(row.lastModifyTime, 19), bet: rawAmount(row.bet), win: rawAmount(row.win), total: rawAmount(row.total), currency: 'MYR' as const};
    });
    return {records, timeBasis: mode === 'recent' ? 'lastModifyTime' as const : 'gameDate' as const, complete: false as const};
  }

  return Object.freeze({profile, listGames, createPlayer, verifyPlayer, launch, transfer, queryTransfer, fetchWagers});
}
