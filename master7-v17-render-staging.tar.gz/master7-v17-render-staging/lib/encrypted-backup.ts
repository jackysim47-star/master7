import {constants,createCipheriv,createHash,publicEncrypt,randomBytes} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {BACKUP_PUBLIC_KEY,BACKUP_PUBLIC_KEY_SHA256} from './backup-public-key.ts';

export const BACKUP_FORMAT='MASTER7-ENCRYPTED-BACKUP-1';
export const BACKUP_SCHEMA_VERSION='0107-benefit-claim-reviews';
export const BACKUP_PAGE_SIZE=1000;

// Authentication sessions, OTP challenges and rate-limit buckets are deliberately
// excluded. A restored portal must require every person to sign in again.
export const BACKUP_TABLES=[
 'users','password_credentials','referral_codes','referral_relationships',
 'marketing_contacts','marketing_campaigns','marketing_deliveries',
 'deposit_orders','wallet_ledger','wallet_reservations','game_wallet_sessions','game_wallet_ledger',
 'company_bank_accounts','manual_deposit_requests','announcements','audit',
 'providers','tickets','replies','ticket_reads','settings','lobby_ads','benefit_rules',
 'game_visibility','custom_game_cards','payment_channel_controls',
 'brand_directory_entries','api_supplier_artwork','portal_schema_migrations',
 'portal_status_snapshots','withdrawal_requests','game_catalogue_cache',
 'accounting_daily_snapshots','accounting_snapshot_adjustments',
 'accounting_late_adjustments','accounting_job_runs','benefit_claims',
 'voucher_manual_reviews','voucher_manual_play_events',
 'commission_periods','commission_entries','turnover_obligations',
 'wallet_posting_intents','payment_recovery_leases',
 'provider_payout_controls','provider_payouts',
 'rewards_checkins','rewards_points_ledger',
 'responsible_play_profiles','responsible_play_deposit_reservations'
] as const;

const EXCLUDED_TABLES=['password_sessions','otp_challenges','rate_limits'] as const;
const sha256=(value:Uint8Array|string)=>createHash('sha256').update(value).digest('hex');
export const BACKUP_SCHEMA_SHA256=sha256(JSON.stringify({format:BACKUP_FORMAT,schemaVersion:BACKUP_SCHEMA_VERSION,tables:BACKUP_TABLES}));

async function tableRows(db:D1Database,table:string){
 const items:Record<string,unknown>[]=[];
 // The adapter maps the same placeholders to SQLite and PostgreSQL. Ordering
 // by the first selected column makes page boundaries deterministic while the
 // bounded page size avoids the old 10,000-row truncation/failure mode.
 for(let offset=0;;offset+=BACKUP_PAGE_SIZE){
  const result=await db.prepare(`SELECT * FROM ${table} ORDER BY 1 LIMIT ? OFFSET ?`).bind(BACKUP_PAGE_SIZE,offset).all();
  const page=(result.results??[]) as Record<string,unknown>[];
  items.push(...page);
  if(page.length<BACKUP_PAGE_SIZE)break;
 }
 return items;
}

export async function createEncryptedPortalBackup(db:D1Database,release:string,cryptoConfig:{publicKey?:string;publicKeySha256?:string}={}){
 const tables:Record<string,Record<string,unknown>[]>=Object.create(null),manifestTables:{name:string;rows:number;sha256:string}[]=[];
 for(const table of BACKUP_TABLES){
  const items=await tableRows(db,table),serialized=JSON.stringify(items);
  tables[table]=items;
  manifestTables.push({name:table,rows:items.length,sha256:sha256(serialized)});
 }
 const createdAt=new Date().toISOString(),totalRecords=manifestTables.reduce((sum,item)=>sum+item.rows,0),payload={format:BACKUP_FORMAT,release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,createdAt,source:'master7-portal-logical-backup',restorePolicy:{forceNewSessions:true,excludedTables:[...EXCLUDED_TABLES]},manifest:{tableCount:manifestTables.length,totalRecords,tables:manifestTables},tables};
 const publicKey=cryptoConfig.publicKey??BACKUP_PUBLIC_KEY,publicKeySha256=cryptoConfig.publicKeySha256??BACKUP_PUBLIC_KEY_SHA256,plaintext=Buffer.from(JSON.stringify(payload)),compressed=gzipSync(plaintext,{level:9}),contentKey=randomBytes(32),iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',contentKey,iv),ciphertext=Buffer.concat([cipher.update(compressed),cipher.final()]),authTag=cipher.getAuthTag(),encryptedKey=publicEncrypt({key:publicKey,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},contentKey);
 const envelope={format:BACKUP_FORMAT,release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,createdAt,publicKeySha256,encryption:{key:'RSA-OAEP-SHA256',content:'AES-256-GCM',compression:'gzip'},manifest:{tableCount:manifestTables.length,totalRecords,tables:manifestTables.map(item=>({name:item.name,rows:item.rows}))},encryptedKey:encryptedKey.toString('base64'),iv:iv.toString('base64'),authTag:authTag.toString('base64'),ciphertext:ciphertext.toString('base64'),ciphertextSha256:sha256(ciphertext),plaintextSha256:sha256(plaintext)};
 return {envelope,metadata:{release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,createdAt,totalRecords,tableCount:manifestTables.length,publicKeySha256,ciphertextSha256:envelope.ciphertextSha256}};
}
