import {constants,createCipheriv,createHash,publicEncrypt,randomBytes} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {BACKUP_PUBLIC_KEY,BACKUP_PUBLIC_KEY_SHA256} from './backup-public-key.ts';

export const BACKUP_FORMAT='MASTER7-ENCRYPTED-BACKUP-1';
export const BACKUP_SCHEMA_VERSION='0117-flexible-public-contacts';
export const BACKUP_PAGE_SIZE=1000;

export type BackupReader={
 prepare(sql:string):{bind(...values:unknown[]):{all():Promise<{results?:unknown[]}>}};
};
type BackupSource=BackupReader&{withReadSnapshot?<T>(read:(db:BackupReader)=>Promise<T>):Promise<T>};

// Preserve the deployed 0107 manifest for explicitly identified legacy restores.
const LEGACY_0107_BACKUP_TABLES=[
 'users','password_credentials','referral_codes','referral_relationships',
 'marketing_contacts','marketing_campaigns','marketing_deliveries',
 'deposit_orders','wallet_ledger','wallet_reservations','game_wallet_sessions','game_wallet_ledger',
 'company_bank_accounts','manual_deposit_requests','announcements','audit',
 'providers','tickets','replies','ticket_reads','settings','lobby_ads','benefit_rules',
 'game_visibility','custom_game_cards','payment_channel_controls',
 'brand_directory_entries','api_supplier_artwork','portal_schema_migrations',
 'portal_status_snapshots','withdrawal_requests','game_catalogue_cache',
 'accounting_daily_snapshots','accounting_snapshot_adjustments',
 'accounting_late_adjustments','accounting_job_runs','benefit_claims',
 'voucher_manual_reviews','voucher_manual_play_events',
 'commission_periods','commission_entries','turnover_obligations',
 'wallet_posting_intents','payment_recovery_leases',
 'provider_payout_controls','provider_payouts',
 'rewards_checkins','rewards_points_ledger',
 'responsible_play_profiles','responsible_play_deposit_reservations'
] as const;

const FULL_0107_BACKUP_TABLES=[...LEGACY_0107_BACKUP_TABLES,'marketing_webhook_events'] as const;
const LEGACY_0108_BACKUP_TABLES=[...FULL_0107_BACKUP_TABLES,'manual_compliance_reviews','manual_compliance_events'] as const;
const GAME_ADAPTER_BACKUP_TABLES=[
 'game_provider_profiles','game_provider_players','game_provider_sessions','game_wallet_transfers','game_rounds',
 'game_transactions','game_wallet_postings','game_callback_receipts','game_wager_sync_cursors','game_recovery_leases'
] as const;
const LEGACY_0110_BACKUP_TABLES=[...LEGACY_0108_BACKUP_TABLES,...GAME_ADAPTER_BACKUP_TABLES] as const;
const LEGACY_0112_BACKUP_TABLES=[...LEGACY_0110_BACKUP_TABLES,'megah5_launch_operations'] as const;
const GAME_ACCEPTANCE_BACKUP_TABLES=['game_provider_acceptance_events','game_provider_acceptance_current'] as const;
const LEGACY_0113_BACKUP_TABLES=[...LEGACY_0112_BACKUP_TABLES,...GAME_ACCEPTANCE_BACKUP_TABLES] as const;
const LEGACY_0115_BACKUP_TABLES=[...LEGACY_0113_BACKUP_TABLES,'manual_bank_transactions'] as const;
const LEGACY_0116_BACKUP_TABLES=[...LEGACY_0115_BACKUP_TABLES,'provider_wallet_operations'] as const;
export const BACKUP_TABLES=[...LEGACY_0116_BACKUP_TABLES,'public_contact_revisions'] as const;
type BackupTable=(typeof BACKUP_TABLES)[number];
// These keys are checked against the release migrations by the pagination
// regression. A prefix of a composite key does not define stable page bounds.
const BACKUP_PRIMARY_KEYS:Record<BackupTable,readonly string[]>={
 public_contact_revisions:['id'],provider_wallet_operations:['session_id'],manual_bank_transactions:['id'],users:['id'],password_credentials:['username'],referral_codes:['code'],referral_relationships:['member_id'],
 marketing_contacts:['id'],marketing_campaigns:['id'],marketing_deliveries:['campaign_id','contact_id'],
 deposit_orders:['id'],wallet_ledger:['id'],wallet_reservations:['user_id'],game_wallet_sessions:['id'],game_wallet_ledger:['id'],
 company_bank_accounts:['id'],manual_deposit_requests:['deposit_order_id'],announcements:['id'],audit:['id'],
 providers:['id'],tickets:['id'],replies:['id'],ticket_reads:['ticket_id','user_id'],settings:['id'],lobby_ads:['id'],benefit_rules:['id'],
 game_visibility:['provider_id','game_code'],custom_game_cards:['id'],payment_channel_controls:['provider_id'],
 brand_directory_entries:['id'],api_supplier_artwork:['provider_id'],portal_schema_migrations:['version'],
 portal_status_snapshots:['migration_version','entity_type','entity_key'],withdrawal_requests:['id'],game_catalogue_cache:['provider_id'],
 accounting_daily_snapshots:['period_start'],accounting_snapshot_adjustments:['id'],accounting_late_adjustments:['id'],accounting_job_runs:['job_key'],
 benefit_claims:['id'],voucher_manual_reviews:['claim_id'],voucher_manual_play_events:['id'],commission_periods:['id'],commission_entries:['id'],
 turnover_obligations:['id'],wallet_posting_intents:['id'],payment_recovery_leases:['provider','order_id'],
 provider_payout_controls:['provider_id'],provider_payouts:['id'],rewards_checkins:['id'],rewards_points_ledger:['id'],
 responsible_play_profiles:['user_id'],responsible_play_deposit_reservations:['user_id','request_key'],marketing_webhook_events:['event_key'],manual_compliance_reviews:['user_id'],manual_compliance_events:['id'],
 game_provider_profiles:['id'],game_provider_players:['profile_id','user_id'],game_provider_sessions:['id'],game_wallet_transfers:['id'],
 game_rounds:['id'],game_transactions:['id'],game_wallet_postings:['id'],game_callback_receipts:['profile_id','event_key'],
 game_wager_sync_cursors:['profile_id'],game_recovery_leases:['profile_id','resource_type','resource_id'],
 megah5_launch_operations:['id'],
 game_provider_acceptance_events:['id'],game_provider_acceptance_current:['profile_id','capability','environment'],
};
// A restored portal requires fresh sign-ins. The lock row is re-created by the
// next transaction; restrictions and reservations remain in the durable tables.
// Member wallet guard rows are similarly recreated and do not contain risk data.
export const BACKUP_EXCLUDED_TABLES=['password_sessions','otp_challenges','rate_limits','responsible_play_locks','member_wallet_guards'] as const;
const sha256=(value:Uint8Array|string)=>createHash('sha256').update(value).digest('hex');
export const BACKUP_SCHEMA_SHA256=sha256(JSON.stringify({format:BACKUP_FORMAT,schemaVersion:BACKUP_SCHEMA_VERSION,tables:BACKUP_TABLES}));

export function backupRestoreContract(schemaVersion:unknown,schemaSha256:unknown){
 if(schemaVersion===BACKUP_SCHEMA_VERSION&&schemaSha256===BACKUP_SCHEMA_SHA256)return {tables:BACKUP_TABLES,missingTables:[] as string[]};
 if(schemaVersion==='0116-provider-wallet-operations'&&schemaSha256===sha256(JSON.stringify({format:BACKUP_FORMAT,schemaVersion:'0116-provider-wallet-operations',tables:LEGACY_0116_BACKUP_TABLES})))return {tables:LEGACY_0116_BACKUP_TABLES,missingTables:['public_contact_revisions']};
 if(schemaVersion==='0115-manual-bank-funds'&&schemaSha256===sha256(JSON.stringify({format:BACKUP_FORMAT,schemaVersion:'0115-manual-bank-funds',tables:LEGACY_0115_BACKUP_TABLES})))return {tables:LEGACY_0115_BACKUP_TABLES,missingTables:['provider_wallet_operations','public_contact_revisions']};
 if(schemaVersion==='0113-game-provider-acceptance'&&schemaSha256===sha256(JSON.stringify({format:BACKUP_FORMAT,schemaVersion:'0113-game-provider-acceptance',tables:LEGACY_0113_BACKUP_TABLES})))return {tables:LEGACY_0113_BACKUP_TABLES,missingTables:['manual_bank_transactions','provider_wallet_operations','public_contact_revisions']};
 if(schemaVersion==='0112-megah5-launch-operations'&&schemaSha256==='2ce57d7e348bdee3a0b6e145d19479a113136ccadc61e9fdfda2e1511a6a3e3b')return {tables:LEGACY_0112_BACKUP_TABLES,missingTables:['manual_bank_transactions',...GAME_ACCEPTANCE_BACKUP_TABLES,'provider_wallet_operations','public_contact_revisions']};
 // Legacy archives cannot prove that no launch was in flight at backup time.
 // Preserve their data but never report complete launch-operation coverage.
 if(schemaVersion==='0110-game-provider-adapter-core'&&schemaSha256==='4a1e7437fb14dc212ec39a801e173f7e898fcfa44707e7b523f5c8ba299b1555')return {tables:LEGACY_0110_BACKUP_TABLES,missingTables:['manual_bank_transactions','megah5_launch_operations',...GAME_ACCEPTANCE_BACKUP_TABLES,'provider_wallet_operations','public_contact_revisions']};
 if(schemaVersion==='0108-manual-compliance-review'&&schemaSha256==='6453a7551fd5cbc19e6b7ca6728405f4ead79db7864b5b8d52186905bcb8798a')return {tables:LEGACY_0108_BACKUP_TABLES,missingTables:['manual_bank_transactions',...GAME_ADAPTER_BACKUP_TABLES,'megah5_launch_operations',...GAME_ACCEPTANCE_BACKUP_TABLES,'provider_wallet_operations','public_contact_revisions']};
 // This exact prior release manifest omitted persistent webhook deduplication.
 // Recover its existing records, but never label that receipt complete/current.
 if(schemaVersion==='0107-benefit-claim-reviews'&&schemaSha256==='5ce4d8778d03097b16ef0fff08c1cc6fa05e7ce9a639bce232564a728982cae9')return {tables:FULL_0107_BACKUP_TABLES,missingTables:['manual_bank_transactions','manual_compliance_reviews','manual_compliance_events',...GAME_ADAPTER_BACKUP_TABLES,'megah5_launch_operations',...GAME_ACCEPTANCE_BACKUP_TABLES,'provider_wallet_operations','public_contact_revisions']};
 if(schemaVersion==='0107-benefit-claim-reviews'&&schemaSha256==='2648becd21723884358bcaf90f5928dc19c7cc58dcf090c87ca1db3c00c34d69')return {tables:LEGACY_0107_BACKUP_TABLES,missingTables:['manual_bank_transactions','marketing_webhook_events','manual_compliance_reviews','manual_compliance_events',...GAME_ADAPTER_BACKUP_TABLES,'megah5_launch_operations',...GAME_ACCEPTANCE_BACKUP_TABLES,'provider_wallet_operations','public_contact_revisions']};
 throw new Error('Backup schema version does not match this release');
}

async function tableRows(db:BackupReader,table:BackupTable){
 const items:Record<string,unknown>[]=[];
 // Use the full unique key, including every composite-key column, so the
 // database may change its plan without repeating or omitting tied rows.
 // Stable ordering alone does not provide a snapshot across concurrent writes.
 const order=BACKUP_PRIMARY_KEYS[table].join(',');
 for(let offset=0;;offset+=BACKUP_PAGE_SIZE){
  const result=await db.prepare(`SELECT * FROM ${table} ORDER BY ${order} LIMIT ? OFFSET ?`).bind(BACKUP_PAGE_SIZE,offset).all();
  const page=(result.results??[]) as Record<string,unknown>[];
  items.push(...page);
  if(page.length<BACKUP_PAGE_SIZE)break;
 }
 return items;
}

async function collectBackupTables(db:BackupReader){
 const tables:Record<string,Record<string,unknown>[]>=Object.create(null);
 for(const table of BACKUP_TABLES)tables[table]=await tableRows(db,table);
 return tables;
}

export async function createEncryptedPortalBackup(db:BackupSource,release:string,cryptoConfig:{publicKey?:string;publicKeySha256?:string}={}){
 let tables:Record<string,Record<string,unknown>[]>,readConsistency:'transaction_snapshot'|'unverified';
 if(typeof db.withReadSnapshot==='function'){
  tables=await db.withReadSnapshot(collectBackupTables);
  readConsistency='transaction_snapshot';
 }else{
  tables=await collectBackupTables(db);
  readConsistency='unverified';
 }
 // The scoped connection has been rolled back and released before hashing,
 // compression or encryption. The caller records its audit event afterwards.
 const manifestTables:{name:string;rows:number;sha256:string}[]=[];
 for(const table of BACKUP_TABLES){
  const items=tables[table],serialized=JSON.stringify(items);
  manifestTables.push({name:table,rows:items.length,sha256:sha256(serialized)});
 }
 const createdAt=new Date().toISOString(),totalRecords=manifestTables.reduce((sum,item)=>sum+item.rows,0),payload={format:BACKUP_FORMAT,release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,createdAt,readConsistency,source:'master7-portal-logical-backup',restorePolicy:{forceNewSessions:true,excludedTables:[...BACKUP_EXCLUDED_TABLES]},manifest:{tableCount:manifestTables.length,totalRecords,tables:manifestTables},tables};
 const publicKey=cryptoConfig.publicKey??BACKUP_PUBLIC_KEY,publicKeySha256=cryptoConfig.publicKeySha256??BACKUP_PUBLIC_KEY_SHA256,plaintext=Buffer.from(JSON.stringify(payload)),compressed=gzipSync(plaintext,{level:9}),contentKey=randomBytes(32),iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',contentKey,iv),ciphertext=Buffer.concat([cipher.update(compressed),cipher.final()]),authTag=cipher.getAuthTag(),encryptedKey=publicEncrypt({key:publicKey,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},contentKey);
 const envelope={format:BACKUP_FORMAT,release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,createdAt,readConsistency,publicKeySha256,encryption:{key:'RSA-OAEP-SHA256',content:'AES-256-GCM',compression:'gzip'},manifest:{tableCount:manifestTables.length,totalRecords,tables:manifestTables.map(item=>({name:item.name,rows:item.rows}))},encryptedKey:encryptedKey.toString('base64'),iv:iv.toString('base64'),authTag:authTag.toString('base64'),ciphertext:ciphertext.toString('base64'),ciphertextSha256:sha256(ciphertext),plaintextSha256:sha256(plaintext)};
 return {envelope,metadata:{release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,createdAt,readConsistency,totalRecords,tableCount:manifestTables.length,publicKeySha256,ciphertextSha256:envelope.ciphertextSha256}};
}
