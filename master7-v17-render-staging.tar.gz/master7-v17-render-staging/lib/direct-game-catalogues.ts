import {createHash,createHmac} from 'node:crypto';

// Read-only integrations. No player creation, game launch, transfer, bet or
// payout operation is available through this module.
export type DirectCatalogueConfig={rectangleApiBase?:string;rectangleOperatorCode?:string;rectangleApiKey?:string;godeeApiBase?:string;godeeOperatorId?:string;godeeApiKey?:string;gameCatalogueFetch?:typeof fetch};
export class CatalogueReadError extends Error{upstreamStatus:number|null;constructor(upstreamStatus:number|null){super('CATALOGUE_READ_FAILED');this.upstreamStatus=upstreamStatus;}}
const maxGames=2000;
function identifier(value:unknown,max:number){
 const text=typeof value==='string'||typeof value==='number'?String(value).trim():'';
 return text.length>0&&text.length<=max&&!/[\u0000-\u001f\u007f-\u009f]/u.test(text)?text:null;
}
function title(value:unknown,max=512){return typeof value==='string'&&value.trim().length>0&&value.trim().length<=max&&!/[\u0000-\u001f\u007f-\u009f]/u.test(value)?value.trim():null;}
export function directCatalogueConfigured(c:DirectCatalogueConfig,id:string){
 if(id==='rectangle')return c.rectangleApiBase==='https://apig.rg-lgna.com'&&/^[A-Za-z0-9_-]{1,64}$/.test(c.rectangleOperatorCode??'')&&(c.rectangleApiKey??'').length>=16;
 if(id==='godeezone')return c.godeeApiBase==='https://api.godeezone1.com'&&/^[A-Za-z0-9_-]{1,64}$/.test(c.godeeOperatorId??'')&&(c.godeeApiKey??'').length>=16;
 return false;
}
export function rectangleCatalogueHeaders(host:string,secret:string,time:number){
 const hash=createHash('sha256').update('').digest('hex'),date=new Date(time*1000).toISOString().slice(0,10).replaceAll('-','');
 const signature=createHmac('sha256',secret).update(host+hash+date).digest('hex');
 return {Accept:'application/json','Content-Type':'application/json','X-Date':date,'X-Content-SHA256':hash,Authorization:`RG-HMAC-SHA256 SignedHeaders=host;x-content-sha256;x-date,Signature=${signature}`};
}
async function read(c:DirectCatalogueConfig,url:string,headers:Record<string,string>,signal:AbortSignal){
 const r=await(c.gameCatalogueFetch??fetch)(url,{method:'GET',headers,redirect:'error',signal});
 if(!r.ok||!/^application\/json(?:;|$)/i.test(r.headers.get('content-type')??'')){await r.body?.cancel();throw new CatalogueReadError(r.status);}
 const reader=r.body?.getReader();if(!reader)throw new CatalogueReadError(r.status);const parts:Uint8Array[]=[];let size=0;
 for(;;){const n=await reader.read();if(n.done)break;size+=n.value.length;if(size>2*1024*1024){await reader.cancel();throw new CatalogueReadError(r.status);}parts.push(n.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}
 let data;try{data=JSON.parse(new TextDecoder().decode(bytes));}catch{throw new CatalogueReadError(r.status);}if(!data||typeof data!=='object'||Array.isArray(data))throw new CatalogueReadError(r.status);return data;
}
async function rectangle(c:DirectCatalogueConfig,time:number,signal:AbortSignal){
 const u=new URL('/api/v1/available-games',c.rectangleApiBase);u.searchParams.set('oc',c.rectangleOperatorCode!);u.searchParams.set('l','en');
 const data=await read(c,u.href,rectangleCatalogueHeaders(u.hostname,c.rectangleApiKey!,time),signal);
 if(!Array.isArray(data.data)||data.data.length>maxGames)throw new CatalogueReadError(200);
 const seen=new Set<string>(),games=data.data.map((g:any)=>{
  if(!g||typeof g!=='object'||Array.isArray(g))throw new CatalogueReadError(200);
  const gameCode=identifier(g.code,100),name=title(g.name),category=g.type===undefined?'':title(g.type,40);
  if(!gameCode||!name||category===null||seen.has(gameCode))throw new CatalogueReadError(200);seen.add(gameCode);
  return {gameCode,name,category,maintenance:g.status!=='ACTIVE'};
 });
 return {games,complete:true};
}
async function godee(c:DirectCatalogueConfig,signal:AbortSignal){
 const base=c.godeeApiBase!,auth=await read(c,base+'/token',{Accept:'application/json','X-Operator':c.godeeOperatorId!,'X-Key':c.godeeApiKey!},signal);
 const token=auth.status==='success'?auth.data?.token:null;if(typeof token!=='string'||token.length<8||token.length>8192)throw new CatalogueReadError(200);
 const headers={Accept:'application/json','X-Token':token},providers:any[]=[],providerIds=new Set<string>();
 for(let page=1;page<=10;page++){
  const data=await read(c,base+`/game-providers?rows=100&page=${page}`,headers,signal);
  if(data.status!=='success'||!Array.isArray(data.data?.gameProviders))throw new CatalogueReadError(200);
  for(const provider of data.data.gameProviders){const providerId=identifier(provider?.id,12);if(!providerId||!/^[0-9]+$/.test(providerId)||providerIds.has(providerId))throw new CatalogueReadError(200);providerIds.add(providerId);providers.push(provider);}
  if(data.data.meta?.hasNext!==true)break;if(page===10)throw new CatalogueReadError(200);
 }
 const games:any[]=[],gameIds=new Set<string>();let complete=true;
 // The documented provider parameter is mandatory. Never substitute a global
 // games request or copy another merchant's customer or wallet identifiers.
 for(const p of providers.slice(0,40)){
  const providerId=identifier(p.id,12);if(!providerId||!/^[0-9]+$/.test(providerId))throw new CatalogueReadError(200);
  for(let page=1;page<=20;page++){
   const data=await read(c,base+`/games?provider=${providerId}&rows=100&page=${page}&locale=en`,headers,signal);
   if(data.status!=='success'||!Array.isArray(data.data?.games))throw new CatalogueReadError(200);
   for(const g of data.data.games){
    if(String(g.providerId)!==providerId)throw new CatalogueReadError(200);
   const originalGameCode=identifier(g.code??g.gameId??g.id,100),gameCode=originalGameCode?providerId+':'+originalGameCode:'';
   if(!originalGameCode||gameIds.has(gameCode))throw new CatalogueReadError(200);gameIds.add(gameCode);
   games.push({gameCode,originalProviderId:providerId,originalGameCode,name:title(g.name)??originalGameCode,providerName:title(p.name)??'Games',category:title(g.category,40)??'',maintenance:g.actived!==true||Number(g.disabled)!==0});
   }
   if(games.length>2000){complete=false;break;}
   if(data.data.meta?.hasNext!==true)break;if(page===20)complete=false;
  }
  if(games.length>2000)break;
 }
 if(providers.length>40)complete=false;
 return {games,complete};
}
export async function readDirectCatalogue(c:DirectCatalogueConfig,id:string,time:number){
 if(!directCatalogueConfigured(c,id))throw new CatalogueReadError(null);
 const signal=AbortSignal.timeout(18000);
 return id==='rectangle'?rectangle(c,time,signal):id==='godeezone'?godee(c,signal):Promise.reject(new CatalogueReadError(null));
}
