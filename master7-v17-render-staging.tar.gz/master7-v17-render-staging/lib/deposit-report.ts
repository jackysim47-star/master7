import {mytDateLabel,mytDateStart,mytDayStart} from './accounting.ts';

const groups=['credited','pending','failed','review','other'] as const;
type Group=typeof groups[number];
type Totals={orders:number;members:number;amountMinor:string};
type GroupTotals=Record<Group,Totals>;
type AggregateRow={provider?:string;state_group:Group;orders:number|string;members:number|string;amount_minor:string|number};

export class DepositReportInputError extends Error {}

function positiveInteger(value:string|null,fallback:number,maximum=Number.MAX_SAFE_INTEGER){
 if(value===null)return fallback;
 const number=Number(value);
 if(!/^[1-9]\d*$/.test(value)||!Number.isSafeInteger(number)||number>maximum)throw new DepositReportInputError('Invalid deposit report pagination');
 return number;
}

function emptyTotals():GroupTotals{
 return Object.fromEntries(groups.map(group=>[group,{orders:0,members:0,amountMinor:'0'}])) as GroupTotals;
}

function totals(row:AggregateRow):Totals{
 return {orders:Number(row.orders),members:Number(row.members),amountMinor:String(row.amount_minor)};
}

// Unknown payments are still awaiting confirmation, never settled cashflow.
const stateGroup="CASE WHEN d.status='credited' THEN 'credited' WHEN d.status IN ('pending','creating','created','unknown') THEN 'pending' WHEN d.status='failed' THEN 'failed' WHEN d.status='review' THEN 'review' ELSE 'other' END";
const aggregate="COUNT(*) orders,COUNT(DISTINCT d.user_id) members,CAST(COALESCE(SUM(d.amount_minor),0) AS TEXT) amount_minor";

export async function readDepositReport(db:D1Database,query:URLSearchParams,timestamp=Math.floor(Date.now()/1000)){
 const today=mytDateLabel(mytDayStart(timestamp)),scope=query.get('scope')??'day',date=query.get('date')??today,start=mytDateStart(date);
 if((scope!=='day'&&scope!=='all')||start===null)throw new DepositReportInputError('Use a valid MYT date (YYYY-MM-DD) and day or all scope');
 const requestedPage=positiveInteger(query.get('page'),1),pageSize=positiveInteger(query.get('pageSize'),100,250),end=start+86400;
 // These totals and UI are denominated in MYR. Never add another currency's
 // minor units to them, even if a future payment adapter shares this table.
 const where=scope==='day'?"WHERE d.currency='MYR' AND d.updated_at>=? AND d.updated_at<?":"WHERE d.currency='MYR'",values=scope==='day'?[start,end]:[];
 // Aggregates cover the full selection. Detail pagination never changes totals.
 // As in accounting, updated_at assigns a credited order to its settlement day;
 // other groups describe current states, not a historical end-of-day snapshot.
 const [grouped,providerGroups]=await Promise.all([
  db.prepare(`SELECT ${stateGroup} state_group,${aggregate} FROM deposit_orders d ${where} GROUP BY ${stateGroup}`).bind(...values).all<AggregateRow>(),
  db.prepare(`SELECT d.provider,${stateGroup} state_group,${aggregate} FROM deposit_orders d ${where} GROUP BY d.provider,${stateGroup} ORDER BY d.provider,state_group`).bind(...values).all<AggregateRow>(),
 ]);
 const summary=emptyTotals();
 for(const row of grouped.results??[])summary[row.state_group]=totals(row);
 const providers=new Map<string,{provider:string}&GroupTotals>();
 for(const row of providerGroups.results??[]){
  const provider=String(row.provider),entry=providers.get(provider)??{provider,...emptyTotals()};
  entry[row.state_group]=totals(row);providers.set(provider,entry);
 }
 const total=groups.reduce((sum,group)=>sum+summary[group].orders,0),totalPages=Math.max(1,Math.ceil(total/pageSize)),page=Math.min(requestedPage,totalPages),offset=(page-1)*pageSize;
 const records=await db.prepare(`SELECT d.id,d.user_id,u.username,d.provider,CAST(d.amount_minor AS TEXT) amount_minor,d.currency,d.status,d.provider_trade_no,d.created_at,d.updated_at FROM deposit_orders d LEFT JOIN users u ON u.id=d.user_id ${where} ORDER BY d.updated_at DESC,d.id DESC LIMIT ? OFFSET ?`).bind(...values,pageSize,offset).all<Record<string,unknown>>();
 return {
  readOnly:true,currency:'MYR',timezone:'Asia/Kuching',scope,date:scope==='day'?date:null,today,
  start:scope==='day'?start:null,end:scope==='day'?end:null,timestampBasis:'updated_at',statusMeaning:'current_status',generatedAt:timestamp,
  summary,providers:[...providers.values()],
  pagination:{total,page,pageSize,totalPages,hasMore:page*pageSize<total,hasPrevious:page>1},
  items:(records.results??[]).map(row=>({...row,amount_minor:String(row.amount_minor),created_at:Number(row.created_at),updated_at:Number(row.updated_at)})),
 };
}
