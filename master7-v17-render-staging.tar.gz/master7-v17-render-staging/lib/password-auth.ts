import { randomBytes, createHash, scryptSync, timingSafeEqual } from 'node:crypto';
import { Buffer } from 'node:buffer';
import { requestOriginAllowed } from './request-origin.ts';

export type PortalUser = {id:string;username:string;role:string;approved:number;csrf:string;created_at:number};
export type AuthConfig = {db:D1Database;ownerEmail:string;ownerLoginId?:string;allowedOrigins?:string[];ownerSetupHash?:string;ownerSetupExpires?:number;ownerResetHash?:string;ownerResetExpires?:number;ownerResetIssuedAt?:number};
type Credential = {username:string;user_id:string;salt:string;password_hash:string;version:number;changed_at:number};
export type LocalSession = {user:PortalUser;tokenHash:string;version:number};
export class AuthError extends Error {status:number;constructor(status:number,message:string){super(message);this.status=status;}}
const now=()=>Math.floor(Date.now()/1000);
const random=()=>randomBytes(32).toString('base64url');
const digest=(value:string)=>createHash('sha256').update(value).digest('hex');
const cookieName='__Host-master7_session';
const duration=8*60*60;
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Cookie, oai-authenticated-user-id'};
const json=(value:unknown,status=200,cookie?:string)=>new Response(JSON.stringify(value),{status,headers:{...headers,...(cookie?{'Set-Cookie':cookie}:{})}});
const cookie=(token:string,age=duration)=>`${cookieName}=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${age}`;
const deny=()=>new AuthError(401,'账号或密码不正确 / Incorrect ID or password');
function loginId(value:unknown){if(typeof value!=='string'||! /^[a-zA-Z0-9_]{4,32}$/.test(value))throw new AuthError(400,'ID 需为 4–32 位英文字母、数字或下划线');return value.toLowerCase();}
function password(value:unknown){if(typeof value!=='string'||[...value].length<15||[...value].length>128||new TextEncoder().encode(value).length>512)throw new AuthError(400,'密码需为 15–128 个字符 / Use 15–128 characters');return value;}
// Native scrypt: OWASP's 32 MiB configuration (N=2^15, r=8, p=3).
// Fixed parameters and bounded input prevent database-controlled work factors.
function hash(value:string,salt:string){return scryptSync(value,salt,32,{N:32768,r:8,p:3,maxmem:64*1024*1024}).toString('hex');}
function equal(a:string,b:string){return a.length===b.length&&timingSafeEqual(Buffer.from(a),Buffer.from(b));}
function verify(value:unknown,c:Credential|null){const input=typeof value==='string'&&value.length<=512?value:'';const actual=hash(input,c?.salt??'master7-dummy-comparison-salt');return !!c&&equal(actual,c.password_hash);}
async function payload(req:Request){if(!req.headers.get('content-type')?.startsWith('application/json'))throw new AuthError(415,'JSON required');const reader=req.body?.getReader();if(!reader)throw new AuthError(400,'Body required');let length=0;const parts:Uint8Array[]=[];for(;;){const part=await reader.read();if(part.done)break;length+=part.value.length;if(length>4096){await reader.cancel();throw new AuthError(413,'Request too large');}parts.push(part.value);}const out=new Uint8Array(length);let offset=0;for(const p of parts){out.set(p,offset);offset+=p.length;}try{const p=JSON.parse(new TextDecoder().decode(out));if(p&&typeof p==='object'&&!Array.isArray(p))return p;}catch{}throw new AuthError(400,'Invalid JSON');}
async function rate(db:D1Database,key:string,max:number,window=600){const timestamp=now();const id=`auth:${digest(key)}:${Math.floor(timestamp/window)}`;const r=await db.prepare('INSERT INTO rate_limits(id,count,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=rate_limits.count+1 RETURNING count').bind(id,timestamp+window*2).first<{count:number}>();if((r?.count??max+1)>max)throw new AuthError(429,'尝试过多，请 10 分钟后再试 / Try again in 10 minutes');await db.prepare('DELETE FROM rate_limits WHERE expires_at < ?').bind(timestamp).run();}
function audit(db:D1Database,id:string,event:string){return db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),id,event,'account',now());}
async function credential(db:D1Database,id:string){return db.prepare('SELECT * FROM password_credentials WHERE username=?').bind(id).first<Credential>();}
function origin(req:Request,allowedOrigins?:string[]){if(!requestOriginAllowed(req,allowedOrigins))throw new AuthError(403,'Origin denied');}
function csrf(req:Request,local:LocalSession|null){if(!local)throw new AuthError(401,'请先使用 MASTER7 ID 登录 / Sign in with your MASTER7 ID');if(req.headers.get('x-csrf-token')!==local.user.csrf)throw new AuthError(403,'CSRF denied');return local;}
export async function readLocalSession(req:Request,db:D1Database):Promise<LocalSession|null>{
 const token=(req.headers.get('cookie')??'').split(';').map(x=>x.trim()).find(x=>x.startsWith(cookieName+'='))?.slice(cookieName.length+1);
 if(!token||! /^[A-Za-z0-9_-]{43}$/.test(token))return null;
 const tokenHash=digest(token);
 const row=await db.prepare('SELECT u.*,c.username login_id,s.csrf session_csrf,s.credential_version FROM password_sessions s JOIN users u ON u.id=s.user_id JOIN password_credentials c ON c.user_id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND s.credential_version=c.version').bind(tokenHash,now()).first<PortalUser&{login_id:string;session_csrf:string;credential_version:number}>();
 return row?{user:{id:row.id,username:row.login_id,role:row.role,approved:row.approved,csrf:row.session_csrf,created_at:row.created_at},tokenHash,version:row.credential_version}:null;
}
async function session(db:D1Database,c:Credential){
 const token=random(),csrf=random(),timestamp=now();
 await db.batch([
  db.prepare('DELETE FROM password_sessions WHERE expires_at<=? OR (user_id=? AND token_hash NOT IN (SELECT token_hash FROM password_sessions WHERE user_id=? ORDER BY created_at DESC LIMIT 4))').bind(timestamp,c.user_id,c.user_id),
  db.prepare('INSERT INTO password_sessions(token_hash,user_id,csrf,credential_version,expires_at,created_at) VALUES(?,?,?,?,?,?)').bind(digest(token),c.user_id,csrf,c.version,timestamp+duration,timestamp)
 ]);
 return cookie(token);
}
export async function handlePasswordAuth(req:Request,c:AuthConfig,local:LocalSession|null):Promise<Response>{
 const path=new URL(req.url).pathname,db=c.db;
 if(req.method==='GET'&&path==='/api/auth/options'){
  const consumed=await db.prepare("SELECT id FROM settings WHERE id='owner_password_setup'").first();
  const resetUsed=c.ownerResetHash?await db.prepare('SELECT id FROM settings WHERE id=?').bind('owner_password_reset:'+c.ownerResetHash).first():null;
  return json({passwordLogin:true,ownerSetupComplete:!!consumed,ownerSetupAvailable:!!c.ownerSetupHash&&!!c.ownerSetupExpires&&c.ownerSetupExpires>now()&&!consumed,ownerResetAvailable:!!consumed&&!!c.ownerResetHash&&!!c.ownerResetIssuedAt&&!!c.ownerResetExpires&&c.ownerResetExpires>now()&&!resetUsed});
 }
 if(req.method!=='POST')throw new AuthError(405,'Method not allowed');
 origin(req,c.allowedOrigins);
 if(path==='/api/auth/logout'){
  const s=csrf(req,local);await db.prepare('DELETE FROM password_sessions WHERE token_hash=?').bind(s.tokenHash).run();return json({status:'ok'},200,cookie('',0));
 }
 const d=await payload(req);
 const ip=req.headers.get('cf-connecting-ip');
 await rate(db,'ip:'+(ip??'unavailable'),ip?30:120);
 if(path==='/api/auth/reset-owner'){
  await rate(db,'owner-reset:'+(ip??'unavailable'),5);
  if(!c.ownerResetHash||!c.ownerResetIssuedAt||!c.ownerResetExpires||c.ownerResetExpires<=now()||typeof d.code!=='string'||! /^[A-Za-z0-9_-]{43}$/.test(d.code)||!equal(digest(d.code),c.ownerResetHash))throw new AuthError(403,'重设码无效或已过期 / Invalid or expired reset code');
  const resetKey='owner_password_reset:'+c.ownerResetHash;
  if(await db.prepare('SELECT id FROM settings WHERE id=?').bind(resetKey).first())throw new AuthError(409,'重设码已使用，请使用新密码登录 / Reset code already used; sign in');
  const marker=await db.prepare("SELECT value FROM settings WHERE id='owner_password_setup'").first<{value:string}>();
  let ownerId:unknown;try{ownerId=marker?JSON.parse(marker.value).userId:null;}catch{}
  if(typeof ownerId!=='string'||!ownerId||ownerId.length>128)throw new AuthError(409,'老板账号尚未激活 / Owner account not activated');
  // Only the originally activated owner can be recovered. No request-supplied target is accepted.
  const found=await db.prepare("SELECT c.* FROM password_credentials c JOIN users u ON u.id=c.user_id WHERE c.user_id=? AND u.role='owner'").bind(ownerId).first<Credential>();
  if(!found)throw new AuthError(409,'老板账号不可重设，请联系站点所有者 / Owner account unavailable');
  if(found.changed_at>=c.ownerResetIssuedAt)throw new AuthError(409,'密码已更新，请申请新的重设码 / Password changed; request a new reset code');
  const pass=password(d.password),salt=random(),passwordHash=hash(pass,salt),timestamp=now();
  // Marker, credential update and session revocation commit atomically; replay loses the whole transaction.
  try{await db.batch([
   db.prepare('INSERT INTO settings(id,value) VALUES(?,(SELECT ? FROM password_credentials WHERE user_id=? AND version=?))').bind(resetKey,JSON.stringify({userId:ownerId,usedAt:timestamp}),ownerId,found.version),
   db.prepare('UPDATE password_credentials SET salt=?,password_hash=?,version=version+1,changed_at=? WHERE user_id=?').bind(salt,passwordHash,timestamp,ownerId),
   db.prepare('DELETE FROM password_sessions WHERE user_id=?').bind(ownerId),
   db.prepare('DELETE FROM rate_limits WHERE substr(id,1,70)=?').bind('auth:'+digest('login:'+found.username)+':'),
   audit(db,ownerId,'owner_password_reset')
  ]);}catch{if(await db.prepare('SELECT id FROM settings WHERE id=?').bind(resetKey).first())throw new AuthError(409,'重设码已使用，请使用新密码登录 / Reset code already used; sign in');throw new AuthError(503,'密码未重设，请稍后再试 / Password was not reset; try again later');}
  return json({status:'ok',username:found.username,signInAgain:true},200,cookie('',0));
 }
 if(path==='/api/auth/login'){
  let id:string;try{id=loginId(d.username);}catch{throw deny();}
  await rate(db,'login:'+id,10);
  const found=await credential(db,id);
  if(!verify(d.password,found))throw deny();
  return json({status:'ok'},200,await session(db,found!));
 }
 if(path==='/api/auth/activate'){
  if(!c.ownerSetupHash||!c.ownerSetupExpires||c.ownerSetupExpires<=now()||typeof d.code!=='string'||d.code.length!==43||!equal(digest(d.code),c.ownerSetupHash))throw new AuthError(403,'激活码无效或已过期 / Invalid or expired activation code');
  if(await db.prepare("SELECT id FROM settings WHERE id='owner_password_setup'").first())throw new AuthError(409,'此激活码已经使用，请直接登录 / Already activated; sign in');
  const username=loginId(c.ownerLoginId??'master7_owner'),pass=password(d.password);
  if(await credential(db,username))throw new AuthError(409,'账号已存在 / Account already exists');
  const existing=await db.prepare("SELECT id FROM users WHERE role='owner' AND lower(username)=lower(?) LIMIT 1").bind(c.ownerEmail).first<{id:string}>();
  const id=existing?.id??'local:'+crypto.randomUUID(),salt=random(),passwordHash=hash(pass,salt),timestamp=now();
  // The unique marker and all writes commit atomically. Two activation requests cannot both win.
  const statements=[db.prepare("INSERT INTO settings(id,value) VALUES('owner_password_setup',?)").bind(JSON.stringify({userId:id,activatedAt:timestamp}))];
  if(!existing)statements.push(db.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,?)').bind(id,username,'owner',1,random(),timestamp));
  statements.push(db.prepare('INSERT INTO password_credentials(username,user_id,salt,password_hash,version,changed_at) VALUES(?,?,?,?,1,?)').bind(username,id,salt,passwordHash,timestamp),audit(db,id,'owner_password_activated'));
  try{await db.batch(statements);}catch{throw new AuthError(409,'激活已完成或账号已存在，请直接登录 / Activation already completed');}
  return json({status:'ok',username},201);
 }
 if(path==='/api/auth/register'){
  await rate(db,'register:'+(ip??'unavailable'),ip?5:30);
  const username=loginId(d.username),pass=password(d.password);
  if(username===(c.ownerLoginId??'master7_owner').toLowerCase()||await credential(db,username))throw new AuthError(409,'此 ID 不可用 / ID unavailable');
  const id='local:'+crypto.randomUUID(),salt=random(),passwordHash=hash(pass,salt),timestamp=now();
  try{await db.batch([
   db.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,?)').bind(id,username,'member',0,random(),timestamp),
   db.prepare('INSERT INTO password_credentials(username,user_id,salt,password_hash,version,changed_at) VALUES(?,?,?,?,1,?)').bind(username,id,salt,passwordHash,timestamp),audit(db,id,'member_registered')
  ]);}catch{throw new AuthError(409,'此 ID 不可用 / ID unavailable');}
  return json({status:'ok',approvalRequired:true},201);
 }
 if(path==='/api/auth/change-password'){
  const s=csrf(req,local);await rate(db,'change:'+s.user.id,5);
  const found=await db.prepare('SELECT * FROM password_credentials WHERE user_id=?').bind(s.user.id).first<Credential>();
  if(!verify(d.currentPassword,found))throw deny();
  const pass=password(d.newPassword);if(d.currentPassword===pass)throw new AuthError(400,'新密码不能与原密码相同 / Choose a different password');
  const username=d.newUsername===undefined?found!.username:loginId(d.newUsername);
  if(username!==found!.username&&(username===(c.ownerLoginId??'master7_owner').toLowerCase()||await credential(db,username)))throw new AuthError(409,'此 ID 不可用 / ID unavailable');
  const salt=random(),passwordHash=hash(pass,salt);
  // Version compare prevents concurrent changes from restoring a stale credential.
  const updated=await db.prepare('UPDATE password_credentials SET username=?,salt=?,password_hash=?,version=version+1,changed_at=? WHERE user_id=? AND version=? RETURNING version').bind(username,salt,passwordHash,now(),s.user.id,s.version).first<{version:number}>();
  if(!updated)throw new AuthError(409,'账号已更新，请重新登录 / Sign in again');
  await db.batch([db.prepare('DELETE FROM password_sessions WHERE user_id=?').bind(s.user.id),db.prepare('UPDATE users SET username=? WHERE id=?').bind(username,s.user.id),audit(db,s.user.id,'password_changed')]);
  return json({status:'ok',signInAgain:true,username},200,cookie('',0));
 }
 throw new AuthError(404,'Not found');
}
