/** Implementations must come from an account-specific, verified supplier
 * contract. A browser closing or a generic kick acknowledgement is insufficient. */
export type MegaClosureInput={walletSessionId:string;launchOperationId:string;providerPlayerId:string;gameCode:string};
export type MegaClosureReceipt=MegaClosureInput&{providerClosureReference:string;allIssuedLaunchesInvalidated:true;pendingRounds:0;lateResultsFinal:true};
export type MegaSessionCloser=(input:MegaClosureInput)=>Promise<{state:'closed';receipt:MegaClosureReceipt}|{state:'playing'|'unknown'}>;
export type MegaAcceptanceCapabilities={catalogue:boolean;launch:boolean;wallet:boolean;settlement:boolean;recovery:boolean};
export const MEGA_CLOSURE_EVENT='megah5_session_closed';

export function megaClosureProofSql(alias:'o'|'closed_launch'){
 return `EXISTS(SELECT 1 FROM audit closure_audit WHERE closure_audit.user_id=${alias}.user_id AND closure_audit.event='${MEGA_CLOSURE_EVENT}' AND closure_audit.target LIKE ${alias}.wallet_session_id||':'||${alias}.id||':%' AND LENGTH(closure_audit.target)=LENGTH(${alias}.wallet_session_id)+LENGTH(${alias}.id)+66)`;
}

export function validMegaClosureReceipt(input:MegaClosureInput,value:unknown):value is MegaClosureReceipt{
 if(!value||typeof value!=='object')return false;
 const r=value as Record<string,unknown>;
 return r.walletSessionId===input.walletSessionId&&r.launchOperationId===input.launchOperationId&&r.providerPlayerId===input.providerPlayerId&&r.gameCode===input.gameCode&&typeof r.providerClosureReference==='string'&&/^[A-Za-z0-9_.:-]{1,200}$/.test(r.providerClosureReference)&&r.allIssuedLaunchesInvalidated===true&&r.pendingRounds===0&&r.lateResultsFinal===true;
}
