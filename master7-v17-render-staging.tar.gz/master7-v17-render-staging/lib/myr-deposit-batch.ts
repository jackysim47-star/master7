import { randomUUID } from 'node:crypto';
import { PAYMENT_ACCEPTANCE_CAPABILITIES, type getProductionAcceptanceReadiness } from './production-acceptance.ts';

export const MYR_DEPOSIT_PROFILES = {
 vpay: 'vpay_myr', gspay: 'gspay_myr', '1mpay': 'onempay_myr',
} as const;
export type MyrDepositProvider = keyof typeof MYR_DEPOSIT_PROFILES;
export const MYR_DEPOSIT_PROVIDERS = Object.keys(MYR_DEPOSIT_PROFILES) as MyrDepositProvider[];
type Acceptance = Awaited<ReturnType<typeof getProductionAcceptanceReadiness>>;
type BatchProviders = Record<MyrDepositProvider, boolean>;
type DepositControls = Record<MyrDepositProvider, 'auto' | 'paused'>;

export function isMyrDepositProvider(value: unknown): value is MyrDepositProvider {
 return typeof value === 'string' && Object.hasOwn(MYR_DEPOSIT_PROFILES, value);
}

export function myrDepositEvidence(acceptance: Acceptance) {
 const providers = {} as BatchProviders;
 for (const provider of MYR_DEPOSIT_PROVIDERS) {
  const profile = acceptance.requirements.find(item => item.category === 'payment' && item.subjectId === MYR_DEPOSIT_PROFILES[provider]);
  const records = PAYMENT_ACCEPTANCE_CAPABILITIES.map(capability => profile?.capabilities[capability]);
  const first = records[0];
  providers[provider] = !!first?.evidenceReference && !!first.evidenceSha256 && records.every(record =>
   record?.passed === true && record.evidenceReference === first.evidenceReference && record.evidenceSha256 === first.evidenceSha256);
 }
 const credentialIds = ['vpay', 'gspay_myr', '1mpay'];
 const credentialsReady = credentialIds.every(id =>
  acceptance.requirements.find(item => item.category === 'credential' && item.subjectId === id)?.capabilities.rotated?.passed === true);
 return {
  providers,
  passedCount: MYR_DEPOSIT_PROVIDERS.filter(provider => providers[provider]).length,
  releaseReady: acceptance.primaryIntegrityReady && acceptance.domainReady && credentialsReady && acceptance.signoffReady,
 };
}

export function myrDepositBatchStatus(
 evidence: ReturnType<typeof myrDepositEvidence>, ordersEnabled: boolean, controls: DepositControls, runtime: BatchProviders,
) {
 const paused = !ordersEnabled || MYR_DEPOSIT_PROVIDERS.some(provider => controls[provider] === 'paused');
 const ready = evidence.passedCount === MYR_DEPOSIT_PROVIDERS.length && evidence.releaseReady;
 const open = !paused && ready && MYR_DEPOSIT_PROVIDERS.every(provider => runtime[provider]);
 const state = paused ? 'paused' : open ? 'open' : 'waiting';
 const reason = paused ? 'myr_batch_paused' : open ? 'myr_batch_open'
  : evidence.passedCount < MYR_DEPOSIT_PROVIDERS.length ? 'myr_batch_acceptance_pending'
  : !evidence.releaseReady ? 'myr_batch_signoff_pending' : 'myr_batch_runtime_pending';
 return { state, reason, open, total: MYR_DEPOSIT_PROVIDERS.length, passedCount: evidence.passedCount, providers: evidence.providers };
}
export type MyrDepositBatchStatus = ReturnType<typeof myrDepositBatchStatus>;

const ALLOWED_TEST_CODES = ['1', '2', '3', '4', '5', '7'];
const MAX_TEST_SECONDS = 3600;
const allowedMember = /^[A-Za-z0-9:_-]{3,100}$/;
const allowedEvidence = /^[A-Za-z0-9][A-Za-z0-9._:/#-]{0,199}$/;
type TestGrant = {
 memberId: string; requestKey: string; amountMinor: string; expiresAt: number;
 evidenceReference: string; tradeCode?: string;
};

export class MyrDepositTestError extends Error {
 readonly status: number;
 constructor(status: number, message: string) {
  super(message);
  this.status = status;
 }
}

function grantKey(provider: MyrDepositProvider) { return `myr_deposit_test:${provider}`; }

export async function saveMyrDepositTest(
 db: D1Database, ownerId: string, input: Record<string, unknown>, now: number,
) {
 const provider = input.providerId;
 if (!isMyrDepositProvider(provider)) throw new MyrDepositTestError(400, 'Invalid MYR deposit provider');
 if (input.revoke === true) {
  if (Object.keys(input).length !== 2) throw new MyrDepositTestError(400, 'Invalid test revocation');
  await db.batch([
   db.prepare('DELETE FROM settings WHERE id=?').bind(grantKey(provider)),
   db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)')
    .bind(randomUUID(), ownerId, 'myr_deposit_test_revoked', provider, now),
  ]);
  return { providerId: provider, revoked: true };
 }

 const { memberId, amountMinor, expiresAt, evidenceReference, tradeCode } = input;
 const knownFields = ['providerId', 'memberId', 'amountMinor', 'expiresAt', 'evidenceReference', 'tradeCode'];
 if (Object.keys(input).some(key => !knownFields.includes(key))
     || typeof memberId !== 'string' || !allowedMember.test(memberId)
     || typeof amountMinor !== 'string' || !/^[1-9]\d{0,7}$/.test(amountMinor) || Number(amountMinor) > 10_000_000
     || typeof expiresAt !== 'number' || !Number.isSafeInteger(expiresAt) || expiresAt <= now || expiresAt > now + MAX_TEST_SECONDS
     || typeof evidenceReference !== 'string' || !allowedEvidence.test(evidenceReference)
     || (provider === 'vpay' ? typeof tradeCode !== 'string' || !ALLOWED_TEST_CODES.includes(tradeCode) : tradeCode !== undefined)) {
  throw new MyrDepositTestError(400, 'Invalid MYR deposit test scope');
 }
 const member = await db.prepare("SELECT id FROM users WHERE id=? AND role='member' AND approved=1").bind(memberId).first<{ id: string }>();
 if (!member) throw new MyrDepositTestError(400, 'Test member must be an approved member');
 const grant: TestGrant = { memberId, amountMinor, expiresAt, evidenceReference, requestKey: `myr-test-${randomUUID()}`,
  ...(typeof tradeCode === 'string' ? { tradeCode } : {}) };
 await db.batch([
  db.prepare('INSERT INTO settings(id,value) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value')
   .bind(grantKey(provider), JSON.stringify(grant)),
  db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)')
   .bind(randomUUID(), ownerId, 'myr_deposit_test_granted', `${provider}:${evidenceReference}`, now),
 ]);
 return { providerId: provider, currency: 'MYR', ...grant };
}

export async function myrDepositTestAllowed(
 db: D1Database, provider: MyrDepositProvider, memberId: string, input: Record<string, unknown>, amountMinor: string | null, now: number,
) {
 if (typeof input.requestKey !== 'string' || !/^myr-test-[0-9a-f-]{36}$/.test(input.requestKey) || !amountMinor) return false;
 const row = await db.prepare('SELECT value FROM settings WHERE id=?').bind(grantKey(provider)).first<{ value: string }>();
 if (!row) return false;
 let grant: TestGrant;
 try { grant = JSON.parse(row.value); } catch { return false; }
 return !!grant && grant.memberId === memberId && grant.requestKey === input.requestKey && grant.amountMinor === amountMinor
  && Number.isSafeInteger(grant.expiresAt) && grant.expiresAt > now && grant.expiresAt <= now + MAX_TEST_SECONDS
  && (provider !== 'vpay' || grant.tradeCode === input.tradeCode);
}
