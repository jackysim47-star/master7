import { createHash, timingSafeEqual } from 'node:crypto';
import { withdrawalWalletState } from './withdrawals.ts';
import {PaymentRequestError,recordPaymentDiagnostic,safeProviderCode,paymentUrlHost} from './payment-diagnostics.ts';

type Member = { id: string; username: string; role: string; approved: number; csrf: string };
export type VPayContext = {
  db: D1Database;
  user: Member | null;
  gatewayUrl?: string;
  orderToken?: string;
  queryToken?: string;
  callbackToken?: string;
  enabled?: string;
  mode?: string;
  vpayTraderId?: string;
  returnUrl?: string;
  fetchImpl?: typeof fetch;
};

const gatewayOrigin = 'https://master7-integration-gateway.onrender.com';
const callbackUrl = gatewayOrigin + '/callbacks/vpay/payment';
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
const text = (body: string, status = 200) => new Response(body, { status, headers: { 'Cache-Control': 'no-store', 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' } });
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
const tokenReady = (value?: string) => typeof value === 'string' && Buffer.byteLength(value) >= 32 && Buffer.byteLength(value) <= 1024;
const equal = (left: string, right: string) => {
  const a = Buffer.from(left), b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
};
function enabled(c: VPayContext) {
  const gateway = c.gatewayUrl === gatewayOrigin;
  const tokens = tokenReady(c.orderToken) && tokenReady(c.queryToken) && tokenReady(c.callbackToken)
    && new Set([c.orderToken, c.queryToken, c.callbackToken]).size === 3;
  let returnUrl = false;
  try {
    const u = new URL(c.returnUrl ?? '');
    returnUrl = u.protocol === 'https:' && u.hostname === 'master7-v17-staging.onrender.com' && u.pathname === '/payment/return' && !u.username && !u.password && !u.port && !u.search && !u.hash;
  } catch {}
  return gateway && tokens && returnUrl && c.mode === 'uat' && typeof c.vpayTraderId === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(c.vpayTraderId);
}
function orderEnabled(c: VPayContext) { return enabled(c) && c.enabled === 'true'; }
export const vpayOrdersConfigured = orderEnabled;

async function payload(req: Request, limit = 8192): Promise<Record<string, unknown>> {
  if (!req.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw Error('JSON_REQUIRED');
  const reader = req.body?.getReader(); if (!reader) throw Error('BODY_REQUIRED');
  const chunks: Uint8Array[] = []; let size = 0;
  for (;;) { const part = await reader.read(); if (part.done) break; size += part.value.length; if (size > limit) { await reader.cancel(); throw Error('BODY_TOO_LARGE'); } chunks.push(part.value); }
  const bytes = new Uint8Array(size); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  let value: unknown; try { value = JSON.parse(new TextDecoder().decode(bytes)); } catch { throw Error('INVALID_JSON'); }
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('INVALID_OBJECT');
  return value as Record<string, unknown>;
}

async function gatewayJson(c: VPayContext, path: string, token: string, method = 'GET', body?: unknown) {
  const fetcher = c.fetchImpl ?? fetch, controller = new AbortController(), timer = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetcher(new URL(path, gatewayOrigin), { method, redirect: 'error', signal: controller.signal,
      headers: { Accept: 'application/json', Authorization: `Bearer ${token}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {}) });
    if (response.redirected || response.url && response.url !== new URL(path, gatewayOrigin).href || !/^application\/json(?:;|$)/i.test(response.headers.get('content-type') ?? '')) { await response.body?.cancel(); throw new PaymentRequestError({kind:'GATEWAY_RESPONSE',httpStatus:response.status}); }
    const raw = await response.text(); if (raw.length > 65536) throw Error('GATEWAY_RESPONSE_TOO_LARGE');
    const value = JSON.parse(raw); if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('GATEWAY_RESPONSE_INVALID');
    if(!response.ok){const v=value as Record<string,any>,upstream=Number(v.upstreamStatus),allowed=['unauthorized','vpay_orders_disabled','invalid_vpay_order','vpay_payment_configuration_incomplete','upstream_timeout','internal_error'];throw new PaymentRequestError({kind:'GATEWAY_HTTP',httpStatus:response.status,...(Number.isInteger(upstream)&&upstream>=100&&upstream<600?{upstreamStatus:upstream}:{}),providerCode:safeProviderCode(v.result?.code),gatewayError:allowed.includes(v.error)?v.error:undefined});}
    return value as Record<string, any>;
  } finally { clearTimeout(timer); }
}

const amountMinor = (value: unknown) => {
  if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
  if (typeof value !== 'string' || !/^(0|[1-9]\d{0,6})(?:\.(\d{1,2}))?$/.test(value)) return null;
  const [whole, fraction = ''] = value.split('.'); const minor = BigInt(whole) * BigInt(100) + BigInt(fraction.padEnd(2, '0'));
  return minor > BigInt(0) && minor <= BigInt(10000000) ? minor.toString() : null;
};
const amountString = (minor: string) => `${BigInt(minor) / BigInt(100)}.${(BigInt(minor) % BigInt(100)).toString().padStart(2, '0')}`;
const opaque = (value: unknown, max = 128): string | null => typeof value === 'string' && value.length > 0 && value.length <= max && /^[A-Za-z0-9_-]+$/.test(value) ? value : null;
const safePaymentUrl = (value: unknown) => {
  try { const u = new URL(String(value)); return u.protocol === 'https:' && u.origin === 'https://payment.vpay.club' && u.pathname !== '/' && !u.username && !u.password && !u.port && !u.hash ? u.href : ''; } catch { return ''; }
};

export async function handleVPay(req: Request, c: VPayContext): Promise<Response | null> {
  const path = new URL(req.url).pathname;
  if (path === '/api/payment-callbacks/vpay/payment' && req.method === 'GET') {
    const supplied = req.headers.get('authorization') ?? '';
    if (!enabled(c) || !tokenReady(c.callbackToken) || !supplied.startsWith('Bearer ') || !equal(supplied.slice(7), c.callbackToken!)) return text('UNAUTHORIZED', 401);
    return json({ provider: 'vpay', callbackReady: true, scope: 'handler-configuration-only' });
  }
  if (path === '/api/payment-callbacks/vpay/payment' && req.method === 'POST') return callback(req, c);
  if (path === '/api/payments/vpay/status' && req.method === 'GET') {
    const channel = await c.db.prepare('SELECT status FROM payment_channel_controls WHERE provider_id=?').bind('vpay').first<{status:string}>();
    const channelStatus = channel?.status ?? 'suspended';
    if (channelStatus !== 'active') return json({ provider: 'vpay', currency: 'MYR', enabled: false, mode: 'disabled', channelStatus, tradeCodes: [], realPayments: false, liveReady: false });
    if (!orderEnabled(c)) return json({ provider: 'vpay', currency: 'MYR', enabled: false, mode: 'disabled', tradeCodes: [], realPayments: false, liveReady: false });
    try {
      const config = await gatewayJson(c, '/platform/vpay/config', c.queryToken!);
      const ready = config.provider === 'vpay' && config.mode === 'uat' && config.paymentReady === true
        && config.traderId === c.vpayTraderId && config.notifyUrl === callbackUrl && config.returnUrl === c.returnUrl
        && Array.isArray(config.tradeCodes);
      const tradeCodes = ready ? [...new Set(config.tradeCodes.filter((code: unknown) => ['1', '2', '3', '4', '5', '7'].includes(String(code))).map(String))] : [];
      return json({ provider: 'vpay', currency: 'MYR', enabled: ready && tradeCodes.length > 0, mode: ready ? 'uat' : 'disabled', channelStatus, tradeCodes: ready ? tradeCodes : [], realPayments: false, liveReady: false });
    } catch {
      return json({ provider: 'vpay', currency: 'MYR', enabled: false, mode: 'disabled', tradeCodes: [], realPayments: false, liveReady: false });
    }
  }
  if (path === '/api/wallet' && req.method === 'GET') {
    if (!c.user) return json({ error: 'Sign in required' }, 401);
    if (c.user.role !== 'member') return json({ error: 'Member account required' }, 403);
    if (!c.user.approved) return json({ error: 'Account awaiting approval' }, 403);
    const wallet = await withdrawalWalletState(c.db,c.user.id);
    return json({ currency: 'MYR', ...wallet, providerTransactionsEnabled: false });
  }
  if (path === '/api/payment-records' && req.method === 'GET') {
    if (!c.user) return json({ error: 'Sign in required' }, 401);
    if (c.user.role !== 'member') return json({ error: 'Member account required' }, 403);
    const records = await c.db.prepare('SELECT id,provider,request_key,amount_minor,currency,status,provider_trade_no,created_at,updated_at FROM deposit_orders WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 100').bind(c.user.id).all();
    return json({ items: records.results ?? [] });
  }
  if (path === '/api/admin/deposits' && req.method === 'GET') {
    if (!c.user) return json({ error: 'Sign in required' }, 401);
    if (c.user.role !== 'owner') return json({ error: 'Access denied' }, 403);
    const day=Math.floor((Math.floor(Date.now()/1000)+28800)/86400)*86400-28800;
    const records = await c.db.prepare('SELECT d.id,d.user_id,u.username,d.provider,d.amount_minor,d.currency,d.status,d.provider_trade_no,d.created_at,d.updated_at FROM deposit_orders d JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC,d.id DESC LIMIT 500').all();
    const today=await c.db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount_minor FROM deposit_orders WHERE status='credited' AND updated_at>=?").bind(day).first<any>();
    return json({ items: records.results ?? [], readOnly:true, summary:{membersToday:today?.members??0,ordersToday:today?.orders??0,amountMinorToday:String(today?.amount_minor??0)} });
  }
  return null;
}

export async function createVPayOrder(d: Record<string, unknown>, c: VPayContext): Promise<Response> {
  const u = c.user;
  if (!u) return json({ error: 'Sign in required' }, 401);
  if (u.role !== 'member') return json({ error: 'Member account required' }, 403);
  if (!u.approved) return json({ error: 'Account awaiting approval' }, 403);
  const channel = await c.db.prepare('SELECT status FROM payment_channel_controls WHERE provider_id=?').bind('vpay').first<{status:string}>();
  if (channel?.status !== 'active') return json({ error: 'VPAY_CHANNEL_NOT_ACTIVE' }, 503);
  if (!orderEnabled(c)) return json({ error: 'VPAY_UAT_NOT_CONFIGURED' }, 503);
  const amount = amountMinor(d.amount), requestKey = typeof d.requestKey === 'string' && /^[A-Za-z0-9_-]{16,80}$/.test(d.requestKey) ? d.requestKey : '';
  const tradeCode = typeof d.tradeCode === 'string' && ['1', '2', '3', '4', '5', '7'].includes(d.tradeCode) ? d.tradeCode : '';
  const payerName = typeof d.payerName === 'string' && d.payerName.trim().length >= 1 && d.payerName.trim().length <= 30 && !/[\u0000-\u001f\u007f-\u009f]/u.test(d.payerName) ? d.payerName.trim() : '';
  if (!amount || !requestKey || !tradeCode || !payerName) return json({ error: 'Invalid MYR order' }, 400);
  const config = await gatewayJson(c, '/platform/vpay/config', c.queryToken!);
  if (config.provider !== 'vpay' || config.mode !== 'uat' || config.paymentReady !== true || config.traderId !== c.vpayTraderId || !Array.isArray(config.tradeCodes) || !config.tradeCodes.includes(tradeCode) || config.notifyUrl !== callbackUrl || config.returnUrl !== c.returnUrl) return json({ error: 'VPAY_GATEWAY_NOT_READY' }, 503);
  const fingerprint = digest(JSON.stringify({ amount, tradeCode, payerName, currency: 'MYR', mode: 'uat' }));
  const id = crypto.randomUUID(), timestamp = Math.floor(Date.now() / 1000);
  await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,? ,?,'MYR',?,'pending',?,?) ON CONFLICT(user_id,request_key) DO NOTHING")
    .bind(id, u.id, requestKey, fingerprint, 'vpay', amount, tradeCode, timestamp, timestamp).run();
  const order = await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(u.id, requestKey).first<any>();
  if (!order) return json({ error: 'Order unavailable' }, 503);
  if (order.fingerprint !== fingerprint) return json({ error: 'IDEMPOTENCY_CONFLICT' }, 409);
  if (order.status === 'created' && order.checkout_url) return json({ id: order.id, status: 'awaiting_payment', payUrl: order.checkout_url, expiresAt: order.expires_at_raw }, 200);
  if (order.status !== 'pending') return json({ id: order.id, status: order.status === 'credited' ? 'credited' : 'awaiting_confirmation', payUrl: null }, 202);
  const claim = await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(timestamp, order.id).first();
  if (!claim) return json({ id: order.id, status: 'awaiting_confirmation', payUrl: null }, 202);
  try {
    const created = await gatewayJson(c, '/platform/vpay/order', c.orderToken!, 'POST', { outTradeNo: order.id, title: 'MASTER7 deposit', amount: amountString(amount), tradeCode, payerName, notifyUrl: config.notifyUrl, callbackUrl: config.returnUrl });
    const envelope = created.result;
    const data = envelope?.data;
    const payUrl = safePaymentUrl(data?.pay_url);
    const reference=opaque(data?.trade_no),success=created.provider==='vpay'&&(envelope?.code===0||envelope?.code==='0');
    let bound=String(data?.trader_id)===String(config.traderId)&&data?.out_trade_no===order.id&&amountMinor(data?.amount)===amount&&(!data?.currency||data.currency==='MYR');
    if(success&&reference&&payUrl&&!bound){
      try{const reply=await gatewayJson(c,'/platform/vpay/order-query',c.queryToken!,'POST',{outTradeNo:order.id,tradeNo:reference}),v=reply.result?.data;bound=reply.provider==='vpay'&&(reply.result?.code===0||reply.result?.code==='0')&&v?.out_trade_no===order.id&&v?.trade_no===reference&&amountMinor(v?.amount)===amount&&(!v?.trader_id||String(v.trader_id)===String(config.traderId))&&(!v?.currency||v.currency==='MYR');}
      catch(error){if(error instanceof PaymentRequestError)throw new PaymentRequestError({...error.facts,providerTradeNo:reference});throw error;}
    }
    if(!success||!reference||!payUrl||!bound)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerCode:safeProviderCode(envelope?.code),providerTradeNo:reference??undefined,checkoutHost:paymentUrlHost(data?.pay_url),missing:[...(!reference?['providerTradeNo']:[]),...(!payUrl?['checkoutUrl']:[]),...(!bound?['verifiedOrderBinding']:[])]});
    const expiry=typeof data.expired_time==='string'&&data.expired_time.length<=64?data.expired_time:typeof data.expired_time==='number'&&Number.isFinite(data.expired_time)?String(data.expired_time):null;
    await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,expires_at_raw=?,updated_at=? WHERE id=? AND status='creating'").bind(reference, payUrl, expiry, Math.floor(Date.now() / 1000), order.id).run();
    return json({ id: order.id, status: 'awaiting_payment', payUrl, expiresAt: expiry }, 201);
  } catch(error) {
    await c.db.prepare("UPDATE deposit_orders SET status='unknown',updated_at=? WHERE id=? AND status='creating'").bind(Math.floor(Date.now() / 1000), order.id).run();
    await recordPaymentDiagnostic(c.db,u.id,'vpay',order.id,error);
    return json({ id: order.id, status: 'awaiting_confirmation', payUrl: null }, 202);
  }
}

async function callback(req: Request, c: VPayContext): Promise<Response> {
  const supplied = req.headers.get('authorization') ?? '';
  if (!enabled(c) || !tokenReady(c.callbackToken) || !supplied.startsWith('Bearer ') || !equal(supplied.slice(7), c.callbackToken!)) return text('UNAUTHORIZED', 401);
  let d: Record<string, unknown>; try { d = await payload(req); } catch { return text('INVALID', 400); }
  const orderId = opaque(d.out_trade_no, 50), tradeNo = opaque(d.trade_no), callbackAmount = amountMinor(d.amount);
  if (!orderId || !tradeNo || !callbackAmount || String(d.trader_id) !== c.vpayTraderId) return text('INVALID', 400);
  const order = await c.db.prepare('SELECT * FROM deposit_orders WHERE id=? AND provider=?').bind(orderId, 'vpay').first<any>();
  if (!order) return text('UNKNOWN_ORDER', 404);
  if (order.status === 'credited') return await verifyLedger(c, order) ? text('SUCCESS') : text('LEDGER_REVIEW', 503);
  if (String(order.amount_minor) !== callbackAmount || (order.provider_trade_no && order.provider_trade_no !== tradeNo) || String(d.state) !== '3') {
    await c.db.batch([
      c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=?").bind(tradeNo, Math.floor(Date.now() / 1000), orderId),
      c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(), order.user_id, 'deposit_callback_review', orderId, Math.floor(Date.now() / 1000)),
    ]);
    return text('REVIEW_REQUIRED', 502);
  }
  const queried = await gatewayJson(c, '/platform/vpay/order-query', c.queryToken!, 'POST', { outTradeNo: orderId, tradeNo });
  const envelope = queried.result;
  const verified = envelope?.data;
  if (queried.provider !== 'vpay' || (envelope?.code !== 0 && envelope?.code !== '0') || verified?.out_trade_no !== orderId || verified?.trade_no !== tradeNo
    || amountMinor(verified?.amount) !== callbackAmount || String(verified?.state) !== '3' || verified?.trader_id && String(verified.trader_id) !== c.vpayTraderId) return text('PENDING', 502);
  const timestamp = Math.floor(Date.now() / 1000);
  await c.db.batch([
    c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES(?,?,?,?,?,'MYR',?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(), orderId, order.user_id, 'member', callbackAmount, timestamp),
    c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES(?,?,?,?,?,'MYR',?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(), orderId, order.user_id, 'provider_clearing', (-BigInt(callbackAmount)).toString(), timestamp),
    c.db.prepare("UPDATE deposit_orders SET status='credited',provider_trade_no=?,updated_at=? WHERE id=? AND status!='credited'").bind(tradeNo, timestamp, orderId),
    c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(), order.user_id, 'deposit_credited', orderId, timestamp),
  ]);
  return await verifyLedger(c, order) ? text('SUCCESS') : text('LEDGER_REVIEW', 503);
}

async function verifyLedger(c: VPayContext, order: any) {
  const rows = await c.db.prepare('SELECT account_code,amount_minor,currency FROM wallet_ledger WHERE order_id=?').bind(order.id).all<any>();
  const entries = rows.results ?? [];
  const member = entries.find((x: any) => x.account_code === 'member'), clearing = entries.find((x: any) => x.account_code === 'provider_clearing');
  return entries.length === 2 && member?.currency === 'MYR' && clearing?.currency === 'MYR' && String(member?.amount_minor) === String(order.amount_minor) && BigInt(clearing?.amount_minor ?? 0) === -BigInt(order.amount_minor) && BigInt(member?.amount_minor ?? 0) + BigInt(clearing?.amount_minor ?? 0) === BigInt(0);
}
