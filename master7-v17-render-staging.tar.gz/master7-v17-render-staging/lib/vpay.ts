import {walletGuardStatements} from './wallet-guard.ts';
import { createHash, timingSafeEqual } from 'node:crypto';
import { withdrawalWalletState } from './withdrawals.ts';
import {PaymentRequestError,definitivePaymentRejection,reconcileHistoricalPaymentRejections,recordPaymentDiagnostic,safeProviderCode,paymentUrlHost} from './payment-diagnostics.ts';
import {automaticDepositCapability,automaticPaymentStatus,paymentCapability} from './payment-capabilities.ts';
import {vpayPayoutCapabilitySnapshot} from './vpay-payout.ts';
import {claimPaymentRecovery,escalateExhaustedPaymentRecoveries,finishPaymentRecovery,recoveryCandidates} from './payment-recovery.ts';
import {DepositReportInputError,readDepositReport} from './deposit-report.ts';
import {readDepositTrace} from './deposit-trace.ts';
import {matchesCustomerPortalEndpoint,stagingPortalOrigin} from './portal-origin.mjs';

type Member = { id: string; username: string; role: string; approved: number; csrf: string };
export type VPayContext = {
  db: D1Database;
  user: Member | null;
  gatewayUrl?: string;
  orderToken?: string;
  queryToken?: string;
  callbackToken?: string;
  payoutToken?: string;
  balanceToken?: string;
  balanceEnabled?: string;
  payoutEnabled?: string;
  newPayoutsEnabled?: string;
  withdrawalDataKey?: string;
  enabled?: string;
  newDepositsEnabled?: string;
  mode?: string;
  vpayTraderId?: string;
  portalOrigins?: string[];
  returnUrl?: string;
  recoveryEnabled?: string;
  uatMemberId?: string;
  uatOrderId?: string;
  uatAmountMinor?: string;
  uatTradeCode?: string;
  uatExpiresAt?: string;
  acceptance?: {realPaymentVerified:boolean;settlementVerified:boolean};
  fetchImpl?: typeof fetch;
};

const gatewayOrigin = 'https://master7-integration-gateway.onrender.com';
const uatGatewayOrigin = 'https://master7-payment-uat.onrender.com';
function resolveGatewayOrigin(c:VPayContext):string|null {
  if(c.gatewayUrl===gatewayOrigin)return gatewayOrigin;
  // A separate exact origin is allowed only for the isolated Staging UAT
  // context. Never accept arbitrary URLs or route a production portal to UAT.
  const stagingOnly=c.portalOrigins===undefined||Array.isArray(c.portalOrigins)
    &&c.portalOrigins.length>0&&c.portalOrigins.every(origin=>origin===stagingPortalOrigin);
  return c.gatewayUrl===uatGatewayOrigin&&c.mode==='uat'&&stagingOnly
    &&c.returnUrl===stagingPortalOrigin+'/payment/return'?uatGatewayOrigin:null;
}
const gatewayCallbackUrl=(c:VPayContext)=>{
  const origin=resolveGatewayOrigin(c);return origin?origin+'/callbacks/vpay/payment':null;
};
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
const text = (body: string, status = 200) => new Response(body, { status, headers: { 'Cache-Control': 'no-store', 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' } });
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
const tokenReady = (value?: string) => typeof value === 'string' && Buffer.byteLength(value) >= 32 && Buffer.byteLength(value) <= 1024;
const equal = (left: string, right: string) => {
  const a = Buffer.from(left), b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
};
function enabled(c: VPayContext) {
  const gateway = resolveGatewayOrigin(c)!==null;
  const tokens = tokenReady(c.orderToken) && tokenReady(c.queryToken) && tokenReady(c.callbackToken)
    && new Set([c.orderToken, c.queryToken, c.callbackToken]).size === 3;
  const returnUrl = matchesCustomerPortalEndpoint(c.returnUrl, c.portalOrigins, '/payment/return');
  return gateway && tokens && returnUrl && (c.mode === 'uat' || c.mode === 'production') && typeof c.vpayTraderId === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(c.vpayTraderId);
}
function orderEnabled(c: VPayContext) { return enabled(c) && c.enabled === 'true' && c.newDepositsEnabled === 'true'; }
export const vpayOrdersConfigured = enabled;

function balanceConfigured(c:VPayContext){
 const peers=[c.orderToken,c.queryToken,c.callbackToken,c.payoutToken].filter(tokenReady);
 return resolveGatewayOrigin(c)!==null&&tokenReady(c.balanceToken)&&!peers.includes(c.balanceToken);
}

function vpayUatOrderScope(c:VPayContext,u:Member,amount:string,tradeCode:string){
 const required=resolveGatewayOrigin(c)===uatGatewayOrigin&&c.mode==='uat';
 if(!required)return {required:false,ready:true,orderId:crypto.randomUUID(),expiresAt:null as number|null,gatewayMemberId:null as string|null};
 const memberId=String(c.uatMemberId??''),orderId=String(c.uatOrderId??''),amountMinor=String(c.uatAmountMinor??''),allowedTradeCode=String(c.uatTradeCode??''),expiresAt=Number(c.uatExpiresAt??0),now=Math.floor(Date.now()/1000);
 const ready=/^[A-Za-z0-9:_-]{3,100}$/.test(memberId)&&/^[A-Za-z0-9_-]{8,50}$/.test(orderId)&&/^[1-9]\d{0,9}$/.test(amountMinor)&&['1','2','3','4','5','7'].includes(allowedTradeCode)&&Number.isSafeInteger(expiresAt)&&expiresAt>now&&expiresAt<=now+3600;
 if(!ready)return {required:true,ready:false,orderId:null,expiresAt:null as number|null,gatewayMemberId:null as string|null,error:json({error:'VPay UAT gate is closed',code:'VPAY_UAT_GATE_CLOSED'},503)};
 if(u.id!==memberId&&u.username!==memberId)return {required:true,ready:true,orderId:null,expiresAt,gatewayMemberId:null as string|null,error:json({error:'VPay UAT member is not allowed',code:'VPAY_UAT_MEMBER_DENIED'},403)};
 if(amount!==amountMinor||tradeCode!==allowedTradeCode)return {required:true,ready:true,orderId:null,expiresAt,gatewayMemberId:null as string|null,error:json({error:'VPay UAT request is outside the approved scope',code:'VPAY_UAT_SCOPE_MISMATCH'},400)};
 return {required:true,ready:true,orderId,expiresAt,gatewayMemberId:memberId};
}

export function vpayCapabilitySnapshot(c:VPayContext,channelActive=false,remoteReady=false,gatewayContractReady=remoteReady,remoteBalanceReady=false){
 const configured=enabled(c),depositEnabled=configured&&remoteReady&&c.enabled==='true'&&c.newDepositsEnabled==='true';
 const balanceConfiguredLocally=balanceConfigured(c),balanceEnabled=balanceConfiguredLocally&&c.balanceEnabled==='true'&&remoteBalanceReady;
 return {
  deposit:automaticDepositCapability({implemented:true,configured,enabled:depositEnabled,blockers:[...(!configured?['deposit_configuration_incomplete']:[]),...(configured&&!gatewayContractReady?['gateway_contract_not_ready']:[]),...(c.newDepositsEnabled!=='true'?['new_deposits_paused']:[]),...(c.enabled!=='true'?['profile_orders_disabled']:[]),...(configured&&gatewayContractReady&&!remoteReady?['gateway_orders_paused']:[])]},'gateway_contract'),
  payout:vpayPayoutCapabilitySnapshot(c,channelActive),
  balance:paymentCapability({implemented:true,configured:balanceConfiguredLocally,enabled:balanceEnabled,blockers:[...(!balanceConfiguredLocally?['balance_configuration_incomplete']:[]),...(c.balanceEnabled!=='true'?['balance_query_disabled']:[]),...(balanceConfiguredLocally&&c.balanceEnabled==='true'&&!remoteBalanceReady?['gateway_balance_not_ready']:[])]}),
 };
}

async function payload(req: Request, limit = 8192): Promise<Record<string, unknown>> {
  if (!req.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw Error('JSON_REQUIRED');
  const reader = req.body?.getReader(); if (!reader) throw Error('BODY_REQUIRED');
  const chunks: Uint8Array[] = []; let size = 0;
  for (;;) { const part = await reader.read(); if (part.done) break; size += part.value.length; if (size > limit) { await reader.cancel(); throw Error('BODY_TOO_LARGE'); } chunks.push(part.value); }
  const bytes = new Uint8Array(size); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  let value: unknown; try { value = JSON.parse(new TextDecoder().decode(bytes)); } catch { throw Error('INVALID_JSON'); }
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('INVALID_OBJECT');
  return value as Record<string, unknown>;
}

async function gatewayJson(c: VPayContext, path: string, token: string, method = 'GET', body?: unknown) {
  const selectedOrigin=resolveGatewayOrigin(c);
  if(!selectedOrigin)throw Error('VPAY_GATEWAY_NOT_CONFIGURED');
  const fetcher = c.fetchImpl ?? fetch, controller = new AbortController(), timer = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetcher(new URL(path, selectedOrigin), { method, redirect: 'error', signal: controller.signal,
      headers: { Accept: 'application/json', Authorization: `Bearer ${token}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {}) });
    if (response.redirected || response.url && response.url !== new URL(path, selectedOrigin).href || !/^application\/json(?:;|$)/i.test(response.headers.get('content-type') ?? '')) { await response.body?.cancel(); throw new PaymentRequestError({kind:'GATEWAY_RESPONSE',httpStatus:response.status}); }
    const raw = await response.text(); if (raw.length > 65536) throw Error('GATEWAY_RESPONSE_TOO_LARGE');
    const value = JSON.parse(raw); if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('GATEWAY_RESPONSE_INVALID');
    if(!response.ok){const v=value as Record<string,any>,upstream=Number(v.upstreamStatus),allowed=['unauthorized','vpay_orders_disabled','invalid_vpay_order','vpay_payment_configuration_incomplete','upstream_timeout','internal_error','vpay_invalid_signature','vpay_order_not_found','vpay_invalid_credentials','vpay_query_rejected','vpay_ip_not_allowed','vpay_notify_url_not_allowed','vpay_return_url_not_allowed','vpay_domain_not_allowed','vpay_allowlist_rejected','vpay_amount_rejected','vpay_channel_rejected','vpay_order_permission_rejected','vpay_order_rejected'],providerTradeNo=opaque(v.result?.data?.trade_no);throw new PaymentRequestError({kind:'GATEWAY_HTTP',httpStatus:response.status,...(Number.isInteger(upstream)&&upstream>=100&&upstream<600?{upstreamStatus:upstream}:{}),providerCode:safeProviderCode(v.result?.code),...(providerTradeNo?{providerTradeNo}:{}),...(paymentUrlHost(v.result?.data?.pay_url)?{checkoutHost:paymentUrlHost(v.result.data.pay_url)}:{}),gatewayError:allowed.includes(v.error)?v.error:undefined});}
    return value as Record<string, any>;
  } finally { clearTimeout(timer); }
}

function remoteMaintenanceCapabilities(config:Record<string,any>){
 const legacyReady=config.queryReady===undefined&&config.callbacksReady===undefined&&config.paymentReady===true;
 return {queryReady:config.queryReady===true||legacyReady,callbacksReady:config.callbacksReady===true||legacyReady};
}

export async function vpayDepositAvailability(c:VPayContext){
 const programReady=enabled(c),uatOrderGateRequired=resolveGatewayOrigin(c)===uatGatewayOrigin,unavailable={programReady,gatewayContractReady:false,remoteOrderReady:false,orderReady:false,queryReady:false,callbacksReady:false,balanceReady:false,uatOrderGateRequired,uatOrderGateReady:!uatOrderGateRequired,uatOrderExpiresAt:null as number|null,tradeCodes:[] as string[]};
 if(!programReady)return unavailable;
 try{
  const config=await gatewayJson(c,'/platform/vpay/config',c.queryToken!);
  const identityReady=config.provider==='vpay'&&config.mode===c.mode&&config.traderId===c.vpayTraderId;
  const contractReady=identityReady&&config.notifyUrl===gatewayCallbackUrl(c)&&config.returnUrl===c.returnUrl
   &&Array.isArray(config.tradeCodes);
  const capabilities=remoteMaintenanceCapabilities(config);
  const queryReady=contractReady&&capabilities.queryReady,callbacksReady=contractReady&&capabilities.callbacksReady;
  const tradeCodes=contractReady?[...new Set<string>(config.tradeCodes.filter((code:unknown)=>['1','2','3','4','5','7'].includes(String(code))).map(String))]:[];
  const gatewayContractReady=contractReady&&queryReady&&callbacksReady&&tradeCodes.length>0;
  const remoteUatGateRequired=config.uatOrderGateRequired===true,uatOrderGateReady=!remoteUatGateRequired||config.uatOrderGateReady===true,remoteUatExpiry=Number(config.uatOrderExpiresAt),uatOrderExpiresAt=Number.isSafeInteger(remoteUatExpiry)&&remoteUatExpiry>0?remoteUatExpiry:null;
  const remoteOrderReady=config.paymentReady===true&&gatewayContractReady&&uatOrderGateReady;
  const balanceReady=identityReady&&balanceConfigured(c)&&c.balanceEnabled==='true'&&config.balanceReady===true;
  return {programReady,gatewayContractReady,remoteOrderReady,orderReady:remoteOrderReady&&c.enabled==='true'&&c.newDepositsEnabled==='true',queryReady,callbacksReady,balanceReady,uatOrderGateRequired:remoteUatGateRequired,uatOrderGateReady,uatOrderExpiresAt,tradeCodes};
 }catch{return unavailable;}
}

export async function vpayRemoteOrderReady(c:VPayContext){
 const availability=await vpayDepositAvailability(c);return availability.remoteOrderReady;
}

const amountMinor = (value: unknown) => {
  if(typeof value==='number'){if(!Number.isFinite(value)||Number(value.toFixed(2))!==value)return null;value=value.toFixed(2);}
  if (typeof value !== 'string' || !/^(0|[1-9]\d{0,6})(?:\.(\d{1,2}))?$/.test(value)) return null;
  const [whole, fraction = ''] = value.split('.'); const minor = BigInt(whole) * BigInt(100) + BigInt(fraction.padEnd(2, '0'));
  return minor > BigInt(0) && minor <= BigInt(10000000) ? minor.toString() : null;
};
const amountString = (minor: string) => `${BigInt(minor) / BigInt(100)}.${(BigInt(minor) % BigInt(100)).toString().padStart(2, '0')}`;
const opaque = (value: unknown, max = 128): string | null => typeof value === 'string' && value.length > 0 && value.length <= max && /^[A-Za-z0-9_-]+$/.test(value) ? value : null;
const safePaymentUrl = (value: unknown) => {
  try { const u = new URL(String(value)); return u.protocol === 'https:' && u.origin === 'https://payment.vpay.club' && u.pathname !== '/' && !u.username && !u.password && !u.port && !u.hash ? u.href : ''; } catch { return ''; }
};

export async function handleVPay(req: Request, c: VPayContext): Promise<Response | null> {
  const path = new URL(req.url).pathname;
  if (path === '/api/payment-callbacks/vpay/payment' && req.method === 'GET') {
    const supplied = req.headers.get('authorization') ?? '';
    if (!enabled(c) || !tokenReady(c.callbackToken) || !supplied.startsWith('Bearer ') || !equal(supplied.slice(7), c.callbackToken!)) return text('UNAUTHORIZED', 401);
    return json({ provider: 'vpay', callbackReady: true, scope: 'handler-configuration-only' });
  }
  if (path === '/api/payment-callbacks/vpay/payment' && req.method === 'POST') return callback(req, c);
  if (path === '/api/payments/vpay/status' && req.method === 'GET') {
    const channel = await c.db.prepare('SELECT status FROM payment_channel_controls WHERE provider_id=?').bind('vpay').first<{status:string}>();
    // Historical channel status is still used by the separate payout capability.
    const {gatewayContractReady,remoteOrderReady,...availability}=await vpayDepositAvailability(c),capabilities=vpayCapabilitySnapshot(c,channel?.status==='active',remoteOrderReady,gatewayContractReady,availability.balanceReady);
    const realPaymentVerified=c.acceptance?.realPaymentVerified===true,settlementVerified=c.acceptance?.settlementVerified===true;
    return json({provider:'vpay',profileId:'vpay_myr',currency:'MYR',enabled:availability.orderReady,mode:availability.orderReady?c.mode:'disabled',...automaticPaymentStatus(capabilities.deposit),gatewayContractReady,remoteOrderReady,...availability,recoveryReady:c.recoveryEnabled==='true'&&availability.queryReady,payoutReady:capabilities.payout.enabled,balanceReady:capabilities.balance.enabled,realPayments:availability.orderReady&&c.mode==='production',realPaymentVerified,settlementVerified,liveReady:availability.orderReady&&realPaymentVerified&&settlementVerified,capabilities});
  }
  if (path === '/api/wallet' && req.method === 'GET') {
    if (!c.user) return json({ error: 'Sign in required' }, 401);
    if (c.user.role !== 'member') return json({ error: 'Member account required' }, 403);
    if (!c.user.approved) return json({ error: 'Account awaiting approval' }, 403);
    const wallet = await withdrawalWalletState(c.db,c.user.id);
    return json({ currency: 'MYR', ...wallet, providerTransactionsEnabled: false });
  }
  if (path === '/api/payment-records' && req.method === 'GET') {
    if (!c.user) return json({ error: 'Sign in required' }, 401);
    if (c.user.role !== 'member') return json({ error: 'Member account required' }, 403);
    await reconcileHistoricalPaymentRejections(c.db,c.user.id);
    const records = await c.db.prepare('SELECT id,provider,request_key,amount_minor,currency,status,provider_trade_no,created_at,updated_at FROM deposit_orders WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 100').bind(c.user.id).all();
    return json({ items: records.results ?? [] });
  }
  if (path === '/api/admin/deposits/trace' && req.method === 'GET') {
    if (!c.user) return json({ error: 'Sign in required' }, 401);
    if (c.user.role !== 'owner') return json({ error: 'Access denied' }, 403);
    const ids = new URL(req.url).searchParams.getAll('orderId');
    if (ids.length !== 1 || !/^[A-Za-z0-9_-]{1,128}$/.test(ids[0])) return json({error:'Invalid order ID'},400);
    const trace = await readDepositTrace(c.db,ids[0]);
    return trace ? json(trace) : json({error:'Order not found'},404);
  }
  if (path === '/api/admin/deposits' && req.method === 'GET') {
    if (!c.user) return json({ error: 'Sign in required' }, 401);
    if (c.user.role !== 'owner') return json({ error: 'Access denied' }, 403);
    try{return json(await readDepositReport(c.db,new URL(req.url).searchParams));}
    catch(error){if(error instanceof DepositReportInputError)return json({error:error.message},400);throw error;}
  }
  return null;
}

function balanceDecimal(value:unknown){
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,11})\.\d{2}$/.test(value))return null;
 const [whole,fraction]=value.split('.');return `${BigInt(whole)}.${fraction}`;
}

export async function queryVPayBalance(c:VPayContext){
 const user=c.user;if(!user)return json({error:'Sign in required'},401);if(user.role!=='owner')return json({error:'Access denied'},403);
 if(!balanceConfigured(c)||c.balanceEnabled!=='true')return json({error:'VPAY_BALANCE_QUERY_DISABLED'},503);
 try{
  const result=await gatewayJson(c,'/platform/vpay/balance',c.balanceToken!,'POST',{}),balance=balanceDecimal(result.balance);
  if(result.provider!=='vpay'||result.currency!=='MYR'||result.readOnly!==true||result.verified!==false||result.settlementVerified!==false||!balance)throw Error('BALANCE_RESPONSE_INVALID');
  return json({provider:'vpay',currency:'MYR',balance,readOnly:true,verified:false,settlementVerified:false});
 }catch{return json({error:'VPAY_BALANCE_UNAVAILABLE'},502);}
}

export async function createVPayOrder(d: Record<string, unknown>, c: VPayContext): Promise<Response> {
  const u = c.user;
  if (!u) return json({ error: 'Sign in required' }, 401);
  if (u.role !== 'member') return json({ error: 'Member account required' }, 403);
  if (!u.approved) return json({ error: 'Account awaiting approval' }, 403);
  if (c.newDepositsEnabled !== 'true') return json({error:'New deposits are temporarily unavailable',code:'DEPOSITS_MAINTENANCE'},503);
  if (c.enabled !== 'true') return json({error:'VPay new orders are disabled',code:'PROVIDER_ORDERS_DISABLED'},503);
  if (!orderEnabled(c)) return json({ error: 'VPAY_NOT_CONFIGURED' }, 503);
  const amount = amountMinor(d.amount), requestKey = typeof d.requestKey === 'string' && /^[A-Za-z0-9_-]{16,80}$/.test(d.requestKey) ? d.requestKey : '';
  const tradeCode = typeof d.tradeCode === 'string' && ['1', '2', '3', '4', '5', '7'].includes(d.tradeCode) ? d.tradeCode : '';
  const payerName = typeof d.payerName === 'string' && d.payerName.trim().length >= 1 && d.payerName.trim().length <= 30 && !/[\u0000-\u001f\u007f-\u009f]/u.test(d.payerName) ? d.payerName.trim() : '';
  if (!amount || !requestKey || !tradeCode || !payerName) return json({ error: 'Invalid MYR order' }, 400);
  const uatScope=vpayUatOrderScope(c,u,amount,tradeCode);if(uatScope.error)return uatScope.error;
  const config = await gatewayJson(c, '/platform/vpay/config', c.queryToken!);
  const maintenance=remoteMaintenanceCapabilities(config);
  if (config.provider !== 'vpay' || config.mode !== c.mode || config.paymentReady !== true || !maintenance.queryReady || !maintenance.callbacksReady || config.traderId !== c.vpayTraderId || !Array.isArray(config.tradeCodes) || !config.tradeCodes.includes(tradeCode) || config.notifyUrl !== gatewayCallbackUrl(c) || config.returnUrl !== c.returnUrl || uatScope.required&&(config.uatOrderGateRequired!==true||config.uatOrderGateReady!==true||Number(config.uatOrderExpiresAt)!==uatScope.expiresAt)) return json({ error: 'VPAY_GATEWAY_NOT_READY' }, 503);
  const fingerprint = digest(JSON.stringify({ amount, tradeCode, payerName, currency: 'MYR', mode: c.mode }));
  const id = uatScope.orderId!, timestamp = Math.floor(Date.now() / 1000);
  await c.db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,? ,?,'MYR',?,'pending',?,?) ON CONFLICT DO NOTHING")
    .bind(id, u.id, requestKey, fingerprint, 'vpay', amount, tradeCode, timestamp, timestamp).run();
  const order = await c.db.prepare('SELECT * FROM deposit_orders WHERE user_id=? AND request_key=?').bind(u.id, requestKey).first<any>();
  if (!order) {
    const claimed=uatScope.required?await c.db.prepare('SELECT user_id,request_key FROM deposit_orders WHERE id=?').bind(id).first<{user_id:string;request_key:string}>():null;
    if(claimed)return json({error:'VPay UAT order is already bound',code:'VPAY_UAT_ORDER_ALREADY_BOUND'},409);
    return json({ error: 'Order unavailable' }, 503);
  }
  if (order.fingerprint !== fingerprint || order.provider !== 'vpay') return json({ error: 'IDEMPOTENCY_CONFLICT' }, 409);
  const requestBound=order.user_id===u.id&&String(order.amount_minor)===amount&&order.currency==='MYR'&&order.trade_code===tradeCode;
  if(order.status==='created'){
    const reference=opaque(order.provider_trade_no),payUrl=safePaymentUrl(order.checkout_url);
    if(requestBound&&reference&&payUrl)return json({id:order.id,status:'awaiting_payment',payUrl,expiresAt:order.expires_at_raw},200);
    return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
  }
  if(order.status==='credited'){
    const reference=opaque(order.provider_trade_no);
    return requestBound&&reference&&await confirmedCredit(c,order,reference)?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'review',payUrl:null},409);
  }
  if(order.status==='unknown'&&!order.provider_trade_no&&!order.checkout_url){await reconcileHistoricalPaymentRejections(c.db,u.id);const historical=await c.db.prepare('SELECT status FROM deposit_orders WHERE id=? AND user_id=?').bind(order.id,u.id).first<{status:string}>();if(historical?.status==='failed')return json({error:'PROVIDER_REJECTED',id:order.id,status:'failed',payUrl:null},422);}
  if (order.status !== 'pending') return order.status === 'failed' ? json({ error:'PROVIDER_REJECTED',id:order.id,status:'failed',payUrl:null },422) : json({ id: order.id, status: 'awaiting_confirmation', payUrl: null }, 202);
  const claim = await c.db.prepare("UPDATE deposit_orders SET status='creating',updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(timestamp, order.id).first();
  if (!claim) return json({ id: order.id, status: 'awaiting_confirmation', payUrl: null }, 202);
  try {
    const created = await gatewayJson(c, '/platform/vpay/order', c.orderToken!, 'POST', { outTradeNo: order.id, ...(uatScope.required?{memberId:uatScope.gatewayMemberId}:{}), title: 'MASTER7 deposit', amount: amountString(amount), tradeCode, payerName, notifyUrl: config.notifyUrl, callbackUrl: config.returnUrl });
    const envelope = created.result;
    const data = envelope?.data;
    const payUrl = safePaymentUrl(data?.pay_url);
    const reference=opaque(data?.trade_no),success=created.provider==='vpay'&&(envelope?.code===0||envelope?.code==='0');
    let bound=String(data?.trader_id)===String(config.traderId)&&data?.out_trade_no===order.id&&amountMinor(data?.amount)===amount&&(!data?.currency||data.currency==='MYR');
    if(success&&reference&&payUrl&&!bound){
      try{const reply=await gatewayJson(c,'/platform/vpay/order-query',c.queryToken!,'POST',{outTradeNo:order.id,tradeNo:reference}),v=reply.result?.data;bound=reply.provider==='vpay'&&(reply.result?.code===0||reply.result?.code==='0')&&v?.out_trade_no===order.id&&v?.trade_no===reference&&amountMinor(v?.amount)===amount&&(!v?.trader_id||String(v.trader_id)===String(config.traderId))&&(!v?.currency||v.currency==='MYR');}
      catch(error){if(error instanceof PaymentRequestError)throw new PaymentRequestError({...error.facts,providerTradeNo:reference});throw error;}
    }
    if(!success||!reference||!payUrl||!bound)throw new PaymentRequestError({kind:'ORDER_RESPONSE',providerCode:safeProviderCode(envelope?.code),providerTradeNo:reference??undefined,checkoutHost:paymentUrlHost(data?.pay_url),missing:[...(!reference?['providerTradeNo']:[]),...(!payUrl?['checkoutUrl']:[]),...(!bound?['verifiedOrderBinding']:[])]});
    const expiry=typeof data.expired_time==='string'&&data.expired_time.length<=64?data.expired_time:typeof data.expired_time==='number'&&Number.isFinite(data.expired_time)?String(data.expired_time):null;
    await c.db.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=?,expires_at_raw=?,updated_at=? WHERE id=? AND status='creating' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(reference, payUrl, expiry, Math.floor(Date.now() / 1000), order.id,reference).run();
    const current=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='vpay'").bind(order.id,u.id).first<any>();
    if(!current||current.fingerprint!==fingerprint||String(current.amount_minor)!==amount||current.currency!=='MYR'||current.trade_code!==tradeCode||current.provider_trade_no!==reference)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
    if(current.status==='credited')return await confirmedCredit(c,current,reference)?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'review',payUrl:null},409);
    if(current.status!=='created'||current.checkout_url!==payUrl||current.expires_at_raw!==expiry)return json({id:order.id,status:'awaiting_confirmation',payUrl:null},202);
    return json({ id: order.id, status: 'awaiting_payment', payUrl, expiresAt: expiry }, 201);
  } catch(error) {
    const rejected=definitivePaymentRejection(error);
    const reference=!rejected&&error instanceof PaymentRequestError?opaque(error.facts.providerTradeNo):null;
    // A callback may have bound a reference while the create request was in
    // flight. A rejection that did not see that reference cannot mark it failed.
    const rejectionGuard=rejected?' AND provider_trade_no IS NULL':'';
    await c.db.prepare(`UPDATE deposit_orders SET status=?,provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND status='creating'${rejectionGuard}`).bind(rejected?'failed':'unknown',reference,Math.floor(Date.now() / 1000), order.id).run();
    await recordPaymentDiagnostic(c.db,u.id,'vpay',order.id,error);
    const current=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='vpay'").bind(order.id,u.id).first<any>();
    if(current?.status==='credited'){
      const currentReference=opaque(current.provider_trade_no);
      return currentReference&&current.fingerprint===fingerprint&&String(current.amount_minor)===amount&&current.currency==='MYR'&&current.trade_code===tradeCode&&await confirmedCredit(c,current,currentReference)?json({id:order.id,status:'credited',payUrl:null}):json({id:order.id,status:'review',payUrl:null},409);
    }
    const serviceUnavailable=error instanceof PaymentRequestError&&['vpay_ip_not_allowed','vpay_notify_url_not_allowed','vpay_return_url_not_allowed','vpay_domain_not_allowed','vpay_allowlist_rejected','vpay_order_permission_rejected','vpay_channel_rejected','vpay_invalid_credentials','vpay_invalid_signature'].includes(error.facts.gatewayError??'');
    return rejected&&current?.status==='failed'&&!current.provider_trade_no ? json({ error:serviceUnavailable?'PROVIDER_UNAVAILABLE':'PROVIDER_REJECTED',id:order.id,status:'failed',payUrl:null },422) : json({ id: order.id, status: 'awaiting_confirmation', payUrl: null }, 202);
  }
}

/** Read-only incident evidence. Queries at most ten stored orders with two
 * concurrent workers. Never binds a reference, reconciles, updates or credits. */
export async function readVPayDepositProviderEvidence(c:VPayContext){
 const resultBase={readOnly:true,provider:'vpay',providerQueriesExecuted:0,repairsExecuted:false,walletCreditExecuted:false};
 const configured=resolveGatewayOrigin(c)!==null&&tokenReady(c.queryToken)&&typeof c.vpayTraderId==='string'&&/^[1-9]\d{0,11}$/.test(c.vpayTraderId)&&c.queryToken!==c.orderToken&&c.queryToken!==c.callbackToken;
 if(!configured)return {...resultBase,configured:false,truncated:false,items:[]};
 const result=await c.db.prepare("SELECT id,user_id,amount_minor,currency,provider_trade_no,status FROM deposit_orders WHERE provider='vpay' ORDER BY created_at,id LIMIT 11").all<{id:string;user_id:string;amount_minor:string;currency:string;provider_trade_no:string|null;status:string}>();
 if(!Array.isArray(result.results))throw Error('Incident orders unavailable');
 const orders=result.results.slice(0,10),items:Record<string,unknown>[]=new Array(orders.length);let next=0,queries=0;
 async function worker(){for(;;){const index=next++;if(index>=orders.length)return;const order=orders[index],ref=opaque(order.id,50),storedTrade=order.provider_trade_no===null?null:opaque(order.provider_trade_no);
  if(!ref||order.currency!=='MYR'||!/^[1-9]\d*$/.test(String(order.amount_minor))||(order.provider_trade_no!==null&&!storedTrade)){items[index]={orderId:order.id,outcome:'invalid_stored_binding',paymentVerified:false};continue;}
  queries++;
  try{
   const reply=await gatewayJson(c,'/platform/vpay/order-query',c.queryToken!,'POST',{outTradeNo:ref,...(storedTrade?{tradeNo:storedTrade}:{})}),envelope=reply.result,data=envelope?.data;
   if(reply.provider!=='vpay'||!(envelope?.code===0||envelope?.code==='0')){items[index]={orderId:ref,outcome:'provider_query_rejected',providerCode:safeProviderCode(envelope?.code),paymentVerified:false};continue;}
   const trade=opaque(data?.trade_no),bound=data?.out_trade_no===ref&&!!trade&&(!storedTrade||trade===storedTrade)&&amountMinor(data?.amount)===String(order.amount_minor)&&(data?.trader_id===undefined||String(data.trader_id)===c.vpayTraderId)&&(data?.currency===undefined||data.currency==='MYR');
   if(!bound){items[index]={orderId:ref,outcome:'provider_binding_mismatch',paymentVerified:false};continue;}
   const state=String(data.state),status=['0','1','2','3','4','5'].includes(state)?state:'unrecognized';
   items[index]={orderId:ref,providerTransactionId:trade,amountMinor:String(order.amount_minor),currency:'MYR',storedStatus:order.status,outcome:'provider_query_bound',providerState:status,paymentVerified:status==='3'};
  }catch(error){items[index]={orderId:ref,outcome:'provider_query_unavailable',paymentVerified:false,...(error instanceof PaymentRequestError?{kind:error.facts.kind,httpStatus:error.facts.httpStatus,upstreamStatus:error.facts.upstreamStatus,providerCode:error.facts.providerCode,gatewayError:error.facts.gatewayError}:{})};}
 }}
 await Promise.all([worker(),worker()]);return {...resultBase,configured:true,providerQueriesExecuted:queries,truncated:result.results.length>10,items};
}

async function reconcileVPayOrder(c:VPayContext,order:any,tradeNo:string|null){
 if(order.status==='review')return 'review';
 if(order.status==='credited'&&(!tradeNo||!await confirmedCredit(c,order,tradeNo)))return 'review';
 const queried=await gatewayJson(c,'/platform/vpay/order-query',c.queryToken!,'POST',{outTradeNo:order.id,...(tradeNo?{tradeNo}:{})}),envelope=queried.result,verified=envelope?.data;
 const successCode=envelope?.code===0||envelope?.code==='0',returnedTrade=opaque(verified?.trade_no),returnedOrder=opaque(verified?.out_trade_no,50),returnedAmount=amountMinor(verified?.amount);
 if(queried.provider!=='vpay'||!successCode)return 'awaiting_confirmation';
 // Legacy VPay replies may omit currency; an explicit currency must match MYR.
 if(returnedOrder!==order.id||(tradeNo&&returnedTrade&&returnedTrade!==tradeNo)||returnedAmount!==String(order.amount_minor)||(order.provider_trade_no&&order.provider_trade_no!==returnedTrade)||(verified?.trader_id!==undefined&&String(verified.trader_id)!==String(c.vpayTraderId))||(verified?.currency!==undefined&&verified.currency!=='MYR')){
  await holdLedgerReview(c,order,Math.floor(Date.now()/1000),'deposit_query_binding_review');return 'review';
 }
 if(!returnedTrade)return 'awaiting_confirmation';
 if(!tradeNo){
  // The provider's authenticated query can recover an unknown reference only
  // after its order, amount, merchant and currency are independently matched.
  // Serialize binding with wallet writes and do not overwrite another result.
  const timestamp=Math.floor(Date.now()/1000);
  await c.db.batch([
   ...walletGuardStatements(c.db,order.user_id),
   c.db.prepare("UPDATE deposit_orders SET provider_trade_no=?,updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status IN ('creating','unknown','failed') AND provider_trade_no IS NULL").bind(returnedTrade,timestamp,order.id,order.user_id,String(order.amount_minor)),
  ]);
  const current=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND provider='vpay'").bind(order.id).first<any>();
  if(!current||current.user_id!==order.user_id||String(current.amount_minor)!==String(order.amount_minor)||current.currency!=='MYR')return 'awaiting_confirmation';
  if(current.status==='review')return 'review';
  if(!current.provider_trade_no)return 'awaiting_confirmation';
  if(current.provider_trade_no!==returnedTrade){await holdLedgerReview(c,order,timestamp,'deposit_query_binding_review');return 'review';}
  order=current;tradeNo=returnedTrade;
 }
 const alreadyCredited=order.status==='credited';
 if(alreadyCredited&&!await confirmedCredit(c,order,tradeNo))return 'review';
 const providerState=String(verified?.state);
 if(alreadyCredited){
  if(providerState==='3')return await confirmedCredit(c,order,tradeNo)?'credited':'review';
  // Any independently queried state other than paid is inconsistent with a
  // previously credited order. Preserve its balanced ledger, remove it from
  // spendable balance by moving the order to review, and record one incident.
  await holdProviderStateReview(c,order,providerState);return 'review';
 }
 if(providerState==='0'||providerState==='2')return 'awaiting_confirmation';
 if(providerState==='1')return await markProviderFailed(c,order,tradeNo);
 if(providerState==='4'||providerState==='5'){await holdProviderStateReview(c,order,providerState);return 'review';}
 if(providerState!=='3'){await holdProviderStateReview(c,order,'unknown');return 'review';}
 const member=await c.db.prepare("SELECT id FROM users WHERE id=? AND role='member' AND approved=1").bind(order.user_id).first<{id:string}>();
 if(!member){await holdLedgerReview(c,order,Math.floor(Date.now()/1000),'deposit_member_binding_review');return 'review';}
 const timestamp=Math.floor(Date.now()/1000),existing=await ledgerRows(c,order.id);
 if(existing.length&&!validLedger(existing,order)){await holdLedgerReview(c,order,timestamp);return 'review';}
 await c.db.batch([
  ...walletGuardStatements(c.db,order.user_id),
  // A successful query after a previously recorded terminal failure is a
  // contradiction requiring staff reconciliation, not an automatic credit.
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'vpay_late_success_review',id,? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='failed' AND (provider_trade_no IS NULL OR provider_trade_no=?) AND NOT EXISTS (SELECT 1 FROM audit a WHERE a.event='vpay_late_success_review' AND a.target=deposit_orders.id)").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='failed' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(tradeNo,timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  // The ledger can change after the preflight read while this transaction is
  // waiting for the guard. Never add a leg to an incomplete or conflicting
  // historical ledger; mark it for review before any insert is attempted.
  c.db.prepare(`UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status<>'review' AND (provider_trade_no IS NULL OR provider_trade_no=?)
   AND EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)
   AND NOT ((SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
    AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor))`).bind(timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'member',amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  c.db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) SELECT ?,id,user_id,'provider_clearing',-amount_minor,'MYR',? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(order_id,account_code) DO NOTHING").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  c.db.prepare(`UPDATE deposit_orders SET status='credited',provider_trade_no=?,updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status NOT IN ('credited','failed','review') AND (provider_trade_no IS NULL OR provider_trade_no=?)
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
   AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor)`).bind(tradeNo,timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  // An inconsistent ledger discovered after the initial read must enter review
  // while the same member guard is still held; otherwise a new spend could
  // start between this batch and the later review transaction.
  c.db.prepare(`UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status<>'review' AND (provider_trade_no IS NULL OR provider_trade_no=?)
   AND EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)
   AND NOT ((SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
    AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor))`).bind(timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  c.db.prepare(`INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'deposit_ledger_review',id,? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='review'
   AND EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)
   AND NOT ((SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
    AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor))
   AND NOT EXISTS (SELECT 1 FROM audit a WHERE a.event='deposit_ledger_review' AND a.target=deposit_orders.id)`).bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor)),
  c.db.prepare(`INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'deposit_credited',id,? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='credited' AND provider_trade_no=?
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=deposit_orders.id)=2
   AND EXISTS (SELECT 1 FROM wallet_ledger m JOIN wallet_ledger p ON p.order_id=m.order_id WHERE m.order_id=deposit_orders.id AND m.account_code='member' AND p.account_code='provider_clearing' AND m.user_id=deposit_orders.user_id AND p.user_id=deposit_orders.user_id AND m.currency='MYR' AND p.currency='MYR' AND m.amount_minor=deposit_orders.amount_minor AND p.amount_minor=-deposit_orders.amount_minor)
   AND NOT EXISTS (SELECT 1 FROM audit a WHERE a.event='deposit_credited' AND a.target=deposit_orders.id)`).bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
 ]);
 const committed=await c.db.prepare("SELECT status,provider_trade_no FROM deposit_orders WHERE id=? AND provider='vpay'").bind(order.id).first<{status:string;provider_trade_no:string|null}>();
 if(committed?.status==='credited'&&committed.provider_trade_no===tradeNo&&await confirmedCredit(c,order,tradeNo))return 'credited';
 if(committed?.status==='review')return 'review';
 await holdLedgerReview(c,order);return 'review';
}

export async function refreshVPayOrder(data:Record<string,unknown>,c:VPayContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member'||!u.approved)return json({error:'Member account required'},403);if(!enabled(c))return json({error:'VPAY_NOT_CONFIGURED'},503);
 const orderId=opaque(data.orderId,50)??'',order=await c.db.prepare("SELECT * FROM deposit_orders WHERE id=? AND user_id=? AND provider='vpay'").bind(orderId,u.id).first<any>();
 if(!order)return json({error:'Order not found'},404);if(order.status==='review')return json({id:order.id,status:'review'},409);
 if(order.currency!=='MYR')return json({error:'Currency mismatch'},409);
 const tradeNo=opaque(order.provider_trade_no);
 if(!tradeNo&&(!['creating','unknown'].includes(order.status)||Number(order.updated_at)>Math.floor(Date.now()/1000)-60))return json({id:order.id,status:'awaiting_confirmation'},202);
 try{const status=await reconcileVPayOrder(c,order,tradeNo);return json({id:order.id,status},status==='credited'?200:status==='review'?409:status==='failed'?422:202);}catch{return json({id:order.id,status:'awaiting_confirmation'},202);}
}

export async function recoverVPayDeposits(c:VPayContext,limit=25){
 const summary={provider:'vpay',enabled:c.recoveryEnabled==='true'&&enabled(c),scanned:0,queried:0,credited:0,review:0,escalated:0,pending:0,errors:0};
 summary.escalated=await escalateExhaustedPaymentRecoveries(c.db,'vpay');
 if(!summary.enabled)return summary;
 const candidates=await recoveryCandidates(c.db,'vpay',limit);summary.scanned=candidates.length;
 for(const order of candidates){const claim=await claimPaymentRecovery(c.db,'vpay',order.id);if(!claim)continue;try{const tradeNo=opaque(order.provider_trade_no);summary.queried++;const status=await reconcileVPayOrder(c,order,tradeNo);if(status==='credited')summary.credited++;else if(status==='review')summary.review++;else summary.pending++;}catch{summary.errors++;}finally{await finishPaymentRecovery(c.db,'vpay',order.id,claim);}}
 return summary;
}

async function callback(req: Request, c: VPayContext): Promise<Response> {
  const supplied = req.headers.get('authorization') ?? '';
  if (!enabled(c) || !tokenReady(c.callbackToken) || !supplied.startsWith('Bearer ') || !equal(supplied.slice(7), c.callbackToken!)) return text('UNAUTHORIZED', 401);
  let d: Record<string, unknown>; try { d = await payload(req); } catch { return text('INVALID', 400); }
  const orderId = opaque(d.out_trade_no, 50), tradeNo = opaque(d.trade_no), callbackAmount = amountMinor(d.amount);
  if (!orderId || !tradeNo || !callbackAmount || String(d.trader_id) !== c.vpayTraderId) return text('INVALID', 400);
  let order = await c.db.prepare('SELECT * FROM deposit_orders WHERE id=? AND provider=?').bind(orderId, 'vpay').first<any>();
  if (!order) return text('UNKNOWN_ORDER', 404);
  if (order.currency !== 'MYR') return text('CURRENCY_MISMATCH', 409);
  if (order.status === 'review') return text('LEDGER_REVIEW', 503);
  if (order.status === 'credited') {
    if (!await confirmedCredit(c,order,tradeNo)) { if(!await verifyLedger(c,order))await holdLedgerReview(c,order); return text('LEDGER_REVIEW', 503); }
    if (String(order.amount_minor) !== callbackAmount || (order.provider_trade_no && order.provider_trade_no !== tradeNo)) {
      await holdProviderStateReview(c,order,'unknown');return text('REVIEW_REQUIRED',502);
    }
    const callbackState=String(d.state);
    try{if(!await recordVPayCallbackAuthenticated(c,order,tradeNo,callbackAmount,callbackState))return text('PENDING',502);}catch{return text('PENDING',502);}
    if(callbackState==='3')return text('SUCCESS');
    if(callbackState==='4'||callbackState==='5'){
      try{const status=await reconcileVPayOrder(c,order,tradeNo);return status==='review'?text('REVIEW_REQUIRED',409):status==='credited'?text('SUCCESS'):text('PENDING',502);}catch{return text('PENDING',502);}
    }
    return text('PENDING',502);
  }
  if (String(order.amount_minor) !== callbackAmount || (order.provider_trade_no && order.provider_trade_no !== tradeNo) || String(d.state) !== '3') {
    if(String(order.amount_minor)===callbackAmount&&(!order.provider_trade_no||order.provider_trade_no===tradeNo)&&/^[0-5]$/.test(String(d.state))){
      try{if(!await recordVPayCallbackAuthenticated(c,order,tradeNo,callbackAmount,String(d.state)))return text('PENDING',502);}catch{return text('PENDING',502);}
    }
    await c.db.batch([
      ...walletGuardStatements(c.db,order.user_id),
      c.db.prepare("UPDATE deposit_orders SET status='review',provider_trade_no=COALESCE(provider_trade_no,?),updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'").bind(tradeNo, Math.floor(Date.now() / 1000), orderId,order.user_id,String(order.amount_minor)),
      c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'deposit_callback_review',id,? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='review'").bind(crypto.randomUUID(),Math.floor(Date.now()/1000),orderId,order.user_id,String(order.amount_minor)),
    ]);
    return text('REVIEW_REQUIRED', 502);
  }
  try{if(!await recordVPayCallbackAuthenticated(c,order,tradeNo,callbackAmount,String(d.state)))return text('PENDING',502);}catch{return text('PENDING',502);}
  // A trusted gateway notification can carry the only provider reference.
  // Preserve it before querying so a query timeout stays recoverable; wallet
  // credit still requires the independently bound provider response.
  if(!order.provider_trade_no){
    try{
      const bound=await c.db.prepare("UPDATE deposit_orders SET provider_trade_no=?,updated_at=? WHERE id=? AND provider='vpay' AND currency='MYR' AND status NOT IN ('credited','review') AND provider_trade_no IS NULL RETURNING id").bind(tradeNo,Math.floor(Date.now()/1000),order.id).first();
      if(!bound){
        order=await c.db.prepare('SELECT * FROM deposit_orders WHERE id=? AND provider=?').bind(orderId,'vpay').first<any>();
        if(!order||order.currency!=='MYR'||String(order.amount_minor)!==callbackAmount||order.provider_trade_no!==tradeNo)return text('REVIEW_REQUIRED',502);
        if(order.status==='credited')return await confirmedCredit(c,order,tradeNo)?text('SUCCESS'):text('LEDGER_REVIEW',503);
        if(order.status==='review')return text('LEDGER_REVIEW',503);
      }else order={...order,provider_trade_no:tradeNo};
    }catch{return text('PENDING',502);}
  }
  try{const status=await reconcileVPayOrder(c,order,tradeNo);if(status==='credited')return text('SUCCESS');if(status==='review')return text('LEDGER_REVIEW',503);return text('PENDING',502);}catch{return text('PENDING',502);}
}

// Persist receipt of one authenticated, order-bound gateway notification
// before any provider query or wallet mutation. The event proves delivery
// only; it does not treat the callback state as payment proof. The target is
// the order ID, while the deterministic primary key contains only a digest of
// normalized non-secret fields.
async function recordVPayCallbackAuthenticated(c:VPayContext,order:any,tradeNo:string,callbackAmount:string,state:string){
 if(!/^[0-5]$/.test(state))return false;
 const receiptId='vpay-callback-'+digest(JSON.stringify({provider:'vpay',orderId:order.id,tradeNo,amountMinor:callbackAmount,state,traderId:c.vpayTraderId})).slice(0,48),timestamp=Math.floor(Date.now()/1000);
 await c.db.prepare(`INSERT INTO audit(id,user_id,event,target,created_at)
  SELECT ?,user_id,'vpay_callback_authenticated',id,? FROM deposit_orders
  WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'
   AND (provider_trade_no IS NULL OR provider_trade_no=?) ON CONFLICT(id) DO NOTHING`).bind(receiptId,timestamp,order.id,order.user_id,callbackAmount,tradeNo).run();
 return !!await c.db.prepare("SELECT id FROM audit WHERE id=? AND event='vpay_callback_authenticated' AND target=? AND user_id=?").bind(receiptId,order.id,order.user_id).first();
}

async function ledgerRows(c: VPayContext, orderId: string) {
  const rows = await c.db.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=?').bind(orderId).all<any>();
  return rows.results ?? [];
}

function validLedger(entries: any[], order: any) {
  const member = entries.find((x: any) => x.account_code === 'member'), clearing = entries.find((x: any) => x.account_code === 'provider_clearing');
  return entries.length === 2 && entries.every((x: any) => x.currency === 'MYR' && x.user_id === order.user_id)
    && String(member?.amount_minor) === String(order.amount_minor)
    && BigInt(clearing?.amount_minor ?? 0) === -BigInt(order.amount_minor)
    && BigInt(member?.amount_minor ?? 0) + BigInt(clearing?.amount_minor ?? 0) === BigInt(0);
}

async function holdLedgerReview(c: VPayContext, order: any, timestamp = Math.floor(Date.now() / 1000),event='deposit_ledger_review') {
  await c.db.batch([
    ...walletGuardStatements(c.db,order.user_id),
    c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'").bind(timestamp, order.id,order.user_id,String(order.amount_minor)),
    c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,?,id,? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status='review'").bind(crypto.randomUUID(),event,timestamp,order.id,order.user_id,String(order.amount_minor)),
  ]);
}

async function markProviderFailed(c:VPayContext,order:any,tradeNo:string,timestamp=Math.floor(Date.now()/1000)){
 await c.db.batch([
  ...walletGuardStatements(c.db,order.user_id),
  c.db.prepare("UPDATE deposit_orders SET status=CASE WHEN status='credited' OR EXISTS (SELECT 1 FROM wallet_ledger l WHERE l.order_id=deposit_orders.id) THEN 'review' ELSE 'failed' END,updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status<>'review' AND (provider_trade_no IS NULL OR provider_trade_no=?)").bind(timestamp,order.id,order.user_id,String(order.amount_minor),tradeNo),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,CASE WHEN status='review' THEN 'vpay_deposit_state_review' ELSE 'vpay_deposit_failed' END,id,? FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR' AND status IN ('failed','review') AND NOT EXISTS(SELECT 1 FROM audit WHERE event=CASE WHEN deposit_orders.status='review' THEN 'vpay_deposit_state_review' ELSE 'vpay_deposit_failed' END AND target=deposit_orders.id)").bind(crypto.randomUUID(),timestamp,order.id,order.user_id,String(order.amount_minor)),
 ]);
 const current=await c.db.prepare("SELECT status FROM deposit_orders WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'").bind(order.id,order.user_id,String(order.amount_minor)).first<{status:string}>();
 return current?.status==='failed'?'failed':'review';
}

async function holdProviderStateReview(c:VPayContext,order:any,state:string,timestamp=Math.floor(Date.now()/1000)){
 const event=state==='4'?'vpay_deposit_reversed_review':state==='5'?'vpay_deposit_risk_control_review':state==='1'?'vpay_post_credit_failed_review':'vpay_deposit_state_review';
 await c.db.batch([
  ...walletGuardStatements(c.db,order.user_id),
  c.db.prepare("UPDATE deposit_orders SET status='review',updated_at=? WHERE id=? AND provider='vpay' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'").bind(timestamp,order.id,order.user_id,String(order.amount_minor)),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,?,id,? FROM deposit_orders WHERE id=? AND provider=\'vpay\' AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND currency=\'MYR\' AND status=\'review\' AND NOT EXISTS(SELECT 1 FROM audit WHERE event=? AND target=?)').bind(crypto.randomUUID(),event,timestamp,order.id,order.user_id,String(order.amount_minor),event,order.id),
 ]);
}

async function verifyLedger(c: VPayContext, order: any) {
  return validLedger(await ledgerRows(c, order.id), order);
}

// Acknowledgement requires the current order and both balanced ledger legs,
// not an earlier order snapshot followed by a separate ledger read.
async function confirmedCredit(c:VPayContext,order:any,tradeNo:string){
 return !!await c.db.prepare(`SELECT o.id FROM deposit_orders o
  JOIN wallet_ledger m ON m.order_id=o.id AND m.account_code='member'
  JOIN wallet_ledger p ON p.order_id=o.id AND p.account_code='provider_clearing'
  WHERE o.id=? AND o.provider='vpay' AND o.user_id=? AND o.currency='MYR'
   AND o.amount_minor=CAST(? AS BIGINT) AND o.status='credited' AND o.provider_trade_no=?
   AND m.user_id=o.user_id AND p.user_id=o.user_id AND m.currency='MYR' AND p.currency='MYR'
   AND m.amount_minor=o.amount_minor AND p.amount_minor=-o.amount_minor
   AND (SELECT COUNT(*) FROM wallet_ledger l WHERE l.order_id=o.id)=2`).bind(order.id,order.user_id,String(order.amount_minor),tradeNo).first();
}
