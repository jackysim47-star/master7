import { RenderD1Compat } from "./render-d1";

// The application keeps its D1-shaped data access contract. On Render this
// object adapts that contract to the independent PostgreSQL staging database.
export const env = {
  DB: new RenderD1Compat(),
  RENDER_EXTERNAL_URL: process.env.RENDER_EXTERNAL_URL,
  PUBLIC_ORIGIN: process.env.PUBLIC_ORIGIN,
  PORTAL_ALLOWED_ORIGINS: process.env.PORTAL_ALLOWED_ORIGINS,
  OWNER_EMAIL: process.env.OWNER_EMAIL ?? "",
  OWNER_LOGIN_ID: process.env.OWNER_LOGIN_ID,
  OWNER_SETUP_TOKEN_HASH: process.env.OWNER_SETUP_TOKEN_HASH,
  OWNER_SETUP_EXPIRES_AT: process.env.OWNER_SETUP_EXPIRES_AT,
  OWNER_RESET_TOKEN_HASH: process.env.OWNER_RESET_TOKEN_HASH,
  OWNER_RESET_EXPIRES_AT: process.env.OWNER_RESET_EXPIRES_AT,
  OWNER_RESET_ISSUED_AT: process.env.OWNER_RESET_ISSUED_AT,
};
