import {createHmac, timingSafeEqual} from 'node:crypto';

// EliteHubz v1.20.5 canonicalization and signing only. There is no callback
// route or live wallet integration in this module.
export class EliteHubzSignatureError extends Error {
  constructor() { super('invalid_elitehubz_signature_input'); this.name = 'EliteHubzSignatureError'; }
}
const invalid = (): never => { throw new EliteHubzSignatureError(); };

export function eliteHubzQuery(value: unknown): string {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return invalid();
  const fields = new Map<string, string>(), visiting = new WeakSet<object>();
  function walk(item: unknown, prefix: string, depth: number): void {
    if (depth > 16) return invalid();
    if (item === null || item === undefined || item === '') return;
    if (typeof item === 'string' || typeof item === 'boolean' || typeof item === 'number') {
      if (!prefix || (typeof item === 'number' && !Number.isFinite(item))) return invalid();
      const rendered = String(item);
      if (rendered.length > 4096 || fields.has(prefix) || fields.size >= 2000) return invalid();
      fields.set(prefix, rendered);
      return;
    }
    if (typeof item !== 'object') return invalid();
    if (visiting.has(item)) return invalid();
    visiting.add(item);
    if (Array.isArray(item)) {
      if (item.length > 1000) return invalid();
      let index = 0;
      for (const child of item) {
        if (child === null || child === undefined || child === '') continue;
        walk(child, `${prefix}[${index++}]`, depth + 1);
      }
    } else {
      if (![Object.prototype, null].includes(Object.getPrototypeOf(item))) return invalid();
      for (const [key, child] of Object.entries(item)) {
        if (!/^[A-Za-z][A-Za-z0-9_]{0,99}$/.test(key)) return invalid();
        walk(child, prefix ? `${prefix}.${key}` : key, depth + 1);
      }
    }
    visiting.delete(item);
  }
  walk(value, '', 0);
  const encode = (text: string) => encodeURIComponent(text).replace(/%[0-9A-F]{2}/g, match => match.toLowerCase());
  try {
    const query = [...fields.keys()].sort().map(key => `${encode(key)}=${encode(fields.get(key)!)}`).join('&');
    return query.length <= 64 * 1024 ? query : invalid();
  } catch { return invalid(); }
}

export function signEliteHubz(value: unknown, timestamp: number, secret: string): string {
  if (!Number.isSafeInteger(timestamp) || timestamp <= 0 || typeof secret !== 'string' || !/^[A-Za-z0-9]{20}$/.test(secret)) return invalid();
  return createHmac('sha256', secret).update(`${eliteHubzQuery(value)}|${timestamp}`).digest('base64');
}

export function verifyEliteHubzSignature(value: unknown, timestamp: number, signature: string, secret: string, now: number, maxSkewMs: number): boolean {
  if (!Number.isSafeInteger(now) || !Number.isSafeInteger(maxSkewMs) || maxSkewMs < 0 || Math.abs(now - timestamp) > maxSkewMs || typeof signature !== 'string' || !/^[A-Za-z0-9+/]{43}=$/.test(signature)) return false;
  try {
    const expected = Buffer.from(signEliteHubz(value, timestamp, secret), 'base64'), received = Buffer.from(signature, 'base64');
    return received.length === expected.length && received.toString('base64') === signature && timingSafeEqual(received, expected);
  } catch { return false; }
}
