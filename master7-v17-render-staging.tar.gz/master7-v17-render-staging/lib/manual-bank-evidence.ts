import {createHash} from 'node:crypto';

export const bankHash=(value:string)=>createHash('sha256').update(value).digest('hex');
export const bankAccountKey=(number:string)=>bankHash(number.replace(/[\s-]/g,''));
export const bankReference=(value:unknown)=>{
 if(typeof value!=='string'||value.trim().length>100||!/^[A-Za-z0-9][A-Za-z0-9 /_.:-]{3,99}$/.test(value.trim()))return null;
 const original=value.trim(),normalized=original.toUpperCase().replace(/[\s-]/g,'');
 return normalized.length>=4?{original,normalized}:null;
};
export function bankImage(value:unknown){
 if(typeof value!=='string'||value.length>500000||!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(value))return null;
 try{const raw=atob(value.slice(value.indexOf(',')+1)),b=[...raw.slice(0,12)].map(x=>x.charCodeAt(0));
 const magic=value.startsWith('data:image/jpeg;')&&b[0]===255&&b[1]===216&&b[2]===255||value.startsWith('data:image/png;')&&b.slice(0,8).join(',')==='137,80,78,71,13,10,26,10'||value.startsWith('data:image/webp;')&&raw.slice(0,4)==='RIFF'&&raw.slice(8,12)==='WEBP';
 return raw.length>=16&&raw.length<=350000&&magic?value:null;}catch{return null;}
}
export function bankAmount(value:unknown){
 if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,2})?$/.test(value))return null;
 const[a,b='']=value.split('.'),n=BigInt(a)*100n+BigInt(b.padEnd(2,'0'));
 return n>0n&&n<=10000000n?n.toString():null;
}
export function bankEvidence(input:Record<string,unknown>,timestamp:number){
 const reference=bankReference(input.bankReference),proof=bankImage(input.proofData),amount=bankAmount(input.bankAmount),occurred=Number(input.bankOccurredAt);
 if(!reference||!proof||!amount||input.currency!=='MYR'||input.bankConfirmed!==true||!Number.isSafeInteger(occurred)||occurred<1577836800||occurred>timestamp+300)return null;
 return {reference,proof,amount,occurred,hash:bankHash(proof)};
}
// Trusted SQL aliases p=provider_payouts, w=withdrawal_requests. This same
// predicate is used by balance reads, the atomic spend guard, and hold recovery.
export const manualPayoutEvidenceSql=`(p.provider_id='manual_bank' AND EXISTS (
 SELECT 1 FROM manual_bank_transactions b JOIN company_bank_accounts bank ON bank.id=b.bank_account_id
 WHERE b.id=p.provider_reference AND b.payout_id=p.id AND b.direction='withdrawal'
 AND b.bank_account_id=p.manual_bank_account_id AND b.amount_minor=p.amount_minor AND b.currency=p.currency
 AND b.proof_sha256=p.last_event_hash AND LENGTH(b.proof_sha256)=64 AND b.proof_data<>''
 AND (SELECT COUNT(*) FROM audit a WHERE a.event='manual_bank_payout_paid' AND a.target=b.id AND a.user_id=b.recorded_by)=1
 AND EXISTS(SELECT 1 FROM audit a WHERE a.event='manual_bank_payout_paid' AND a.target=b.id AND a.user_id=b.recorded_by AND a.created_at=b.recorded_at)))`;
