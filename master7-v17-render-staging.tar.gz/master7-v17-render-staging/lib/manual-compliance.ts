import {randomUUID} from 'node:crypto';

// Only stores review decisions. The reviewer is responsible for examining
// identity evidence and performing AML screening through approved procedures.
// No identity documents, numbers, free-text notes, or secrets are accepted.
export class ManualComplianceError extends Error {
 status:number;code:string;
 constructor(status:number,code:string,message:string){super(message);this.status=status;this.code=code;}
}
type Review={user_id:string;identity_status:'pending'|'passed'|'failed';aml_status:'pending'|'passed'|'failed';version:number;created_at:number;updated_at:number};
const error=(status:number,code:string,message:string):never=>{throw new ManualComplianceError(status,code,message);};
// Locally registered members use IDs such as local:<uuid>.
const validId=(value:unknown):value is string=>typeof value==='string'&&/^[A-Za-z0-9:_-]{1,128}$/.test(value);
const publicReview=(row:Review|null)=>row?{identityStatus:row.identity_status,amlStatus:row.aml_status,version:Number(row.version),updatedAt:Number(row.updated_at),reviewComplete:row.identity_status==='passed'&&row.aml_status==='passed'}:{identityStatus:'not_started',amlStatus:'not_started',version:0,updatedAt:null,reviewComplete:false};

export async function getManualCompliance(db:D1Database,userId:string){
 if(!validId(userId))return error(400,'INVALID_MEMBER','Invalid member');
 const row=await db.prepare('SELECT user_id,identity_status,aml_status,version,created_at,updated_at FROM manual_compliance_reviews WHERE user_id=?').bind(userId).first<Review>();
 return publicReview(row);
}

export async function requestManualCompliance(db:D1Database,userId:string,at=Math.floor(Date.now()/1000)){
 if(!validId(userId))return error(400,'INVALID_MEMBER','Invalid member');
 const changeId=randomUUID();
 await db.prepare("INSERT INTO manual_compliance_reviews(user_id,last_change_id,created_at,updated_at) SELECT id,?,?,? FROM users WHERE id=? AND role='member' ON CONFLICT(user_id) DO NOTHING").bind(changeId,at,at,userId).run();
 const row=await db.prepare('SELECT user_id,identity_status,aml_status,version,created_at,updated_at FROM manual_compliance_reviews WHERE user_id=?').bind(userId).first<Review>();
 if(!row)return error(404,'MEMBER_NOT_FOUND','Member not found');
 return publicReview(row);
}

// Each new operation obtains an authorization while the review row is locked.
// A later review change applies to subsequent operations; existing provider
// callbacks, order queries and game settlement/recovery are never blocked.
export async function authorizeManualComplianceAction(db:D1Database,userId:string,action:'deposit'|'game_launch'|'withdrawal',at=Math.floor(Date.now()/1000)){
 if(!validId(userId)||!['deposit','game_launch','withdrawal'].includes(action))return error(400,'INVALID_ACTION','Invalid member action');
 const id=randomUUID();
 await db.batch([
  db.prepare("UPDATE manual_compliance_reviews SET last_authorization_id=? WHERE user_id=? AND identity_status='passed' AND aml_status='passed'").bind(id,userId),
  db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,user_id,'manual_compliance_action_authorized',? || ':v' || CAST(version AS TEXT),? FROM manual_compliance_reviews WHERE user_id=? AND last_authorization_id=?").bind(id,action,at,userId,id),
 ]);
 if(!await db.prepare("SELECT id FROM audit WHERE id=? AND user_id=? AND event='manual_compliance_action_authorized'").bind(id,userId).first())return error(403,'COMPLIANCE_REVIEW_REQUIRED','Complete identity and risk review before this action');
 return {authorized:true};
}

export async function reviewManualCompliance(db:D1Database,reviewerId:string,input:Record<string,unknown>,at=Math.floor(Date.now()/1000)){
 const {memberId,reviewType,decision,expectedVersion,confirmed}=input;
 if(Object.keys(input).some(key=>!['memberId','reviewType','decision','expectedVersion','confirmed'].includes(key)))return error(400,'INVALID_FIELDS','Only review decision fields are accepted');
 if(!validId(reviewerId)||!validId(memberId)||!['identity','aml'].includes(String(reviewType))||!['passed','failed'].includes(String(decision))||!Number.isSafeInteger(expectedVersion)||Number(expectedVersion)<1||confirmed!==true)return error(400,'INVALID_REVIEW','A confirmed review and current version are required');
 const existing=await db.prepare('SELECT user_id,identity_status,aml_status,version,created_at,updated_at FROM manual_compliance_reviews WHERE user_id=?').bind(memberId).first<Review>();
 if(!existing)return error(404,'REVIEW_NOT_FOUND','Review not found');
 if(Number(existing.version)!==expectedVersion)return error(409,'STALE_REVIEW','Review has changed; refresh and try again');
 const column=reviewType==='identity'?'identity_status':'aml_status',changeId=randomUUID();
 await db.batch([
  db.prepare(`UPDATE manual_compliance_reviews SET ${column}=?,version=version+1,last_change_id=?,updated_at=? WHERE user_id=? AND version=?`).bind(decision,changeId,at,memberId,expectedVersion),
  db.prepare('INSERT INTO manual_compliance_events(id,user_id,reviewer_id,review_type,decision,created_at) SELECT ?,user_id,?,?,?,? FROM manual_compliance_reviews WHERE user_id=? AND last_change_id=?').bind(changeId,reviewerId,reviewType,decision,at,memberId,changeId)
 ]);
 const event=await db.prepare('SELECT id FROM manual_compliance_events WHERE id=?').bind(changeId).first<{id:string}>();
 if(!event)return error(409,'STALE_REVIEW','Review has changed; refresh and try again');
 return getManualCompliance(db,memberId);
}
