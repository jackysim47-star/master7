import {createHash} from 'node:crypto';

export class RewardStateError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

const epoch=()=>Math.floor(Date.now()/1000);
const digest=(value:string)=>createHash('sha256').update(value).digest('hex');
const stable=(value:any):any=>Array.isArray(value)?value.map(stable):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,stable(value[key])])):value;
const stableJson=(value:any)=>JSON.stringify(stable(value));

export type BlockedBenefitClaimInput={
 userId:string;
 benefitRuleId:string;
 requestKey:string;
 depositOrderId:string|null;
 rules:Record<string,unknown>;
 depositMinor:string;
 rewardMinor:string;
 turnoverRequiredMinor:string;
 expiresAt:number;
};

function benefitClaimRecord(row:any){
 return {id:String(row.id),benefitRuleId:String(row.benefit_rule_id),depositOrderId:row.deposit_order_id?String(row.deposit_order_id):null,depositMinor:String(row.deposit_minor),rewardMinor:String(row.reward_minor),turnoverRequiredMinor:String(row.turnover_required_minor),expiresAt:Number(row.expires_at),status:String(row.status),walletCreditStatus:String(row.wallet_credit_status),turnoverSourceStatus:String(row.turnover_source_status),walletCredited:false,turnoverEnforced:false,createdAt:Number(row.created_at),updatedAt:Number(row.updated_at)};
}

export async function createBlockedBenefitClaim(db:D1Database,input:BlockedBenefitClaimInput){
 const existing=await db.prepare('SELECT * FROM benefit_claims WHERE user_id=? AND request_key=?').bind(input.userId,input.requestKey).first<any>();
 if(existing)return {created:false,claim:benefitClaimRecord(existing)};
 if(input.depositOrderId){
  const duplicate=await db.prepare('SELECT * FROM benefit_claims WHERE user_id=? AND benefit_rule_id=? AND deposit_order_id=?').bind(input.userId,input.benefitRuleId,input.depositOrderId).first<any>();
  if(duplicate)return {created:false,claim:benefitClaimRecord(duplicate)};
 }
 const id=crypto.randomUUID(),createdAt=epoch(),turnoverId='to_'+digest(`benefit:${id}`).slice(0,40),postingId='wp_'+digest(`benefit:${id}`).slice(0,40);
 try{
  await db.batch([
   db.prepare("INSERT INTO benefit_claims(id,user_id,benefit_rule_id,request_key,deposit_order_id,rules_snapshot_json,deposit_minor,reward_minor,turnover_required_minor,expires_at,status,wallet_credit_status,turnover_source_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,'awaiting_acceptance','disabled','not_connected',?,?)").bind(id,input.userId,input.benefitRuleId,input.requestKey,input.depositOrderId,stableJson(input.rules),input.depositMinor,input.rewardMinor,input.turnoverRequiredMinor,input.expiresAt,createdAt,createdAt),
   db.prepare("INSERT INTO turnover_obligations(id,source_type,source_id,user_id,required_minor,completed_minor,wager_source_status,status,created_at,updated_at) VALUES(?,'benefit',?,?,?,0,'not_connected','blocked',?,?)").bind(turnoverId,id,input.userId,input.turnoverRequiredMinor,createdAt,createdAt),
   db.prepare("INSERT INTO wallet_posting_intents(id,source_type,source_id,user_id,account_bucket,amount_minor,idempotency_key,status,created_at,updated_at) VALUES(?,'benefit',?,?,'bonus',?,?,'disabled',?,?)").bind(postingId,id,input.userId,input.rewardMinor,`benefit:${id}`,createdAt,createdAt),
  ]);
 }catch(error:any){
  if(!String(error?.message??'').match(/UNIQUE|constraint/i))throw error;
  const raced=await db.prepare('SELECT * FROM benefit_claims WHERE user_id=? AND request_key=?').bind(input.userId,input.requestKey).first<any>()??(input.depositOrderId?await db.prepare('SELECT * FROM benefit_claims WHERE user_id=? AND benefit_rule_id=? AND deposit_order_id=?').bind(input.userId,input.benefitRuleId,input.depositOrderId).first<any>():null);
  if(!raced)throw error;
  return {created:false,claim:benefitClaimRecord(raced)};
 }
 const saved=await db.prepare('SELECT * FROM benefit_claims WHERE id=?').bind(id).first<any>();
 return {created:true,claim:benefitClaimRecord(saved)};
}

export async function listBenefitClaims(db:D1Database,userId:string){
 const result=await db.prepare('SELECT * FROM benefit_claims WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 100').bind(userId).all<any>();
 return (result.results??[]).map(benefitClaimRecord);
}

export async function getBenefitClaimByRequest(db:D1Database,userId:string,requestKey:string){
 const row=await db.prepare('SELECT * FROM benefit_claims WHERE user_id=? AND request_key=?').bind(userId,requestKey).first<any>();
 return row?benefitClaimRecord(row):null;
}

export async function persistCommissionPreview(db:D1Database,actorId:string,settings:any,preview:any){
 if(!settings.configured||!settings.enabled)throw new RewardStateError(409,'Commission program is not configured and enabled');
 if(!preview.basisReady||!preview.scheduleActive)throw new RewardStateError(409,preview.reason||'Commission basis is not ready');
 const settingsSnapshot={...settings,rateBasisPoints:undefined,configured:undefined},settingsJson=stableJson(settingsSnapshot),settingsHash=digest(settingsJson),periodId='cp_'+digest(`${settingsHash}:${preview.period.start}:${preview.period.end}`).slice(0,40),stamp=epoch();
 const statements:any[]=[
  db.prepare("INSERT INTO commission_periods(id,settings_hash,settings_snapshot_json,basis,frequency,period_start,period_end,total_basis_minor,total_commission_minor,status,wallet_credit_status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,'preview','disabled',?,?,?) ON CONFLICT(settings_hash,period_start,period_end) DO UPDATE SET total_basis_minor=excluded.total_basis_minor,total_commission_minor=excluded.total_commission_minor,status='preview',wallet_credit_status='disabled',updated_at=excluded.updated_at").bind(periodId,settingsHash,settingsJson,settings.basis,settings.frequency,preview.period.start,preview.period.end,preview.totalBasisMinor,preview.totalCommissionMinor,actorId,stamp,stamp),
  db.prepare("DELETE FROM wallet_posting_intents WHERE source_type='commission' AND source_id IN (SELECT id FROM commission_entries WHERE period_id=?)").bind(periodId),
  db.prepare('DELETE FROM commission_entries WHERE period_id=?').bind(periodId),
 ];
 for(const entry of preview.ledger??[]){
  const entryId='ce_'+digest(`${periodId}:${entry.uplineId}:${entry.sourceMemberId}:${entry.level}`).slice(0,40),postingId='wp_'+digest(`commission:${entryId}`).slice(0,40);
  statements.push(db.prepare("INSERT INTO commission_entries(id,period_id,upline_user_id,source_user_id,level,rate_basis_points,basis_minor,commission_minor,available_at,expires_at,status,wallet_credit_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,'preview','disabled',?,?)").bind(entryId,periodId,entry.uplineId,entry.sourceMemberId,entry.level,Math.round(Number(entry.ratePercent)*100),entry.basisMinor,entry.commissionMinor,entry.availableAt,entry.expiresAt??null,stamp,stamp));
  statements.push(db.prepare("INSERT INTO wallet_posting_intents(id,source_type,source_id,user_id,account_bucket,amount_minor,idempotency_key,status,created_at,updated_at) VALUES(?,'commission',?,?,'commission',?,?,'disabled',?,?) ON CONFLICT(idempotency_key) DO UPDATE SET amount_minor=excluded.amount_minor,status='disabled',updated_at=excluded.updated_at").bind(postingId,entryId,entry.uplineId,entry.commissionMinor,`commission:${entryId}`,stamp,stamp));
 }
 await db.batch(statements);
 return {periodId,entryCount:(preview.ledger??[]).length,state:'preview',walletCredited:false,idempotencyKey:`${settingsHash}:${preview.period.start}:${preview.period.end}`};
}

export async function listCommissionPeriods(db:D1Database){
 const periods=await db.prepare('SELECT id,basis,frequency,period_start,period_end,total_basis_minor,total_commission_minor,status,wallet_credit_status,created_at,updated_at FROM commission_periods ORDER BY period_end DESC,updated_at DESC LIMIT 50').all<any>();
 return (periods.results??[]).map((row:any)=>({id:String(row.id),basis:String(row.basis),frequency:String(row.frequency),periodStart:Number(row.period_start),periodEnd:Number(row.period_end),totalBasisMinor:String(row.total_basis_minor),totalCommissionMinor:String(row.total_commission_minor),status:String(row.status),walletCreditStatus:String(row.wallet_credit_status),walletCredited:false,createdAt:Number(row.created_at),updatedAt:Number(row.updated_at)}));
}

export async function listCommissionEntries(db:D1Database,periodId:string){
 const entries=await db.prepare('SELECT id,period_id,upline_user_id,source_user_id,level,rate_basis_points,basis_minor,commission_minor,available_at,expires_at,status,wallet_credit_status,created_at,updated_at FROM commission_entries WHERE period_id=? ORDER BY upline_user_id,source_user_id,level LIMIT 5000').bind(periodId).all<any>();
 return (entries.results??[]).map((row:any)=>({id:String(row.id),periodId:String(row.period_id),uplineUserId:String(row.upline_user_id),sourceUserId:String(row.source_user_id),level:Number(row.level),rateBasisPoints:Number(row.rate_basis_points),basisMinor:String(row.basis_minor),commissionMinor:String(row.commission_minor),availableAt:Number(row.available_at),expiresAt:row.expires_at===null?null:Number(row.expires_at),status:String(row.status),walletCreditStatus:String(row.wallet_credit_status),walletCredited:false}));
}

