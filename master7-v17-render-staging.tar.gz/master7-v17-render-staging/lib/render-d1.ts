import { Pool, type PoolClient, type QueryResult } from "pg";
import { postgresSql } from "./render-sql.mjs";

type Result<T = Record<string, unknown>> = {
  results: T[];
  success: true;
  meta: { changes: number };
};

type BoundStatement = {
  sql: string;
  values: unknown[];
};

let pool: Pool | undefined;

function getPool(): Pool {
  if (pool) return pool;
  const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
  if (!connectionString) throw new Error("PORTAL_POSTGRES_URL is required");
  const ssl = process.env.PGSSLMODE === "disable"
    ? false
    : {
        rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== "false",
        ...(process.env.PGSSL_CA ? { ca: process.env.PGSSL_CA.replaceAll("\\n", "\n") } : {}),
      };
  pool = new Pool({
    connectionString,
    ssl,
    max: Number(process.env.PG_POOL_MAX ?? 5),
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
  });
  return pool;
}

async function query(client: Pool | PoolClient, statement: BoundStatement): Promise<QueryResult> {
  return client.query(postgresSql(statement.sql), statement.values);
}

class D1Statement {
  constructor(private readonly statement: BoundStatement) {}

  bind(...values: unknown[]): D1Statement {
    return new D1Statement({ ...this.statement, values });
  }

  async first<T = Record<string, unknown>>(): Promise<T | null> {
    const result = await query(getPool(), this.statement);
    return (result.rows[0] as T | undefined) ?? null;
  }

  async all<T = Record<string, unknown>>(): Promise<Result<T>> {
    const result = await query(getPool(), this.statement);
    return { results: result.rows as T[], success: true, meta: { changes: result.rowCount ?? 0 } };
  }

  async run(): Promise<Result> {
    const result = await query(getPool(), this.statement);
    return { results: result.rows, success: true, meta: { changes: result.rowCount ?? 0 } };
  }

  async execute(client: PoolClient): Promise<Result> {
    const result = await query(client, this.statement);
    return { results: result.rows, success: true, meta: { changes: result.rowCount ?? 0 } };
  }
}

export class RenderD1Compat {
  prepare(sql: string): D1Statement {
    return new D1Statement({ sql, values: [] });
  }

  async batch(statements: D1Statement[]): Promise<Result[]> {
    const client = await getPool().connect();
    try {
      await client.query("BEGIN");
      const results: Result[] = [];
      for (const statement of statements) results.push(await statement.execute(client));
      await client.query("COMMIT");
      return results;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
}

export async function closeRenderPool(): Promise<void> {
  if (pool) await pool.end();
  pool = undefined;
}
