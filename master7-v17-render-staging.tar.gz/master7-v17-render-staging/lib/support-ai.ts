import {generateOpenAiText,openAiGatewayStatus,type OpenAiGatewayConfig} from './openai-gateway.ts';

export const SUPPORT_ASSISTANT_NAME='Stephanie · MASTER7 AI 客服';

export type SupportAiConfig=OpenAiGatewayConfig;
export type SupportCategory='deposit'|'withdrawal'|'security'|'complaint'|'game'|'benefit'|'general';
export type SupportReply={message:string;engine:'openai_compatible'|'built_in_rules_v2';category:SupportCategory;requiresHumanHandoff:boolean;providerAttempted:boolean};

const patterns:Record<Exclude<SupportCategory,'general'>,RegExp>={
 deposit:/deposit|top[ -]?up|payment|存款|充值|入款|汇款|进钱|bank slip|receipt|bayaran|tambah nilai/i,
 withdrawal:/withdraw|payout|提款|出款|取款|pengeluaran/i,
 security:/login|password|passcode|otp|register|account|登录|密码|注册|账号|kata laluan|log masuk|akaun/i,
 complaint:/complaint|fraud|scam|stolen|unauthori[sz]ed|投诉|诈骗|骗子|盗用|penipuan|aduan|dicuri/i,
 game:/game|launch|slot|live|fish|游戏|开不到|不能玩|卡住|permainan|tidak boleh masuk/i,
 benefit:/bonus|benefit|turnover|vip|cashback|commission|dividend|福利|流水|周转|优惠|返水|佣金|分红|ganjaran|komisen/i,
};

function categoryFor(input:string):SupportCategory{for(const category of ['complaint','deposit','withdrawal','security','game','benefit'] as const)if(patterns[category].test(input))return category;return 'general';}
function languageFor(input:string){if(/[\u3400-\u9fff]/u.test(input))return 'zh';if(/\b(?:saya|akaun|bantuan|tidak|boleh|pengeluaran|bayaran|permainan|ganjaran|terima kasih)\b/i.test(input))return 'ms';return 'en';}

const replies={
 deposit:{zh:'我们已收到你的充值查询。请在工单补充付款公司、金额、时间及交易编号；请勿发送密码或 OTP。Master Admin 会核对平台与厂家记录。',en:'We received your deposit enquiry. Please add the payment company, amount, time and transaction reference. Never send a password or OTP. The Master Admin will reconcile the portal and provider records.',ms:'Kami telah menerima pertanyaan deposit anda. Sila tambah nama syarikat pembayaran, jumlah, masa dan rujukan transaksi. Jangan hantar kata laluan atau OTP. Master Admin akan menyemak rekod portal dan penyedia.'},
 withdrawal:{zh:'我们已收到你的提款查询。请提供提款记录编号及银行名称，并先确认游戏钱包已结算；请勿发送密码、OTP 或完整银行号码。Master Admin 会继续审核。',en:'We received your withdrawal enquiry. Please provide the withdrawal record ID and bank name, and confirm that the game wallet is settled. Never send a password, OTP or full bank number. The Master Admin will continue the review.',ms:'Kami telah menerima pertanyaan pengeluaran anda. Sila beri ID rekod pengeluaran dan nama bank serta pastikan dompet permainan telah diselesaikan. Jangan hantar kata laluan, OTP atau nombor bank penuh. Master Admin akan meneruskan semakan.'},
 security:{zh:'我们已收到账户安全查询。请只提供会员 ID 与错误提示；不要在工单发送密码、OTP、完整银行卡号码或安全密钥。Master Admin 会进行身份与安全审核。',en:'We received your account-security enquiry. Send only the member ID and error message. Never post passwords, OTPs, full bank numbers or security keys. The Master Admin will perform the identity and security review.',ms:'Kami telah menerima pertanyaan keselamatan akaun. Hantar ID ahli dan mesej ralat sahaja. Jangan hantar kata laluan, OTP, nombor bank penuh atau kunci keselamatan. Master Admin akan membuat semakan identiti dan keselamatan.'},
 complaint:{zh:'你的投诉已记录并交由 Master Admin 优先审核。请提供相关记录编号、时间和画面提示；不要发送密码、OTP、完整银行号码或安全密钥。',en:'Your complaint is recorded and escalated to the Master Admin for priority review. Please provide the related record ID, time and on-screen message. Never send passwords, OTPs, full bank numbers or security keys.',ms:'Aduan anda telah direkodkan dan dinaikkan kepada Master Admin untuk semakan keutamaan. Sila beri ID rekod, masa dan mesej pada skrin. Jangan hantar kata laluan, OTP, nombor bank penuh atau kunci keselamatan.'},
 game:{zh:'我们已收到游戏问题。请补充厂家名称、游戏名称或编号、发生时间及画面提示，Master Admin 会检查游戏与钱包记录。',en:'We received the game issue. Please add the supplier, game name or code, time and on-screen message so the Master Admin can check the game and wallet records.',ms:'Kami telah menerima masalah permainan. Sila tambah nama penyedia, nama atau kod permainan, masa dan mesej pada skrin supaya Master Admin dapat menyemak rekod permainan dan dompet.'},
 benefit:{zh:'我们已收到 VIP、福利或佣金查询。请提供项目名称及相关记录编号；系统只按已公布且已连接的数据计算，Master Admin 会核对资格。',en:'We received your VIP, benefit or commission enquiry. Please provide the program name and related record ID. The system calculates only from published rules and connected data; the Master Admin will verify eligibility.',ms:'Kami telah menerima pertanyaan VIP, ganjaran atau komisen. Sila beri nama program dan ID rekod berkaitan. Sistem hanya mengira berdasarkan peraturan diterbitkan dan data yang disambungkan; Master Admin akan menyemak kelayakan.'},
 general:{zh:'你的信息已收到并建立工单。请补充相关记录编号、发生时间及画面提示；Master Admin 会在同一工单继续回复。请勿发送密码或 OTP。',en:'Your message is recorded as a ticket. Please add any record ID, time and on-screen message. The Master Admin will continue in this ticket. Never send a password or OTP.',ms:'Mesej anda telah direkodkan sebagai tiket. Sila tambah ID rekod, masa dan mesej pada skrin. Master Admin akan meneruskan dalam tiket ini. Jangan hantar kata laluan atau OTP.'},
} as const;

function formatReply(body:string,language:string){const disclosure=language==='zh'?'此回复由 Stephanie AI 客服提供；需要审核的事项将由 Master Admin 跟进。':language==='ms'?'Balasan ini diberikan oleh khidmat AI Stephanie; perkara yang memerlukan semakan akan disusuli oleh Master Admin.':'This reply is provided by Stephanie AI support; matters requiring review will be followed up by the Master Admin.';return `${SUPPORT_ASSISTANT_NAME}\n${body}\n\n${disclosure}`;}

export function builtInSupportReply(subject:string,message:string):SupportReply{
 const input=`${subject}\n${message}`,category=categoryFor(input),language=languageFor(input),body=replies[category][language as 'zh'|'en'|'ms'];
 return {message:formatReply(body,language),engine:'built_in_rules_v2',category,requiresHumanHandoff:['deposit','withdrawal','security','complaint'].includes(category),providerAttempted:false};
}

export function supportAiProviderStatus(config:SupportAiConfig){const status=openAiGatewayStatus(config);return {assistantName:SUPPORT_ASSISTANT_NAME,externalProvider:'openai_compatible',externalProviderConfigured:status.configured,externalProviderEnabled:status.enabled,externalProviderReady:status.ready,rulesFallbackReady:status.rulesFallbackReady,modelConfigured:status.modelConfigured,serverOnly:status.serverOnly,transactionAutomation:status.transactionAutomation,tasks:status.tasks};}

function externalEligible(reply:SupportReply,input:string){return !reply.requiresHumanHandoff&&!/(?:BEGIN [A-Z ]+ KEY|api[_ -]?key|secret[_ -]?key|bearer\s+[A-Za-z0-9._-]+)/i.test(input);}

export async function generateSupportReply(config:SupportAiConfig,subject:string,message:string):Promise<SupportReply>{
 const fallback=builtInSupportReply(subject,message),status=supportAiProviderStatus(config),input=`${subject}\n${message}`;
 if(!status.externalProviderReady||!externalEligible(fallback,input))return fallback;
 const result=await generateOpenAiText(config,{task:'support_reply',systemPrompt:'You are Stephanie, the clearly disclosed AI customer-support assistant for MASTER7. Reply in the customer language: Chinese, English, or Bahasa Melayu. Be concise and warm. Never claim that a deposit, withdrawal, wallet, game, VIP reward, cashback, commission, dividend, account status, or settlement is approved, completed, connected, or verified unless that fact appears in the user message; do not make financial decisions or change records. Never request a password, OTP, full bank number, API key, or secret. Ask for a non-sensitive record ID and time when useful. State that the Master Admin will review anything involving money, security, complaints, or unavailable records. Do not invent promotions, rates, balances, provider status, or timelines.',userPrompt:input,maxTokens:350});
 if(!result.text)return {...fallback,providerAttempted:result.providerAttempted};
 return {message:formatReply(result.text,languageFor(input)),engine:'openai_compatible',category:fallback.category,requiresHumanHandoff:false,providerAttempted:true};
}
