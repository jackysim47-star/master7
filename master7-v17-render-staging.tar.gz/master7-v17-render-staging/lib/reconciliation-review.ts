import {createHash,randomUUID} from 'node:crypto';
import {reconcileStatements} from './reconciliation.ts';

export type ReconciliationReviewActor={id:string;role:string};
export type ReconciliationReviewDecision='acknowledged'|'needs_follow_up';

type RunRow={
 run_id:string;report_sha256:string;schema_version:string;source_commit:string;mapping_version:string;rule_version:string;
 internal_snapshot_id:string;period_start:string;period_end_exclusive:string;result:string;internal_count:number|string;
 external_count:number|string;matched_count:number|string;discrepancy_count:number|string;report_json?:string;
 evidence_reference:string;recorded_by:string;recorded_at:number|string;review_id:string|null;review_revision:number|string|null;
 review_decision:string|null;review_note:string|null;review_evidence_reference:string|null;reviewed_by:string|null;reviewed_at:number|string|null;
};

type ReviewRow={id:string;run_id:string;revision:number|string;decision:ReconciliationReviewDecision;note:string;evidence_reference:string;request_key:string;reviewed_by:string;reviewed_at:number|string};
type ReportIntegrityRow=Pick<RunRow,'run_id'|'report_sha256'|'schema_version'|'source_commit'|'mapping_version'|'rule_version'|'internal_snapshot_id'|'period_start'|'period_end_exclusive'|'result'|'internal_count'|'external_count'|'matched_count'|'discrepancy_count'|'report_json'>;
const reportIntegrityColumns=['run_id','report_sha256','schema_version','source_commit','mapping_version','rule_version','internal_snapshot_id','period_start','period_end_exclusive','result','internal_count','external_count','matched_count','discrepancy_count','report_json'] as const;

export class ReconciliationReviewError extends Error{
 status:number;code:string;
 constructor(status:number,code:string,message:string){super(message);this.status=status;this.code=code;}
}

const fail=(status:number,code:string,message:string):never=>{throw new ReconciliationReviewError(status,code,message);};
const sha256=(value:string)=>createHash('sha256').update(value).digest('hex');
const actorId=(value:unknown):value is string=>typeof value==='string'&&value.length>0&&value.length<=256&&!/[\u0000-\u001f\u007f]/u.test(value);
const runId=(value:unknown):value is string=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const reference=(value:unknown):value is string=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9_.:/#-]{0,199}$/.test(value);
const requestKey=(value:unknown):value is string=>typeof value==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(value);
const changed=(value:unknown)=>Number((value as any)?.meta?.changes??(value as any)?.changes??0);

function readAccess(actor:ReconciliationReviewActor){
 if(!actorId(actor?.id))fail(401,'SIGN_IN_REQUIRED','Sign in required');
 if(actor.role!=='owner'&&actor.role!=='staff')fail(403,'ACCESS_DENIED','Owner or staff access required');
}
function ownerAccess(actor:ReconciliationReviewActor){
 if(!actorId(actor?.id))fail(401,'SIGN_IN_REQUIRED','Sign in required');
 if(actor.role!=='owner')fail(403,'OWNER_REQUIRED','Owner access required');
}
function storedReport(row:ReportIntegrityRow){
 const value=row.report_json;if(typeof value!=='string')throw new ReconciliationReviewError(409,'RECONCILIATION_INTEGRITY_ERROR','Stored reconciliation report digest does not match');
 if(sha256(value)!==row.report_sha256)fail(409,'RECONCILIATION_INTEGRITY_ERROR','Stored reconciliation report digest does not match');
 let parsed:unknown;try{parsed=JSON.parse(value);}catch{fail(409,'RECONCILIATION_INTEGRITY_ERROR','Stored reconciliation report is invalid');}
 if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))fail(409,'RECONCILIATION_INTEGRITY_ERROR','Stored reconciliation report is invalid');
 const report=parsed as ReturnType<typeof reconcileStatements>,counts=report.counts,period=report.period;
 if(report.schemaVersion!==row.schema_version||report.runId!==row.run_id||report.sourceCommit!==row.source_commit||report.mappingVersion!==row.mapping_version||report.ruleVersion!==row.rule_version||report.internalSnapshotId!==row.internal_snapshot_id||period?.startUtc!==row.period_start||period?.endUtcExclusive!==row.period_end_exclusive||report.result!==row.result||counts?.internal!==Number(row.internal_count)||counts?.external!==Number(row.external_count)||counts?.matched!==Number(row.matched_count)||counts?.discrepancies!==Number(row.discrepancy_count)||report.scope!=='canonical_input_comparison_only'||!Array.isArray(report.financialActions)||report.financialActions.length!==0||report.ownerReview!=='pending')fail(409,'RECONCILIATION_INTEGRITY_ERROR','Stored reconciliation report metadata does not match');
 return report;
}
async function reviewableReport(db:D1Database,selectedRun:string){
 const row=await db.prepare(`SELECT ${reportIntegrityColumns.join(',')} FROM reconciliation_runs WHERE run_id=?`).bind(selectedRun).first<ReportIntegrityRow>();
 if(!row)return fail(404,'RUN_NOT_FOUND','Reconciliation run not found');
 storedReport(row);return row;
}
function result(row:RunRow,includeReport=false){
 const review=row.review_id?{id:row.review_id,revision:Number(row.review_revision),decision:row.review_decision,note:row.review_note,evidenceReference:row.review_evidence_reference,reviewedBy:row.reviewed_by,reviewedAt:Number(row.reviewed_at)}:null;
 return {runId:row.run_id,reportSha256:row.report_sha256,schemaVersion:row.schema_version,sourceCommit:row.source_commit,mappingVersion:row.mapping_version,ruleVersion:row.rule_version,internalSnapshotId:row.internal_snapshot_id,period:{startUtc:row.period_start,endUtcExclusive:row.period_end_exclusive},result:row.result,counts:{internal:Number(row.internal_count),external:Number(row.external_count),matched:Number(row.matched_count),discrepancies:Number(row.discrepancy_count)},evidenceReference:row.evidence_reference,recordedBy:row.recorded_by,recordedAt:Number(row.recorded_at),review,reportIntegrity:includeReport?'verified':'not_loaded',...(includeReport?{report:storedReport(row)}:{})};
}

const runSelect=`SELECT r.run_id,r.report_sha256,r.schema_version,r.source_commit,r.mapping_version,r.rule_version,
 r.internal_snapshot_id,r.period_start,r.period_end_exclusive,r.result,r.internal_count,r.external_count,r.matched_count,
 r.discrepancy_count,r.evidence_reference,r.recorded_by,r.recorded_at,
 e.id review_id,e.revision review_revision,e.decision review_decision,e.note review_note,
 e.evidence_reference review_evidence_reference,e.reviewed_by,e.reviewed_at`;
const latestReviewJoin=`LEFT JOIN reconciliation_review_events e ON e.id=(SELECT latest.id FROM reconciliation_review_events latest WHERE latest.run_id=r.run_id ORDER BY latest.revision DESC LIMIT 1)`;

export async function getReconciliationRuns(db:D1Database,actor:ReconciliationReviewActor,input:{limit?:unknown;runId?:unknown}={}){
 readAccess(actor);
 const limit=input.limit===undefined?20:Number(input.limit);if(!Number.isSafeInteger(limit)||limit<1||limit>100)fail(400,'INVALID_LIMIT','Limit must be between 1 and 100');
 const selectedRun=input.runId===undefined||input.runId===null||input.runId===''?null:input.runId;if(selectedRun!==null&&!runId(selectedRun))fail(400,'INVALID_RUN_ID','Invalid reconciliation run ID');
 let rows:RunRow[];
 if(selectedRun){const row=await db.prepare(`${runSelect},r.report_json FROM reconciliation_runs r ${latestReviewJoin} WHERE r.run_id=?`).bind(selectedRun).first<RunRow>();rows=row?[row]:[];}
 else rows=((await db.prepare(`${runSelect} FROM reconciliation_runs r ${latestReviewJoin} ORDER BY r.recorded_at DESC,r.run_id DESC LIMIT ?`).bind(limit).all<RunRow>()).results??[]) as RunRow[];
 return {items:rows.map(row=>result(row,selectedRun!==null)),readOnlyReports:true,reviewAnnotationsOnly:true,financialActions:[] as never[],acceptanceGranted:false,productionStateChanged:false};
}

export async function recordReconciliationRun(db:D1Database,actor:ReconciliationReviewActor,input:Record<string,unknown>,at=Math.floor(Date.now()/1000)){
 ownerAccess(actor);
 if(Object.keys(input).some(key=>!['input','evidenceReference'].includes(key)))fail(400,'INVALID_FIELDS','Only canonical input and evidence reference are accepted');
 const evidenceReference=typeof input.evidenceReference==='string'?input.evidenceReference.trim():'';if(!reference(evidenceReference))fail(400,'INVALID_EVIDENCE_REFERENCE','Evidence reference must be a non-secret identifier');
 let report:ReturnType<typeof reconcileStatements>;try{report=reconcileStatements(input.input);}catch(error){const message=String(error instanceof Error?error.message:error);if(message.startsWith('RECONCILIATION_INPUT_INVALID:'))fail(400,'INVALID_RECONCILIATION_INPUT',message);throw error;}
 const reportJson=JSON.stringify(report);if(Buffer.byteLength(reportJson)>2_000_000)fail(413,'REPORT_TOO_LARGE','Reconciliation report exceeds the persistence limit');
 const reportSha256=sha256(reportJson),existing=await db.prepare(`SELECT run_id,report_sha256,schema_version,source_commit,mapping_version,rule_version,internal_snapshot_id,period_start,period_end_exclusive,result,internal_count,external_count,matched_count,discrepancy_count,report_json FROM reconciliation_runs WHERE run_id=?`).bind(report.runId).first<ReportIntegrityRow>();
 if(existing){storedReport(existing);if(existing.report_sha256!==reportSha256)fail(409,'RECONCILIATION_INTEGRITY_ERROR','Stored reconciliation report digest does not match');return {status:'recorded',runId:report.runId,reportSha256,result:report.result,counts:report.counts,idempotent:true,financialActions:[] as never[],acceptanceGranted:false,productionStateChanged:false};}
 const auditId=`reconciliation-run:${report.runId}`,auditTarget=JSON.stringify({runId:report.runId,reportSha256,result:report.result});
 const statements=await db.batch([
  db.prepare(`INSERT INTO reconciliation_runs(run_id,report_sha256,schema_version,source_commit,mapping_version,rule_version,internal_snapshot_id,period_start,period_end_exclusive,result,internal_count,external_count,matched_count,discrepancy_count,report_json,evidence_reference,recorded_by,recorded_at)
   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(run_id) DO NOTHING`).bind(report.runId,reportSha256,report.schemaVersion,report.sourceCommit,report.mappingVersion,report.ruleVersion,report.internalSnapshotId,report.period.startUtc,report.period.endUtcExclusive,report.result,report.counts.internal,report.counts.external,report.counts.matched,report.counts.discrepancies,reportJson,evidenceReference,actor.id,at),
  db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'reconciliation_run_recorded',?,? WHERE EXISTS(SELECT 1 FROM reconciliation_runs WHERE run_id=? AND report_sha256=?) ON CONFLICT(id) DO NOTHING").bind(auditId,actor.id,auditTarget,at,report.runId,reportSha256),
 ]);
 const saved=await db.prepare('SELECT report_sha256 FROM reconciliation_runs WHERE run_id=?').bind(report.runId).first<{report_sha256:string}>();if(!saved||saved.report_sha256!==reportSha256)fail(409,'RECONCILIATION_INTEGRITY_ERROR','Reconciliation run was not persisted exactly');
 return {status:'recorded',runId:report.runId,reportSha256,result:report.result,counts:report.counts,idempotent:changed(statements[0])!==1,financialActions:[] as never[],acceptanceGranted:false,productionStateChanged:false};
}

function sameReview(row:ReviewRow,input:{decision:ReconciliationReviewDecision;note:string;evidenceReference:string},actor:ReconciliationReviewActor){return row.decision===input.decision&&row.note===input.note&&row.evidence_reference===input.evidenceReference&&row.reviewed_by===actor.id;}
function reviewResult(row:ReviewRow,idempotent:boolean){return {status:'recorded',id:row.id,runId:row.run_id,revision:Number(row.revision),decision:row.decision,note:row.note,evidenceReference:row.evidence_reference,reviewedBy:row.reviewed_by,reviewedAt:Number(row.reviewed_at),idempotent,reviewAnnotationsOnly:true,financialActions:[] as never[],acceptanceGranted:false,productionStateChanged:false};}

export async function recordReconciliationReview(db:D1Database,actor:ReconciliationReviewActor,input:Record<string,unknown>,at=Math.floor(Date.now()/1000)){
 ownerAccess(actor);
 if(Object.keys(input).some(key=>!['runId','expectedRevision','decision','note','evidenceReference','requestKey'].includes(key)))fail(400,'INVALID_FIELDS','Only reconciliation review fields are accepted');
 if(!runId(input.runId))return fail(400,'INVALID_RUN_ID','Invalid reconciliation run ID');const selectedRun=input.runId;
 const expectedRevision=Number(input.expectedRevision);if(!Number.isSafeInteger(expectedRevision)||expectedRevision<0)fail(400,'INVALID_EXPECTED_REVISION','Expected review revision is required');
 const requestedDecision=input.decision;
 if(requestedDecision!=='acknowledged'&&requestedDecision!=='needs_follow_up')fail(400,'INVALID_DECISION','Review decision must be acknowledged or needs_follow_up');
 const decision=requestedDecision as ReconciliationReviewDecision;
 const note=typeof input.note==='string'?input.note.trim():'';if(note.length<5||note.length>500||/[\u0000-\u001f\u007f]/u.test(note))fail(400,'INVALID_NOTE','Review note must contain 5 to 500 safe characters');
 const evidenceReference=typeof input.evidenceReference==='string'?input.evidenceReference.trim():'';if(!reference(evidenceReference))fail(400,'INVALID_EVIDENCE_REFERENCE','Evidence reference must be a non-secret identifier');
 if(!requestKey(input.requestKey))fail(400,'INVALID_REQUEST_KEY','Review request key must contain 16 to 80 safe characters');const selectedRequestKey=input.requestKey;
 const run=await reviewableReport(db,selectedRun);
 const values={decision,note,evidenceReference},replay=await db.prepare('SELECT * FROM reconciliation_review_events WHERE run_id=? AND request_key=?').bind(selectedRun,selectedRequestKey).first<ReviewRow>();
 if(replay){if(!sameReview(replay,values,actor))fail(409,'REVIEW_REQUEST_CONFLICT','Review request key was already used with different values');return reviewResult(replay,true);}
 const latest=await db.prepare('SELECT revision FROM reconciliation_review_events WHERE run_id=? ORDER BY revision DESC LIMIT 1').bind(selectedRun).first<{revision:number|string}>(),currentRevision=Number(latest?.revision??0);if(expectedRevision!==currentRevision)fail(409,'STALE_REVIEW','Review changed; refresh and try again');
 const id=randomUUID(),revision=expectedRevision+1,auditId=`reconciliation-review:${id}`,auditTarget=JSON.stringify({runId:selectedRun,revision,decision});
 try{await db.batch([
  db.prepare(`INSERT INTO reconciliation_review_events(id,run_id,revision,decision,note,evidence_reference,request_key,reviewed_by,reviewed_at)
   SELECT ?,?,?,?,?,?,?,?,? WHERE ?=COALESCE((SELECT MAX(revision) FROM reconciliation_review_events WHERE run_id=?),0)
   AND EXISTS(SELECT 1 FROM reconciliation_runs WHERE ${reportIntegrityColumns.map(column=>`${column}=?`).join(' AND ')})`).bind(id,selectedRun,revision,decision,note,evidenceReference,selectedRequestKey,actor.id,at,expectedRevision,selectedRun,...reportIntegrityColumns.map(column=>run[column])),
  db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'reconciliation_owner_review_recorded',?,? FROM reconciliation_review_events WHERE id=? ON CONFLICT(id) DO NOTHING").bind(auditId,actor.id,auditTarget,at,id),
 ]);}catch(error){
  const existing=await db.prepare('SELECT * FROM reconciliation_review_events WHERE run_id=? AND request_key=?').bind(selectedRun,selectedRequestKey).first<ReviewRow>();if(existing){await reviewableReport(db,selectedRun);if(!sameReview(existing,values,actor))fail(409,'REVIEW_REQUEST_CONFLICT','Review request key was already used with different values');return reviewResult(existing,true);}const detail=String(error instanceof Error?error.message:error);if(/unique|duplicate/i.test(detail))fail(409,'STALE_REVIEW','Review changed; refresh and try again');throw error;
 }
 const saved=await db.prepare('SELECT * FROM reconciliation_review_events WHERE id=?').bind(id).first<ReviewRow>();if(!saved){await reviewableReport(db,selectedRun);return fail(409,'STALE_REVIEW','Review changed; refresh and try again');}return reviewResult(saved,false);
}
