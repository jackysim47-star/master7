import {megaClosureProofSql} from './mega-session-closure.ts';
import {providerWalletRiskFreeSql,providerTerminalHoldEvidenceSql} from './provider-wallet-consistency.ts';
import {manualPayoutEvidenceSql} from './manual-bank-evidence.ts';
import {createHash} from 'node:crypto';
import {malaysiaBank,malaysiaBanks} from './malaysia-banks.ts';
import {malaysiaEwallet,malaysiaEwallets,malaysiaMemberPhone,maskMalaysiaPhone} from './malaysia-ewallets.ts';
import {decryptWithdrawalValue,encryptWithdrawalValue,withdrawalDataKeyReady} from './withdrawal-secrets.ts';
import {walletGuardStatements,walletGuardedReservation,walletRiskFreeSql,walletAvailableSql} from './wallet-guard.ts';
import {genericGameWalletConsistency,genericGameWalletRiskFreeSql} from './game-wallet-consistency.ts';

type Member={id:string;username:string;role:string;approved:number};
type PayoutSubmission={status:'processing'|'succeeded'|'failed'|'review';providerReference?:string|null};
type PayoutAdapter={enabled:boolean;reason:string;allowsMember?:(id:string)=>Promise<boolean>;supportsBank?:(bankCode:string)=>boolean;submit:(input:{payoutId:string;withdrawalId:string;userId:string;accountHolder:string;accountNumber:string;bankCode:string;amountMinor:string})=>Promise<PayoutSubmission>};
type WithdrawalContext={db:D1Database;user:Member|null;dataKey?:string;payouts?:Partial<Record<'vpay'|'gspay'|'1mpay'|'manual_bank',PayoutAdapter>>};
type WithdrawalProvider={id:'vpay'|'gspay'|'1mpay'|'manual_bank';name:string;enabled:boolean;reason:string};

const responseHeaders={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:responseHeaders});
const amountMinor=(value:unknown)=>{if(typeof value!=='string'||!/^(0|[1-9]\d{0,5})(?:\.(\d{1,2}))?$/.test(value))return null;const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));return minor>0n&&minor<=10000000n?minor.toString():null;};
const providers=(c?:WithdrawalContext):readonly WithdrawalProvider[]=>[
 {id:'manual_bank',name:'Company Bank',enabled:c?.payouts?.manual_bank?.enabled===true,reason:c?.payouts?.manual_bank?.reason??'Company-bank withdrawals are closed'},
 {id:'vpay',name:'VPay',enabled:c?.payouts?.vpay?.enabled===true,reason:c?.payouts?.vpay?.reason??'Payout adapter is not configured'},
 {id:'gspay',name:'GSPAY+',enabled:c?.payouts?.gspay?.enabled===true,reason:c?.payouts?.gspay?.reason??'Payout adapter is not configured'},
 {id:'1mpay',name:'1MPAY',enabled:c?.payouts?.['1mpay']?.enabled===true,reason:c?.payouts?.['1mpay']?.reason??'Payout adapter is not configured'},
];
const provider=(value:unknown,c:WithdrawalContext)=>providers(c).find(x=>x.id===value);
const cleanName=(value:unknown)=>typeof value==='string'&&value.trim().length>=2&&value.trim().length<=80&&!/[\u0000-\u001f\u007f-\u009f]/u.test(value)?value.trim():null;
const cleanAccount=(value:unknown)=>{const account=typeof value==='string'?value.replace(/[\s-]/g,''):'';return /^\d{6,20}$/.test(account)?account:null;};
const destinationType=(x:any):'bank'|'ewallet'=>x.destination_type==='ewallet'?'ewallet':'bank';
const record=(x:any)=>{const method=destinationType(x),last4=method==='ewallet'?x.ewallet_account_last4:x.account_last4;return {id:x.id,userId:x.user_id,username:x.username??undefined,providerId:x.provider_id,providerName:x.provider_name,destinationType:method,destinationMethod:method==='ewallet'?'E-Wallet':'Bank Account',bankCode:method==='bank'?x.bank_code:undefined,bankName:method==='bank'?x.bank_name:undefined,ewalletCode:method==='ewallet'?x.ewallet_code:undefined,ewalletName:method==='ewallet'?x.ewallet_name:undefined,destinationNumber:`•••• ${last4}`,accountNumber:`•••• ${last4}`,accountLast4:last4,amountMinor:String(x.amount_minor),currency:x.currency,status:x.status,ownerNote:x.owner_note,createdAt:Number(x.created_at),updatedAt:Number(x.updated_at)};};
const ownerBaseRecord=(x:any)=>{const redacted:Record<string,unknown>={...record(x),payoutId:x.payout_id,payoutStatus:x.payout_status,payoutReference:x.payout_reference,companyBankId:x.manual_bank_account_id,bankTransactionId:x.provider_id==='manual_bank'?x.payout_reference:undefined,auditReference:`MASTER7 ${x.id}`,reviewStatus:x.status};delete redacted.accountNumber;delete redacted.destinationNumber;return redacted;};
// The owner needs the recipient name and account suffix for a human review,
// never the full account number. Decrypt both fields only to validate that the
// server-side approval fingerprint still describes readable, matching data.
const ownerRecord=(x:any,secret?:string)=>{
 const method=destinationType(x),accountHolder=decryptWithdrawalValue(x.account_holder_encrypted,secret),encrypted=method==='ewallet'?x.ewallet_account_encrypted:x.account_number_encrypted,accountNumber=decryptWithdrawalValue(encrypted,secret),last4=method==='ewallet'?x.ewallet_account_last4:x.account_last4;
 if(!cleanName(accountHolder)||!(method==='ewallet'?malaysiaMemberPhone(accountNumber):cleanAccount(accountNumber))||!/^\d{4}$/.test(last4)||accountNumber.slice(-4)!==last4)throw Error('Invalid recipient data');
 return {...ownerBaseRecord(x),accountHolder};
};
// SQL expression has only static literals; it works on both SQLite and PostgreSQL.
const withoutDigits=Array.from('0123456789').reduce((sql,digit)=>`REPLACE(${sql},'${digit}','')`,'p.provider_reference');
const payoutReferenceValidSql=`(${manualPayoutEvidenceSql} OR (p.provider_id='vpay' AND p.provider_reference=p.id) OR (p.provider_id='gspay' AND LENGTH(p.provider_reference) BETWEEN 1 AND 40 AND SUBSTR(p.provider_reference,1,1)<>'0' AND ${withoutDigits}=''))`;

// The owner must approve precisely the recipient and amount displayed on the list.
export const approvalFingerprint=(x:any)=>createHash('sha256').update(JSON.stringify(destinationType(x)==='bank'?[x.id,x.payout_id,x.user_id,x.provider_id,x.request_key,String(x.amount_minor),x.currency,x.bank_code,x.account_holder_encrypted,x.account_number_encrypted,x.payout_fingerprint,String(x.compliance_version)]:[x.id,x.payout_id,x.user_id,x.provider_id,x.request_key,String(x.amount_minor),x.currency,'ewallet',x.ewallet_code,x.account_holder_encrypted,x.ewallet_account_encrypted,x.payout_fingerprint,String(x.compliance_version)])).digest('hex');
export const approvalQuery=`SELECT w.*,u.username,p.id payout_id,p.fingerprint payout_fingerprint,p.status payout_status,p.create_outcome payout_outcome,p.provider_reference payout_reference,p.manual_bank_account_id,c.version compliance_version,
 CASE WHEN c.identity_status='passed' AND c.aml_status='passed' AND w.status='pending' AND p.status='prepared' AND p.create_outcome='not_submitted' AND p.provider_reference IS NULL
 AND p.provider_id=w.provider_id AND p.request_key=w.request_key AND p.amount_minor=w.amount_minor AND p.currency=w.currency
 AND EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.kind='withdrawal' AND r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor)
 AND EXISTS (SELECT 1 FROM audit a WHERE a.id='withdrawal_request_v1_'||w.id AND a.event='withdrawal_requested_v1' AND a.target=w.id AND a.user_id=w.user_id)
 THEN 1 ELSE 0 END approval_eligible
 FROM withdrawal_requests w JOIN users u ON u.id=w.user_id LEFT JOIN provider_payouts p ON p.withdrawal_id=w.id LEFT JOIN manual_compliance_reviews c ON c.user_id=w.user_id`;

async function verifiedPaidWithdrawal(db:D1Database,userId:string,id:string){
 const wallet=await withdrawalWalletState(db,userId);if(wallet.reconciliationRequired)return false;
 return !!await db.prepare(`SELECT w.id FROM withdrawal_requests w JOIN provider_payouts p ON p.withdrawal_id=w.id
  WHERE w.id=? AND w.user_id=? AND w.status='paid' AND p.status='succeeded' AND p.create_outcome='accepted'
   AND p.provider_id=w.provider_id AND p.request_key=w.request_key AND p.amount_minor=w.amount_minor AND p.currency=w.currency
   AND COALESCE(p.last_error_code,'')='' AND ${payoutReferenceValidSql}
   AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.reference_id=w.id)`).bind(id,userId).first();
}
async function verifiedUnsubmittedCancellation(db:D1Database,userId:string,id:string){
 const wallet=await withdrawalWalletState(db,userId);if(wallet.reconciliationRequired)return false;
 return !!await db.prepare(`SELECT w.id FROM withdrawal_requests w JOIN provider_payouts p ON p.withdrawal_id=w.id
  WHERE w.id=? AND w.user_id=? AND w.status IN ('rejected','cancelled') AND p.status='failed' AND p.create_outcome='not_submitted'
   AND p.provider_id=w.provider_id AND p.request_key=w.request_key AND p.amount_minor=w.amount_minor AND p.currency=w.currency
   AND p.provider_reference IS NULL AND SUBSTR(COALESCE(p.last_error_code,''),1,13)='owner_cancel_'
   AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.reference_id=w.id)`).bind(id,userId).first();
}

export async function withdrawalWalletState(db:D1Database,userId:string){
 // Generic sessions and unmatched reservations stay held until a settlement
 // or review flow explicitly removes them; a status alone cannot prove posting.
 const values=await db.prepare(`SELECT
  CAST(COALESCE((SELECT SUM(member.amount_minor)
   FROM wallet_ledger member
   JOIN deposit_orders orders ON orders.id=member.order_id AND orders.user_id=member.user_id
   JOIN wallet_ledger clearing ON clearing.order_id=member.order_id AND clearing.account_code='provider_clearing'
   WHERE member.user_id=? AND member.account_code='member' AND member.currency='MYR'
    AND orders.status='credited' AND orders.currency='MYR' AND member.amount_minor=orders.amount_minor
    AND clearing.user_id=orders.user_id AND clearing.currency='MYR' AND clearing.amount_minor=-orders.amount_minor),0) AS TEXT) credits,
  CAST(COALESCE((SELECT SUM(l.amount_minor) FROM game_wallet_ledger l JOIN game_wallet_sessions s ON s.id=l.session_id AND s.user_id=l.user_id WHERE l.user_id=? AND s.status='settled' AND s.amount_returned_minor IS NOT NULL AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=s.amount_returned_minor-s.amount_out_minor),0) AS TEXT) game_results,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=? AND status='paid' AND currency='MYR'),0) AS TEXT) paid,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=? AND status IN ('pending','approved','processing') AND currency='MYR'),0) AS TEXT) withdrawal_held,
  CAST(COALESCE((SELECT SUM(amount_out_minor) FROM game_wallet_sessions WHERE user_id=? AND status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')),0)
   + COALESCE((SELECT SUM(r.amount_minor) FROM wallet_reservations r WHERE r.user_id=? AND r.kind='game' AND (
     EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.id=r.reference_id AND s.user_id=r.user_id)
     OR NOT EXISTS (SELECT 1 FROM game_wallet_sessions g WHERE g.id=r.reference_id AND g.user_id=r.user_id AND g.status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')))),0) AS TEXT) game_held`).bind(userId,userId,userId,userId,userId,userId).first<any>();
 const credits=BigInt(values?.credits??0),gameResults=BigInt(values?.game_results??0),paid=BigInt(values?.paid??0),withdrawalHeld=BigInt(values?.withdrawal_held??0),gameHeld=BigInt(values?.game_held??0),balance=credits+gameResults-paid,held=withdrawalHeld+gameHeld,available=balance-held;
 const unreserved=await db.prepare(`SELECT s.id FROM game_provider_sessions s WHERE s.user_id=? AND s.wallet_mode='transfer' AND s.status IN ('prepared','launching','active','settling','unknown','review')
  AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.user_id=s.user_id AND r.kind='game' AND r.reference_id=s.id) LIMIT 1`).bind(userId).first();
 const invalidGameResult=await db.prepare(`SELECT s.id FROM game_wallet_sessions s LEFT JOIN game_wallet_ledger l ON l.session_id=s.id WHERE (s.user_id=? OR l.user_id=?) AND ((s.status='settled' AND (s.amount_returned_minor IS NULL OR l.id IS NULL OR l.user_id<>s.user_id OR l.account_code<>'game_result' OR l.currency<>'MYR' OR l.amount_minor<>s.amount_returned_minor-s.amount_out_minor)) OR (s.status<>'settled' AND l.id IS NOT NULL)) LIMIT 1`).bind(userId,userId).first();
 // An unresolved provider launch cannot justify a settled or unreserved wallet.
 const invalidLaunch=await db.prepare(`SELECT o.id FROM megah5_launch_operations o LEFT JOIN game_wallet_sessions s ON s.id=o.wallet_session_id LEFT JOIN wallet_reservations r ON r.kind='game' AND r.reference_id=o.wallet_session_id WHERE (o.user_id=? OR s.user_id=?) AND ((o.state='closed' AND NOT ${megaClosureProofSql('o')}) OR (o.state<>'closed' AND (s.id IS NULL OR s.user_id<>o.user_id OR s.game_code<>o.game_code OR s.status<>'active' OR r.user_id IS NULL OR r.user_id<>s.user_id OR r.amount_minor<>s.amount_out_minor))) LIMIT 1`).bind(userId,userId).first();
 // Historical payout/withdrawal contradictions must never turn a released
 // or absent reservation into spendable funds. A missing payout is not proof
 // that an older external transfer was never submitted: require reconciliation.
 const invalidWithdrawal=await db.prepare(`SELECT w.id FROM withdrawal_requests w LEFT JOIN provider_payouts p ON p.withdrawal_id=w.id
  LEFT JOIN wallet_reservations r ON r.kind='withdrawal' AND r.reference_id=w.id
  WHERE w.user_id=? AND (
   p.id IS NULL
   OR (p.id IS NOT NULL AND (p.provider_id<>w.provider_id OR p.request_key<>w.request_key OR p.amount_minor<>w.amount_minor OR p.currency<>w.currency))
   OR (r.user_id IS NOT NULL AND (r.user_id<>w.user_id OR r.amount_minor<>w.amount_minor))
   OR (w.status IN ('pending','approved','processing') AND (r.user_id IS NULL OR r.user_id<>w.user_id OR r.amount_minor<>w.amount_minor))
   OR (p.id IS NOT NULL AND p.status='review')
   OR (p.id IS NOT NULL AND p.status='prepared' AND (p.create_outcome<>'not_submitted' OR p.provider_reference IS NOT NULL))
   OR (p.id IS NOT NULL AND p.status='submitting' AND p.create_outcome<>'in_flight')
   OR (w.status='paid' AND (p.id IS NULL OR p.status<>'succeeded' OR p.create_outcome<>'accepted' OR COALESCE(p.last_error_code,'')<>'' OR NOT COALESCE(${payoutReferenceValidSql},FALSE)))
   OR (p.id IS NOT NULL AND w.status IN ('rejected','cancelled') AND NOT (p.status='failed' AND p.create_outcome='not_submitted' AND p.provider_reference IS NULL AND SUBSTR(COALESCE(p.last_error_code,''),1,13)='owner_cancel_'))
   OR (p.id IS NOT NULL AND w.status IN ('pending','approved','processing') AND p.status IN ('succeeded','failed','reversed'))
  ) UNION ALL
  SELECT r.reference_id FROM wallet_reservations r WHERE r.user_id=? AND r.kind='withdrawal' AND NOT EXISTS (
   SELECT 1 FROM withdrawal_requests w WHERE w.id=r.reference_id AND w.user_id=r.user_id AND w.amount_minor=r.amount_minor AND w.currency='MYR') LIMIT 1`).bind(userId,userId).first();
 // A previously posted credit moved to review cannot be treated as if it
 // never existed: block new spending of other credits pending reconciliation.
 const reviewedCredit=await db.prepare(`SELECT o.id FROM deposit_orders o JOIN wallet_ledger l ON l.order_id=o.id WHERE (o.user_id=? OR l.user_id=?) AND o.status='review' AND l.account_code='member' LIMIT 1`).bind(userId,userId).first();
 const providerRisk=await db.prepare(`SELECT CASE WHEN ${providerWalletRiskFreeSql} THEN 0 ELSE 1 END mismatch FROM (SELECT ? AS id) m`).bind(userId).first<{mismatch:number|string}>();
 const generic=await genericGameWalletConsistency(db,userId);
 const needsReconciliation=!!unreserved||!!invalidGameResult||!!invalidLaunch||!!invalidWithdrawal||!!reviewedCredit||generic.reconciliationRequired||Number(providerRisk?.mismatch??1)!==0;
 return {balanceMinor:(balance>0n?balance:0n).toString(),availableMinor:(!needsReconciliation&&available>0n?available:0n).toString(),heldMinor:held.toString(),withdrawalHeldMinor:withdrawalHeld.toString(),gameHeldMinor:gameHeld.toString(),...(needsReconciliation?{reconciliationRequired:true}:{})};
}

export async function getWithdrawalBanks(c?:WithdrawalContext){
 const available=providers(c);let verifiedPhoneMasked:string|null=null;
 if(c?.user?.role==='member'){const row=await c.db.prepare('SELECT phone FROM users WHERE id=? AND role=\'member\'').bind(c.user.id).first<{phone:string|null}>();verifiedPhoneMasked=maskMalaysiaPhone(row?.phone);}
 return json({currency:'MYR',enabled:available.some(x=>x.enabled),banks:malaysiaBanks.map(([id,name])=>({id,name})),ewallets:malaysiaEwallets.map(([id,name])=>({id,name})),verifiedPhoneMasked,providers:available});
}

export async function listMemberWithdrawals(c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);
 const result=await c.db.prepare('SELECT * FROM withdrawal_requests WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 100').bind(u.id).all<any>();
 return json({items:(result.results??[]).map(x=>record(x)),wallet:await withdrawalWalletState(c.db,u.id)});
}

export async function listAdminWithdrawals(c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(!['owner','staff'].includes(u.role))return json({error:'Access denied'},403);if(u.role==='staff'){const result=await c.db.prepare('SELECT w.id,w.user_id,u.username,w.provider_id,w.provider_name,w.destination_type,w.bank_name,w.account_last4,w.ewallet_code,w.ewallet_name,w.ewallet_account_last4,w.amount_minor,w.currency,w.status,w.owner_note,w.created_at,w.updated_at,p.status payout_status,p.provider_reference payout_reference FROM withdrawal_requests w JOIN users u ON u.id=w.user_id LEFT JOIN provider_payouts p ON p.withdrawal_id=w.id ORDER BY w.created_at DESC LIMIT 500').all<any>();return json({items:(result.results??[]).map(x=>({...record(x),approvalEligible:false,auditReference:`MASTER7 ${x.id}`,reviewStatus:x.status,payoutStatus:x.payout_status,payoutReference:x.payout_reference})),readOnly:true});}if(!withdrawalDataKeyReady(c.dataKey))return json({error:'Withdrawal security not configured'},503);
 try{const result=await c.db.prepare(approvalQuery+' ORDER BY w.created_at DESC,w.id DESC LIMIT 500').all<any>();return json({items:(result.results??[]).map(x=>{const eligible=Number(x.approval_eligible)===1;if(!eligible)return {...ownerBaseRecord(x),approvalEligible:false};try{return {...ownerRecord(x,c.dataKey),approvalEligible:true,approvalFingerprint:approvalFingerprint(x)};}catch{return {...ownerBaseRecord(x),approvalEligible:false,recipientUnavailable:true};}}),providers:providers(c)});}catch{return json({error:'Withdrawal records unavailable'},503);}
}

export async function submitWithdrawal(d:Record<string,unknown>,c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);if(!withdrawalDataKeyReady(c.dataKey))return json({error:'Withdrawal security not configured'},503);
 const method=d.destinationType==='ewallet'?'ewallet':d.destinationType===undefined||d.destinationType==='bank'?'bank':null,selectedProvider=provider(d.providerId,c);if(selectedProvider&&!selectedProvider.enabled)return json({error:`${selectedProvider.name} payout is not connected`},503);
 const selectedBank=method==='bank'?malaysiaBank(d.bankCode):null,selectedEwallet=method==='ewallet'?malaysiaEwallet(d.ewalletCode):null,name=cleanName(d.accountHolder),bankAccount=method==='bank'?cleanAccount(d.accountNumber):null,amount=amountMinor(d.amount),requestKey=typeof d.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(d.requestKey)?d.requestKey:'';
 let ewalletAccount:string|null=null;
 if(method==='ewallet'){
  if(selectedProvider?.id!=='manual_bank')return json({error:'E-Wallet withdrawals require Company Bank manual review'},400);
  const stored=await c.db.prepare('SELECT phone FROM users WHERE id=? AND role=\'member\'').bind(u.id).first<{phone:string|null}>(),memberPhone=malaysiaMemberPhone(stored?.phone),submittedPhone=malaysiaMemberPhone(d.ewalletAccountIdentifier);
  if(!memberPhone||!submittedPhone||memberPhone!==submittedPhone)return json({error:'Use the verified phone number on your member account'},400);ewalletAccount=memberPhone;
 }
 if(!method||!selectedProvider||!name||!amount||!requestKey||(method==='bank'&&(!selectedBank||!bankAccount))||(method==='ewallet'&&(!selectedEwallet||!ewalletAccount)))return json({error:'Invalid withdrawal details'},400);
 const adapter=c.payouts?.[selectedProvider.id];if(!adapter||!adapter.enabled)return json({error:`${selectedProvider.name} payout is not connected`},503);if(method==='bank'&&selectedBank&&adapter.supportsBank&&!adapter.supportsBank(selectedBank[0]))return json({error:`${selectedBank[1]} is not supported by ${selectedProvider.name}`},400);
 const destinationAccount=method==='ewallet'?ewalletAccount!:bankAccount!,destinationCode=method==='ewallet'?selectedEwallet![0]:selectedBank![0],fingerprintPayload=method==='bank'?{provider:selectedProvider.id,userId:u.id,amount,bank:destinationCode,account:createHash('sha256').update(destinationAccount).digest('hex')}:{provider:selectedProvider.id,userId:u.id,amount,destinationType:method,destinationCode,account:createHash('sha256').update(destinationAccount).digest('hex')},fingerprint=createHash('sha256').update(JSON.stringify(fingerprintPayload)).digest('hex'),replay=await c.db.prepare('SELECT w.*,p.fingerprint FROM withdrawal_requests w LEFT JOIN provider_payouts p ON p.withdrawal_id=w.id WHERE w.user_id=? AND w.request_key=?').bind(u.id,requestKey).first<any>();
 if(replay){
  if(replay.fingerprint!==fingerprint)return json({error:'IDEMPOTENCY_CONFLICT'},409);
  const status=replay.status==='paid'?(await verifiedPaidWithdrawal(c.db,u.id,replay.id)?'paid':'review'):replay.status==='rejected'||replay.status==='cancelled'?(await verifiedUnsubmittedCancellation(c.db,u.id,replay.id)?'failed':'review'):replay.status==='pending'?'pending':replay.status==='processing'?'processing':'review';
  return json({status,withdrawal:{...record(replay),...(['paid','rejected','cancelled'].includes(replay.status)&&status==='review'?{status:'review'}:{})}},200);
 }
 await clearStaleReservation(c.db,u.id);
 const gameOpen=await c.db.prepare("SELECT id FROM game_wallet_sessions WHERE user_id=? AND status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review') LIMIT 1").bind(u.id).first();if(gameOpen||await hasProtectedGameReservation(c.db,u.id))return json({error:'Settle the game wallet before withdrawing'},409);
 const open=await c.db.prepare("SELECT id FROM withdrawal_requests WHERE user_id=? AND status IN ('pending','approved','processing') LIMIT 1").bind(u.id).first();if(open)return json({error:'You already have a withdrawal being processed'},409);
 const wallet=await withdrawalWalletState(c.db,u.id);if(BigInt(wallet.availableMinor)<BigInt(amount))return json({error:'Insufficient available balance'},409);
 const id=crypto.randomUUID(),payoutId=`P7${crypto.randomUUID().replaceAll('-','').slice(0,30)}`,timestamp=Math.floor(Date.now()/1000);
 try{const created=await c.db.batch([
  ...walletGuardStatements(c.db,u.id),
  walletGuardedReservation(c.db,{userId:u.id,kind:'withdrawal',referenceId:id,amountMinor:amount,createdAt:timestamp}),
  c.db.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,destination_type,ewallet_code,ewallet_name,ewallet_account_encrypted,ewallet_account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'MYR','pending','',?,? WHERE EXISTS (SELECT 1 FROM wallet_reservations WHERE user_id=? AND kind='withdrawal' AND reference_id=? AND amount_minor=CAST(? AS BIGINT))").bind(id,u.id,requestKey,selectedProvider.id,selectedProvider.name,selectedBank?.[0]??'',selectedBank?.[1]??'',encryptWithdrawalValue(name,c.dataKey),method==='bank'?encryptWithdrawalValue(bankAccount!,c.dataKey):encryptWithdrawalValue('not-applicable',c.dataKey),method==='bank'?bankAccount!.slice(-4):'----',method,selectedEwallet?.[0]??null,selectedEwallet?.[1]??null,method==='ewallet'?encryptWithdrawalValue(ewalletAccount!,c.dataKey):null,method==='ewallet'?ewalletAccount!.slice(-4):null,amount,timestamp,timestamp,u.id,id,amount),
  c.db.prepare("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,created_at,updated_at) SELECT ?,?,?,?,?,?,'MYR','prepared','not_submitted',?,? WHERE EXISTS (SELECT 1 FROM withdrawal_requests w JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor AND r.kind='withdrawal' WHERE w.id=? AND w.user_id=? AND w.amount_minor=CAST(? AS BIGINT) AND w.status='pending')").bind(payoutId,id,selectedProvider.id,requestKey,fingerprint,amount,timestamp,timestamp,id,u.id,amount),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'withdrawal_requested',?,? WHERE EXISTS (SELECT 1 FROM withdrawal_requests w JOIN provider_payouts p ON p.withdrawal_id=w.id JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor AND r.kind='withdrawal' WHERE w.id=? AND w.user_id=? AND p.id=?)").bind(crypto.randomUUID(),u.id,id,timestamp,id,u.id,payoutId),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'withdrawal_requested_v1',?,? WHERE EXISTS (SELECT 1 FROM withdrawal_requests w JOIN provider_payouts p ON p.withdrawal_id=w.id JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor AND r.kind='withdrawal' WHERE w.id=? AND w.user_id=? AND p.id=?)").bind(`withdrawal_request_v1_${id}`,u.id,id,timestamp,id,u.id,payoutId),
 ]);
  // The locked eligibility check can reject after the earlier UI balance read.
  // Never contact the provider unless all three new records were committed.
  const changed=(result:any)=>Number(result?.meta?.changes??result?.changes??0);
  if(created.length!==7||created.slice(1).some(result=>changed(result)!==1))return json({error:'Wallet needs reconciliation or available balance has changed',code:'WALLET_RECONCILIATION_REQUIRED'},409);
  const committed=await c.db.prepare("SELECT w.id FROM withdrawal_requests w JOIN provider_payouts p ON p.withdrawal_id=w.id JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor AND r.kind='withdrawal' WHERE w.id=? AND w.user_id=? AND w.amount_minor=CAST(? AS BIGINT) AND w.status='pending' AND p.id=? AND p.provider_id=w.provider_id AND p.request_key=w.request_key AND p.fingerprint=? AND p.amount_minor=w.amount_minor AND p.currency=w.currency AND p.status='prepared'").bind(id,u.id,amount,payoutId,fingerprint).first();
  if(!committed)return json({error:'Withdrawal needs reconciliation',code:'WALLET_RECONCILIATION_REQUIRED'},409);
  // New requests are reserved for review. Never contact a provider here.
  return json({status:'pending',withdrawal:{id,providerName:selectedProvider.name,destinationType:method,destinationMethod:method==='ewallet'?'E-Wallet':'Bank Account',bankName:selectedBank?.[1],ewalletName:selectedEwallet?.[1],destinationNumber:`•••• ${destinationAccount.slice(-4)}`,accountNumber:`•••• ${destinationAccount.slice(-4)}`,amountMinor:amount,currency:'MYR',status:'pending',createdAt:timestamp}},201);
 }catch(error:any){if(String(error?.message??'').includes('UNIQUE'))return json({error:'You already have a withdrawal being processed'},409);throw error;}
}

/** Claim a reviewed, immutable withdrawal once; existing/legacy requests without
 * the request marker cannot be approved. External payout happens after commit. */
export async function approveWithdrawal(d:Record<string,unknown>,c:WithdrawalContext){
 const owner=c.user;if(!owner)return json({error:'Sign in required'},401);if(owner.role!=='owner')return json({error:'Access denied'},403);if(!withdrawalDataKeyReady(c.dataKey))return json({error:'Withdrawal security not configured'},503);
 const id=typeof d.id==='string'&&/^[A-Za-z0-9-]{8,80}$/.test(d.id)?d.id:'',fp=typeof d.approvalFingerprint==='string'&&/^[a-f0-9]{64}$/.test(d.approvalFingerprint)?d.approvalFingerprint:'',note=typeof d.ownerNote==='string'&&d.ownerNote.trim().length<=200&&!/[\u0000-\u001f\u007f-\u009f]/u.test(d.ownerNote)?d.ownerNote.trim():null;
 if(!id||!fp||note===null)return json({error:'Review the withdrawal and provide its approval fingerprint'},400);
 const x=await c.db.prepare(approvalQuery+' WHERE w.id=?').bind(id).first<any>();if(!x)return json({error:'Withdrawal not found'},404);
 if(Number(x.approval_eligible)!==1||approvalFingerprint(x)!==fp)return json({error:'Withdrawal changed or requires manual reconciliation; refresh and review'},409);
 const method=destinationType(x),adapter=c.payouts?.[x.provider_id as 'vpay'|'gspay'|'1mpay'|'manual_bank'];if(!adapter?.enabled||adapter.allowsMember&&!await adapter.allowsMember(x.user_id))return json({error:'Payout provider unavailable'},503);if(method==='ewallet'&&x.provider_id!=='manual_bank')return json({error:'E-Wallet payout requires manual Company Bank review'},409);if(method==='bank'&&adapter.supportsBank&&!adapter.supportsBank(x.bank_code))return json({error:'Bank is not supported'},400);
 let holder:string,account:string;try{holder=decryptWithdrawalValue(x.account_holder_encrypted,c.dataKey);account=decryptWithdrawalValue(method==='ewallet'?x.ewallet_account_encrypted:x.account_number_encrypted,c.dataKey);}catch{return json({error:'Withdrawal security data invalid'},409);}
 const destination=method==='ewallet'?malaysiaEwallet(x.ewallet_code):malaysiaBank(x.bank_code);
 if(!cleanName(holder)||!(method==='ewallet'?malaysiaMemberPhone(account):cleanAccount(account))||!destination)return json({error:'Withdrawal recipient invalid'},409);
 const fingerprintPayload=method==='bank'?{provider:x.provider_id,userId:x.user_id,amount:String(x.amount_minor),bank:destination[0],account:createHash('sha256').update(account).digest('hex')}:{provider:x.provider_id,userId:x.user_id,amount:String(x.amount_minor),destinationType:method,destinationCode:destination[0],account:createHash('sha256').update(account).digest('hex')},expectedPayoutFingerprint=createHash('sha256').update(JSON.stringify(fingerprintPayload)).digest('hex');
 if(expectedPayoutFingerprint!==x.payout_fingerprint)return json({error:'Withdrawal needs reconciliation'},409);
 const at=Math.floor(Date.now()/1000),authId=crypto.randomUUID(),approvalId=`withdrawal_approved_v1_${id}`,bindingId=`withdrawal_approval_binding_v1_${id}_${fp}`;
 // The review row UPDATE serializes against compliance changes. Guarded risk
 // and balance are evaluated under the same member wallet lock as the claim.
 const results=await c.db.batch([
  ...walletGuardStatements(c.db,x.user_id),
  c.db.prepare("UPDATE users SET approved=approved WHERE id=? AND role='owner' AND approved=1").bind(owner.id),
  c.db.prepare("UPDATE manual_compliance_reviews SET last_authorization_id=? WHERE user_id=? AND identity_status='passed' AND aml_status='passed' AND version=?").bind(authId,x.user_id,x.compliance_version),
  c.db.prepare(`UPDATE withdrawal_requests SET status='approved',owner_note=?,updated_by=?,updated_at=? WHERE id=? AND user_id=? AND status='pending' AND provider_id=? AND request_key=? AND amount_minor=CAST(? AS BIGINT) AND currency=? AND destination_type=? AND bank_code=? AND COALESCE(ewallet_code,'')=COALESCE(?,'') AND account_holder_encrypted=? AND account_number_encrypted=? AND COALESCE(ewallet_account_encrypted,'')=COALESCE(?,'')
   AND EXISTS (SELECT 1 FROM users reviewer WHERE reviewer.id=? AND reviewer.role='owner' AND reviewer.approved=1)
   AND EXISTS (SELECT 1 FROM users m WHERE m.id=withdrawal_requests.user_id AND m.role='member' AND m.approved=1 AND ${walletRiskFreeSql} AND ${walletAvailableSql}>=0)
   AND EXISTS (SELECT 1 FROM manual_compliance_reviews c WHERE c.user_id=withdrawal_requests.user_id AND c.identity_status='passed' AND c.aml_status='passed' AND c.last_authorization_id=? AND c.version=?)
   AND EXISTS (SELECT 1 FROM audit a WHERE a.id=? AND a.event='withdrawal_requested_v1' AND a.target=withdrawal_requests.id AND a.user_id=withdrawal_requests.user_id)
   AND NOT EXISTS (SELECT 1 FROM audit a WHERE a.id=?)
   AND EXISTS (SELECT 1 FROM provider_payouts p JOIN wallet_reservations r ON r.kind='withdrawal' AND r.reference_id=withdrawal_requests.id AND r.user_id=withdrawal_requests.user_id AND r.amount_minor=withdrawal_requests.amount_minor WHERE p.id=? AND p.withdrawal_id=withdrawal_requests.id AND p.provider_id=withdrawal_requests.provider_id AND p.request_key=withdrawal_requests.request_key AND p.amount_minor=withdrawal_requests.amount_minor AND p.currency=withdrawal_requests.currency AND p.fingerprint=? AND p.status='prepared' AND p.create_outcome='not_submitted' AND p.provider_reference IS NULL)`)
   .bind(note,owner.id,at,id,x.user_id,x.provider_id,x.request_key,String(x.amount_minor),x.currency,method,x.bank_code,x.ewallet_code,x.account_holder_encrypted,x.account_number_encrypted,x.ewallet_account_encrypted,owner.id,authId,x.compliance_version,`withdrawal_request_v1_${id}`,approvalId,x.payout_id,x.payout_fingerprint),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'withdrawal_approval_binding_v1',?,? WHERE NOT EXISTS (SELECT 1 FROM audit a WHERE a.id=?) AND EXISTS (SELECT 1 FROM withdrawal_requests w JOIN manual_compliance_reviews c ON c.user_id=w.user_id WHERE w.id=? AND w.status='approved' AND w.updated_by=? AND w.updated_at=? AND w.owner_note=? AND w.account_holder_encrypted=? AND w.account_number_encrypted=? AND c.last_authorization_id=? AND c.version=?) ON CONFLICT(id) DO NOTHING").bind(bindingId,owner.id,id,at,approvalId,id,owner.id,at,note,x.account_holder_encrypted,x.account_number_encrypted,authId,x.compliance_version),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'withdrawal_approved_v1',?,? WHERE EXISTS (SELECT 1 FROM withdrawal_requests w JOIN audit a ON a.id=? AND a.user_id=w.updated_by AND a.event='withdrawal_approval_binding_v1' AND a.target=w.id WHERE w.id=? AND w.status='approved' AND w.updated_by=? AND w.updated_at=? AND w.owner_note=?) ON CONFLICT(id) DO NOTHING").bind(approvalId,owner.id,id,at,bindingId,id,owner.id,at,note),
 ]);
 const changed=(v:any)=>Number(v?.meta?.changes??v?.changes??0);
 if(changed(results[2])!==1||changed(results[3])!==1||changed(results[4])!==1||changed(results[5])!==1||changed(results[6])!==1)return json({error:'Withdrawal changed, failed compliance, or needs reconciliation; refresh and review'},409);
 if(x.provider_id==='manual_bank')return json({status:'approved',withdrawal:{id,status:'approved'},manualTransferRequired:true},202);
 let payout:PayoutSubmission={status:'review'};
 try{payout=await adapter.submit({payoutId:x.payout_id,withdrawalId:id,userId:x.user_id,accountHolder:holder,accountNumber:account,bankCode:x.bank_code,amountMinor:String(x.amount_minor)});}catch{
  const failedAt=Math.floor(Date.now()/1000);await c.db.batch([...walletGuardStatements(c.db,x.user_id),c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code='submission_internal_error',updated_at=? WHERE id=? AND status IN ('prepared','submitting','processing')").bind(failedAt,x.payout_id),c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status='approved' AND EXISTS (SELECT 1 FROM provider_payouts WHERE id=? AND withdrawal_id=withdrawal_requests.id AND status='review')").bind(failedAt,id,x.payout_id)]);
 }
 const current=await c.db.prepare('SELECT status FROM withdrawal_requests WHERE id=?').bind(id).first<{status:string}>();
 const status=current?.status==='paid'?(await verifiedPaidWithdrawal(c.db,x.user_id,id)?'paid':'review'):current?.status==='rejected'||current?.status==='cancelled'?(await verifiedUnsubmittedCancellation(c.db,x.user_id,id)?'failed':'review'):payout.status==='review'||payout.status==='failed'||payout.status==='succeeded'?'review':current?.status==='approved'?'approved':'processing';
 const withdrawalStatus=current&&['paid','rejected','cancelled'].includes(current.status)&&status==='review'?'review':current?.status??'approved';
 return json({status,withdrawal:{id,status:withdrawalStatus}},202);
}

export async function cancelWithdrawal(d:Record<string,unknown>,c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='owner')return json({error:'Access denied'},403);
 const id=typeof d.id==='string'&&/^[A-Za-z0-9-]{8,80}$/.test(d.id)?d.id:'',next=typeof d.status==='string'?d.status:'',note=typeof d.ownerNote==='string'&&d.ownerNote.trim().length<=200&&!/[\u0000-\u001f\u007f-\u009f]/u.test(d.ownerNote)?d.ownerNote.trim():null;
 if(!id||note===null||!['rejected','cancelled'].includes(next))return json({error:'Only cancellation of an unsubmitted withdrawal is allowed'},400);
 const member=await c.db.prepare('SELECT user_id FROM withdrawal_requests WHERE id=?').bind(id).first<{user_id:string}>();
 if(!member)return json({error:'Withdrawal not found'},404);
 const timestamp=Math.floor(Date.now()/1000),marker=`owner_cancel_${crypto.randomUUID()}`;
 // Serialize against the adapter's prepared -> submitting CAS on the same
 // payout row. Only an untouched payout can be closed by an owner; otherwise
 // it may already be in flight and the member's reservation must remain held.
 // A missing payout might be a legacy external transfer; it is not proof that
 // the transfer was never submitted and therefore requires manual review.
 const results=await c.db.batch([
  ...walletGuardStatements(c.db,member.user_id),
  c.db.prepare("UPDATE users SET approved=approved WHERE id=? AND role='owner' AND approved=1").bind(u.id),
  c.db.prepare("UPDATE provider_payouts SET status='failed',last_error_code=?,updated_at=? WHERE withdrawal_id=? AND status='prepared' AND create_outcome='not_submitted' AND provider_reference IS NULL AND EXISTS (SELECT 1 FROM users owner WHERE owner.id=? AND owner.role='owner' AND owner.approved=1) AND EXISTS (SELECT 1 FROM withdrawal_requests w JOIN wallet_reservations r ON r.kind='withdrawal' AND r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=? AND w.status IN ('pending','approved') AND EXISTS (SELECT 1 FROM audit a WHERE a.id='withdrawal_request_v1_'||w.id AND a.event='withdrawal_requested_v1' AND a.target=w.id AND a.user_id=w.user_id) AND w.provider_id=provider_payouts.provider_id AND w.request_key=provider_payouts.request_key AND w.amount_minor=provider_payouts.amount_minor AND w.currency='MYR' AND w.currency=provider_payouts.currency)").bind(marker,timestamp,id,u.id,member.user_id),
  c.db.prepare("UPDATE withdrawal_requests SET status=?,owner_note=?,updated_by=?,updated_at=? WHERE id=? AND status IN ('pending','approved') AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.withdrawal_id=withdrawal_requests.id AND p.status='failed' AND p.create_outcome='not_submitted' AND p.last_error_code=?)").bind(next,note,u.id,timestamp,id,marker),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=? AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=wallet_reservations.reference_id AND w.user_id=wallet_reservations.user_id AND w.amount_minor=wallet_reservations.amount_minor AND w.currency='MYR' AND w.status=? AND w.updated_by=? AND w.updated_at=? AND w.owner_note=? AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.withdrawal_id=w.id AND p.status='failed' AND p.create_outcome='not_submitted' AND p.last_error_code=?))").bind(id,next,u.id,timestamp,note,marker),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=? AND w.status=? AND w.updated_by=? AND w.updated_at=? AND w.owner_note=? AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.withdrawal_id=w.id AND p.status='failed' AND p.create_outcome='not_submitted' AND p.last_error_code=?)) ON CONFLICT(id) DO NOTHING").bind(`withdrawal_owner_cancel_${id}`,u.id,'withdrawal_'+next,id,timestamp,id,next,u.id,timestamp,note,marker),
 ]);
 const outcome=results[4] as {meta?:{changes?:number};changes?:number}|undefined;
 const changed=Number(outcome?.meta?.changes??outcome?.changes??0);
 if(!changed){const current=await c.db.prepare('SELECT status FROM withdrawal_requests WHERE id=?').bind(id).first<{status:string}>();return current?json({error:['pending','approved'].includes(current.status)?'Withdrawal requires manual reconciliation before cancellation':'Withdrawal is no longer cancellable'},409):json({error:'Withdrawal not found'},404);}
 return json({status:'ok',withdrawalStatus:next});
}

export async function hasProtectedGameReservation(db:D1Database,userId:string){
 if((await genericGameWalletConsistency(db,userId)).reconciliationRequired)return true;
 const result=await db.prepare(`SELECT r.reference_id FROM wallet_reservations r WHERE r.user_id=? AND r.kind='game' AND (
  EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.id=r.reference_id AND s.user_id=r.user_id)
  OR NOT EXISTS (SELECT 1 FROM game_wallet_sessions g WHERE g.id=r.reference_id AND g.user_id=r.user_id AND g.status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')))
  UNION ALL SELECT s.id FROM game_provider_sessions s WHERE s.user_id=? AND s.wallet_mode='transfer' AND s.status IN ('prepared','launching','active','settling','unknown','review') LIMIT 1`).bind(userId,userId).first();
 return !!result;
}

export async function clearStaleReservation(db:D1Database,userId:string){
 await db.batch([...walletGuardStatements(db,userId),db.prepare(`DELETE FROM wallet_reservations WHERE user_id=?
 AND EXISTS (SELECT 1 FROM (SELECT ? AS id) m WHERE ${genericGameWalletRiskFreeSql}) AND (
  (kind='withdrawal' AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=wallet_reservations.reference_id AND w.user_id=wallet_reservations.user_id AND w.amount_minor=wallet_reservations.amount_minor AND w.currency='MYR' AND (
    (w.status IN ('rejected','cancelled') AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.withdrawal_id=w.id AND p.provider_id=w.provider_id AND p.request_key=w.request_key AND p.amount_minor=w.amount_minor AND p.currency=w.currency AND p.status='failed' AND p.create_outcome='not_submitted' AND p.provider_reference IS NULL AND SUBSTR(COALESCE(p.last_error_code,''),1,13)='owner_cancel_'))
    OR (w.status='paid' AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.withdrawal_id=w.id AND p.provider_id=w.provider_id AND p.request_key=w.request_key AND p.amount_minor=w.amount_minor AND p.currency=w.currency AND p.status='succeeded' AND p.create_outcome='accepted' AND COALESCE(p.last_error_code,'')='' AND ${payoutReferenceValidSql})))))
  OR (kind='game'
   AND EXISTS (SELECT 1 FROM game_wallet_sessions g WHERE g.id=wallet_reservations.reference_id AND g.user_id=wallet_reservations.user_id AND ${providerTerminalHoldEvidenceSql} AND (
    (g.status='deposit_failed' AND NOT EXISTS (SELECT 1 FROM game_wallet_ledger l WHERE l.session_id=g.id)) OR (g.status='settled' AND g.amount_returned_minor IS NOT NULL AND g.amount_out_minor=wallet_reservations.amount_minor AND EXISTS (SELECT 1 FROM game_wallet_ledger l WHERE l.session_id=g.id AND l.user_id=g.user_id AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=g.amount_returned_minor-g.amount_out_minor))))
   AND NOT EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.id=wallet_reservations.reference_id AND s.user_id=wallet_reservations.user_id)
   AND NOT EXISTS (SELECT 1 FROM megah5_launch_operations o WHERE o.wallet_session_id=wallet_reservations.reference_id AND (o.state<>'closed' OR NOT ${megaClosureProofSql('o')})))
 )`).bind(userId,userId)]);
}
