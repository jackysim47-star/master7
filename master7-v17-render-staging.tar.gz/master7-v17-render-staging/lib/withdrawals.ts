import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';

type Member={id:string;username:string;role:string;approved:number};
type WithdrawalContext={db:D1Database;user:Member|null;dataKey?:string};

export const withdrawalProviders=[
 {id:'vpay',name:'VPay'},
 {id:'1mpay',name:'1MPAY'},
] as const;

export const malaysiaBanks=[
 ['maybank','Maybank'],['cimb','CIMB Bank'],['public_bank','Public Bank'],['rhb','RHB Bank'],
 ['hong_leong','Hong Leong Bank'],['ambank','AmBank'],['bank_islam','Bank Islam'],['bank_rakyat','Bank Rakyat'],
 ['bsn','Bank Simpanan Nasional (BSN)'],['alliance','Alliance Bank'],['affin','Affin Bank'],
 ['ocbc','OCBC Bank Malaysia'],['uob','UOB Malaysia'],['hsbc','HSBC Malaysia'],
 ['standard_chartered','Standard Chartered Malaysia'],['agrobank','Agrobank'],
 ['bank_muamalat','Bank Muamalat'],['mbsb','MBSB Bank'],
] as const;

const responseHeaders={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:responseHeaders});
const keyBytes=(secret?:string)=>typeof secret==='string'&&Buffer.byteLength(secret)>=32&&Buffer.byteLength(secret)<=1024?createHash('sha256').update(secret).digest():null;
const encrypt=(value:string,secret?:string)=>{const key=keyBytes(secret);if(!key)throw Error('WITHDRAWAL_SECURITY_NOT_CONFIGURED');const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv),data=Buffer.concat([cipher.update(value,'utf8'),cipher.final()]),tag=cipher.getAuthTag();return [iv,tag,data].map(x=>x.toString('base64url')).join('.');};
const decrypt=(value:string,secret?:string)=>{const key=keyBytes(secret);if(!key)throw Error('WITHDRAWAL_SECURITY_NOT_CONFIGURED');const [a,b,d]=value.split('.');if(!a||!b||!d)throw Error('WITHDRAWAL_DATA_INVALID');const decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(a,'base64url'));decipher.setAuthTag(Buffer.from(b,'base64url'));return Buffer.concat([decipher.update(Buffer.from(d,'base64url')),decipher.final()]).toString('utf8');};
const amountMinor=(value:unknown)=>{if(typeof value!=='string'||!/^(0|[1-9]\d{0,5})(?:\.(\d{1,2}))?$/.test(value))return null;const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));return minor>0n&&minor<=10000000n?minor.toString():null;};
const provider=(value:unknown)=>withdrawalProviders.find(x=>x.id===value);
const bank=(value:unknown)=>malaysiaBanks.find(x=>x[0]===value);
const cleanName=(value:unknown)=>typeof value==='string'&&value.trim().length>=2&&value.trim().length<=80&&!/[\u0000-\u001f\u007f-\u009f]/u.test(value)?value.trim():null;
const cleanAccount=(value:unknown)=>{const account=typeof value==='string'?value.replace(/[\s-]/g,''):'';return /^\d{6,20}$/.test(account)?account:null;};
const record=(x:any,secret?:string,full=false)=>({id:x.id,userId:x.user_id,username:x.username??undefined,providerId:x.provider_id,providerName:x.provider_name,bankCode:x.bank_code,bankName:x.bank_name,accountHolder:full?decrypt(x.account_holder_encrypted,secret):undefined,accountNumber:full?decrypt(x.account_number_encrypted,secret):`•••• ${x.account_last4}`,accountLast4:x.account_last4,amountMinor:String(x.amount_minor),currency:x.currency,status:x.status,ownerNote:x.owner_note,createdAt:Number(x.created_at),updatedAt:Number(x.updated_at)});

export async function withdrawalWalletState(db:D1Database,userId:string){
 const values=await db.prepare(`SELECT
  CAST(COALESCE((SELECT SUM(amount_minor) FROM wallet_ledger WHERE user_id=? AND account_code='member' AND currency='MYR'),0) AS TEXT) credits,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM game_wallet_ledger WHERE user_id=? AND account_code='game_result' AND currency='MYR'),0) AS TEXT) game_results,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=? AND status='paid' AND currency='MYR'),0) AS TEXT) paid,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=? AND status IN ('pending','approved','processing') AND currency='MYR'),0) AS TEXT) withdrawal_held,
  CAST(COALESCE((SELECT SUM(amount_out_minor) FROM game_wallet_sessions WHERE user_id=? AND status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')),0) AS TEXT) game_held`).bind(userId,userId,userId,userId,userId).first<any>();
 const credits=BigInt(values?.credits??0),gameResults=BigInt(values?.game_results??0),paid=BigInt(values?.paid??0),withdrawalHeld=BigInt(values?.withdrawal_held??0),gameHeld=BigInt(values?.game_held??0),balance=credits+gameResults-paid,held=withdrawalHeld+gameHeld,available=balance-held;
 return {balanceMinor:(balance>0n?balance:0n).toString(),availableMinor:(available>0n?available:0n).toString(),heldMinor:held.toString(),withdrawalHeldMinor:withdrawalHeld.toString(),gameHeldMinor:gameHeld.toString()};
}

export async function getWithdrawalBanks(){return json({currency:'MYR',banks:malaysiaBanks.map(([id,name])=>({id,name})),providers:withdrawalProviders});}

export async function listMemberWithdrawals(c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);
 const result=await c.db.prepare('SELECT * FROM withdrawal_requests WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 100').bind(u.id).all<any>();
 return json({items:(result.results??[]).map(x=>record(x)),wallet:await withdrawalWalletState(c.db,u.id)});
}

export async function listAdminWithdrawals(c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='owner')return json({error:'Access denied'},403);if(!keyBytes(c.dataKey))return json({error:'Withdrawal security not configured'},503);
 try{const result=await c.db.prepare('SELECT w.*,u.username FROM withdrawal_requests w JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC,w.id DESC LIMIT 500').all<any>();return json({items:(result.results??[]).map(x=>record(x,c.dataKey,true)),providers:withdrawalProviders});}catch{return json({error:'Withdrawal records unavailable'},503);}
}

export async function submitWithdrawal(d:Record<string,unknown>,c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);if(d.providerId==='gspay'||d.providerId==='gspay_plus')return json({error:'GSPAY withdrawal is not available; this integration is Deposit only'},400);if(!keyBytes(c.dataKey))return json({error:'Withdrawal security not configured'},503);
 const selectedProvider=provider(d.providerId),selectedBank=bank(d.bankCode),name=cleanName(d.accountHolder),account=cleanAccount(d.accountNumber),amount=amountMinor(d.amount),requestKey=typeof d.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(d.requestKey)?d.requestKey:'';
 if(!selectedProvider||!selectedBank||!name||!account||!amount||!requestKey)return json({error:'Invalid withdrawal details'},400);
 const gameOpen=await c.db.prepare("SELECT id FROM game_wallet_sessions WHERE user_id=? AND status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review') LIMIT 1").bind(u.id).first();if(gameOpen)return json({error:'Settle the game wallet before withdrawing'},409);
 const open=await c.db.prepare("SELECT id FROM withdrawal_requests WHERE user_id=? AND status IN ('pending','approved','processing') LIMIT 1").bind(u.id).first();if(open)return json({error:'You already have a withdrawal being processed'},409);
 const wallet=await withdrawalWalletState(c.db,u.id);if(BigInt(wallet.availableMinor)<BigInt(amount))return json({error:'Insufficient available balance'},409);
 const id=crypto.randomUUID(),timestamp=Math.floor(Date.now()/1000);
 try{await c.db.batch([
  c.db.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'MYR','pending','',?,?)").bind(id,u.id,requestKey,selectedProvider.id,selectedProvider.name,selectedBank[0],selectedBank[1],encrypt(name,c.dataKey),encrypt(account,c.dataKey),account.slice(-4),amount,timestamp,timestamp),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),u.id,'withdrawal_requested',id,timestamp),
 ]);return json({status:'ok',withdrawal:{id,providerName:selectedProvider.name,bankName:selectedBank[1],accountNumber:`•••• ${account.slice(-4)}`,amountMinor:amount,currency:'MYR',status:'pending',createdAt:timestamp}},201);}catch(error:any){if(String(error?.message??'').includes('UNIQUE'))return json({error:'You already have a withdrawal being processed'},409);throw error;}
}

export async function updateWithdrawal(d:Record<string,unknown>,c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='owner')return json({error:'Access denied'},403);
 const id=typeof d.id==='string'&&/^[A-Za-z0-9-]{8,80}$/.test(d.id)?d.id:'',next=typeof d.status==='string'?d.status:'',note=typeof d.ownerNote==='string'&&d.ownerNote.trim().length<=200&&!/[\u0000-\u001f\u007f-\u009f]/u.test(d.ownerNote)?d.ownerNote.trim():null;
 if(!id||note===null||!['approved','processing','paid','rejected'].includes(next))return json({error:'Invalid withdrawal update'},400);
 const current=await c.db.prepare('SELECT status FROM withdrawal_requests WHERE id=?').bind(id).first<{status:string}>();if(!current)return json({error:'Withdrawal not found'},404);
 const allowed:Record<string,string[]>={pending:['approved','rejected'],approved:['processing','rejected'],processing:['paid','rejected']};if(!allowed[current.status]?.includes(next))return json({error:'Invalid withdrawal status transition'},409);
 const timestamp=Math.floor(Date.now()/1000);await c.db.batch([c.db.prepare('UPDATE withdrawal_requests SET status=?,owner_note=?,updated_by=?,updated_at=? WHERE id=? AND status=?').bind(next,note,u.id,timestamp,id,current.status),c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),u.id,'withdrawal_'+next,id,timestamp)]);return json({status:'ok',withdrawalStatus:next});
}
