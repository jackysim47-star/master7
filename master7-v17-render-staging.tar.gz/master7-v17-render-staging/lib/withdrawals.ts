import {createHash} from 'node:crypto';
import {malaysiaBank,malaysiaBanks} from './malaysia-banks.ts';
import {decryptWithdrawalValue,encryptWithdrawalValue,withdrawalDataKeyReady} from './withdrawal-secrets.ts';

type Member={id:string;username:string;role:string;approved:number};
type PayoutSubmission={status:'processing'|'succeeded'|'failed'|'review';providerReference?:string|null};
type PayoutAdapter={enabled:boolean;reason:string;supportsBank?:(bankCode:string)=>boolean;submit:(input:{payoutId:string;withdrawalId:string;userId:string;accountHolder:string;accountNumber:string;bankCode:string;amountMinor:string})=>Promise<PayoutSubmission>};
type WithdrawalContext={db:D1Database;user:Member|null;dataKey?:string;payouts?:Partial<Record<'vpay'|'gspay'|'1mpay',PayoutAdapter>>};
type WithdrawalProvider={id:'vpay'|'gspay'|'1mpay';name:string;enabled:boolean;reason:string};

const responseHeaders={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:responseHeaders});
const amountMinor=(value:unknown)=>{if(typeof value!=='string'||!/^(0|[1-9]\d{0,5})(?:\.(\d{1,2}))?$/.test(value))return null;const [whole,fraction='']=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));return minor>0n&&minor<=10000000n?minor.toString():null;};
const providers=(c?:WithdrawalContext):readonly WithdrawalProvider[]=>[
 {id:'vpay',name:'VPay',enabled:c?.payouts?.vpay?.enabled===true,reason:c?.payouts?.vpay?.reason??'Payout adapter is not configured'},
 {id:'gspay',name:'GSPAY+',enabled:c?.payouts?.gspay?.enabled===true,reason:c?.payouts?.gspay?.reason??'Payout adapter is not configured'},
 {id:'1mpay',name:'1MPAY',enabled:c?.payouts?.['1mpay']?.enabled===true,reason:c?.payouts?.['1mpay']?.reason??'Payout adapter is not configured'},
];
const provider=(value:unknown,c:WithdrawalContext)=>providers(c).find(x=>x.id===value);
const cleanName=(value:unknown)=>typeof value==='string'&&value.trim().length>=2&&value.trim().length<=80&&!/[\u0000-\u001f\u007f-\u009f]/u.test(value)?value.trim():null;
const cleanAccount=(value:unknown)=>{const account=typeof value==='string'?value.replace(/[\s-]/g,''):'';return /^\d{6,20}$/.test(account)?account:null;};
const record=(x:any,secret?:string,full=false)=>({id:x.id,userId:x.user_id,username:x.username??undefined,providerId:x.provider_id,providerName:x.provider_name,bankCode:x.bank_code,bankName:x.bank_name,accountHolder:full?decryptWithdrawalValue(x.account_holder_encrypted,secret):undefined,accountNumber:full?decryptWithdrawalValue(x.account_number_encrypted,secret):`•••• ${x.account_last4}`,accountLast4:x.account_last4,amountMinor:String(x.amount_minor),currency:x.currency,status:x.status,ownerNote:x.owner_note,createdAt:Number(x.created_at),updatedAt:Number(x.updated_at)});

export async function withdrawalWalletState(db:D1Database,userId:string){
 const values=await db.prepare(`SELECT
  CAST(COALESCE((SELECT SUM(member.amount_minor)
   FROM wallet_ledger member
   JOIN deposit_orders orders ON orders.id=member.order_id AND orders.user_id=member.user_id
   JOIN wallet_ledger clearing ON clearing.order_id=member.order_id AND clearing.account_code='provider_clearing'
   WHERE member.user_id=? AND member.account_code='member' AND member.currency='MYR'
    AND orders.status='credited' AND orders.currency='MYR' AND member.amount_minor=orders.amount_minor
    AND clearing.user_id=orders.user_id AND clearing.currency='MYR' AND clearing.amount_minor=-orders.amount_minor),0) AS TEXT) credits,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM game_wallet_ledger WHERE user_id=? AND account_code='game_result' AND currency='MYR'),0) AS TEXT) game_results,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=? AND status='paid' AND currency='MYR'),0) AS TEXT) paid,
  CAST(COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=? AND status IN ('pending','approved','processing') AND currency='MYR'),0) AS TEXT) withdrawal_held,
  CAST(COALESCE((SELECT SUM(amount_out_minor) FROM game_wallet_sessions WHERE user_id=? AND status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')),0) AS TEXT) game_held`).bind(userId,userId,userId,userId,userId).first<any>();
 const credits=BigInt(values?.credits??0),gameResults=BigInt(values?.game_results??0),paid=BigInt(values?.paid??0),withdrawalHeld=BigInt(values?.withdrawal_held??0),gameHeld=BigInt(values?.game_held??0),balance=credits+gameResults-paid,held=withdrawalHeld+gameHeld,available=balance-held;
 return {balanceMinor:(balance>0n?balance:0n).toString(),availableMinor:(available>0n?available:0n).toString(),heldMinor:held.toString(),withdrawalHeldMinor:withdrawalHeld.toString(),gameHeldMinor:gameHeld.toString()};
}

export async function getWithdrawalBanks(c?:WithdrawalContext){const available=providers(c);return json({currency:'MYR',enabled:available.some(x=>x.enabled),banks:malaysiaBanks.map(([id,name])=>({id,name})),providers:available});}

export async function listMemberWithdrawals(c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);
 const result=await c.db.prepare('SELECT * FROM withdrawal_requests WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 100').bind(u.id).all<any>();
 return json({items:(result.results??[]).map(x=>record(x)),wallet:await withdrawalWalletState(c.db,u.id)});
}

export async function listAdminWithdrawals(c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='owner')return json({error:'Access denied'},403);if(!withdrawalDataKeyReady(c.dataKey))return json({error:'Withdrawal security not configured'},503);
 try{const result=await c.db.prepare('SELECT w.*,u.username FROM withdrawal_requests w JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC,w.id DESC LIMIT 500').all<any>();return json({items:(result.results??[]).map(x=>record(x,c.dataKey,true)),providers:providers(c)});}catch{return json({error:'Withdrawal records unavailable'},503);}
}

export async function submitWithdrawal(d:Record<string,unknown>,c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='member')return json({error:'Member account required'},403);if(!u.approved)return json({error:'Account awaiting approval'},403);if(!withdrawalDataKeyReady(c.dataKey))return json({error:'Withdrawal security not configured'},503);
 const selectedProvider=provider(d.providerId,c);if(selectedProvider&&!selectedProvider.enabled)return json({error:`${selectedProvider.name} payout is not connected`},503);
 const selectedBank=malaysiaBank(d.bankCode),name=cleanName(d.accountHolder),account=cleanAccount(d.accountNumber),amount=amountMinor(d.amount),requestKey=typeof d.requestKey==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(d.requestKey)?d.requestKey:'';
 if(!selectedProvider||!selectedBank||!name||!account||!amount||!requestKey)return json({error:'Invalid withdrawal details'},400);
 const adapter=c.payouts?.[selectedProvider.id];if(!adapter||!adapter.enabled)return json({error:`${selectedProvider.name} payout is not connected`},503);if(adapter.supportsBank&&!adapter.supportsBank(selectedBank[0]))return json({error:`${selectedBank[1]} is not supported by ${selectedProvider.name}`},400);
 const fingerprint=createHash('sha256').update(JSON.stringify({provider:selectedProvider.id,userId:u.id,amount,bank:selectedBank[0],account:createHash('sha256').update(account).digest('hex')})).digest('hex'),replay=await c.db.prepare('SELECT w.*,p.fingerprint FROM withdrawal_requests w LEFT JOIN provider_payouts p ON p.withdrawal_id=w.id WHERE w.user_id=? AND w.request_key=?').bind(u.id,requestKey).first<any>();
 if(replay){if(replay.fingerprint!==fingerprint)return json({error:'IDEMPOTENCY_CONFLICT'},409);return json({status:replay.status==='paid'?'paid':replay.status==='rejected'||replay.status==='cancelled'?'failed':replay.status==='processing'?'processing':'review',withdrawal:record(replay)},200);}
 await clearStaleReservation(c.db,u.id);
 const gameOpen=await c.db.prepare("SELECT id FROM game_wallet_sessions WHERE user_id=? AND status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review') LIMIT 1").bind(u.id).first();if(gameOpen)return json({error:'Settle the game wallet before withdrawing'},409);
 const open=await c.db.prepare("SELECT id FROM withdrawal_requests WHERE user_id=? AND status IN ('pending','approved','processing') LIMIT 1").bind(u.id).first();if(open)return json({error:'You already have a withdrawal being processed'},409);
 const wallet=await withdrawalWalletState(c.db,u.id);if(BigInt(wallet.availableMinor)<BigInt(amount))return json({error:'Insufficient available balance'},409);
 const id=crypto.randomUUID(),payoutId=`P7${crypto.randomUUID().replaceAll('-','').slice(0,30)}`,timestamp=Math.floor(Date.now()/1000);
 try{await c.db.batch([
  c.db.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES(?,'withdrawal',?,?,?)").bind(u.id,id,amount,timestamp),
  c.db.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'MYR','pending','',?,?)").bind(id,u.id,requestKey,selectedProvider.id,selectedProvider.name,selectedBank[0],selectedBank[1],encryptWithdrawalValue(name,c.dataKey),encryptWithdrawalValue(account,c.dataKey),account.slice(-4),amount,timestamp,timestamp),
  c.db.prepare("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,created_at,updated_at) VALUES(?,?,?, ?,?,?,'MYR','prepared','not_submitted',?,?)").bind(payoutId,id,selectedProvider.id,requestKey,fingerprint,amount,timestamp,timestamp),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),u.id,'withdrawal_requested',id,timestamp),
 ]);
  let payout:PayoutSubmission={status:'processing'};try{payout=await adapter.submit({payoutId,withdrawalId:id,userId:u.id,accountHolder:name,accountNumber:account,bankCode:selectedBank[0],amountMinor:amount});}catch{const failedAt=Math.floor(Date.now()/1000);await c.db.batch([c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code='submission_internal_error',updated_at=? WHERE id=? AND status<>'succeeded'").bind(failedAt,payoutId),c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status='pending'").bind(failedAt,id)]);payout={status:'review'};}
  const current=await c.db.prepare('SELECT status FROM withdrawal_requests WHERE id=?').bind(id).first<{status:string}>();
  return json({status:payout.status==='succeeded'?'paid':payout.status==='failed'?'failed':payout.status==='review'?'review':'processing',withdrawal:{id,providerName:selectedProvider.name,bankName:selectedBank[1],accountNumber:`•••• ${account.slice(-4)}`,amountMinor:amount,currency:'MYR',status:current?.status??'processing',createdAt:timestamp}},payout.status==='succeeded'?201:202);
 }catch(error:any){if(String(error?.message??'').includes('UNIQUE'))return json({error:'You already have a withdrawal being processed'},409);throw error;}
}

export async function cancelWithdrawal(d:Record<string,unknown>,c:WithdrawalContext){
 const u=c.user;if(!u)return json({error:'Sign in required'},401);if(u.role!=='owner')return json({error:'Access denied'},403);
 const id=typeof d.id==='string'&&/^[A-Za-z0-9-]{8,80}$/.test(d.id)?d.id:'',next=typeof d.status==='string'?d.status:'',note=typeof d.ownerNote==='string'&&d.ownerNote.trim().length<=200&&!/[\u0000-\u001f\u007f-\u009f]/u.test(d.ownerNote)?d.ownerNote.trim():null;
 if(!id||note===null||!['rejected','cancelled'].includes(next))return json({error:'Only cancellation of a pending withdrawal is allowed'},400);
 const timestamp=Math.floor(Date.now()/1000),claimed=await c.db.prepare("UPDATE withdrawal_requests SET status=?,owner_note=?,updated_by=?,updated_at=? WHERE id=? AND status='pending' RETURNING id").bind(next,note,u.id,timestamp,id).first<{id:string}>();
 if(!claimed){const current=await c.db.prepare('SELECT status FROM withdrawal_requests WHERE id=?').bind(id).first<{status:string}>();return current?json({error:'Withdrawal is no longer pending'},409):json({error:'Withdrawal not found'},404);}
 await c.db.batch([
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(id),
  c.db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),u.id,'withdrawal_'+next,id,timestamp),
 ]);
 return json({status:'ok',withdrawalStatus:next});
}

export async function clearStaleReservation(db:D1Database,userId:string){
 await db.prepare(`DELETE FROM wallet_reservations WHERE user_id=? AND (
  (kind='withdrawal' AND NOT EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=wallet_reservations.reference_id AND w.status IN ('pending','approved','processing')))
  OR (kind='game' AND NOT EXISTS (SELECT 1 FROM game_wallet_sessions g WHERE g.id=wallet_reservations.reference_id AND g.status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')))
 )`).bind(userId).run();
}
