import {createJdbGameProviderAdapter} from './jdb-provider-adapter.ts';
import type {JdbConfig,JdbProfile} from './jdb-transfer-protocol.ts';
import {getGameProviderProfile} from './game-provider-registry.ts';

/** This document is a Render Secret. It is never returned to either frontend.
 * Account routing is selected by the server's registered profile, never by a
 * browser-supplied API URL, merchant, currency, IV or key. */
export function jdbProfileRuntime(raw:string|undefined,profileId:string,userId:string,options:{fetchImpl?:typeof fetch;productionAccepted?:boolean}={}){
 if(!raw||raw.length>32_768||!['jdb_myr','spribe_myr'].includes(profileId))return null;
 try{
  const root=JSON.parse(raw),value=root?.profiles?.[profileId],profile=getGameProviderProfile(profileId);
  if(!profile||!value||!['closed','qa','production'].includes(value.mode)||value.environment!=='production'||typeof value.recoveryEnabled!=='boolean')return null;
  const cfg=value.connection as JdbConfig;if(!cfg||cfg.profile!==profileId||!Array.isArray(value.approvedApiOrigins)||!value.approvedApiOrigins.includes(cfg.baseUrl)||!Array.isArray(value.qaMemberIds)||value.qaMemberIds.length>50||value.qaMemberIds.some((id:unknown)=>typeof id!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(id)))return null;
  const launchAuthorized=Array.isArray(cfg.launchOrigins)&&cfg.launchOrigins.length>0&&value.recoveryEnabled===true&&value.sessionClosureVerified===true&&(value.mode==='qa'?value.qaMemberIds.includes(userId):value.mode==='production'&&options.productionAccepted===true);
  const adapter=createJdbGameProviderAdapter({...cfg,profile:profileId as JdbProfile},{fetchImpl:options.fetchImpl??fetch,allowedReturnOrigins:value.allowedReturnOrigins??['https://www.master7.best','https://master7-v17-staging.onrender.com'],playerCreationEnabled:launchAuthorized,depositEnabled:launchAuthorized,launchEnabled:launchAuthorized,withdrawalEnabled:value.recoveryEnabled,sessionClosureEnabled:value.recoveryEnabled,sessionClosureVerified:value.sessionClosureVerified===true});
  return {profile,adapter,launchAuthorized,recoveryEnabled:value.recoveryEnabled,mode:value.mode as 'closed'|'qa'|'production',environment:'production' as const};
 }catch{return null;}
}

export async function seedJdbTransferProfile(db:D1Database,runtime:NonNullable<ReturnType<typeof jdbProfileRuntime>>){
 const p=runtime.profile,at=Math.floor(Date.now()/1000);
 await db.prepare("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES(?,?,?,?,'transfer','cash','MYR',1,1,'production',?,?,?) ON CONFLICT(id) DO NOTHING").bind(p.profileId,p.providerId,p.displayName,p.adapterKey,runtime.mode==='qa'?'uat':runtime.mode==='production'&&runtime.launchAuthorized?'active':'closed',at,at).run();
 const existing=await db.prepare('SELECT environment FROM game_provider_profiles WHERE id=?').bind(p.profileId).first<{environment:string}>();
 if(existing?.environment!=='production')return false;return true;
}
