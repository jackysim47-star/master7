import {createJdbGameProviderAdapter} from './jdb-provider-adapter.ts';
import type {JdbConfig,JdbProfile} from './jdb-transfer-protocol.ts';
import {getGameProviderProfile} from './game-provider-registry.ts';

const CUSTOMER_RETURN_ORIGIN='https://www.master7.best';

function approvedHttpsOrigin(value:unknown){
 if(typeof value!=='string')return null;
 try{const url=new URL(value);if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||!['','/'].includes(url.pathname)||(url.port&&url.port!=='443'))return null;return url.origin;}catch{return null;}
}
function sha(value:unknown){return typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);}
function returnOrigins(value:unknown){
 if(!Array.isArray(value)||value.length===0||value.length>20)return {allowed:[] as string[],customerAllowed:false};
 const allowed=value.map(approvedHttpsOrigin);if(allowed.some(origin=>origin===null))return {allowed:[] as string[],customerAllowed:false};
 const exact=allowed as string[];return {allowed:exact,customerAllowed:exact.includes(CUSTOMER_RETURN_ORIGIN)};
}

/** This document is a Render Secret. It is never returned to either frontend.
 * Account routing is selected by the server's registered profile, never by a
 * browser-supplied API URL, merchant, currency, IV or key. */
export function jdbProfileRuntime(raw:string|undefined,profileId:string,userId:string,options:{fetchImpl?:typeof fetch;productionAccepted?:boolean}={}){
 if(!raw||raw.length>32_768||!['jdb_myr','spribe_myr'].includes(profileId))return null;
 try{
  const root=JSON.parse(raw),value=root?.profiles?.[profileId],profile=getGameProviderProfile(profileId);
  if(!profile||!value||!['closed','qa','production'].includes(value.mode)||value.environment!=='production'||typeof value.recoveryEnabled!=='boolean')return null;
  const cfg=value.connection as JdbConfig,apiOrigin=approvedHttpsOrigin(cfg?.baseUrl),approvedOrigins=Array.isArray(value.approvedApiOrigins)?value.approvedApiOrigins.map(approvedHttpsOrigin):[];if(!cfg||cfg.profile!==profileId||!apiOrigin||approvedOrigins.length===0||approvedOrigins.length>20||approvedOrigins.some((origin:unknown)=>origin===null)||!approvedOrigins.includes(apiOrigin)||!Array.isArray(value.qaMemberIds)||value.qaMemberIds.length>50||value.qaMemberIds.some((id:unknown)=>typeof id!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(id)))return null;
  // Generic acceptance rows and possession of credentials cannot establish
  // that this merchant/account may move MYR, how provider units settle, or
  // when issued URLs and late results are final. Keep each proof explicit and
  // immutable. QA membership only authorizes a new launch; recovery remains
  // independently available so removing a member cannot strand old funds.
  const contractVerified=value.merchantContractVerified===true&&sha(value.merchantContractEvidenceSha256);
  const merchantAuthorized=contractVerified&&value.merchantAuthorizationVerified===true&&sha(value.merchantAuthorizationEvidenceSha256);
  const amountUnitVerified=contractVerified&&value.amountUnitVerified===true&&sha(value.amountUnitEvidenceSha256);
  const catalogueEnabled=merchantAuthorized&&amountUnitVerified&&value.catalogueAvailabilityVerified===true&&sha(value.catalogueAvailabilityEvidenceSha256);
  const closureVerified=merchantAuthorized&&amountUnitVerified&&value.sessionClosureVerified===true&&value.allIssuedLaunchesInvalidated===true&&value.lateResultsFinal===true&&sha(value.sessionClosureEvidenceSha256);
  const recoveryEnabled=value.recoveryEnabled===true&&closureVerified;
  const reportEnabled=merchantAuthorized&&amountUnitVerified&&value.reportEnabled===true&&value.reportSemanticsVerified===true&&sha(value.reportEvidenceSha256);
  const returns=returnOrigins(value.allowedReturnOrigins);
  const memberAuthorized=value.mode==='qa'?value.qaMemberIds.includes(userId):value.mode==='production'&&options.productionAccepted===true;
  const launchAuthorized=catalogueEnabled&&recoveryEnabled&&returns.customerAllowed&&cfg.launchOrigins.length>0&&memberAuthorized;
  const adapter=createJdbGameProviderAdapter({...cfg,profile:profileId as JdbProfile},{fetchImpl:options.fetchImpl??fetch,allowedReturnOrigins:returns.allowed,catalogueEnabled,playerCreationEnabled:launchAuthorized,depositEnabled:launchAuthorized,launchEnabled:launchAuthorized,withdrawalEnabled:recoveryEnabled,recoveryEnabled,reportEnabled,sessionClosureEnabled:recoveryEnabled,sessionClosureVerified:closureVerified});
  return {profile,adapter,launchAuthorized,recoveryEnabled,reportEnabled,catalogueEnabled,mode:value.mode as 'closed'|'qa'|'production',environment:'production' as const};
 }catch{return null;}
}

export async function seedJdbTransferProfile(db:D1Database,runtime:NonNullable<ReturnType<typeof jdbProfileRuntime>>){
 const p=runtime.profile,at=Math.floor(Date.now()/1000);
 await db.prepare("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES(?,?,?,?,'transfer','cash','MYR',1,1,'production','closed',?,?) ON CONFLICT(id) DO NOTHING").bind(p.profileId,p.providerId,p.displayName,p.adapterKey,at,at).run();
 const existing=await db.prepare('SELECT environment FROM game_provider_profiles WHERE id=?').bind(p.profileId).first<{environment:string}>();
 if(existing?.environment!=='production')return false;return true;
}
