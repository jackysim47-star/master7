import {createJdbGameProviderAdapter} from './jdb-provider-adapter.ts';
import type {JdbConfig,JdbProfile} from './jdb-transfer-protocol.ts';
import {getGameProviderProfile} from './game-provider-registry.ts';

function approvedHttpsOrigin(value:unknown){
 if(typeof value!=='string')return null;
 try{const url=new URL(value);if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||!['','/'].includes(url.pathname)||(url.port&&url.port!=='443'))return null;return url.origin;}catch{return null;}
}

/** This document is a Render Secret. It is never returned to either frontend.
 * Account routing is selected by the server's registered profile, never by a
 * browser-supplied API URL, merchant, currency, IV or key. */
export function jdbProfileRuntime(raw:string|undefined,profileId:string,userId:string,options:{fetchImpl?:typeof fetch;productionAccepted?:boolean}={}){
 if(!raw||raw.length>32_768||!['jdb_myr','spribe_myr'].includes(profileId))return null;
 try{
  const root=JSON.parse(raw),value=root?.profiles?.[profileId],profile=getGameProviderProfile(profileId);
  if(!profile||!value||!['closed','qa','production'].includes(value.mode)||value.environment!=='production'||typeof value.recoveryEnabled!=='boolean')return null;
  const cfg=value.connection as JdbConfig,apiOrigin=approvedHttpsOrigin(cfg?.baseUrl),approvedOrigins=Array.isArray(value.approvedApiOrigins)?value.approvedApiOrigins.map(approvedHttpsOrigin):[];if(!cfg||cfg.profile!==profileId||!apiOrigin||approvedOrigins.length===0||approvedOrigins.length>20||approvedOrigins.some((origin:unknown)=>origin===null)||!approvedOrigins.includes(apiOrigin)||!Array.isArray(value.qaMemberIds)||value.qaMemberIds.length>50||value.qaMemberIds.some((id:unknown)=>typeof id!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(id)))return null;
  // v164 stores review-only report receipts. Those receipts deliberately
  // cannot prove report finality, merchant authorization or official session
  // closure, so neither a secret document nor generic capability evidence may
  // activate JDB money or Play. The adapter remains usable by fixture tests;
  // every operation flag and runtime readiness value stays closed.
  const launchAuthorized=false,recoveryEnabled=false;
  const adapter=createJdbGameProviderAdapter({...cfg,profile:profileId as JdbProfile},{fetchImpl:options.fetchImpl??fetch,allowedReturnOrigins:value.allowedReturnOrigins??['https://www.master7.best','https://master7-v17-staging.onrender.com'],playerCreationEnabled:false,depositEnabled:false,launchEnabled:false,withdrawalEnabled:false,sessionClosureEnabled:false,sessionClosureVerified:false});
  return {profile,adapter,launchAuthorized,recoveryEnabled,mode:'closed' as const,environment:'production' as const};
 }catch{return null;}
}

export async function seedJdbTransferProfile(db:D1Database,runtime:NonNullable<ReturnType<typeof jdbProfileRuntime>>){
 const p=runtime.profile,at=Math.floor(Date.now()/1000);
 await db.prepare("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES(?,?,?,?,'transfer','cash','MYR',1,1,'production','closed',?,?) ON CONFLICT(id) DO NOTHING").bind(p.profileId,p.providerId,p.displayName,p.adapterKey,at,at).run();
 const existing=await db.prepare('SELECT environment FROM game_provider_profiles WHERE id=?').bind(p.profileId).first<{environment:string}>();
 if(existing?.environment!=='production')return false;return true;
}
