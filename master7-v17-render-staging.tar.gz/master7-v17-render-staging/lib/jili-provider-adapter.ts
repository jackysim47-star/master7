import {createJiliProtocolClient,jiliPlayerId,jiliTransactionId,type JiliConfig,type JiliProfile} from './jili-transfer-protocol.ts';
import {createHash} from 'node:crypto';
import type {GameProviderAdapter,GameProviderContext,GameProviderSweepInput,GameProviderTransferInput} from './game-provider-adapter.ts';

export type JiliAdapterOptions={fetchImpl:typeof fetch;now?:()=>number;allowedReturnOrigins:readonly string[];catalogueAvailabilityVerified?:boolean;playerCreationEnabled?:boolean;depositEnabled?:boolean;launchEnabled?:boolean;recoveryEnabled?:boolean;reportEnabled?:boolean;merchantContractVerified?:boolean;sessionClosureVerified?:boolean};
export class JiliAdapterError extends Error{readonly code:string;constructor(code:string){super(code);this.name='JiliAdapterError';this.code=code;}}
const fail=(code:string):never=>{throw new JiliAdapterError(code);};

/** Constructing an adapter does not activate a profile or certify a supplier
 * account. Cash methods additionally require its verified merchant contract. */
export function createJiliGameProviderAdapter(config:JiliConfig,options:JiliAdapterOptions):GameProviderAdapter&{readonly profileId:JiliProfile}{
 if(!options||!Array.isArray(options.allowedReturnOrigins))return fail('JILI_CONFIGURATION_INVALID');
 const snapshot={...config,launchOrigins:[...config.launchOrigins]},client=createJiliProtocolClient(snapshot,options.fetchImpl,options.now),profileId=config.profile;
 const returns=new Set(options.allowedReturnOrigins.map(raw=>{try{const u=new URL(raw);if(u.origin!==raw||u.protocol!=='https:'||u.port)return fail('JILI_RETURN_ORIGIN_INVALID');return u.origin;}catch{return fail('JILI_RETURN_ORIGIN_INVALID');}}));
 const flags=Object.freeze({contract:options.merchantContractVerified===true,closure:options.sessionClosureVerified===true,catalogue:options.catalogueAvailabilityVerified===true,player:options.playerCreationEnabled===true,deposit:options.depositEnabled===true,launch:options.launchEnabled===true,recovery:options.recoveryEnabled===true,report:options.reportEnabled===true});
 function context(c:GameProviderContext){
  const p=c?.profile,scale=profileId==='jili_my1_1to100'?100:1;
  if(!p||p.profileId!==profileId||p.providerId!=='jili'||p.adapterKey!=='jili'||p.walletMode!=='transfer'||p.currency!=='MYR'||p.balanceClass==='free_credit'||p.unitScale!==scale||p.playerNamespace!==profileId||p.ledgerNamespace!==profileId)return fail('JILI_PROFILE_MISMATCH');
 }
 function player(userId:string,supplied:string){const expected=jiliPlayerId(profileId,userId);if(supplied!==expected)return fail('JILI_PLAYER_MISMATCH');return expected;}
 function binding(input:GameProviderSweepInput,direction:'deposit'|'withdrawal'){
  if(!input||input.currency!=='MYR')return fail('JILI_TRANSFER_INPUT_INVALID');
  return {playerId:player(input.userId,input.providerPlayerId),transactionId:jiliTransactionId(profileId,input.platformTransactionId,direction),direction};
 }
 function cashEnabled(enabled:boolean){if(!enabled||!flags.contract||!flags.closure)return fail('JILI_MERCHANT_CONTRACT_UNVERIFIED');}
 const adapter:GameProviderAdapter&{readonly profileId:JiliProfile}={
  key:'jili',profileId,executable:true,withdrawalMode:'all',
  transferContractFingerprint:createHash('sha256').update(JSON.stringify([profileId,new URL(snapshot.baseUrl).href.replace(/\/$/,''),snapshot.agentId,snapshot.transferAmountUnit,snapshot.queryAmountUnit,snapshot.balanceAmountUnit,snapshot.reportAmountUnit])).digest('hex'),
  async listGames(c){context(c);const games=await client.listGames();return games.map(game=>({...game,maintenance:!flags.catalogue}));},
  async createOrVerifyPlayer(c,m){
   context(c);const id=jiliPlayerId(profileId,m.userId);let created=false;
   if(flags.player){cashEnabled(true);try{created=(await client.createPlayer(id)).created;}catch{/* Verify once; never retry a timed-out create. */}}
   const found=await client.player(id);if(!found.exists||found.residual)return fail('JILI_PLAYER_UNVERIFIED');return {providerPlayerId:id,created};
  },
  async depositToGame(c,input:GameProviderTransferInput){
   context(c);const value=binding(input,'deposit');cashEnabled(flags.deposit);const found=await client.player(value.playerId);
   if(!found.exists||found.residual)return {state:'unknown',errorCode:'JILI_PLAYER_UNVERIFIED',requiresLedgerReconciliation:true};
   return client.transfer({...value,amountMinor:input.amountMinor});
  },
  async queryBalance(c,input){context(c);const found=await client.player(player(input.userId,input.providerPlayerId));if(!found.exists)return fail('JILI_PLAYER_UNVERIFIED');return {amountMinor:found.amountMinor,currency:'MYR',residual:found.residual,providerAmount:found.providerAmount};},
  async launchGame(c,input){
   context(c);const id=player(input.userId,input.providerPlayerId);cashEnabled(flags.launch);
   let url:URL;try{url=new URL(input.returnUrl);}catch{return fail('JILI_RETURN_URL_INVALID');}
   if(!returns.has(url.origin)||url.protocol!=='https:'||url.username||url.password||url.hash||url.href.length>500)return fail('JILI_RETURN_URL_INVALID');
   return client.launch(id,input.providerGameId,input.language,url.href);
  },
  async withdrawFromGame(c){context(c);return fail('JILI_EXACT_WITHDRAWAL_UNSUPPORTED');},
  async withdrawAllFromGame(c,input){context(c);const value=binding(input,'withdrawal');cashEnabled(flags.recovery);return client.transfer(value);},
  async queryWithdrawAll(c,input){context(c);const value=binding(input,'withdrawal');cashEnabled(flags.recovery);return client.queryTransfer({...value,providerTransactionId:input.providerTransactionId});},
  async queryTransfer(c,input){
   context(c);if(input.direction!=='deposit')return fail('JILI_EXACT_WITHDRAWAL_UNSUPPORTED');const value=binding(input,'deposit');cashEnabled(flags.recovery);return client.queryTransfer({...value,amountMinor:input.amountMinor,providerTransactionId:input.providerTransactionId});
  },
  async closeGame(c,input){
   context(c);const id=player(input.userId,input.providerPlayerId);
   // Offline is useful only after the merchant's closure/finality contract has
   // been independently accepted. A point-in-time member status is not that
   // evidence and must never be promoted to a platform closure on its own.
   if(!flags.closure)return fail('JILI_SESSION_CLOSURE_UNVERIFIED');
   if(input.requestClosure){cashEnabled(flags.recovery);try{await client.kick(id);}catch{return {state:'unknown'};}}
   try{const found=await client.player(id);if(!found.exists)return {state:'unknown'};return found.online?{state:'playing'}:{state:'closed',evidenceCode:input.requestClosure?'JILI_VERIFIED_KICK_OFFLINE':'JILI_MEMBER_OFFLINE'};}catch{return {state:'unknown'};}
  },
  async fetchWagers(c,cursor){context(c);if(!flags.report)return fail('JILI_REPORT_DISABLED');if(!cursor)return fail('JILI_REPORT_WINDOW_INVALID');return client.wagers(cursor.from,cursor.to,cursor.cursor);},
  async handleCallback(c){context(c);return {accepted:false,duplicate:false,responseBody:'UNSUPPORTED_TRANSFER_CALLBACK',responseStatus:403};},
 };
 return Object.freeze(adapter);
}
