export class RewardsHubError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

type CheckInConfig={enabled:boolean;dailyPoints:[number,number,number,number,number,number,number]};
type PointsMission={enabled:boolean;rewardPoints:number};
type DepositMission=PointsMission&{targetMYR:number};
type TurnoverMission=PointsMission&{targetMYR:number};
type GameplayMission=PointsMission&{targetCount:number};
type ReferralMilestone={id:string;active:boolean;targetQualified:number;rewardPoints:number};
type CouponEligibility={type:'all'|'min_credited_deposit'|'min_qualified_referrals';threshold:number};
type RewardCoupon={id:string;title:string;description:string;active:boolean;expiresAt:number|null;eligibility:CouponEligibility};
export type RewardsHubProgram={
 version:1;
 name:string;
 enabled:boolean;
 pointsName:string;
 pointsEnabled:boolean;
 checkIn:CheckInConfig;
 missions:{registration:PointsMission;creditedDeposit:DepositMission;turnover:TurnoverMission;gameplay:GameplayMission};
 referralMilestones:ReferralMilestone[];
 coupons:RewardCoupon[];
};
type StoredProgram=RewardsHubProgram&{updatedAt:number;updatedBy:string};

const SETTING_ID='rewards_hub_v1',MYT_OFFSET=8*3600,DAY=86400;
const PROGRAM_KEYS=['version','name','enabled','pointsName','pointsEnabled','checkIn','missions','referralMilestones','coupons'] as const;
const CAPABILITIES={
 cashValue:false,walletCredit:false,redemption:false,missionClaimProcessing:false,couponClaimProcessing:false,
 checkInPointsLedger:true,timezone:'Asia/Kuching',separateFromVip:true,separateFromBenefits:true,
 sources:{registration:'users',creditedDeposit:'deposit_orders:credited',referrals:'referral_relationships+deposit_orders:credited',turnover:'not_connected',wager:'not_connected',gameplay:'not_connected'},
} as const;

function record(value:unknown,label:string):Record<string,unknown>{
 if(!value||typeof value!=='object'||Array.isArray(value))throw new RewardsHubError(400,`Invalid ${label}`);
 return value as Record<string,unknown>;
}
function exact(value:Record<string,unknown>,keys:readonly string[],label:string){
 const allowed=new Set(keys),unknown=Object.keys(value).find(key=>!allowed.has(key)),missing=keys.find(key=>!Object.hasOwn(value,key));
 if(unknown)throw new RewardsHubError(400,`Unknown ${label} field: ${unknown}`);
 if(missing)throw new RewardsHubError(400,`Missing ${label} field: ${missing}`);
}
function bool(value:unknown,label:string){if(typeof value!=='boolean')throw new RewardsHubError(400,`Invalid ${label}`);return value;}
function integer(value:unknown,label:string,min=0,max=1_000_000){if(typeof value!=='number'||!Number.isSafeInteger(value)||value<min||value>max)throw new RewardsHubError(400,`Invalid ${label}`);return value;}
function amount(value:unknown,label:string){if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>1_000_000_000||Math.abs(Math.round(value*100)-value*100)>1e-7)throw new RewardsHubError(400,`Invalid ${label}`);return value;}
function text(value:unknown,label:string,min:number,max:number){if(typeof value!=='string'||value.trim()!==value||value.length<min||value.length>max)throw new RewardsHubError(400,`Invalid ${label}`);return value;}
function id(value:unknown,label:string){const out=text(value,label,1,40);if(!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(out))throw new RewardsHubError(400,`Invalid ${label}`);return out;}
function pointsMission(value:unknown,label:string):PointsMission{const item=record(value,label);exact(item,['enabled','rewardPoints'],label);return {enabled:bool(item.enabled,`${label} state`),rewardPoints:integer(item.rewardPoints,`${label} points`)};}

export function validateRewardsHubProgram(input:unknown):RewardsHubProgram{
 const value=record(input,'Rewards Hub program');exact(value,PROGRAM_KEYS,'Rewards Hub program');
 if(value.version!==1)throw new RewardsHubError(400,'Unsupported Rewards Hub version');
 const name=text(value.name,'program name',2,60),enabled=bool(value.enabled,'program state'),pointsName=text(value.pointsName,'points name',2,40),pointsEnabled=bool(value.pointsEnabled,'points state');
 const checkInRaw=record(value.checkIn,'check-in');exact(checkInRaw,['enabled','dailyPoints'],'check-in');
 if(!Array.isArray(checkInRaw.dailyPoints)||checkInRaw.dailyPoints.length!==7)throw new RewardsHubError(400,'Check-in requires exactly seven daily point values');
 const dailyPoints=checkInRaw.dailyPoints.map((entry,index)=>integer(entry,`day ${index+1} check-in points`)) as CheckInConfig['dailyPoints'];
 const checkIn={enabled:bool(checkInRaw.enabled,'check-in state'),dailyPoints};
 const missionsRaw=record(value.missions,'missions');exact(missionsRaw,['registration','creditedDeposit','turnover','gameplay'],'missions');
 const registration=pointsMission(missionsRaw.registration,'registration mission');
 const depositRaw=record(missionsRaw.creditedDeposit,'credited deposit mission');exact(depositRaw,['enabled','targetMYR','rewardPoints'],'credited deposit mission');
 const creditedDeposit={enabled:bool(depositRaw.enabled,'credited deposit mission state'),targetMYR:amount(depositRaw.targetMYR,'credited deposit target'),rewardPoints:integer(depositRaw.rewardPoints,'credited deposit points')};
 const turnoverRaw=record(missionsRaw.turnover,'turnover mission');exact(turnoverRaw,['enabled','targetMYR','rewardPoints'],'turnover mission');
 const turnover={enabled:bool(turnoverRaw.enabled,'turnover mission state'),targetMYR:amount(turnoverRaw.targetMYR,'turnover target'),rewardPoints:integer(turnoverRaw.rewardPoints,'turnover points')};
 const gameplayRaw=record(missionsRaw.gameplay,'gameplay mission');exact(gameplayRaw,['enabled','targetCount','rewardPoints'],'gameplay mission');
 const gameplay={enabled:bool(gameplayRaw.enabled,'gameplay mission state'),targetCount:integer(gameplayRaw.targetCount,'gameplay target',0,1_000_000_000),rewardPoints:integer(gameplayRaw.rewardPoints,'gameplay points')};
 if(creditedDeposit.enabled&&creditedDeposit.targetMYR<=0)throw new RewardsHubError(400,'Enabled deposit missions require a positive target');
 if(turnover.enabled&&turnover.targetMYR<=0)throw new RewardsHubError(400,'Enabled turnover missions require a positive target');
 if(gameplay.enabled&&gameplay.targetCount<=0)throw new RewardsHubError(400,'Enabled gameplay missions require a positive target');
 if(!Array.isArray(value.referralMilestones)||value.referralMilestones.length>10)throw new RewardsHubError(400,'Referral milestones must contain zero to ten items');
 const milestoneIds=new Set<string>(),milestoneTargets=new Set<number>();
 const referralMilestones=value.referralMilestones.map((entry,index)=>{const item=record(entry,`referral milestone ${index+1}`);exact(item,['id','active','targetQualified','rewardPoints'],`referral milestone ${index+1}`);const result={id:id(item.id,`referral milestone ${index+1} id`),active:bool(item.active,`referral milestone ${index+1} state`),targetQualified:integer(item.targetQualified,`referral milestone ${index+1} target`,1,1_000_000),rewardPoints:integer(item.rewardPoints,`referral milestone ${index+1} points`)};if(milestoneIds.has(result.id)||milestoneTargets.has(result.targetQualified))throw new RewardsHubError(400,'Referral milestone ids and targets must be unique');milestoneIds.add(result.id);milestoneTargets.add(result.targetQualified);return result;});
 for(let index=1;index<referralMilestones.length;index++)if(referralMilestones[index].targetQualified<=referralMilestones[index-1].targetQualified)throw new RewardsHubError(400,'Referral milestones must be ordered by target');
 if(!Array.isArray(value.coupons)||value.coupons.length>20)throw new RewardsHubError(400,'Coupons must contain zero to twenty items');
 const couponIds=new Set<string>();
 const coupons=value.coupons.map((entry,index)=>{const item=record(entry,`coupon ${index+1}`);exact(item,['id','title','description','active','expiresAt','eligibility'],`coupon ${index+1}`);const couponId=id(item.id,`coupon ${index+1} id`);if(couponIds.has(couponId))throw new RewardsHubError(400,'Coupon ids must be unique');couponIds.add(couponId);const eligibilityRaw=record(item.eligibility,`coupon ${couponId} eligibility`);exact(eligibilityRaw,['type','threshold'],`coupon ${couponId} eligibility`);if(!['all','min_credited_deposit','min_qualified_referrals'].includes(String(eligibilityRaw.type)))throw new RewardsHubError(400,`Invalid coupon ${couponId} eligibility`);const type=eligibilityRaw.type as CouponEligibility['type'],threshold=type==='min_qualified_referrals'?integer(eligibilityRaw.threshold,`coupon ${couponId} threshold`,0,1_000_000):amount(eligibilityRaw.threshold,`coupon ${couponId} threshold`);if(type==='all'&&threshold!==0)throw new RewardsHubError(400,`Coupon ${couponId} all-member threshold must be zero`);const expiresAt=item.expiresAt===null?null:integer(item.expiresAt,`coupon ${couponId} expiry`,1,9_999_999_999);return {id:couponId,title:text(item.title,`coupon ${couponId} title`,2,80),description:text(item.description,`coupon ${couponId} description`,0,500),active:bool(item.active,`coupon ${couponId} state`),expiresAt,eligibility:{type,threshold}};});
 const configuredPoints=[...dailyPoints,registration.rewardPoints,creditedDeposit.rewardPoints,turnover.rewardPoints,gameplay.rewardPoints,...referralMilestones.map(item=>item.rewardPoints)].some(value=>value>0);
 if((checkIn.enabled||configuredPoints)&&!pointsEnabled)throw new RewardsHubError(400,'Enable Lucky Points before enabling point rewards');
 return {version:1,name,enabled,pointsName,pointsEnabled,checkIn,missions:{registration,creditedDeposit,turnover,gameplay},referralMilestones,coupons};
}

export function defaultRewardsHubProgram():RewardsHubProgram{return {version:1,name:'MASTER7 Rewards Hub',enabled:false,pointsName:'Lucky Points',pointsEnabled:false,checkIn:{enabled:false,dailyPoints:[0,0,0,0,0,0,0]},missions:{registration:{enabled:false,rewardPoints:0},creditedDeposit:{enabled:false,targetMYR:0,rewardPoints:0},turnover:{enabled:false,targetMYR:0,rewardPoints:0},gameplay:{enabled:false,targetCount:0,rewardPoints:0}},referralMilestones:[],coupons:[]};}

async function loadProgram(db:D1Database):Promise<{configured:boolean;program:RewardsHubProgram;updatedAt:number|null;updatedBy:string|null}>{
 const row=await db.prepare('SELECT value FROM settings WHERE id=?').bind(SETTING_ID).first<{value:string}>();if(!row)return {configured:false,program:defaultRewardsHubProgram(),updatedAt:null,updatedBy:null};
 let stored:Record<string,unknown>;try{stored=record(JSON.parse(row.value),'stored Rewards Hub program');}catch{throw new RewardsHubError(503,'Stored Rewards Hub program is invalid');}
 const keys=[...PROGRAM_KEYS,'updatedAt','updatedBy'];if(Object.keys(stored).some(key=>!keys.includes(key as any)))throw new RewardsHubError(503,'Stored Rewards Hub program is invalid');
 let program:RewardsHubProgram;try{program=validateRewardsHubProgram(Object.fromEntries(PROGRAM_KEYS.map(key=>[key,stored[key]])));}catch{throw new RewardsHubError(503,'Stored Rewards Hub program is invalid');}
 if(!Number.isSafeInteger(stored.updatedAt)||Number(stored.updatedAt)<0||typeof stored.updatedBy!=='string'||stored.updatedBy.length<1||stored.updatedBy.length>128)throw new RewardsHubError(503,'Stored Rewards Hub program is invalid');
 return {configured:true,program,updatedAt:Number(stored.updatedAt),updatedBy:stored.updatedBy};
}

export function mytDayStart(at=Math.floor(Date.now()/1000)){if(!Number.isSafeInteger(at)||at<0)throw new RewardsHubError(400,'Invalid check-in time');return Math.floor((at+MYT_OFFSET)/DAY)*DAY-MYT_OFFSET;}
function dayLabel(dayStart:number){return new Date((dayStart+MYT_OFFSET)*1000).toISOString().slice(0,10);}
function capabilities(){return {...CAPABILITIES};}
function pointsBalance(value:unknown){const parsed=Number(value??0);return Number.isSafeInteger(parsed)&&parsed>=0?parsed:0;}

async function memberState(db:D1Database,userId:string,program:RewardsHubProgram,at:number){
 const today=mytDayStart(at),yesterday=today-DAY;
 const [balanceRow,lastCheckIn,todayCheckIn,depositRow,referralRow,ledgerResult]=await Promise.all([
  db.prepare("SELECT COALESCE(SUM(points),0) points FROM rewards_points_ledger WHERE user_id=? AND status='earned'").bind(userId).first<{points:number|string}>(),
  db.prepare('SELECT myt_day,cycle_day,streak,points,created_at FROM rewards_checkins WHERE user_id=? ORDER BY myt_day DESC LIMIT 1').bind(userId).first<any>(),
  db.prepare('SELECT myt_day,cycle_day,streak,points,created_at FROM rewards_checkins WHERE user_id=? AND myt_day=?').bind(userId,today).first<any>(),
  db.prepare("SELECT CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount_minor,COUNT(*) orders FROM deposit_orders WHERE user_id=? AND currency='MYR' AND status='credited'").bind(userId).first<{amount_minor:string;orders:number|string}>(),
  db.prepare("SELECT COUNT(*) direct_count,COALESCE(SUM(CASE WHEN member.approved=1 AND EXISTS(SELECT 1 FROM deposit_orders d WHERE d.user_id=r.member_id AND d.currency='MYR' AND d.status='credited') THEN 1 ELSE 0 END),0) qualified_count FROM referral_relationships r JOIN users member ON member.id=r.member_id WHERE r.referrer_id=?").bind(userId).first<{direct_count:number|string;qualified_count:number|string}>(),
  db.prepare("SELECT source_type,points,created_at FROM rewards_points_ledger WHERE user_id=? AND status='earned' ORDER BY created_at DESC,id DESC LIMIT 50").bind(userId).all<any>(),
 ]);
 const creditedMinor=BigInt(String(depositRow?.amount_minor??'0')),creditedMYR=Number(creditedMinor)/100,directCount=pointsBalance(referralRow?.direct_count),qualifiedCount=pointsBalance(referralRow?.qualified_count),previousStreak=Number(lastCheckIn?.myt_day)===yesterday?pointsBalance(lastCheckIn?.streak):0,nextCycleDay=previousStreak%7+1;
 const progress=(value:number,target:number)=>target<=0?0:Math.min(100,Math.floor(value/target*100));
 const missions=[
  {id:'registration',label:'Registration',enabled:program.missions.registration.enabled,source:'users',sourceStatus:'connected',progress:1,target:1,percent:100,completed:true,rewardPoints:program.missions.registration.rewardPoints,claimable:false},
  {id:'credited_deposit',label:'Credited deposit',enabled:program.missions.creditedDeposit.enabled,source:'deposit_orders',sourceStatus:'connected',progress:creditedMYR,target:program.missions.creditedDeposit.targetMYR,percent:progress(creditedMYR,program.missions.creditedDeposit.targetMYR),completed:program.missions.creditedDeposit.targetMYR>0&&creditedMYR>=program.missions.creditedDeposit.targetMYR,rewardPoints:program.missions.creditedDeposit.rewardPoints,claimable:false},
  {id:'turnover',label:'Turnover',enabled:program.missions.turnover.enabled,source:'not_connected',sourceStatus:'not_connected',progress:null,target:program.missions.turnover.targetMYR,percent:null,completed:false,rewardPoints:program.missions.turnover.rewardPoints,claimable:false},
  {id:'gameplay',label:'Gameplay',enabled:program.missions.gameplay.enabled,source:'not_connected',sourceStatus:'not_connected',progress:null,target:program.missions.gameplay.targetCount,percent:null,completed:false,rewardPoints:program.missions.gameplay.rewardPoints,claimable:false},
 ];
 const referralMilestones=program.referralMilestones.map(item=>({...item,source:'referral_relationships+deposit_orders:credited',sourceStatus:'connected',progress:qualifiedCount,percent:progress(qualifiedCount,item.targetQualified),completed:qualifiedCount>=item.targetQualified,claimable:false}));
 const coupons=program.coupons.map(item=>{const expired=item.expiresAt!==null&&item.expiresAt<=at,eligible=!expired&&item.active&&(item.eligibility.type==='all'||item.eligibility.type==='min_credited_deposit'&&creditedMYR>=item.eligibility.threshold||item.eligibility.type==='min_qualified_referrals'&&qualifiedCount>=item.eligibility.threshold);return {...item,expired,eligible,claimable:false,redemption:false};});
 return {points:{name:program.pointsName,balance:pointsBalance(balanceRow?.points),cashValue:false,walletCredit:false,redemption:false,ledger:(ledgerResult.results??[])},checkIn:{enabled:program.enabled&&program.pointsEnabled&&program.checkIn.enabled,today:dayLabel(today),checkedInToday:!!todayCheckIn,streak:todayCheckIn?pointsBalance(todayCheckIn.streak):previousStreak,nextCycleDay:todayCheckIn?pointsBalance(todayCheckIn.cycle_day):nextCycleDay,nextPoints:program.checkIn.dailyPoints[(todayCheckIn?pointsBalance(todayCheckIn.cycle_day):nextCycleDay)-1]??0,dailyPoints:program.checkIn.dailyPoints,lastCheckIn:lastCheckIn?{date:dayLabel(Number(lastCheckIn.myt_day)),cycleDay:pointsBalance(lastCheckIn.cycle_day),streak:pointsBalance(lastCheckIn.streak),points:pointsBalance(lastCheckIn.points)}:null},verifiedProgress:{creditedDeposit:{source:'deposit_orders',status:'credited',amountMinor:creditedMinor.toString(),amountMYR:creditedMYR,orders:pointsBalance(depositRow?.orders)},referrals:{source:'referral_relationships+deposit_orders:credited',directCount,qualifiedCount}},missions,referralMilestones,couponWallet:{items:coupons,claimProcessing:false,redemption:false}};
}

function base(loaded:Awaited<ReturnType<typeof loadProgram>>){return {configured:loaded.configured,program:loaded.program,member:null,capabilities:capabilities(),claimProcessing:false,walletCredit:false,redemption:false};}
export async function getRewardsHub(db:D1Database,userId:string|null,at=Math.floor(Date.now()/1000)){const loaded=await loadProgram(db),response=base(loaded);return userId?{...response,member:await memberState(db,userId,loaded.program,at)}:response;}
export async function getAdminRewardsHub(db:D1Database){const loaded=await loadProgram(db),[checkIns,ledger]=await Promise.all([db.prepare('SELECT COUNT(*) count FROM rewards_checkins').first<{count:number|string}>(),db.prepare("SELECT COUNT(*) entries,COALESCE(SUM(points),0) points FROM rewards_points_ledger WHERE status='earned'").first<{entries:number|string;points:number|string}>()]);return {...base(loaded),updatedAt:loaded.updatedAt,updatedBy:loaded.updatedBy,storage:SETTING_ID,activity:{checkIns:pointsBalance(checkIns?.count),ledgerEntries:pointsBalance(ledger?.entries),issuedNonCashPoints:pointsBalance(ledger?.points)}};}

export async function saveRewardsHubProgram(db:D1Database,ownerId:string,input:unknown,at=Math.floor(Date.now()/1000)){
 const outer=record(input,'Rewards Hub request'),candidate=Object.hasOwn(outer,'program')?(()=>{exact(outer,['program'],'Rewards Hub request');return outer.program;})():outer,program=validateRewardsHubProgram(candidate),stored:StoredProgram={...program,updatedAt:at,updatedBy:ownerId};
 await db.batch([db.prepare('INSERT INTO settings(id,value) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind(SETTING_ID,JSON.stringify(stored)),db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),ownerId,'rewards_hub_updated',JSON.stringify({version:1,enabled:program.enabled,pointsEnabled:program.pointsEnabled,checkInEnabled:program.checkIn.enabled,coupons:program.coupons.length,milestones:program.referralMilestones.length}),at)]);
 return {...await getAdminRewardsHub(db),status:'ok'};
}

export async function checkInRewardsHub(db:D1Database,userId:string,at=Math.floor(Date.now()/1000)){
 const loaded=await loadProgram(db),program=loaded.program;if(!program.enabled)throw new RewardsHubError(409,'Rewards Hub is not active');if(!program.pointsEnabled||!program.checkIn.enabled)throw new RewardsHubError(409,'Daily check-in is not active');
 const today=mytDayStart(at),previous=await db.prepare('SELECT myt_day,streak FROM rewards_checkins WHERE user_id=? AND myt_day<? ORDER BY myt_day DESC LIMIT 1').bind(userId,today).first<{myt_day:number|string;streak:number|string}>(),streak=Number(previous?.myt_day)===today-DAY?pointsBalance(previous?.streak)+1:1,cycleDay=(streak-1)%7+1,points=program.checkIn.dailyPoints[cycleDay-1],checkInId=crypto.randomUUID();
 const created=await db.prepare('INSERT INTO rewards_checkins(id,user_id,myt_day,cycle_day,streak,points,created_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id,myt_day) DO NOTHING RETURNING id,myt_day,cycle_day,streak,points,created_at').bind(checkInId,userId,today,cycleDay,streak,points,at).first<any>(),saved=created??await db.prepare('SELECT id,myt_day,cycle_day,streak,points,created_at FROM rewards_checkins WHERE user_id=? AND myt_day=?').bind(userId,today).first<any>();
 if(!saved)throw new RewardsHubError(503,'Check-in could not be recorded');
 if(pointsBalance(saved.points)>0)await db.prepare("INSERT INTO rewards_points_ledger(id,user_id,source_type,source_id,points,status,cash_value_status,wallet_credit_status,redemption_status,created_at) VALUES(?,?,?,?,?,'earned','none','disabled','disabled',?) ON CONFLICT(source_type,source_id) DO NOTHING").bind(crypto.randomUUID(),userId,'checkin',saved.id,pointsBalance(saved.points),Number(saved.created_at)).run();
 if(created)await db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),userId,'rewards_checkin',`${dayLabel(today)}:${pointsBalance(saved.points)}`,at).run();
 return {status:'ok',idempotent:!created,date:dayLabel(today),cycleDay:pointsBalance(saved.cycle_day),streak:pointsBalance(saved.streak),points:pointsBalance(saved.points),cashValue:false,walletCredited:false,redemption:false,member:(await getRewardsHub(db,userId,at)).member};
}

export async function rewardsHubStatus(db:D1Database){const loaded=await loadProgram(db);return {configured:loaded.configured,enabled:loaded.program.enabled,pointsEnabled:loaded.program.pointsEnabled,checkInEnabled:loaded.program.checkIn.enabled};}
