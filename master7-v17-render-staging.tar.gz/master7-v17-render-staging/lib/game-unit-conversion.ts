/** Platform ledgers always store MYR sen. Supplier balances use the unit of the
 * particular account profile; a 1:100 account has 100 game points per MYR. */
export class GameUnitConversionError extends Error{readonly code='GAME_UNIT_CONVERSION_INVALID';constructor(){super('Invalid profile amount conversion');this.name='GameUnitConversionError';}}
const invalid=():never=>{throw new GameUnitConversionError();};
const maximum=9_223_372_036_854_775_807n;
function scale(value:unknown):bigint{if(value!==1&&value!==100)return invalid();return BigInt(value);}
function minor(value:unknown):bigint{if(typeof value!=='string'||!/^(0|[1-9]\d{0,18})$/.test(value))return invalid();const n=BigInt(value);if(n>maximum)return invalid();return n;}
export function walletMinorToGameAmount(amountMinor:string,gameUnitsPerMYR:1|100):string{
 const cents=minor(amountMinor)*scale(gameUnitsPerMYR);return `${cents/100n}.${String(cents%100n).padStart(2,'0')}`;
}
export function gameAmountToWalletMinor(raw:string,gameUnitsPerMYR:1|100){
 if(typeof raw!=='string')return invalid();const m=/^(0|[1-9]\d{0,18})(?:\.(\d{1,6}))?$/.exec(raw);if(!m)return invalid();
 const places=m[2]?.length??0,decimalScale=10n**BigInt(places),units=BigInt(m[1])*decimalScale+BigInt(m[2]??'0'),denominator=scale(gameUnitsPerMYR)*decimalScale,numerator=units*100n,whole=numerator/denominator,remainder=numerator%denominator;
 if(whole>maximum)return invalid();
 // A nonzero remainder is evidence for reconciliation, never rounded cash.
 return {amountMinor:whole.toString(),currency:'MYR' as const,residual:remainder!==0n,providerAmount:raw,gameUnitsPerMYR,residualMinorNumerator:remainder.toString(),residualMinorDenominator:denominator.toString()};
}
