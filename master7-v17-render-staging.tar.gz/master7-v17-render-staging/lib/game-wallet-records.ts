import {withdrawalWalletState} from './withdrawals.ts';
import type {RegisteredGameProviderProfile} from './game-provider-registry.ts';
import {genericGameWalletConsistencyForUsers} from './game-wallet-consistency.ts';

type SessionRow={id:string;profile_id:string;user_id:string;game_code:string;provider_game_id:string;status:string;created_at:number;updated_at:number;closed_at:number|null;reserved_minor:string|null;username?:string;display_name?:string};
type TransferRow={id:string;session_id:string;profile_id:string;user_id:string;direction:string;status:string;amount_minor:string;currency:string;provider_reference?:string;created_at:number;updated_at:number};
type AdminSessionRow=SessionRow&{transfer_id:string|null;transfer_direction:string|null;transfer_status:string|null;transfer_amount_minor:string|null;transfer_currency:string|null;transfer_provider_reference:string|null;transfer_created_at:number|null;transfer_updated_at:number|null};

const publicSession=(row:SessionRow|null)=>row?{
 id:row.id,profileId:row.profile_id,gameCode:row.game_code,providerGameId:row.provider_game_id,status:row.status,
 reservedMinor:row.reserved_minor===null?null:String(row.reserved_minor),createdAt:Number(row.created_at),updatedAt:Number(row.updated_at),closedAt:row.closed_at===null?null:Number(row.closed_at),
}:null;
const publicTransfer=(row:TransferRow)=>({id:row.id,direction:row.direction,status:row.status,amountMinor:String(row.amount_minor),currency:row.currency,createdAt:Number(row.created_at),updatedAt:Number(row.updated_at)});

/** Read existing records only. This does not enable or contact a supplier. */
export async function memberProfileGameWallet(db:D1Database,userId:string,profile:RegisteredGameProviderProfile){
 const session=await db.prepare(`SELECT s.id,s.profile_id,s.user_id,s.game_code,s.provider_game_id,s.status,s.created_at,s.updated_at,s.closed_at,CAST(r.amount_minor AS TEXT) reserved_minor
  FROM game_provider_sessions s LEFT JOIN wallet_reservations r ON r.user_id=s.user_id AND r.kind='game' AND r.reference_id=s.id
  WHERE s.user_id=? AND s.profile_id=? ORDER BY CASE WHEN r.reference_id IS NOT NULL THEN 0 WHEN s.status IN ('prepared','launching','active','settling','unknown','review') THEN 1 ELSE 2 END,s.updated_at DESC,s.id DESC LIMIT 1`).bind(userId,profile.profileId).first<SessionRow>();
 const transfers=session?await db.prepare(`SELECT id,session_id,profile_id,user_id,direction,status,CAST(amount_minor AS TEXT) amount_minor,currency,created_at,updated_at
  FROM game_wallet_transfers WHERE session_id=? AND profile_id=? AND user_id=? ORDER BY created_at DESC,id DESC LIMIT 20`).bind(session.id,profile.profileId,userId).all<TransferRow>():{results:[]};
 return {profileId:profile.profileId,providerId:profile.providerId,provider:profile.providerId,currency:profile.currency,walletMode:profile.walletMode,unitScale:profile.unitScale,gameUnitsPerMYR:profile.unitScale,
  wallet:await withdrawalWalletState(db,userId),session:publicSession(session),transfers:(transfers.results??[]).map(publicTransfer),
  launchReady:false,walletReady:false,liveReady:false,launchVerified:false,walletVerified:false,settlementVerified:false,
  supportsSettlement:false,supportsRecovery:false,readOnly:true,capabilityReason:profile.adapterStatus};
}

/** Staff can inspect queue records and unmatched holds without changing funds. */
export async function adminProfileGameWallets(db:D1Database){
 const sessions=await db.prepare(`SELECT s.id,s.profile_id,s.user_id,s.game_code,s.provider_game_id,s.status,s.created_at,s.updated_at,s.closed_at,
  CAST(r.amount_minor AS TEXT) reserved_minor,u.username,p.display_name,t.id transfer_id,t.direction transfer_direction,t.status transfer_status,
  CAST(t.amount_minor AS TEXT) transfer_amount_minor,t.currency transfer_currency,t.provider_reference transfer_provider_reference,t.created_at transfer_created_at,t.updated_at transfer_updated_at
  FROM game_provider_sessions s JOIN users u ON u.id=s.user_id JOIN game_provider_profiles p ON p.id=s.profile_id
  LEFT JOIN wallet_reservations r ON r.user_id=s.user_id AND r.kind='game' AND r.reference_id=s.id
  LEFT JOIN game_wallet_transfers t ON t.id=(SELECT t2.id FROM game_wallet_transfers t2 WHERE t2.session_id=s.id AND t2.profile_id=s.profile_id AND t2.user_id=s.user_id ORDER BY t2.updated_at DESC,t2.id DESC LIMIT 1)
  ORDER BY CASE WHEN r.reference_id IS NOT NULL THEN 0 WHEN s.status IN ('prepared','launching','active','settling','unknown','review') THEN 1 ELSE 2 END,s.updated_at DESC,s.id DESC LIMIT 500`).all<AdminSessionRow>();
 const unmatched=await db.prepare(`SELECT r.user_id,u.username,r.reference_id,CAST(r.amount_minor AS TEXT) amount_minor,r.created_at
  FROM wallet_reservations r JOIN users u ON u.id=r.user_id WHERE r.kind='game'
  AND NOT EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.id=r.reference_id AND s.user_id=r.user_id)
  AND NOT EXISTS (SELECT 1 FROM game_wallet_sessions g WHERE g.id=r.reference_id AND g.user_id=r.user_id)
  ORDER BY r.created_at DESC,r.reference_id DESC LIMIT 500`).all<{user_id:string;username:string;reference_id:string;amount_minor:string;created_at:number}>();
 const consistency=await genericGameWalletConsistencyForUsers(db,(sessions.results??[]).map(row=>row.user_id));
 return {
  profileItems:(sessions.results??[]).map(row=>({...publicSession(row),userId:row.user_id,username:row.username,displayName:row.display_name,consistency:consistency.get(row.user_id),
   lastTransfer:row.transfer_id?{id:row.transfer_id,direction:row.transfer_direction,status:row.transfer_status,amountMinor:String(row.transfer_amount_minor),currency:row.transfer_currency,providerReference:row.transfer_provider_reference,createdAt:Number(row.transfer_created_at),updatedAt:Number(row.transfer_updated_at)}:null})),
  unmatchedReservations:(unmatched.results??[]).map(row=>({userId:row.user_id,username:row.username,referenceId:row.reference_id,amountMinor:String(row.amount_minor),createdAt:Number(row.created_at)})),
  readOnly:true,
 };
}
