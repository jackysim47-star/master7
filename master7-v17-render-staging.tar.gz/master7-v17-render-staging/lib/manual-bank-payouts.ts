import {decryptWithdrawalValue,withdrawalDataKeyReady} from './withdrawal-secrets.ts';
import {walletGuardStatements,walletRiskFreeSql,walletAvailableSql} from './wallet-guard.ts';
import {approvalFingerprint,approvalQuery,withdrawalWalletState} from './withdrawals.ts';
import {bankAccountKey,bankEvidence,manualPayoutEvidenceSql} from './manual-bank-evidence.ts';
import {manualBankAvailability} from './manual-bank.ts';
import {malaysiaEwallet,malaysiaMemberPhone} from './malaysia-ewallets.ts';

type User={id:string;username:string;role:string;approved:number};
type Ctx={db:D1Database;user:User|null;dataKey?:string;newDepositsEnabled?:string;newPayoutsEnabled?:string};
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});
const ident=(x:unknown)=>typeof x==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(x)?x:null;
const changed=(x:any)=>Number(x?.meta?.changes??x?.changes??0);
const now=()=>Math.floor(Date.now()/1000);
function owner(c:Ctx){return !c.user?json({error:'Sign in required'},401):c.user.role!=='owner'||c.user.approved!==1?json({error:'Access denied'},403):!withdrawalDataKeyReady(c.dataKey)?json({error:'Withdrawal security not configured'},503):null;}
async function payout(c:Ctx,id:string){return c.db.prepare(approvalQuery+" WHERE w.id=? AND w.provider_id='manual_bank'").bind(id).first<any>();}
function recipient(x:any,key?:string){
 const accountHolder=decryptWithdrawalValue(x.account_holder_encrypted,key);if(accountHolder.length<2)throw Error('Invalid recipient');
 if(x.destination_type==='ewallet'){
  const wallet=malaysiaEwallet(x.ewallet_code),accountIdentifier=decryptWithdrawalValue(x.ewallet_account_encrypted,key),phone=malaysiaMemberPhone(accountIdentifier);
  if(!wallet||!phone||phone.slice(-4)!==x.ewallet_account_last4)throw Error('Invalid recipient');
  return {destinationType:'ewallet',ewalletCode:wallet[0],ewalletName:wallet[1],accountHolder,accountIdentifier:phone};
 }
 const accountNumber=decryptWithdrawalValue(x.account_number_encrypted,key);
 if(!/^\d{6,20}$/.test(accountNumber)||accountNumber.slice(-4)!==x.account_last4)throw Error('Invalid recipient');
 return {destinationType:'bank',bankCode:x.bank_code,bankName:x.bank_name,accountHolder,accountNumber};
}
async function paid(c:Ctx,x:any){
 const row=await c.db.prepare(`SELECT p.id FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id WHERE w.id=? AND w.status='paid' AND p.status='succeeded' AND p.create_outcome='accepted' AND p.amount_minor=w.amount_minor AND p.currency=w.currency AND p.request_key=w.request_key AND COALESCE(p.last_error_code,'')='' AND ${manualPayoutEvidenceSql} AND NOT EXISTS(SELECT 1 FROM wallet_reservations r WHERE r.reference_id=w.id)`).bind(x.id).first();
 return !!row&&!(await withdrawalWalletState(c.db,x.user_id)).reconciliationRequired;
}
export async function manualBankPayoutGet(req:Request,c:Ctx){
 if(new URL(req.url).pathname!=='/api/admin/manual-bank/payout')return null;
 const denied=owner(c);if(denied)return denied;const id=ident(new URL(req.url).searchParams.get('id'));if(!id)return json({error:'Invalid withdrawal'},400);
 const x=await payout(c,id);if(!x)return json({error:'Withdrawal not found'},404);
 if(!['approved','processing'].includes(x.status))return json({error:'Recipient is available only for an approved transfer'},409);
 try{const details=recipient(x,c.dataKey);await c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,'manual_bank_recipient_viewed',?,?)").bind(crypto.randomUUID(),c.user!.id,x.id,now()).run();return json({withdrawalId:x.id,payoutId:x.payout_id,status:x.status,payoutStatus:x.payout_status,amountMinor:String(x.amount_minor),currency:x.currency,companyBankId:x.manual_bank_account_id??null,recipient:details,warning:'Check this payout ID before transferring. Refreshing this page never authorizes a second bank transfer.'});}catch{return json({error:'Withdrawal recipient unavailable'},409);}
}
export async function manualBankPayoutPost(path:string,d:Record<string,unknown>,c:Ctx){
 if(!['/api/admin/manual-bank/payout/start','/api/admin/manual-bank/payout/confirm','/api/admin/manual-bank/payout/unknown'].includes(path))return null;
 const denied=owner(c);if(denied)return denied;const id=ident(d.id);if(!id)return json({error:'Invalid withdrawal'},400);
 const x=await payout(c,id);if(!x)return json({error:'Withdrawal not found'},404);
 const at=now(),actor=c.user!.id;
 if(path.endsWith('/start')){
  const availability=await manualBankAvailability({...c,user:{...c.user!,id:x.user_id}});
  if(!availability.payoutEnabled)return json({error:'New manual bank transfers are temporarily unavailable',code:'PAYOUTS_MAINTENANCE'},503);
  const bankId=typeof d.bankAccountId==='string'&&/^[A-Za-z0-9_-]{1,100}$/.test(d.bankAccountId)?d.bankAccountId:null;if(!bankId)return json({error:'Choose the company bank used to pay'},400);
  if(x.status==='processing'&&x.payout_status==='processing'){
   const row=await c.db.prepare('SELECT manual_bank_account_id FROM provider_payouts WHERE id=?').bind(x.payout_id).first<any>();
   if(row?.manual_bank_account_id!==bankId)return json({error:'This payout is already assigned to another company bank'},409);
   return json({status:'processing',idempotent:true,withdrawalId:id,payoutId:x.payout_id,recipient:recipient(x,c.dataKey)},200);
  }
  if(x.status!=='approved'||x.payout_status!=='prepared'||x.payout_outcome!=='not_submitted')return json({error:'Approve this withdrawal before starting a bank transfer'},409);
  let details;try{details=recipient(x,c.dataKey);}catch{return json({error:'Recipient data invalid'},409);}
  const fingerprint=approvalFingerprint(x),authorization=crypto.randomUUID(),startId=`manual_bank_payout_started_${x.payout_id}`;
  const result=await c.db.batch([
   ...walletGuardStatements(c.db,x.user_id),
   c.db.prepare("UPDATE users SET approved=approved WHERE id=? AND role='owner' AND approved=1").bind(actor),
   c.db.prepare("UPDATE manual_compliance_reviews SET last_authorization_id=? WHERE user_id=? AND identity_status='passed' AND aml_status='passed' AND version=?").bind(authorization,x.user_id,x.compliance_version),
   c.db.prepare('UPDATE company_bank_accounts SET updated_at=updated_at WHERE id=? AND enabled=1 AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=company_bank_accounts.id)').bind(bankId),
   c.db.prepare(`UPDATE provider_payouts SET status='processing',create_outcome='in_flight',manual_bank_account_id=?,last_error_code='manual_bank_transfer_pending',last_event_hash=?,updated_at=? WHERE id=? AND provider_id='manual_bank' AND status='prepared' AND create_outcome='not_submitted' AND provider_reference IS NULL
    AND EXISTS(SELECT 1 FROM users reviewer WHERE reviewer.id=? AND reviewer.role='owner' AND reviewer.approved=1)
    AND EXISTS(SELECT 1 FROM company_bank_accounts b WHERE b.id=? AND b.enabled=1 AND NOT EXISTS(SELECT 1 FROM company_bank_accounts n WHERE n.supersedes_id=b.id))
    AND EXISTS(SELECT 1 FROM manual_compliance_reviews c WHERE c.user_id=? AND c.version=? AND c.identity_status='passed' AND c.aml_status='passed' AND c.last_authorization_id=?)
    AND EXISTS(SELECT 1 FROM users m WHERE m.id=? AND m.role='member' AND m.approved=1 AND ${walletRiskFreeSql} AND ${walletAvailableSql}>=0)
    AND EXISTS(SELECT 1 FROM withdrawal_requests w JOIN wallet_reservations r ON r.reference_id=w.id AND r.kind='withdrawal' AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor WHERE w.id=provider_payouts.withdrawal_id AND w.id=? AND w.user_id=? AND w.status='approved' AND w.amount_minor=provider_payouts.amount_minor AND w.provider_id=provider_payouts.provider_id AND w.request_key=provider_payouts.request_key AND w.currency=provider_payouts.currency AND w.destination_type=? AND w.account_holder_encrypted=? AND w.account_number_encrypted=? AND COALESCE(w.ewallet_code,'')=COALESCE(?,'') AND COALESCE(w.ewallet_account_encrypted,'')=COALESCE(?,'') )
    AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.event='withdrawal_approved_v1' AND a.target=provider_payouts.withdrawal_id)
    AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.event='withdrawal_approval_binding_v1' AND a.target=provider_payouts.withdrawal_id)`)
    .bind(bankId,authorization,at,x.payout_id,actor,bankId,x.user_id,x.compliance_version,authorization,x.user_id,id,x.user_id,x.destination_type??'bank',x.account_holder_encrypted,x.account_number_encrypted,x.ewallet_code,x.ewallet_account_encrypted,`withdrawal_approved_v1_${id}`,`withdrawal_approval_binding_v1_${id}_${fingerprint}`),
   c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status='approved' AND EXISTS(SELECT 1 FROM provider_payouts p WHERE p.withdrawal_id=withdrawal_requests.id AND p.status='processing' AND p.last_event_hash=?)").bind(at,id,authorization),
   c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'manual_bank_payout_started',?,? FROM provider_payouts p WHERE p.id=? AND p.status='processing' AND p.last_event_hash=? ON CONFLICT(id) DO NOTHING").bind(startId,actor,id,at,x.payout_id,authorization),
  ]);
  if(result.slice(2).some(r=>changed(r)!==1))return json({error:'Withdrawal changed or needs reconciliation; refresh'},409);
  return json({status:'processing',withdrawalId:id,payoutId:x.payout_id,companyBankId:bankId,recipient:details},202);
 }
 if(path.endsWith('/unknown')){
  const marker=crypto.randomUUID(),result=await c.db.batch([...walletGuardStatements(c.db,x.user_id),c.db.prepare("UPDATE provider_payouts SET status='review',create_outcome='unknown',last_error_code='manual_bank_outcome_unknown',last_event_hash=?,updated_at=? WHERE id=? AND provider_id='manual_bank' AND status='processing' AND create_outcome='in_flight' AND EXISTS(SELECT 1 FROM withdrawal_requests w JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor WHERE w.id=provider_payouts.withdrawal_id AND w.status='processing' AND r.kind='withdrawal')").bind(marker,at,x.payout_id),c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'manual_bank_payout_unknown',?,? WHERE EXISTS(SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.last_event_hash=? AND p.status='review')").bind(crypto.randomUUID(),actor,id,at,x.payout_id,marker)]);
  return changed(result[2])===1?json({status:'review',fundsHeld:true}):json({error:'Payout changed; refresh'},409);
 }
 const evidence=bankEvidence(d,at);if(!evidence)return json({error:'Bank transfer confirmation, MYR amount, time, reference and proof image are required'},400);
 const bank=await c.db.prepare('SELECT b.*,p.manual_bank_account_id FROM provider_payouts p JOIN company_bank_accounts b ON b.id=p.manual_bank_account_id WHERE p.id=?').bind(x.payout_id).first<any>();
 if(!bank||d.bankAccountId!==bank.id||evidence.amount!==String(x.amount_minor))return json({error:'Bank account or amount does not match this payout'},409);
 if(x.status==='paid'){
  const old=await c.db.prepare('SELECT * FROM manual_bank_transactions WHERE payout_id=?').bind(x.payout_id).first<any>();
  return old?.normalized_reference===evidence.reference.normalized&&old.proof_sha256===evidence.hash&&Number(old.bank_occurred_at)===evidence.occurred&&await paid(c,x)?json({status:'paid',idempotent:true,bankTransactionId:old.id}):json({error:'Payout confirmation conflict'},409);
 }
 if(x.status!=='processing'||!['processing','review'].includes(x.payout_status))return json({error:'Start this bank transfer before confirming payment'},409);
 const proofId=crypto.randomUUID(),decision=crypto.randomUUID(),paidAudit=`manual_bank_payout_paid_${x.payout_id}`;
 const result=await c.db.batch([
  ...walletGuardStatements(c.db,x.user_id),
  c.db.prepare("UPDATE provider_payouts SET updated_at=updated_at WHERE id=? AND provider_id='manual_bank' AND status IN ('processing','review')").bind(x.payout_id),
  c.db.prepare(`INSERT INTO manual_bank_transactions(id,bank_account_id,bank_account_key,bank_reference,normalized_reference,direction,amount_minor,currency,payout_id,proof_data,proof_sha256,bank_occurred_at,recorded_by,recorded_at)
   SELECT ?,p.manual_bank_account_id,?,?,?,'withdrawal',p.amount_minor,p.currency,p.id,?,?,?,?,? FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor AND r.kind='withdrawal'
   WHERE p.id=? AND p.provider_id='manual_bank' AND p.status IN ('processing','review') AND p.create_outcome IN ('in_flight','unknown') AND w.status='processing' AND p.provider_id=w.provider_id AND p.amount_minor=w.amount_minor AND p.currency=w.currency AND p.request_key=w.request_key AND p.manual_bank_account_id=?
   AND EXISTS(SELECT 1 FROM audit a WHERE a.id=? AND a.event='manual_bank_payout_started' AND a.target=w.id) ON CONFLICT DO NOTHING`)
   .bind(proofId,bankAccountKey(bank.account_number),evidence.reference.original,evidence.reference.normalized,evidence.proof,evidence.hash,evidence.occurred,actor,at,x.payout_id,bank.id,`manual_bank_payout_started_${x.payout_id}`),
  c.db.prepare("UPDATE provider_payouts SET status='succeeded',create_outcome='accepted',provider_reference=?,last_event_hash=?,last_error_code=NULL,updated_at=?,completed_at=? WHERE id=? AND status IN ('processing','review') AND EXISTS(SELECT 1 FROM manual_bank_transactions b WHERE b.id=? AND b.payout_id=provider_payouts.id AND b.bank_account_id=provider_payouts.manual_bank_account_id AND b.amount_minor=provider_payouts.amount_minor AND b.currency=provider_payouts.currency)").bind(proofId,evidence.hash,at,at,x.payout_id,proofId),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'manual_bank_payout_paid',?,? WHERE EXISTS(SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.status='succeeded' AND p.provider_reference=?) ON CONFLICT(id) DO NOTHING").bind(paidAudit,actor,proofId,at,x.payout_id,proofId),
  c.db.prepare(`UPDATE withdrawal_requests SET status='paid',updated_at=?,updated_by=? WHERE id=? AND status='processing' AND EXISTS(SELECT 1 FROM provider_payouts p WHERE p.withdrawal_id=withdrawal_requests.id AND p.status='succeeded' AND p.create_outcome='accepted' AND p.provider_reference=? AND ${manualPayoutEvidenceSql})`).bind(at,actor,id,proofId),
  c.db.prepare(`DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=? AND user_id=? AND amount_minor=CAST(? AS BIGINT) AND EXISTS(SELECT 1 FROM withdrawal_requests w JOIN provider_payouts p ON p.withdrawal_id=w.id WHERE w.id=wallet_reservations.reference_id AND w.status='paid' AND p.provider_reference=? AND ${manualPayoutEvidenceSql})`).bind(id,x.user_id,String(x.amount_minor),proofId),
  // A duplicate reference or inconsistent evidence cannot release a hold.
  c.db.prepare("UPDATE provider_payouts SET status='review',create_outcome='unknown',last_error_code='manual_bank_evidence_conflict',updated_at=? WHERE id=? AND status IN ('processing','review') AND NOT EXISTS(SELECT 1 FROM manual_bank_transactions b WHERE b.id=? AND b.payout_id=provider_payouts.id)").bind(at,x.payout_id,proofId),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'manual_bank_payout_review',?,? WHERE EXISTS(SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.status='review')").bind(decision,actor,id,at,x.payout_id)
 ]);
 if(changed(result[3])!==1||changed(result[4])!==1||changed(result[6])!==1||changed(result[7])!==1){
  // A concurrent identical confirmation may have committed while this request
  // waited on the member lock. Report that committed outcome without reposting.
  const prior=await c.db.prepare('SELECT id,normalized_reference,proof_sha256,bank_occurred_at FROM manual_bank_transactions WHERE payout_id=?').bind(x.payout_id).first<any>();
  if(prior?.normalized_reference===evidence.reference.normalized&&prior.proof_sha256===evidence.hash&&Number(prior.bank_occurred_at)===evidence.occurred&&await paid(c,x))return json({status:'paid',idempotent:true,bankTransactionId:prior.id});
  return json({error:'Bank evidence conflicts or payout needs reconciliation',status:'review',fundsHeld:true},409);
 }
 if(!await paid(c,x))return json({error:'Wallet reconciliation is required',status:'review'},409);
 return json({status:'paid',bankTransactionId:proofId,wallet:await withdrawalWalletState(c.db,x.user_id)});
}
