import { PAYMENT_RECOVERY_MAX_ATTEMPTS } from './payment-recovery.ts';

/** Owner-only callers may inspect stored evidence. No provider or ledger writes. */
type OrderRow={id:string;user_id:string;username:string|null;provider:string;amount_minor:string;currency:string;status:string;provider_trade_no:string|null;checkout_recorded:number|string;created_at:number;updated_at:number};
type LedgerRow={id:string;user_id:string;account_code:string;amount_minor:string;currency:string;created_at:number};
type AuditRow={event:string;target:string;created_at:number};
type LeaseRow={attempts:number;last_checked_at:number};
type FinalOrderState={status:string;updated_at:number;provider_trade_no:string|null};

const directEvents=[
 'deposit_callback_review','deposit_credited','vpay_deposit_failed','deposit_query_binding_review',
 'deposit_ledger_review','deposit_member_binding_review','vpay_deposit_reversed_review',
 'vpay_deposit_risk_control_review','vpay_post_credit_failed_review','vpay_deposit_state_review','gspay_deposit_credited',
 'gspay_late_success_review','gspay_member_binding_review','1mpay_deposit_credited',
 'manual_bank_deposit_submitted','manual_bank_deposit_rejected','manual_bank_deposit_approved',
 'payment_recovery_manual_review',
];
const allowedKinds=new Set(['GATEWAY_HTTP','GATEWAY_RESPONSE','PROVIDER_HTTP','INVALID_JSON','ORDER_RESPONSE','TIMEOUT','REQUEST_UNCONFIRMED']);
const allowedErrors=new Set(['unauthorized','vpay_orders_disabled','invalid_vpay_order','vpay_payment_configuration_incomplete','upstream_timeout','internal_error']);
const allowedReasons=new Set(['query_binding_mismatch','provider_reference_missing']);
const integer=(value:unknown,min:number,max:number)=>typeof value==='number'&&Number.isInteger(value)&&value>=min&&value<=max?value:null;

function diagnostic(row:AuditRow,order:OrderRow){
 let value:unknown;try{value=JSON.parse(row.target);}catch{return null;}
 if(!value||typeof value!=='object'||Array.isArray(value))return null;
 const data=value as Record<string,unknown>;
 if(data.orderId!==order.id)return null;
 if(row.event==='payment_order_diagnostic'){
  if(data.provider!==order.provider)return null;
  const kind=typeof data.kind==='string'&&allowedKinds.has(data.kind)?data.kind:'UNAVAILABLE';
  const httpStatus=integer(data.httpStatus,100,599),upstreamStatus=integer(data.upstreamStatus,100,599),providerCode=integer(data.providerCode,-999999,999999);
  return {event:row.event,createdAt:Number(row.created_at),kind,httpStatus,upstreamStatus,providerCode,gatewayError:typeof data.gatewayError==='string'&&allowedErrors.has(data.gatewayError)?data.gatewayError:null};
 }
 if(row.event==='1mpay_recovery_review'&&order.provider==='1mpay'){
  return {event:row.event,createdAt:Number(row.created_at),reason:typeof data.reason==='string'&&allowedReasons.has(data.reason)?data.reason:'unavailable'};
 }
 return null;
}

export async function readDepositTrace(db:D1Database,orderId:string){
 const order=await db.prepare(`SELECT d.id,d.user_id,u.username,d.provider,CAST(d.amount_minor AS TEXT) amount_minor,d.currency,d.status,d.provider_trade_no,
 CASE WHEN d.checkout_url IS NULL OR d.checkout_url='' THEN 0 ELSE 1 END checkout_recorded,d.created_at,d.updated_at
 FROM deposit_orders d LEFT JOIN users u ON u.id=d.user_id WHERE d.id=?`).bind(orderId).first<OrderRow>();
 if(!order)return null;
 const [ledgerResult,auditResult,diagnosticResult,lease]=await Promise.all([
  db.prepare('SELECT id,user_id,account_code,CAST(amount_minor AS TEXT) amount_minor,currency,created_at FROM wallet_ledger WHERE order_id=? ORDER BY created_at,id LIMIT 11').bind(order.id).all<LedgerRow>(),
  db.prepare(`SELECT event,target,created_at FROM audit WHERE target=? AND event IN (${directEvents.map(()=>'?').join(',')}) ORDER BY created_at DESC,id DESC LIMIT 101`).bind(order.id,...directEvents).all<AuditRow>(),
  db.prepare("SELECT event,target,created_at FROM audit WHERE user_id=? AND event IN ('payment_order_diagnostic','1mpay_recovery_review') AND target LIKE ? ORDER BY created_at DESC,id DESC LIMIT 101").bind(order.user_id,`%${order.id}%`).all<AuditRow>(),
  ['vpay','gspay'].includes(order.provider)?db.prepare('SELECT attempts,last_checked_at FROM payment_recovery_leases WHERE provider=? AND order_id=?').bind(order.provider,order.id).first<LeaseRow>():Promise.resolve(null),
 ]);
 const ledger=ledgerResult.results??[],entries=ledger.slice(0,10),member=ledger.find(row=>row.account_code==='member'),clearing=ledger.find(row=>row.account_code==='provider_clearing');
 let balanced=false;
 try{balanced=ledger.length===2&&ledger.every(row=>row.user_id===order.user_id&&row.currency===order.currency)
  &&String(member?.amount_minor)===String(order.amount_minor)&&BigInt(clearing?.amount_minor??0)===-BigInt(order.amount_minor);}catch{balanced=false;}
 const ledgerStatus=ledger.length===0?'no_entries':balanced?'balanced':'mismatch';
 const records=(auditResult.results??[]).slice(0,100).map(row=>({event:row.event,createdAt:Number(row.created_at)}));
 const diagnostics=(diagnosticResult.results??[]).slice(0,100).map(row=>diagnostic(row,order)).filter(item=>item!==null);
 const callback=order.provider==='manual_bank'?'not_applicable':records.some(row=>row.event==='deposit_callback_review')?'review_recorded':'unknown';
 // Statements may use separate connections: do not label an in-flight change as
 // an accounting mismatch when the order changed while evidence was read.
 const finalOrder=await db.prepare('SELECT status,updated_at,provider_trade_no FROM deposit_orders WHERE id=?').bind(order.id).first<FinalOrderState>();
 const snapshotConsistent=!!finalOrder&&finalOrder.status===order.status&&Number(finalOrder.updated_at)===Number(order.updated_at)&&finalOrder.provider_trade_no===order.provider_trade_no;
 const reviewRequired=snapshotConsistent?((order.status==='credited'&&!balanced)||(order.status!=='credited'&&ledger.length>0)||order.status==='review'):null;
 return {
  readOnly:true,snapshotConsistent,order:{id:order.id,userId:order.user_id,username:order.username,provider:order.provider,amountMinor:String(order.amount_minor),currency:order.currency,status:order.status,providerTradeNo:order.provider_trade_no,checkoutRecorded:Number(order.checkout_recorded)===1,createdAt:Number(order.created_at),updatedAt:Number(order.updated_at)},
  providerPayment:'unverified',callback:{status:callback,completeHistory:false},
  ledger:{status:ledgerStatus,reviewRequired,truncated:ledger.length>10,entries:entries.map(row=>({id:row.id,accountCode:row.account_code,amountMinor:String(row.amount_minor),currency:row.currency,memberMatches:row.user_id===order.user_id,createdAt:Number(row.created_at)}))},
  audit:{records,diagnostics,truncated:(auditResult.results??[]).length>100||(diagnosticResult.results??[]).length>100},
  recovery:!['vpay','gspay'].includes(order.provider)?{status:'not_in_lease_table'}:lease?{status:Number(lease.attempts)>=PAYMENT_RECOVERY_MAX_ATTEMPTS?'manual_review':'recorded',attempts:Number(lease.attempts),lastCheckedAt:Number(lease.last_checked_at)||null}:{status:'not_recorded'},
 };
}
