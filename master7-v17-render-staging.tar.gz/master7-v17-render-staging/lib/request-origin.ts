/** Validate browser mutation origins against an explicit trusted host list.
 * Render terminates TLS at its edge, so the server-side Request URL may use an
 * internal host. Never derive trust from forwarded headers supplied by callers.
 */
export function requestOriginAllowed(req: Request, allowedOrigins?: string[]) {
  const origin = req.headers.get('origin');
  if (!origin) return false;
  try {
    const parsed = new URL(origin);
    if (parsed.origin !== origin || parsed.protocol !== 'https:' || parsed.username || parsed.password) return false;
    const trusted = allowedOrigins?.length ? allowedOrigins : [new URL(req.url).origin];
    return trusted.includes(origin);
  } catch {
    return false;
  }
}
