type FieldKind='string'|'string_list'|'nonnegative_integer'|'sha256'|'ratio';
export type ProviderContractRequirement=Readonly<{field:string;kind:FieldKind;purpose:string;expected?:readonly string[]}>;
const field=(name:string,kind:FieldKind,purpose:string,expected?:readonly string[]):ProviderContractRequirement=>Object.freeze({field:name,kind,purpose,...(expected?{expected}:{})});

/**
 * Minimum evidence needed before implementing a supplier-specific adapter.
 * This list intentionally describes documents and protocol behavior, never
 * credential values or mutable runtime configuration.
 */
export const GENERIC_PROVIDER_REQUIRED_CONTRACT_FIELDS:readonly ProviderContractRequirement[]=Object.freeze([
 field('document.document_id','string','Identify the authoritative supplier document.'),
 field('document.api_version','string','Bind the contract to an exact API version.'),
 field('document.environment','string','Identify UAT or production scope.',['uat','production']),
 field('document.merchant_scope','string','Identify the merchant scope.'),
 field('document.base_urls','string_list','List authoritative API bases.'),
 field('document.operation_names','string_list','List official operation names.'),
 field('document.sha256','sha256','Bind review to immutable document bytes.'),

 field('network.outbound_ip_allowlist_rule','string','Define portal egress allowlisting.'),
 field('network.callback_source_ips','string_list','List trusted callback sources.'),
 field('network.tls_rule','string','Define TLS and certificate requirements.'),
 field('authentication.scheme','string','Define authentication scheme.'),
 field('authentication.credential_fields','string_list','Name credential fields without values.'),
 field('authentication.signature_algorithm','string','Define signature or MAC algorithm.'),
 field('authentication.canonical_request_rule','string','Define field ordering and encoding.'),
 field('authentication.signed_fields','string_list','List signed fields.'),
 field('authentication.timestamp_rule','string','Define timestamp and clock skew.'),
 field('authentication.nonce_or_replay_rule','string','Define replay protection.'),
 field('authentication.test_vectors','string_list','Provide non-secret official test vectors.'),

 field('catalogue.endpoint','string','Define catalogue endpoint.'),
 field('catalogue.method','string','Define catalogue HTTP method.'),
 field('catalogue.required_fields','string_list','List catalogue request fields.'),
 field('catalogue.game_id_field','string','Identify immutable game ID.'),
 field('catalogue.category_field','string','Identify game category.'),
 field('catalogue.availability_field','string','Identify game availability.'),
 field('catalogue.pagination_rule','string','Define complete catalogue pagination.'),

 field('player.create.endpoint','string','Define player creation endpoint.'),
 field('player.create.method','string','Define player creation HTTP method.'),
 field('player.create.required_fields','string_list','List player creation fields.'),
 field('player.create.idempotency_rule','string','Define duplicate creation behavior.'),
 field('player.lookup.endpoint','string','Define player lookup endpoint.'),
 field('player.lookup.method','string','Define player lookup HTTP method.'),
 field('player.namespace_rule','string','Define player namespace isolation.'),

 field('launch.endpoint','string','Define launch endpoint.'),
 field('launch.method','string','Define launch HTTP method.'),
 field('launch.required_fields','string_list','List launch fields.'),
 field('launch.game_id_field','string','Identify launch game ID.'),
 field('launch.url_field','string','Identify successful launch URL.'),
 field('launch.session_id_field','string','Identify supplier session ID.'),
 field('launch.url_ttl_rule','string','Define launch token or URL lifetime.'),
 field('launch.return_url_rule','string','Define return-to-lobby behavior.'),
 field('launch.success_codes','string_list','List successful launch results.'),
 field('launch.error_codes','string_list','List launch errors.'),

 field('wallet.mode','string','Confirm transfer or seamless wallet mode.',['transfer','seamless']),
 field('wallet.balance.endpoint','string','Define balance endpoint.'),
 field('wallet.balance.method','string','Define balance HTTP method.'),
 field('wallet.balance.amount_field','string','Identify balance amount.'),
 field('wallet.balance.currency_field','string','Identify balance currency.'),
 field('wallet.funds_flow.operations','string_list','List transfer or seamless operations.'),
 field('wallet.funds_flow.required_fields','string_list','List fields for every wallet operation.'),
 field('wallet.funds_flow.transaction_id_field','string','Identify immutable transaction ID.'),
 field('wallet.funds_flow.idempotency_field','string','Identify idempotency key.'),
 field('wallet.funds_flow.duplicate_rule','string','Define duplicate behavior.'),
 field('wallet.funds_flow.success_codes','string_list','List successful wallet results.'),
 field('wallet.funds_flow.error_codes','string_list','List wallet errors.'),
 field('wallet.transaction_query.endpoint','string','Define transaction query endpoint.'),
 field('wallet.transaction_query.method','string','Define transaction query HTTP method.'),
 field('wallet.transaction_query.binding_fields','string_list','Bind player, amount, currency, direction and IDs.'),
 field('wallet.transaction_query.pending_statuses','string_list','List non-terminal statuses.'),
 field('wallet.transaction_query.terminal_success_statuses','string_list','List successful terminal statuses.'),
 field('wallet.transaction_query.terminal_failure_statuses','string_list','List failed terminal statuses.'),
 field('wallet.transaction_query.not_found_rule','string','Define transaction-not-found behavior.'),
 field('wallet.transaction_query.late_success_rule','string','Define late success after timeout.'),

 field('reports.endpoint','string','Define bet and round report endpoint.'),
 field('reports.method','string','Define report HTTP method.'),
 field('reports.required_fields','string_list','List report fields.'),
 field('reports.round_id_field','string','Identify immutable round ID.'),
 field('reports.bet_id_field','string','Identify immutable bet ID.'),
 field('reports.transaction_id_field','string','Identify immutable result transaction ID.'),
 field('reports.amount_fields','string_list','Identify bet, win, refund and adjustment amounts.'),
 field('reports.currency_field','string','Identify report currency.'),
 field('reports.finality_rule','string','Define result finality.'),
 field('reports.pagination_rule','string','Define stable report pagination.'),
 field('callbacks.signature_rule','string','Define callback signature validation.'),
 field('callbacks.source_ip_rule','string','Define callback source IP validation.'),
 field('callbacks.deduplication_field','string','Identify callback deduplication key.'),
 field('callbacks.retry_policy','string','Define callback retries.'),
 field('callbacks.ack_schema','string','Define callback acknowledgement.'),

 field('session.exit.endpoint','string','Define explicit session exit endpoint.'),
 field('session.exit.method','string','Define exit HTTP method.'),
 field('session.kick.endpoint','string','Define forced logout endpoint.'),
 field('session.kick.method','string','Define forced logout HTTP method.'),
 field('session.offline_status.endpoint','string','Define online-status endpoint.'),
 field('session.unfinished_rounds.endpoint','string','Define unfinished-round endpoint.'),
 field('session.issued_token_invalidation_rule','string','Define launch-token invalidation.'),
 field('session.late_result_finality_rule','string','Define when late results can no longer arrive.'),

 field('settlement.reversal_rule','string','Define refund, void and cancellation.'),
 field('settlement.reconciliation_fields','string_list','List provider reconciliation keys.'),
 field('recovery.timeout_rule','string','Define ambiguous timeout handling.'),
 field('recovery.retry_policy','string','Define bounded safe retries.'),
 field('recovery.polling_policy','string','Define status and session recovery polling.'),
 field('maintenance.status_endpoint','string','Define maintenance endpoint.'),
 field('maintenance.behavior','string','Define fail-closed maintenance behavior.'),
 field('limits.request_rate_rule','string','Define request and concurrency limits.'),
 field('limits.amount_bounds_rule','string','Define wallet amount bounds.'),
 field('acceptance.uat_account_scope','string','Identify authorized UAT account scope.'),
 field('acceptance.uat_test_cases','string_list','List supplier-approved UAT cases.'),

 field('profile.profile_id','string','Bind evidence to one portal profile.'),
 field('profile.provider_id','string','Bind evidence to one supplier.'),
 field('profile.provider_account_scope','string','Identify supplier account scope without secrets.'),
 field('profile.provider_currency','string','Confirm provider currency.'),
 field('profile.settlement_currency','string','Confirm settlement currency.'),
 field('profile.amount_unit','string','Define major, minor or point units.'),
 field('profile.amount_precision','nonnegative_integer','Define decimal precision.'),
 field('profile.conversion_ratio','ratio','Define provider units to MYR conversion.'),
 field('profile.rounding_rule','string','Define rounding and residual handling.'),
 field('profile.game_scope','string_list','Identify authorized games.'),
]);

function validIdentifier(value:string){return /^[a-z0-9][a-z0-9_-]{0,99}$/.test(value);}
function readPath(input:unknown,path:string):unknown{let current=input;for(const segment of path.split('.')){if(!current||typeof current!=='object'||Array.isArray(current))return undefined;current=(current as Record<string,unknown>)[segment];}return current;}
function validateValue(value:unknown,requirement:ProviderContractRequirement,expected?:readonly string[]):string|null{
 if(requirement.kind==='string'){
  if(typeof value!=='string'||!value.trim()||value.length>2000||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value))return 'invalid_string';
  const allowed=expected??requirement.expected;return allowed&&!allowed.includes(value.trim())?'unexpected_value':null;
 }
 if(requirement.kind==='string_list')return !Array.isArray(value)||value.length===0||value.length>100||value.some(item=>typeof item!=='string'||!item.trim()||item.length>256)?'invalid_string_list':null;
 if(requirement.kind==='nonnegative_integer')return Number.isSafeInteger(value)&&Number(value)>=0?null:'invalid_nonnegative_integer';
 if(requirement.kind==='sha256')return typeof value==='string'&&/^[a-f0-9]{64}$/.test(value)?null:'invalid_sha256';
 if(requirement.kind==='ratio')return typeof value==='string'&&/^[1-9]\d{0,8}:[1-9]\d{0,8}$/.test(value)?null:'invalid_ratio';
 return 'invalid_value';
}

export type ProviderContractDiagnostic=Readonly<{
 profileId:string;providerId:string;knownScope:boolean;manifestComplete:boolean;missingContractFields:readonly string[];
 invalidContractFields:readonly Readonly<{field:string;reason:string}>[];documentationOnly:true;credentialsPresent:boolean;
 adapterImplemented:false;catalogueAllowed:false;launchAllowed:false;walletAllowed:false;settlementAllowed:false;
 recoveryAllowed:false;playAllowed:false;
}>;

/** A complete document still cannot create or enable a supplier adapter. */
export function inspectProviderContractManifest(profileId:string,providerId:string,manifest:unknown={}):ProviderContractDiagnostic{
 const knownScope=validIdentifier(profileId)&&validIdentifier(providerId),missingContractFields:string[]=[],invalidContractFields:Array<{field:string;reason:string}>=[];
 if(knownScope)for(const requirement of GENERIC_PROVIDER_REQUIRED_CONTRACT_FIELDS){
  const value=readPath(manifest,requirement.field);
  if(value===undefined||value===null||value===''){missingContractFields.push(requirement.field);continue;}
  const expected=requirement.field==='profile.profile_id'?[profileId]:requirement.field==='profile.provider_id'?[providerId]:
   requirement.field==='profile.provider_currency'||requirement.field==='profile.settlement_currency'?['MYR']:undefined;
  const reason=validateValue(value,requirement,expected);if(reason)invalidContractFields.push({field:requirement.field,reason});
 }
 const record=manifest&&typeof manifest==='object'&&!Array.isArray(manifest)?manifest as Record<string,unknown>:{};
 const credentialsPresent=['apiKey','api_key','apiToken','token','secret','secretKey','password','merchantId','operatorId']
  .some(key=>typeof record[key]==='string'&&String(record[key]).trim().length>0);
 return Object.freeze({profileId,providerId,knownScope,manifestComplete:knownScope&&missingContractFields.length===0&&invalidContractFields.length===0,
  missingContractFields:Object.freeze(missingContractFields),invalidContractFields:Object.freeze(invalidContractFields.map(item=>Object.freeze(item))),
  documentationOnly:true,credentialsPresent,adapterImplemented:false,catalogueAllowed:false,launchAllowed:false,walletAllowed:false,
  settlementAllowed:false,recoveryAllowed:false,playAllowed:false});
}
