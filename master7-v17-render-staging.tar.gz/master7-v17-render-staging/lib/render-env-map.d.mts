export function mapVPayEnvironment(
  source?: Record<string, string | undefined>,
): Record<string, string | undefined>;

export function mapGSPayEnvironment(
  source?: Record<string, string | undefined>,
): Record<string, string | undefined>;

export function mapGSPayUsdtEnvironment(
  source?: Record<string, string | undefined>,
): Record<string, string | undefined>;

export function mapOneMpayEnvironment(
  source?: Record<string, string | undefined>,
): Record<string, string | undefined>;
