export function mapVPayEnvironment(
  source?: Record<string, string | undefined>,
): Record<string, string | undefined>;
