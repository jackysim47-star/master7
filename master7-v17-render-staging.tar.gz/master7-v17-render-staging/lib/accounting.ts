import {createHash,randomUUID} from 'node:crypto';

const MYT_OFFSET=8*3600;
const DAY=86400;
export const ACCOUNTING_CLOSE_MINUTE=5;
export const ACCOUNTING_REPORT_TYPE='settled_cashflow';

type FlowRow={orders?:number|string;members?:number|string;amount?:number|string};
type SnapshotRow={period_start:number|string;period_end:number|string;deposit_orders:number|string;deposit_minor:string;withdrawal_orders:number|string;withdrawal_minor:string;net_cashflow_minor:string;revision:number|string;checksum:string};

const rows=async(db:D1Database,sql:string,...values:(string|number)[])=>((await db.prepare(sql).bind(...values).all()).results??[]) as any[];
const changed=(result:any)=>Number(result?.meta?.changes??result?.changes??0);
const integer=(value:unknown)=>Number(value??0);
const textAmount=(value:unknown)=>String(value??'0');
const hash=(value:unknown)=>createHash('sha256').update(JSON.stringify(value)).digest('hex');

export function mytDayStart(timestamp:number){return Math.floor((timestamp+MYT_OFFSET)/DAY)*DAY-MYT_OFFSET;}
export function previousMytDayStart(timestamp:number){return mytDayStart(timestamp)-DAY;}
export function mytDateLabel(periodStart:number){return new Date((periodStart+MYT_OFFSET)*1000).toISOString().slice(0,10);}
export function mytDateStart(value:string){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return null;
 const timestamp=Math.floor(Date.parse(value+'T00:00:00+08:00')/1000);
 return Number.isSafeInteger(timestamp)&&mytDateLabel(timestamp)===value?timestamp:null;
}
export function accountingCloseDue(timestamp:number){return timestamp-mytDayStart(timestamp)>=ACCOUNTING_CLOSE_MINUTE*60;}

export async function settledCashflow(db:D1Database,start:number,end:number,label=mytDateLabel(start),period='day'){
 const [deposits,withdrawals,depositProviders,withdrawProviders]=await Promise.all([
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<?").bind(start,end).first<FlowRow>(),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM withdrawal_requests WHERE status='paid' AND updated_at>=? AND updated_at<?").bind(start,end).first<FlowRow>(),
  rows(db,"SELECT provider,COUNT(*) orders,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<? GROUP BY provider ORDER BY provider",start,end),
  rows(db,"SELECT provider_id provider,COUNT(*) orders,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM withdrawal_requests WHERE status='paid' AND updated_at>=? AND updated_at<? GROUP BY provider_id ORDER BY provider_id",start,end)
 ]);
 const depositMinor=textAmount(deposits?.amount),withdrawalMinor=textAmount(withdrawals?.amount),netCashflowMinor=(BigInt(depositMinor)-BigInt(withdrawalMinor)).toString();
 const report={currency:'MYR',timezone:'Asia/Kuching',reportType:ACCOUNTING_REPORT_TYPE,scope:'Settled deposits minus paid withdrawals; excludes bonuses, commissions, game P&L, provider fees, refunds and operating expenses.',period,start,end,label,deposits:{orders:integer(deposits?.orders),members:integer(deposits?.members),amountMinor:depositMinor},withdrawals:{orders:integer(withdrawals?.orders),members:integer(withdrawals?.members),amountMinor:withdrawalMinor},netCashflowMinor,depositProviders,withdrawProviders};
 return {...report,checksum:hash(report)};
}

async function recordLateSettlements(db:D1Database,scanSince:number,runAt:number){
 const [deposits,withdrawals]=await Promise.all([
  rows(db,"SELECT id,provider,amount_minor,created_at,updated_at FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<=? ORDER BY updated_at,id",scanSince,runAt),
  rows(db,"SELECT id,provider_id provider,amount_minor,created_at,updated_at FROM withdrawal_requests WHERE status='paid' AND updated_at>=? AND updated_at<=? ORDER BY updated_at,id",scanSince,runAt)
 ]),candidates=[...deposits.map(item=>({...item,source_type:'deposit'})),...withdrawals.map(item=>({...item,source_type:'withdrawal'}))];
 let inserted=0;
 for(const item of candidates){
  const original=mytDayStart(Number(item.created_at)),settled=mytDayStart(Number(item.updated_at));if(settled<=original)continue;
  const snapshot=await db.prepare('SELECT period_start FROM accounting_daily_snapshots WHERE period_start=?').bind(original).first();if(!snapshot)continue;
  const result=await db.prepare("INSERT INTO accounting_late_adjustments(id,original_period_start,source_type,source_id,provider,amount_minor,settled_at,detected_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source_type,source_id) DO NOTHING").bind(`${item.source_type}:${item.id}`,original,item.source_type,String(item.id),String(item.provider??''),String(item.amount_minor),Number(item.updated_at),runAt).run();
  inserted+=changed(result);
 }
 return inserted;
}

export async function closeAccountingDay(db:D1Database,periodStart:number,runAt:number,jobKey=`daily:${periodStart}`){
 if(periodStart!==mytDayStart(periodStart)||periodStart+DAY>mytDayStart(runAt))throw new Error('Accounting period is not a completed MYT day');
 const claimed=await db.prepare("INSERT INTO accounting_job_runs(job_key,period_start,started_at,status,result_json,error) VALUES(?,?,?,'running','','') ON CONFLICT(job_key) DO NOTHING RETURNING job_key").bind(jobKey,periodStart,runAt).first<{job_key:string}>();
 if(!claimed){
  const existing=await db.prepare('SELECT status,result_json,started_at FROM accounting_job_runs WHERE job_key=?').bind(jobKey).first<any>();
  if(existing?.status==='completed'){let result:any={};try{result=JSON.parse(existing.result_json||'{}');}catch{}return {...result,idempotent:true};}
  if(existing?.status==='running'&&Number(existing.started_at)>runAt-900)return {status:'running',jobKey,periodStart,idempotent:true};
  const reclaimed=await db.prepare("UPDATE accounting_job_runs SET period_start=?,started_at=?,completed_at=NULL,status='running',result_json='',error='' WHERE job_key=? AND (status='failed' OR started_at<=?) RETURNING job_key").bind(periodStart,runAt,jobKey,runAt-900).first();
  if(!reclaimed)return {status:'running',jobKey,periodStart,idempotent:true};
 }
 try{
  const end=periodStart+DAY,report=await settledCashflow(db,periodStart,end),existing=await db.prepare('SELECT * FROM accounting_daily_snapshots WHERE period_start=?').bind(periodStart).first<SnapshotRow>();let revision=1,adjusted=false;
  if(!existing){
   await db.prepare("INSERT INTO accounting_daily_snapshots(period_start,period_end,label,timezone,report_type,deposit_orders,deposit_members,deposit_minor,withdrawal_orders,withdrawal_members,withdrawal_minor,net_cashflow_minor,deposit_providers_json,withdrawal_providers_json,revision,checksum,closed_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(periodStart,end,report.label,report.timezone,report.reportType,report.deposits.orders,report.deposits.members,report.deposits.amountMinor,report.withdrawals.orders,report.withdrawals.members,report.withdrawals.amountMinor,report.netCashflowMinor,JSON.stringify(report.depositProviders),JSON.stringify(report.withdrawProviders),1,report.checksum,runAt,runAt).run();
  }else if(existing.checksum!==report.checksum){
   revision=Number(existing.revision)+1;adjusted=true;const depositMinorDelta=(BigInt(report.deposits.amountMinor)-BigInt(existing.deposit_minor)).toString(),withdrawalMinorDelta=(BigInt(report.withdrawals.amountMinor)-BigInt(existing.withdrawal_minor)).toString(),netDelta=(BigInt(report.netCashflowMinor)-BigInt(existing.net_cashflow_minor)).toString(),details=JSON.stringify({previousChecksum:existing.checksum,nextChecksum:report.checksum});
   await db.batch([
    db.prepare('INSERT INTO accounting_snapshot_adjustments(id,period_start,revision,deposit_orders_delta,deposit_minor_delta,withdrawal_orders_delta,withdrawal_minor_delta,net_cashflow_minor_delta,detected_at,details_json) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(period_start,revision) DO NOTHING').bind(randomUUID(),periodStart,revision,report.deposits.orders-Number(existing.deposit_orders),depositMinorDelta,report.withdrawals.orders-Number(existing.withdrawal_orders),withdrawalMinorDelta,netDelta,runAt,details),
    db.prepare('UPDATE accounting_daily_snapshots SET deposit_orders=?,deposit_members=?,deposit_minor=?,withdrawal_orders=?,withdrawal_members=?,withdrawal_minor=?,net_cashflow_minor=?,deposit_providers_json=?,withdrawal_providers_json=?,revision=?,checksum=?,updated_at=? WHERE period_start=? AND revision=?').bind(report.deposits.orders,report.deposits.members,report.deposits.amountMinor,report.withdrawals.orders,report.withdrawals.members,report.withdrawals.amountMinor,report.netCashflowMinor,JSON.stringify(report.depositProviders),JSON.stringify(report.withdrawProviders),revision,report.checksum,runAt,periodStart,Number(existing.revision))
   ]);
  }else revision=Number(existing.revision);
  // Re-scan a bounded settlement window on every run. The unique source key
  // makes this idempotent and avoids missing a back-dated provider callback.
  const scanSince=runAt-31*DAY,lateAdjustments=await recordLateSettlements(db,scanSince,runAt),result={status:'completed',jobKey,periodStart,periodEnd:end,label:report.label,revision,adjusted,lateAdjustments,reportType:ACCOUNTING_REPORT_TYPE,completedAt:runAt};
  await db.prepare("UPDATE accounting_job_runs SET completed_at=?,status='completed',result_json=?,error='' WHERE job_key=?").bind(runAt,JSON.stringify(result),jobKey).run();return result;
 }catch(error){await db.prepare("UPDATE accounting_job_runs SET completed_at=?,status='failed',error=? WHERE job_key=?").bind(runAt,String(error instanceof Error?error.message:error).slice(0,500),jobKey).run();throw error;}
}

export async function runAccountingCatchUp(db:D1Database,runAt:number,options:{periodStart?:number;jobKey?:string}={}){
 if(options.periodStart===undefined&&!accountingCloseDue(runAt))return {status:'not_due',nextCloseMinuteMYT:ACCOUNTING_CLOSE_MINUTE};
 const yesterday=previousMytDayStart(runAt);let starts:number[];
 if(options.periodStart!==undefined)starts=[options.periodStart];
 else{
  const latest=await db.prepare('SELECT MAX(period_start) period_start FROM accounting_daily_snapshots').first<{period_start:number}>(),first=latest?.period_start===null||latest?.period_start===undefined?yesterday:Number(latest.period_start)+DAY;
  starts=[];for(let value=first;value<=yesterday&&starts.length<31;value+=DAY)starts.push(value);
  if(!starts.length)starts=[yesterday];
 }
 const results=[];for(const start of starts)results.push(await closeAccountingDay(db,start,runAt,options.jobKey&&starts.length===1?options.jobKey:`daily:${start}`));
 return {status:'completed',closed:results.length,results};
}

export async function accountingSnapshot(db:D1Database,periodStart:number){
 const item=await db.prepare('SELECT * FROM accounting_daily_snapshots WHERE period_start=?').bind(periodStart).first<any>();if(!item)return null;
 const adjustments=await rows(db,'SELECT revision,deposit_orders_delta,deposit_minor_delta,withdrawal_orders_delta,withdrawal_minor_delta,net_cashflow_minor_delta,detected_at FROM accounting_snapshot_adjustments WHERE period_start=? ORDER BY revision',periodStart),late=await rows(db,'SELECT source_type,source_id,provider,amount_minor,settled_at,detected_at FROM accounting_late_adjustments WHERE original_period_start=? ORDER BY settled_at,source_type,source_id',periodStart);
 return {currency:'MYR',timezone:item.timezone,reportType:item.report_type,scope:'Settled deposits minus paid withdrawals; excludes bonuses, commissions, game P&L, provider fees, refunds and operating expenses.',period:'day',start:Number(item.period_start),end:Number(item.period_end),label:item.label,deposits:{orders:Number(item.deposit_orders),members:Number(item.deposit_members),amountMinor:String(item.deposit_minor)},withdrawals:{orders:Number(item.withdrawal_orders),members:Number(item.withdrawal_members),amountMinor:String(item.withdrawal_minor)},netCashflowMinor:String(item.net_cashflow_minor),depositProviders:JSON.parse(item.deposit_providers_json),withdrawProviders:JSON.parse(item.withdrawal_providers_json),snapshot:{closed:true,revision:Number(item.revision),closedAt:Number(item.closed_at),updatedAt:Number(item.updated_at),checksum:item.checksum,adjustments},lateAdjustments:{count:late.length,includedInOriginalPeriodCashflow:false,items:late}};
}
