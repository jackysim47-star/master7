import {disabledPayoutCapability} from './payment-capabilities.ts';

export const providerPayoutStates=['prepared','submitting','processing','succeeded','failed','reversed','review'] as const;
export type ProviderPayoutState=typeof providerPayoutStates[number];

const transitions:Record<ProviderPayoutState,readonly ProviderPayoutState[]>={
 prepared:['submitting','review'],
 submitting:['processing','failed','review'],
 processing:['succeeded','failed','review'],
 succeeded:['reversed','review'],
 failed:['review'],
 reversed:['review'],
 review:[],
};

export function payoutTransitionAllowed(from:ProviderPayoutState,to:ProviderPayoutState){return transitions[from].includes(to);}

export const providerPayoutCapabilities={
 vpay:disabledPayoutCapability('provider_payout_submission_not_connected'),
 gspay:disabledPayoutCapability('provider_payout_submission_not_connected'),
 '1mpay':disabledPayoutCapability('provider_payout_contract_incomplete'),
} as const;

// This release deliberately has no provider submission function. The database
// state machine exists so a later, separately accepted adapter cannot overload
// the member withdrawal request or mark it paid by hand.
export async function payoutSubmissionControls(db:D1Database){
 const result=await db.prepare('SELECT provider_id,submission_enabled FROM provider_payout_controls ORDER BY provider_id').all<{provider_id:string;submission_enabled:number}>();
 return (result.results??[]).map(row=>({providerId:row.provider_id,submissionEnabled:row.submission_enabled===1}));
}
