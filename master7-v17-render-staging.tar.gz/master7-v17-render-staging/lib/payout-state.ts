import {disabledPayoutCapability,paymentCapability} from './payment-capabilities.ts';

export const providerPayoutStates=['prepared','submitting','processing','succeeded','failed','reversed','review'] as const;
export type ProviderPayoutState=typeof providerPayoutStates[number];

const transitions:Record<ProviderPayoutState,readonly ProviderPayoutState[]>={
 prepared:['submitting','review'],
 submitting:['processing','failed','review'],
 processing:['succeeded','failed','review'],
 succeeded:['reversed','review'],
 failed:['review'],
 reversed:['review'],
 review:[],
};

export function payoutTransitionAllowed(from:ProviderPayoutState,to:ProviderPayoutState){return transitions[from].includes(to);}

export const providerPayoutCapabilities={
 vpay:paymentCapability({implemented:true,configured:false,enabled:false,submissionEnabled:false,blockers:['payout_configuration_incomplete','submission_disabled']}),
 gspay:paymentCapability({implemented:true,configured:false,enabled:false,submissionEnabled:false,blockers:['payout_configuration_incomplete','submission_disabled']}),
 '1mpay':disabledPayoutCapability('provider_payout_contract_incomplete'),
} as const;

// Provider submission controls remain independent from deposit controls. Each
// runtime adapter also has its own fail-closed environment switch.
export async function payoutSubmissionControls(db:D1Database){
 const result=await db.prepare('SELECT provider_id,submission_enabled FROM provider_payout_controls ORDER BY provider_id').all<{provider_id:string;submission_enabled:number}>();
 return (result.results??[]).map(row=>({providerId:row.provider_id,submissionEnabled:row.submission_enabled===1}));
}
