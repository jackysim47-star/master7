/** Static, correlated SQL shared by the wallet display and the transactional
 * spend guard. A session status alone never releases uncertain provider funds.
 * No supplier request, repair, posting or reservation deletion happens here. */
const open="'prepared','launching','active','settling','unknown','review'";
const fundedDeposit="t.direction='deposit' AND t.status IN ('prepared','submitting','unknown','succeeded','review')";

const badSession=`EXISTS (
 SELECT 1 FROM game_provider_sessions s
 LEFT JOIN game_provider_profiles p ON p.id=s.profile_id
 LEFT JOIN game_provider_players player ON player.profile_id=s.profile_id AND player.user_id=s.user_id
 LEFT JOIN wallet_reservations r ON r.reference_id=s.id
 WHERE (s.user_id=m.id OR r.user_id=m.id)
 AND (s.status IN (${open}) OR r.user_id IS NOT NULL OR EXISTS (SELECT 1 FROM game_wallet_transfers t WHERE t.session_id=s.id))
 AND (
  p.id IS NULL OR player.user_id IS NULL OR player.provider_player_id<>s.provider_player_id OR player.status<>'verified'
  OR p.wallet_mode<>s.wallet_mode OR p.currency<>s.currency OR s.currency<>'MYR' OR p.balance_class<>'cash'
  OR s.status='review'
  OR (s.status IN (${open}) AND s.closed_at IS NOT NULL)
  OR (s.wallet_mode='transfer' AND s.status IN (${open}) AND (r.user_id IS NULL OR r.user_id<>s.user_id OR r.kind<>'game'))
  OR (r.user_id IS NOT NULL AND (r.user_id<>s.user_id OR r.kind<>'game'))
  OR (s.status IN ('settled','failed') AND r.user_id IS NOT NULL)
  OR (s.wallet_mode='transfer' AND s.status IN (${open}) AND r.user_id=s.user_id AND EXISTS (
    SELECT 1 FROM game_wallet_transfers t WHERE t.session_id=s.id AND ${fundedDeposit})
   AND r.amount_minor<>(SELECT COALESCE(SUM(t.amount_minor),0) FROM game_wallet_transfers t WHERE t.session_id=s.id AND ${fundedDeposit}))
  OR (s.wallet_mode='transfer' AND s.status IN ('launching','active','settling') AND NOT EXISTS (
    SELECT 1 FROM game_wallet_transfers t WHERE t.session_id=s.id AND t.profile_id=s.profile_id AND t.user_id=s.user_id AND t.currency=s.currency AND t.direction='deposit' AND t.status='succeeded'))
  OR (s.status IN ('settled','failed') AND EXISTS (SELECT 1 FROM game_wallet_transfers t WHERE t.session_id=s.id
    AND (t.status IN ('submitting','unknown','succeeded','review','reversed') OR (t.status='prepared' AND t.attempts>0))))
 ))`;

const badTransfer=`EXISTS (
 SELECT 1 FROM game_wallet_transfers t LEFT JOIN game_provider_sessions s ON s.id=t.session_id
 WHERE (t.user_id=m.id OR s.user_id=m.id) AND (
  s.id IS NULL OR s.user_id<>t.user_id OR s.profile_id<>t.profile_id OR s.currency<>t.currency OR t.currency<>'MYR'
  OR LENGTH(TRIM(t.provider_reference))<1 OR LENGTH(t.provider_reference)>200
  OR t.status IN ('review','reversed')
  OR (t.status='prepared' AND (t.attempts<>0 OR t.completed_at IS NOT NULL))
  OR (t.status IN ('submitting','unknown','succeeded') AND t.attempts<1)
  OR (t.status='succeeded' AND t.completed_at IS NULL)
  OR (t.status='failed' AND t.attempts>0 AND t.completed_at IS NULL)
  OR (t.direction='withdrawal' AND t.status NOT IN ('failed') AND NOT EXISTS (
    SELECT 1 FROM game_wallet_transfers d WHERE d.session_id=t.session_id AND d.profile_id=t.profile_id AND d.user_id=t.user_id
    AND d.currency=t.currency AND d.direction='deposit' AND d.status='succeeded'))
 ))`;

// The generic posting tables are not yet part of the canonical cash balance.
// Never ignore an applied transaction or existing posting and spend old credits.
// A future posting integration must replace this barrier with ledger proof.
const unprojectedPosting=`(
 EXISTS (SELECT 1 FROM game_transactions t WHERE t.user_id=m.id AND t.status='applied')
 OR EXISTS (SELECT 1 FROM game_wallet_postings p LEFT JOIN game_transactions t ON t.id=p.transaction_id
  WHERE p.user_id=m.id OR t.user_id=m.id)
)`;

export const genericGameWalletRiskFreeSql=`NOT (${badSession} OR ${badTransfer} OR ${unprojectedPosting})`;
export type GenericGameWalletConsistency={sessionMismatch:boolean;transferMismatch:boolean;unprojectedPosting:boolean;reconciliationRequired:boolean};

function consistency(row:{session_mismatch:number|string;transfer_mismatch:number|string;unprojected_posting:number|string}):GenericGameWalletConsistency{
 const flag=(value:unknown)=>{if(value===0||value==='0')return false;if(value===1||value==='1')return true;throw new Error('Game wallet consistency is unavailable');};
 const sessionMismatch=flag(row.session_mismatch),transferMismatch=flag(row.transfer_mismatch),unprojected=flag(row.unprojected_posting);
 return {sessionMismatch,transferMismatch,unprojectedPosting:unprojected,reconciliationRequired:sessionMismatch||transferMismatch||unprojected};
}

export async function genericGameWalletConsistency(db:D1Database,userId:string):Promise<GenericGameWalletConsistency>{
 const row=await db.prepare(`SELECT CASE WHEN ${badSession} THEN 1 ELSE 0 END session_mismatch,
 CASE WHEN ${badTransfer} THEN 1 ELSE 0 END transfer_mismatch,
 CASE WHEN ${unprojectedPosting} THEN 1 ELSE 0 END unprojected_posting FROM (SELECT ? AS id) m`).bind(userId).first<{session_mismatch:number;transfer_mismatch:number;unprojected_posting:number}>();
 if(!row)throw new Error('Game wallet consistency is unavailable');
 return consistency(row);
}

/** At most one assessment per distinct user in an already authorized admin page. */
export async function genericGameWalletConsistencyForUsers(db:D1Database,userIds:readonly string[]){
 const ids=[...new Set(userIds)];if(ids.length>500)throw new Error('Game wallet review page is too large');
 const results=new Map<string,GenericGameWalletConsistency>();if(!ids.length)return results;
 const rows=await db.prepare(`SELECT m.id user_id,CASE WHEN ${badSession} THEN 1 ELSE 0 END session_mismatch,
  CASE WHEN ${badTransfer} THEN 1 ELSE 0 END transfer_mismatch,
  CASE WHEN ${unprojectedPosting} THEN 1 ELSE 0 END unprojected_posting FROM users m WHERE m.id IN (${ids.map(()=>'?').join(',')})`)
  .bind(...ids).all<{user_id:string;session_mismatch:number;transfer_mismatch:number;unprojected_posting:number}>();
 if(!Array.isArray(rows.results))throw new Error('Game wallet consistency is unavailable');
 for(const row of rows.results)results.set(row.user_id,consistency(row));
 if(ids.some(id=>!results.has(id)))throw new Error('Game wallet consistency is unavailable');
 return results;
}
