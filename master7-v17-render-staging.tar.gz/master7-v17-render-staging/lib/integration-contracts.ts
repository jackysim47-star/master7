/**
 * Non-secret supplier contract inventory used by the staging handover.
 *
 * This module deliberately contains documentation requirements only. It does
 * not accept credentials, call a supplier, create an order, move funds, or
 * grant any game capability. Runtime readiness remains owned by the existing
 * payment and game acceptance gates.
 */

export type IntegrationContractStatus = 'contract_missing' | 'documented_not_verified';

export type GameIntegrationContract = Readonly<{
  providerId: 'lebet';
  displayName: 'Lebet';
  status: IntegrationContractStatus;
  documentationOnly: true;
  implemented: false;
  enabled: false;
  launchReady: false;
  walletReady: false;
  recoveryReady: false;
  liveReady: false;
  requiredEvidence: readonly string[];
}>;

export type PaymentIntegrationContract = Readonly<{
  providerId: 'vpay_myr' | 'gspay_myr' | 'gspay_usdt' | 'onempay_myr';
  displayName: string;
  status: IntegrationContractStatus;
  documentationOnly: true;
  implemented: boolean;
  enabled: false;
  orderReady: false;
  callbackReady: false;
  recoveryReady: false;
  settlementVerified: false;
  liveReady: false;
  requiredEvidence: readonly string[];
}>;

const GAME_EVIDENCE = Object.freeze([
  'official_api_document',
  'api_version_and_environment',
  'authentication_and_signature',
  'network_and_callback_rules',
  'catalogue_contract',
  'player_mapping_contract',
  'launch_contract',
  'wallet_mode_and_balance_contract',
  'wallet_transfer_contract',
  'callback_and_deduplication_contract',
  'recovery_and_timeout_contract',
  'settlement_and_reconciliation_contract',
  'maintenance_and_error_contract',
  'authorized_uat_scope',
  'provider_uat_evidence',
]);

const PAYMENT_EVIDENCE = Object.freeze([
  'official_api_document',
  'api_version_and_environment',
  'authentication_and_signature',
  'credential_rotation_evidence',
  'order_contract',
  'callback_contract',
  'query_and_recovery_contract',
  'wallet_credit_contract',
  'settlement_and_reconciliation_contract',
  'authorized_uat_scope',
  'provider_uat_evidence',
]);

const gameContracts: readonly GameIntegrationContract[] = Object.freeze([
  Object.freeze({
    providerId: 'lebet',
    displayName: 'Lebet',
    status: 'contract_missing',
    documentationOnly: true,
    implemented: false,
    enabled: false,
    launchReady: false,
    walletReady: false,
    recoveryReady: false,
    liveReady: false,
    requiredEvidence: GAME_EVIDENCE,
  }),
]);

const paymentContracts: readonly PaymentIntegrationContract[] = Object.freeze([
  Object.freeze({
    providerId: 'vpay_myr',
    displayName: 'VPay · MYR',
    status: 'documented_not_verified',
    documentationOnly: true,
    implemented: true,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    requiredEvidence: PAYMENT_EVIDENCE,
  }),
  Object.freeze({
    providerId: 'gspay_myr',
    displayName: 'GSPAY · MYR',
    status: 'documented_not_verified',
    documentationOnly: true,
    implemented: true,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    requiredEvidence: PAYMENT_EVIDENCE,
  }),
  Object.freeze({
    providerId: 'gspay_usdt',
    displayName: 'GSPAY · USDT',
    status: 'contract_missing',
    documentationOnly: true,
    implemented: false,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    requiredEvidence: Object.freeze([
      ...PAYMENT_EVIDENCE,
      'asset_network_and_scale_rules',
    ]),
  }),
  Object.freeze({
    providerId: 'onempay_myr',
    displayName: '1MPAY · MYR',
    status: 'documented_not_verified',
    documentationOnly: true,
    implemented: true,
    enabled: false,
    orderReady: false,
    callbackReady: false,
    recoveryReady: false,
    settlementVerified: false,
    liveReady: false,
    requiredEvidence: PAYMENT_EVIDENCE,
  }),
]);

export function getIntegrationContractIntake() {
  return Object.freeze({
    documentationOnly: true as const,
    gameProviders: gameContracts,
    paymentProviders: paymentContracts,
  });
}
