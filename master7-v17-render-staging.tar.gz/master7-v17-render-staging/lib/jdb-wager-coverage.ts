import {createHash,randomUUID} from 'node:crypto';
import type {GameProviderWager,GameProviderWagerPage} from './game-provider-adapter.ts';

export type JdbWagerTimeBasis='lastModifyTime'|'gameDate';
export type JdbWagerWindow={profileId:'jdb_myr';timeBasis:JdbWagerTimeBasis;from:number;to:number};
export type JdbWagerClaim=JdbWagerWindow&{windowId:string;claimToken:string;fence:number;lockedUntil:number};
export const JDB_WAGER_FIXTURE_PAGE_LIMIT=500;

type Actor={id:string;role:string};
type Normalized={identity:string;payload:string;roundHash:string|null;playerHash:string;gameHash:string;bet:string;win:string;settledAt:number;detailsHash:string;count:number};

export class JdbWagerCoverageError extends Error{
 readonly status:number;readonly code:string;
 constructor(status:number,code:string){super(code);this.name='JdbWagerCoverageError';this.status=status;this.code=code;}
}
const fail=(status:number,code:string):never=>{throw new JdbWagerCoverageError(status,code);};
const sha=(value:string)=>createHash('sha256').update(value).digest('hex');
const positiveInt=(value:unknown)=>Number.isSafeInteger(value)&&Number(value)>0;
const nonnegativeMinor=(value:unknown)=>typeof value==='string'&&/^(0|[1-9]\d{0,15})$/.test(value);
const safeIdentifier=(value:unknown,max=256)=>typeof value==='string'&&value.length>0&&value.length<=max&&!/[\u0000-\u001f\u007f]/u.test(value);

function stable(value:unknown):string{
 if(value===null||typeof value!=='object')return JSON.stringify(value);
 if(Array.isArray(value))return `[${value.map(stable).join(',')}]`;
 return `{${Object.entries(value as Record<string,unknown>).sort(([a],[b])=>a.localeCompare(b)).map(([key,item])=>`${JSON.stringify(key)}:${stable(item)}`).join(',')}}`;
}

function validateWindow(input:JdbWagerWindow):JdbWagerWindow{
 if(input?.profileId!=='jdb_myr')fail(400,'JDB_WAGER_PROFILE_INVALID');
 if(input.timeBasis!=='lastModifyTime'&&input.timeBasis!=='gameDate')fail(400,'JDB_WAGER_TIME_BASIS_INVALID');
 const duration=Number(input.to)-Number(input.from),max=input.timeBasis==='lastModifyTime'?15*60_000:5*60_000;
 if(!positiveInt(input.from)||!positiveInt(input.to)||input.from>=input.to||input.from%60_000!==0||input.to%60_000!==0||duration>max)fail(400,'JDB_WAGER_WINDOW_INVALID');
 return input;
}

function windowId(window:JdbWagerWindow){return sha(stable({profileId:window.profileId,timeBasis:window.timeBasis,from:window.from,to:window.to}));}
function leaseValidSql(){return `EXISTS(SELECT 1 FROM game_recovery_leases l JOIN jdb_wager_sync_windows w ON w.window_id=l.resource_id AND w.profile_id=l.profile_id WHERE l.profile_id=? AND l.resource_type='wager_sync' AND l.resource_id=? AND l.claim_token=? AND l.attempts=? AND l.locked_until>=? AND w.current_fence=l.attempts AND w.state='syncing')`;}

/** Claims one immutable report window. The generic recovery lease attempt is
 * the fencing generation; a timed-out worker can never stage after takeover. */
export async function claimJdbWagerWindow(db:D1Database,input:JdbWagerWindow,options:{at?:number;leaseSeconds?:number;claimToken?:string}={}):Promise<JdbWagerClaim>{
 const w=validateWindow(input),at=options.at??Math.floor(Date.now()/1000),leaseSeconds=options.leaseSeconds??90,claimToken=options.claimToken??randomUUID(),id=windowId(w);
 if(!Number.isSafeInteger(at)||at<=0||!Number.isSafeInteger(leaseSeconds)||leaseSeconds<5||leaseSeconds>900||!safeIdentifier(claimToken,200))fail(400,'JDB_WAGER_LEASE_INVALID');
 const profile=await db.prepare('SELECT provider_id,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status FROM game_provider_profiles WHERE id=?').bind(w.profileId).first<Record<string,unknown>>();
 if(!profile||profile.provider_id!=='jdb'||profile.adapter_key!=='jdb'||profile.wallet_mode!=='transfer'||profile.balance_class!=='cash'||profile.currency!=='MYR'||String(profile.unit_numerator)!=='1'||String(profile.unit_denominator)!=='1'||profile.environment!=='production'||profile.status!=='closed')fail(409,'JDB_WAGER_PROFILE_NOT_CLOSED');
 await db.prepare(`INSERT INTO jdb_wager_sync_windows(window_id,profile_id,time_basis,window_start_ms,window_end_ms,state,current_fence,created_at,updated_at)
  VALUES(?,?,?,?,?,'idle',0,?,?) ON CONFLICT(window_id) DO NOTHING`).bind(id,w.profileId,w.timeBasis,w.from,w.to,at,at).run();
 const row=await db.prepare(`INSERT INTO game_recovery_leases(profile_id,resource_type,resource_id,claim_token,locked_until,last_checked_at,attempts)
  VALUES(?,'wager_sync',?,?,?, ?,1)
  ON CONFLICT(profile_id,resource_type,resource_id) DO UPDATE SET claim_token=excluded.claim_token,locked_until=excluded.locked_until,
   last_checked_at=excluded.last_checked_at,attempts=game_recovery_leases.attempts+1
  WHERE game_recovery_leases.locked_until<=? OR game_recovery_leases.claim_token=''
  RETURNING attempts`).bind(w.profileId,id,claimToken,at+leaseSeconds,at,at).first<{attempts:number}>();
 if(!row)throw new JdbWagerCoverageError(409,'JDB_WAGER_WINDOW_BUSY');
 const fence=Number(row.attempts);
 const updated=await db.prepare(`UPDATE jdb_wager_sync_windows SET state='syncing',current_fence=?,last_error_code=NULL,updated_at=?
  WHERE window_id=? AND profile_id=? AND EXISTS(SELECT 1 FROM game_recovery_leases WHERE profile_id=? AND resource_type='wager_sync' AND resource_id=? AND claim_token=? AND attempts=? AND locked_until>=?)`).bind(fence,at,id,w.profileId,w.profileId,id,claimToken,fence,at).run();
 if(Number(updated.meta?.changes??0)!==1)fail(409,'JDB_WAGER_CLAIM_LOST');
 return {...w,windowId:id,claimToken,fence,lockedUntil:at+leaseSeconds};
}

function normalize(item:GameProviderWager):Omit<Normalized,'count'>{
 if(!item||!safeIdentifier(item.providerBetId)||!safeIdentifier(item.providerPlayerId)||!safeIdentifier(item.providerGameId)||item.currency!=='MYR'||!nonnegativeMinor(item.betMinor)||!nonnegativeMinor(item.winMinor)||!positiveInt(item.settledAt))fail(400,'JDB_WAGER_ITEM_INVALID');
 if(item.providerRoundId!==null&&!safeIdentifier(item.providerRoundId))fail(400,'JDB_WAGER_ITEM_INVALID');
 if(item.sourceDetails!==undefined&&(!item.sourceDetails||typeof item.sourceDetails!=='object'||Array.isArray(item.sourceDetails)||Object.entries(item.sourceDetails).some(([key,value])=>!safeIdentifier(key,80)||typeof value!=='string'||value.length>1000)))fail(400,'JDB_WAGER_DETAILS_INVALID');
 const semanticDetails=Object.fromEntries(Object.entries(item.sourceDetails??{}).filter(([key])=>key!=='timeBasis'));
 const roundHash=item.providerRoundId===null?null:sha(item.providerRoundId),playerHash=sha(item.providerPlayerId),gameHash=sha(item.providerGameId),detailsHash=sha(stable(semanticDetails));
 const identity=sha(stable({profile:'jdb_myr',playerHash,bet:item.providerBetId,gameHash}));
 const payload=sha(stable({identity,roundHash,playerHash,gameHash,bet:item.betMinor,win:item.winMinor,currency:item.currency,settledAt:item.settledAt,detailsHash}));
 return {identity,payload,roundHash,playerHash,gameHash,bet:item.betMinor,win:item.winMinor,settledAt:item.settledAt,detailsHash};
}

function receiptPublic(row:any){return {receiptId:String(row.id),profileId:String(row.profile_id),windowId:String(row.window_id),fence:Number(row.fence),inputCount:Number(row.input_count),uniqueInputCount:Number(row.unique_input_count),originalCount:Number(row.original_count),duplicateCount:Number(row.duplicate_count),lateCount:Number(row.late_count),revisionCount:Number(row.revision_count),reversalCandidateCount:Number(row.reversal_candidate_count),providerPageComplete:false,sourceFinalityVerified:false,sessionClosureVerified:false,merchantAuthorizationVerified:false,coverageComplete:false,status:'review' as const,observedAt:Number(row.observed_at)};}

/** Persists a supplied page only. This module never calls a provider and never
 * posts wallet, turnover, reward, round or accounting rows. */
export async function stageJdbWagerPage(db:D1Database,claim:JdbWagerClaim,page:GameProviderWagerPage,options:{at?:number}={}){
 const w=validateWindow(claim),at=options.at??Math.floor(Date.now()/1000);
 if(claim.windowId!==windowId(w)||!safeIdentifier(claim.claimToken,200)||!Number.isSafeInteger(claim.fence)||claim.fence<1||!page||!Array.isArray(page.items)||page.items.length>JDB_WAGER_FIXTURE_PAGE_LIMIT||page.complete!==false||page.nextCursor!==undefined||!Number.isSafeInteger(at)||at<=0)fail(400,'JDB_WAGER_STAGE_INVALID');
 const claimHash=sha(claim.claimToken);
 const groups=new Map<string,Normalized>();
 for(const item of page.items){if(item.sourceDetails?.timeBasis!==undefined&&item.sourceDetails.timeBasis!==w.timeBasis)fail(400,'JDB_WAGER_TIME_BASIS_MISMATCH');const normalized=normalize(item),key=`${normalized.identity}:${normalized.payload}`,prior=groups.get(key);groups.set(key,{...normalized,count:(prior?.count??0)+1});}
 const orderedGroups=[...groups.values()].sort((a,b)=>a.identity.localeCompare(b.identity)||Number(a.bet==='0'&&a.win==='0')-Number(b.bet==='0'&&b.win==='0')||a.payload.localeCompare(b.payload));
 const pageSha=sha(stable(orderedGroups.map(item=>({identity:item.identity,payload:item.payload,count:item.count})))),receiptId=sha(stable({windowId:claim.windowId,pageSha}));
 const existing=await db.prepare('SELECT * FROM jdb_wager_receipts WHERE id=? AND page_sha256=?').bind(receiptId,pageSha).first();
 if(existing){
  const lease=await db.prepare("SELECT claim_token,attempts,locked_until FROM game_recovery_leases WHERE profile_id=? AND resource_type='wager_sync' AND resource_id=?").bind(w.profileId,claim.windowId).first<{claim_token:string;attempts:number;locked_until:number}>();
  if(lease?.claim_token===claim.claimToken&&Number(lease.attempts)===claim.fence&&Number(lease.locked_until)>=at)await db.batch([
   db.prepare(`UPDATE jdb_wager_sync_windows SET state='review',last_receipt_id=?,last_error_code='JDB_SOURCE_FINALITY_UNVERIFIED',updated_at=? WHERE window_id=? AND current_fence=?`).bind(receiptId,at,claim.windowId,claim.fence),
   db.prepare("UPDATE game_recovery_leases SET claim_token='',locked_until=0,last_checked_at=? WHERE profile_id=? AND resource_type='wager_sync' AND resource_id=? AND claim_token=? AND attempts=?").bind(at,w.profileId,claim.windowId,claim.claimToken,claim.fence),
  ]);
  return receiptPublic(existing);
 }
 const statements:any[]=[];
 const valid=leaseValidSql();
 // The first write locks the generic lease row for this transaction. The
 // second statement deliberately violates the window state CHECK on a stale
 // fence, forcing the whole batch to roll back before any evidence can write.
 statements.push(db.prepare("UPDATE game_recovery_leases SET last_checked_at=last_checked_at WHERE profile_id=? AND resource_type='wager_sync' AND resource_id=? AND claim_token=? AND attempts=? AND locked_until>=?").bind(w.profileId,claim.windowId,claim.claimToken,claim.fence,at));
 statements.push(db.prepare(`UPDATE jdb_wager_sync_windows SET state=CASE WHEN ${valid} THEN 'syncing' ELSE 'stale_fence' END WHERE window_id=?`).bind(w.profileId,claim.windowId,claim.claimToken,claim.fence,at,claim.windowId));
 statements.push(db.prepare(`INSERT INTO jdb_wager_receipts(id,window_id,profile_id,fence,claim_token_sha256,page_sha256,input_count,unique_input_count,original_count,duplicate_count,late_count,revision_count,reversal_candidate_count,page_complete,source_finality_verified,session_closure_verified,merchant_authorization_verified,coverage_complete,status,observed_at)
  SELECT ?,?,?,?,?,?,?,?,0,0,0,0,0,0,0,0,0,0,'review',? WHERE ${valid} ON CONFLICT(id) DO NOTHING`).bind(receiptId,claim.windowId,w.profileId,claim.fence,claimHash,pageSha,page.items.length,groups.size,at,w.profileId,claim.windowId,claim.claimToken,claim.fence,at));
 for(const item of orderedGroups){
  statements.push(db.prepare(`INSERT INTO jdb_wager_identities(identity_sha256,profile_id,first_payload_sha256,first_receipt_id,first_observed_at)
   SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM jdb_wager_receipts WHERE id=?) ON CONFLICT(identity_sha256) DO NOTHING`).bind(item.identity,w.profileId,item.payload,receiptId,at,receiptId));
  statements.push(db.prepare(`INSERT INTO jdb_wager_event_versions(identity_sha256,payload_sha256,profile_id,provider_round_sha256,provider_player_sha256,provider_game_sha256,bet_minor,win_minor,currency,settled_at_ms,source_details_sha256,classification,first_receipt_id,first_observed_at)
   SELECT ?,?,?,?,?,?,?,?,?,?,?,CASE WHEN i.first_payload_sha256=? THEN CASE WHEN EXISTS(SELECT 1 FROM jdb_wager_receipts prior WHERE prior.window_id=? AND prior.id<>?) THEN 'late' ELSE 'original' END ELSE ? END,?,? FROM jdb_wager_identities i
   WHERE i.identity_sha256=? AND EXISTS(SELECT 1 FROM jdb_wager_receipts WHERE id=?) ON CONFLICT(identity_sha256,payload_sha256) DO NOTHING`)
   .bind(item.identity,item.payload,w.profileId,item.roundHash,item.playerHash,item.gameHash,item.bet,item.win,'MYR',item.settledAt,item.detailsHash,item.payload,
    claim.windowId,receiptId,(item.bet==='0'&&item.win==='0')?'reversal_candidate':'revision',receiptId,at,item.identity,receiptId));
  statements.push(db.prepare(`INSERT INTO jdb_wager_observations(receipt_id,identity_sha256,payload_sha256,classification,occurrence_count)
   SELECT ?,e.identity_sha256,e.payload_sha256,CASE WHEN e.first_receipt_id=? THEN e.classification ELSE 'duplicate' END,?
   FROM jdb_wager_event_versions e WHERE e.identity_sha256=? AND e.payload_sha256=? AND EXISTS(SELECT 1 FROM jdb_wager_receipts WHERE id=?)
   ON CONFLICT(receipt_id,identity_sha256,payload_sha256) DO UPDATE SET occurrence_count=excluded.occurrence_count`).bind(receiptId,receiptId,item.count,item.identity,item.payload,receiptId));
 }
 statements.push(db.prepare(`UPDATE jdb_wager_receipts SET
  original_count=COALESCE((SELECT SUM(CASE WHEN classification='original' THEN 1 ELSE 0 END) FROM jdb_wager_observations WHERE receipt_id=?),0),
  duplicate_count=COALESCE((SELECT SUM(CASE WHEN classification='duplicate' THEN occurrence_count ELSE occurrence_count-1 END) FROM jdb_wager_observations WHERE receipt_id=?),0),
  late_count=COALESCE((SELECT SUM(CASE WHEN classification='late' THEN 1 ELSE 0 END) FROM jdb_wager_observations WHERE receipt_id=?),0),
  revision_count=COALESCE((SELECT SUM(CASE WHEN classification='revision' THEN 1 ELSE 0 END) FROM jdb_wager_observations WHERE receipt_id=?),0),
  reversal_candidate_count=COALESCE((SELECT SUM(CASE WHEN classification='reversal_candidate' THEN 1 ELSE 0 END) FROM jdb_wager_observations WHERE receipt_id=?),0)
  WHERE id=?`).bind(receiptId,receiptId,receiptId,receiptId,receiptId,receiptId));
 statements.push(db.prepare(`UPDATE jdb_wager_sync_windows SET state='review',last_receipt_id=?,last_error_code='JDB_SOURCE_FINALITY_UNVERIFIED',updated_at=?
  WHERE window_id=? AND ${valid}`).bind(receiptId,at,claim.windowId,w.profileId,claim.windowId,claim.claimToken,claim.fence,at));
 statements.push(db.prepare(`INSERT INTO game_wager_sync_cursors(profile_id,cursor_value,watermark_at,status,last_error_code,last_success_at,updated_at)
  SELECT ?,'',0,'review','JDB_SOURCE_FINALITY_UNVERIFIED',0,? WHERE EXISTS(SELECT 1 FROM jdb_wager_receipts WHERE id=?)
  ON CONFLICT(profile_id) DO UPDATE SET status='review',last_error_code='JDB_SOURCE_FINALITY_UNVERIFIED',updated_at=excluded.updated_at`).bind(w.profileId,at,receiptId));
 statements.push(db.prepare(`UPDATE game_recovery_leases SET
  resource_type=CASE WHEN claim_token=? AND attempts=? AND locked_until>=? THEN resource_type ELSE 'stale_release' END,
  claim_token=CASE WHEN claim_token=? AND attempts=? AND locked_until>=? THEN '' ELSE claim_token END,
  locked_until=CASE WHEN claim_token=? AND attempts=? AND locked_until>=? THEN 0 ELSE locked_until END,last_checked_at=?
  WHERE profile_id=? AND resource_type='wager_sync' AND resource_id=?`).bind(claim.claimToken,claim.fence,at,claim.claimToken,claim.fence,at,claim.claimToken,claim.fence,at,at,w.profileId,claim.windowId));
 let batchResults:any[];
 try{batchResults=await db.batch(statements) as any[];}catch(error){
  const current=await db.prepare("SELECT claim_token,attempts,locked_until FROM game_recovery_leases WHERE profile_id=? AND resource_type='wager_sync' AND resource_id=?").bind(w.profileId,claim.windowId).first<{claim_token:string;attempts:number;locked_until:number}>();
  if(!current||current.claim_token!==claim.claimToken||Number(current.attempts)!==claim.fence||Number(current.locked_until)<at)throw new JdbWagerCoverageError(409,'JDB_WAGER_CLAIM_STALE');
  throw error;
 }
 if(Number((batchResults as any[])?.[0]?.meta?.changes??0)!==1||Number((batchResults as any[])?.at(-1)?.meta?.changes??0)!==1)fail(409,'JDB_WAGER_FENCE_INVARIANT_FAILED');
 const stored=await db.prepare('SELECT * FROM jdb_wager_receipts WHERE id=? AND claim_token_sha256=?').bind(receiptId,claimHash).first();
 if(!stored)fail(409,'JDB_WAGER_CLAIM_STALE');
 const lease=await db.prepare("SELECT claim_token FROM game_recovery_leases WHERE profile_id=? AND resource_type='wager_sync' AND resource_id=?").bind(w.profileId,claim.windowId).first<{claim_token:string}>();
 if(lease?.claim_token!=='')fail(409,'JDB_WAGER_FENCE_RELEASE_FAILED');
 return receiptPublic(stored);
}

function requireRead(actor:Actor){if(!actor?.id)fail(401,'SIGN_IN_REQUIRED');if(actor.role!=='owner'&&actor.role!=='staff')fail(403,'ACCESS_DENIED');}

/** Aggregate-only diagnostic: never returns supplier/member/bet identifiers,
 * hashes, payloads, amounts or lease tokens. Observed continuity is not proof
 * of supplier finality or production acceptance. */
export async function getJdbWagerCoverage(db:D1Database,actor:Actor,input:{from?:unknown;to?:unknown;timeBasis?:unknown}={}){
 requireRead(actor);
 const from=input.from===undefined?undefined:Number(input.from),to=input.to===undefined?undefined:Number(input.to),basis=input.timeBasis;
 if((from!==undefined&&!positiveInt(from))||(to!==undefined&&!positiveInt(to))||(from!==undefined&&to!==undefined&&from>=to)||(basis!==undefined&&basis!=='lastModifyTime'&&basis!=='gameDate'))fail(400,'JDB_WAGER_DIAGNOSTIC_FILTER_INVALID');
 const where=["w.profile_id='jdb_myr'"],values:unknown[]=[];
 if(basis!==undefined){where.push('w.time_basis=?');values.push(basis);}if(from!==undefined){where.push('w.window_end_ms>?');values.push(from);}if(to!==undefined){where.push('w.window_start_ms<?');values.push(to);}
 const result=await db.prepare(`SELECT w.time_basis,w.window_start_ms,w.window_end_ms,w.state,w.current_fence,w.last_error_code,
  r.input_count,r.unique_input_count,r.original_count,r.duplicate_count,r.late_count,r.revision_count,r.reversal_candidate_count,r.observed_at,
  CASE WHEN l.claim_token<>'' AND l.locked_until>? THEN 1 ELSE 0 END active_lease
  FROM jdb_wager_sync_windows w LEFT JOIN (SELECT window_id,SUM(input_count) input_count,SUM(unique_input_count) unique_input_count,
   SUM(original_count) original_count,SUM(duplicate_count) duplicate_count,SUM(late_count) late_count,SUM(revision_count) revision_count,
   SUM(reversal_candidate_count) reversal_candidate_count,MAX(observed_at) observed_at FROM jdb_wager_receipts GROUP BY window_id) r ON r.window_id=w.window_id
  LEFT JOIN game_recovery_leases l ON l.profile_id=w.profile_id AND l.resource_type='wager_sync' AND l.resource_id=w.window_id
  WHERE ${where.join(' AND ')} ORDER BY w.time_basis,w.window_start_ms,w.window_end_ms`).bind(Math.floor(Date.now()/1000),...values).all<any>();
 const rows=result.results??[],ranges:any[]=[],gaps:any[]=[],overlaps:any[]=[],gapKeys=new Set<string>();
 const addGap=(timeBasis:JdbWagerTimeBasis,gapFrom:number,gapTo:number)=>{if(gapFrom>=gapTo)return;const key=`${timeBasis}:${gapFrom}:${gapTo}`;if(!gapKeys.has(key)){gapKeys.add(key);gaps.push({timeBasis,from:gapFrom,to:gapTo});}};
 for(const timeBasis of ['lastModifyTime','gameDate'] as const){const intervals=rows.filter(row=>row.time_basis===timeBasis&&row.input_count!==null).map(row=>({from:Number(row.window_start_ms),to:Number(row.window_end_ms)}));let current:null|{from:number;to:number}=null;for(const interval of intervals){if(!current){current={...interval};continue;}if(interval.from>current.to){ranges.push({timeBasis,...current});if(from===undefined||to===undefined)addGap(timeBasis,current.to,interval.from);current={...interval};}else{if(interval.from<current.to)overlaps.push({timeBasis,from:interval.from,to:Math.min(interval.to,current.to)});current.to=Math.max(current.to,interval.to);}}if(current)ranges.push({timeBasis,...current});}
 if(from!==undefined&&to!==undefined){for(const timeBasis of basis?[basis as JdbWagerTimeBasis]:['lastModifyTime','gameDate'] as const){const covered=ranges.filter(range=>range.timeBasis===timeBasis&&range.to>from&&range.from<to);let cursor=from;for(const range of covered){if(range.from>cursor)addGap(timeBasis,cursor,Math.min(range.from,to));cursor=Math.max(cursor,range.to);if(cursor>=to)break;}if(cursor<to)addGap(timeBasis,cursor,to);}}
 const totals=rows.reduce((sum,row)=>({windows:sum.windows+(row.input_count===null?0:1),items:sum.items+Number(row.input_count??0),uniqueItems:sum.uniqueItems+Number(row.unique_input_count??0),originals:sum.originals+Number(row.original_count??0),duplicates:sum.duplicates+Number(row.duplicate_count??0),late:sum.late+Number(row.late_count??0),revisions:sum.revisions+Number(row.revision_count??0),reversalCandidates:sum.reversalCandidates+Number(row.reversal_candidate_count??0),activeLeases:sum.activeLeases+Number(row.active_lease??0)}),{windows:0,items:0,uniqueItems:0,originals:0,duplicates:0,late:0,revisions:0,reversalCandidates:0,activeLeases:0});
 const windowSummaries=rows.filter(row=>row.input_count!==null).map(row=>({timeBasis:row.time_basis,from:Number(row.window_start_ms),to:Number(row.window_end_ms),inputCount:Number(row.input_count),uniqueInputCount:Number(row.unique_input_count),duplicateCount:Number(row.duplicate_count),lateCount:Number(row.late_count),revisionCount:Number(row.revision_count),reversalCandidateCount:Number(row.reversal_candidate_count),status:'review'}));
 const continuityByTimeBasis=Object.fromEntries((['lastModifyTime','gameDate'] as const).map(timeBasis=>{const basisRanges=ranges.filter(range=>range.timeBasis===timeBasis),basisGaps=gaps.filter(gap=>gap.timeBasis===timeBasis);return [timeBasis,{observed:basisRanges.length>0,contiguous:basisRanges.length>0&&basisGaps.length===0,rangeCount:basisRanges.length,gapCount:basisGaps.length}];}));
 return {profileId:'jdb_myr',readOnly:true,fixtureStagingOnly:true,launchReady:false,walletReady:false,settlementReady:false,recoveryReady:false,playable:false,windowContinuityObserved:gaps.length===0&&ranges.length>0,continuityByTimeBasis,observedRanges:ranges,gaps,overlaps,windowSummaries,totals,
  complete:false,providerCoverageComplete:false,sourceFinalityVerified:false,closureVerified:false,merchantAuthorizationVerified:false,turnoverConnected:false,rewardConnected:false,accountingConnected:false,productionReady:false,
  blockers:['official_merchant_authorization_missing','provider_report_finality_unverified','session_closure_semantics_unverified','accounting_activation_disabled']};
}
