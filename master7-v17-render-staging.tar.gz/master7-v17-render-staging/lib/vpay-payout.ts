import {createHash,timingSafeEqual} from 'node:crypto';
import {paymentCapability} from './payment-capabilities.ts';
import {decryptWithdrawalValue,withdrawalDataKeyReady} from './withdrawal-secrets.ts';
import {walletGuardStatements,walletRiskFreeSql,walletAvailableSql} from './wallet-guard.ts';

export type VPayPayoutContext={db:D1Database;gatewayUrl?:string;payoutToken?:string;callbackToken?:string;payoutEnabled?:string;newPayoutsEnabled?:string;vpayTraderId?:string;withdrawalDataKey?:string;fetchImpl?:typeof fetch};
export type VPayPayoutInput={payoutId:string;withdrawalId:string;userId:string;accountHolder:string;accountNumber:string;bankCode:string;amountMinor:string};
type Result={status:'processing'|'succeeded'|'failed'|'review';providerReference?:string|null};

// A payout observation may alter the member's available funds or mark the
// account for reconciliation. Take the same member lock as new reservations,
// before touching the payout/withdrawal rows, without holding it over HTTP.
async function payoutBatch(c:VPayPayoutContext,userId:string,statements:D1PreparedStatement[]){
 const results=await c.db.batch([...walletGuardStatements(c.db,userId),...statements]);
 return results.slice(2);
}
function changeCount(result:unknown){const r=result as {meta?:{changes?:number};changes?:number}|undefined;return Number(r?.meta?.changes??r?.changes??0);}

const gatewayOrigin='https://master7-integration-gateway.onrender.com';
const callbackPath='/api/payment-callbacks/vpay/withdrawal';
const bankCodes:Record<string,string>={
 maybank:'MBB',cimb:'CIMB',public_bank:'PBB',rhb:'RHB',hong_leong:'HLB',ambank:'AMB',
 bank_islam:'ISLAM',bank_rakyat:'KRYT',bsn:'BSN',alliance:'ALB',affin:'AFB',ocbc:'OCBC',
 uob:'UOB',hsbc:'HSBC',standard_chartered:'SCB',agrobank:'AGRO',bank_muamalat:'BMM',
};
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const ack=(value='SUCCESS',status=200)=>new Response(value,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const secureToken=(value:unknown)=>typeof value==='string'&&Buffer.byteLength(value)>=32&&Buffer.byteLength(value)<=1024;
const constantEqual=(left:unknown,right:string)=>typeof left==='string'&&Buffer.byteLength(left)===Buffer.byteLength(right)&&timingSafeEqual(Buffer.from(left),Buffer.from(right));
const moneyMinor=(value:unknown)=>{if(typeof value==='number'&&Number.isFinite(value))value=value.toFixed(2);if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,6})\.\d{2}$/.test(value))return null;const [whole,fraction]=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction);return minor>0n&&minor<=1000000000n?minor.toString():null;};
const decimal=(minor:unknown)=>{try{const value=BigInt(String(minor));return value>0n?`${value/100n}.${String(value%100n).padStart(2,'0')}`:null;}catch{return null;}};
const reference=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,50}$/.test(value)?value:null;
const configured=(c:VPayPayoutContext)=>c.gatewayUrl===gatewayOrigin&&secureToken(c.payoutToken)&&secureToken(c.callbackToken)&&c.payoutToken!==c.callbackToken&&/^\d{1,10}$/.test(c.vpayTraderId??'')&&withdrawalDataKeyReady(c.withdrawalDataKey);

export function vpayPayoutSupportsBank(bankCode:string){return Boolean(bankCodes[bankCode]);}

export async function vpayPayoutAvailability(c:VPayPayoutContext){
 const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='vpay'").first<{status:string}>(),channelActive=channel?.status==='active',ready=configured(c),enabled=ready&&channelActive&&c.payoutEnabled==='true'&&c.newPayoutsEnabled==='true';
 const reason=!ready?'Payout security or gateway configuration is incomplete':!channelActive?'Payment channel is not active':c.payoutEnabled!=='true'?'Payout submission switch is disabled':c.newPayoutsEnabled!=='true'?'New payouts are temporarily paused':'';
 return {implemented:true,configured:ready,enabled,channelActive,submissionEnabled:enabled,reason};
}

export function vpayPayoutCapabilitySnapshot(c:VPayPayoutContext,channelActive=false){
 const ready=configured(c),enabled=ready&&channelActive&&c.payoutEnabled==='true'&&c.newPayoutsEnabled==='true';
 return paymentCapability({implemented:true,configured:ready,enabled,submissionEnabled:enabled,blockers:[...(!ready?['payout_configuration_incomplete']:[]),...(!channelActive?['channel_not_active']:[]),...(c.payoutEnabled!=='true'?['submission_disabled']:[]),...(c.newPayoutsEnabled!=='true'?['new_payouts_paused']:[])]});
}

async function gateway(c:VPayPayoutContext,path:string,payload:Record<string,unknown>){
 if(!configured(c))throw Error('PAYOUT_NOT_CONFIGURED');const url=new URL(path,c.gatewayUrl),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.fetchImpl??fetch)(url,{method:'POST',redirect:'error',signal:controller.signal,headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${c.payoutToken}`},body:JSON.stringify(payload)});
  const raw=await response.text();if(Buffer.byteLength(raw)>65536)throw Error('PAYOUT_RESPONSE_TOO_LARGE');let data:unknown;try{data=JSON.parse(raw);}catch{throw Error('PAYOUT_INVALID_JSON');}
  return {ok:response.ok,status:response.status,data:data as any};
 }finally{clearTimeout(timer);}
}

async function payoutRecord(c:VPayPayoutContext,payoutId:string){
 return c.db.prepare(`SELECT p.*,w.user_id,w.status withdrawal_status,w.bank_code,w.account_holder_encrypted,w.account_number_encrypted,w.amount_minor withdrawal_amount_minor,w.currency withdrawal_currency,w.request_key withdrawal_request_key,w.updated_by approver_id,cr.version compliance_version,cr.identity_status,cr.aml_status
  FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id LEFT JOIN manual_compliance_reviews cr ON cr.user_id=w.user_id
  WHERE p.id=? AND p.provider_id='vpay' AND w.provider_id='vpay'`).bind(payoutId).first<any>();
}

function secrets(c:VPayPayoutContext,payout:any){
 try{const accountHolder=decryptWithdrawalValue(String(payout.account_holder_encrypted),c.withdrawalDataKey),accountNumber=decryptWithdrawalValue(String(payout.account_number_encrypted),c.withdrawalDataKey);return accountHolder&&/^\d{6,20}$/.test(accountNumber)?{accountHolder,accountNumber}:null;}catch{return null;}
}

function payoutBindingValid(c:VPayPayoutContext,payout:any){
 const bound=secrets(c,payout),fingerprint=bound?createHash('sha256').update(JSON.stringify({provider:'vpay',userId:payout.user_id,amount:String(payout.amount_minor),bank:payout.bank_code,account:createHash('sha256').update(bound.accountNumber).digest('hex')})).digest('hex'):'';
 return !!bound&&payout.fingerprint===fingerprint&&payout.request_key===payout.withdrawal_request_key&&String(payout.withdrawal_amount_minor)===String(payout.amount_minor)&&payout.withdrawal_currency==='MYR'&&payout.currency==='MYR'&&(payout.provider_reference==null||payout.provider_reference===payout.id);
}

async function payoutResult(c:VPayPayoutContext,payout:any):Promise<Result>{
 const current=await payoutRecord(c,payout.id);
 if(!current)return {status:'review',providerReference:payout.provider_reference??payout.id};
 const held=await c.db.prepare("SELECT user_id,amount_minor FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(current.withdrawal_id).first<{user_id:string;amount_minor:string|number}>();
 const bindingValid=payoutBindingValid(c,current);
 if(bindingValid&&current.provider_reference===current.id&&current.status==='succeeded'&&current.create_outcome==='accepted'&&current.withdrawal_status==='paid'&&!current.last_error_code&&!held)return {status:'succeeded',providerReference:current.provider_reference??current.id};
 if(current.status==='review')return {status:'review',providerReference:current.provider_reference??current.id};
 if(bindingValid&&['prepared','submitting','processing'].includes(current.status)&&['pending','approved','processing'].includes(current.withdrawal_status)&&held!==null&&held.user_id===current.user_id&&String(held.amount_minor)===String(current.amount_minor))return {status:'processing',providerReference:current.provider_reference??current.id};
 // Includes historical terminal-state inconsistencies: never present them as success.
 return {status:'review',providerReference:current.provider_reference??current.id};
}

async function toReview(c:VPayPayoutContext,payout:any,code:string):Promise<Result>{
 const now=Math.floor(Date.now()/1000),marker=`review_${crypto.randomUUID()}`;
 await payoutBatch(c,payout.user_id,[
  c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code=?,updated_at=? WHERE id=? AND status IN ('prepared','submitting','processing','succeeded','failed','review') AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(marker,now,payout.id,payout.user_id),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND user_id=? AND status IN ('pending','approved') AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.withdrawal_id=withdrawal_requests.id AND p.status='review' AND p.last_error_code=?)").bind(now,payout.withdrawal_id,payout.user_id,payout.id,marker),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'vpay_payout_review',?,? WHERE EXISTS (SELECT 1 FROM provider_payouts WHERE id=? AND status='review' AND last_error_code=?)").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,now,payout.id,marker),
  c.db.prepare("UPDATE provider_payouts SET last_error_code=? WHERE id=? AND status='review' AND last_error_code=?").bind(code,payout.id,marker),
 ]);
 return payoutResult(c,payout);
}

// A reported failure, rejection or reversal can conflict with an already
// submitted transfer. Do not release held funds or undo an established debit.
async function failed(c:VPayPayoutContext,payout:any,code:string):Promise<Result>{
 return toReview(c,payout,code);
}

async function succeeded(c:VPayPayoutContext,payout:any):Promise<Result>{
 if(!payoutBindingValid(c,payout))return toReview(c,payout,'payout_binding_mismatch');
 const now=Math.floor(Date.now()/1000),marker=`paid_${crypto.randomUUID()}`;
 await payoutBatch(c,payout.user_id,[
  c.db.prepare(`UPDATE provider_payouts SET status='succeeded',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),last_error_code=?,updated_at=?,completed_at=COALESCE(completed_at,?)
   WHERE id=? AND status IN ('submitting','processing') AND (provider_reference IS NULL OR provider_reference=?) AND EXISTS (
    SELECT 1 FROM withdrawal_requests w JOIN wallet_reservations r ON r.reference_id=w.id AND r.kind='withdrawal' AND r.user_id=w.user_id AND r.amount_minor=w.amount_minor
    WHERE w.id=provider_payouts.withdrawal_id AND w.provider_id='vpay' AND w.currency='MYR' AND provider_payouts.currency='MYR' AND w.amount_minor=provider_payouts.amount_minor AND w.user_id=? AND w.bank_code=? AND w.account_holder_encrypted=? AND w.account_number_encrypted=? AND provider_payouts.fingerprint=? AND w.status IN ('pending','approved','processing'))`).bind(payout.id,marker,now,now,payout.id,payout.id,payout.user_id,payout.bank_code,payout.account_holder_encrypted,payout.account_number_encrypted,payout.fingerprint),
  c.db.prepare("UPDATE withdrawal_requests SET status='paid',updated_at=? WHERE id=? AND status IN ('pending','approved','processing') AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.withdrawal_id=withdrawal_requests.id AND p.status='succeeded' AND p.last_error_code=?)").bind(now,payout.withdrawal_id,payout.id,marker),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=? AND EXISTS (SELECT 1 FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id WHERE p.id=? AND p.status='succeeded' AND p.last_error_code=? AND w.id=wallet_reservations.reference_id AND w.user_id=wallet_reservations.user_id AND w.amount_minor=wallet_reservations.amount_minor AND w.status='paid')").bind(payout.withdrawal_id,payout.id,marker),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'vpay_payout_paid',?,? WHERE EXISTS (SELECT 1 FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id WHERE p.id=? AND p.status='succeeded' AND p.last_error_code=? AND w.status='paid')").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,now,payout.id,marker),
  c.db.prepare("UPDATE provider_payouts SET last_error_code=NULL WHERE id=? AND status='succeeded' AND last_error_code=?").bind(payout.id,marker),
 ]);
 const current=await payoutResult(c,payout);
 if(current.status==='review')return toReview(c,payout,'withdrawal_state_conflict');
 return current;
}

async function reversed(c:VPayPayoutContext,payout:any):Promise<Result>{
 return toReview(c,payout,'provider_reversal_review');
}

async function reconcile(c:VPayPayoutContext,payoutId:string):Promise<Result>{
 const payout=await payoutRecord(c,payoutId);if(!payout)throw Error('PAYOUT_NOT_FOUND');
 const amount=decimal(payout.amount_minor);if(!amount||!secrets(c,payout))return toReview(c,payout,'payout_binding_unavailable');
 const response=await gateway(c,'/platform/vpay/withdrawal-query',{contract:'vpay-payout-query-v1',outMoneyId:payout.id});
 const envelope=response.data?.result,data=envelope?.data,state=String(data?.state??''),returned=reference(data?.out_money_id),returnedAmount=moneyMinor(data?.amount);
 if(!response.ok||(envelope?.code!==0&&envelope?.code!=='0'))throw Error('PAYOUT_QUERY_FAILED');
 if(returned!==payout.id||returnedAmount!==String(payout.amount_minor)||(payout.provider_reference&&payout.provider_reference!==returned))return toReview(c,payout,'query_binding_mismatch');
 if(state==='3')return succeeded(c,payout);if(state==='2')return failed(c,payout,'provider_rejected');if(state==='5')return toReview(c,payout,'provider_exception');if(state==='6')return reversed(c,payout);
 if(!['1','4'].includes(state))return toReview(c,payout,'unknown_provider_state');
 const now=Math.floor(Date.now()/1000);await payoutBatch(c,payout.user_id,[
  c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),last_error_code=NULL,updated_at=? WHERE id=? AND status IN ('prepared','submitting','processing') AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(payout.id,now,payout.id,payout.user_id),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND user_id=? AND status IN ('pending','approved','processing')").bind(now,payout.withdrawal_id,payout.user_id),
 ]);return payoutResult(c,payout);
}

export async function submitVPayPayout(input:VPayPayoutInput,c:VPayPayoutContext):Promise<Result>{
 const payout=await payoutRecord(c,input.payoutId),mapped=bankCodes[input.bankCode],amount=decimal(input.amountMinor);if(!payout||!mapped||!amount)return {status:'review'};
 const bound=secrets(c,payout);if(!bound||payout.withdrawal_id!==input.withdrawalId||payout.user_id!==input.userId||String(payout.amount_minor)!==input.amountMinor||payout.bank_code!==input.bankCode||bound.accountHolder!==input.accountHolder||bound.accountNumber!==input.accountNumber)return toReview(c,payout,'submission_binding_mismatch');
 if(payout.status!=='prepared')return payoutResult(c,payout);
 if(!payoutBindingValid(c,payout)||payout.identity_status!=='passed'||payout.aml_status!=='passed'||!payout.compliance_version)return {status:'review'};
 const snapshot=[payout.withdrawal_id,payout.id,payout.user_id,payout.provider_id,payout.request_key,String(payout.amount_minor),payout.currency,payout.bank_code,payout.account_holder_encrypted,payout.account_number_encrypted,payout.fingerprint,String(payout.compliance_version)];
 const claimMarker=`claim_${crypto.randomUUID()}`;
 const now=Math.floor(Date.now()/1000),[memberLocked,ownerLocked,locked,complianceLocked,claim,processing,cleared]=await payoutBatch(c,payout.user_id,[
  // Lock the withdrawal row as well as the member before checking approval.
  c.db.prepare("UPDATE users SET approved=approved WHERE id=? AND approved=1 AND role='member'").bind(payout.user_id),
  c.db.prepare("UPDATE users SET approved=approved WHERE id=? AND approved=1 AND role='owner'").bind(payout.approver_id),
  c.db.prepare("UPDATE withdrawal_requests SET updated_at=updated_at WHERE id=? AND user_id=? AND status='approved'").bind(payout.withdrawal_id,payout.user_id),
  c.db.prepare("UPDATE manual_compliance_reviews SET updated_at=updated_at WHERE user_id=? AND version=? AND identity_status='passed' AND aml_status='passed'").bind(payout.user_id,payout.compliance_version),
  c.db.prepare(`UPDATE provider_payouts SET status='submitting',create_outcome='in_flight',last_error_code=?,updated_at=?
   WHERE id=? AND withdrawal_id=? AND provider_id=? AND status='prepared' AND create_outcome='not_submitted' AND provider_reference IS NULL
   AND request_key=? AND fingerprint=? AND amount_minor=CAST(? AS BIGINT) AND currency='MYR'
   AND EXISTS (SELECT 1 FROM withdrawal_requests w
    JOIN wallet_reservations r ON r.reference_id=w.id AND r.user_id=w.user_id AND r.kind='withdrawal' AND r.amount_minor=w.amount_minor
    JOIN audit requested ON requested.id=('withdrawal_request_v1_' || w.id) AND requested.event='withdrawal_requested_v1' AND requested.target=w.id AND requested.user_id=w.user_id
    JOIN audit approved ON approved.id=('withdrawal_approved_v1_' || w.id) AND approved.event='withdrawal_approved_v1' AND approved.target=w.id AND approved.user_id=w.updated_by AND approved.user_id=?
    JOIN audit binding ON binding.id=? AND binding.event='withdrawal_approval_binding_v1' AND binding.target=w.id AND binding.user_id=w.updated_by
    JOIN users member ON member.id=w.user_id AND member.role='member' AND member.approved=1
    JOIN users owner ON owner.id=approved.user_id AND owner.role='owner' AND owner.approved=1
    JOIN manual_compliance_reviews cr ON cr.user_id=w.user_id AND cr.version=? AND cr.identity_status='passed' AND cr.aml_status='passed'
    WHERE w.id=provider_payouts.withdrawal_id AND w.status='approved' AND w.user_id=? AND w.provider_id=provider_payouts.provider_id
     AND w.request_key=provider_payouts.request_key AND w.amount_minor=provider_payouts.amount_minor AND w.currency=provider_payouts.currency
     AND w.bank_code=? AND w.account_holder_encrypted=? AND w.account_number_encrypted=?
     AND EXISTS (SELECT 1 FROM (SELECT w.user_id AS id) m WHERE ${walletRiskFreeSql} AND ${walletAvailableSql}>=0))`).bind(claimMarker,now,payout.id,payout.withdrawal_id,payout.provider_id,payout.request_key,payout.fingerprint,String(payout.amount_minor),payout.approver_id,`withdrawal_approval_binding_v1_${payout.withdrawal_id}_${createHash('sha256').update(JSON.stringify(snapshot)).digest('hex')}`,payout.compliance_version,payout.user_id,payout.bank_code,payout.account_holder_encrypted,payout.account_number_encrypted),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND user_id=? AND status='approved' AND EXISTS (SELECT 1 FROM provider_payouts p WHERE p.id=? AND p.withdrawal_id=withdrawal_requests.id AND p.status='submitting' AND p.create_outcome='in_flight' AND p.last_error_code=?)").bind(now,payout.withdrawal_id,payout.user_id,payout.id,claimMarker),
  c.db.prepare("UPDATE provider_payouts SET last_error_code=NULL WHERE id=? AND status='submitting' AND last_error_code=? AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=? AND w.status='processing')").bind(payout.id,claimMarker,payout.user_id),
 ]);
 // Never submit unless both the payout claim and withdrawal transition succeed.
 if(!changeCount(memberLocked)||!changeCount(ownerLocked)||!changeCount(locked)||!changeCount(complianceLocked)||!changeCount(claim))return payoutResult(c,payout);
 if(!changeCount(processing)||!changeCount(cleared))return {status:'review' as const};
 try{
  const response=await gateway(c,'/platform/vpay/withdrawal',{contract:'vpay-payout-v1',currency:'MYR',refId:payout.id,amount,bankName:mapped,accountName:bound.accountHolder,accountNumber:bound.accountNumber}),envelope=response.data?.result,data=envelope?.data,returned=reference(data?.out_money_id);
  if(!response.ok){if([400,401,403,503].includes(response.status)||(response.data?.provider==='vpay'&&envelope?.code!==undefined))return failed(c,payout,'provider_submission_rejected');throw Error('PAYOUT_SUBMISSION_UNKNOWN');}
  if((envelope?.code!==0&&envelope?.code!=='0')||returned!==payout.id||!reference(data?.money_id))return toReview(c,payout,'create_binding_mismatch');
  await payoutBatch(c,payout.user_id,[c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='accepted',provider_reference=?,last_error_code=NULL,updated_at=? WHERE id=? AND status='submitting' AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(returned,Math.floor(Date.now()/1000),payout.id,payout.user_id)]);
  try{return await reconcile(c,payout.id);}catch{return {status:'processing',providerReference:returned};}
 }catch{
  await payoutBatch(c,payout.user_id,[c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='unknown',last_error_code='submission_outcome_unknown',updated_at=? WHERE id=? AND status='submitting' AND EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=provider_payouts.withdrawal_id AND w.user_id=?)").bind(Math.floor(Date.now()/1000),payout.id,payout.user_id)]);return {status:'processing'};
 }
}

export async function recoverVPayPayouts(c:VPayPayoutContext,limit=25){
 const summary={provider:'vpay',enabled:configured(c),queried:0,succeeded:0,failed:0,processing:0,review:0,errors:0};if(!summary.enabled)return summary;
 const rows=await c.db.prepare("SELECT id FROM provider_payouts WHERE provider_id='vpay' AND status IN ('submitting','processing') ORDER BY updated_at,id LIMIT ?").bind(Math.max(1,Math.min(100,limit))).all<{id:string}>();
 for(const row of rows.results??[]){summary.queried++;try{const result=await reconcile(c,row.id);summary[result.status]++;}catch{summary.errors++;}}return summary;
}

export async function handleVPayPayoutCallback(req:Request,c:VPayPayoutContext):Promise<Response|null>{
 const url=new URL(req.url);if(url.pathname!==callbackPath)return null;if(req.method==='GET')return json({ok:true,provider:'vpay',callback:'withdrawal',active:configured(c),settlementVerified:false});if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(!configured(c))return ack('UNAVAILABLE',503);const authorization=req.headers.get('authorization')??'',given=authorization.startsWith('Bearer ')?authorization.slice(7):'';if(!constantEqual(given,c.callbackToken!))return ack('UNAUTHORIZED',401);
 let data:any;try{data=await req.json();}catch{return ack('INVALID',400);}if(!data||typeof data!=='object'||Array.isArray(data))return ack('INVALID',400);
 const payoutId=reference(data.out_money_id),amount=moneyMinor(data.amount),state=String(data.state??'');if(!payoutId||!amount||!['1','2','3','4','5','6'].includes(state)||String(data.trader_id)!==c.vpayTraderId)return ack('INVALID',400);
 const payout=await payoutRecord(c,payoutId);if(!payout)return ack('UNKNOWN',404);if(String(payout.amount_minor)!==amount)return ack('REVIEW',409);
 const eventHash=createHash('sha256').update(JSON.stringify({payoutId,amount,state,moneyId:String(data.money_id??'')})).digest('hex');await c.db.prepare("UPDATE provider_payouts SET last_event_hash=?,updated_at=? WHERE id=? AND status<>'reversed'").bind(eventHash,Math.floor(Date.now()/1000),payout.id).run();
 try{const result=state==='5'?await toReview(c,payout,'provider_exception_callback'):await reconcile(c,payout.id);return result.status==='review'&&state!=='5'?ack('REVIEW',503):ack();}catch{return ack('PENDING',503);}
}
