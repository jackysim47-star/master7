import {createHash,timingSafeEqual} from 'node:crypto';
import {paymentCapability} from './payment-capabilities.ts';
import {decryptWithdrawalValue,withdrawalDataKeyReady} from './withdrawal-secrets.ts';

export type VPayPayoutContext={db:D1Database;gatewayUrl?:string;payoutToken?:string;callbackToken?:string;payoutEnabled?:string;vpayTraderId?:string;withdrawalDataKey?:string;fetchImpl?:typeof fetch};
export type VPayPayoutInput={payoutId:string;withdrawalId:string;userId:string;accountHolder:string;accountNumber:string;bankCode:string;amountMinor:string};
type Result={status:'processing'|'succeeded'|'failed'|'review';providerReference?:string|null};

const gatewayOrigin='https://master7-integration-gateway.onrender.com';
const callbackPath='/api/payment-callbacks/vpay/withdrawal';
const bankCodes:Record<string,string>={
 maybank:'MBB',cimb:'CIMB',public_bank:'PBB',rhb:'RHB',hong_leong:'HLB',ambank:'AMB',
 bank_islam:'ISLAM',bank_rakyat:'KRYT',bsn:'BSN',alliance:'ALB',affin:'AFB',ocbc:'OCBC',
 uob:'UOB',hsbc:'HSBC',standard_chartered:'SCB',agrobank:'AGRO',bank_muamalat:'BMM',
};
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const ack=(value='SUCCESS',status=200)=>new Response(value,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const secureToken=(value:unknown)=>typeof value==='string'&&Buffer.byteLength(value)>=32&&Buffer.byteLength(value)<=1024;
const constantEqual=(left:unknown,right:string)=>typeof left==='string'&&Buffer.byteLength(left)===Buffer.byteLength(right)&&timingSafeEqual(Buffer.from(left),Buffer.from(right));
const moneyMinor=(value:unknown)=>{if(typeof value==='number'&&Number.isFinite(value))value=value.toFixed(2);if(typeof value!=='string'||!/^(?:0|[1-9]\d{0,6})\.\d{2}$/.test(value))return null;const [whole,fraction]=value.split('.'),minor=BigInt(whole)*100n+BigInt(fraction);return minor>0n&&minor<=1000000000n?minor.toString():null;};
const decimal=(minor:unknown)=>{try{const value=BigInt(String(minor));return value>0n?`${value/100n}.${String(value%100n).padStart(2,'0')}`:null;}catch{return null;}};
const reference=(value:unknown)=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,50}$/.test(value)?value:null;
const configured=(c:VPayPayoutContext)=>c.gatewayUrl===gatewayOrigin&&secureToken(c.payoutToken)&&secureToken(c.callbackToken)&&c.payoutToken!==c.callbackToken&&/^\d{1,10}$/.test(c.vpayTraderId??'')&&withdrawalDataKeyReady(c.withdrawalDataKey);

export function vpayPayoutSupportsBank(bankCode:string){return Boolean(bankCodes[bankCode]);}

export async function vpayPayoutAvailability(c:VPayPayoutContext){
 const channel=await c.db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='vpay'").first<{status:string}>(),channelActive=channel?.status==='active',ready=configured(c),enabled=ready&&channelActive&&c.payoutEnabled==='true';
 const reason=!ready?'Payout security or gateway configuration is incomplete':!channelActive?'Payment channel is not active':c.payoutEnabled!=='true'?'Payout submission switch is disabled':'';
 return {implemented:true,configured:ready,enabled,channelActive,submissionEnabled:enabled,reason};
}

export function vpayPayoutCapabilitySnapshot(c:VPayPayoutContext,channelActive=false){
 const ready=configured(c),enabled=ready&&channelActive&&c.payoutEnabled==='true';
 return paymentCapability({implemented:true,configured:ready,enabled,submissionEnabled:enabled,blockers:[...(!ready?['payout_configuration_incomplete']:[]),...(!channelActive?['channel_not_active']:[]),...(c.payoutEnabled!=='true'?['submission_disabled']:[])]});
}

async function gateway(c:VPayPayoutContext,path:string,payload:Record<string,unknown>){
 if(!configured(c))throw Error('PAYOUT_NOT_CONFIGURED');const url=new URL(path,c.gatewayUrl),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.fetchImpl??fetch)(url,{method:'POST',redirect:'error',signal:controller.signal,headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${c.payoutToken}`},body:JSON.stringify(payload)});
  const raw=await response.text();if(Buffer.byteLength(raw)>65536)throw Error('PAYOUT_RESPONSE_TOO_LARGE');let data:unknown;try{data=JSON.parse(raw);}catch{throw Error('PAYOUT_INVALID_JSON');}
  return {ok:response.ok,status:response.status,data:data as any};
 }finally{clearTimeout(timer);}
}

async function payoutRecord(c:VPayPayoutContext,payoutId:string){
 return c.db.prepare(`SELECT p.*,w.user_id,w.status withdrawal_status,w.bank_code,w.account_holder_encrypted,w.account_number_encrypted,w.amount_minor withdrawal_amount_minor
  FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id
  WHERE p.id=? AND p.provider_id='vpay' AND w.provider_id='vpay'`).bind(payoutId).first<any>();
}

function secrets(c:VPayPayoutContext,payout:any){
 try{const accountHolder=decryptWithdrawalValue(String(payout.account_holder_encrypted),c.withdrawalDataKey),accountNumber=decryptWithdrawalValue(String(payout.account_number_encrypted),c.withdrawalDataKey);return accountHolder&&/^\d{6,20}$/.test(accountNumber)?{accountHolder,accountNumber}:null;}catch{return null;}
}

async function toReview(c:VPayPayoutContext,payout:any,code:string):Promise<Result>{
 const now=Math.floor(Date.now()/1000);await c.db.batch([
  c.db.prepare("UPDATE provider_payouts SET status='review',last_error_code=?,updated_at=? WHERE id=? AND status<>'succeeded'").bind(code,now,payout.id),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status IN ('pending','approved','processing')").bind(now,payout.withdrawal_id),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)").bind(crypto.randomUUID(),payout.user_id,'vpay_payout_review',payout.withdrawal_id,now),
 ]);return {status:'review',providerReference:payout.provider_reference??payout.id};
}

async function failed(c:VPayPayoutContext,payout:any,code:string):Promise<Result>{
 if(payout.status==='succeeded'||payout.withdrawal_status==='paid')return toReview(c,payout,'late_failure_after_success');
 const now=Math.floor(Date.now()/1000);await c.db.batch([
  c.db.prepare("UPDATE provider_payouts SET status='failed',create_outcome='rejected',provider_reference=COALESCE(provider_reference,?),last_error_code=?,updated_at=?,completed_at=COALESCE(completed_at,?) WHERE id=? AND status IN ('prepared','submitting','processing','failed')").bind(payout.id,code,now,now,payout.id),
  c.db.prepare("UPDATE withdrawal_requests SET status='rejected',updated_at=? WHERE id=? AND status IN ('pending','approved','processing')").bind(now,payout.withdrawal_id),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(payout.withdrawal_id),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)").bind(crypto.randomUUID(),payout.user_id,'vpay_payout_failed',payout.withdrawal_id,now),
 ]);return {status:'failed',providerReference:payout.id};
}

async function succeeded(c:VPayPayoutContext,payout:any):Promise<Result>{
 if(payout.status==='succeeded'&&payout.withdrawal_status==='paid')return {status:'succeeded',providerReference:payout.id};
 if(!['pending','approved','processing','paid'].includes(payout.withdrawal_status))return toReview(c,payout,'withdrawal_state_conflict');
 const now=Math.floor(Date.now()/1000);await c.db.batch([
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) SELECT ?,?,'vpay_payout_paid',?,? WHERE EXISTS (SELECT 1 FROM provider_payouts WHERE id=? AND status<>'succeeded')").bind(crypto.randomUUID(),payout.user_id,payout.withdrawal_id,now,payout.id),
  c.db.prepare("UPDATE provider_payouts SET status='succeeded',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),last_error_code=NULL,updated_at=?,completed_at=COALESCE(completed_at,?) WHERE id=? AND status IN ('submitting','processing','succeeded')").bind(payout.id,now,now,payout.id),
  c.db.prepare("UPDATE withdrawal_requests SET status='paid',updated_at=? WHERE id=? AND status IN ('pending','approved','processing','paid')").bind(now,payout.withdrawal_id),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(payout.withdrawal_id),
 ]);return {status:'succeeded',providerReference:payout.id};
}

async function reversed(c:VPayPayoutContext,payout:any):Promise<Result>{
 if(payout.status!=='succeeded'&&payout.status!=='reversed')return toReview(c,payout,'reversal_before_success');
 const now=Math.floor(Date.now()/1000);await c.db.batch([
  c.db.prepare("UPDATE provider_payouts SET status='reversed',last_error_code='provider_reversed',updated_at=?,completed_at=COALESCE(completed_at,?) WHERE id=? AND status IN ('succeeded','reversed')").bind(now,now,payout.id),
  c.db.prepare("UPDATE withdrawal_requests SET status='cancelled',owner_note='Provider reversed payout',updated_at=? WHERE id=? AND status='paid'").bind(now,payout.withdrawal_id),
  c.db.prepare("DELETE FROM wallet_reservations WHERE kind='withdrawal' AND reference_id=?").bind(payout.withdrawal_id),
  c.db.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)").bind(crypto.randomUUID(),payout.user_id,'vpay_payout_reversed',payout.withdrawal_id,now),
 ]);return {status:'failed',providerReference:payout.id};
}

async function reconcile(c:VPayPayoutContext,payoutId:string):Promise<Result>{
 const payout=await payoutRecord(c,payoutId);if(!payout)throw Error('PAYOUT_NOT_FOUND');
 const amount=decimal(payout.amount_minor);if(!amount||!secrets(c,payout))return toReview(c,payout,'payout_binding_unavailable');
 const response=await gateway(c,'/platform/vpay/withdrawal-query',{contract:'vpay-payout-query-v1',outMoneyId:payout.id});
 const envelope=response.data?.result,data=envelope?.data,state=String(data?.state??''),returned=reference(data?.out_money_id),returnedAmount=moneyMinor(data?.amount);
 if(!response.ok||(envelope?.code!==0&&envelope?.code!=='0'))throw Error('PAYOUT_QUERY_FAILED');
 if(returned!==payout.id||returnedAmount!==String(payout.amount_minor)||(payout.provider_reference&&payout.provider_reference!==returned))return toReview(c,payout,'query_binding_mismatch');
 if(state==='3')return succeeded(c,payout);if(state==='2')return failed(c,payout,'provider_rejected');if(state==='5')return toReview(c,payout,'provider_exception');if(state==='6')return reversed(c,payout);
 if(!['1','4'].includes(state))return toReview(c,payout,'unknown_provider_state');
 const now=Math.floor(Date.now()/1000);await c.db.batch([
  c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='accepted',provider_reference=COALESCE(provider_reference,?),last_error_code=NULL,updated_at=? WHERE id=? AND status IN ('prepared','submitting','processing')").bind(payout.id,now,payout.id),
  c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status IN ('pending','approved','processing')").bind(now,payout.withdrawal_id),
 ]);return {status:'processing',providerReference:payout.id};
}

export async function submitVPayPayout(input:VPayPayoutInput,c:VPayPayoutContext):Promise<Result>{
 const payout=await payoutRecord(c,input.payoutId),mapped=bankCodes[input.bankCode],amount=decimal(input.amountMinor);if(!payout||!mapped||!amount)return {status:'review'};
 const bound=secrets(c,payout);if(!bound||payout.withdrawal_id!==input.withdrawalId||payout.user_id!==input.userId||String(payout.amount_minor)!==input.amountMinor||payout.bank_code!==input.bankCode||bound.accountHolder!==input.accountHolder||bound.accountNumber!==input.accountNumber)return toReview(c,payout,'submission_binding_mismatch');
 if(payout.status!=='prepared')return payout.status==='succeeded'?{status:'succeeded',providerReference:payout.provider_reference}:{status:payout.status==='failed'?'failed':payout.status==='review'?'review':'processing',providerReference:payout.provider_reference};
 const now=Math.floor(Date.now()/1000),claim=await c.db.prepare("UPDATE provider_payouts SET status='submitting',create_outcome='in_flight',updated_at=? WHERE id=? AND status='prepared' RETURNING id").bind(now,payout.id).first();if(!claim)return {status:'processing'};
 await c.db.prepare("UPDATE withdrawal_requests SET status='processing',updated_at=? WHERE id=? AND status='pending'").bind(now,payout.withdrawal_id).run();
 try{
  const response=await gateway(c,'/platform/vpay/withdrawal',{contract:'vpay-payout-v1',currency:'MYR',refId:payout.id,amount,bankName:mapped,accountName:bound.accountHolder,accountNumber:bound.accountNumber}),envelope=response.data?.result,data=envelope?.data,returned=reference(data?.out_money_id);
  if(!response.ok){if([400,401,403,503].includes(response.status)||(response.data?.provider==='vpay'&&envelope?.code!==undefined))return failed(c,payout,'provider_submission_rejected');throw Error('PAYOUT_SUBMISSION_UNKNOWN');}
  if((envelope?.code!==0&&envelope?.code!=='0')||returned!==payout.id||!reference(data?.money_id))return toReview(c,payout,'create_binding_mismatch');
  await c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='accepted',provider_reference=?,last_error_code=NULL,updated_at=? WHERE id=? AND status='submitting'").bind(returned,Math.floor(Date.now()/1000),payout.id).run();
  try{return await reconcile(c,payout.id);}catch{return {status:'processing',providerReference:returned};}
 }catch{
  await c.db.prepare("UPDATE provider_payouts SET status='processing',create_outcome='unknown',last_error_code='submission_outcome_unknown',updated_at=? WHERE id=? AND status='submitting'").bind(Math.floor(Date.now()/1000),payout.id).run();return {status:'processing'};
 }
}

export async function recoverVPayPayouts(c:VPayPayoutContext,limit=25){
 const summary={provider:'vpay',enabled:configured(c),queried:0,succeeded:0,failed:0,processing:0,review:0,errors:0};if(!summary.enabled)return summary;
 const rows=await c.db.prepare("SELECT id FROM provider_payouts WHERE provider_id='vpay' AND status IN ('submitting','processing') ORDER BY updated_at,id LIMIT ?").bind(Math.max(1,Math.min(100,limit))).all<{id:string}>();
 for(const row of rows.results??[]){summary.queried++;try{const result=await reconcile(c,row.id);summary[result.status]++;}catch{summary.errors++;}}return summary;
}

export async function handleVPayPayoutCallback(req:Request,c:VPayPayoutContext):Promise<Response|null>{
 const url=new URL(req.url);if(url.pathname!==callbackPath)return null;if(req.method==='GET')return json({ok:true,provider:'vpay',callback:'withdrawal',active:configured(c),settlementVerified:false});if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(!configured(c))return ack('UNAVAILABLE',503);const authorization=req.headers.get('authorization')??'',given=authorization.startsWith('Bearer ')?authorization.slice(7):'';if(!constantEqual(given,c.callbackToken!))return ack('UNAUTHORIZED',401);
 let data:any;try{data=await req.json();}catch{return ack('INVALID',400);}if(!data||typeof data!=='object'||Array.isArray(data))return ack('INVALID',400);
 const payoutId=reference(data.out_money_id),amount=moneyMinor(data.amount),state=String(data.state??'');if(!payoutId||!amount||!['1','2','3','4','5','6'].includes(state)||String(data.trader_id)!==c.vpayTraderId)return ack('INVALID',400);
 const payout=await payoutRecord(c,payoutId);if(!payout)return ack('UNKNOWN',404);if(String(payout.amount_minor)!==amount)return ack('REVIEW',409);
 const eventHash=createHash('sha256').update(JSON.stringify({payoutId,amount,state,moneyId:String(data.money_id??'')})).digest('hex');await c.db.prepare("UPDATE provider_payouts SET last_event_hash=?,updated_at=? WHERE id=? AND status<>'reversed'").bind(eventHash,Math.floor(Date.now()/1000),payout.id).run();
 try{const result=state==='5'?await toReview(c,payout,'provider_exception_callback'):await reconcile(c,payout.id);return result.status==='review'&&state!=='5'?ack('REVIEW',503):ack();}catch{return ack('PENDING',503);}
}
