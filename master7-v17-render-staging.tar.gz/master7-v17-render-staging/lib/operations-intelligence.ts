export type OperationsWindow={period:'day'|'week'|'month';start:number;end:number;label:string};
export type OperationsReadiness={
 productionReady?:boolean;
 paymentsReady?:boolean;
 payoutsReady?:boolean;
 settlementVerified?:boolean;
 gamesReady?:boolean;
 whatsappReady?:boolean;
 supportAiProviderReady?:boolean;
 expectedCatalogueIds?:readonly string[];
};

type AggregateRow=Record<string,unknown>;
type Severity='critical'|'high'|'medium'|'low';
const MYT_OFFSET=8*3600,DAY=86400;

const rows=async(db:D1Database,sql:string,...values:(string|number)[])=>((await db.prepare(sql).bind(...values).all()).results??[]) as AggregateRow[];
const integer=(value:unknown)=>Number.isSafeInteger(Number(value))?Number(value):0;
const amount=(value:unknown)=>String(value??'0');

function validateWindow(window:OperationsWindow){
 if(!window||!['day','week','month'].includes(window.period)||typeof window.label!=='string'||window.label.length<1||window.label.length>80||!Number.isSafeInteger(window.start)||!Number.isSafeInteger(window.end)||window.start<0||window.end<=window.start||window.end-window.start>86400*32)throw new Error('Invalid operations report window');
}

function catalogueInventory(value:unknown){
 if(value===undefined)return [];
 if(!Array.isArray(value)||value.length>100||value.some(item=>typeof item!=='string'||!/^[a-z0-9_-]{1,40}$/.test(item))||new Set(value).size!==value.length)throw new Error('Invalid expected catalogue inventory');
 return [...value] as string[];
}

export function operationsWindow(period:unknown='day',at=Math.floor(Date.now()/1000)):OperationsWindow{
 if(!['day','week','month'].includes(String(period))||!Number.isSafeInteger(at)||at<0)throw new Error('Invalid operations report period');
 const selected=String(period) as OperationsWindow['period'],shifted=new Date((at+MYT_OFFSET)*1000),dayStart=Math.floor((at+MYT_OFFSET)/DAY)*DAY-MYT_OFFSET;
 let start:number,label:string;
 if(selected==='week'){
  const sinceMonday=(shifted.getUTCDay()+6)%7;start=dayStart-sinceMonday*DAY;label=`Week of ${new Date((start+MYT_OFFSET)*1000).toISOString().slice(0,10)}`;
 }else if(selected==='month'){
  start=Math.floor(Date.UTC(shifted.getUTCFullYear(),shifted.getUTCMonth(),1)/1000)-MYT_OFFSET;label=`${shifted.getUTCFullYear()}-${String(shifted.getUTCMonth()+1).padStart(2,'0')}`;
 }else{start=dayStart;label=new Date((start+MYT_OFFSET)*1000).toISOString().slice(0,10);}
 return {period:selected,start,end:at+1,label};
}

function recommendation(id:string,severity:Severity,title:string,reason:string,evidence:Record<string,string|number|boolean|null>,recommendedAction:string){
 return {id,severity,title,reason,evidence,recommendedAction,approvalRequired:true,automaticAction:false,status:'open' as const};
}

export async function operationsIntelligenceReport(db:D1Database,window:OperationsWindow,readiness:OperationsReadiness={},generatedAt=Math.floor(Date.now()/1000)){
 validateWindow(window);
 if(!Number.isSafeInteger(generatedAt)||generatedAt<0)throw new Error('Invalid operations report time');
 const [memberRow,depositActivityRow,depositSettledRow,depositBacklogRow,depositStatuses,withdrawalActivityRow,withdrawalSettledRow,withdrawalBacklogRow,withdrawalStatuses,bankRow,manualRow,ticketRow,sessionActivityRow,sessionBacklogRow,catalogueRows,providerRow,marketingRows,contactRow,ledgerRow,benefitRow,commissionRow]=await Promise.all([
  db.prepare("SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN approved=1 THEN 1 ELSE 0 END),0) approved,COALESCE(SUM(CASE WHEN created_at>=? AND created_at<? THEN 1 ELSE 0 END),0) new_members FROM users WHERE role='member'").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,COALESCE(SUM(CASE WHEN status IN ('pending','creating','created','review') THEN 1 ELSE 0 END),0) pending,COALESCE(SUM(CASE WHEN status='unknown' THEN 1 ELSE 0 END),0) unknown_count,COALESCE(SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END),0) failed FROM deposit_orders WHERE created_at>=? AND created_at<?").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount_minor FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<?").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COALESCE(SUM(CASE WHEN status IN ('pending','creating','created','review') THEN 1 ELSE 0 END),0) pending,COALESCE(SUM(CASE WHEN status='unknown' THEN 1 ELSE 0 END),0) unknown_count FROM deposit_orders").first<AggregateRow>(),
  rows(db,"SELECT status,COUNT(*) count FROM deposit_orders WHERE created_at>=? AND created_at<? GROUP BY status ORDER BY status",window.start,window.end),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,COALESCE(SUM(CASE WHEN status IN ('pending','approved','processing') THEN 1 ELSE 0 END),0) pending FROM withdrawal_requests WHERE created_at>=? AND created_at<?").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount_minor FROM withdrawal_requests WHERE status='paid' AND updated_at>=? AND updated_at<?").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) pending FROM withdrawal_requests WHERE status IN ('pending','approved','processing')").first<AggregateRow>(),
  rows(db,"SELECT status,COUNT(*) count FROM withdrawal_requests WHERE created_at>=? AND created_at<? GROUP BY status ORDER BY status",window.start,window.end),
  db.prepare('SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN enabled=1 THEN 1 ELSE 0 END),0) enabled FROM company_bank_accounts').first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) pending FROM manual_deposit_requests m JOIN deposit_orders d ON d.id=m.deposit_order_id WHERE d.status IN ('pending','review')").first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) total_open,COALESCE(SUM(CASE WHEN created_at>=? AND created_at<? THEN 1 ELSE 0 END),0) new_open FROM tickets WHERE status='open'").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) sessions,COALESCE(SUM(CASE WHEN status='settled' THEN 1 ELSE 0 END),0) settled,COALESCE(SUM(CASE WHEN status IN ('deposit_unknown','withdraw_unknown','manual_review') THEN 1 ELSE 0 END),0) review_required FROM game_wallet_sessions WHERE created_at>=? AND created_at<?").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) review_required FROM game_wallet_sessions WHERE status IN ('deposit_unknown','withdraw_unknown','manual_review')").first<AggregateRow>(),
  rows(db,'SELECT provider_id,status,checked_at,last_success_at,complete FROM game_catalogue_cache ORDER BY provider_id'),
  db.prepare('SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN visible=1 THEN 1 ELSE 0 END),0) visible FROM providers').first<AggregateRow>(),
  rows(db,'SELECT status,COUNT(*) count FROM marketing_campaigns GROUP BY status ORDER BY status'),
  db.prepare("SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN consent_status='opted_in' THEN 1 ELSE 0 END),0) opted_in,COALESCE(SUM(CASE WHEN consent_status='opted_out' THEN 1 ELSE 0 END),0) opted_out FROM marketing_contacts").first<AggregateRow>(),
  db.prepare("WITH credited AS (SELECT id,amount_minor FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<?), postings AS (SELECT c.id order_id,c.amount_minor credited_minor,COALESCE(SUM(CASE WHEN l.account_code='member' THEN l.amount_minor ELSE 0 END),0) member_minor,COALESCE(SUM(CASE WHEN l.account_code='provider_clearing' THEN l.amount_minor ELSE 0 END),0) clearing_minor,COALESCE(SUM(CASE WHEN l.account_code='member' THEN 1 ELSE 0 END),0) member_entries,COALESCE(SUM(CASE WHEN l.account_code='provider_clearing' THEN 1 ELSE 0 END),0) clearing_entries FROM credited c LEFT JOIN wallet_ledger l ON l.order_id=c.id GROUP BY c.id,c.amount_minor) SELECT COUNT(*) credited_orders,CAST(COALESCE(SUM(credited_minor),0) AS TEXT) credited_minor,CAST(COALESCE(SUM(member_minor),0) AS TEXT) member_minor,CAST(COALESCE(SUM(clearing_minor),0) AS TEXT) clearing_minor,COALESCE(SUM(CASE WHEN member_entries>0 THEN 1 ELSE 0 END),0) member_orders,COALESCE(SUM(CASE WHEN clearing_entries>0 THEN 1 ELSE 0 END),0) clearing_orders,COALESCE(SUM(CASE WHEN member_entries=1 AND clearing_entries=1 AND member_minor=credited_minor AND clearing_minor=-credited_minor THEN 0 ELSE 1 END),0) mismatch_orders FROM postings").bind(window.start,window.end).first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) awaiting FROM benefit_claims WHERE status='awaiting_acceptance'").first<AggregateRow>(),
  db.prepare("SELECT COUNT(*) preview_periods,CAST(COALESCE(SUM(total_commission_minor),0) AS TEXT) preview_minor FROM commission_periods WHERE status='preview'").first<AggregateRow>()
 ]);
 const bankEnabled=integer(bankRow?.enabled),manualPending=integer(manualRow?.pending),depositPending=integer(depositBacklogRow?.pending),depositUnknown=integer(depositBacklogRow?.unknown_count),depositFailed=integer(depositActivityRow?.failed),withdrawalPending=integer(withdrawalBacklogRow?.pending),openTickets=integer(ticketRow?.total_open),gameReview=integer(sessionBacklogRow?.review_required);
 const memberMinor=amount(ledgerRow?.member_minor),clearingMinor=amount(ledgerRow?.clearing_minor),creditedMinor=amount(ledgerRow?.credited_minor),memberOrders=integer(ledgerRow?.member_orders),clearingOrders=integer(ledgerRow?.clearing_orders),creditedOrders=integer(ledgerRow?.credited_orders),mismatchOrders=integer(ledgerRow?.mismatch_orders);
 const walletMatched=creditedOrders>0&&mismatchOrders===0,walletStatus=creditedOrders===0?'no_activity':walletMatched?'matched':'mismatch';
 const providerCards=integer(providerRow?.total),expectedCatalogueIds=catalogueInventory(readiness.expectedCatalogueIds),expectedCatalogueSet=new Set(expectedCatalogueIds),expectedCatalogueRows=catalogueRows.filter(item=>expectedCatalogueSet.has(String(item.provider_id))),cachedCatalogueIds=new Set(expectedCatalogueRows.map(item=>String(item.provider_id))),cachedCatalogues=cachedCatalogueIds.size,freshAvailableCatalogues=expectedCatalogueRows.filter(item=>String(item.status)==='available'&&integer(item.complete)===1&&integer(item.checked_at)>=generatedAt-900&&integer(item.last_success_at)>0).length,incompleteCatalogues=expectedCatalogueRows.filter(item=>String(item.status)==='available'&&integer(item.complete)!==1).length,missingCatalogues=expectedCatalogueIds.filter(id=>!cachedCatalogueIds.has(id)).length,unavailableCatalogues=expectedCatalogueRows.filter(item=>['blocked','unavailable'].includes(String(item.status))).length,staleOrEmptyCatalogues=Math.max(0,cachedCatalogues-freshAvailableCatalogues),catalogueStatus=expectedCatalogueIds.length===0?'not_configured':cachedCatalogues===0?'no_data':missingCatalogues||staleOrEmptyCatalogues?'degraded':'connected',catalogueConnectionsPending=catalogueStatus!=='connected',catalogueStatusCounts=[...expectedCatalogueRows.reduce((map,item)=>map.set(String(item.status),(map.get(String(item.status))??0)+1),new Map<string,number>())].map(([status,count])=>({status,count}));
 const productionReady=readiness.productionReady===true,paymentsReady=readiness.paymentsReady===true,payoutsReady=readiness.payoutsReady===true,settlementVerified=readiness.settlementVerified===true,gamesReady=readiness.gamesReady===true,whatsappReady=readiness.whatsappReady===true;
 const recommendations=[] as ReturnType<typeof recommendation>[];
 if(bankEnabled===0)recommendations.push(recommendation('configure_company_bank','critical','公司收款银行尚未启用','前台手工银行存款没有可展示的公司户口。',{enabledBankAccounts:0},'由 Owner 在 Bank & Deposit 录入并核对公司银行户口，再开启显示。'));
 if(creditedOrders>0&&mismatchOrders>0)recommendations.push(recommendation('review_wallet_reconciliation','critical','钱包双重记账需要复核','至少一笔已入账存款与 member/provider_clearing 分录不一致。',{creditedOrders,mismatchOrders,memberOrders,clearingOrders,creditedMinor,memberMinor,clearingMinor},'暂停相关人工入账，逐单核对 wallet_ledger；只在证据完整后修复。'));
 if(manualPending>0)recommendations.push(recommendation('review_manual_deposits','high','有银行单等待后台核对','客户已提交手工银行存款申请。',{pendingManualDeposits:manualPending},'员工核对公司银行实际到账、金额与回单后逐单批准或拒绝。'));
 if(depositPending>0)recommendations.push(recommendation('review_pending_deposits','medium','有充值订单尚未完成','仍有 pending、creating、created 或 review 状态的充值订单。',{pendingDeposits:depositPending},'检查厂家查单、回调和人工银行单；没有可信成功证据时不得入账。'));
 if(depositUnknown>0)recommendations.push(recommendation('reconcile_unknown_deposits','high','支付订单状态未知','订单没有可靠的最终支付结果。',{unknownDeposits:depositUnknown},'先查询厂家订单与回调记录；没有可信成功证据时不得入账。'));
 if(withdrawalPending>0)recommendations.push(recommendation('review_withdrawals','high','有提款等待审核','提款仍在 pending、approved 或 processing。',{pendingWithdrawals:withdrawalPending},'核对会员余额、银行资料与厂家状态后由 Owner 批准；系统不自动付款。'));
 if(!productionReady)recommendations.push(recommendation('complete_production_readiness','high','平台仍未达到正式营业条件','Canonical productionReady 状态尚未通过。',{productionReady},'完成支付、出款、结算和游戏闭环验收后，再由 Owner 决定正式营业。'));
 if(!paymentsReady)recommendations.push(recommendation('complete_payment_acceptance','high','线上充值尚未完成生产验收','真实支付渠道未全部通过创建、回调、查询及重复回调测试。',{paymentsReady},'按厂家逐家完成小额生产验收并保存证据，成功前保持未就绪状态。'));
 if(!payoutsReady)recommendations.push(recommendation('complete_payout_acceptance','high','自动出款尚未完成生产验收','出款权限、白名单、查询与回调闭环没有可信的生产验收证据。',{payoutsReady},'保持自动出款关闭；由 Owner 完成厂家小额验收及银行资料核对后再单独启用。'));
 if(!settlementVerified)recommendations.push(recommendation('verify_settlement','high','资金结算尚未验证','平台没有可信的厂家结算对账结果。',{settlementVerified},'取得厂家结算单并与订单、银行和钱包分录核对。'));
 if(!gamesReady)recommendations.push(recommendation('complete_game_acceptance','high','游戏启动与结算尚未完成验收','至少一个必要的真实启动、转入、返回与结算条件未通过。',{gamesReady},'逐家用厂家测试会员完成启动与钱包闭环；未通过的厂家保持不可玩。'));
 if(gameReview>0)recommendations.push(recommendation('review_game_wallet_sessions','high','游戏钱包会话需要人工复核','存在未知或 manual_review 的游戏钱包会话。',{reviewRequiredSessions:gameReview},'查询厂家余额与交易参考，确认资金位置后再结算。'));
 if(openTickets>0)recommendations.push(recommendation('answer_support_tickets','medium','有客户工单等待回复','客服仍有 open 工单。',{openTickets,newInWindow:integer(ticketRow?.new_open)},'由 Stephanie 草拟回复，员工核对后发送；资金与投诉问题升级人工。'));
 if(catalogueConnectionsPending)recommendations.push(recommendation('repair_catalogue_connections','medium','部分游戏目录连接异常','已配置的厂家目录没有资料、不完整、已过期，或状态不是可用。',{expectedCatalogues:expectedCatalogueIds.length,cachedCatalogues,freshAvailableCatalogues,incompleteCatalogues,missingCatalogues,unavailableCatalogues,staleOrEmptyCatalogues},'检查厂家 API、白名单与凭证；连接恢复后重新同步。'));
 if(depositFailed>0)recommendations.push(recommendation('inspect_failed_deposits','medium','本期有充值创建失败','失败订单可能影响客户充值体验。',{failedDeposits:depositFailed},'按厂家错误码汇总并排查，不要把失败订单当成已付款。'));
 if(!whatsappReady)recommendations.push(recommendation('complete_whatsapp_setup','low','WhatsApp Business 推广未就绪','正式模板、号码、权限或同意名单尚未全部验证。',{whatsappReady,optedInContacts:integer(contactRow?.opted_in)},'只向已同意联系人发送已批准模板；完成 Meta 配置后再启用。'));
 const severityOrder:Record<Severity,number>={critical:4,high:3,medium:2,low:1};
 recommendations.sort((a,b)=>severityOrder[b.severity]-severityOrder[a.severity]||a.id.localeCompare(b.id));
 const metrics={
  members:{source:'users',status:'connected',total:integer(memberRow?.total),approved:integer(memberRow?.approved),newInWindow:integer(memberRow?.new_members)},
  deposits:{source:'deposit_orders',status:'connected',createdOrders:integer(depositActivityRow?.orders),createdMembers:integer(depositActivityRow?.members),creditedOrders:integer(depositSettledRow?.orders),creditedMembers:integer(depositSettledRow?.members),creditedMinor:amount(depositSettledRow?.amount_minor),settledBy:'updated_at',pending:depositPending,unknown:depositUnknown,createdPending:integer(depositActivityRow?.pending),createdUnknown:integer(depositActivityRow?.unknown_count),failed:depositFailed,byStatus:depositStatuses.map(item=>({status:String(item.status),count:integer(item.count)}))},
  withdrawals:{source:'withdrawal_requests',status:'connected',createdOrders:integer(withdrawalActivityRow?.orders),createdMembers:integer(withdrawalActivityRow?.members),paidOrders:integer(withdrawalSettledRow?.orders),paidMembers:integer(withdrawalSettledRow?.members),paidMinor:amount(withdrawalSettledRow?.amount_minor),settledBy:'updated_at',pending:withdrawalPending,createdPending:integer(withdrawalActivityRow?.pending),byStatus:withdrawalStatuses.map(item=>({status:String(item.status),count:integer(item.count)}))},
  companyBank:{source:'company_bank_accounts',status:bankEnabled>0?'configured':'not_configured',total:integer(bankRow?.total),enabled:bankEnabled,pendingReceipts:manualPending},
  support:{source:'tickets',status:'connected',open:openTickets,newOpenInWindow:integer(ticketRow?.new_open)},
  gameWallet:{source:'game_wallet_sessions',status:gamesReady?'verified':'unverified',sessions:integer(sessionActivityRow?.sessions),settled:integer(sessionActivityRow?.settled),reviewRequired:gameReview,createdReviewRequired:integer(sessionActivityRow?.review_required)},
  catalogue:{source:'game_catalogue_cache+configured_inventory',status:catalogueStatus,providerCards,visibleProviderCards:integer(providerRow?.visible),expectedCatalogues:expectedCatalogueIds.length,cachedCatalogues,freshAvailableCatalogues,incompleteCatalogues,missingCatalogues,unavailableCatalogues,staleOrEmptyCatalogues,freshnessSeconds:900,byStatus:catalogueStatusCounts},
  marketing:{source:'marketing_campaigns+marketing_contacts',status:whatsappReady?'connected':'not_connected',campaigns:marketingRows.map(item=>({status:String(item.status),count:integer(item.count)})),contacts:{total:integer(contactRow?.total),optedIn:integer(contactRow?.opted_in),optedOut:integer(contactRow?.opted_out)}},
  rewards:{source:'benefit_claims+commission_periods',status:'preview_only',benefitClaimsAwaitingAcceptance:integer(benefitRow?.awaiting),commissionPreviewPeriods:integer(commissionRow?.preview_periods),commissionPreviewMinor:amount(commissionRow?.preview_minor),walletPostingEnabled:false},
  reconciliation:{source:'deposit_orders+wallet_ledger',status:walletStatus,matched:creditedOrders===0?null:walletMatched,creditedOrders,mismatchOrders,memberOrders,clearingOrders,creditedMinor,memberMinor,clearingMinor}
 };
 const critical=recommendations.filter(item=>item.severity==='critical').length,high=recommendations.filter(item=>item.severity==='high').length,ready=productionReady&&settlementVerified&&recommendations.length===0;
 return {
  reportType:'operations_intelligence_v1',timezone:'Asia/Kuching',generatedAt,window,
  assistant:{name:'MASTER7 AI Operations Manager',mode:'deterministic_rules',externalModelStatus:readiness.supportAiProviderReady===true?'available_not_used_for_actions':'not_connected',readOnly:true},
  control:{actionsEnabled:false,approvalRequiredForAllActions:true,automaticWalletCredit:false,automaticDepositApproval:false,automaticWithdrawalApproval:false,automaticPayout:false,automaticAccountSanction:false,automaticCampaignSend:false},
  summary:{status:critical?'critical':high?'attention':ready?'ready':'pending',productionReady,critical,high,openRecommendations:recommendations.length,statement:critical?'发现需要 Owner 立即复核的项目。':high?'平台仍有上线或日常运营项目需要处理。':ready?'真实上线条件与运营检查均已通过。':'没有高优先异常，但仍有等待连接或人工核对项目。'},
  metrics,recommendations,
  sourcePolicy:'Only persisted platform records and explicit readiness flags are used. Missing external evidence remains unverified or not_connected; no value is invented.'
 };
}
