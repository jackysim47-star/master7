import {createCipheriv,createDecipheriv,createHash,randomBytes} from 'node:crypto';

const keyBytes=(secret?:string)=>typeof secret==='string'&&Buffer.byteLength(secret)>=32&&Buffer.byteLength(secret)<=1024?createHash('sha256').update(secret).digest():null;

export const withdrawalDataKeyReady=(secret?:string)=>keyBytes(secret)!==null;

export function encryptWithdrawalValue(value:string,secret?:string){
 const key=keyBytes(secret);if(!key)throw Error('WITHDRAWAL_SECURITY_NOT_CONFIGURED');
 const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv),data=Buffer.concat([cipher.update(value,'utf8'),cipher.final()]),tag=cipher.getAuthTag();
 return [iv,tag,data].map(part=>part.toString('base64url')).join('.');
}

export function decryptWithdrawalValue(value:string,secret?:string){
 const key=keyBytes(secret);if(!key)throw Error('WITHDRAWAL_SECURITY_NOT_CONFIGURED');
 const [iv,tag,data]=value.split('.');if(!iv||!tag||!data)throw Error('WITHDRAWAL_DATA_INVALID');
 const decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(iv,'base64url'));decipher.setAuthTag(Buffer.from(tag,'base64url'));
 return Buffer.concat([decipher.update(Buffer.from(data,'base64url')),decipher.final()]).toString('utf8');
}
