export const COBA8_PROFILE_ID = 'coba8_myr' as const;

/**
 * Field names describe the evidence needed from the supplier. They never hold
 * credential values and are safe to expose in an internal readiness report.
 */
export const COBA8_REQUIRED_CONTRACT_FIELDS = Object.freeze([
  'document.document_id',
  'document.api_version',
  'document.environment',
  'document.merchant_scope',
  'document.base_urls',
  'document.sha256',
  'authentication.scheme',
  'authentication.credential_header_names',
  'authentication.signature_algorithm',
  'authentication.canonical_request_rule',
  'authentication.signed_fields',
  'authentication.timestamp_rule',
  'authentication.replay_protection_rule',
  'authentication.official_test_vectors',
  'network.outbound_ip_allowlist_rule',
  'network.callback_source_ips',
  'catalogue.endpoint',
  'catalogue.method',
  'catalogue.required_fields',
  'catalogue.game_id_field',
  'catalogue.category_field',
  'catalogue.availability_field',
  'catalogue.pagination_rule',
  'player.create.endpoint',
  'player.create.method',
  'player.create.required_fields',
  'player.create.idempotency_rule',
  'player.lookup.endpoint',
  'player.lookup.method',
  'player.namespace_rule',
  'launch.endpoint',
  'launch.method',
  'launch.required_fields',
  'launch.game_id_field',
  'launch.url_field',
  'launch.session_id_field',
  'launch.url_ttl_rule',
  'launch.return_url_rule',
  'launch.delivery_modes',
  'wallet.mode',
  'wallet.balance.endpoint',
  'wallet.balance.method',
  'wallet.balance.amount_field',
  'wallet.balance.currency_field',
  'wallet.deposit.endpoint',
  'wallet.deposit.method',
  'wallet.withdraw.endpoint',
  'wallet.withdraw.method',
  'wallet.transfer.required_fields',
  'wallet.transfer.idempotency_field',
  'wallet.transfer.transaction_id_field',
  'wallet.transfer.duplicate_rule',
  'wallet.transfer_query.endpoint',
  'wallet.transfer_query.method',
  'wallet.transfer_query.binding_fields',
  'wallet.transfer_query.pending_statuses',
  'wallet.transfer_query.terminal_statuses',
  'reports.endpoint',
  'reports.method',
  'reports.required_fields',
  'reports.bet_id_field',
  'reports.round_id_field',
  'reports.player_id_field',
  'reports.amount_fields',
  'reports.currency_field',
  'reports.settled_at_field',
  'reports.pagination_rule',
  'reports.finality_rule',
  'callbacks.endpoint',
  'callbacks.signature_rule',
  'callbacks.source_ip_rule',
  'callbacks.deduplication_field',
  'callbacks.retry_policy',
  'callbacks.ack_schema',
  'session.exit.endpoint',
  'session.exit.method',
  'session.kick.endpoint',
  'session.kick.method',
  'session.offline_status.endpoint',
  'session.unfinished_rounds.endpoint',
  'session.issued_token_invalidation_rule',
  'session.late_result_finality_rule',
  'settlement.reversal_rule',
  'recovery.timeout_rule',
  'recovery.retry_policy',
  'recovery.polling_policy',
  'maintenance.status_endpoint',
  'maintenance.behavior',
  'limits.request_rate_rule',
  'limits.amount_bounds_rule',
  'errors.success_codes',
  'errors.pending_codes',
  'errors.terminal_failure_codes',
  'acceptance.uat_account_scope',
  'acceptance.uat_test_cases',
  'profile.profile_id',
  'profile.provider_currency',
  'profile.settlement_currency',
  'profile.amount_unit',
  'profile.amount_precision',
  'profile.conversion_ratio',
] as const);

function readPath(input: unknown, path: string): unknown {
  let current: unknown = input;
  for (const segment of path.split('.')) {
    if (!current || typeof current !== 'object' || Array.isArray(current)) return undefined;
    current = (current as Record<string, unknown>)[segment];
  }
  return current;
}

function documented(value: unknown): boolean {
  if (typeof value === 'string') return value.trim().length > 0;
  if (Array.isArray(value)) return value.length > 0 && value.every(item => typeof item === 'string' && item.trim().length > 0);
  return Number.isSafeInteger(value) && Number(value) >= 0;
}

export type Coba8ContractDiagnostic = Readonly<{
  profileId: typeof COBA8_PROFILE_ID;
  manifestComplete: boolean;
  missingContractFields: readonly string[];
  documentationOnly: true;
  credentialsPresent: boolean;
  adapterImplemented: false;
  catalogueAllowed: false;
  launchAllowed: false;
  walletAllowed: false;
  settlementAllowed: false;
  recoveryAllowed: false;
  playAllowed: false;
}>;

/**
 * This validator reports documentation gaps only. Credential-shaped input is
 * intentionally ignored: a login, password or API token is not an API contract
 * and can never enable a catalogue, adapter, wallet or Play button.
 */
export function inspectCoba8ContractManifest(manifest: unknown = {}): Coba8ContractDiagnostic {
  const missingContractFields = COBA8_REQUIRED_CONTRACT_FIELDS.filter(path => !documented(readPath(manifest, path)));
  const record = manifest && typeof manifest === 'object' && !Array.isArray(manifest) ? manifest as Record<string, unknown> : {};
  const credentialsPresent = ['apiToken', 'api_key', 'token', 'username', 'password', 'merchantId']
    .some(key => typeof record[key] === 'string' && String(record[key]).trim().length > 0);
  return Object.freeze({
    profileId: COBA8_PROFILE_ID,
    manifestComplete: missingContractFields.length === 0,
    missingContractFields: Object.freeze([...missingContractFields]),
    documentationOnly: true,
    credentialsPresent,
    adapterImplemented: false,
    catalogueAllowed: false,
    launchAllowed: false,
    walletAllowed: false,
    settlementAllowed: false,
    recoveryAllowed: false,
    playAllowed: false,
  });
}
