export type TelegramAdminContext={
 botToken?:string;
 adminChatId?:string;
 fetchImpl?:typeof fetch;
};

export type TelegramAdminStatus={
 configured:boolean;
 ready:boolean;
 mode:'outbound_admin_alerts';
 inboundWebhookEnabled:false;
};

const tokenPattern=/^\d{6,12}:[A-Za-z0-9_-]{30,100}$/;
const chatPattern=/^-?\d{5,20}$/;
async function limitedText(response:Response,maximum=65536){
 const declared=Number(response.headers.get('content-length')??0);if(Number.isFinite(declared)&&declared>maximum)throw new Error('oversized');
 const reader=response.body?.getReader();if(!reader)return '';
 const chunks:Uint8Array[]=[];let size=0;for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>maximum){await reader.cancel();throw new Error('oversized');}chunks.push(part.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}return new TextDecoder().decode(bytes);
}

export function telegramAdminStatus(c:TelegramAdminContext):TelegramAdminStatus{
 const configured=typeof c.botToken==='string'&&tokenPattern.test(c.botToken)&&typeof c.adminChatId==='string'&&chatPattern.test(c.adminChatId);
 return {configured,ready:configured,mode:'outbound_admin_alerts',inboundWebhookEnabled:false};
}

export async function sendTelegramAdminTest(c:TelegramAdminContext){
 const status=telegramAdminStatus(c);
 if(!status.configured)return {ok:false,kind:'not_configured' as const};
 const endpoint=`https://api.telegram.org/bot${c.botToken}/sendMessage`,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
 try{
  const response=await(c.fetchImpl??fetch)(endpoint,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json'},body:JSON.stringify({chat_id:c.adminChatId,text:'MASTER7 backoffice Telegram notification test · connection ready',disable_web_page_preview:true}),redirect:'error',signal:controller.signal});
  const type=(response.headers.get('content-type')??'').toLowerCase(),raw=await limitedText(response);
  let parsed:any=null;if(type.startsWith('application/json'))try{parsed=JSON.parse(raw);}catch{}
  if(!response.ok||parsed?.ok!==true||!Number.isSafeInteger(Number(parsed?.result?.message_id)))return {ok:false,kind:'upstream_rejected' as const,httpStatus:response.status};
  return {ok:true as const,messageId:Number(parsed.result.message_id)};
 }catch{return {ok:false,kind:'unavailable' as const};}
 finally{clearTimeout(timer);}
}
