import {automaticDepositCapability,automaticPaymentStatus,disabledPayoutCapability,unavailableBalanceCapability} from './payment-capabilities.ts';

export type GSPayUsdtContext={
 apiBase?:string;
 authKey?:string;
 secretKey?:string;
 callbackToken?:string;
 ordersEnabled?:string;
 returnUrl?:string;
 callbackUrl?:string;
 recoveryEnabled?:string;
 balanceEnabled?:string;
 contractVerified?:string;
 assetNetwork?:string;
 currencyScale?:string;
 checkoutOrigin?:string;
};

const profileId='gspay_usdt';
const provider='gspay';
const currency='USDT';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const secret=(value:unknown)=>typeof value==='string'&&Buffer.byteLength(value)>=16&&Buffer.byteLength(value)<=1024;
const httpsUrl=(value:unknown)=>{try{const url=new URL(String(value));return url.protocol==='https:'&&!url.username&&!url.password&&!url.hash;}catch{return false;}};

export function gspayUsdtPrerequisites(c:GSPayUsdtContext){
 const credentialsConfigured=secret(c.authKey)&&secret(c.secretKey)&&secret(c.callbackToken)&&new Set([c.authKey,c.secretKey,c.callbackToken]).size===3;
 const endpointsDeclared=httpsUrl(c.apiBase)&&httpsUrl(c.returnUrl)&&httpsUrl(c.callbackUrl)&&httpsUrl(c.checkoutOrigin);
 const currencyRulesDeclared=typeof c.assetNetwork==='string'&&/^[A-Za-z0-9._-]{2,32}$/.test(c.assetNetwork)&&typeof c.currencyScale==='string'&&/^(?:[0-9]|1[0-8])$/.test(c.currencyScale);
 const contractVerified=c.contractVerified==='true';
 return {credentialsConfigured,endpointsDeclared,currencyRulesDeclared,contractVerified};
}

export function gspayUsdtCapabilitySnapshot(c:GSPayUsdtContext){
 const prerequisites=gspayUsdtPrerequisites(c),blockers=[
  ...(!prerequisites.credentialsConfigured?['profile_credentials_incomplete']:[]),
  ...(!prerequisites.endpointsDeclared?['profile_endpoints_unverified']:[]),
  ...(!prerequisites.currencyRulesDeclared?['asset_network_or_scale_unverified']:[]),
  ...(!prerequisites.contractVerified?['provider_contract_unverified']:[]),
  'deposit_adapter_not_implemented',
  ...(c.ordersEnabled==='true'?['orders_switch_ignored_until_adapter_acceptance']:['submission_disabled']),
 ];
 return {
  deposit:automaticDepositCapability({implemented:false,configured:false,enabled:false,blockers},'gateway_contract'),
  payout:disabledPayoutCapability('usdt_payout_contract_not_provided'),
  balance:unavailableBalanceCapability('usdt_balance_contract_not_verified'),
  recovery:{implemented:false,configured:false,enabled:false,verified:false,settlementVerified:false,blockers:['usdt_query_contract_not_verified','recovery_disabled']},
 };
}

export function handleGSPayUsdtStatus(req:Request,c:GSPayUsdtContext):Response|null{
 const path=new URL(req.url).pathname;
 if(path!=='/api/payments/gspay/usdt/status'||req.method!=='GET')return null;
 const prerequisites=gspayUsdtPrerequisites(c),capabilities=gspayUsdtCapabilitySnapshot(c),status=automaticPaymentStatus(capabilities.deposit);
 return json({
  provider,profileId,currency,enabled:false,mode:'disabled',...status,
  credentialsConfigured:prerequisites.credentialsConfigured,
  contractVerified:prerequisites.contractVerified,
  endpointContractDeclared:prerequisites.endpointsDeclared,
  currencyRulesDeclared:prerequisites.currencyRulesDeclared,
  programConfigured:false,createProgramReady:false,orderReady:false,queryReady:false,callbacksReady:false,recoveryReady:false,
  payoutReady:false,realPayments:false,settlementVerified:false,liveReady:false,capabilities,
 });
}
