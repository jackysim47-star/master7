import {timingSafeEqual} from 'node:crypto';
import {getGameCatalogue,cachedGameArtwork,gameSources} from './game-catalogue.ts';
import { readLocalSession, handlePasswordAuth, AuthError } from './password-auth.ts';
import { requestOriginAllowed } from './request-origin.ts';
import { createVPayOrder, handleVPay, vpayOrdersConfigured } from './vpay.ts';
import { createOneMpayOrder, handleOneMpay, refreshOneMpayOrder, oneMpayConfigurationReady } from './onempay.ts';
import { getWithdrawalBanks, listAdminWithdrawals, listMemberWithdrawals, submitWithdrawal, updateWithdrawal } from './withdrawals.ts';
export const RELEASE = '17.0.0-selfbuilt.33-additional-game-sync';
export const SOURCE_RELEASE = '17.0.0-preview.6-qa3-integrated-r3';
type Identity={userId:string;email:string};
type User={id:string;username:string;role:string;approved:number;csrf:string;created_at:number};
export type Context={db:D1Database;identity:Identity|null;ownerEmail:string;ownerLoginId?:string;allowedOrigins?:string[];gameGatewayUrl?:string;gameGatewayFetch?:typeof fetch;gameArtFetch?:typeof fetch;vpayGatewayUrl?:string;vpayOrderToken?:string;vpayQueryToken?:string;vpayCallbackToken?:string;vpayOrdersEnabled?:string;vpayMode?:string;vpayTraderId?:string;vpayReturnUrl?:string;vpayFetch?:typeof fetch;ownerSetupHash?:string;ownerSetupExpires?:number;ownerResetHash?:string;ownerResetExpires?:number;ownerResetIssuedAt?:number;anchorApiBaseUrl?:string;anchorUsername?:string;anchorPassword?:string;anchorSenderId?:string;otpHashSecret?:string;smsFetch?:typeof fetch;withdrawalDataKey?:string;oneMpayApiBase?:string;oneMpayMerchant?:string;oneMpaySecretKey?:string;oneMpayOrdersEnabled?:string;oneMpayCallbackUrl?:string;oneMpayReturnUrl?:string;oneMpayDiagnosticToken?:string;oneMpayFetch?:typeof fetch;rectangleApiBase?:string;rectangleOperatorCode?:string;rectangleApiKey?:string;godeeApiBase?:string;godeeOperatorId?:string;godeeApiKey?:string;gameCatalogueFetch?:typeof fetch;gameSyncToken?:string};
function vpaySettings(c:Context,user:User|null){return {db:c.db,user,gatewayUrl:c.vpayGatewayUrl,orderToken:c.vpayOrderToken,queryToken:c.vpayQueryToken,callbackToken:c.vpayCallbackToken,enabled:c.vpayOrdersEnabled,mode:c.vpayMode,vpayTraderId:c.vpayTraderId,returnUrl:c.vpayReturnUrl,fetchImpl:c.vpayFetch};}
function oneMpaySettings(c:Context,user:User|null){return {db:c.db,user,apiBase:c.oneMpayApiBase,merchant:c.oneMpayMerchant,secretKey:c.oneMpaySecretKey,enabled:c.oneMpayOrdersEnabled,callbackUrl:c.oneMpayCallbackUrl,returnUrl:c.oneMpayReturnUrl,diagnosticToken:c.oneMpayDiagnosticToken,fetchImpl:c.oneMpayFetch};}
function paymentFlags(c:Context,channels:Record<string,unknown>[]){
 const active=(id:string)=>channels.some(x=>x.provider_id===id&&x.status==='active');
 const vpay=active('vpay')&&vpayOrdersConfigured(vpaySettings(c,null));
 const oneMpay=active('1mpay')&&c.oneMpayOrdersEnabled==='true'&&oneMpayConfigurationReady(oneMpaySettings(c,null));
 return {transactionsEnabled:vpay||oneMpay,realPayments:oneMpay,settlementVerified:false,providerOrdersEnabled:{vpay,'1mpay':oneMpay,gspay:false,gspay_plus:false}};
}
class ApiError extends Error{ status:number; constructor(status:number,message:string){super(message);this.status=status;} }
const now=()=>Math.floor(Date.now()/1000);
const uuid=()=>crypto.randomUUID();
export const responseHeaders={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Cookie, oai-authenticated-user-id'};
function json(value:unknown,status=200){return new Response(JSON.stringify(value),{status,headers:responseHeaders});}
function textField(v:unknown,min:number,max:number){if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)throw new ApiError(400,'输入长度不符合要求 / Invalid input');return v.trim();}
function idField(v:unknown){return textField(v,1,128);}
function optionalNumber(v:unknown,min:number,max:number,name:string){if(v===''||v===null||v===undefined)return null;const value=typeof v==='number'?v:Number(v);if(!Number.isFinite(value)||value<min||value>max)throw new ApiError(400,`Invalid ${name}`);return value;}
function optionalInteger(v:unknown,min:number,max:number,name:string){const value=optionalNumber(v,min,max,name);if(value!==null&&!Number.isInteger(value))throw new ApiError(400,`Invalid ${name}`);return value;}
function advertisementUrl(v:unknown){if(v===undefined||v===null||v==='')return '';const value=textField(v,1,500);let url:URL;try{url=new URL(value);}catch{throw new ApiError(400,'Invalid ad destination');}if(url.protocol!=='https:'||url.username||url.password||url.port)throw new ApiError(400,'Ad destination must be an HTTPS URL');return url.href;}
function validImageData(value:string){try{const encoded=value.slice(value.indexOf(',')+1),bytes=atob(encoded);if(bytes.length<16||bytes.length>350000)return false;const prefix=(start:number,end:number)=>[...bytes.slice(start,end)].map(char=>char.charCodeAt(0));const b=prefix(0,12);return value.startsWith('data:image/jpeg;')&&b[0]===0xff&&b[1]===0xd8&&b[2]===0xff||value.startsWith('data:image/png;')&&b[0]===0x89&&b[1]===0x50&&b[2]===0x4e&&b[3]===0x47&&b[4]===0x0d&&b[5]===0x0a&&b[6]===0x1a&&b[7]===0x0a||value.startsWith('data:image/webp;')&&String.fromCharCode(...b.slice(0,4))==='RIFF'&&String.fromCharCode(...b.slice(8,12))==='WEBP';}catch{return false;}}
function urlField(v:unknown,service:string){if(v==='')return '';const s=textField(v,1,300);let u:URL;try{u=new URL(s);}catch{throw new ApiError(400,'Invalid URL');}if(u.protocol!=='https:'||u.username||u.password||u.port||!['www.'+service+'.com',service+'.com'].includes(u.hostname))throw new ApiError(400,'请使用官方 HTTPS 主页地址');return u.href;}
function role(u:User|null,roles=['owner','staff','member']):asserts u is User{if(!u)throw new ApiError(401,'请先登录 / Sign in required');if(!roles.includes(u.role))throw new ApiError(403,'没有访问权限 / Access denied');}
async function currentUser(c:Context,create=false){if(!c.identity)return null;const {userId,email}=c.identity;let u=await c.db.prepare('SELECT * FROM users WHERE id=?').bind(userId).first<User>();if(!u&&create){const owner=!!c.ownerEmail&&email.toLowerCase()===c.ownerEmail.toLowerCase();await c.db.prepare('INSERT OR IGNORE INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,?)').bind(userId,email,owner?'owner':'member',owner?1:0,uuid()+uuid(),now()).run();u=await c.db.prepare('SELECT * FROM users WHERE id=?').bind(userId).first<User>();}return u;}
function auditStmt(db:D1Database,u:User,event:string,target:string){return db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(uuid(),u.id,event,target,now());}
async function rows(db:D1Database,sql:string,...values:(string|number)[]){return (await db.prepare(sql).bind(...values).all()).results;}
async function body(req:Request,maxBytes=24000){if(!req.headers.get('content-type')?.startsWith('application/json'))throw new ApiError(415,'JSON required');const reader=req.body?.getReader();if(!reader)throw new ApiError(400,'Body required');const parts:Uint8Array[]=[];let size=0;for(;;){const x=await reader.read();if(x.done)break;size+=x.value.length;if(size>maxBytes){await reader.cancel();throw new ApiError(413,'Request too large');}parts.push(x.value);}const out=new Uint8Array(size);let offset=0;for(const p of parts){out.set(p,offset);offset+=p.length;}let d;try{d=JSON.parse(new TextDecoder().decode(out));}catch{throw new ApiError(400,'Invalid JSON');}if(!d||Array.isArray(d)||typeof d!=='object')throw new ApiError(400,'Object required');return d;}
async function limited(db:D1Database,u:User){const bucket=Math.floor(now()/60),key=u.id+':'+bucket;const r=await db.prepare('INSERT INTO rate_limits(id,count,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=rate_limits.count+1 RETURNING count').bind(key,now()+120).first<{count:number}>();if((r?.count??31)>30){await auditStmt(db,u,'write_rate_limited','request').run();throw new ApiError(429,'操作过快，请稍后重试 / Too many requests');}await db.prepare('DELETE FROM rate_limits WHERE expires_at < ?').bind(now()).run();}
async function social(db:D1Database){const x=await db.prepare('SELECT value FROM settings WHERE id=?').bind('social').first<{value:string}>();return x?JSON.parse(x.value):{enabled:false,facebookUrl:'',instagramUrl:''};}
const vendorCategories=['SLOT','FAST GAME','LIVE','FISH','SPORT','OTHERS'] as const;
type VendorCategory=typeof vendorCategories[number];
const apiSupplierIds=['megah5','jili','918kissh5','gameplay','lionking','suncity','pgsoft','gfg','sagaming','ps9','dragoonsoft','jdb','bg','allbet','quickspin','astar','metagaming','fuma','yl','funky','gamitech','spadegaming','turbo','ct855','pragmaticplay','joker','cg','atg','rectangle','m8bet','awc','evo888h5','cosmoplay','geminiupdown','epicwin','venus','clotplay','godeezone'];
function publicImage(value:unknown,host:string){if(!host||typeof value!=='string'||value.length>500)return null;try{const u=new URL(value);return u.protocol==='https:'&&u.hostname===host&&!u.username&&!u.password&&!u.port&&u.pathname.startsWith('/thumbs/')&&!u.search&&!u.hash?u.href:null;}catch{return null;}}
function gameArtPath(provider:string,gameCode:string,imageUrl:string|null){return imageUrl&&['megah5','918kissh5'].includes(provider)?`/api/game-art?provider=${encodeURIComponent(provider)}&gameCode=${encodeURIComponent(gameCode)}`:provider==='jili'?'/assets/providers/jili.webp':null;}
async function gameArt(req:Request,c:Context){
 const search=new URL(req.url).searchParams,provider=search.get('provider')??'',gameCode=search.get('gameCode')??'';
 if(!/^[A-Za-z0-9_-]{1,100}$/.test(gameCode)||!['megah5','918kissh5','evo888h5'].includes(provider))throw new ApiError(404,'Game artwork not found');
 const host=provider==='megah5'?'gth.megah5.com':'gth.kissh5.com';
 const artwork=provider==='evo888h5'?await cachedGameArtwork(c,provider,gameCode):`https://${host}/thumbs/web/${encodeURIComponent(gameCode)}.png`;
 if(!artwork)throw new ApiError(404,'Game artwork not found');
 const source=new URL(artwork),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
 try{
  const response=await (c.gameArtFetch??fetch)(source,{method:'GET',headers:{Accept:'image/avif,image/webp,image/png,image/*','User-Agent':'MASTER7-Game-Art/1.0','Referer':new URL(req.url).origin+'/'},redirect:'error',signal:controller.signal});
  const type=(response.headers.get('content-type')??'').split(';')[0].trim().toLowerCase(),declared=Number(response.headers.get('content-length')??0);
  if(!response.ok||!['image/png','image/jpeg','image/webp'].includes(type)||declared>1024*1024)throw new ApiError(404,'Game artwork not found');
  const bytes=await response.arrayBuffer();if(bytes.byteLength<16||bytes.byteLength>1024*1024)throw new ApiError(404,'Game artwork not found');
  return new Response(bytes,{headers:{'Content-Type':type,'Cache-Control':'public, max-age=86400, stale-while-revalidate=604800','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
 }catch(error){if(error instanceof ApiError)throw error;throw new ApiError(404,'Game artwork not found');}finally{clearTimeout(timer);}
}
async function gatewayGames(c:Context){return getGameCatalogue(c);}
async function applyGameVisibility(db:D1Database,catalog:any,includeClosed:boolean){
 const overrides=await rows(db,'SELECT provider_id,game_code,visible,status,image_data,category_override FROM game_visibility');
 const records=new Map(overrides.map((x:any)=>[`${x.provider_id}:${x.game_code}`,x]));
 const games=catalog.games.map((game:any)=>{
  const override=records.get(`${game.provider}:${game.gameCode||game.name}`) as any;
  const configuredStatus=override?.status||'active';
  const status=configuredStatus==='closed'?'closed':game.maintenance?'suspended':configuredStatus;
  return {...game,status,configuredStatus,providerMaintenance:!!game.maintenance,categoryOverride:override?.category_override||'',imageData:override?.image_data||''};
 }).filter((game:any)=>includeClosed||game.status!=='closed');
 return {...catalog,games,providers:catalog.providers.map((provider:any)=>({...provider,count:games.filter((game:any)=>game.provider===provider.id).length}))};
}
export async function handle(req:Request,c:Context):Promise<Response>{try{return await route(req,c);}catch(e){if(e instanceof ApiError||e instanceof AuthError)return json({error:e.message},e.status);const code=e&&typeof e==='object'&&'code'in e&&typeof e.code==='string'&&/^[A-Z0-9]{5}$/.test(e.code)?e.code:'unknown';console.error('MASTER7 API unavailable',e instanceof Error?e.name:'Error',code);return json({error:'服务暂时不可用 / Service temporarily unavailable'},503);}}
async function route(req:Request,c:Context){
 const p=new URL(req.url).pathname,db=c.db;
 if(req.method==='GET'&&(p==='/health'||p==='/api/version')){await db.prepare('SELECT id FROM users LIMIT 1').all();return json({status:'ok',release:RELEASE,sourceRelease:SOURCE_RELEASE,database:'ready',smsOtpReady:!!(c.anchorApiBaseUrl&&c.anchorUsername&&c.anchorPassword&&c.anchorSenderId&&c.otpHashSecret&&c.otpHashSecret.length>=32),mode:'selfbuilt-service-portal',...paymentFlags(c,await rows(db,'SELECT provider_id,status FROM payment_channel_controls')),liveGames:false,productionReady:false,scope:'portal-database-health'});}
 if(req.method==='GET'&&p==='/api/internal/catalogue-sync'){const token=c.gameSyncToken??'',auth=req.headers.get('authorization')??'',given=auth.startsWith('Bearer ')?auth.slice(7):'';if(token.length<32||Buffer.byteLength(given)!==Buffer.byteLength(token)||!timingSafeEqual(Buffer.from(given),Buffer.from(token)))return json({error:'Access denied'},401);const catalogue=await getGameCatalogue(c);return json({providers:catalogue.providers,gameCount:catalogue.games.length,playable:false});}
 if(req.method==='GET'&&p==='/api/game-art')return gameArt(req,c);
 if(!['GET','POST'].includes(req.method))throw new ApiError(405,'Method not allowed');
 const local=await readLocalSession(req,db);
 if(p.startsWith('/api/auth/'))return handlePasswordAuth(req,c,local);
 const u=local?.user??await currentUser(c,p==='/api/session'&&req.method==='GET');
 const vpayContext=vpaySettings(c,u);
 const vpayResponse=await handleVPay(req,vpayContext);
 if(vpayResponse)return vpayResponse;
 const oneMpayContext=oneMpaySettings(c,u);
 const oneMpayResponse=await handleOneMpay(req,oneMpayContext);
 if(oneMpayResponse)return oneMpayResponse;
 if(req.method==='GET'){
  if(p==='/api/session')return json({user:u?{id:u.id,username:u.username,role:u.role,approved:!!u.approved}:null,csrf:u?.csrf??null,authMethod:u?(local?'password':'chatgpt'):null});
  if(p==='/api/withdrawal-banks')return getWithdrawalBanks();
  if(p==='/api/withdrawals')return listMemberWithdrawals({db,user:u,dataKey:c.withdrawalDataKey});
  if(p==='/api/announcements')return json({items:await rows(db,'SELECT id,title,body,created_at FROM announcements ORDER BY created_at DESC,id DESC LIMIT 100')});
  if(p==='/api/ads')return json({items:await rows(db,'SELECT id,title,image_data,target_url,position FROM lobby_ads WHERE enabled=1 ORDER BY position ASC,created_at DESC,id ASC LIMIT 20')});
  if(p==='/api/payment-channels'){const items=await rows(db,'SELECT provider_id,provider_name,status FROM payment_channel_controls ORDER BY CASE provider_id WHEN \'vpay\' THEN 1 WHEN \'gspay\' THEN 2 WHEN \'1mpay\' THEN 3 ELSE 4 END');return json({items,...paymentFlags(c,items)});}
  if(p==='/api/custom-games')return json({playable:false,items:[]});
  if(p==='/api/benefits'){const items=await rows(db,"SELECT id,title,description,rules_json,created_at,updated_at FROM benefit_rules WHERE status='active' ORDER BY updated_at DESC,id ASC LIMIT 100");return json({items:items.map((x:any)=>({...x,rules:JSON.parse(x.rules_json)}))});}
  if(p==='/api/supplier-art-list')return json({items:await rows(db,'SELECT provider_id,updated_at FROM api_supplier_artwork ORDER BY provider_id')});
  if(p==='/api/supplier-art'){
   const providerId=new URL(req.url).searchParams.get('provider')??'';if(!apiSupplierIds.includes(providerId))throw new ApiError(404,'Supplier artwork not found');
   const entry=await db.prepare('SELECT image_data FROM api_supplier_artwork WHERE provider_id=?').bind(providerId).first<{image_data:string}>(),match=entry?.image_data?.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);
   if(!match||!validImageData(entry!.image_data))throw new ApiError(404,'Supplier artwork not found');
   const bytes=Uint8Array.from(atob(match[2]),char=>char.charCodeAt(0));return new Response(bytes,{headers:{'Content-Type':match[1],'Cache-Control':'public, max-age=60','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
  }
  if(p==='/api/brand-directory'){
   const items=await rows(db,"SELECT id,category,display_name,position,marked,status,image_data FROM brand_directory_entries WHERE status IN ('active','suspended') ORDER BY CASE category WHEN 'SLOT' THEN 1 WHEN 'FAST GAME' THEN 2 WHEN 'LIVE' THEN 3 WHEN 'FISH' THEN 4 WHEN 'SPORT' THEN 5 ELSE 6 END,position,id LIMIT 100");
   return json({items:items.map((x:any)=>({id:x.id,category:x.category,display_name:x.display_name,position:x.position,marked:x.marked,status:x.status,imageAvailable:!!x.image_data,integrationState:'not_configured'})),categories:vendorCategories,playable:false});
  }
  if(p==='/api/brand-directory-art'){
   const id=new URL(req.url).searchParams.get('id');if(!id)throw new ApiError(400,'Provider ID required');
   const entry=await c.db.prepare("SELECT image_data FROM brand_directory_entries WHERE id=? AND status IN ('active','suspended')").bind(id).first<{image_data:string}>();
   const match=entry?.image_data?.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);
   if(!match||!validImageData(entry!.image_data))throw new ApiError(404,'Artwork not found');
   const bytes=Uint8Array.from(atob(match[2]),char=>char.charCodeAt(0));
   return new Response(bytes,{headers:{'Content-Type':match[1],'Cache-Control':'private, max-age=60','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
  }
  if(p==='/api/admin/game-sync'){role(u,['owner','staff']);const catalogue=await gatewayGames(c);return json({providers:catalogue.providers,gameCount:catalogue.games.length,syncIntervalSeconds:300,playable:false});}
  if(p==='/api/admin/games'){role(u,['owner','staff']);return json({...await applyGameVisibility(db,await gatewayGames(c),true),playable:false});}
  if(p==='/api/games')return json({...await applyGameVisibility(db,await gatewayGames(c),false),playable:false});
  if(p==='/api/providers')return json({items:await rows(db,u&&['staff','owner'].includes(u.role)?'SELECT * FROM providers ORDER BY name':'SELECT * FROM providers WHERE visible=1 ORDER BY name'),playable:false});
  if(p==='/api/social-links'){const s=await social(db);return json(s.enabled?s:{enabled:false,facebookUrl:'',instagramUrl:''});}
  if(p==='/api/tickets'){
   role(u);const staff=u.role!=='member';const items=await rows(db,'SELECT t.*,u.username FROM tickets t JOIN users u ON u.id=t.user_id '+(staff?'':'WHERE t.user_id=? ')+'ORDER BY t.created_at DESC,t.id DESC LIMIT 100',...(staff?[]:[u.id]));
   const replies=await rows(db,'SELECT r.*,u.username FROM replies r JOIN users u ON u.id=r.user_id JOIN tickets t ON t.id=r.ticket_id '+(staff?'':'WHERE t.user_id=? ')+'ORDER BY r.created_at,r.id LIMIT 1000',...(staff?[]:[u.id]));
   return json({items:items.map(t=>({...t,replies:replies.filter(r=>r.ticket_id===t.id)}))});
  }
  if(p.startsWith('/api/admin/')){
   role(u,['owner','staff']);
   if(p==='/api/admin/summary'){const summary=await db.prepare("SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM users WHERE approved=0) pending,(SELECT COUNT(*) FROM tickets WHERE status='open') ticketsOpen,(SELECT COUNT(*) FROM providers WHERE visible=1) providersVisible").first();return json({...summary,financialMetrics:'not-connected'});}
   if(p==='/api/admin/payment-channels')return json({items:await rows(db,'SELECT provider_id,provider_name,status,updated_at FROM payment_channel_controls ORDER BY CASE provider_id WHEN \'vpay\' THEN 1 WHEN \'gspay\' THEN 2 WHEN \'1mpay\' THEN 3 ELSE 4 END')});
   if(p==='/api/admin/brand-directory')return json({items:(await rows(db,"SELECT id,category,display_name,position,marked,status,image_data,updated_at FROM brand_directory_entries ORDER BY CASE category WHEN 'SLOT' THEN 1 WHEN 'FAST GAME' THEN 2 WHEN 'LIVE' THEN 3 WHEN 'FISH' THEN 4 WHEN 'SPORT' THEN 5 ELSE 6 END,position,id")).map((x:any)=>({...x,integrationState:'not_configured'})),categories:vendorCategories,imageSize:'800x600',imageMaxBytes:350000});
   if(p==='/api/admin/ads')return json({items:await rows(db,'SELECT id,title,image_data,target_url,enabled,position,created_at,updated_at FROM lobby_ads ORDER BY position ASC,created_at DESC,id ASC LIMIT 20'),maxAds:20,imageMaxBytes:350000,desktopSize:'1200x360',rotationSeconds:300});
   if(p==='/api/admin/custom-games')return json({items:await rows(db,'SELECT id,title,provider_name,game_code,category,image_data,is_platform_mini,enabled,status,position,created_at,updated_at FROM custom_game_cards ORDER BY is_platform_mini DESC,provider_name ASC,position ASC,created_at ASC LIMIT 100'),maxCards:100,maxPlatformMiniGames:5,imageMaxBytes:350000,imageSize:'800x600'});
   if(p==='/api/admin/benefits'){const items=await rows(db,'SELECT id,title,description,rules_json,status,created_at,updated_at FROM benefit_rules ORDER BY updated_at DESC,id ASC LIMIT 100');return json({items:items.map((x:any)=>({...x,rules:JSON.parse(x.rules_json)})),moneyAutomation:false});}
   if(p==='/api/admin/social-links')return json({...await social(db),canEdit:u.role==='owner'});
   if(p==='/api/admin/operations'){const day=Math.floor((now()+28800)/86400)*86400-28800;const n=await db.prepare('SELECT COUNT(*) n FROM users WHERE created_at>=?').bind(day).first<{n:number}>(),w=await db.prepare("SELECT CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM withdrawal_requests WHERE status='paid' AND created_at>=?").bind(day).first<{amount:string}>();return json({metrics:{newMembersPreview:n?.n??0,depositMYR:null,withdrawMYR:Number(w?.amount??0)/100,bonusMYR:null,netRevenueMYR:null,groupJoins:null}});}
   role(u,['owner']);
   if(p==='/api/admin/withdrawals')return listAdminWithdrawals({db,user:u,dataKey:c.withdrawalDataKey});
   if(p==='/api/admin/users')return json({items:await rows(db,'SELECT id,username,role,approved,created_at FROM users ORDER BY created_at DESC LIMIT 500')});
   if(p==='/api/admin/payment-diagnostics')return json({items:(await rows(db,"SELECT target,created_at FROM audit WHERE event='payment_order_diagnostic' ORDER BY created_at DESC,id DESC LIMIT 100")).map((x:any)=>{try{return {...JSON.parse(x.target),createdAt:x.created_at};}catch{return {kind:'UNAVAILABLE',createdAt:x.created_at};}})});
   if(p==='/api/admin/audit')return json({items:await rows(db,'SELECT a.event,a.target,a.created_at,u.username FROM audit a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC,a.id DESC LIMIT 100')});
   if(p==='/api/admin/security'){const n=await db.prepare("SELECT COUNT(*) n FROM audit WHERE event='write_rate_limited' AND created_at>=?").bind(Math.floor((now()+28800)/86400)*86400-28800).first<{n:number}>();return json({today:{login_denied:null,login_rate_limited:null,registration_rate_limited:null,write_rate_limited:n?.n??0}});}
   if(p==='/api/admin/export'){const data:Record<string,unknown>={release:RELEASE,exportedAt:new Date().toISOString(),scope:'new-portal-only'};for(const table of ['users','tickets','replies','announcements','providers','brand_directory_entries','api_supplier_artwork','portal_status_snapshots','lobby_ads','custom_game_cards','benefit_rules','game_visibility','payment_channel_controls','withdrawal_requests','settings','audit']){const list=await rows(db,`SELECT ${table==='users'?'id,username,role,approved,created_at':table==='api_supplier_artwork'?'provider_id,updated_by,updated_at':table==='lobby_ads'?'id,title,target_url,enabled,position,created_by,created_at,updated_at':table==='custom_game_cards'?'id,title,provider_name,game_code,category,is_platform_mini,enabled,status,position,created_by,created_at,updated_at':table==='game_visibility'?'provider_id,game_code,visible,status,category_override,updated_by,updated_at':table==='withdrawal_requests'?'id,user_id,provider_id,provider_name,bank_code,bank_name,account_last4,amount_minor,currency,status,owner_note,updated_by,created_at,updated_at':'*'} FROM ${table}${table==='settings'?" WHERE id NOT LIKE 'owner_password_%'":''} LIMIT 10001`);if(list.length>10000)throw new ApiError(413,'导出超过单次上限，请联系站点维护人员');data[table]=list;}return new Response(JSON.stringify(data,null,2),{headers:{...responseHeaders,'Content-Disposition':'attachment; filename="master7-portal-export.json"'}});}
  }
  throw new ApiError(404,'Not found');
 }
 // Cookies alone never authorize writes. Require exact Origin and a per-user token.
 if(!requestOriginAllowed(req,c.allowedOrigins))throw new ApiError(403,'Origin denied');
 role(u);if(!u.approved)throw new ApiError(403,'账号待老板审批 / Account awaiting approval');
 if(req.headers.get('x-csrf-token')!==u.csrf)throw new ApiError(403,'CSRF denied');
 const d=await body(req,p==='/api/admin/ads'||p==='/api/admin/custom-games'||p==='/api/admin/game-visibility'||p==='/api/admin/provider'||p==='/api/admin/brand-directory'||p==='/api/admin/supplier-art'?550000:24000);await limited(db,u);
 if(p==='/api/payments/vpay/orders')return createVPayOrder(d,vpayContext);
 if(p==='/api/payments/1mpay/orders')return createOneMpayOrder(d,oneMpayContext);
 if(p==='/api/payments/1mpay/orders/query')return refreshOneMpayOrder(d,oneMpayContext);
 if(p==='/api/withdrawals')return submitWithdrawal(d,{db,user:u,dataKey:c.withdrawalDataKey});
 if(p==='/api/tickets'){const subject=textField(d.subject,3,120),message=textField(d.message,5,2000),id=uuid();await db.batch([db.prepare('INSERT INTO tickets(id,user_id,subject,message,created_at) VALUES(?,?,?,?,?)').bind(id,u.id,subject,message,now()),auditStmt(db,u,'ticket_created',id)]);return json({status:'ok',id},201);}
 if(p==='/api/tickets/reply'){const id=idField(d.ticketId),message=textField(d.message,1,2000),ticket=await db.prepare('SELECT user_id,status FROM tickets WHERE id=?').bind(id).first<{user_id:string;status:string}>();if(!ticket||u.role==='member'&&ticket.user_id!==u.id)throw new ApiError(404,'Ticket not found');if(ticket.status!=='open')throw new ApiError(409,'工单已关闭 / Ticket closed');await db.batch([db.prepare('INSERT INTO replies(id,ticket_id,user_id,message,created_at) VALUES(?,?,?,?,?)').bind(uuid(),id,u.id,message,now()),auditStmt(db,u,'ticket_replied',id)]);return json({status:'ok'});}
 if(p.startsWith('/api/admin/')){
  role(u,['owner','staff']);
  if(p==='/api/admin/game-sync'){const catalogue=await getGameCatalogue(c,{force:true});await auditStmt(db,u,'game_catalogue_sync','catalogue').run();return json({providers:catalogue.providers,gameCount:catalogue.games.length,syncIntervalSeconds:300,playable:false});}
  if(p==='/api/admin/withdrawals/status'){role(u,['owner']);return updateWithdrawal(d,{db,user:u,dataKey:c.withdrawalDataKey});}
  if(p==='/api/admin/supplier-art'){
   role(u,['owner']);const providerId=textField(d.providerId,1,32);if(!apiSupplierIds.includes(providerId))throw new ApiError(400,'Invalid supplier');
   if(typeof d.imageData!=='string'||d.imageData.length>500000||!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');
   const timestamp=now();await db.batch([db.prepare('INSERT INTO api_supplier_artwork(provider_id,image_data,updated_by,updated_at) VALUES(?,?,?,?) ON CONFLICT(provider_id) DO UPDATE SET image_data=excluded.image_data,updated_by=excluded.updated_by,updated_at=excluded.updated_at').bind(providerId,d.imageData,u.id,timestamp),auditStmt(db,u,'api_supplier_artwork_updated',providerId)]);return json({status:'ok',providerId,updatedAt:timestamp});
  }
  if(p==='/api/admin/ads'){
   const action=textField(d.action,3,10);
   if(action==='delete'){
    const id=idField(d.id);if(!await db.prepare('SELECT id FROM lobby_ads WHERE id=?').bind(id).first())throw new ApiError(404,'Ad not found');
    await db.batch([db.prepare('DELETE FROM lobby_ads WHERE id=?').bind(id),auditStmt(db,u,'lobby_ad_deleted',id)]);return json({status:'ok'});
   }
   if(action==='toggle'){
    const id=idField(d.id);if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid enabled state');if(!await db.prepare('SELECT id FROM lobby_ads WHERE id=?').bind(id).first())throw new ApiError(404,'Ad not found');
    await db.batch([db.prepare('UPDATE lobby_ads SET enabled=?,updated_at=? WHERE id=?').bind(d.enabled?1:0,now(),id),auditStmt(db,u,d.enabled?'lobby_ad_enabled':'lobby_ad_disabled',id)]);return json({status:'ok'});
   }
   if(action==='save'){
    const id=typeof d.id==='string'&&d.id? idField(d.id):uuid(),title=textField(d.title,2,100),target=advertisementUrl(d.targetUrl),enabled=typeof d.enabled==='boolean'?d.enabled:true,position=Number.isInteger(d.position)&&d.position>=0&&d.position<1000?d.position:0;
    let imageData=typeof d.imageData==='string'?d.imageData:'';
    if(imageData){if(imageData.length>500000||!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(imageData)||!validImageData(imageData))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');}
    const existing=await db.prepare('SELECT id,image_data FROM lobby_ads WHERE id=?').bind(id).first<{id:string;image_data:string}>();
    if(!imageData&&existing)imageData=existing.image_data;
    if(!imageData)throw new ApiError(400,'Ad image is required');
    if(existing){await db.batch([db.prepare('UPDATE lobby_ads SET title=?,image_data=?,target_url=?,enabled=?,position=?,updated_at=? WHERE id=?').bind(title,imageData,target,enabled?1:0,position,now(),id),auditStmt(db,u,'lobby_ad_updated',id)]);}
    else{const count=await db.prepare('SELECT COUNT(*) AS count FROM lobby_ads').first<{count:number}>();if(Number(count?.count??0)>=20)throw new ApiError(409,'The lobby supports up to 20 ads');await db.batch([db.prepare('INSERT INTO lobby_ads(id,title,image_data,target_url,enabled,position,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(id,title,imageData,target,enabled?1:0,position,u.id,now(),now()),auditStmt(db,u,'lobby_ad_created',id)]);}
    return json({status:'ok',id},existing?200:201);
   }
   throw new ApiError(400,'Invalid ad action');
  }
  if(p==='/api/admin/custom-games'){
   role(u,['owner']);
   const action=textField(d.action,3,10);
   if(action==='delete'||action==='toggle'||action==='status'){
    const id=idField(d.id);if(!await db.prepare('SELECT id FROM custom_game_cards WHERE id=?').bind(id).first())throw new ApiError(404,'Game card not found');
    if(action==='delete'){await db.batch([db.prepare('DELETE FROM custom_game_cards WHERE id=?').bind(id),auditStmt(db,u,'custom_game_deleted',id)]);return json({status:'ok'});}
    if(action==='status'){if(!['suspended','active','closed'].includes(d.status))throw new ApiError(400,'Invalid game status');await db.batch([db.prepare('UPDATE custom_game_cards SET status=?,enabled=?,updated_at=? WHERE id=?').bind(d.status,d.status==='closed'?0:1,now(),id),auditStmt(db,u,'custom_game_'+d.status,id)]);return json({status:'ok',gameStatus:d.status,playable:false});}
    if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid enabled state');await db.batch([db.prepare('UPDATE custom_game_cards SET enabled=?,updated_at=? WHERE id=?').bind(d.enabled?1:0,now(),id),auditStmt(db,u,d.enabled?'custom_game_enabled':'custom_game_disabled',id)]);return json({status:'ok'});
   }
   if(action==='save'){
    const id=typeof d.id==='string'&&d.id?idField(d.id):uuid(),title=textField(d.title,2,100),isPlatformMini=d.isPlatformMini===true,providerName=isPlatformMini?'MASTER7 Mini Games':textField(d.providerName,2,80),gameCode=typeof d.gameCode==='string'?d.gameCode.trim().slice(0,100):'',category=typeof d.category==='string'?d.category.trim().slice(0,40):'',enabled=typeof d.enabled==='boolean'?d.enabled:false,position=optionalInteger(d.position,0,999,'position')??0;
    let imageData=typeof d.imageData==='string'?d.imageData:'';if(imageData&&(imageData.length>500000||!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(imageData)||!validImageData(imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');
    const existing=await db.prepare('SELECT id,image_data,is_platform_mini FROM custom_game_cards WHERE id=?').bind(id).first<{id:string;image_data:string;is_platform_mini:number}>();if(!imageData&&existing)imageData=existing.image_data;if(!imageData)throw new ApiError(400,'Game image is required');
    if(isPlatformMini&&(!existing||!Number(existing.is_platform_mini))){const count=await db.prepare('SELECT COUNT(*) AS count FROM custom_game_cards WHERE is_platform_mini=1').first<{count:number}>();if(Number(count?.count??0)>=5)throw new ApiError(409,'Only five MASTER7 platform mini-game cards are allowed');}
    if(existing){await db.batch([db.prepare('UPDATE custom_game_cards SET title=?,provider_name=?,game_code=?,category=?,image_data=?,is_platform_mini=?,enabled=?,position=?,updated_at=? WHERE id=?').bind(title,providerName,gameCode,category,imageData,isPlatformMini?1:0,enabled?1:0,position,now(),id),auditStmt(db,u,'custom_game_updated',id)]);}
    else{const count=await db.prepare('SELECT COUNT(*) AS count FROM custom_game_cards').first<{count:number}>();if(Number(count?.count??0)>=100)throw new ApiError(409,'The lobby supports up to 100 custom game cards');await db.batch([db.prepare('INSERT INTO custom_game_cards(id,title,provider_name,game_code,category,image_data,is_platform_mini,enabled,status,position,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,title,providerName,gameCode,category,imageData,isPlatformMini?1:0,0,'closed',position,u.id,now(),now()),auditStmt(db,u,'custom_game_created',id)]);}
    return json({status:'ok',id},existing?200:201);
   }
   throw new ApiError(400,'Invalid game-card action');
  }
  if(p==='/api/admin/benefits'){
   role(u,['owner']);
   const action=textField(d.action,3,10);
   if(action==='delete'){
    const id=idField(d.id);if(!await db.prepare('SELECT id FROM benefit_rules WHERE id=?').bind(id).first())throw new ApiError(404,'Benefit not found');
    await db.batch([db.prepare('DELETE FROM benefit_rules WHERE id=?').bind(id),auditStmt(db,u,'benefit_rule_deleted',id)]);return json({status:'ok'});
   }
   if(action==='toggle'){
    const id=idField(d.id),status=d.status;if(!['draft','active'].includes(status))throw new ApiError(400,'Invalid benefit status');if(!await db.prepare('SELECT id FROM benefit_rules WHERE id=?').bind(id).first())throw new ApiError(404,'Benefit not found');
    await db.batch([db.prepare('UPDATE benefit_rules SET status=?,updated_at=? WHERE id=?').bind(status,now(),id),auditStmt(db,u,status==='active'?'benefit_rule_published':'benefit_rule_unpublished',id)]);return json({status:'ok'});
   }
   if(action==='save'){
    const id=typeof d.id==='string'&&d.id?idField(d.id):uuid(),title=textField(d.title,2,100),description=textField(d.description,3,2000),rewardType=textField(d.rewardType,3,32);
    if(!['deposit_bonus','cashback','free_credit','vip','referral','other'].includes(rewardType))throw new ApiError(400,'Invalid benefit type');
    const turnoverBase=d.turnoverBase??'deposit_plus_bonus';if(!['deposit','bonus','deposit_plus_bonus'].includes(turnoverBase))throw new ApiError(400,'Invalid turnover base');
    const providerId=d.providerId??'all';if(!['all','jili','megah5','918kissh5'].includes(providerId))throw new ApiError(400,'Invalid sponsored provider');
    const rules={currency:'MYR',providerId,rewardType,rewardAmountMYR:optionalNumber(d.rewardAmountMYR,0,1000000,'reward amount'),rewardPercent:optionalNumber(d.rewardPercent,0,1000,'reward percent'),minDepositMYR:optionalNumber(d.minDepositMYR,0,1000000,'minimum deposit'),maxRewardMYR:optionalNumber(d.maxRewardMYR,0,1000000,'maximum reward'),turnoverMultiplier:optionalNumber(d.turnoverMultiplier,0,1000,'turnover multiplier'),turnoverBase,turnoverRequiredMYR:optionalNumber(d.turnoverRequiredMYR,0,100000000,'turnover amount'),withdrawalCapMYR:optionalNumber(d.withdrawalCapMYR,0,1000000,'withdrawal cap'),claimLimitPerMember:optionalInteger(d.claimLimitPerMember,1,100000,'claim limit'),validityDays:optionalInteger(d.validityDays,1,3650,'validity')};
    if(!rules.rewardAmountMYR&&!rules.rewardPercent&&d.status==='active')throw new ApiError(400,'Set a reward amount or percentage before publishing');
    const status=d.status==='active'?'active':'draft',existing=await db.prepare('SELECT id FROM benefit_rules WHERE id=?').bind(id).first();
    if(existing)await db.batch([db.prepare('UPDATE benefit_rules SET title=?,description=?,rules_json=?,status=?,updated_at=? WHERE id=?').bind(title,description,JSON.stringify(rules),status,now(),id),auditStmt(db,u,'benefit_rule_updated',id)]);
    else await db.batch([db.prepare('INSERT INTO benefit_rules(id,title,description,rules_json,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').bind(id,title,description,JSON.stringify(rules),status,u.id,now(),now()),auditStmt(db,u,'benefit_rule_created',id)]);
    return json({status:'ok',id,ruleStatus:status},existing?200:201);
   }
   throw new ApiError(400,'Invalid benefit action');
  }
  if(p==='/api/admin/announcement'){const title=textField(d.title,3,100),content=textField(d.body,5,1000),id=uuid();await db.batch([db.prepare('INSERT INTO announcements(id,title,body,created_by,created_at) VALUES(?,?,?,?,?)').bind(id,title,content,u.id,now()),auditStmt(db,u,'announcement_created',id)]);return json({status:'ok'},201);}
  if(p==='/api/admin/payment-channels'){
   role(u,['owner']);
   const providerId=textField(d.providerId,1,32),status=d.status;
   if(!['vpay','gspay','1mpay','gspay_plus'].includes(providerId)||!['suspended','active','closed'].includes(status))throw new ApiError(400,'Invalid payment channel status');
   const channel=await db.prepare('SELECT provider_name FROM payment_channel_controls WHERE provider_id=?').bind(providerId).first<{provider_name:string}>();if(!channel)throw new ApiError(404,'Payment channel not found');
   await db.batch([db.prepare('UPDATE payment_channel_controls SET status=?,updated_by=?,updated_at=? WHERE provider_id=?').bind(status,u.id,now(),providerId),auditStmt(db,u,'payment_channel_'+status,providerId)]);return json({status:'ok',providerId,channelStatus:status,...paymentFlags(c,await rows(db,'SELECT provider_id,status FROM payment_channel_controls'))});
  }
  if(p==='/api/admin/ticket-status'){const id=idField(d.ticketId);if(!['open','closed'].includes(d.status))throw new ApiError(400,'Invalid status');if(!await db.prepare('SELECT id FROM tickets WHERE id=?').bind(id).first())throw new ApiError(404,'Ticket not found');await db.batch([db.prepare('UPDATE tickets SET status=? WHERE id=?').bind(d.status,id),auditStmt(db,u,'ticket_'+d.status,id)]);return json({status:'ok'});}
  if(p==='/api/admin/game-visibility'){
   role(u,['owner']);
   const providerId=textField(d.providerId,1,32),gameCode=textField(d.gameCode,1,100);if(!gameSources.some(s=>s.id===providerId))throw new ApiError(400,'Invalid game provider');
   const status=d.status;if(status!==undefined&&!['suspended','active','closed'].includes(status))throw new ApiError(400,'Invalid game status');
   const categoryOverride=d.category===undefined?undefined:d.category;if(categoryOverride!==undefined&&categoryOverride!==''&&!vendorCategories.includes(categoryOverride as VendorCategory))throw new ApiError(400,'Invalid game category');
   if(status===undefined&&d.imageData===undefined&&categoryOverride===undefined)throw new ApiError(400,'A status, category or game image is required');
   let imageData:string|undefined;if(d.imageData!==undefined){if(typeof d.imageData!=='string'||d.imageData.length>500000||d.imageData!==''&&(!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');imageData=d.imageData;}
   const key=`${providerId}:${gameCode}`,existing=await db.prepare('SELECT status,image_data,category_override FROM game_visibility WHERE provider_id=? AND game_code=?').bind(providerId,gameCode).first<{status:string;image_data:string;category_override:string}>(),nextStatus=status??existing?.status??'closed',nextImage=imageData??existing?.image_data??'',nextCategory=categoryOverride===undefined?existing?.category_override??'':categoryOverride;
   await db.batch([db.prepare('INSERT INTO game_visibility(provider_id,game_code,visible,status,image_data,category_override,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(provider_id,game_code) DO UPDATE SET visible=excluded.visible,status=excluded.status,image_data=excluded.image_data,category_override=excluded.category_override,updated_by=excluded.updated_by,updated_at=excluded.updated_at').bind(providerId,gameCode,nextStatus==='closed'?0:1,nextStatus,nextImage,nextCategory,u.id,now()),auditStmt(db,u,imageData!==undefined&&status===undefined&&categoryOverride===undefined?'game_artwork_updated':`game_${nextStatus}`,key)]);
   return json({status:'ok',gameStatus:nextStatus,artworkSaved:imageData!==undefined,playable:false});
  }
  if(p==='/api/admin/provider'){
   role(u,['owner']);
   const id=idField(d.id);if(typeof d.visible!=='boolean'&&d.imageData===undefined)throw new ApiError(400,'A visibility state or provider image is required');
   const existing=await db.prepare('SELECT visible,image_data FROM providers WHERE id=?').bind(id).first<{visible:number;image_data:string}>();if(!existing)throw new ApiError(404,'Provider not found');
   let imageData=existing.image_data;if(d.imageData!==undefined){if(typeof d.imageData!=='string'||d.imageData.length>500000||d.imageData!==''&&(!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');imageData=d.imageData;}
   const visible=d.visible===undefined?Number(existing.visible):d.visible?1:0;
   await db.batch([db.prepare('UPDATE providers SET visible=?,image_data=? WHERE id=?').bind(visible,imageData,id),auditStmt(db,u,d.imageData!==undefined?'provider_artwork_updated':'provider_visibility',id)]);return json({status:'ok',providerId:id,artworkSaved:d.imageData!==undefined});
  }
  if(p==='/api/admin/brand-directory'){
   role(u,['owner']);
   const id=idField(d.id),status=d.status;if(status!==undefined&&!['suspended','active','closed'].includes(status))throw new ApiError(400,'Invalid brand status');
   if(status===undefined&&d.imageData===undefined)throw new ApiError(400,'A status or brand image is required');
   const existing=await db.prepare('SELECT status,image_data FROM brand_directory_entries WHERE id=?').bind(id).first<{status:string;image_data:string}>();if(!existing)throw new ApiError(404,'Brand directory entry not found');
   let imageData:string|undefined;if(d.imageData!==undefined){if(typeof d.imageData!=='string'||d.imageData.length>500000||d.imageData!==''&&(!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');imageData=d.imageData;}
   const nextStatus=status??existing.status,nextImage=imageData??existing.image_data;
   await db.batch([db.prepare('UPDATE brand_directory_entries SET status=?,image_data=?,updated_by=?,updated_at=? WHERE id=?').bind(nextStatus,nextImage,u.id,now(),id),auditStmt(db,u,imageData!==undefined&&status===undefined?'brand_artwork_updated':`brand_${nextStatus}`,id)]);
   return json({status:'ok',brandStatus:nextStatus,artworkSaved:imageData!==undefined,integrationState:'not_configured'});
  }
  role(u,['owner']);
  if(p==='/api/admin/approve'||p==='/api/admin/role'){const id=idField(d.userId),target=await db.prepare('SELECT role FROM users WHERE id=?').bind(id).first<{role:string}>();if(!target)throw new ApiError(404,'User not found');if(target.role==='owner')throw new ApiError(403,'Owner protected');if(p.endsWith('/role')){if(!['member','staff'].includes(d.role))throw new ApiError(400,'Invalid role');await db.batch([db.prepare('UPDATE users SET role=?,approved=1 WHERE id=?').bind(d.role,id),auditStmt(db,u,'role_'+d.role,id)]);}else await db.batch([db.prepare('UPDATE users SET approved=1 WHERE id=?').bind(id),auditStmt(db,u,'user_approved',id)]);return json({status:'ok'});}
  if(p==='/api/admin/social-links'){if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid state');const value={enabled:d.enabled,facebookUrl:urlField(d.facebookUrl,'facebook'),instagramUrl:urlField(d.instagramUrl,'instagram')};if(value.enabled&&!value.facebookUrl&&!value.instagramUrl)throw new ApiError(400,'至少填写一个主页');await db.batch([db.prepare("INSERT INTO settings(id,value) VALUES('social',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(JSON.stringify(value)),auditStmt(db,u,'social_links_updated','social')]);return json({status:'ok'});}
 }
 throw new ApiError(404,'Not found');
}
