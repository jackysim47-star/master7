import {createHash,timingSafeEqual} from 'node:crypto';
import {getGameCatalogue,cachedGameArtwork,gameSources} from './game-catalogue.ts';
import { readLocalSession, handlePasswordAuth, AuthError } from './password-auth.ts';
import { requestOriginAllowed } from './request-origin.ts';
import { createVPayOrder, handleVPay, vpayOrdersConfigured } from './vpay.ts';
import { createOneMpayOrder, handleOneMpay, refreshOneMpayOrder, oneMpayConfigurationReady } from './onempay.ts';
import { createGSPayOrder, handleGSPay, handleGSPayCallback, refreshGSPayOrder, gspayProgramConfigured } from './gspay.ts';
import { getWithdrawalBanks, listAdminWithdrawals, listMemberWithdrawals, submitWithdrawal } from './withdrawals.ts';
import { manualBankGet, manualBankPost } from './manual-bank.ts';
import {MegaWalletError,adminMegaWalletSessions,megaWalletConfigured,memberMegaWalletState,prepareMegaWallet,recoverMegaWallet,settleMegaWallet,type MegaWalletContext} from './megah5-wallet.ts';
import {createEncryptedPortalBackup} from './encrypted-backup.ts';
import {BACKUP_PUBLIC_KEY_SHA256} from './backup-public-key.ts';
export const RELEASE = '17.0.0-selfbuilt.57-payment-checks';
export const SOURCE_RELEASE = '17.0.0-preview.6-qa3-integrated-r3';
type Identity={userId:string;email:string};
type User={id:string;username:string;role:string;approved:number;csrf:string;created_at:number};
export type Context={db:D1Database;identity:Identity|null;ownerEmail:string;ownerLoginId?:string;allowedOrigins?:string[];gameGatewayUrl?:string;gameGatewayToken?:string;gameGatewayWalletToken?:string;megaTransfersEnabled?:string;gameGatewayFetch?:typeof fetch;gameArtFetch?:typeof fetch;vpayGatewayUrl?:string;vpayOrderToken?:string;vpayQueryToken?:string;vpayCallbackToken?:string;vpayOrdersEnabled?:string;vpayMode?:string;vpayTraderId?:string;vpayReturnUrl?:string;vpayFetch?:typeof fetch;gspayGatewayUrl?:string;gspayOrderToken?:string;gspayQueryToken?:string;gspayCallbackToken?:string;gspayOrdersEnabled?:string;gspayMode?:string;gspayFetch?:typeof fetch;ownerSetupHash?:string;ownerSetupExpires?:number;ownerResetHash?:string;ownerResetExpires?:number;ownerResetIssuedAt?:number;anchorApiBaseUrl?:string;anchorUsername?:string;anchorPassword?:string;anchorSenderId?:string;otpHashSecret?:string;smsFetch?:typeof fetch;withdrawalDataKey?:string;oneMpayApiBase?:string;oneMpayMerchant?:string;oneMpaySecretKey?:string;oneMpayOrdersEnabled?:string;oneMpayCallbackUrl?:string;oneMpayReturnUrl?:string;oneMpayDiagnosticToken?:string;oneMpayFetch?:typeof fetch;rectangleApiBase?:string;rectangleOperatorCode?:string;rectangleApiKey?:string;godeeApiBase?:string;godeeOperatorId?:string;godeeApiKey?:string;gameCatalogueFetch?:typeof fetch;gameSyncToken?:string};
function vpaySettings(c:Context,user:User|null){return {db:c.db,user,gatewayUrl:c.vpayGatewayUrl,orderToken:c.vpayOrderToken,queryToken:c.vpayQueryToken,callbackToken:c.vpayCallbackToken,enabled:c.vpayOrdersEnabled,mode:c.vpayMode,vpayTraderId:c.vpayTraderId,returnUrl:c.vpayReturnUrl,fetchImpl:c.vpayFetch};}
function oneMpaySettings(c:Context,user:User|null){return {db:c.db,user,apiBase:c.oneMpayApiBase,merchant:c.oneMpayMerchant,secretKey:c.oneMpaySecretKey,enabled:c.oneMpayOrdersEnabled,callbackUrl:c.oneMpayCallbackUrl,returnUrl:c.oneMpayReturnUrl,diagnosticToken:c.oneMpayDiagnosticToken,fetchImpl:c.oneMpayFetch};}
function gspaySettings(c:Context,user:User|null){return {db:c.db,user,gatewayUrl:c.gspayGatewayUrl,orderToken:c.gspayOrderToken,queryToken:c.gspayQueryToken,callbackToken:c.gspayCallbackToken,enabled:c.gspayOrdersEnabled,mode:c.gspayMode,fetchImpl:c.gspayFetch};}
function megaWalletSettings(c:Context,user:User):MegaWalletContext{return {db:c.db,user,gatewayUrl:c.gameGatewayUrl,gameToken:c.gameGatewayToken,walletToken:c.gameGatewayWalletToken,enabled:c.megaTransfersEnabled,fetchImpl:c.gameGatewayFetch};}
function megaLaunchReady(c:Context,user:User|null){return !!user&&user.role==='member'&&!!user.approved&&megaWalletConfigured(megaWalletSettings(c,user));}
function paymentFlags(c:Context,channels:Record<string,unknown>[]){
 const active=(id:string)=>channels.some(x=>x.provider_id===id&&x.status==='active');
 const vpay=active('vpay')&&vpayOrdersConfigured(vpaySettings(c,null));
 const oneMpay=active('1mpay')&&c.oneMpayOrdersEnabled==='true'&&oneMpayConfigurationReady(oneMpaySettings(c,null));
 const gspayProgram=gspayProgramConfigured(gspaySettings(c,null));
 return {transactionsEnabled:vpay||oneMpay,realPayments:oneMpay,settlementVerified:false,providerProgramsConfigured:{gspay:gspayProgram},providerOrdersEnabled:{vpay,'1mpay':oneMpay,gspay:false,gspay_plus:false}};
}
class ApiError extends Error{ status:number; constructor(status:number,message:string){super(message);this.status=status;} }
const now=()=>Math.floor(Date.now()/1000);
const uuid=()=>crypto.randomUUID();
function accountingPeriod(search:URLSearchParams,timestamp=now()){
 const day=Math.floor((timestamp+28800)/86400)*86400-28800,shifted=new Date((timestamp+28800)*1000),year=shifted.getUTCFullYear(),month=shifted.getUTCMonth(),period=search.get('period')||'yesterday';let start:number,end:number,label:string;
 const monthStart=(y:number,m:number)=>Math.floor(Date.UTC(y,m,1)/1000)-28800;
 if(period==='month'&&/^\d{4}-\d{2}$/.test(search.get('month')||'')){const [y,m]=(search.get('month')||'').split('-').map(Number);if(y<2020||y>2100||m<1||m>12)throw new ApiError(400,'Invalid month');start=monthStart(y,m-1);end=monthStart(y,m);label=`${y}-${String(m).padStart(2,'0')}`;}
 else if(period==='month'){start=monthStart(year,month);end=monthStart(year,month+1);label=`${year}-${String(month+1).padStart(2,'0')}`;}
 else if(period==='half'){const first=month<6?0:6;start=monthStart(year,first);end=monthStart(year,first+6);label=`${year} H${first===0?1:2}`;}
 else if(period==='year'){start=monthStart(year,0);end=monthStart(year+1,0);label=String(year);}
 else if(period==='today'){start=day;end=timestamp+1;label='Today';}
 else{start=day-86400;end=day;label=new Date((start+28800)*1000).toISOString().slice(0,10);}
 return {period,start,end,label};
}
export const responseHeaders={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Cookie, oai-authenticated-user-id'};
function json(value:unknown,status=200){return new Response(JSON.stringify(value),{status,headers:responseHeaders});}
function textField(v:unknown,min:number,max:number){if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)throw new ApiError(400,'输入长度不符合要求 / Invalid input');return v.trim();}
function idField(v:unknown){return textField(v,1,128);}
function optionalNumber(v:unknown,min:number,max:number,name:string){if(v===''||v===null||v===undefined)return null;const value=typeof v==='number'?v:Number(v);if(!Number.isFinite(value)||value<min||value>max)throw new ApiError(400,`Invalid ${name}`);return value;}
function optionalInteger(v:unknown,min:number,max:number,name:string){const value=optionalNumber(v,min,max,name);if(value!==null&&!Number.isInteger(value))throw new ApiError(400,`Invalid ${name}`);return value;}
function calculateBenefit(r:any,depositMYR:number){
 const money=(value:number)=>Math.round((value+Number.EPSILON)*100)/100,min=Number(r.minDepositMYR??0),eligible=depositMYR>=min;
 const fixed=Number(r.rewardAmountMYR??0),percentage=money(depositMYR*Number(r.rewardPercent??0)/100),uncapped=money(fixed+percentage),cap=r.maxRewardMYR==null?null:Number(r.maxRewardMYR),rewardMYR=eligible?money(cap==null?uncapped:Math.min(uncapped,cap)):0;
 const turnoverBase=r.turnoverBase??'deposit_plus_bonus',baseMYR=turnoverBase==='deposit'?depositMYR:turnoverBase==='bonus'?rewardMYR:money(depositMYR+rewardMYR),turnoverMYR=r.turnoverRequiredMYR!=null?money(Number(r.turnoverRequiredMYR)):money(baseMYR*Number(r.turnoverMultiplier??0));
 return {currency:'MYR',depositMYR:money(depositMYR),eligible,minDepositMYR:min,rewardMYR,turnoverMYR,turnoverBase,turnoverMultiplier:r.turnoverMultiplier??null,fixedTurnover:r.turnoverRequiredMYR!=null,rewardFormula:{fixedMYR:fixed,percentage:Number(r.rewardPercent??0),maximumMYR:cap}};
}
function advertisementUrl(v:unknown){if(v===undefined||v===null||v==='')return '';const value=textField(v,1,500);let url:URL;try{url=new URL(value);}catch{throw new ApiError(400,'Invalid ad destination');}if(url.protocol!=='https:'||url.username||url.password||url.port)throw new ApiError(400,'Ad destination must be an HTTPS URL');return url.href;}
function validImageData(value:string){try{const encoded=value.slice(value.indexOf(',')+1),bytes=atob(encoded);if(bytes.length<16||bytes.length>350000)return false;const prefix=(start:number,end:number)=>[...bytes.slice(start,end)].map(char=>char.charCodeAt(0));const b=prefix(0,12);return value.startsWith('data:image/jpeg;')&&b[0]===0xff&&b[1]===0xd8&&b[2]===0xff||value.startsWith('data:image/png;')&&b[0]===0x89&&b[1]===0x50&&b[2]===0x4e&&b[3]===0x47&&b[4]===0x0d&&b[5]===0x0a&&b[6]===0x1a&&b[7]===0x0a||value.startsWith('data:image/webp;')&&String.fromCharCode(...b.slice(0,4))==='RIFF'&&String.fromCharCode(...b.slice(8,12))==='WEBP';}catch{return false;}}
function urlField(v:unknown,service:string){if(v==='')return '';const s=textField(v,1,300);let u:URL;try{u=new URL(s);}catch{throw new ApiError(400,'Invalid URL');}if(u.protocol!=='https:'||u.username||u.password||u.port||!['www.'+service+'.com',service+'.com'].includes(u.hostname))throw new ApiError(400,'请使用官方 HTTPS 主页地址');return u.href;}
function role(u:User|null,roles=['owner','staff','member']):asserts u is User{if(!u)throw new ApiError(401,'请先登录 / Sign in required');if(!roles.includes(u.role))throw new ApiError(403,'没有访问权限 / Access denied');}
async function currentUser(c:Context,create=false){if(!c.identity)return null;const {userId,email}=c.identity;let u=await c.db.prepare('SELECT * FROM users WHERE id=?').bind(userId).first<User>();if(!u&&create){const owner=!!c.ownerEmail&&email.toLowerCase()===c.ownerEmail.toLowerCase();await c.db.prepare('INSERT OR IGNORE INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,?)').bind(userId,email,owner?'owner':'member',owner?1:0,uuid()+uuid(),now()).run();u=await c.db.prepare('SELECT * FROM users WHERE id=?').bind(userId).first<User>();}return u;}
function auditStmt(db:D1Database,u:User,event:string,target:string){return db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(uuid(),u.id,event,target,now());}
async function rows(db:D1Database,sql:string,...values:(string|number)[]){return (await db.prepare(sql).bind(...values).all()).results;}
async function body(req:Request,maxBytes=24000){if(!req.headers.get('content-type')?.startsWith('application/json'))throw new ApiError(415,'JSON required');const reader=req.body?.getReader();if(!reader)throw new ApiError(400,'Body required');const parts:Uint8Array[]=[];let size=0;for(;;){const x=await reader.read();if(x.done)break;size+=x.value.length;if(size>maxBytes){await reader.cancel();throw new ApiError(413,'Request too large');}parts.push(x.value);}const out=new Uint8Array(size);let offset=0;for(const p of parts){out.set(p,offset);offset+=p.length;}let d;try{d=JSON.parse(new TextDecoder().decode(out));}catch{throw new ApiError(400,'Invalid JSON');}if(!d||Array.isArray(d)||typeof d!=='object')throw new ApiError(400,'Object required');return d;}
async function limited(db:D1Database,u:User,maxPerMinute=30){const bucket=Math.floor(now()/60),key=u.id+':'+bucket;const r=await db.prepare('INSERT INTO rate_limits(id,count,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=rate_limits.count+1 RETURNING count').bind(key,now()+120).first<{count:number}>();if((r?.count??maxPerMinute+1)>maxPerMinute){await auditStmt(db,u,'write_rate_limited','request').run();throw new ApiError(429,'操作过快，请稍后重试 / Too many requests');}await db.prepare('DELETE FROM rate_limits WHERE expires_at < ?').bind(now()).run();}
async function social(db:D1Database){const x=await db.prepare('SELECT value FROM settings WHERE id=?').bind('social').first<{value:string}>();return x?JSON.parse(x.value):{enabled:false,facebookUrl:'',instagramUrl:''};}
const commissionDefaults={enabled:true,basis:'deposit',maxLevels:3,claimMode:'manual',tierRatesPercent:[5,2,1],frequency:'weekly_mon',minQualifyingMYR:0,minActiveDownlines:0,dailyCapMYR:500,monthlyCapMYR:10000,lifetimeCapMYR:0,holdDays:1,expireUnclaimedDays:30,minClaimMYR:50,minAccrualMYR:.01,turnoverValue:1,turnoverType:'multiplier',winoverValue:0,winoverType:'multiplier',maxWithdrawFixedMYR:0,maxWithdrawMultiplier:0,gameCategory:'all',eligibleGames:'',startsAt:'',endsAt:''};
function finiteSetting(value:unknown,fallback:number,min:number,max:number,integer=false){const parsed=Number(value);return Number.isFinite(parsed)&&parsed>=min&&parsed<=max?(integer?Math.round(parsed):Math.round((parsed+Number.EPSILON)*100)/100):fallback;}
function normalizedCommissionSettings(value:any){
 const raw=value&&typeof value==='object'&&!Array.isArray(value)?value:{},legacyRate=Number.isInteger(raw.rateBasisPoints)?raw.rateBasisPoints/100:commissionDefaults.tierRatesPercent[0],rates=Array.isArray(raw.tierRatesPercent)?raw.tierRatesPercent:[];
 return {...commissionDefaults,enabled:raw.enabled!==false,basis:['deposit','turnover','company_profit'].includes(raw.basis)?raw.basis:'deposit',maxLevels:finiteSetting(raw.maxLevels,commissionDefaults.maxLevels,1,3,true),claimMode:['manual','automatic'].includes(raw.claimMode)?raw.claimMode:'manual',tierRatesPercent:[0,1,2].map(index=>finiteSetting(rates[index],index?commissionDefaults.tierRatesPercent[index]:legacyRate,0,100)),frequency:['daily','weekly_mon','monthly'].includes(raw.frequency)?raw.frequency:'weekly_mon',minQualifyingMYR:finiteSetting(raw.minQualifyingMYR,0,0,1000000),minActiveDownlines:finiteSetting(raw.minActiveDownlines,0,0,100000,true),dailyCapMYR:finiteSetting(raw.dailyCapMYR,500,0,1000000),monthlyCapMYR:finiteSetting(raw.monthlyCapMYR,10000,0,10000000),lifetimeCapMYR:finiteSetting(raw.lifetimeCapMYR,0,0,100000000),holdDays:finiteSetting(raw.holdDays,1,0,3650,true),expireUnclaimedDays:finiteSetting(raw.expireUnclaimedDays,30,0,3650,true),minClaimMYR:finiteSetting(raw.minClaimMYR,50,0,1000000),minAccrualMYR:finiteSetting(raw.minAccrualMYR,.01,.01,100000),turnoverValue:finiteSetting(raw.turnoverValue,1,0,1000000),turnoverType:['multiplier','fixed'].includes(raw.turnoverType)?raw.turnoverType:'multiplier',winoverValue:finiteSetting(raw.winoverValue,0,0,1000000),winoverType:['multiplier','fixed'].includes(raw.winoverType)?raw.winoverType:'multiplier',maxWithdrawFixedMYR:finiteSetting(raw.maxWithdrawFixedMYR,0,0,10000000),maxWithdrawMultiplier:finiteSetting(raw.maxWithdrawMultiplier,0,0,10000),gameCategory:typeof raw.gameCategory==='string'&&/^(all|slot|live|fish|sport|fast_game)$/.test(raw.gameCategory)?raw.gameCategory:'all',eligibleGames:typeof raw.eligibleGames==='string'?raw.eligibleGames.slice(0,2000):'',startsAt:typeof raw.startsAt==='string'?raw.startsAt.slice(0,32):'',endsAt:typeof raw.endsAt==='string'?raw.endsAt.slice(0,32):''};
}
function commissionInput(value:any){
 if(!value||typeof value!=='object'||Array.isArray(value))throw new ApiError(400,'Invalid commission settings');
 const required=(key:string,min:number,max:number,integer=false)=>{const parsed=Number(value[key]);if(!Number.isFinite(parsed)||parsed<min||parsed>max)throw new ApiError(400,`Invalid ${key}`);return integer?Math.round(parsed):Math.round((parsed+Number.EPSILON)*100)/100;},choice=(key:string,values:string[])=>{if(typeof value[key]!=='string'||!values.includes(value[key]))throw new ApiError(400,`Invalid ${key}`);return value[key];},date=(key:string)=>{const input=value[key];if(input===undefined||input===null||input==='')return '';const normalized=typeof input==='string'&&input.length===16?input+':00':input;if(typeof input!=='string'||input.length>32||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/.test(input)||!Number.isFinite(Date.parse(normalized+'+08:00')))throw new ApiError(400,`Invalid ${key}`);return input;};
 const rates=value.tierRatesPercent;if(!Array.isArray(rates)||rates.length!==3)throw new ApiError(400,'Three tier rates are required');
 return {enabled:typeof value.enabled==='boolean'?value.enabled:(()=>{throw new ApiError(400,'Invalid commission state')})(),basis:choice('basis',['deposit','turnover','company_profit']),maxLevels:required('maxLevels',1,3,true),claimMode:choice('claimMode',['manual','automatic']),tierRatesPercent:rates.map((rate:any,index:number)=>{const parsed=Number(rate);if(!Number.isFinite(parsed)||parsed<0||parsed>100)throw new ApiError(400,`Invalid L${index+1} rate`);return Math.round((parsed+Number.EPSILON)*100)/100;}),frequency:choice('frequency',['daily','weekly_mon','monthly']),minQualifyingMYR:required('minQualifyingMYR',0,1000000),minActiveDownlines:required('minActiveDownlines',0,100000,true),dailyCapMYR:required('dailyCapMYR',0,1000000),monthlyCapMYR:required('monthlyCapMYR',0,10000000),lifetimeCapMYR:required('lifetimeCapMYR',0,100000000),holdDays:required('holdDays',0,3650,true),expireUnclaimedDays:required('expireUnclaimedDays',0,3650,true),minClaimMYR:required('minClaimMYR',0,1000000),minAccrualMYR:required('minAccrualMYR',.01,100000),turnoverValue:required('turnoverValue',0,1000000),turnoverType:choice('turnoverType',['multiplier','fixed']),winoverValue:required('winoverValue',0,1000000),winoverType:choice('winoverType',['multiplier','fixed']),maxWithdrawFixedMYR:required('maxWithdrawFixedMYR',0,10000000),maxWithdrawMultiplier:required('maxWithdrawMultiplier',0,10000),gameCategory:choice('gameCategory',['all','slot','live','fish','sport','fast_game']),eligibleGames:typeof value.eligibleGames==='string'?value.eligibleGames.slice(0,2000):'',startsAt:date('startsAt'),endsAt:date('endsAt')};
}
async function referralSettings(db:D1Database){
 const row=await db.prepare("SELECT value FROM settings WHERE id='referral_program'").first<{value:string}>();let value:any={};try{value=row?JSON.parse(row.value):{};}catch{}const settings=normalizedCommissionSettings(value),rateBasisPoints=Math.round(settings.tierRatesPercent[0]*100);return {...settings,rateBasisPoints};
}
function latestCommissionPeriod(frequency:string,at=now()){
 const offset=8*3600,shifted=new Date((at+offset)*1000),midnight=Math.floor(Date.UTC(shifted.getUTCFullYear(),shifted.getUTCMonth(),shifted.getUTCDate())/1000)-offset;
 if(frequency==='daily')return {start:midnight-86400,end:midnight};
 if(frequency==='monthly'){const end=Math.floor(Date.UTC(shifted.getUTCFullYear(),shifted.getUTCMonth(),1)/1000)-offset,start=Math.floor(Date.UTC(shifted.getUTCFullYear(),shifted.getUTCMonth()-1,1)/1000)-offset;return {start,end};}
 const sinceMonday=(shifted.getUTCDay()+6)%7,end=midnight-sinceMonday*86400;return {start:end-7*86400,end};
}
function mytSettingEpoch(value:string){if(!value)return null;const normalized=value.length===16?value+':00':value,ms=Date.parse(normalized+'+08:00');return Number.isFinite(ms)?Math.floor(ms/1000):null;}
async function commissionPreview(db:D1Database,settings:any){
 const period=latestCommissionPeriod(settings.frequency),basisReady=settings.basis==='deposit',startLimit=mytSettingEpoch(settings.startsAt),endLimit=mytSettingEpoch(settings.endsAt),scheduleActive=(startLimit===null||period.end>startLimit)&&(endLimit===null||period.start<endLimit);
 const relationships=await rows(db,'SELECT member_id,referrer_id,created_at FROM referral_relationships ORDER BY created_at ASC'),users=await rows(db,'SELECT id,username FROM users'),names=new Map(users.map((item:any)=>[String(item.id),String(item.username)])),parent=new Map(relationships.map((item:any)=>[String(item.member_id),String(item.referrer_id)]));
 const deposits=basisReady&&scheduleActive?await rows(db,"SELECT user_id,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) basis_minor,COUNT(*) orders FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<? GROUP BY user_id",period.start,period.end):[],minBasis=BigInt(Math.round(settings.minQualifyingMYR*100)),unit=BigInt(Math.max(1,Math.round(settings.minAccrualMYR*100))),raw:any[]=[];
 for(const item of deposits as any[]){const sourceId=String(item.user_id),basis=BigInt(String(item.basis_minor??0));if(basis<minBasis)continue;let upline=parent.get(sourceId);for(let level=1;level<=settings.maxLevels&&upline;level++){const rate=Math.round(settings.tierRatesPercent[level-1]*100);let amount=basis*BigInt(rate)/10000n;amount=amount/unit*unit;if(amount>0n)raw.push({uplineId:upline,uplineUsername:names.get(upline)??upline,sourceMemberId:sourceId,sourceMemberUsername:names.get(sourceId)??sourceId,level,ratePercent:settings.tierRatesPercent[level-1],basisMinor:basis.toString(),orders:Number(item.orders??0),commissionMinor:amount.toString(),availableAt:period.end+settings.holdDays*86400,expiresAt:settings.expireUnclaimedDays?period.end+(settings.holdDays+settings.expireUnclaimedDays)*86400:null,status:settings.holdDays?'held':'claimable'});upline=parent.get(upline);}}
 const sourcesByUpline=new Map<string,Set<string>>();for(const entry of raw){if(!sourcesByUpline.has(entry.uplineId))sourcesByUpline.set(entry.uplineId,new Set());sourcesByUpline.get(entry.uplineId)!.add(entry.sourceMemberId);}let ledger=raw.filter(entry=>(sourcesByUpline.get(entry.uplineId)?.size??0)>=settings.minActiveDownlines);
 const periodDays=Math.max(1,Math.round((period.end-period.start)/86400)),dailyCap=BigInt(Math.round(settings.dailyCapMYR*100))*BigInt(periodDays),monthlyCap=BigInt(Math.round(settings.monthlyCapMYR*100)),cap=dailyCap&&monthlyCap?(dailyCap<monthlyCap?dailyCap:monthlyCap):(dailyCap||monthlyCap),used=new Map<string,bigint>();
 if(cap>0n)ledger=ledger.map(entry=>{const current=used.get(entry.uplineId)??0n,remaining=cap>current?cap-current:0n,amount=BigInt(entry.commissionMinor),applied=amount<remaining?amount:remaining;used.set(entry.uplineId,current+applied);return {...entry,commissionMinor:applied.toString(),capped:applied<amount};}).filter(entry=>BigInt(entry.commissionMinor)>0n);
 const grouped=new Map<string,any>();for(const entry of ledger){const item=grouped.get(entry.uplineId)??{uplineId:entry.uplineId,uplineUsername:entry.uplineUsername,downlines:new Set<string>(),basisMinor:0n,commissionMinor:0n,entries:0};item.downlines.add(entry.sourceMemberId);item.basisMinor+=BigInt(entry.basisMinor);item.commissionMinor+=BigInt(entry.commissionMinor);item.entries++;grouped.set(entry.uplineId,item);}
 const byUpline=[...grouped.values()].map(item=>({uplineId:item.uplineId,uplineUsername:item.uplineUsername,activeDownlines:item.downlines.size,basisMinor:item.basisMinor.toString(),commissionMinor:item.commissionMinor.toString(),entries:item.entries})).sort((a,b)=>BigInt(a.commissionMinor)===BigInt(b.commissionMinor)?0:BigInt(a.commissionMinor)>BigInt(b.commissionMinor)?-1:1),totalBasisMinor=ledger.reduce((sum,entry)=>sum+BigInt(entry.basisMinor),0n).toString(),totalCommissionMinor=ledger.reduce((sum,entry)=>sum+BigInt(entry.commissionMinor),0n).toString();
 return {basis:settings.basis,basisReady,scheduleActive,reason:!basisReady?'Selected basis data is not connected':!scheduleActive?'Program is outside its configured date range':'',period:{...period,timezone:'MYT (+08:00)',frequency:settings.frequency},relationshipCount:relationships.length,ledger,byUpline,totalBasisMinor,totalCommissionMinor,walletCreditAutomated:false,claimMode:settings.claimMode};
}
async function supportAutomationSettings(db:D1Database){
 const row=await db.prepare("SELECT value FROM settings WHERE id='support_automation'").first<{value:string}>();let value:any={};try{value=row?JSON.parse(row.value):{};}catch{}
 return {aiEnabled:value.aiEnabled===true,humanHandoff:value.humanHandoff!==false,providerReady:false,effectiveAiReply:false,status:'awaiting_provider_verification'};
}
async function ensureReferralCode(db:D1Database,userId:string){
 const existing=await db.prepare('SELECT code FROM referral_codes WHERE user_id=?').bind(userId).first<{code:string}>();if(existing)return existing.code;
 for(let attempt=0;attempt<4;attempt++){const code=crypto.randomUUID().replace(/-/g,'').slice(0,10).toUpperCase();try{await db.prepare('INSERT INTO referral_codes(code,user_id,created_at) VALUES(?,?,?) ON CONFLICT(user_id) DO NOTHING').bind(code,userId,now()).run();const saved=await db.prepare('SELECT code FROM referral_codes WHERE user_id=?').bind(userId).first<{code:string}>();if(saved)return saved.code;}catch{} }
 throw new ApiError(503,'Referral code is temporarily unavailable');
}
function referralCommission(amount:unknown,rateBasisPoints:number){return (BigInt(String(amount??0))*BigInt(rateBasisPoints)/10000n).toString();}
function malaysiaMarketingPhone(value:unknown){
 if(typeof value!=='string')return null;let digits=value.replace(/\D/g,'');
 if(digits.startsWith('60'))digits=digits.slice(2);if(digits.startsWith('0'))digits=digits.slice(1);
 if(!/^1\d{8,9}$/.test(digits))return null;return `+60${digits}`;
}
function csvCell(value:unknown){const text=String(value??'');return /[",\r\n]/.test(text)?`"${text.replace(/"/g,'""')}"`:text;}
const vendorCategories=['SLOT','FAST GAME','LIVE','FISH','SPORT','OTHERS'] as const;
type VendorCategory=typeof vendorCategories[number];
const apiSupplierIds=['megah5','jili','918kissh5','gameplay','lionking','suncity','pgsoft','gfg','sagaming','ps9','dragoonsoft','jdb','bg','allbet','quickspin','astar','metagaming','fuma','yl','funky','gamitech','spadegaming','turbo','ct855','pragmaticplay','joker','cg','atg','rectangle','m8bet','awc','evo888h5','cosmoplay','geminiupdown','epicwin','venus','clotplay','godeezone'];
function publicImage(value:unknown,host:string){if(!host||typeof value!=='string'||value.length>500)return null;try{const u=new URL(value);return u.protocol==='https:'&&u.hostname===host&&!u.username&&!u.password&&!u.port&&u.pathname.startsWith('/thumbs/')&&!u.search&&!u.hash?u.href:null;}catch{return null;}}
function gameArtPath(provider:string,gameCode:string,imageUrl:string|null){return imageUrl&&['megah5','918kissh5'].includes(provider)?`/api/game-art?provider=${encodeURIComponent(provider)}&gameCode=${encodeURIComponent(gameCode)}`:provider==='jili'?'/assets/providers/jili.webp':null;}
async function gameArt(req:Request,c:Context){
 const search=new URL(req.url).searchParams,provider=search.get('provider')??'',gameCode=search.get('gameCode')??'';
 if(!/^[A-Za-z0-9_-]{1,100}$/.test(gameCode)||!['megah5','918kissh5','evo888h5'].includes(provider))throw new ApiError(404,'Game artwork not found');
 const host=provider==='megah5'?'gth.megah5.com':'gth.kissh5.com';
 const artwork=provider==='evo888h5'?await cachedGameArtwork(c,provider,gameCode):`https://${host}/thumbs/web/${encodeURIComponent(gameCode)}.png`;
 if(!artwork)throw new ApiError(404,'Game artwork not found');
 const source=new URL(artwork),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
 try{
  const response=await (c.gameArtFetch??fetch)(source,{method:'GET',headers:{Accept:'image/avif,image/webp,image/png,image/*','User-Agent':'MASTER7-Game-Art/1.0','Referer':new URL(req.url).origin+'/'},redirect:'error',signal:controller.signal});
  const type=(response.headers.get('content-type')??'').split(';')[0].trim().toLowerCase(),declared=Number(response.headers.get('content-length')??0);
  if(!response.ok||!['image/png','image/jpeg','image/webp'].includes(type)||declared>1024*1024)throw new ApiError(404,'Game artwork not found');
  const bytes=await response.arrayBuffer();if(bytes.byteLength<16||bytes.byteLength>1024*1024)throw new ApiError(404,'Game artwork not found');
  return new Response(bytes,{headers:{'Content-Type':type,'Cache-Control':'public, max-age=86400, stale-while-revalidate=604800','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
 }catch(error){if(error instanceof ApiError)throw error;throw new ApiError(404,'Game artwork not found');}finally{clearTimeout(timer);}
}
async function gatewayGames(c:Context){return getGameCatalogue(c);}
async function applyGameVisibility(db:D1Database,catalog:any,includeClosed:boolean){
 const overrides=await rows(db,'SELECT provider_id,game_code,visible,status,image_data,category_override,access_zone FROM game_visibility');
 const records=new Map(overrides.map((x:any)=>[`${x.provider_id}:${x.game_code}`,x]));
 const games=catalog.games.map((game:any)=>{
  const override=records.get(`${game.provider}:${game.gameCode||game.name}`) as any;
  const configuredStatus=override?.status||'active';
  const status=configuredStatus==='closed'?'closed':game.maintenance?'suspended':configuredStatus;
  return {...game,status,configuredStatus,providerMaintenance:!!game.maintenance,categoryOverride:override?.category_override||'',accessZone:override?.access_zone==='free'?'free':'paid',imageData:override?.image_data||''};
 }).filter((game:any)=>includeClosed||game.status!=='closed');
 return {...catalog,games,providers:catalog.providers.map((provider:any)=>({...provider,count:games.filter((game:any)=>game.provider===provider.id).length}))};
}
function launchClientIp(req:Request){
 const candidates=[req.headers.get('cf-connecting-ip'),...(req.headers.get('x-forwarded-for')??'').split(',')];
 return candidates.map(value=>value?.trim()??'').find(value=>{const parts=value.split('.');return parts.length===4&&parts.every(part=>/^\d{1,3}$/.test(part)&&Number(part)<=255);})??'';
}
async function launchMegaH5(req:Request,c:Context,u:User,d:any){
 const gameCode=textField(d.gameCode,1,100);if(!/^\d{1,12}$/.test(gameCode))throw new ApiError(400,'Invalid MegaH5 game');
 if(c.gameGatewayUrl!=='https://master7-integration-gateway.onrender.com'||!c.gameGatewayToken||Buffer.byteLength(c.gameGatewayToken)<32)throw new ApiError(503,'MegaH5 launch connection is not active');
 if(!megaWalletConfigured(megaWalletSettings(c,u)))throw new ApiError(503,'MegaH5 game wallet is awaiting production acceptance');
 const catalogue=await applyGameVisibility(c.db,await gatewayGames(c),false),game=catalogue.games.find((item:any)=>item.provider==='megah5'&&item.gameCode===gameCode);
 if(!game||game.status!=='active')throw new ApiError(409,'Game is unavailable or under maintenance');
 const ip=launchClientIp(req);if(!ip)throw new ApiError(400,'Player network address is unavailable');
 const playerId=`m7_${createHash('sha256').update(u.id).digest('hex').slice(0,32)}`,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const response=await(c.gameGatewayFetch??fetch)(`${c.gameGatewayUrl}/platform/megah5/session`,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${c.gameGatewayToken}`},body:JSON.stringify({playerId,gameCode,ip,lang:'en-us'}),redirect:'error',signal:controller.signal});
  const type=response.headers.get('content-type')??'';if(!response.ok||response.redirected||!/^application\/json(?:;|$)/i.test(type))throw new ApiError(502,'MegaH5 launch was rejected');
  const raw=await response.text();if(Buffer.byteLength(raw)>65536)throw new ApiError(502,'MegaH5 launch response is invalid');let result:any;try{result=JSON.parse(raw);}catch{throw new ApiError(502,'MegaH5 launch response is invalid');}
  const urlValue=result?.result?.Url??result?.result?.URL??result?.result?.GameUrl??result?.result?.GameURL;let launchUrl:URL;try{launchUrl=new URL(String(urlValue??''));}catch{throw new ApiError(502,'MegaH5 launch URL is missing');}
  if(launchUrl.protocol!=='https:'||launchUrl.username||launchUrl.password||launchUrl.hash)throw new ApiError(502,'MegaH5 launch URL is invalid');
  const prepared=await prepareMegaWallet(megaWalletSettings(c,u),gameCode);
  await auditStmt(c.db,u,'game_launch_created',`megah5:${gameCode}`).run();return json({provider:'megah5',gameCode,launchUrl:launchUrl.href,walletVerified:prepared.walletVerified,walletSessionId:prepared.sessionId,amountInGameMinor:prepared.amountOutMinor});
 }catch(error){if(error instanceof ApiError||error instanceof MegaWalletError)throw error;throw new ApiError(503,'MegaH5 launch is temporarily unavailable');}finally{clearTimeout(timer);}
}
export async function handle(req:Request,c:Context):Promise<Response>{try{return await route(req,c);}catch(e){if(e instanceof ApiError||e instanceof AuthError||e instanceof MegaWalletError)return json({error:e.message},e.status);const code=e&&typeof e==='object'&&'code'in e&&typeof e.code==='string'&&/^[A-Z0-9]{5}$/.test(e.code)?e.code:'unknown';console.error('MASTER7 API unavailable',e instanceof Error?e.name:'Error',code);return json({error:'服务暂时不可用 / Service temporarily unavailable'},503);}}
async function route(req:Request,c:Context){
 const p=new URL(req.url).pathname,db=c.db;
 if(req.method==='GET'&&(p==='/health'||p==='/api/version')){await db.prepare('SELECT id FROM users LIMIT 1').all();const megaWalletCredentialsConfigured=c.gameGatewayUrl==='https://master7-integration-gateway.onrender.com'&&!!c.gameGatewayToken&&!!c.gameGatewayWalletToken&&c.gameGatewayToken!==c.gameGatewayWalletToken&&Buffer.byteLength(c.gameGatewayToken)>=32&&Buffer.byteLength(c.gameGatewayWalletToken)>=32;return json({status:'ok',release:RELEASE,sourceRelease:SOURCE_RELEASE,database:'ready',smsOtpReady:!!(c.anchorApiBaseUrl&&c.anchorUsername&&c.anchorPassword&&c.anchorSenderId&&c.otpHashSecret&&c.otpHashSecret.length>=32),mode:'selfbuilt-service-portal',...paymentFlags(c,await rows(db,'SELECT provider_id,status FROM payment_channel_controls')),megaWallet:{configured:megaWalletCredentialsConfigured,enabled:c.megaTransfersEnabled==='true',settlementVerified:false,liveReady:false},liveGames:false,productionReady:false,scope:'portal-database-health'});}
 if(req.method==='GET'&&p==='/api/internal/catalogue-sync'){const token=c.gameSyncToken??'',auth=req.headers.get('authorization')??'',given=auth.startsWith('Bearer ')?auth.slice(7):'';if(token.length<32||Buffer.byteLength(given)!==Buffer.byteLength(token)||!timingSafeEqual(Buffer.from(given),Buffer.from(token)))return json({error:'Access denied'},401);const catalogue=await getGameCatalogue(c);return json({providers:catalogue.providers,gameCount:catalogue.games.length,playable:false});}
 if(req.method==='GET'&&p==='/api/game-art')return gameArt(req,c);
 if(!['GET','POST'].includes(req.method))throw new ApiError(405,'Method not allowed');
 const gspayCallback=await handleGSPayCallback(req,gspaySettings(c,null));
 if(gspayCallback)return gspayCallback;
 const local=await readLocalSession(req,db);
 if(p.startsWith('/api/auth/'))return handlePasswordAuth(req,c,local);
 const u=local?.user??await currentUser(c,p==='/api/session'&&req.method==='GET');
 const vpayContext=vpaySettings(c,u);
 const vpayResponse=await handleVPay(req,vpayContext);
 if(vpayResponse)return vpayResponse;
 const oneMpayContext=oneMpaySettings(c,u);
 const oneMpayResponse=await handleOneMpay(req,oneMpayContext);
 if(oneMpayResponse)return oneMpayResponse;
 const gspayContext=gspaySettings(c,u);
 const gspayResponse=await handleGSPay(req,gspayContext);
 if(gspayResponse)return gspayResponse;
  if(req.method==='GET'){const manual=await manualBankGet(req,{db,user:u});if(manual)return manual;}
 if(req.method==='GET'){
  if(p==='/api/session')return json({user:u?{id:u.id,username:u.username,role:u.role,approved:!!u.approved}:null,csrf:u?.csrf??null,authMethod:u?(local?'password':'chatgpt'):null});
  if(p==='/api/referral'){
   role(u);const code=await ensureReferralCode(db,u.id),config=await referralSettings(db),origin=new URL(req.url).origin;
   const items=await rows(db,"SELECT r.member_id,u.username,u.approved,r.created_at,CAST(COALESCE(SUM(CASE WHEN d.status='credited' THEN d.amount_minor ELSE 0 END),0) AS TEXT) deposit_minor,COUNT(DISTINCT CASE WHEN d.status='credited' THEN d.id END) deposit_orders FROM referral_relationships r JOIN users u ON u.id=r.member_id LEFT JOIN deposit_orders d ON d.user_id=r.member_id WHERE r.referrer_id=? GROUP BY r.member_id,u.username,u.approved,r.created_at ORDER BY r.created_at DESC LIMIT 500",u.id);
   const canCalculate=config.enabled&&config.basis==='deposit',creditedMinor=items.reduce((sum:any,item:any)=>sum+BigInt(String(item.deposit_minor??0)),0n).toString(),commissionMinor=canCalculate?referralCommission(creditedMinor,config.rateBasisPoints):'0';
   return json({code,link:`${origin}/register?ref=${encodeURIComponent(code)}`,enabled:config.enabled,basis:config.basis,basisReady:config.basis==='deposit',rateBasisPoints:config.rateBasisPoints,ratePercent:config.rateBasisPoints/100,referredCount:items.length,creditedMinor,commissionMinor,items:items.map((item:any)=>({...item,commission_minor:canCalculate?referralCommission(item.deposit_minor,config.rateBasisPoints):'0'}))});
  }
  if(p==='/api/withdrawal-banks')return getWithdrawalBanks();
  if(p==='/api/withdrawals')return listMemberWithdrawals({db,user:u,dataKey:c.withdrawalDataKey});
  if(p==='/api/game-wallet'){role(u,['member']);if(!u.approved)throw new ApiError(403,'Account awaiting approval');return json(await memberMegaWalletState(megaWalletSettings(c,u)));}
  if(p==='/api/announcements')return json({items:await rows(db,'SELECT id,title,body,created_at FROM announcements ORDER BY created_at DESC,id DESC LIMIT 100')});
  if(p==='/api/ads')return json({items:await rows(db,'SELECT id,title,image_data,target_url,position FROM lobby_ads WHERE enabled=1 ORDER BY position ASC,created_at DESC,id ASC LIMIT 20')});
  if(p==='/api/payment-channels'){const items=await rows(db,'SELECT provider_id,provider_name,status FROM payment_channel_controls ORDER BY CASE provider_id WHEN \'vpay\' THEN 1 WHEN \'gspay\' THEN 2 WHEN \'1mpay\' THEN 3 ELSE 4 END');return json({items,...paymentFlags(c,items)});}
  if(p==='/api/custom-games')return json({playable:false,items:[]});
  if(p==='/api/benefits'){const items=await rows(db,"SELECT id,title,description,rules_json,created_at,updated_at FROM benefit_rules WHERE status='active' ORDER BY updated_at DESC,id ASC LIMIT 100");return json({items:items.map((x:any)=>({...x,rules:JSON.parse(x.rules_json)})),calculation:'system'});}
  if(p==='/api/benefits/calculate'){const q=new URL(req.url).searchParams,id=q.get('id')??'',deposit=Number(q.get('deposit'));if(!id||!Number.isFinite(deposit)||deposit<0.01||deposit>1000000)throw new ApiError(400,'Invalid benefit or deposit amount');const item=await db.prepare("SELECT rules_json FROM benefit_rules WHERE id=? AND status='active'").bind(id).first<{rules_json:string}>();if(!item)throw new ApiError(404,'Benefit not found');return json(calculateBenefit(JSON.parse(item.rules_json),deposit));}
  if(p==='/api/supplier-art-list')return json({items:await rows(db,"SELECT provider_id,status,CASE WHEN image_data<>'' THEN updated_at ELSE NULL END image_updated_at FROM api_supplier_artwork ORDER BY provider_id")});
  if(p==='/api/supplier-art'){
   const providerId=new URL(req.url).searchParams.get('provider')??'';if(!apiSupplierIds.includes(providerId))throw new ApiError(404,'Supplier artwork not found');
   const entry=await db.prepare('SELECT image_data FROM api_supplier_artwork WHERE provider_id=?').bind(providerId).first<{image_data:string}>(),match=entry?.image_data?.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);
   if(!match||!validImageData(entry!.image_data))throw new ApiError(404,'Supplier artwork not found');
   const bytes=Uint8Array.from(atob(match[2]),char=>char.charCodeAt(0));return new Response(bytes,{headers:{'Content-Type':match[1],'Cache-Control':'public, max-age=60','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
  }
  if(p==='/api/brand-directory'){
   const items=await rows(db,"SELECT id,category,display_name,position,marked,status,image_data FROM brand_directory_entries WHERE status IN ('active','suspended') ORDER BY CASE category WHEN 'SLOT' THEN 1 WHEN 'FAST GAME' THEN 2 WHEN 'LIVE' THEN 3 WHEN 'FISH' THEN 4 WHEN 'SPORT' THEN 5 ELSE 6 END,position,id LIMIT 100");
   return json({items:items.map((x:any)=>({id:x.id,category:x.category,display_name:x.display_name,position:x.position,marked:x.marked,status:x.status,imageAvailable:!!x.image_data,integrationState:'not_configured'})),categories:vendorCategories,playable:false});
  }
  if(p==='/api/brand-directory-art'){
   const id=new URL(req.url).searchParams.get('id');if(!id)throw new ApiError(400,'Provider ID required');
   const entry=await c.db.prepare("SELECT image_data FROM brand_directory_entries WHERE id=? AND status IN ('active','suspended')").bind(id).first<{image_data:string}>();
   const match=entry?.image_data?.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);
   if(!match||!validImageData(entry!.image_data))throw new ApiError(404,'Artwork not found');
   const bytes=Uint8Array.from(atob(match[2]),char=>char.charCodeAt(0));
   return new Response(bytes,{headers:{'Content-Type':match[1],'Cache-Control':'private, max-age=60','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}});
  }
  if(p==='/api/admin/game-sync'){role(u,['owner','staff']);const catalogue=await gatewayGames(c);return json({providers:catalogue.providers,gameCount:catalogue.games.length,syncIntervalSeconds:300,playable:false});}
  if(p==='/api/admin/games'){role(u,['owner','staff']);return json({...await applyGameVisibility(db,await gatewayGames(c),true),playable:false});}
  if(p==='/api/games'){
   const catalogue=await applyGameVisibility(db,await gatewayGames(c),false),ready=megaLaunchReady(c,u);
   return json({...catalogue,games:catalogue.games.map((game:any)=>({...game,playable:ready&&game.provider==='megah5'&&game.status==='active'})),playable:ready,launchProvider:ready?'megah5':null});
  }
  if(p==='/api/providers')return json({items:await rows(db,u&&['staff','owner'].includes(u.role)?'SELECT * FROM providers ORDER BY name':'SELECT * FROM providers WHERE visible=1 ORDER BY name'),playable:false});
  if(p==='/api/social-links'){const s=await social(db);return json(s.enabled?s:{enabled:false,facebookUrl:'',instagramUrl:''});}
  if(p==='/api/tickets'){
   role(u);const staff=u.role!=='member';const items=await rows(db,'SELECT t.*,u.username FROM tickets t JOIN users u ON u.id=t.user_id '+(staff?'':'WHERE t.user_id=? ')+'ORDER BY t.created_at DESC,t.id DESC LIMIT 100',...(staff?[]:[u.id]));
   const replies=await rows(db,'SELECT r.*,u.username FROM replies r JOIN users u ON u.id=r.user_id JOIN tickets t ON t.id=r.ticket_id '+(staff?'':'WHERE t.user_id=? ')+'ORDER BY r.created_at,r.id LIMIT 1000',...(staff?[]:[u.id]));
   return json({items:items.map(t=>({...t,replies:replies.filter(r=>r.ticket_id===t.id)}))});
  }
  if(p.startsWith('/api/admin/')){
   role(u,['owner','staff']);
   if(p==='/api/admin/summary'){const summary=await db.prepare("SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM users WHERE approved=0) pending,(SELECT COUNT(*) FROM tickets WHERE status='open') ticketsOpen,(SELECT COUNT(*) FROM providers WHERE visible=1) providersVisible").first();return json({...summary,financialMetrics:'not-connected'});}
   if(p==='/api/admin/payment-channels')return json({items:await rows(db,'SELECT provider_id,provider_name,status,updated_at FROM payment_channel_controls ORDER BY CASE provider_id WHEN \'vpay\' THEN 1 WHEN \'gspay\' THEN 2 WHEN \'1mpay\' THEN 3 ELSE 4 END')});
   if(p==='/api/admin/game-wallet')return json(await adminMegaWalletSessions(megaWalletSettings(c,u)));
   if(p==='/api/admin/brand-directory')return json({items:(await rows(db,"SELECT id,category,display_name,position,marked,status,image_data,updated_at FROM brand_directory_entries ORDER BY CASE category WHEN 'SLOT' THEN 1 WHEN 'FAST GAME' THEN 2 WHEN 'LIVE' THEN 3 WHEN 'FISH' THEN 4 WHEN 'SPORT' THEN 5 ELSE 6 END,position,id")).map((x:any)=>({...x,integrationState:'not_configured'})),categories:vendorCategories,imageSize:'800x600',imageMaxBytes:350000});
   if(p==='/api/admin/ads')return json({items:await rows(db,'SELECT id,title,image_data,target_url,enabled,position,created_at,updated_at FROM lobby_ads ORDER BY position ASC,created_at DESC,id ASC LIMIT 20'),maxAds:20,imageMaxBytes:350000,desktopSize:'1200x360',rotationSeconds:300});
   if(p==='/api/admin/custom-games')return json({items:await rows(db,'SELECT id,title,provider_name,game_code,category,image_data,is_platform_mini,enabled,status,position,created_at,updated_at FROM custom_game_cards ORDER BY is_platform_mini DESC,provider_name ASC,position ASC,created_at ASC LIMIT 100'),maxCards:100,maxPlatformMiniGames:5,imageMaxBytes:350000,imageSize:'800x600'});
   if(p==='/api/admin/benefits'){const items=await rows(db,'SELECT id,title,description,rules_json,status,created_at,updated_at FROM benefit_rules ORDER BY updated_at DESC,id ASC LIMIT 100');return json({items:items.map((x:any)=>({...x,rules:JSON.parse(x.rules_json)})),calculationAutomation:true,walletCreditAutomation:false});}
   if(p==='/api/admin/social-links')return json({...await social(db),canEdit:u.role==='owner'});
   if(p==='/api/admin/referrals'){
    role(u,['owner']);const config=await referralSettings(db),items=await rows(db,"SELECT r.referrer_id,ref.username referrer_username,r.member_id,member.username member_username,member.approved,r.code,r.created_at,CAST(COALESCE(SUM(CASE WHEN d.status='credited' THEN d.amount_minor ELSE 0 END),0) AS TEXT) deposit_minor,COUNT(DISTINCT CASE WHEN d.status='credited' THEN d.id END) deposit_orders FROM referral_relationships r JOIN users ref ON ref.id=r.referrer_id JOIN users member ON member.id=r.member_id LEFT JOIN deposit_orders d ON d.user_id=r.member_id GROUP BY r.referrer_id,ref.username,r.member_id,member.username,member.approved,r.code,r.created_at ORDER BY r.created_at DESC LIMIT 1000"),preview=await commissionPreview(db,config);
    const canCalculate=config.enabled&&config.basis==='deposit',totalDepositMinor=items.reduce((sum:any,item:any)=>sum+BigInt(String(item.deposit_minor??0)),0n).toString();return json({settings:config,...config,ratePercent:config.rateBasisPoints/100,relationshipCount:items.length,totalDepositMinor,totalCommissionMinor:canCalculate?referralCommission(totalDepositMinor,config.rateBasisPoints):'0',walletCreditAutomation:false,preview,items:items.map((item:any)=>({...item,commission_minor:canCalculate?referralCommission(item.deposit_minor,config.rateBasisPoints):'0'}))});
   }
   if(p==='/api/admin/support-settings'){role(u,['owner']);return json(await supportAutomationSettings(db));}
   if(p==='/api/admin/system-readiness'){
     const [counts,support,backupAudit,rehearsalRow]=await Promise.all([
      db.prepare("SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM audit) audit_events,(SELECT COUNT(*) FROM tickets) tickets,(SELECT COUNT(*) FROM settings) settings").first<any>(),
      supportAutomationSettings(db),
      db.prepare("SELECT COUNT(*) n FROM audit WHERE event='encrypted_backup_created'").first<{n:number}>(),
      db.prepare("SELECT value FROM settings WHERE id='backup_restore_rehearsal'").first<{value:string}>()
     ]);
     let rehearsal:any=null;try{rehearsal=rehearsalRow?.value?JSON.parse(rehearsalRow.value):null;}catch{}
     const backupReady=Number(backupAudit?.n??0)>0,restoreReady=!!rehearsal&&rehearsal.status==='verified'&&rehearsal.publicKeySha256===BACKUP_PUBLIC_KEY_SHA256&&rehearsal.foreignKeyViolations===0&&rehearsal.tableCount===30&&rehearsal.totalRecords>=0;
     return json({release:RELEASE,databaseReady:true,exportReady:true,rolesReady:true,otpConfigured:!!(c.anchorApiBaseUrl&&c.anchorUsername&&c.anchorPassword&&c.anchorSenderId&&c.otpHashSecret&&c.otpHashSecret.length>=32),counts,items:[{id:'portal',label:'Customer frontend entry · master7.best',status:'ready'},{id:'portal_www',label:'Customer www alias · www.master7.best',status:'pending_verification'},{id:'backoffice_domain',label:'Staff entry · master7.site',status:'ready'},{id:'backoffice',label:'Staff backoffice route · /admin',status:'ready'},{id:'android_app',label:'MASTER7 Android APK · v17.0.52',status:'ready'},{id:'ios_app',label:'MASTER7 iPhone Safari Web App entry',status:'ready'},{id:'roles',label:'Owner / staff / member roles',status:'ready'},{id:'otp',label:'Malaysia registration SMS OTP',status:!!(c.anchorApiBaseUrl&&c.anchorUsername&&c.anchorPassword&&c.anchorSenderId&&c.otpHashSecret&&c.otpHashSecret.length>=32)?'ready':'pending_verification'},{id:'languages',label:'Chinese / English / Bahasa Melayu',status:'ready'},{id:'supplier_controls',label:'Independent supplier buttons, logos and states',status:'ready'},{id:'free_paid_zones',label:'Free / paid game zone controls and display',status:'ready'},{id:'orders',label:'Wallet, deposit and withdrawal production acceptance',status:'maintenance'},{id:'reports',label:'Daily / month / half-year / yearly reports',status:'ready'},{id:'vip',label:'VIP and benefit rule management',status:'ready'},{id:'referral',label:'Referral ownership and three-level commission calculator',status:'ready'},{id:'commission_wallet',label:'Commission automatic wallet credit',status:'pending_verification'},{id:'support',label:'Customer tickets and staff replies',status:'ready'},{id:'export',label:'Portal CSV export',status:'ready'},{id:'security',label:'Role protection and audit trail',status:'ready'},{id:'encrypted_backup',label:'Encrypted independent backup',status:backupReady?'ready':'pending_verification'},{id:'restore_rehearsal',label:'Recovery rehearsal',status:restoreReady?'ready':'pending_verification'},{id:'payments',label:'VPay / GSPAY / 1MPAY production acceptance',status:'maintenance'},{id:'games',label:'Game launch and settlement acceptance',status:'maintenance'},{id:'ai_support',label:'AI customer reply provider',status:support.providerReady?'ready':'pending_verification'}]});
   }
	   if(p==='/api/admin/marketing'){
	    role(u,['owner']);const url=new URL(req.url),format=url.searchParams.get('format'),campaignId=url.searchParams.get('campaign')??'';
	    if(format==='csv'){
	     const campaign=campaignId?await db.prepare('SELECT id,name,message,benefit_text,referral_code FROM marketing_campaigns WHERE id=?').bind(campaignId).first<any>():null;if(!campaign)throw new ApiError(404,'Campaign not found');
	     const contacts=await rows(db,"SELECT phone,name FROM marketing_contacts WHERE consent_status='opted_in' ORDER BY created_at,id LIMIT 600000"),origin=new URL(req.url).origin,link=campaign.referral_code?`${origin}/register?ref=${encodeURIComponent(campaign.referral_code)}`:`${origin}/register`,message=[campaign.message,campaign.benefit_text,link].filter(Boolean).join('\n');
	     const lines=['phone,name,message,registration_link',...contacts.map((x:any)=>[x.phone,x.name,message,link].map(csvCell).join(','))];return new Response('\uFEFF'+lines.join('\n'),{headers:{...responseHeaders,'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="master7-campaign-${campaign.id}.csv"`}});
	    }
	    const [counts,campaigns,codes]=await Promise.all([
	     db.prepare("SELECT COUNT(*) total,SUM(CASE WHEN consent_status='opted_in' THEN 1 ELSE 0 END) opted_in,SUM(CASE WHEN consent_status='unknown' THEN 1 ELSE 0 END) unknown_count,SUM(CASE WHEN consent_status='opted_out' THEN 1 ELSE 0 END) opted_out FROM marketing_contacts").first<any>(),
	     rows(db,"SELECT c.id,c.name,c.channel,c.message,c.benefit_text,c.referral_code,c.retention_goal,c.send_rate_per_minute,c.scheduled_at,c.status,c.updated_at,COUNT(d.contact_id) queued_count,SUM(CASE WHEN d.status='sent' THEN 1 ELSE 0 END) sent_count,SUM(CASE WHEN d.status='delivered' THEN 1 ELSE 0 END) delivered_count,SUM(CASE WHEN d.status='failed' THEN 1 ELSE 0 END) failed_count FROM marketing_campaigns c LEFT JOIN marketing_deliveries d ON d.campaign_id=c.id GROUP BY c.id,c.name,c.channel,c.message,c.benefit_text,c.referral_code,c.retention_goal,c.send_rate_per_minute,c.scheduled_at,c.status,c.updated_at ORDER BY c.updated_at DESC LIMIT 50"),
	     rows(db,'SELECT r.code,u.username FROM referral_codes r JOIN users u ON u.id=r.user_id ORDER BY u.created_at DESC LIMIT 5000')
	    ]);
	    return json({providerReady:false,launchEnabled:false,providerStatus:'Official SMS / WhatsApp sending channel not connected',freeTools:true,maximumContacts:600000,counts:{total:Number(counts?.total??0),optedIn:Number(counts?.opted_in??0),unknown:Number(counts?.unknown_count??0),optedOut:Number(counts?.opted_out??0)},campaigns,codes});
	   }
   if(p==='/api/admin/accounting'){
    role(u,['owner']);
    const url=new URL(req.url),range=accountingPeriod(url.searchParams),[deposits,withdrawals,depositProviders,withdrawProviders]=await Promise.all([
     db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<?").bind(range.start,range.end).first<any>(),
     db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM withdrawal_requests WHERE status='paid' AND updated_at>=? AND updated_at<?").bind(range.start,range.end).first<any>(),
     rows(db,"SELECT provider,COUNT(*) orders,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE status='credited' AND updated_at>=? AND updated_at<? GROUP BY provider ORDER BY provider",range.start,range.end),
     rows(db,"SELECT provider_id provider,COUNT(*) orders,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM withdrawal_requests WHERE status='paid' AND updated_at>=? AND updated_at<? GROUP BY provider_id ORDER BY provider_id",range.start,range.end)
    ]),depositMinor=String(deposits?.amount??'0'),withdrawMinor=String(withdrawals?.amount??'0'),netMinor=(BigInt(depositMinor)-BigInt(withdrawMinor)).toString(),result={currency:'MYR',timezone:'Asia/Kuala_Lumpur',...range,deposits:{orders:Number(deposits?.orders??0),members:Number(deposits?.members??0),amountMinor:depositMinor},withdrawals:{orders:Number(withdrawals?.orders??0),members:Number(withdrawals?.members??0),amountMinor:withdrawMinor},netCashflowMinor:netMinor,depositProviders,withdrawProviders,generatedAt:now()};
    if(url.searchParams.get('format')==='csv'){const lines=['Period,Start,End,Deposit orders,Deposit members,Deposit MYR,Withdrawal orders,Withdrawal members,Withdrawal MYR,Net cashflow MYR',[range.label,range.start,range.end,result.deposits.orders,result.deposits.members,(Number(depositMinor)/100).toFixed(2),result.withdrawals.orders,result.withdrawals.members,(Number(withdrawMinor)/100).toFixed(2),(Number(netMinor)/100).toFixed(2)].join(',')];return new Response(lines.join('\n'),{headers:{...responseHeaders,'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="master7-accounts-${range.label.replace(/[^0-9A-Za-z-]/g,'-')}.csv"`}});}
    return json(result);
   }
   if(p==='/api/admin/operations'){
    const day=Math.floor((now()+28800)/86400)*86400-28800;
    const [n,d,w]=await Promise.all([
     db.prepare('SELECT COUNT(*) n FROM users WHERE created_at>=?').bind(day).first<{n:number}>(),
     db.prepare("SELECT COUNT(*) orders,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM deposit_orders WHERE status='credited' AND updated_at>=?").bind(day).first<{orders:number;members:number;amount:string}>(),
     db.prepare("SELECT COUNT(*) requests,COUNT(DISTINCT user_id) members,CAST(COALESCE(SUM(amount_minor),0) AS TEXT) amount FROM withdrawal_requests WHERE created_at>=?").bind(day).first<{requests:number;members:number;amount:string}>()
    ]);
    return json({readOnly:true,metrics:{newMembersPreview:n?.n??0,depositMembersToday:d?.members??0,depositOrdersToday:d?.orders??0,depositMYR:Number(d?.amount??0)/100,withdrawMembersToday:w?.members??0,withdrawRequestsToday:w?.requests??0,withdrawMYR:Number(w?.amount??0)/100,bonusMYR:null,netRevenueMYR:null,groupJoins:null}});
   }
   role(u,['owner']);
   if(p==='/api/admin/withdrawals')return listAdminWithdrawals({db,user:u,dataKey:c.withdrawalDataKey});
   if(p==='/api/admin/users')return json({items:await rows(db,'SELECT id,username,role,approved,created_at FROM users ORDER BY created_at DESC LIMIT 500')});
   if(p==='/api/admin/payment-diagnostics')return json({items:(await rows(db,"SELECT target,created_at FROM audit WHERE event='payment_order_diagnostic' ORDER BY created_at DESC,id DESC LIMIT 100")).map((x:any)=>{try{return {...JSON.parse(x.target),createdAt:x.created_at};}catch{return {kind:'UNAVAILABLE',createdAt:x.created_at};}})});
   if(p==='/api/admin/audit')return json({items:await rows(db,'SELECT a.event,a.target,a.created_at,u.username FROM audit a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC,a.id DESC LIMIT 100')});
   if(p==='/api/admin/security'){const n=await db.prepare("SELECT COUNT(*) n FROM audit WHERE event='write_rate_limited' AND created_at>=?").bind(Math.floor((now()+28800)/86400)*86400-28800).first<{n:number}>();return json({today:{login_denied:null,login_rate_limited:null,registration_rate_limited:null,write_rate_limited:n?.n??0}});}
   if(p==='/api/admin/export'){const data:Record<string,unknown>={release:RELEASE,exportedAt:new Date().toISOString(),scope:'new-portal-only'};for(const table of ['users','tickets','replies','announcements','providers','brand_directory_entries','api_supplier_artwork','portal_status_snapshots','lobby_ads','custom_game_cards','benefit_rules','game_visibility','payment_channel_controls','withdrawal_requests','company_bank_accounts','manual_deposit_requests','game_wallet_sessions','game_wallet_ledger','settings','audit']){const list=await rows(db,`SELECT ${table==='users'?'id,username,role,approved,created_at':table==='api_supplier_artwork'?'provider_id,updated_by,updated_at':table==='lobby_ads'?'id,title,target_url,enabled,position,created_by,created_at,updated_at':table==='custom_game_cards'?'id,title,provider_name,game_code,category,is_platform_mini,enabled,status,position,created_by,created_at,updated_at':table==='game_visibility'?'provider_id,game_code,visible,status,category_override,access_zone,updated_by,updated_at':table==='withdrawal_requests'?'id,user_id,provider_id,provider_name,bank_code,bank_name,account_last4,amount_minor,currency,status,owner_note,updated_by,created_at,updated_at':table==='manual_deposit_requests'?'deposit_order_id,bank_account_id,reviewed_by,created_at,updated_at':table==='game_wallet_sessions'?'id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,expected_return_minor,deposit_reference,withdraw_reference,provider_residual,last_error,created_at,updated_at,settled_at':'*'} FROM ${table}${table==='settings'?" WHERE id NOT LIKE 'owner_password_%'":''} LIMIT 10001`);if(list.length>10000)throw new ApiError(413,'导出超过单次上限，请联系站点维护人员');data[table]=list;}return new Response(JSON.stringify(data,null,2),{headers:{...responseHeaders,'Content-Disposition':'attachment; filename="master7-portal-export.json"'}});}
  }
  throw new ApiError(404,'Not found');
 }
 // Cookies alone never authorize writes. Require exact Origin and a per-user token.
 if(!requestOriginAllowed(req,c.allowedOrigins))throw new ApiError(403,'Origin denied');
 role(u);if(!u.approved)throw new ApiError(403,'账号待老板审批 / Account awaiting approval');
 if(req.headers.get('x-csrf-token')!==u.csrf)throw new ApiError(403,'CSRF denied');
 const d=await body(req,p==='/api/admin/ads'||p==='/api/admin/custom-games'||p==='/api/admin/game-visibility'||p==='/api/admin/provider'||p==='/api/admin/brand-directory'||p==='/api/admin/supplier-art'||p==='/api/admin/marketing'?550000:24000);await limited(db,u,p==='/api/admin/marketing'?180:30);
 if(p==='/api/payments/vpay/orders')return createVPayOrder(d,vpayContext);
 if(p==='/api/payments/1mpay/orders')return createOneMpayOrder(d,oneMpayContext);
 if(p==='/api/payments/1mpay/orders/query')return refreshOneMpayOrder(d,oneMpayContext);
 if(p==='/api/payments/gspay/orders')return createGSPayOrder(d,gspayContext);
 if(p==='/api/payments/gspay/orders/query')return refreshGSPayOrder(d,gspayContext);
 if(p==='/api/game-launch'){role(u,['member']);return launchMegaH5(req,c,u,d);}
 if(p==='/api/game-wallet/settle'){role(u,['member']);return json(await settleMegaWallet(megaWalletSettings(c,u)));}
 if(p==='/api/game-wallet/recover'){role(u,['member']);return json(await recoverMegaWallet(megaWalletSettings(c,u)));}
 const manual=await manualBankPost(p,d,{db,user:u});if(manual)return manual;
 if(p==='/api/withdrawals')return submitWithdrawal(d,{db,user:u,dataKey:c.withdrawalDataKey});
 if(p==='/api/tickets'){const subject=textField(d.subject,3,120),message=textField(d.message,5,2000),id=uuid();await db.batch([db.prepare('INSERT INTO tickets(id,user_id,subject,message,created_at) VALUES(?,?,?,?,?)').bind(id,u.id,subject,message,now()),auditStmt(db,u,'ticket_created',id)]);return json({status:'ok',id},201);}
 if(p==='/api/tickets/reply'){const id=idField(d.ticketId),message=textField(d.message,1,2000),ticket=await db.prepare('SELECT user_id,status FROM tickets WHERE id=?').bind(id).first<{user_id:string;status:string}>();if(!ticket||u.role==='member'&&ticket.user_id!==u.id)throw new ApiError(404,'Ticket not found');if(ticket.status!=='open')throw new ApiError(409,'工单已关闭 / Ticket closed');await db.batch([db.prepare('INSERT INTO replies(id,ticket_id,user_id,message,created_at) VALUES(?,?,?,?,?)').bind(uuid(),id,u.id,message,now()),auditStmt(db,u,'ticket_replied',id)]);return json({status:'ok'});}
 if(p.startsWith('/api/admin/')){
  role(u,['owner','staff']);
	   if(p==='/api/admin/backup'){
	    role(u,['owner']);
	    if(d.action==='record_rehearsal'){
	     const digest=(value:unknown,name:string)=>{if(typeof value!=='string'||!/^[a-f0-9]{64}$/.test(value))throw new ApiError(400,`Invalid ${name}`);return value;},tableCount=Number(d.tableCount),totalRecords=Number(d.totalRecords),foreignKeyViolations=Number(d.foreignKeyViolations),verifiedAt=typeof d.verifiedAt==='string'?d.verifiedAt:'';
	     if(d.status!=='verified'||d.format!=='MASTER7-ENCRYPTED-BACKUP-1'||d.publicKeySha256!==BACKUP_PUBLIC_KEY_SHA256||tableCount!==30||!Number.isSafeInteger(totalRecords)||totalRecords<0||foreignKeyViolations!==0||!verifiedAt||!Number.isFinite(Date.parse(verifiedAt)))throw new ApiError(400,'Invalid recovery rehearsal receipt');
	     const receipt={status:'verified',format:d.format,release:typeof d.release==='string'?d.release.slice(0,100):'',backupSha256:digest(d.backupSha256,'backup hash'),plaintextSha256:digest(d.plaintextSha256,'plaintext hash'),publicKeySha256:BACKUP_PUBLIC_KEY_SHA256,tableCount,totalRecords,foreignKeyViolations:0,verifiedAt,recordedAt:new Date().toISOString()},value=JSON.stringify(receipt);
	     await db.batch([db.prepare("INSERT INTO settings(id,value) VALUES('backup_restore_rehearsal',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(value),auditStmt(db,u,'backup_restore_rehearsal',JSON.stringify({verifiedAt,tableCount,totalRecords,publicKeySha256:BACKUP_PUBLIC_KEY_SHA256}))]);return json({status:'ok',verified:true});
	    }
	    if(d.action!=='create')throw new ApiError(400,'Invalid backup action');const {envelope,metadata}=await createEncryptedPortalBackup(db,RELEASE);await auditStmt(db,u,'encrypted_backup_created',JSON.stringify(metadata)).run();return new Response(JSON.stringify(envelope),{headers:{...responseHeaders,'Content-Disposition':`attachment; filename="master7-encrypted-backup-${metadata.createdAt.replace(/[:.]/g,'-')}.json"`}});
	   }
	   if(p==='/api/admin/marketing'){
	    role(u,['owner']);const action=textField(d.action,3,20);
	    if(action==='import'){
	     if(!Array.isArray(d.contacts)||d.contacts.length<1||d.contacts.length>1000)throw new ApiError(400,'Import 1 to 1,000 contacts per batch');const source=typeof d.source==='string'?d.source.trim().slice(0,80)||'csv':'csv',stamp=now(),unique=new Map<string,{phone:string;name:string;consent:string}>();let invalid=0;
	     for(const raw of d.contacts){const phone=malaysiaMarketingPhone(raw?.phone??raw);if(!phone){invalid++;continue;}const name=typeof raw?.name==='string'?raw.name.trim().slice(0,100):'',consent=raw?.consent===true||raw?.consent==='opted_in'?'opted_in':raw?.consent==='opted_out'?'opted_out':'unknown';unique.set(phone,{phone,name,consent});}
	     const before=await db.prepare('SELECT COUNT(*) count FROM marketing_contacts').first<{count:number}>(),statements=[...unique.values()].map(item=>db.prepare("INSERT INTO marketing_contacts(id,phone,name,consent_status,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(phone) DO UPDATE SET name=CASE WHEN excluded.name<>'' THEN excluded.name ELSE marketing_contacts.name END,consent_status=CASE WHEN marketing_contacts.consent_status='opted_out' THEN 'opted_out' ELSE excluded.consent_status END,source=excluded.source,updated_at=excluded.updated_at").bind(uuid(),item.phone,item.name,item.consent,source,stamp,stamp));if(statements.length)await db.batch(statements);const after=await db.prepare('SELECT COUNT(*) count FROM marketing_contacts').first<{count:number}>(),imported=Math.max(0,Number(after?.count??0)-Number(before?.count??0));await auditStmt(db,u,'marketing_contacts_imported',`${imported}/${unique.size}`).run();return json({status:'ok',received:d.contacts.length,valid:unique.size,invalid,imported,duplicates:unique.size-imported,total:Number(after?.count??0)});
	    }
	    if(action==='save'){
	     const id=typeof d.id==='string'&&d.id?idField(d.id):uuid(),name=textField(d.name,2,100),channel=['whatsapp','sms','share'].includes(d.channel)?d.channel:'share',message=textField(d.message,3,2000),benefitText=typeof d.benefitText==='string'?d.benefitText.trim().slice(0,1000):'',retentionGoal=optionalInteger(d.retentionGoal,1,600000,'retention goal')??18000,sendRate=optionalInteger(d.sendRatePerMinute,1,10000,'send rate')??30,scheduledAt=d.scheduledAt?Math.floor(new Date(String(d.scheduledAt)).getTime()/1000):null,referralCode=typeof d.referralCode==='string'&&d.referralCode?textField(d.referralCode,8,12).toUpperCase():null;
	     if(scheduledAt!==null&&!Number.isFinite(scheduledAt))throw new ApiError(400,'Invalid schedule time');
	     if(referralCode&&!await db.prepare('SELECT code FROM referral_codes WHERE code=?').bind(referralCode).first())throw new ApiError(400,'Referral code not found');let imageData=typeof d.imageData==='string'?d.imageData:'';if(imageData&&(imageData.length>500000||!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(imageData)||!validImageData(imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');const existing=await db.prepare('SELECT image_data FROM marketing_campaigns WHERE id=?').bind(id).first<{image_data:string}>();if(!imageData&&existing)imageData=existing.image_data;const status=channel==='share'?'ready':'blocked',stamp=now();
	     if(existing)await db.batch([db.prepare('UPDATE marketing_campaigns SET name=?,channel=?,message=?,image_data=?,benefit_text=?,referral_code=?,retention_goal=?,send_rate_per_minute=?,scheduled_at=?,status=?,updated_at=? WHERE id=?').bind(name,channel,message,imageData,benefitText,referralCode,retentionGoal,sendRate,scheduledAt,status,stamp,id),auditStmt(db,u,'marketing_campaign_updated',id)]);else await db.batch([db.prepare('INSERT INTO marketing_campaigns(id,name,channel,message,image_data,benefit_text,referral_code,retention_goal,send_rate_per_minute,scheduled_at,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,name,channel,message,imageData,benefitText,referralCode,retentionGoal,sendRate,scheduledAt,status,u.id,stamp,stamp),auditStmt(db,u,'marketing_campaign_created',id)]);return json({status:'ok',id,campaignStatus:status,providerReady:false},existing?200:201);
	    }
	    if(action==='launch')throw new ApiError(409,'Official SMS / WhatsApp sending channel is not connected. Export the prepared campaign or connect a provider first.');
	    if(action==='opt_out'){const phone=malaysiaMarketingPhone(d.phone);if(!phone)throw new ApiError(400,'Invalid Malaysian phone');await db.prepare("UPDATE marketing_contacts SET consent_status='opted_out',updated_at=? WHERE phone=?").bind(now(),phone).run();await auditStmt(db,u,'marketing_contact_opted_out',phone.slice(-4)).run();return json({status:'ok'});}
	    throw new ApiError(400,'Invalid marketing action');
	   }
  if(p==='/api/admin/game-sync'){const catalogue=await getGameCatalogue(c,{force:true});await auditStmt(db,u,'game_catalogue_sync','catalogue').run();return json({providers:catalogue.providers,gameCount:catalogue.games.length,syncIntervalSeconds:300,playable:false});}
  if(p==='/api/admin/withdrawals/status')return json({error:'Read-only withdrawal records; provider callbacks update status'},405);
  if(p==='/api/admin/supplier-art'){
   role(u,['owner']);const providerId=textField(d.providerId,1,32);if(!apiSupplierIds.includes(providerId))throw new ApiError(400,'Invalid supplier');
   const hasImage=typeof d.imageData==='string'&&d.imageData.length>0,status=typeof d.status==='string'?d.status:null;if(!hasImage&&!status)throw new ApiError(400,'Image or status required');if(status&&!['active','suspended','closed'].includes(status))throw new ApiError(400,'Invalid supplier status');
   if(hasImage&&(d.imageData.length>500000||!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');
   const current=await db.prepare('SELECT status FROM api_supplier_artwork WHERE provider_id=?').bind(providerId).first<{status:string}>(),nextStatus=status??current?.status??'active',timestamp=now(),imageData=hasImage?d.imageData:'';await db.batch([db.prepare("INSERT INTO api_supplier_artwork(provider_id,image_data,status,updated_by,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(provider_id) DO UPDATE SET image_data=CASE WHEN excluded.image_data='' THEN api_supplier_artwork.image_data ELSE excluded.image_data END,status=excluded.status,updated_by=excluded.updated_by,updated_at=excluded.updated_at").bind(providerId,imageData,nextStatus,u.id,timestamp),auditStmt(db,u,status?'api_supplier_status_updated':'api_supplier_artwork_updated',providerId)]);return json({status:'ok',providerId,supplierStatus:nextStatus,updatedAt:timestamp});
  }
  if(p==='/api/admin/ads'){
   const action=textField(d.action,3,10);
   if(action==='delete'){
    const id=idField(d.id);if(!await db.prepare('SELECT id FROM lobby_ads WHERE id=?').bind(id).first())throw new ApiError(404,'Ad not found');
    await db.batch([db.prepare('DELETE FROM lobby_ads WHERE id=?').bind(id),auditStmt(db,u,'lobby_ad_deleted',id)]);return json({status:'ok'});
   }
   if(action==='toggle'){
    const id=idField(d.id);if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid enabled state');if(!await db.prepare('SELECT id FROM lobby_ads WHERE id=?').bind(id).first())throw new ApiError(404,'Ad not found');
    await db.batch([db.prepare('UPDATE lobby_ads SET enabled=?,updated_at=? WHERE id=?').bind(d.enabled?1:0,now(),id),auditStmt(db,u,d.enabled?'lobby_ad_enabled':'lobby_ad_disabled',id)]);return json({status:'ok'});
   }
   if(action==='save'){
    const id=typeof d.id==='string'&&d.id? idField(d.id):uuid(),title=textField(d.title,2,100),target=advertisementUrl(d.targetUrl),enabled=typeof d.enabled==='boolean'?d.enabled:true,position=Number.isInteger(d.position)&&d.position>=0&&d.position<1000?d.position:0;
    let imageData=typeof d.imageData==='string'?d.imageData:'';
    if(imageData){if(imageData.length>500000||!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(imageData)||!validImageData(imageData))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');}
    const existing=await db.prepare('SELECT id,image_data FROM lobby_ads WHERE id=?').bind(id).first<{id:string;image_data:string}>();
    if(!imageData&&existing)imageData=existing.image_data;
    if(!imageData)throw new ApiError(400,'Ad image is required');
    if(existing){await db.batch([db.prepare('UPDATE lobby_ads SET title=?,image_data=?,target_url=?,enabled=?,position=?,updated_at=? WHERE id=?').bind(title,imageData,target,enabled?1:0,position,now(),id),auditStmt(db,u,'lobby_ad_updated',id)]);}
    else{const count=await db.prepare('SELECT COUNT(*) AS count FROM lobby_ads').first<{count:number}>();if(Number(count?.count??0)>=20)throw new ApiError(409,'The lobby supports up to 20 ads');await db.batch([db.prepare('INSERT INTO lobby_ads(id,title,image_data,target_url,enabled,position,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(id,title,imageData,target,enabled?1:0,position,u.id,now(),now()),auditStmt(db,u,'lobby_ad_created',id)]);}
    return json({status:'ok',id},existing?200:201);
   }
   throw new ApiError(400,'Invalid ad action');
  }
  if(p==='/api/admin/custom-games'){
   role(u,['owner']);
   const action=textField(d.action,3,10);
   if(action==='delete'||action==='toggle'||action==='status'){
    const id=idField(d.id);if(!await db.prepare('SELECT id FROM custom_game_cards WHERE id=?').bind(id).first())throw new ApiError(404,'Game card not found');
    if(action==='delete'){await db.batch([db.prepare('DELETE FROM custom_game_cards WHERE id=?').bind(id),auditStmt(db,u,'custom_game_deleted',id)]);return json({status:'ok'});}
    if(action==='status'){if(!['suspended','active','closed'].includes(d.status))throw new ApiError(400,'Invalid game status');await db.batch([db.prepare('UPDATE custom_game_cards SET status=?,enabled=?,updated_at=? WHERE id=?').bind(d.status,d.status==='closed'?0:1,now(),id),auditStmt(db,u,'custom_game_'+d.status,id)]);return json({status:'ok',gameStatus:d.status,playable:false});}
    if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid enabled state');await db.batch([db.prepare('UPDATE custom_game_cards SET enabled=?,updated_at=? WHERE id=?').bind(d.enabled?1:0,now(),id),auditStmt(db,u,d.enabled?'custom_game_enabled':'custom_game_disabled',id)]);return json({status:'ok'});
   }
   if(action==='save'){
    const id=typeof d.id==='string'&&d.id?idField(d.id):uuid(),title=textField(d.title,2,100),isPlatformMini=d.isPlatformMini===true,providerName=isPlatformMini?'MASTER7 Mini Games':textField(d.providerName,2,80),gameCode=typeof d.gameCode==='string'?d.gameCode.trim().slice(0,100):'',category=typeof d.category==='string'?d.category.trim().slice(0,40):'',enabled=typeof d.enabled==='boolean'?d.enabled:false,position=optionalInteger(d.position,0,999,'position')??0;
    let imageData=typeof d.imageData==='string'?d.imageData:'';if(imageData&&(imageData.length>500000||!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(imageData)||!validImageData(imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');
    const existing=await db.prepare('SELECT id,image_data,is_platform_mini FROM custom_game_cards WHERE id=?').bind(id).first<{id:string;image_data:string;is_platform_mini:number}>();if(!imageData&&existing)imageData=existing.image_data;if(!imageData)throw new ApiError(400,'Game image is required');
    if(isPlatformMini&&(!existing||!Number(existing.is_platform_mini))){const count=await db.prepare('SELECT COUNT(*) AS count FROM custom_game_cards WHERE is_platform_mini=1').first<{count:number}>();if(Number(count?.count??0)>=5)throw new ApiError(409,'Only five MASTER7 platform mini-game cards are allowed');}
    if(existing){await db.batch([db.prepare('UPDATE custom_game_cards SET title=?,provider_name=?,game_code=?,category=?,image_data=?,is_platform_mini=?,enabled=?,position=?,updated_at=? WHERE id=?').bind(title,providerName,gameCode,category,imageData,isPlatformMini?1:0,enabled?1:0,position,now(),id),auditStmt(db,u,'custom_game_updated',id)]);}
    else{const count=await db.prepare('SELECT COUNT(*) AS count FROM custom_game_cards').first<{count:number}>();if(Number(count?.count??0)>=100)throw new ApiError(409,'The lobby supports up to 100 custom game cards');await db.batch([db.prepare('INSERT INTO custom_game_cards(id,title,provider_name,game_code,category,image_data,is_platform_mini,enabled,status,position,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,title,providerName,gameCode,category,imageData,isPlatformMini?1:0,0,'closed',position,u.id,now(),now()),auditStmt(db,u,'custom_game_created',id)]);}
    return json({status:'ok',id},existing?200:201);
   }
   throw new ApiError(400,'Invalid game-card action');
  }
  if(p==='/api/admin/benefits'){
   role(u,['owner']);
   const action=textField(d.action,3,10);
   if(action==='delete'){
    const id=idField(d.id);if(!await db.prepare('SELECT id FROM benefit_rules WHERE id=?').bind(id).first())throw new ApiError(404,'Benefit not found');
    await db.batch([db.prepare('DELETE FROM benefit_rules WHERE id=?').bind(id),auditStmt(db,u,'benefit_rule_deleted',id)]);return json({status:'ok'});
   }
   if(action==='toggle'){
    const id=idField(d.id),status=d.status;if(!['draft','active'].includes(status))throw new ApiError(400,'Invalid benefit status');if(!await db.prepare('SELECT id FROM benefit_rules WHERE id=?').bind(id).first())throw new ApiError(404,'Benefit not found');
    await db.batch([db.prepare('UPDATE benefit_rules SET status=?,updated_at=? WHERE id=?').bind(status,now(),id),auditStmt(db,u,status==='active'?'benefit_rule_published':'benefit_rule_unpublished',id)]);return json({status:'ok'});
   }
   if(action==='save'){
    const id=typeof d.id==='string'&&d.id?idField(d.id):uuid(),title=textField(d.title,2,100),description=textField(d.description,3,2000),rewardType=textField(d.rewardType,3,32);
    if(!['deposit_bonus','cashback','free_credit','vip','referral','turnover','other'].includes(rewardType))throw new ApiError(400,'Invalid benefit type');
    const turnoverBase=d.turnoverBase??'deposit_plus_bonus';if(!['deposit','bonus','deposit_plus_bonus'].includes(turnoverBase))throw new ApiError(400,'Invalid turnover base');
    const providerId=d.providerId??'all';if(!['all','jili','megah5','918kissh5'].includes(providerId))throw new ApiError(400,'Invalid sponsored provider');
    const rules={currency:'MYR',providerId,rewardType,rewardAmountMYR:optionalNumber(d.rewardAmountMYR,0,1000000,'reward amount'),rewardPercent:optionalNumber(d.rewardPercent,0,1000,'reward percent'),minDepositMYR:optionalNumber(d.minDepositMYR,0,1000000,'minimum deposit'),maxRewardMYR:optionalNumber(d.maxRewardMYR,0,1000000,'maximum reward'),turnoverMultiplier:optionalNumber(d.turnoverMultiplier,0,1000,'turnover multiplier'),turnoverBase,turnoverRequiredMYR:optionalNumber(d.turnoverRequiredMYR,0,100000000,'turnover amount'),withdrawalCapMYR:optionalNumber(d.withdrawalCapMYR,0,1000000,'withdrawal cap'),claimLimitPerMember:optionalInteger(d.claimLimitPerMember,1,100000,'claim limit'),validityDays:optionalInteger(d.validityDays,1,3650,'validity')};
    if(!rules.rewardAmountMYR&&!rules.rewardPercent&&d.status==='active')throw new ApiError(400,'Set a reward amount or percentage before publishing');
    const status=d.status==='active'?'active':'draft',existing=await db.prepare('SELECT id FROM benefit_rules WHERE id=?').bind(id).first();
    if(existing)await db.batch([db.prepare('UPDATE benefit_rules SET title=?,description=?,rules_json=?,status=?,updated_at=? WHERE id=?').bind(title,description,JSON.stringify(rules),status,now(),id),auditStmt(db,u,'benefit_rule_updated',id)]);
    else await db.batch([db.prepare('INSERT INTO benefit_rules(id,title,description,rules_json,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').bind(id,title,description,JSON.stringify(rules),status,u.id,now(),now()),auditStmt(db,u,'benefit_rule_created',id)]);
    return json({status:'ok',id,ruleStatus:status},existing?200:201);
   }
   throw new ApiError(400,'Invalid benefit action');
  }
  if(p==='/api/admin/referrals'){
   role(u,['owner']);
   if(d.action==='run'){
    const config=await referralSettings(db),preview=await commissionPreview(db,config);await auditStmt(db,u,'commission_period_previewed',`${preview.period.start}:${preview.period.end}:${preview.totalCommissionMinor}`).run();return json({status:'ok',preview,walletCredited:false,message:preview.basisReady?'Period calculated. Wallet credit remains pending acceptance.':'Selected basis data is not connected.'});
   }
   let value:any;
   if(d.settings!==undefined)value=commissionInput(d.settings);
   else{if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid referral state');const ratePercent=Number(d.ratePercent);if(!Number.isFinite(ratePercent)||ratePercent<0||ratePercent>100)throw new ApiError(400,'Referral commission must be between 0% and 100%');value=normalizedCommissionSettings({enabled:d.enabled,rateBasisPoints:Math.round(ratePercent*100)});}
   const rateBasisPoints=Math.round(value.tierRatesPercent[0]*100);await db.batch([db.prepare("INSERT INTO settings(id,value) VALUES('referral_program',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(JSON.stringify(value)),auditStmt(db,u,'referral_program_updated',`${value.enabled?'active':'closed'}:${value.basis}:${rateBasisPoints}`)]);return json({status:'ok',settings:{...value,rateBasisPoints},...value,rateBasisPoints,ratePercent:rateBasisPoints/100});
  }
  if(p==='/api/admin/support-settings'){
   role(u,['owner']);if(typeof d.aiEnabled!=='boolean'||typeof d.humanHandoff!=='boolean')throw new ApiError(400,'Invalid support automation settings');const value={aiEnabled:d.aiEnabled,humanHandoff:d.humanHandoff};await db.batch([db.prepare("INSERT INTO settings(id,value) VALUES('support_automation',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(JSON.stringify(value)),auditStmt(db,u,'support_automation_updated',`${value.aiEnabled?'requested':'off'}:${value.humanHandoff?'handoff':'no-handoff'}`)]);return json({status:'ok',...value,providerReady:false,effectiveAiReply:false,status:'awaiting_provider_verification'});
  }
  if(p==='/api/admin/announcement'){const title=textField(d.title,3,100),content=textField(d.body,5,1000),id=uuid();await db.batch([db.prepare('INSERT INTO announcements(id,title,body,created_by,created_at) VALUES(?,?,?,?,?)').bind(id,title,content,u.id,now()),auditStmt(db,u,'announcement_created',id)]);return json({status:'ok'},201);}
  if(p==='/api/admin/payment-channels'){
   role(u,['owner']);
   const providerId=textField(d.providerId,1,32),status=d.status;
   if(!['vpay','gspay','1mpay','gspay_plus'].includes(providerId)||!['suspended','active','closed'].includes(status))throw new ApiError(400,'Invalid payment channel status');
   const channel=await db.prepare('SELECT provider_name FROM payment_channel_controls WHERE provider_id=?').bind(providerId).first<{provider_name:string}>();if(!channel)throw new ApiError(404,'Payment channel not found');
   await db.batch([db.prepare('UPDATE payment_channel_controls SET status=?,updated_by=?,updated_at=? WHERE provider_id=?').bind(status,u.id,now(),providerId),auditStmt(db,u,'payment_channel_'+status,providerId)]);return json({status:'ok',providerId,channelStatus:status,...paymentFlags(c,await rows(db,'SELECT provider_id,status FROM payment_channel_controls'))});
  }
  if(p==='/api/admin/ticket-status'){const id=idField(d.ticketId);if(!['open','closed'].includes(d.status))throw new ApiError(400,'Invalid status');if(!await db.prepare('SELECT id FROM tickets WHERE id=?').bind(id).first())throw new ApiError(404,'Ticket not found');await db.batch([db.prepare('UPDATE tickets SET status=? WHERE id=?').bind(d.status,id),auditStmt(db,u,'ticket_'+d.status,id)]);return json({status:'ok'});}
  if(p==='/api/admin/game-visibility'){
   role(u,['owner']);
   const providerId=textField(d.providerId,1,32),gameCode=textField(d.gameCode,1,100);if(!gameSources.some(s=>s.id===providerId))throw new ApiError(400,'Invalid game provider');
   const status=d.status;if(status!==undefined&&!['suspended','active','closed'].includes(status))throw new ApiError(400,'Invalid game status');
   const categoryOverride=d.category===undefined?undefined:d.category;if(categoryOverride!==undefined&&categoryOverride!==''&&!vendorCategories.includes(categoryOverride as VendorCategory))throw new ApiError(400,'Invalid game category');
   const accessZone=d.accessZone===undefined?undefined:d.accessZone;if(accessZone!==undefined&&!['free','paid'].includes(accessZone))throw new ApiError(400,'Invalid game access zone');
   if(status===undefined&&d.imageData===undefined&&categoryOverride===undefined&&accessZone===undefined)throw new ApiError(400,'A status, category, access zone or game image is required');
   let imageData:string|undefined;if(d.imageData!==undefined){if(typeof d.imageData!=='string'||d.imageData.length>500000||d.imageData!==''&&(!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');imageData=d.imageData;}
   const key=`${providerId}:${gameCode}`,existing=await db.prepare('SELECT status,image_data,category_override,access_zone FROM game_visibility WHERE provider_id=? AND game_code=?').bind(providerId,gameCode).first<{status:string;image_data:string;category_override:string;access_zone:string}>(),nextStatus=status??existing?.status??'closed',nextImage=imageData??existing?.image_data??'',nextCategory=categoryOverride===undefined?existing?.category_override??'':categoryOverride,nextZone=accessZone??existing?.access_zone??'paid';
   const event=accessZone!==undefined&&status===undefined&&categoryOverride===undefined&&imageData===undefined?'game_access_zone_updated':imageData!==undefined&&status===undefined&&categoryOverride===undefined&&accessZone===undefined?'game_artwork_updated':`game_${nextStatus}`;
   await db.batch([db.prepare('INSERT INTO game_visibility(provider_id,game_code,visible,status,image_data,category_override,access_zone,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(provider_id,game_code) DO UPDATE SET visible=excluded.visible,status=excluded.status,image_data=excluded.image_data,category_override=excluded.category_override,access_zone=excluded.access_zone,updated_by=excluded.updated_by,updated_at=excluded.updated_at').bind(providerId,gameCode,nextStatus==='closed'?0:1,nextStatus,nextImage,nextCategory,nextZone,u.id,now()),auditStmt(db,u,event,`${key}:${nextZone}`)]);
   return json({status:'ok',gameStatus:nextStatus,accessZone:nextZone,artworkSaved:imageData!==undefined,playable:false});
  }
  if(p==='/api/admin/provider'){
   role(u,['owner']);
   const id=idField(d.id);if(typeof d.visible!=='boolean'&&d.imageData===undefined)throw new ApiError(400,'A visibility state or provider image is required');
   const existing=await db.prepare('SELECT visible,image_data FROM providers WHERE id=?').bind(id).first<{visible:number;image_data:string}>();if(!existing)throw new ApiError(404,'Provider not found');
   let imageData=existing.image_data;if(d.imageData!==undefined){if(typeof d.imageData!=='string'||d.imageData.length>500000||d.imageData!==''&&(!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');imageData=d.imageData;}
   const visible=d.visible===undefined?Number(existing.visible):d.visible?1:0;
   await db.batch([db.prepare('UPDATE providers SET visible=?,image_data=? WHERE id=?').bind(visible,imageData,id),auditStmt(db,u,d.imageData!==undefined?'provider_artwork_updated':'provider_visibility',id)]);return json({status:'ok',providerId:id,artworkSaved:d.imageData!==undefined});
  }
  if(p==='/api/admin/brand-directory'){
   role(u,['owner']);
   const id=idField(d.id),status=d.status;if(status!==undefined&&!['suspended','active','closed'].includes(status))throw new ApiError(400,'Invalid brand status');
   if(status===undefined&&d.imageData===undefined)throw new ApiError(400,'A status or brand image is required');
   const existing=await db.prepare('SELECT status,image_data FROM brand_directory_entries WHERE id=?').bind(id).first<{status:string;image_data:string}>();if(!existing)throw new ApiError(404,'Brand directory entry not found');
   let imageData:string|undefined;if(d.imageData!==undefined){if(typeof d.imageData!=='string'||d.imageData.length>500000||d.imageData!==''&&(!/^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(d.imageData)||!validImageData(d.imageData)))throw new ApiError(400,'Upload a valid JPG, PNG or WebP image under 350 KB');imageData=d.imageData;}
   const nextStatus=status??existing.status,nextImage=imageData??existing.image_data;
   await db.batch([db.prepare('UPDATE brand_directory_entries SET status=?,image_data=?,updated_by=?,updated_at=? WHERE id=?').bind(nextStatus,nextImage,u.id,now(),id),auditStmt(db,u,imageData!==undefined&&status===undefined?'brand_artwork_updated':`brand_${nextStatus}`,id)]);
   return json({status:'ok',brandStatus:nextStatus,artworkSaved:imageData!==undefined,integrationState:'not_configured'});
  }
  role(u,['owner']);
  if(p==='/api/admin/approve'||p==='/api/admin/role'){const id=idField(d.userId),target=await db.prepare('SELECT role FROM users WHERE id=?').bind(id).first<{role:string}>();if(!target)throw new ApiError(404,'User not found');if(target.role==='owner')throw new ApiError(403,'Owner protected');if(p.endsWith('/role')){if(!['member','staff'].includes(d.role))throw new ApiError(400,'Invalid role');await db.batch([db.prepare('UPDATE users SET role=?,approved=1 WHERE id=?').bind(d.role,id),auditStmt(db,u,'role_'+d.role,id)]);}else await db.batch([db.prepare('UPDATE users SET approved=1 WHERE id=?').bind(id),auditStmt(db,u,'user_approved',id)]);return json({status:'ok'});}
  if(p==='/api/admin/social-links'){if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid state');const value={enabled:d.enabled,facebookUrl:urlField(d.facebookUrl,'facebook'),instagramUrl:urlField(d.instagramUrl,'instagram')};if(value.enabled&&!value.facebookUrl&&!value.instagramUrl)throw new ApiError(400,'至少填写一个主页');await db.batch([db.prepare("INSERT INTO settings(id,value) VALUES('social',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(JSON.stringify(value)),auditStmt(db,u,'social_links_updated','social')]);return json({status:'ok'});}
 }
 throw new ApiError(404,'Not found');
}
