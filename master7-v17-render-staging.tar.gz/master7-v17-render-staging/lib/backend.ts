import { readLocalSession, handlePasswordAuth, AuthError } from './password-auth.ts';
import { requestOriginAllowed } from './request-origin.ts';
export const RELEASE = '17.0.0-selfbuilt.8';
export const SOURCE_RELEASE = '17.0.0-preview.6-qa3-integrated-r3';
type Identity={userId:string;email:string};
type User={id:string;username:string;role:string;approved:number;csrf:string;created_at:number};
export type Context={db:D1Database;identity:Identity|null;ownerEmail:string;ownerLoginId?:string;allowedOrigins?:string[];gameGatewayUrl?:string;gameGatewayFetch?:typeof fetch;ownerSetupHash?:string;ownerSetupExpires?:number;ownerResetHash?:string;ownerResetExpires?:number;ownerResetIssuedAt?:number};
class ApiError extends Error{ status:number; constructor(status:number,message:string){super(message);this.status=status;} }
const now=()=>Math.floor(Date.now()/1000);
const uuid=()=>crypto.randomUUID();
export const responseHeaders={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Cookie, oai-authenticated-user-id'};
function json(value:unknown,status=200){return new Response(JSON.stringify(value),{status,headers:responseHeaders});}
function textField(v:unknown,min:number,max:number){if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)throw new ApiError(400,'输入长度不符合要求 / Invalid input');return v.trim();}
function idField(v:unknown){return textField(v,1,128);}
function urlField(v:unknown,service:string){if(v==='')return '';const s=textField(v,1,300);let u:URL;try{u=new URL(s);}catch{throw new ApiError(400,'Invalid URL');}if(u.protocol!=='https:'||u.username||u.password||u.port||!['www.'+service+'.com',service+'.com'].includes(u.hostname))throw new ApiError(400,'请使用官方 HTTPS 主页地址');return u.href;}
function role(u:User|null,roles=['owner','staff','member']):asserts u is User{if(!u)throw new ApiError(401,'请先登录 / Sign in required');if(!roles.includes(u.role))throw new ApiError(403,'没有访问权限 / Access denied');}
async function currentUser(c:Context,create=false){if(!c.identity)return null;const {userId,email}=c.identity;let u=await c.db.prepare('SELECT * FROM users WHERE id=?').bind(userId).first<User>();if(!u&&create){const owner=!!c.ownerEmail&&email.toLowerCase()===c.ownerEmail.toLowerCase();await c.db.prepare('INSERT OR IGNORE INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,?)').bind(userId,email,owner?'owner':'member',owner?1:0,uuid()+uuid(),now()).run();u=await c.db.prepare('SELECT * FROM users WHERE id=?').bind(userId).first<User>();}return u;}
function auditStmt(db:D1Database,u:User,event:string,target:string){return db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(uuid(),u.id,event,target,now());}
async function rows(db:D1Database,sql:string,...values:(string|number)[]){return (await db.prepare(sql).bind(...values).all()).results;}
async function body(req:Request){if(!req.headers.get('content-type')?.startsWith('application/json'))throw new ApiError(415,'JSON required');const reader=req.body?.getReader();if(!reader)throw new ApiError(400,'Body required');const parts:Uint8Array[]=[];let size=0;for(;;){const x=await reader.read();if(x.done)break;size+=x.value.length;if(size>24000){await reader.cancel();throw new ApiError(413,'Request too large');}parts.push(x.value);}const out=new Uint8Array(size);let offset=0;for(const p of parts){out.set(p,offset);offset+=p.length;}let d;try{d=JSON.parse(new TextDecoder().decode(out));}catch{throw new ApiError(400,'Invalid JSON');}if(!d||Array.isArray(d)||typeof d!=='object')throw new ApiError(400,'Object required');return d;}
async function limited(db:D1Database,u:User){const bucket=Math.floor(now()/60),key=u.id+':'+bucket;const r=await db.prepare('INSERT INTO rate_limits(id,count,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=rate_limits.count+1 RETURNING count').bind(key,now()+120).first<{count:number}>();if((r?.count??31)>30){await auditStmt(db,u,'write_rate_limited','request').run();throw new ApiError(429,'操作过快，请稍后重试 / Too many requests');}await db.prepare('DELETE FROM rate_limits WHERE expires_at < ?').bind(now()).run();}
async function social(db:D1Database){const x=await db.prepare('SELECT value FROM settings WHERE id=?').bind('social').first<{value:string}>();return x?JSON.parse(x.value):{enabled:false,facebookUrl:'',instagramUrl:''};}
const gameSources=[
 {id:'megah5',name:'MegaH5',path:'/providers/megah5/games',imageHost:'gth.megah5.com'},
 {id:'jili',name:'JILI',path:'/providers/jili/games?account=1to1',imageHost:''},
 {id:'918kissh5',name:'918KISS',path:'/providers/918kissh5/games?account=normal',imageHost:'gth.kissh5.com'}
];
function publicImage(value:unknown,host:string){if(!host||typeof value!=='string'||value.length>500)return null;try{const u=new URL(value);return u.protocol==='https:'&&u.hostname===host&&!u.username&&!u.password&&!u.port&&u.pathname.startsWith('/thumbs/')&&!u.search&&!u.hash?u.href:null;}catch{return null;}}
function boundedText(value:unknown,max=160){return typeof value==='string'?value.trim().slice(0,max):typeof value==='number'&&Number.isFinite(value)?String(value).slice(0,max):'';}
async function gatewayGames(c:Context){
 const unavailable=(status:string)=>({mode:'uat-catalogue-only',playable:false,providers:gameSources.map(s=>({id:s.id,name:s.name,status,count:0})),games:[] as Record<string,unknown>[]});
 let origin:URL;try{origin=new URL(c.gameGatewayUrl??'');if(origin.origin!=='https://master7-integration-gateway.onrender.com'||origin.pathname!=='/'||origin.search||origin.hash) return unavailable('not_configured');}catch{return unavailable('not_configured');}
 const request=c.gameGatewayFetch??fetch;
 const results=await Promise.all(gameSources.map(async source=>{
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
  try{
   const response=await request(new URL(source.path,origin),{method:'GET',headers:{Accept:'application/json'},redirect:'error',signal:controller.signal});
   const length=Number(response.headers.get('content-length')??0);if(length>2*1024*1024)return{source,status:'unavailable',games:[] as Record<string,unknown>[]};
   const raw=await response.text();if(raw.length>2*1024*1024||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')??''))return{source,status:'unavailable',games:[] as Record<string,unknown>[]};
   let data:any;try{data=JSON.parse(raw);}catch{return{source,status:'unavailable',games:[] as Record<string,unknown>[]};}
   if(!response.ok)return{source,status:'blocked',games:[] as Record<string,unknown>[]};
   const rows=source.id==='megah5'?(Array.isArray(data?.result?.Game)?data.result.Game:[]):Array.isArray(data?.games)?data.games:[];
   if(!rows.length)return{source,status:'empty',games:[] as Record<string,unknown>[]};
   const games=rows.slice(0,500).map((g:any)=>{
    const code=boundedText(source.id==='megah5'?(g?.GameCode??g?.GameId):g?.gameCode,100);
    const name=boundedText(source.id==='megah5'?(g?.GameName??g?.OtherName):g?.name);
    const nameZh=boundedText(g?.nameZh??(source.id==='megah5'?g?.OtherName:''));
    return {provider:source.id,providerName:source.name,gameCode:code,name:name||code||source.name,nameZh,category:boundedText(source.id==='megah5'?g?.GameType:g?.category,40),imageUrl:publicImage(source.id==='megah5'?g?.ImageUrl:g?.imageUrl,source.imageHost),maintenance:source.id==='megah5'?Boolean(g?.Maintenance):Boolean(g?.maintenance),playable:false};
   }).filter((g:any)=>g.gameCode&&g.name);
   return{source,status:'available',games};
  }catch{return{source,status:'unavailable',games:[] as Record<string,unknown>[]};}finally{clearTimeout(timer);}
 }));
 const games=results.flatMap(x=>x.games),providers=results.map(x=>({id:x.source.id,name:x.source.name,status:x.status,count:x.games.length}));
 return {mode:'uat-catalogue-only',playable:false,providers,games};
}
export async function handle(req:Request,c:Context):Promise<Response>{try{return await route(req,c);}catch(e){if(e instanceof ApiError||e instanceof AuthError)return json({error:e.message},e.status);const code=e&&typeof e==='object'&&'code'in e&&typeof e.code==='string'&&/^[A-Z0-9]{5}$/.test(e.code)?e.code:'unknown';console.error('MASTER7 API unavailable',e instanceof Error?e.name:'Error',code);return json({error:'服务暂时不可用 / Service temporarily unavailable'},503);}}
async function route(req:Request,c:Context){
 const p=new URL(req.url).pathname,db=c.db;
 if(req.method==='GET'&&(p==='/health'||p==='/api/version')){await db.prepare('SELECT id FROM users LIMIT 1').all();return json({status:'ok',release:RELEASE,sourceRelease:SOURCE_RELEASE,database:'ready',mode:'selfbuilt-service-portal',realPayments:false,liveGames:false,productionReady:false,scope:'portal-database-health'});}
 if(!['GET','POST'].includes(req.method))throw new ApiError(405,'Method not allowed');
 const local=await readLocalSession(req,db);
 if(p.startsWith('/api/auth/'))return handlePasswordAuth(req,c,local);
 const u=local?.user??await currentUser(c,p==='/api/session'&&req.method==='GET');
 if(req.method==='GET'){
  if(p==='/api/session')return json({user:u?{id:u.id,username:u.username,role:u.role,approved:!!u.approved}:null,csrf:u?.csrf??null,authMethod:u?(local?'password':'chatgpt'):null});
  if(p==='/api/announcements')return json({items:await rows(db,'SELECT id,title,body,created_at FROM announcements ORDER BY created_at DESC,id DESC LIMIT 100')});
  if(p==='/api/games')return json(await gatewayGames(c));
  if(p==='/api/providers')return json({items:await rows(db,u&&['staff','owner'].includes(u.role)?'SELECT * FROM providers ORDER BY name':'SELECT * FROM providers WHERE visible=1 ORDER BY name'),playable:false});
  if(p==='/api/social-links'){const s=await social(db);return json(s.enabled?s:{enabled:false,facebookUrl:'',instagramUrl:''});}
  if(p==='/api/tickets'){
   role(u);const staff=u.role!=='member';const items=await rows(db,'SELECT t.*,u.username FROM tickets t JOIN users u ON u.id=t.user_id '+(staff?'':'WHERE t.user_id=? ')+'ORDER BY t.created_at DESC,t.id DESC LIMIT 100',...(staff?[]:[u.id]));
   const replies=await rows(db,'SELECT r.*,u.username FROM replies r JOIN users u ON u.id=r.user_id JOIN tickets t ON t.id=r.ticket_id '+(staff?'':'WHERE t.user_id=? ')+'ORDER BY r.created_at,r.id LIMIT 1000',...(staff?[]:[u.id]));
   return json({items:items.map(t=>({...t,replies:replies.filter(r=>r.ticket_id===t.id)}))});
  }
  if(p.startsWith('/api/admin/')){
   role(u,['owner','staff']);
   if(p==='/api/admin/summary'){const summary=await db.prepare("SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM users WHERE approved=0) pending,(SELECT COUNT(*) FROM tickets WHERE status='open') ticketsOpen,(SELECT COUNT(*) FROM providers WHERE visible=1) providersVisible").first();return json({...summary,financialMetrics:'not-connected'});}
   if(p==='/api/admin/social-links')return json({...await social(db),canEdit:u.role==='owner'});
   if(p==='/api/admin/operations'){const day=Math.floor((now()+28800)/86400)*86400-28800;const n=await db.prepare('SELECT COUNT(*) n FROM users WHERE created_at>=?').bind(day).first<{n:number}>();return json({metrics:{newMembersPreview:n?.n??0,depositMYR:null,withdrawMYR:null,bonusMYR:null,netRevenueMYR:null,groupJoins:null}});}
   role(u,['owner']);
   if(p==='/api/admin/users')return json({items:await rows(db,'SELECT id,username,role,approved,created_at FROM users ORDER BY created_at DESC LIMIT 500')});
   if(p==='/api/admin/audit')return json({items:await rows(db,'SELECT a.event,a.target,a.created_at,u.username FROM audit a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC,a.id DESC LIMIT 100')});
   if(p==='/api/admin/security'){const n=await db.prepare("SELECT COUNT(*) n FROM audit WHERE event='write_rate_limited' AND created_at>=?").bind(Math.floor((now()+28800)/86400)*86400-28800).first<{n:number}>();return json({today:{login_denied:null,login_rate_limited:null,registration_rate_limited:null,write_rate_limited:n?.n??0}});}
   if(p==='/api/admin/export'){const data:Record<string,unknown>={release:RELEASE,exportedAt:new Date().toISOString(),scope:'new-portal-only'};for(const table of ['users','tickets','replies','announcements','providers','settings','audit']){const list=await rows(db,`SELECT ${table==='users'?'id,username,role,approved,created_at':'*'} FROM ${table}${table==='settings'?" WHERE id NOT LIKE 'owner_password_%'":''} LIMIT 10001`);if(list.length>10000)throw new ApiError(413,'导出超过单次上限，请联系站点维护人员');data[table]=list;}return new Response(JSON.stringify(data,null,2),{headers:{...responseHeaders,'Content-Disposition':'attachment; filename="master7-portal-export.json"'}});}
  }
  throw new ApiError(404,'Not found');
 }
 // Cookies alone never authorize writes. Require exact Origin and a per-user token.
 if(!requestOriginAllowed(req,c.allowedOrigins))throw new ApiError(403,'Origin denied');
 role(u);if(!u.approved)throw new ApiError(403,'账号待老板审批 / Account awaiting approval');
 if(req.headers.get('x-csrf-token')!==u.csrf)throw new ApiError(403,'CSRF denied');
 const d=await body(req);await limited(db,u);
 if(p==='/api/tickets'){const subject=textField(d.subject,3,120),message=textField(d.message,5,2000),id=uuid();await db.batch([db.prepare('INSERT INTO tickets(id,user_id,subject,message,created_at) VALUES(?,?,?,?,?)').bind(id,u.id,subject,message,now()),auditStmt(db,u,'ticket_created',id)]);return json({status:'ok',id},201);}
 if(p==='/api/tickets/reply'){const id=idField(d.ticketId),message=textField(d.message,1,2000),ticket=await db.prepare('SELECT user_id,status FROM tickets WHERE id=?').bind(id).first<{user_id:string;status:string}>();if(!ticket||u.role==='member'&&ticket.user_id!==u.id)throw new ApiError(404,'Ticket not found');if(ticket.status!=='open')throw new ApiError(409,'工单已关闭 / Ticket closed');await db.batch([db.prepare('INSERT INTO replies(id,ticket_id,user_id,message,created_at) VALUES(?,?,?,?,?)').bind(uuid(),id,u.id,message,now()),auditStmt(db,u,'ticket_replied',id)]);return json({status:'ok'});}
 if(p.startsWith('/api/admin/')){
  role(u,['owner','staff']);
  if(p==='/api/admin/announcement'){const title=textField(d.title,3,100),content=textField(d.body,5,1000),id=uuid();await db.batch([db.prepare('INSERT INTO announcements(id,title,body,created_by,created_at) VALUES(?,?,?,?,?)').bind(id,title,content,u.id,now()),auditStmt(db,u,'announcement_created',id)]);return json({status:'ok'},201);}
  if(p==='/api/admin/ticket-status'){const id=idField(d.ticketId);if(!['open','closed'].includes(d.status))throw new ApiError(400,'Invalid status');if(!await db.prepare('SELECT id FROM tickets WHERE id=?').bind(id).first())throw new ApiError(404,'Ticket not found');await db.batch([db.prepare('UPDATE tickets SET status=? WHERE id=?').bind(d.status,id),auditStmt(db,u,'ticket_'+d.status,id)]);return json({status:'ok'});}
  if(p==='/api/admin/provider'){const id=idField(d.id);if(typeof d.visible!=='boolean')throw new ApiError(400,'Invalid visibility');if(!await db.prepare('SELECT id FROM providers WHERE id=?').bind(id).first())throw new ApiError(404,'Provider not found');await db.batch([db.prepare('UPDATE providers SET visible=? WHERE id=?').bind(d.visible?1:0,id),auditStmt(db,u,'provider_visibility',id)]);return json({status:'ok'});}
  role(u,['owner']);
  if(p==='/api/admin/approve'||p==='/api/admin/role'){const id=idField(d.userId),target=await db.prepare('SELECT role FROM users WHERE id=?').bind(id).first<{role:string}>();if(!target)throw new ApiError(404,'User not found');if(target.role==='owner')throw new ApiError(403,'Owner protected');if(p.endsWith('/role')){if(!['member','staff'].includes(d.role))throw new ApiError(400,'Invalid role');await db.batch([db.prepare('UPDATE users SET role=?,approved=1 WHERE id=?').bind(d.role,id),auditStmt(db,u,'role_'+d.role,id)]);}else await db.batch([db.prepare('UPDATE users SET approved=1 WHERE id=?').bind(id),auditStmt(db,u,'user_approved',id)]);return json({status:'ok'});}
  if(p==='/api/admin/social-links'){if(typeof d.enabled!=='boolean')throw new ApiError(400,'Invalid state');const value={enabled:d.enabled,facebookUrl:urlField(d.facebookUrl,'facebook'),instagramUrl:urlField(d.instagramUrl,'instagram')};if(value.enabled&&!value.facebookUrl&&!value.instagramUrl)throw new ApiError(400,'至少填写一个主页');await db.batch([db.prepare("INSERT INTO settings(id,value) VALUES('social',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value").bind(JSON.stringify(value)),auditStmt(db,u,'social_links_updated','social')]);return json({status:'ok'});}
 }
 throw new ApiError(404,'Not found');
}
