export const GAME_PROVIDER_ADAPTER_METHODS = [
  'listGames',
  'createOrVerifyPlayer',
  'depositToGame',
  'launchGame',
  'queryBalance',
  'withdrawFromGame',
  'queryTransfer',
  'fetchWagers',
  'handleCallback',
] as const;

export type GameProviderAdapterMethod = typeof GAME_PROVIDER_ADAPTER_METHODS[number];
export type GameWalletMode = 'transfer' | 'seamless' | 'unknown';
export type ProviderOperationState = 'confirmed' | 'rejected' | 'unknown';

export type GameProviderProfile = {
  profileId: string;
  providerId: string;
  displayName: string;
  walletMode: GameWalletMode;
  currency: 'MYR';
  unitScale: 1 | 100;
  adapterKey: string;
  envPrefix: string;
  playerNamespace: string;
  ledgerNamespace: string;
  listedInLobby: boolean;
};

export type GameProviderContext = {
  profile: GameProviderProfile;
  fetchImpl?: typeof fetch;
  now?: () => number;
};

export type GameProviderGame = {
  providerGameId: string;
  name: string;
  category: string;
  maintenance: boolean;
};

export type GameProviderMember = {userId: string; username: string};
export type GameProviderPlayer = {providerPlayerId: string; created: boolean};

export type GameProviderTransferInput = {
  userId: string;
  providerPlayerId: string;
  platformTransactionId: string;
  amountMinor: string;
  currency: 'MYR';
};

export type GameProviderTransferResult = {
  state: ProviderOperationState;
  providerTransactionId?: string;
  errorCode?: string;
  // A confirmed supplier receipt is not a platform-wallet posting.
  requiresLedgerReconciliation?: boolean;
};

export type GameProviderLaunchInput = {
  userId: string;
  providerPlayerId: string;
  providerGameId: string;
  language: 'en' | 'zh' | 'ms';
  ip: string;
  returnUrl: string;
};

export type GameProviderLaunchResult = {launchUrl: string; providerSessionId?: string};
export type GameProviderBalance = {amountMinor: string; currency: 'MYR'; residual: boolean; providerAmount?: string};
// Recovery must bind a provider result to the original member, direction and
// amount. A reference alone cannot prove which wallet transaction completed.
export type GameProviderTransferQuery = {
  userId: string;
  platformTransactionId: string;
  providerTransactionId?: string;
  providerPlayerId: string;
  direction: 'deposit' | 'withdrawal';
  amountMinor: string;
  currency: 'MYR';
};
// Report windows and settledAt use Unix milliseconds. Database ingestion must
// explicitly convert units and must not advance a cursor for incomplete pages.
export type GameProviderWagerCursor = {cursor?: string; from: number; to: number};
export type GameProviderWager = {
  // Some transfer-wallet reports have a bet ID but no round ID. Do not invent it.
  providerRoundId: string | null;
  providerBetId: string;
  providerPlayerId: string;
  providerGameId: string;
  betMinor: string;
  winMinor: string;
  currency: 'MYR';
  settledAt: number;
  sourceDetails?: Readonly<Record<string, string>>;
};
export type GameProviderWagerPage = {items: GameProviderWager[]; nextCursor?: string; complete: boolean};
export type GameProviderCallbackResult = {accepted: boolean; duplicate: boolean; providerEventId?: string; responseBody: string; responseStatus: number};

export interface GameProviderAdapter {
  readonly key: string;
  readonly executable: boolean;
  listGames(context: GameProviderContext): Promise<readonly GameProviderGame[]>;
  createOrVerifyPlayer(context: GameProviderContext, member: GameProviderMember): Promise<GameProviderPlayer>;
  depositToGame(context: GameProviderContext, input: GameProviderTransferInput): Promise<GameProviderTransferResult>;
  launchGame(context: GameProviderContext, input: GameProviderLaunchInput): Promise<GameProviderLaunchResult>;
  queryBalance(context: GameProviderContext, input: Pick<GameProviderTransferInput, 'userId' | 'providerPlayerId'>): Promise<GameProviderBalance>;
  withdrawFromGame(context: GameProviderContext, input: GameProviderTransferInput): Promise<GameProviderTransferResult>;
  queryTransfer(context: GameProviderContext, input: GameProviderTransferQuery): Promise<GameProviderTransferResult>;
  fetchWagers(context: GameProviderContext, cursor: GameProviderWagerCursor): Promise<GameProviderWagerPage>;
  handleCallback(context: GameProviderContext, request: Request): Promise<GameProviderCallbackResult>;
}

export type GameProviderBlocker = 'contract_missing' | 'adapter_unimplemented';

export class GameProviderUnavailableError extends Error {
  readonly status = 503;
  readonly code = 'GAME_PROVIDER_UNAVAILABLE';
  readonly profileId: string;
  readonly reason: GameProviderBlocker;
  readonly operation: GameProviderAdapterMethod;
  constructor(
    profileId: string,
    reason: GameProviderBlocker,
    operation: GameProviderAdapterMethod,
  ) {
    super(`${profileId} is unavailable: ${reason}`);
    this.profileId = profileId;
    this.reason = reason;
    this.operation = operation;
  }
}

export function createFailClosedGameProviderAdapter(profile: GameProviderProfile, reason: GameProviderBlocker): GameProviderAdapter {
  const blocked = (operation: GameProviderAdapterMethod): never => {
    throw new GameProviderUnavailableError(profile.profileId, reason, operation);
  };
  return Object.freeze({
    key: `blocked:${profile.adapterKey}`,
    executable: false,
    listGames: async () => blocked('listGames'),
    createOrVerifyPlayer: async () => blocked('createOrVerifyPlayer'),
    depositToGame: async () => blocked('depositToGame'),
    launchGame: async () => blocked('launchGame'),
    queryBalance: async () => blocked('queryBalance'),
    withdrawFromGame: async () => blocked('withdrawFromGame'),
    queryTransfer: async () => blocked('queryTransfer'),
    fetchWagers: async () => blocked('fetchWagers'),
    handleCallback: async () => blocked('handleCallback'),
  });
}
