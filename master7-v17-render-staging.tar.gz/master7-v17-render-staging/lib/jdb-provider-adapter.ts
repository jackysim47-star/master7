import {
  createJdbProtocolClient, jdbPlayerId, jdbSerialNo,
  type JdbConfig, type JdbDirection, type JdbProfile, type JdbTransferResult,
} from './jdb-transfer-protocol.ts';
import type {
  GameProviderAdapter, GameProviderContext, GameProviderTransferInput,
  GameProviderTransferResult, GameProviderWager,
} from './game-provider-adapter.ts';

export type JdbAdapterOptions = {
  fetchImpl: typeof fetch;
  now?: () => number;
  allowedReturnOrigins: readonly string[];
  playerCreationEnabled?: boolean;
  launchEnabled?: boolean;
  depositEnabled?: boolean;
  withdrawalEnabled?: boolean;
};

export class JdbAdapterError extends Error {
  readonly code: string;
  constructor(code: string) { super(code); this.name = 'JdbAdapterError'; this.code = code; }
}
const fail = (code: string): never => { throw new JdbAdapterError(code); };

function exactOrigin(raw: string): string {
  let url: URL;
  try { url = new URL(raw); } catch { return fail('JDB_RETURN_ORIGIN_INVALID'); }
  if (url.origin !== raw || url.protocol !== 'https:' || url.username || url.password || url.port) return fail('JDB_RETURN_ORIGIN_INVALID');
  return raw;
}
function memberId(raw: unknown): string {
  if (typeof raw !== 'string' || raw.length < 1 || raw.length > 200 || /[\u0000-\u001f\u007f]/.test(raw)) return fail('JDB_MEMBER_INVALID');
  return raw;
}
function cents(raw: string): bigint {
  const match = /^(-?)(0|[1-9]\d{0,8})(?:\.(\d{1,6}))?$/.exec(raw);
  if (!match || /[1-9]/.test((match[3] ?? '').slice(2))) return fail('JDB_REPORT_PRECISION_REVIEW');
  const amount = BigInt(match[2]) * 100n + BigInt((match[3] ?? '').slice(0, 2).padEnd(2, '0'));
  return match[1] === '-' ? -amount : amount;
}
function providerDate(raw: string, offset: number): number {
  const match = /^(\d{2})-(\d{2})-(\d{4}) (\d{2}):(\d{2}):(\d{2})$/.exec(raw);
  if (!match) return fail('JDB_REPORT_DATE_INVALID');
  const [,day,month,year,hour,minute,second] = match.map(Number), local = Date.UTC(year, month - 1, day, hour, minute, second), date = new Date(local);
  if (year < 1970 || year > 2100 || date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day || date.getUTCHours() !== hour || date.getUTCMinutes() !== minute || date.getUTCSeconds() !== second) return fail('JDB_REPORT_DATE_INVALID');
  return local - offset * 60_000;
}
function receipt(result: JdbTransferResult, expectedReference?: string): GameProviderTransferResult {
  if (result.state === 'matched') {
    if (expectedReference !== undefined && result.providerTransactionId !== expectedReference) return {state:'unknown',errorCode:'JDB_TRANSFER_REFERENCE_MISMATCH',requiresLedgerReconciliation:true};
    return {state:'confirmed',providerTransactionId:result.providerTransactionId,requiresLedgerReconciliation:true};
  }
  return {state:result.state,errorCode:result.providerCode ? `JDB_${result.providerCode}` : 'JDB_TRANSFER_RESULT_UNKNOWN',requiresLedgerReconciliation:true};
}

/** Protocol adapter only. No registry activation, database writes, wallet
 * postings or live acceptance is implied by constructing this object. */
export function createJdbGameProviderAdapter(config: JdbConfig, options: JdbAdapterOptions): GameProviderAdapter & {readonly profileId:JdbProfile} {
  if(!config||!Array.isArray(config.launchOrigins)||!options||!Array.isArray(options.allowedReturnOrigins))return fail('JDB_CONFIGURATION_INVALID');
  const snapshot = {...config, launchOrigins:[...config.launchOrigins]}, clock = options.now ?? Date.now;
  const client = createJdbProtocolClient(snapshot, options.fetchImpl, clock), profileId = snapshot.profile;
  const expectedProvider = profileId === 'jdb_myr' ? 'jdb' : 'spribe';
  const returns = new Set(options.allowedReturnOrigins.map(exactOrigin));
  const flags = Object.freeze({player:options.playerCreationEnabled===true,launch:options.launchEnabled===true,deposit:options.depositEnabled===true,withdraw:options.withdrawalEnabled===true});

  function context(c: GameProviderContext) {
    const p = c?.profile;
    if (!p || p.profileId !== profileId || p.providerId !== expectedProvider || p.adapterKey !== 'jdb' || p.walletMode !== 'transfer' || p.currency !== 'MYR' || p.unitScale !== 1 || p.playerNamespace !== profileId || p.ledgerNamespace !== profileId) return fail('JDB_PROFILE_MISMATCH');
  }
  function boundPlayer(user: unknown, supplied: unknown) {
    const expected = jdbPlayerId(profileId, memberId(user));
    if (supplied !== expected) return fail('JDB_PLAYER_MISMATCH');
    return expected;
  }
  function transferInput(input: GameProviderTransferInput, direction: JdbDirection) {
    const uid = boundPlayer(input?.userId, input?.providerPlayerId);
    if (input.currency !== 'MYR' || typeof input.platformTransactionId !== 'string' || !/^[A-Za-z0-9_.:-]{1,200}$/.test(input.platformTransactionId) || typeof input.amountMinor !== 'string' || !/^[1-9]\d{0,10}$/.test(input.amountMinor) || BigInt(input.amountMinor)>99_999_999_900n) return fail('JDB_TRANSFER_INPUT_INVALID');
    return {playerId:uid,serialNo:jdbSerialNo(profileId,input.platformTransactionId,direction),direction,amountMinor:input.amountMinor};
  }
  async function transfer(c: GameProviderContext, input: GameProviderTransferInput, direction: JdbDirection) {
    context(c);const validated = transferInput(input,direction);
    if (!flags[direction]) return fail('JDB_TRANSFER_SUBMISSION_DISABLED');
    // Check currency/parent before sending money. Failure keeps the caller's
    // reservation unresolved; a supplier receipt never posts a local credit.
    try {
      const player = await client.verifyPlayer(validated.playerId);
      if ((direction==='deposit'&&!player.active)||player.residual) return {state:'unknown' as const,errorCode:'JDB_PLAYER_REQUIRES_REVIEW',requiresLedgerReconciliation:true};
    } catch { return {state:'unknown' as const,errorCode:'JDB_PLAYER_VERIFICATION_FAILED',requiresLedgerReconciliation:true}; }
    return receipt(await client.transfer(validated));
  }

  const adapter: GameProviderAdapter & {readonly profileId:JdbProfile} = {
    key:'jdb',profileId,executable:true,
    async listGames(c) {
      context(c);return (await client.listGames()).map(game=>({...game,category:'unknown'}));
    },
    async createOrVerifyPlayer(c, member) {
      context(c);const uid=jdbPlayerId(profileId,memberId(member?.userId));
      // A disabled create switch still permits verification of an existing
      // player. A timeout is followed only by a read, never a second create.
      const created=flags.player?await client.createPlayer(uid):null;
      const verified=await client.verifyPlayer(uid);
      if(!verified.active)return fail('JDB_PLAYER_UNAVAILABLE');
      return {providerPlayerId:uid,created:created?.state==='created'};
    },
    depositToGame: (c,input)=>transfer(c,input,'deposit'),
    withdrawFromGame: (c,input)=>transfer(c,input,'withdraw'),
    async queryBalance(c,input) {
      context(c);const uid=boundPlayer(input?.userId,input?.providerPlayerId),player=await client.verifyPlayer(uid);
      return {amountMinor:player.amountMinor,currency:'MYR',residual:player.residual,providerAmount:player.providerAmount};
    },
    async launchGame(c,input) {
      context(c);const uid=boundPlayer(input?.userId,input?.providerPlayerId);
      if(!flags.launch)return fail('JDB_LAUNCH_DISABLED');
      let url:URL;try{url=new URL(input.returnUrl);}catch{return fail('JDB_RETURN_URL_INVALID');}
      if(!returns.has(url.origin)||url.protocol!=='https:'||url.username||url.password||url.hash||url.href.length>100)return fail('JDB_RETURN_URL_INVALID');
      const player=await client.verifyPlayer(uid);if(!player.active)return fail('JDB_PLAYER_UNAVAILABLE');
      return client.launch(uid,input.providerGameId,input.language,url.href);
    },
    async queryTransfer(c,input) {
      context(c);
      if(input?.direction!=='deposit'&&input?.direction!=='withdrawal')return fail('JDB_TRANSFER_INPUT_INVALID');
      const validated=transferInput(input,input.direction==='deposit'?'deposit':'withdraw');
      if(input.providerTransactionId!==undefined&&(typeof input.providerTransactionId!=='string'||!/^[1-9]\d{0,19}$/.test(input.providerTransactionId)))return fail('JDB_TRANSFER_INPUT_INVALID');
      try{await client.verifyPlayer(validated.playerId);}catch{return {state:'unknown',errorCode:'JDB_PLAYER_VERIFICATION_FAILED',requiresLedgerReconciliation:true};}
      return receipt(await client.queryTransfer(validated),input.providerTransactionId);
    },
    async fetchWagers(c,cursor) {
      context(c);
      if(!cursor||typeof cursor!=='object')return fail('JDB_REPORT_WINDOW_INVALID');
      if(cursor?.cursor!==undefined)return fail('JDB_REPORT_CURSOR_UNSUPPORTED');
      const offset=snapshot.reportUtcOffsetMinutes;
      if(offset===undefined)return fail('JDB_REPORT_TIMEZONE_UNCONFIRMED');
      const from=cursor.from,to=cursor.to,mode=from>=clock()-2*60*60_000?'recent':'old';
      const page=await client.fetchWagers(mode,from,to),seen=new Set<string>();
      const items:GameProviderWager[]=page.records.map(raw=>{
        const row=raw as typeof raw & Record<string,string|number|null>;
        const gameType=Number(raw.providerGameId.split(':')[0]);
        if((gameType===9||gameType===92||row.hasGamble==='1')&&typeof row.gambleBet!=='string')return fail('JDB_REPORT_GAMBLE_DATA_MISSING');
        const bet=cents(raw.bet),win=cents(raw.win),gamble=row.gambleBet===undefined?0n:cents(String(row.gambleBet));
        if(bet>0n||gamble>0n||win<0n)return fail('JDB_REPORT_AMOUNT_DIRECTION_INVALID');
        const gameAt=providerDate(raw.gameDate,offset),modifiedAt=providerDate(raw.lastModifyTime,offset),sourceAt=mode==='recent'?modifiedAt:gameAt;
        if(sourceAt<from||sourceAt>to)return fail('JDB_REPORT_WINDOW_MISMATCH');
        const key=`${raw.providerGameId}\0${raw.historyId}`;if(seen.has(key))return fail('JDB_REPORT_DUPLICATE_BET');seen.add(key);
        const sourceDetails:Record<string,string>={bet:raw.bet,win:raw.win,total:raw.total,gameDate:raw.gameDate,lastModifyTime:raw.lastModifyTime,timeBasis:page.timeBasis};
        for(const field of ['gambleBet','hasGamble','tax','validBet','jackpot','jackpotContribute'])if(row[field]!==undefined)sourceDetails[field]=String(row[field]);
        return {providerRoundId:raw.roundSeqNo,providerBetId:raw.historyId,providerPlayerId:raw.playerId,providerGameId:raw.providerGameId,betMinor:(-(bet+gamble)).toString(),winMinor:win.toString(),currency:'MYR',settledAt:modifiedAt,sourceDetails:Object.freeze(sourceDetails)};
      });
      // A supplier time window is not a durable ingestion or coverage receipt.
      return {items,complete:false};
    },
    async handleCallback(c) {
      context(c);return {accepted:false,duplicate:false,responseBody:'UNSUPPORTED_TRANSFER_CALLBACK',responseStatus:403};
    },
  };
  return Object.freeze(adapter);
}
