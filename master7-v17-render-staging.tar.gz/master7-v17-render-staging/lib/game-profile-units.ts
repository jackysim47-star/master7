import {GAME_PROVIDER_PROFILES,getGameProviderProfile} from './game-provider-registry.ts';

/** Ratios describe supplier game points per MYR. All wallet operations remain
 * MYR sen; only the supplier adapter converts at its transport boundary. */
export function registeredCashProfileUnits(profileId:string){
 const profile=getGameProviderProfile(profileId);
 if(!profile||profile.balanceClass==='free_credit')return null;
 return {providerId:profile.providerId,unitScale:profile.unitScale,numerator:profile.unitScale,denominator:1} as const;
}

// These strings contain compiled registry identifiers only, never request data.
const cashProfiles=GAME_PROVIDER_PROFILES.filter(profile=>profile.balanceClass!=='free_credit');
if(cashProfiles.some(profile=>!/^\w+$/.test(profile.profileId)))throw new Error('Invalid registered game profile identifier');
const ids=cashProfiles.map(profile=>`'${profile.profileId}'`).join(',');
const hundred=cashProfiles.filter(profile=>profile.unitScale===100).map(profile=>`'${profile.profileId}'`).join(',');
export const registeredCashProfileRatioSql=`(p.id IN (${ids}) AND p.unit_denominator=1 AND p.unit_numerator=CASE WHEN p.id IN (${hundred||"''"}) THEN 100 ELSE 1 END)`;
