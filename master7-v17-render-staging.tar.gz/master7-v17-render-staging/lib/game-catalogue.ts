import {directCatalogueConfigured,readDirectCatalogue,CatalogueReadError,type DirectCatalogueConfig} from './direct-game-catalogues.ts';
import {GAME_PROVIDER_IDS} from './game-ranking.ts';
type SyncContext=DirectCatalogueConfig&{db:D1Database;gameGatewayUrl?:string;gameGatewayFetch?:typeof fetch;gameSyncNow?:()=>number};
type Source={direct?:boolean;id:string;name:string;path:string;shape:'mega'|'normalized'|'evo';imageHost?:string;cacheKey?:string;profileId?:string;expectedAccount?:string;expectedCurrency?:string;expectedRatio?:string};
type Game={provider:string;providerName:string;gameCode:string;originalProviderId?:string;originalGameCode?:string;profileId?:string;catalogueAccount?:string;providerCurrency?:string;name:string;nameZh:string;category:string;imageUrl:string|null;maintenance:boolean;playable:false;artworkSource?:string};
type Cache={provider_id:string;status:string;games_json:string;checked_at:number;last_success_at:number;lease_until:number;upstream_status:number|null;complete:number};
const gateway='https://master7-integration-gateway.onrender.com';
const ttl=300,leaseSeconds=35,maxGames=2000;
export function gameCatalogueCacheFresh(c:SyncContext,checkedAt:number){
 // Ordinary synchronization starts at checked_at <= time - ttl. A summary
 // may trust only the complementary interval, without starting that request.
 const time=Math.floor(c.gameSyncNow?.()??Date.now()/1000);
 return Number.isFinite(checkedAt)&&checkedAt>time-ttl&&checkedAt<=time+5;
}
const publicProviderIds=new Set<string>(GAME_PROVIDER_IDS);
export const gameSources:readonly Source[]=[
 {id:'megah5',name:'MegaH5',path:'/providers/megah5/games',shape:'mega',imageHost:'gth.megah5.com'},
 {id:'jili',name:'JILI',path:'/providers/jili/games?account=1to1',shape:'normalized'},
 {id:'jdb',name:'JDB',path:'/providers/jdb/games',shape:'normalized'},
 {id:'pragmaticplay',name:'PRAGMATIC PLAY',path:'/providers/pragmaticplay/games',shape:'normalized'},
 {id:'918kissh5',name:'918KISS H5',path:'/providers/918kissh5/games?account=normal',shape:'normalized',imageHost:'gth.kissh5.com',expectedAccount:'normal',expectedCurrency:'MYR'},
 {id:'metagaming',name:'META GAMING',path:'/providers/metagaming/games?account=normal',shape:'normalized',cacheKey:'metagaming_normal_myr',profileId:'metagaming_normal_myr',expectedAccount:'normal',expectedCurrency:'MYR'},
 {id:'evo888h5',name:'EVO888H5',path:'/providers/evo888h5/games',shape:'evo',imageHost:'backendapi.evo888h5.com'},
 {id:'epicwin',name:'EPICWIN',path:'/providers/epicwin/games?account=normal',shape:'normalized'},
 {id:'venus',name:'VENUS GAMING',path:'/providers/venus/games',shape:'normalized'},
 {id:'clotplay',name:'CLOTPLAY',path:'/providers/clotplay/games',shape:'normalized'},
];
const kissSource=gameSources.find(source=>source.id==='918kissh5')!;
const kissProfileSources:Readonly<Record<string,Source>>=Object.freeze({
 '918kiss_normal_myr':Object.freeze({...kissSource,cacheKey:'918kiss_normal_myr',profileId:'918kiss_normal_myr'}),
 '918kiss_normal_my1_1to100':Object.freeze({...kissSource,path:'/providers/918kissh5/games?account=my1',cacheKey:'918kiss_normal_my1_1to100',profileId:'918kiss_normal_my1_1to100',expectedAccount:'my1',expectedCurrency:'MY1'}),
 '918kiss_free_myr':Object.freeze({...kissSource,path:'/providers/918kissh5/games?account=free',cacheKey:'918kiss_free_myr',profileId:'918kiss_free_myr',expectedAccount:'free',expectedCurrency:'MYR'}),
});
const jiliSource=gameSources.find(source=>source.id==='jili')!;
const jiliProfileSources:Readonly<Record<string,Source>>=Object.freeze({
 'jili_myr_1to1':Object.freeze({...jiliSource,cacheKey:'jili_myr_1to1',profileId:'jili_myr_1to1',expectedAccount:'1to1',expectedCurrency:'MYR',expectedRatio:'1:1'}),
 'jili_my1_1to100':Object.freeze({...jiliSource,path:'/providers/jili/games?account=1to100',cacheKey:'jili_my1_1to100',profileId:'jili_my1_1to100',expectedAccount:'1to100',expectedCurrency:'MYR',expectedRatio:'1:100'}),
});
const metaSource=gameSources.find(source=>source.id==='metagaming')!;
const metaProfileSources:Readonly<Record<string,Source>>=Object.freeze({
 'metagaming_normal_myr':metaSource,
 'metagaming_free_myr':Object.freeze({...metaSource,path:'/providers/metagaming/games?account=free',cacheKey:'metagaming_free_myr',profileId:'metagaming_free_myr',expectedAccount:'free'}),
});
// GodeeZone is a separate, internal-only profile until its brand, wallet and
// launch contract are verified. Never reuse ATG's account or cached catalogue.
const directSources:readonly Source[]=[{id:'rectangle',name:'RECTANGLE',path:'',shape:'normalized',direct:true},{id:'godeezone',name:'GodeeZone',path:'',shape:'normalized',direct:true}];
// Per-game owner controls use the same fixed catalogue source inventory. Keep
// this list separate from the 37 supplier artwork buttons: accepting an
// arbitrary supplier id here would allow records that can never appear in a
// trusted game catalogue.
export const gameControlSourceIds:readonly string[]=Object.freeze([...gameSources,...directSources].map(source=>source.id));
const text=(value:unknown,max=160)=>typeof value==='string'?value.trim().slice(0,max):typeof value==='number'&&Number.isFinite(value)?String(value).slice(0,max):'';
const sourceCacheKey=(source:Source)=>source.cacheKey??source.id;
function selectProfileSource(providerId:string|undefined,profileId:string|undefined){
 if(providerId==='jili'&&profileId)return jiliProfileSources[profileId]??null;
 if(providerId==='metagaming'&&profileId)return metaProfileSources[profileId]??null;
 if(providerId!=='918kissh5'||!profileId)return null;
 return kissProfileSources[profileId]??null;
}
export function defaultGameCatalogueCacheKey(providerId:string){return gameSources.find(source=>source.id===providerId)?.cacheKey??providerId;}
function configured(value?:string){try{const u=new URL(value??'');return u.origin===gateway&&u.pathname==='/'&&!u.search&&!u.hash&&!u.username&&!u.password;}catch{return false;}}
export function configuredGameCatalogueSourceIds(c:DirectCatalogueConfig&{gameGatewayUrl?:string}):readonly string[]{
 const sources=[...(configured(c.gameGatewayUrl)?gameSources:[]),...directSources.filter(source=>directCatalogueConfigured(c,source.id))];
 return Object.freeze(sources.map(source=>source.id));
}
export function configuredGameCatalogueCacheKeys(c:DirectCatalogueConfig&{gameGatewayUrl?:string}):readonly string[]{
 const sources=[...(configured(c.gameGatewayUrl)?gameSources:[]),...directSources.filter(source=>directCatalogueConfigured(c,source.id))];
 return Object.freeze(sources.map(sourceCacheKey));
}
export function approvedArtworkUrl(source:Source,value:unknown){
 try{const u=new URL(String(value));const path=source.id==='evo888h5'?/^\/slots\/cover-img\/[A-Za-z0-9_-]+\.(?:png|webp|jpe?g)$/.test(u.pathname):u.pathname.startsWith('/thumbs/');return u.protocol==='https:'&&u.hostname===source.imageHost&&path&&!u.port&&!u.search&&!u.hash&&!u.username&&!u.password?u.href:null;}catch{return null;}
}
function normalize(source:Source,rows:any[]){
 const seen=new Set<string>();
 return rows.slice(0,maxGames).map((g:any):Game|null=>{
  if(!g||typeof g!=='object'||Array.isArray(g))return null;
  const mega=source.shape==='mega',evo=source.shape==='evo';
  const gameCode=text(mega?g.GameCode??g.GameId:evo?g.gameid:g.gameCode,100);
  if(!gameCode||/[\u0000-\u001f\u007f]/.test(gameCode)||seen.has(gameCode))return null;seen.add(gameCode);
  const artwork=approvedArtworkUrl(source,mega?g.ImageUrl:evo?g.thumbnail:g.imageUrl);
  const profileQuery=source.profileId?`&profileId=${encodeURIComponent(source.profileId)}`:'';
  const imageUrl=artwork?`/api/game-art?provider=${source.id}${profileQuery}&gameCode=${encodeURIComponent(gameCode)}`:source.id==='jili'?'/assets/providers/jili.webp':source.id==='jdb'?'/assets/providers/jdb.webp':source.id==='pragmaticplay'?'/assets/providers/pragmaticplay.webp':source.id==='metagaming'?'/assets/providers/metagaming.webp':source.id==='evo888h5'?'/assets/providers/evo888h5.webp':source.id==='rectangle'?'/assets/providers/rectangle.webp':source.id==='atg'?'/assets/providers/atg.webp':null;
  return {provider:source.id,providerName:source.id==='godeezone'?text(g.providerName)||source.name:source.name,gameCode,...(source.id==='godeezone'?{originalProviderId:text(g.originalProviderId,40),originalGameCode:text(g.originalGameCode,100)}:{}),...(source.profileId?{profileId:source.profileId}:{}),...(source.expectedAccount?{catalogueAccount:source.expectedAccount}:{}),...(source.expectedCurrency?{providerCurrency:source.expectedCurrency}:{}),name:text(mega?g.GameName??g.OtherName:evo?g.title??g.name:g.name)||gameCode,nameZh:text(g.nameZh??(mega?g.OtherName:'')),category:evo?'SLOT':text(mega?g.GameType:source.id==='metagaming'?g.gameType:g.category,40),imageUrl,maintenance:mega?g.Maintenance===true||g.Maintenance===1||g.Maintenance==='true'||g.Maintenance==='1':g.maintenance===true,playable:false,...(source.id==='evo888h5'&&artwork?{artworkSource:artwork}:{})};
 }).filter((g):g is Game=>g!==null);
}
async function boundedJson(response:Response){
 if(!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')??''))throw Error('INVALID_CONTENT_TYPE');
 const reader=response.body?.getReader();if(!reader)throw Error('EMPTY_RESPONSE');let size=0;const parts:Uint8Array[]=[];
 for(;;){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>2*1024*1024){await reader.cancel();throw Error('RESPONSE_TOO_LARGE');}parts.push(next.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}const data=JSON.parse(new TextDecoder().decode(bytes));if(!data||typeof data!=='object'||Array.isArray(data))throw Error('INVALID_RESPONSE');return data;
}
function cacheGames(value:unknown):Game[]{try{const rows=JSON.parse(String(value));return Array.isArray(rows)?rows.slice(0,maxGames):[];}catch{return [];}}
async function synchronizeSource(c:SyncContext,source:Source,force:boolean,time:number){
 const cacheKey=sourceCacheKey(source);
 const claim=await c.db.prepare(`INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,lease_until,complete)
   VALUES(?,'unavailable','[]',0,0,?,0)
   ON CONFLICT(provider_id) DO UPDATE SET lease_until=excluded.lease_until
   WHERE game_catalogue_cache.lease_until<=? AND game_catalogue_cache.checked_at<=?
   RETURNING provider_id`).bind(cacheKey,time+leaseSeconds,time,time-(force?5:ttl)).first();
 if(!claim)return;
 const fetcher=c.gameGatewayFetch??fetch;let status='unavailable',upstream:number|null=null,complete=false;
 try{
  const direct=source.direct?await readDirectCatalogue(c,source.id,time):null;
  const response=direct?Response.json({games:direct.games,complete:direct.complete,upstreamStatus:200}):await fetcher(gateway+source.path,{method:'GET',headers:{Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(10000)});
  const data=await boundedJson(response);const code=Number(data.upstreamStatus);if(Number.isInteger(code)&&code>=100&&code<600)upstream=code;
  if(!response.ok){status='blocked';return;}
  const rows=source.shape==='mega'?data.result?.Game:source.shape==='evo'?data.result?.data:data.games;
  if(!Array.isArray(rows)){status='unavailable';return;}
  if(source.shape==='mega'&&Number(data.result?.Status)!==200||source.shape==='evo'&&Number(data.result?.code)!==0){status='blocked';return;}
  if(source.expectedAccount&&(data.provider!==source.id||data.account!==source.expectedAccount||data.currency!==source.expectedCurrency)){status='blocked';return;}
  if(source.expectedRatio&&data.ratio!==source.expectedRatio){status='blocked';return;}
  const games=normalize(source,rows);complete=data.complete!==false&&rows.length<=maxGames&&!(source.id==='clotplay'&&Number(data.pagination?.last_page)>1);
  // An empty success replaces the previous catalogue intentionally; transport
  // and protocol failures retain the last good snapshot for a stable lobby.
  await c.db.prepare(`UPDATE game_catalogue_cache SET games_json=?,status=?,checked_at=?,last_success_at=?,upstream_status=?,complete=?,lease_until=0 WHERE provider_id=? AND lease_until=?`)
   .bind(JSON.stringify(games),games.length?'available':'empty',time,time,upstream,complete?1:0,cacheKey,time+leaseSeconds).run();
  if(games.length&&publicProviderIds.has(source.id))await c.db.prepare("INSERT INTO providers(id,name,category,symbol,visible) VALUES(?,?,'supplier',?,1) ON CONFLICT(id) DO NOTHING").bind(source.id,source.name,source.id==='rectangle'?'RG':source.id==='atg'?'ATG':'M7').run();
  status='saved';
 }catch(error){status='unavailable';if(error instanceof CatalogueReadError){upstream=error.upstreamStatus;status=upstream&&upstream>=400?'blocked':'unavailable';}}
 finally{
  if(status!=='saved')await c.db.prepare('UPDATE game_catalogue_cache SET status=?,checked_at=?,upstream_status=?,lease_until=0 WHERE provider_id=? AND lease_until=?').bind(status,time,upstream,cacheKey,time+leaseSeconds).run();
 }
}
export async function getGameCatalogue(c:SyncContext,options:{force?:boolean;providerId?:string;profileId?:string}={}){
 const direct=directSources.filter(source=>directCatalogueConfigured(c,source.id));
 if(!configured(c.gameGatewayUrl)&&!direct.length)return {mode:'catalogue-only',playable:false,providers:gameSources.map(s=>({id:s.id,name:s.name,status:'not_configured',count:0,catalogueSynced:false,launchVerified:false,walletVerified:false})),games:[]};
 const available=[...(configured(c.gameGatewayUrl)?gameSources:[]),...direct];
 const selectedProfileSource=configured(c.gameGatewayUrl)?selectProfileSource(options.providerId,options.profileId):null,sources=selectedProfileSource?[selectedProfileSource]:options.profileId&&['918kissh5','jili','metagaming'].includes(options.providerId??'')?[]:options.providerId?available.filter(source=>source.id===options.providerId):available;
 const time=Math.floor(c.gameSyncNow?.()??Date.now()/1000);
 await Promise.all(sources.map(source=>synchronizeSource(c,source,!!options.force,time)));
 const rows=(await c.db.prepare('SELECT * FROM game_catalogue_cache').all<Cache>()).results??[];
 const results=sources.map(source=>{
  const cache=rows.find(row=>row.provider_id===sourceCacheKey(source));const saved=cacheGames(cache?.games_json),stale=!gameCatalogueCacheFresh(c,Number(cache?.checked_at))||cache?.status!=='available'&&cache?.status!=='empty';
  const games=saved.map(entry=>{const game={...entry};delete game.artworkSource;return {...game,...(source.profileId?{profileId:source.profileId}:{}),...(source.expectedAccount?{catalogueAccount:source.expectedAccount}:{}),...(source.expectedCurrency?{providerCurrency:source.expectedCurrency}:{}),providerMaintenance:!!game.maintenance,...(stale?{maintenance:true}:{}),playable:false as const};});
  return {provider:{id:source.id,name:source.name,status:cache?.status??'unavailable',count:games.length,...(source.profileId?{catalogueProfileId:source.profileId}:{}),...(source.expectedAccount?{catalogueAccount:source.expectedAccount}:{}),...(source.expectedCurrency?{providerCurrency:source.expectedCurrency}:{}),catalogueSynced:games.length>0&&cache?.complete===1&&!stale,connectionVerified:cache?.status==='available'&&!stale,launchVerified:false,walletVerified:false,complete:cache?.complete===1,stale,checkedAt:Number(cache?.checked_at??0),lastSuccessAt:Number(cache?.last_success_at??0),upstreamStatus:cache?.upstream_status??null},games};
 });
 return {mode:'catalogue-only',playable:false,syncIntervalSeconds:ttl,providers:results.map(x=>x.provider),games:results.flatMap(x=>x.games)};
}
export async function cachedGameArtwork(c:Pick<SyncContext,'db'>,provider:string,gameCode:string,profileId?:string){
 const source=selectProfileSource(provider,profileId)??(!profileId?gameSources.find(s=>s.id===provider):null);if(!source)return null;
 const cache=await c.db.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').bind(sourceCacheKey(source)).first<{games_json:string}>();
 const game=cacheGames(cache?.games_json).find(g=>g.gameCode===gameCode);return approvedArtworkUrl(source,game?.artworkSource);
}
