import {directCatalogueConfigured,readDirectCatalogue,CatalogueReadError,type DirectCatalogueConfig} from './direct-game-catalogues.ts';
type SyncContext=DirectCatalogueConfig&{db:D1Database;gameGatewayUrl?:string;gameGatewayFetch?:typeof fetch;gameSyncNow?:()=>number};
type Source={direct?:boolean;id:string;name:string;path:string;shape:'mega'|'normalized'|'evo';imageHost?:string};
type Game={provider:string;providerName:string;gameCode:string;name:string;nameZh:string;category:string;imageUrl:string|null;maintenance:boolean;playable:false;artworkSource?:string};
type Cache={provider_id:string;status:string;games_json:string;checked_at:number;last_success_at:number;lease_until:number;upstream_status:number|null;complete:number};
const gateway='https://master7-integration-gateway.onrender.com';
const ttl=300,leaseSeconds=35,maxGames=2000;
export const gameSources:readonly Source[]=[
 {id:'megah5',name:'MegaH5',path:'/providers/megah5/games',shape:'mega',imageHost:'gth.megah5.com'},
 {id:'jili',name:'JILI',path:'/providers/jili/games?account=1to1',shape:'normalized'},
 {id:'918kissh5',name:'918KISS H5',path:'/providers/918kissh5/games?account=normal',shape:'normalized',imageHost:'gth.kissh5.com'},
 {id:'evo888h5',name:'EVO888H5',path:'/providers/evo888h5/games',shape:'evo',imageHost:'backendapi.evo888h5.com'},
 {id:'epicwin',name:'EPICWIN',path:'/providers/epicwin/games?account=normal',shape:'normalized'},
 {id:'venus',name:'VENUS',path:'/providers/venus/games',shape:'normalized'},
 {id:'clotplay',name:'CLOTPLAY',path:'/providers/clotplay/games',shape:'normalized'},
];
const directSources:readonly Source[]=[{id:'rectangle',name:'RECTANGLE',path:'',shape:'normalized',direct:true},{id:'godeezone',name:'精选游戏',path:'',shape:'normalized',direct:true}];
const text=(value:unknown,max=160)=>typeof value==='string'?value.trim().slice(0,max):typeof value==='number'&&Number.isFinite(value)?String(value).slice(0,max):'';
function configured(value?:string){try{const u=new URL(value??'');return u.origin===gateway&&u.pathname==='/'&&!u.search&&!u.hash&&!u.username&&!u.password;}catch{return false;}}
export function approvedArtworkUrl(source:Source,value:unknown){
 try{const u=new URL(String(value));const path=source.id==='evo888h5'?/^\/slots\/cover-img\/[A-Za-z0-9_-]+\.(?:png|webp|jpe?g)$/.test(u.pathname):u.pathname.startsWith('/thumbs/');return u.protocol==='https:'&&u.hostname===source.imageHost&&path&&!u.port&&!u.search&&!u.hash&&!u.username&&!u.password?u.href:null;}catch{return null;}
}
function normalize(source:Source,rows:any[]){
 const seen=new Set<string>();
 return rows.slice(0,maxGames).map((g:any):Game|null=>{
  if(!g||typeof g!=='object'||Array.isArray(g))return null;
  const mega=source.shape==='mega',evo=source.shape==='evo';
  const gameCode=text(mega?g.GameCode??g.GameId:evo?g.gameid:g.gameCode,100);
  if(!gameCode||/[\u0000-\u001f\u007f]/.test(gameCode)||seen.has(gameCode))return null;seen.add(gameCode);
  const artwork=approvedArtworkUrl(source,mega?g.ImageUrl:evo?g.thumbnail:g.imageUrl);
  const imageUrl=artwork?`/api/game-art?provider=${source.id}&gameCode=${encodeURIComponent(gameCode)}`:source.id==='jili'?'/assets/providers/jili.webp':source.id==='evo888h5'?'/assets/providers/evo888h5.webp':source.id==='rectangle'?'/assets/providers/rectangle.webp':source.id==='godeezone'?'/assets/seven-emblem.png':null;
  return {provider:source.id,providerName:source.id==='godeezone'?text(g.providerName)||source.name:source.name,gameCode,name:text(mega?g.GameName??g.OtherName:evo?g.title??g.name:g.name)||gameCode,nameZh:text(g.nameZh??(mega?g.OtherName:'')),category:evo?'SLOT':text(mega?g.GameType:g.category,40),imageUrl,maintenance:mega?g.Maintenance===true||g.Maintenance===1||g.Maintenance==='true'||g.Maintenance==='1':g.maintenance===true,playable:false,...(source.id==='evo888h5'&&artwork?{artworkSource:artwork}:{})};
 }).filter((g):g is Game=>g!==null);
}
async function boundedJson(response:Response){
 if(!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')??''))throw Error('INVALID_CONTENT_TYPE');
 const reader=response.body?.getReader();if(!reader)throw Error('EMPTY_RESPONSE');let size=0;const parts:Uint8Array[]=[];
 for(;;){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>2*1024*1024){await reader.cancel();throw Error('RESPONSE_TOO_LARGE');}parts.push(next.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}const data=JSON.parse(new TextDecoder().decode(bytes));if(!data||typeof data!=='object'||Array.isArray(data))throw Error('INVALID_RESPONSE');return data;
}
function cacheGames(value:unknown):Game[]{try{const rows=JSON.parse(String(value));return Array.isArray(rows)?rows.slice(0,maxGames):[];}catch{return [];}}
async function synchronizeSource(c:SyncContext,source:Source,force:boolean,time:number){
 const claim=await c.db.prepare(`INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,lease_until,complete)
   VALUES(?,'unavailable','[]',0,0,?,0)
   ON CONFLICT(provider_id) DO UPDATE SET lease_until=excluded.lease_until
   WHERE game_catalogue_cache.lease_until<=? AND game_catalogue_cache.checked_at<=?
   RETURNING provider_id`).bind(source.id,time+leaseSeconds,time,time-(force?5:ttl)).first();
 if(!claim)return;
 const fetcher=c.gameGatewayFetch??fetch;let status='unavailable',upstream:number|null=null,complete=false;
 try{
  const direct=source.direct?await readDirectCatalogue(c,source.id,time):null;
  const response=direct?Response.json({games:direct.games,complete:direct.complete,upstreamStatus:200}):await fetcher(gateway+source.path,{method:'GET',headers:{Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(10000)});
  const data=await boundedJson(response);const code=Number(data.upstreamStatus);if(Number.isInteger(code)&&code>=100&&code<600)upstream=code;
  if(!response.ok){status='blocked';return;}
  const rows=source.shape==='mega'?data.result?.Game:source.shape==='evo'?data.result?.data:data.games;
  if(!Array.isArray(rows)){status='unavailable';return;}
  if(source.shape==='mega'&&Number(data.result?.Status)!==200||source.shape==='evo'&&Number(data.result?.code)!==0){status='blocked';return;}
  const games=normalize(source,rows);complete=data.complete!==false&&rows.length<=maxGames&&!(source.id==='clotplay'&&Number(data.pagination?.last_page)>1);
  // An empty success replaces the previous catalogue intentionally; transport
  // and protocol failures retain the last good snapshot for a stable lobby.
  await c.db.prepare(`UPDATE game_catalogue_cache SET games_json=?,status=?,checked_at=?,last_success_at=?,upstream_status=?,complete=?,lease_until=0 WHERE provider_id=? AND lease_until=?`)
   .bind(JSON.stringify(games),games.length?'available':'empty',time,time,upstream,complete?1:0,source.id,time+leaseSeconds).run();
  if(source.direct&&games.length)await c.db.prepare("INSERT INTO providers(id,name,category,symbol,visible) VALUES(?,?,'supplier',?,1) ON CONFLICT(id) DO NOTHING").bind(source.id,source.name,source.id==='rectangle'?'RG':'M7').run();
  status='saved';
 }catch(error){status='unavailable';if(error instanceof CatalogueReadError){upstream=error.upstreamStatus;status=upstream&&upstream>=400?'blocked':'unavailable';}}
 finally{
  if(status!=='saved')await c.db.prepare('UPDATE game_catalogue_cache SET status=?,checked_at=?,upstream_status=?,lease_until=0 WHERE provider_id=? AND lease_until=?').bind(status,time,upstream,source.id,time+leaseSeconds).run();
 }
}
export async function getGameCatalogue(c:SyncContext,options:{force?:boolean}={}){
 const direct=directSources.filter(source=>directCatalogueConfigured(c,source.id));
 if(!configured(c.gameGatewayUrl)&&!direct.length)return {mode:'catalogue-only',playable:false,providers:gameSources.map(s=>({id:s.id,name:s.name,status:'not_configured',count:0,catalogueSynced:false,launchVerified:false,walletVerified:false})),games:[]};
 const sources=[...(configured(c.gameGatewayUrl)?gameSources:[]),...direct];
 const time=Math.floor(c.gameSyncNow?.()??Date.now()/1000);
 await Promise.all(sources.map(source=>synchronizeSource(c,source,!!options.force,time)));
 const rows=(await c.db.prepare('SELECT * FROM game_catalogue_cache').all<Cache>()).results??[];
 const results=sources.map(source=>{
  const cache=rows.find(row=>row.provider_id===source.id);const saved=cacheGames(cache?.games_json),stale=cache?.status!=='available'&&cache?.status!=='empty';
  const games=saved.map(entry=>{const game={...entry};delete game.artworkSource;return {...game,...(stale?{maintenance:true}:{}),playable:false as const};});
  return {provider:{id:source.id,name:source.name,status:cache?.status??'unavailable',count:games.length,catalogueSynced:games.length>0&&cache?.complete===1,connectionVerified:cache?.status==='available',launchVerified:false,walletVerified:false,complete:cache?.complete===1,stale,checkedAt:Number(cache?.checked_at??0),lastSuccessAt:Number(cache?.last_success_at??0),upstreamStatus:cache?.upstream_status??null},games};
 });
 return {mode:'catalogue-only',playable:false,syncIntervalSeconds:ttl,providers:results.map(x=>x.provider),games:results.flatMap(x=>x.games)};
}
export async function cachedGameArtwork(c:Pick<SyncContext,'db'>,provider:string,gameCode:string){
 const source=gameSources.find(s=>s.id===provider);if(!source)return null;
 const cache=await c.db.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').bind(provider).first<{games_json:string}>();
 const game=cacheGames(cache?.games_json).find(g=>g.gameCode===gameCode);return approvedArtworkUrl(source,game?.artworkSource);
}
