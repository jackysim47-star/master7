import {providerWalletRiskFreeSql} from './provider-wallet-consistency.ts';
import {manualPayoutEvidenceSql} from './manual-bank-evidence.ts';
import {genericGameWalletRiskFreeSql} from './game-wallet-consistency.ts';

/** Per-member transactional guard for new wallet commitments and risk changes.
 * Callers MUST put these statements first in the SAME db.batch as every write.
 * External calls happen only after the transaction's committed result is read.
 */
type GuardReservation={userId:string;kind:'withdrawal'|'game';referenceId:string;amountMinor:string;createdAt:number};
type GuardLaunch={userId:string;walletSessionId:string;gameCode:string;operationId:string;createdAt:number};

export function walletGuardStatements(db:D1Database,userId:string){
 return [
  db.prepare('INSERT INTO member_wallet_guards(user_id,revision) VALUES(?,0) ON CONFLICT(user_id) DO NOTHING').bind(userId),
  db.prepare('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=?').bind(userId),
 ];
}

// The static expressions below intentionally mirror withdrawalWalletState.
// m.id is a trusted SQL alias, never caller-provided text.
const noDigits=Array.from('0123456789').reduce((sql,digit)=>`REPLACE(${sql},'${digit}','')`,'p.provider_reference');
const referenceValid=`(${manualPayoutEvidenceSql} OR (p.provider_id='vpay' AND p.provider_reference=p.id) OR (p.provider_id='gspay' AND LENGTH(p.provider_reference) BETWEEN 1 AND 40 AND SUBSTR(p.provider_reference,1,1)<>'0' AND ${noDigits}=''))`;
export const walletRiskFreeSql=`
 ${genericGameWalletRiskFreeSql}
 AND ${providerWalletRiskFreeSql}
 AND
 NOT EXISTS (SELECT 1 FROM deposit_orders o JOIN wallet_ledger l ON l.order_id=o.id WHERE (o.user_id=m.id OR l.user_id=m.id) AND o.status='review' AND l.account_code='member')
 AND NOT EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.user_id=m.id AND s.wallet_mode='transfer' AND s.status IN ('prepared','launching','active','settling','unknown','review') AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.user_id=s.user_id AND r.kind='game' AND r.reference_id=s.id))
 AND NOT EXISTS (SELECT 1 FROM game_wallet_sessions s LEFT JOIN game_wallet_ledger l ON l.session_id=s.id WHERE (s.user_id=m.id OR l.user_id=m.id) AND ((s.status='settled' AND (s.amount_returned_minor IS NULL OR l.id IS NULL OR l.user_id<>s.user_id OR l.account_code<>'game_result' OR l.currency<>'MYR' OR l.amount_minor<>s.amount_returned_minor-s.amount_out_minor)) OR (s.status<>'settled' AND l.id IS NOT NULL)))
 AND NOT EXISTS (SELECT 1 FROM megah5_launch_operations o LEFT JOIN game_wallet_sessions s ON s.id=o.wallet_session_id LEFT JOIN wallet_reservations r ON r.kind='game' AND r.reference_id=o.wallet_session_id WHERE (o.user_id=m.id OR s.user_id=m.id) AND o.state<>'closed' AND (s.id IS NULL OR s.user_id<>o.user_id OR s.game_code<>o.game_code OR s.status<>'active' OR r.user_id IS NULL OR r.user_id<>s.user_id OR r.amount_minor<>s.amount_out_minor))
 AND NOT EXISTS (SELECT 1 FROM withdrawal_requests w LEFT JOIN provider_payouts p ON p.withdrawal_id=w.id LEFT JOIN wallet_reservations r ON r.kind='withdrawal' AND r.reference_id=w.id WHERE w.user_id=m.id AND (
  p.id IS NULL OR (p.id IS NOT NULL AND (p.provider_id<>w.provider_id OR p.request_key<>w.request_key OR p.amount_minor<>w.amount_minor OR p.currency<>w.currency))
  OR (r.user_id IS NOT NULL AND (r.user_id<>w.user_id OR r.amount_minor<>w.amount_minor))
  OR (w.status IN ('pending','approved','processing') AND (r.user_id IS NULL OR r.user_id<>w.user_id OR r.amount_minor<>w.amount_minor))
  OR (p.id IS NOT NULL AND p.status='review')
  OR (p.id IS NOT NULL AND p.status='prepared' AND (p.create_outcome<>'not_submitted' OR p.provider_reference IS NOT NULL))
  OR (p.id IS NOT NULL AND p.status='submitting' AND p.create_outcome<>'in_flight')
  OR (w.status='paid' AND (p.id IS NULL OR p.status<>'succeeded' OR p.create_outcome<>'accepted' OR COALESCE(p.last_error_code,'')<>'' OR NOT COALESCE(${referenceValid},FALSE)))
  OR (p.id IS NOT NULL AND w.status IN ('rejected','cancelled') AND NOT (p.status='failed' AND p.create_outcome='not_submitted' AND p.provider_reference IS NULL AND SUBSTR(COALESCE(p.last_error_code,''),1,13)='owner_cancel_'))
  OR (p.id IS NOT NULL AND w.status IN ('pending','approved','processing') AND p.status IN ('succeeded','failed','reversed'))))
 AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.user_id=m.id AND r.kind='withdrawal' AND NOT EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.id=r.reference_id AND w.user_id=r.user_id AND w.amount_minor=r.amount_minor AND w.currency='MYR'))`;
export const walletAvailableSql=`(
 COALESCE((SELECT SUM(member.amount_minor) FROM wallet_ledger member JOIN deposit_orders orders ON orders.id=member.order_id AND orders.user_id=member.user_id JOIN wallet_ledger clearing ON clearing.order_id=member.order_id AND clearing.account_code='provider_clearing' WHERE member.user_id=m.id AND member.account_code='member' AND member.currency='MYR' AND orders.status='credited' AND orders.currency='MYR' AND member.amount_minor=orders.amount_minor AND clearing.user_id=orders.user_id AND clearing.currency='MYR' AND clearing.amount_minor=-orders.amount_minor),0)
 + COALESCE((SELECT SUM(l.amount_minor) FROM game_wallet_ledger l JOIN game_wallet_sessions s ON s.id=l.session_id AND s.user_id=l.user_id WHERE l.user_id=m.id AND s.status='settled' AND s.amount_returned_minor IS NOT NULL AND l.account_code='game_result' AND l.currency='MYR' AND l.amount_minor=s.amount_returned_minor-s.amount_out_minor),0)
 - COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=m.id AND status='paid' AND currency='MYR'),0)
 - COALESCE((SELECT SUM(amount_minor) FROM withdrawal_requests WHERE user_id=m.id AND status IN ('pending','approved','processing') AND currency='MYR'),0)
 - COALESCE((SELECT SUM(amount_out_minor) FROM game_wallet_sessions WHERE user_id=m.id AND status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')),0)
 - COALESCE((SELECT SUM(r.amount_minor) FROM wallet_reservations r WHERE r.user_id=m.id AND r.kind='game' AND (EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.id=r.reference_id AND s.user_id=r.user_id) OR NOT EXISTS (SELECT 1 FROM game_wallet_sessions g WHERE g.id=r.reference_id AND g.user_id=r.user_id AND g.status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')))),0)
)`;

/** Check within a batch after walletGuardStatements; meta.changes=1 means allowed. */
export function walletGuardedRiskCheck(db:D1Database,userId:string){
 return db.prepare(`UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=? AND EXISTS (SELECT 1 FROM (SELECT ? AS id) m WHERE ${walletRiskFreeSql})`).bind(userId,userId);
}

/** Claim exactly one provider launch while the same member guard is held. */
export function walletGuardedMegaLaunch(db:D1Database,input:GuardLaunch){
 return db.prepare(`WITH member AS (SELECT ? AS id)
 INSERT INTO megah5_launch_operations(id,wallet_session_id,user_id,game_code,state,created_at,updated_at,last_error)
 SELECT ?,s.id,s.user_id,s.game_code,'launching',?,? ,''
 FROM member m JOIN member_wallet_guards g ON g.user_id=m.id
 JOIN game_wallet_sessions s ON s.user_id=m.id
 JOIN wallet_reservations r ON r.user_id=s.user_id AND r.kind='game' AND r.reference_id=s.id AND r.amount_minor=s.amount_out_minor
 WHERE s.id=? AND s.game_code=? AND s.status='active' AND s.provider='megah5' AND ${walletRiskFreeSql}
 ON CONFLICT(wallet_session_id) DO NOTHING`)
 .bind(input.userId,input.operationId,input.createdAt,input.createdAt,input.walletSessionId,input.gameCode);
}

/** Authorize a zero-balance game launch only while no other funds are reserved. */
export function walletGuardedEmptyGameCheck(db:D1Database,userId:string){
 return db.prepare(`UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=? AND EXISTS (SELECT 1 FROM (SELECT ? AS id) m WHERE ${walletRiskFreeSql} AND ${walletAvailableSql}=0
 AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.user_id=m.id)
 AND NOT EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.user_id=m.id AND w.status IN ('pending','approved','processing'))
 AND NOT EXISTS (SELECT 1 FROM game_wallet_sessions s WHERE s.user_id=m.id AND s.status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review'))
 AND NOT EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.user_id=m.id AND s.status IN ('prepared','launching','active','settling','unknown','review')))`)
 .bind(userId,userId);
}

/** Must be immediately preceded by walletGuardStatements in the same batch. */
export function walletGuardedReservation(db:D1Database,input:GuardReservation){
 if(!/^[1-9]\d{0,18}$/.test(input.amountMinor))throw new Error('Positive integer minor amount is required');
 return db.prepare(`WITH member AS (SELECT ? AS id)
 INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at)
 SELECT m.id,?,?,CAST(? AS BIGINT),? FROM member m JOIN member_wallet_guards g ON g.user_id=m.id
 WHERE ${walletRiskFreeSql} AND ${walletAvailableSql}${input.kind==='game'?'=':'>='}CAST(? AS BIGINT)
 AND NOT EXISTS (SELECT 1 FROM wallet_reservations r WHERE r.user_id=m.id)
 AND NOT EXISTS (SELECT 1 FROM withdrawal_requests w WHERE w.user_id=m.id AND w.status IN ('pending','approved','processing'))
 AND NOT EXISTS (SELECT 1 FROM game_wallet_sessions s WHERE s.user_id=m.id AND s.status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review'))
 AND NOT EXISTS (SELECT 1 FROM game_provider_sessions s WHERE s.user_id=m.id AND s.status IN ('prepared','launching','active','settling','unknown','review'))`)
 .bind(input.userId,input.kind,input.referenceId,input.amountMinor,input.createdAt,input.amountMinor);
}
