import {GAME_PROVIDER_IDS,GAME_PROVIDER_NAMES} from './game-ranking.ts';

export class EngagementError extends Error{
 status:number;
 constructor(status:number,message:string){super(message);this.status=status;}
}

export const ENGAGEMENT_SETTING_ID='engagement_program_v1';
export const TOURNAMENT_CADENCES=['weekly','monthly'] as const;
export const TOURNAMENT_CATEGORIES=['slot','live','fish','sport'] as const;
export const DRAW_SCHEDULES=['daily','weekly','monthly','manual'] as const;

export type TournamentCadence=typeof TOURNAMENT_CADENCES[number];
export type TournamentCategory=typeof TOURNAMENT_CATEGORIES[number];
export type DrawSchedule=typeof DRAW_SCHEDULES[number];
export type TournamentDraft={
 enabled:boolean;
 title:string;
 cadence:TournamentCadence;
 category:TournamentCategory;
 startsAt:string|null;
 endsAt:string|null;
 eligibilityNote:string;
 prizeNote:string;
};
export type DrawDraft={
 enabled:boolean;
 title:string;
 schedule:DrawSchedule;
 startsAt:string|null;
 endsAt:string|null;
 entryNote:string;
 prizeNote:string;
};
export type PersonalizedLobbyConfig={enabled:boolean;ownerCuratedProviders:string[];maxItems:number};
export type NotificationCenterConfig={enabled:boolean;tickets:boolean;financial:boolean;systemStatus:boolean;sound:boolean};
export type EngagementProgram={
 version:1;
 enabled:boolean;
 tournament:TournamentDraft;
 jackpot:DrawDraft;
 luckyDraw:DrawDraft;
 personalizedLobby:PersonalizedLobbyConfig;
 notificationCenter:NotificationCenterConfig;
};
type StoredEngagementProgram=EngagementProgram&{updatedAt:number;updatedBy:string};

const PROGRAM_KEYS=['version','enabled','tournament','jackpot','luckyDraw','personalizedLobby','notificationCenter'] as const;
const TOURNAMENT_KEYS=['enabled','title','cadence','category','startsAt','endsAt','eligibilityNote','prizeNote'] as const;
const DRAW_KEYS=['enabled','title','schedule','startsAt','endsAt','entryNote','prizeNote'] as const;
const PERSONALIZED_KEYS=['enabled','ownerCuratedProviders','maxItems'] as const;
const NOTIFICATION_KEYS=['enabled','tickets','financial','systemStatus','sound'] as const;
const PROVIDERS=new Set<string>(GAME_PROVIDER_IDS);
const AUTOMATION={automaticRewards:false,walletCredit:false,moneyMovement:false} as const;

function object(value:unknown,label:string):Record<string,unknown>{
 if(!value||typeof value!=='object'||Array.isArray(value))throw new EngagementError(400,`Invalid ${label}`);
 return value as Record<string,unknown>;
}
function exactKeys(value:Record<string,unknown>,allowed:readonly string[],label:string){
 const accepted=new Set(allowed),unknown=Object.keys(value).find(key=>!accepted.has(key)),missing=allowed.find(key=>!Object.hasOwn(value,key));
 if(unknown)throw new EngagementError(400,`Unknown ${label} field: ${unknown}`);
 if(missing)throw new EngagementError(400,`Missing ${label} field: ${missing}`);
}
function bool(value:unknown,label:string){if(typeof value!=='boolean')throw new EngagementError(400,`Invalid ${label}`);return value;}
function text(value:unknown,label:string,min:number,max:number){
 if(typeof value!=='string'||value.trim()!==value||value.length<min||value.length>max)throw new EngagementError(400,`Invalid ${label}`);
 return value;
}
function choice<T extends string>(value:unknown,allowed:readonly T[],label:string):T{
 if(typeof value!=='string'||!allowed.includes(value as T))throw new EngagementError(400,`Invalid ${label}`);
 return value as T;
}
function timestamp(value:unknown,label:string){
 if(value===null)return null;
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)||!Number.isFinite(Date.parse(value))||new Date(value).toISOString()!==value)throw new EngagementError(400,`Invalid ${label}`);
 return value;
}
function period(startsAt:unknown,endsAt:unknown,label:string){
 const start=timestamp(startsAt,`${label} start`),end=timestamp(endsAt,`${label} end`);
 if((start===null)!==(end===null))throw new EngagementError(400,`${label} start and end must both be set or both be empty`);
 if(start!==null&&end!==null&&Date.parse(end)<=Date.parse(start))throw new EngagementError(400,`${label} end must be after its start`);
 return {startsAt:start,endsAt:end};
}
function parseTournament(input:unknown):TournamentDraft{
 const value=object(input,'tournament');exactKeys(value,TOURNAMENT_KEYS,'tournament');const dates=period(value.startsAt,value.endsAt,'tournament');
 return {enabled:bool(value.enabled,'tournament state'),title:text(value.title,'tournament title',2,80),cadence:choice(value.cadence,TOURNAMENT_CADENCES,'tournament cadence'),category:choice(value.category,TOURNAMENT_CATEGORIES,'tournament category'),...dates,eligibilityNote:text(value.eligibilityNote,'tournament eligibility note',0,300),prizeNote:text(value.prizeNote,'tournament prize note',0,300)};
}
function parseDraw(input:unknown,label:string):DrawDraft{
 const value=object(input,label);exactKeys(value,DRAW_KEYS,label);const dates=period(value.startsAt,value.endsAt,label);
 return {enabled:bool(value.enabled,`${label} state`),title:text(value.title,`${label} title`,2,80),schedule:choice(value.schedule,DRAW_SCHEDULES,`${label} schedule`),...dates,entryNote:text(value.entryNote,`${label} entry note`,0,300),prizeNote:text(value.prizeNote,`${label} prize note`,0,300)};
}
function providers(value:unknown){
 if(!Array.isArray(value)||value.some(item=>typeof item!=='string'))throw new EngagementError(400,'Invalid owner-curated providers');
 const result=value as string[];
 if(result.length>GAME_PROVIDER_IDS.length||new Set(result).size!==result.length||result.some(id=>!PROVIDERS.has(id)))throw new EngagementError(400,'Owner-curated providers must be unique known platform IDs');
 return [...result];
}
function integer(value:unknown,label:string,min:number,max:number){if(!Number.isInteger(value)||Number(value)<min||Number(value)>max)throw new EngagementError(400,`Invalid ${label}`);return Number(value);}
function parsePersonalized(input:unknown):PersonalizedLobbyConfig{
 const value=object(input,'personalized lobby');exactKeys(value,PERSONALIZED_KEYS,'personalized lobby');
 return {enabled:bool(value.enabled,'personalized lobby state'),ownerCuratedProviders:providers(value.ownerCuratedProviders),maxItems:integer(value.maxItems,'personalized lobby item limit',1,GAME_PROVIDER_IDS.length)};
}
function parseNotifications(input:unknown):NotificationCenterConfig{
 const value=object(input,'notification center');exactKeys(value,NOTIFICATION_KEYS,'notification center');
 return {enabled:bool(value.enabled,'notification center state'),tickets:bool(value.tickets,'ticket notifications'),financial:bool(value.financial,'financial notifications'),systemStatus:bool(value.systemStatus,'system status notifications'),sound:bool(value.sound,'notification sound')};
}

export function defaultEngagementProgram():EngagementProgram{
 return {
  version:1,enabled:false,
  tournament:{enabled:false,title:'MASTER7 Tournament',cadence:'weekly',category:'slot',startsAt:null,endsAt:null,eligibilityNote:'',prizeNote:''},
  jackpot:{enabled:false,title:'MASTER7 Jackpot',schedule:'weekly',startsAt:null,endsAt:null,entryNote:'',prizeNote:''},
  luckyDraw:{enabled:false,title:'MASTER7 Lucky Draw',schedule:'monthly',startsAt:null,endsAt:null,entryNote:'',prizeNote:''},
  personalizedLobby:{enabled:false,ownerCuratedProviders:[],maxItems:12},
  notificationCenter:{enabled:false,tickets:false,financial:false,systemStatus:false,sound:false},
 };
}

export function validateEngagementProgram(input:unknown):EngagementProgram{
 const value=object(input,'engagement program');exactKeys(value,PROGRAM_KEYS,'engagement program');
 if(value.version!==1)throw new EngagementError(400,'Unsupported engagement program version');
 return {version:1,enabled:bool(value.enabled,'engagement program state'),tournament:parseTournament(value.tournament),jackpot:parseDraw(value.jackpot,'jackpot'),luckyDraw:parseDraw(value.luckyDraw,'lucky draw'),personalizedLobby:parsePersonalized(value.personalizedLobby),notificationCenter:parseNotifications(value.notificationCenter)};
}

export async function loadEngagementProgram(db:D1Database):Promise<{configured:boolean;program:EngagementProgram;updatedAt:number|null;updatedBy:string|null}>{
 const row=await db.prepare('SELECT value FROM settings WHERE id=?').bind(ENGAGEMENT_SETTING_ID).first<{value:string}>();
 if(!row)return {configured:false,program:defaultEngagementProgram(),updatedAt:null,updatedBy:null};
 let stored:Record<string,unknown>;try{stored=object(JSON.parse(row.value),'stored engagement program');}catch{throw new EngagementError(503,'Stored engagement program is invalid');}
 const allowed=[...PROGRAM_KEYS,'updatedAt','updatedBy'];if(Object.keys(stored).some(key=>!allowed.includes(key)))throw new EngagementError(503,'Stored engagement program is invalid');
 let program:EngagementProgram;try{program=validateEngagementProgram(Object.fromEntries(PROGRAM_KEYS.map(key=>[key,stored[key]])));}catch{throw new EngagementError(503,'Stored engagement program is invalid');}
 if(!Number.isSafeInteger(stored.updatedAt)||Number(stored.updatedAt)<0||typeof stored.updatedBy!=='string'||stored.updatedBy.length<1||stored.updatedBy.length>128)throw new EngagementError(503,'Stored engagement program is invalid');
 return {configured:true,program,updatedAt:Number(stored.updatedAt),updatedBy:stored.updatedBy};
}

function readiness(program:EngagementProgram){
 const published=(enabled:boolean)=>program.enabled&&enabled,notificationPublished=published(program.notificationCenter.enabled),notificationSources=[{id:'tickets',enabled:notificationPublished&&program.notificationCenter.tickets,source:'tickets_and_replies',scope:'member_scoped'},{id:'financial',enabled:notificationPublished&&program.notificationCenter.financial,source:'deposit_and_withdrawal_records',scope:'member_scoped'},{id:'system_status',enabled:notificationPublished&&program.notificationCenter.systemStatus,source:'existing_readiness_status',scope:'public_status'}];
 return {
  tournament:{published:published(program.tournament.enabled),scoreSource:'not_connected',wagerSource:'not_connected',leaderboard:[],awardsEnabled:false,walletCredit:false},
  jackpot:{published:published(program.jackpot.enabled),contributionSource:'not_connected',poolAmount:null,drawEnabled:false,randomDrawSource:'not_connected',auditSource:'not_connected',walletCredit:false},
  luckyDraw:{published:published(program.luckyDraw.enabled),entrySource:'not_connected',poolAmount:null,drawEnabled:false,randomDrawSource:'not_connected',auditSource:'not_connected',walletCredit:false},
  personalizedLobby:{published:published(program.personalizedLobby.enabled),sources:['local_favorites','local_recent','owner_curated'],storage:'member_device',sensitiveWageringInference:false,serverProfile:false},
  notificationCenter:{published:notificationPublished,model:'existing_records_only',copiesRecords:false,sources:notificationSources,sound:notificationPublished&&program.notificationCenter.sound&&notificationSources.some(source=>source.enabled),deliveryAutomation:false},
  ...AUTOMATION,
 };
}
function publicProgram(program:EngagementProgram):EngagementProgram{
 const defaults=defaultEngagementProgram(),published=(enabled:boolean)=>program.enabled&&enabled;
 return {
  version:1,
  enabled:program.enabled,
  tournament:published(program.tournament.enabled)?{...program.tournament}:defaults.tournament,
  jackpot:published(program.jackpot.enabled)?{...program.jackpot}:defaults.jackpot,
  luckyDraw:published(program.luckyDraw.enabled)?{...program.luckyDraw}:defaults.luckyDraw,
  personalizedLobby:published(program.personalizedLobby.enabled)?{...program.personalizedLobby,ownerCuratedProviders:[...program.personalizedLobby.ownerCuratedProviders]}:defaults.personalizedLobby,
  notificationCenter:published(program.notificationCenter.enabled)?{...program.notificationCenter}:defaults.notificationCenter,
 };
}
function adminResponse(loaded:Awaited<ReturnType<typeof loadEngagementProgram>>){return {...loaded,storage:ENGAGEMENT_SETTING_ID,providers:GAME_PROVIDER_IDS.map(id=>({id,name:GAME_PROVIDER_NAMES[id]})),readiness:readiness(loaded.program),...AUTOMATION};}
export async function getAdminEngagement(db:D1Database){return adminResponse(await loadEngagementProgram(db));}
export async function getPublicEngagement(db:D1Database){const loaded=await loadEngagementProgram(db),program=publicProgram(loaded.program);return {configured:loaded.configured,program,readiness:readiness(program),...AUTOMATION};}

export async function saveEngagementProgram(db:D1Database,ownerId:string,input:unknown,at=Math.floor(Date.now()/1000)){
 const outer=object(input,'engagement request'),candidate=Object.hasOwn(outer,'program')?(()=>{exactKeys(outer,['program'],'engagement request');return outer.program;})():outer,program=validateEngagementProgram(candidate),stored:StoredEngagementProgram={...program,updatedAt:at,updatedBy:ownerId};
 await db.batch([
  db.prepare('INSERT INTO settings(id,value) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind(ENGAGEMENT_SETTING_ID,JSON.stringify(stored)),
  db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),ownerId,'engagement_program_updated',JSON.stringify({version:1,enabled:program.enabled,modules:{tournament:program.tournament.enabled,jackpot:program.jackpot.enabled,luckyDraw:program.luckyDraw.enabled,personalizedLobby:program.personalizedLobby.enabled,notificationCenter:program.notificationCenter.enabled},automaticRewards:false,walletCredit:false}),at),
 ]);
 return {status:'ok',...adminResponse({configured:true,program,updatedAt:at,updatedBy:ownerId})};
}

function localProviderList(value:unknown){return Array.isArray(value)?value.filter((item):item is string=>typeof item==='string'&&PROVIDERS.has(item)):[];}
export function buildPersonalizedLobby(program:EngagementProgram,local:{favorites?:unknown;recent?:unknown}={}){
 if(!program.enabled||!program.personalizedLobby.enabled)return [];
 const ordered=[...localProviderList(local.favorites),...localProviderList(local.recent),...program.personalizedLobby.ownerCuratedProviders],result:{id:string;name:string;sources:string[]}[]=[],seen=new Map<string,{id:string;name:string;sources:string[]}>();
 for(const [source,items] of [['local_favorite',localProviderList(local.favorites)],['local_recent',localProviderList(local.recent)],['owner_curated',program.personalizedLobby.ownerCuratedProviders]] as const)for(const id of items){const found=seen.get(id);if(found){if(!found.sources.includes(source))found.sources.push(source);continue;}const item={id,name:GAME_PROVIDER_NAMES[id]??id,sources:[source]};seen.set(id,item);result.push(item);}
 return result.filter(item=>ordered.includes(item.id)).slice(0,program.personalizedLobby.maxItems);
}
