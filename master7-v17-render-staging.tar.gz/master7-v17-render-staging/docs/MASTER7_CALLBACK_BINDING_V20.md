# Payment acknowledgment and game response binding candidate .112

This local candidate builds on v19 `.111-wallet-guard`. It does not modify
production configuration, call payment services or certify live settlements.

## 1MPay

The authenticated callback binds order, customer, amount and transaction ID.
It acknowledges success only after an independent provider query is successful
and the current order and both MYR ledger legs are jointly verified. Pending,
review or inconsistent outcomes cannot produce a success ACK. Order creation
replay and refresh must not display credited without the same ledger binding.
The current non-success response is HTTP 503. The provider's retry policy and
precise production contract are not validated here; automatic redelivery must
not be assumed. Existing recovery flags and pending orders require review.

## MegaH5

The existing integration gateway returns `operation` and `referenceId` for
deposit/withdraw, and `operation=transfer_status` for status queries. The portal
requires these gateway fields to match; a mismatch is an unknown outcome and
keeps funds reserved for recovery. The status response does not echo a
reference at the envelope level. This does not establish the provider's live
close-session or in-flight-wager contract.

## GSPAY

All three formerly unguarded non-credited transitions to review now acquire
the member guard and bind the order owner. Even historical non-credited orders
may have a partial member ledger; a transition to review must serialize with
a new withdrawal or game reservation. No history is changed automatically.

## Operational boundary

Guard safety requires a rollout preventing old and new financial writers from
running concurrently. Verify recovery flags, existing transaction queues, and
backup/restore before deploying. Previously supplied credentials require
rotation through approved secret storage. These local tests do not establish
that 37 game providers, four deposit profiles or any payout work with real
money. The historic paid-but-not-credited transaction remains unidentified.
