# MASTER7 v153 provider catalogue safety release

Release: `17.0.0-selfbuilt.153-provider-catalogue-safety`

This release closes catalogue-boundary and reporting gaps across EPICWIN,
META GAMING, JDB and JILI.

- EPICWIN Normal MYR and Free MYR use independent request paths, cache keys,
  profile identities, account checks and currency checks.
- EPICWIN rejects malformed, duplicate and oversized catalogues as one unit.
  Unknown per-title availability remains maintenance and remote artwork is not
  exposed.
- META GAMING retains isolated Normal and Free Credit profiles. Unknown title
  availability remains suspended and unapproved artwork is withheld.
- JDB defaults a missing availability field to maintenance and withholds
  unapproved artwork.
- JILI's two implemented adapters are reported as awaiting their incomplete
  provider contract and production acceptance, rather than unimplemented.

Current supplier evidence remains blocked: META GAMING and EPICWIN return HTTP
403, while JDB returns provider status `9001`. The portal therefore exposes no
Play action for these profiles. No player, launch, wallet, transfer, settlement
or recovery request was added or enabled.

VPay, GSPAY, 1MPay, payment switches, credentials, service plans and DNS are
unchanged.
