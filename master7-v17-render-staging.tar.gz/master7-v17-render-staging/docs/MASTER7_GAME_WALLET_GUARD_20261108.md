# MASTER7 V17 · game wallet reservation guard

Candidate: `17.0.0-selfbuilt.104-game-wallet-guard`
Date: 2026-11-08
Status: local candidate; no production deployment or real-money acceptance.

## Issue and change

The shared member wallet uses `wallet_reservations`, while the existing stale
cleanup recognized only the older `game_wallet_sessions` table. A reservation
belonging to a newer `game_provider_sessions` row could therefore be deleted
and omitted from the member's held balance. This was a source-level finding;
no production incident or affected customer is asserted.

The wallet now counts newer-profile and unmatched game reservations as held.
Cleanup retains them even if a generic session is marked settled or failed;
future settlement must remove the reservation explicitly and atomically with
the verified ledger result. A reference that belongs to another member is not
treated as that member's session. An unmatched reservation remains held for
review. If old and new session IDs collide, the wallet conservatively holds
both amounts rather than understating the hold.

If an open generic transfer session has no matching reservation, the available
balance is reported as zero with `reconciliationRequired: true`; a new game or
withdrawal is blocked. The missing amount cannot be reconstructed from the
session alone and requires reconciliation.
The member wallet and withdrawal page show a reconciliation notice and hide
the unavailable balance while this condition is present.

Withdrawal submission and a new MegaH5 game check protected reservations
before initiating a payout or another game transfer. Existing MegaH5 session
recovery remains available. A stale legacy settled hold is released only if a
matching game result ledger exists; a confirmed legacy deposit failure can
also be released. No new generic settlement or release method is implemented.

The code requires migration `0110-game-provider-adapter-core`, which is part of
this candidate's Render startup migrations and database readiness gate. The
database migration and deployment must be reviewed in an isolated environment
before any production change.

## JDB and VENUS scope

This candidate includes the previous JDB protocol client and EliteHubz signing
helper. They remain disconnected from the customer game routes, reservation
creation, member wallet postings, callbacks and provider settlement. JDB and
VENUS are not verified for real play. See
`docs/MASTER7_JDB_ELITEHUBZ_PROTOCOL_20261108.md` for contract blockers.

## Verification boundary

Tests use local SQLite and simulated provider responses. They cover active,
unknown, terminal and unmatched holds; cross-member and ID collisions;
withdrawal and MegaH5 blocking; and legacy session settlement. A PostgreSQL
concurrency rehearsal, vendor UAT, real wallet reconciliation, backups and
rollback acceptance remain required before production use.

Full regression: 737/737 passed. Maintenance: 11/11; release probes: 16/16;
Render database adapter: 3/3. TypeScript, ESLint and the Render-target build
also passed.
