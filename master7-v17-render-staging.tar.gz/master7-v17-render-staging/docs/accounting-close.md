# MYT settled-cashflow close

MASTER7 reports settled cashflow: credited deposits minus paid withdrawals. It does not claim to be profit and excludes bonuses, commissions, game P&L, provider fees, refunds and operating expenses.

The existing Render web service starts an in-process catch-up scheduler. It checks every five minutes, begins closing after 00:05 MYT and catches up missing dates (up to 31 per pass). `accounting_job_runs.job_key` and the snapshot primary key make repeated or multi-instance calls safe. A successful day is stored in `accounting_daily_snapshots`; late settlement evidence and snapshot revisions are stored separately.

Set a random secret of at least 32 characters as `ACCOUNTING_JOB_TOKEN` on the existing web service. The protected endpoint is:

```
POST /api/internal/accounting-close
Authorization: Bearer $ACCOUNTING_JOB_TOKEN
Content-Type: application/json
{}
```

Manual backfill:

```
ACCOUNTING_CLOSE_BASE_URL=https://master7.best \
ACCOUNTING_JOB_TOKEN=... \
pnpm accounting:close -- --date 2026-11-05 --idempotency-key ops-2026-11-05-1
```

`render.cron.example.yaml` documents an optional independent 00:05 MYT Cron Job. It is deliberately not active; no paid Render resource is created. The web-service scheduler already provides catch-up. Readiness only turns green after the expected snapshot exists successfully, rather than merely because the reporting route exists.
