# MASTER7 META GAMING catalogue candidate

Date: 2026-11-10
Baseline: `17.0.0-selfbuilt.148-jili-transfer-wallet`
State: local candidate only; not deployed

## Scope

This candidate adds two independent, read-only META GAMING catalogue profiles:

| Portal profile | Gateway request | Portal balance class | Runtime adapter |
|---|---|---|---|
| `metagaming_normal_myr` | `GET /providers/metagaming/games?account=normal` | `cash` | `implemented · disabled pending acceptance` |
| `metagaming_free_myr` | `GET /providers/metagaming/games?account=free` | `free_credit` | `implemented · cash-ledger closed` |

The profiles have separate player namespaces, ledger namespaces and catalogue
cache keys. A successful normalized gateway response must identify the exact
`provider`, `account` and `currency` expected by the requested profile:

```json
{
  "provider": "metagaming",
  "account": "normal",
  "currency": "MYR",
  "games": []
}
```

Any metadata mismatch blocks the refresh and retains the previous snapshot in
maintenance state. Catalogue rows are always returned with `playable=false`.
There is no launch, wallet, transfer, settlement or recovery implementation in
this candidate, and neither profile can perform a funds operation.

## Artwork policy

The official META GAMING integration document describes `ImageUrl` and shows
only the template `https://<base-domain-url>/thumbs/Web/<GameCode>.png`. It
does not identify a concrete production thumbnail hostname. Remote META image
URLs are therefore rejected. Catalogue rows use the existing local
`/assets/providers/metagaming.webp` fallback until an official host or asset
manifest is supplied and reviewed.

## Legacy MegaH5 boundary

The existing `megah5` catalogue and `megah5_myr` profile are unchanged. The
available META GAMING document and credential attachment names do not prove
that legacy MegaH5 is the same merchant account or protocol. Renaming,
relabelling, enabling, or sharing a cache/player/ledger namespace would create
an unsafe mapping. Legacy MegaH5 therefore remains separate and fail-closed
under the existing production controls while its mapping remains ambiguous.

## Evidence boundary

Implementation used only the supplied offline META GAMING document and
existing repository artwork. No provider endpoint was called, no credential or
secret was added, and no deployment or environment configuration was changed.
This is catalogue contract work, not production provider acceptance.
