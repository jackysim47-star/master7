# MASTER7 customer withdrawal requests

Updated: 2026-11-05 MYT

## Delivered flow

1. An approved customer opens **Withdraw**.
2. The customer selects one of four separately recorded companies: VPay, GSPAY, 1MPAY or GSPAY+.
3. The customer selects a Malaysian bank and enters account-holder name, account number and an MYR amount.
4. The portal checks the available wallet amount, reserves the requested amount and creates one pending request.
5. The MASTER7 owner backoffice shows an immediate pending-request notice and the full request details.
6. The owner processes the request in the selected company's backoffice and updates MASTER7 through Approved, Processing, Paid or Rejected.
7. Rejected requests release the reserved amount. Paid requests reduce the member wallet once.

This release does not automatically submit a payout to a payment provider. That matches the owner's latest instruction: MASTER7 receives the request first, and the operator then processes it in the selected provider backoffice.

## Data protection

Bank account holder and account number are encrypted at rest with the server-only `WITHDRAWAL_DATA_KEY`. Customer history only returns the last four digits. Exports omit encrypted fields. The key is not included in source, reports or browser code.

## Verification

- Four independent provider choices and 18 Malaysian banks.
- Member-only, approved-account access with existing origin and CSRF controls.
- Available-balance and one-open-request checks.
- Owner-only full details and valid status transitions.
- Wallet hold, rejection release and paid deduction tests.
- Complete local suite: 87 passed, 0 failed, 0 skipped.
- JavaScript syntax and Render production build passed.
