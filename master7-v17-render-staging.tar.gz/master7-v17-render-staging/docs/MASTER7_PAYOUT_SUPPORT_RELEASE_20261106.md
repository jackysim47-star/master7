# MASTER7 `.69` Payout Safety and Support Release

更新时间：2026-11-06 21:09 MYT
版本：`17.0.0-selfbuilt.69-payout-safe-support`

## 本版完成

- VPay 健康状态现在使用 Gateway 远程配置验证，不再把已连接的充值错误报成未就绪。
- GSPAY Payout adapter 已实现建单、签名、回调、独立查单、幂等、钱包预留、失败释放、不确定状态恢复和后台记录。
- 并发出款使用数据库原子锁，任何时候只有一个请求可以调用厂家。网络超时后只查单，不重发出款。
- 前台提款公司由服务器能力动态生成，未完成配置的公司不会显示为可用。
- 内建中英双语客服已接入会员工单，可对充值、提款、游戏、福利和账户问题立即回复，并保留员工接手。
- `/health` 使用真实存款、提款、支付结算和游戏结算条件计算 `productionReady`，没有证据不会误打勾。

## 自动验证

- Portal 全套：238/238 通过。
- GSPAY Payout 专项：7/7 通过，全部使用本地合成厂家响应，没有发送真钱请求。
- TypeScript、ESLint、`git diff --check` 通过。
- Render SQL adapter 3/3 通过，Render production build 通过。

## 默认安全状态

GSPAY Payout 新建单开关默认关闭。当准确密钥、直接 callback、厂家 IP 白名单确认、完整银行对照及受控生产验收未完成时，系统会保持不可用状态。VPay 与 1MPay 提款仍因缺完整 payout 合约而关闭。本版没有进行任何真实充值或出款。

## 线上发布

- Publication commit：`01d36683a0fe2b6fca162321e8aa85e9dac1bce2`
- Render deploy：`dep-dbmt6jmc6qcc73cghapg`，`live`
- 上线完成：2026-11-06 21:19:03 MYT
- `/health` 与 `/api/version`：HTTP 200，`.69`，database ready
- VPay 与 1MPay Deposit：Active；MegaH5：liveReady
- GSPAY Deposit：Closed，credential contract incomplete
- 新实例 error/critical/fatal：0；request 5xx：0
