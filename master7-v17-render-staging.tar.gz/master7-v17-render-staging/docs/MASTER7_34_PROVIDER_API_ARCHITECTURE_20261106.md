# MASTER7 34 家供应商 API 架构核对（已脱敏）

日期：2026-11-06（MYT）
范围：用户提供的生产资料、RSG Hub 官方文档与当前 gateway 源码。
限制：本次没有调用任何生产厂家接口，没有创建玩家、启动游戏、转账或下注；没有把任何账号、密钥、DES 参数或后台密码写入本报告或源码。

## 结论

34 家供应商**不是一个可共用签名与钱包协议的 API**。现有资料显示至少存在二十多个独立 API 主机/协议家族。不能把一家供应商的 `gameId`、签名、玩家创建、启动或钱包流程复制给其余厂家。

目前能确认的共用家族只有一组：`ALLBET (AK)`、`QUICKSPIN (FI)`、`ASTAR (YX)`、`GFG/G4 (G4)`、`SA GAMING (SA)`、`GEMINI UPDOWN (MU)` 六份表格使用相同格式，并指向同一组 API/日志主机。六份资料都只有 `providerCode`、`operatorCode`、`secret_key`、`API_URL` 与 `LOG_URL` 等凭证字段，没有请求方法、签名公式、玩家/启动/钱包/回调 schema。因此它们可以规划成一个“336699 家族 adapter”，但在厂家提供完整 API 文档前不能安全实现或上线。

RSG Hub 是另一套完整而独立的协议。用户提供的 PDF 指向 RSG Hub production，并声明 transfer wallet 与 MYR。RSG 官方文档已足够建立 adapter 的离线实现和 contract tests，但该 PDF 没有说明它对应前台 34 项中的哪一个源码 ID；部署前必须由厂家确认映射，不能自行猜成 `gamitech`、`fuma` 或其他品牌。

其余代表性资料分别指向独立域名和独立后台，例如 AWC、EVO888H5、GAMEPLAY、LION KING、SUNCITY、PGSOFT、PS9、DRAGOONSOFT、JDB、BG、META GAMING、YL、FUNKY、SPADE GAMING、TURBO、CT855、PRAGMATIC PLAY、JOKER、CG、ATG、RECTANGLE、M8BET、COSMOPLAY。凭证存在只证明厂家发过账号资料，不证明请求合同、IP 白名单、钱包模式或生产验收已完成。

## RSG Hub 已核实的接口合同

官方资料：`https://docs.rsghub.dev/v1/transfer/en/`，读取日期 2026-11-06，文档版本 1.33.0。

- Production base：`https://api.rsghub.io`
- Transport：`POST /api/v1/<API name>`，`application/x-www-form-urlencoded`
- Body：单一 `Msg` 字段；内容为 JSON 经 DES-CBC + PKCS7 后再 Base64
- Headers：`X-API-ClientID`、`X-API-Signature`、`X-API-Timestamp`
- Signature：小写 MD5，输入顺序为 Client ID + Client Secret + Unix timestamp + 加密后的 Msg
- Response：DES-CBC/Base64 加密后的标准 envelope；解密后以 `ErrorCode === 0` 为成功
- 时间容差：官方说明超过约 30 秒可能返回解密/时间错误
- 钱包：transfer wallet；平台显式执行 deposit / withdraw / query

实现前台游戏所需的最小端点：

| 能力 | RSG endpoint | 必要字段（脱敏） |
|---|---|---|
| 建立玩家 | `WithBalance/Player/CreatePlayer` | SystemCode, WebId, UserId, Currency |
| 游戏目录 | `WithBalance/Game/GameListByCurrency` | SystemCode, Currency |
| 启动游戏 | `WithBalance/Player/GetURLToken` | SystemCode, WebId, UserId, UserName, GameId, Currency, Language, ExitAction |
| 启动大厅 | `WithBalance/Player/GetLobbyURLToken` | SystemCode, WebId, UserId, UserName, Currency, Language |
| 查询余额 | `WithBalance/Player/GetBalance` | SystemCode, WebId, UserId, Currency |
| 上分 | `WithBalance/Player/Deposit` | SystemCode, WebId, UserId, TransactionID, Currency, Balance |
| 下分 | `WithBalance/Player/Withdraw` | SystemCode, WebId, UserId, TransactionID, Currency, Balance |
| 补查转账 | `WithBalance/Player/GetTransactionResult` | SystemCode, TransactionID |
| 在线状态 | `WithBalance/Player/GetPlayerOnlineStatus` | SystemCode, WebId, UserId |
| 游戏记录 | `WithBalance/History/GetGameDetail` | SystemCode, WebId, GameType, TimeStart, TimeEnd |

RSG 的 `TransactionID` 必须由平台生成并永久唯一。官方错误码 `3014` 表示重复交易；网络结果不确定时应先调用转账结果查询，不能直接重新上分或下分。错误码 `3016` 表示玩家仍在游戏中而拒绝下分，退出结算必须进入待重试状态，不能直接把平台钱包余额改成成功。

## 34 家的推荐代码结构

### 1. 供应商注册表

建立唯一 registry；前台 34 个源码 ID、厂家产品代码和 adapter 名称必须一一对应。每项保存：

- `providerId`、厂家确认的 `productCode`、显示名称；
- 钱包模式：`transfer`、`seamless` 或 `unknown`；
- 能力：catalogue / player / launch / balance / transfer / callbacks / reports；
- MYR 支持、测试/生产环境、允许 IP 与验收状态；
- Render env prefix，只保存变量名称，绝不保存变量值。

未完成厂家映射或合同的项应显示 `contract_missing`，不能显示“已连接”或“可玩”。

### 2. Adapter 接口

每个协议家族实现相同的 server-side interface：

```text
catalogue(context)
ensurePlayer(context, member)
launch(context, member, game)
getBalance(context, member)
deposit(context, transfer)
withdraw(context, transfer)
queryTransfer(context, externalTransactionId)
verifyCallback(context, request)
reconcile(context, window)
```

其中 RSG Hub、336699 家族、AWC 及每个独立厂家分别实现 adapter。共用的是内部 interface 与账本状态机，不共用厂家签名、字段名或 endpoint。

### 3. Portal 到 Gateway 的统一路由

前台可以使用统一平台接口，但 gateway 必须按 registry 分派：

```text
GET  /platform/games/providers
GET  /platform/games/:provider/catalogue
POST /platform/games/:provider/player
POST /platform/games/:provider/launch
GET  /platform/games/:provider/balance
POST /platform/games/:provider/transfers
GET  /platform/games/:provider/transfers/:transactionId
POST /callbacks/games/:provider
```

客户端只能传平台的 `providerId` 与已登记的 `gameId`。厂家 base URL、凭证、签名与外部玩家 ID 全部只存在 server side。Gateway 必须拒绝未注册 provider、任意 URL、任意 method 与未登记游戏代码。

### 4. 钱包与幂等

统一账本至少需要：

- `provider_players`：内部会员与厂家玩家 ID 的固定映射；
- `provider_transfers`：唯一 `(provider_id, external_transaction_id)`；
- `provider_sessions`：启动与退出状态；
- `provider_callbacks`：原始 body hash、签名验证结果与处理结果；
- `provider_reconciliation_runs`：补查时间窗、差异和人工处理状态。

Transfer wallet 的正确流程是“平台预留 → 厂家请求 → 成功确认 → 平台记账”；超时进入 `unknown` 并补查。Seamless wallet 必须逐厂家实现 bet / settle / rollback / cancel 的签名和幂等，不能套用 transfer wallet。

### 5. 逐能力 readiness

每一家分别计算以下状态，不再使用一个全局 `connected` 灯：

```text
credentialsConfigured
ipWhitelistVerified
catalogueVerified
playerVerified
launchVerified
walletVerified
callbackVerified
reconciliationVerified
productionQaPassed
```

只有 `launchVerified && walletVerified && reconciliationVerified && productionQaPassed` 才允许前台按钮执行真实启动。只有目录成功时显示“目录已同步”，不能显示“可玩”。

## 实施顺序

1. 冻结前台 34 项的唯一清单，清除 34/38 混用；取得 RSG Hub 对应的供应商 ID。
2. 建立 registry、capability 类型、统一错误码与 fail-closed 路由。
3. 先完成文档充分的 RSG adapter 及纯离线 contract tests；密钥只放 Render env。
4. 向 336699 家族厂家索取完整 API 文档、签名公式、玩家/启动/钱包/回调及日志查询 schema，再实现一套共享 adapter + 六个 provider profile。
5. 其余厂家按独立协议逐家实现；每家完成目录、玩家、启动、钱包、回调、对账后才进入生产 QA。
6. 使用厂家 UAT 或获准的零资金测试账号验收；没有测试环境的 production 账号不得用真实会员资金做开发测试。

## 目前可以确认与仍缺少的内容

可以确认：

- 34 个前台入口不能靠一个 adapter 自动变成 34 家可玩；
- RSG Hub 有完整 transfer-wallet 文档，可开始安全的离线实现；
- 336699 六家共用凭证模板与 API 主机，可共用一个协议 adapter；
- 当前 gateway 的 supplier catalogue 与单一启动实现无法覆盖上述 34 家。

仍需厂家资料：

- RSG Hub 对应 MASTER7 34 项中的准确供应商名称/源码 ID；
- 336699 家族的完整 API 方法与签名/回调文档；
- 其余独立厂家缺少的 launch、wallet、callback、report 合同；
- 每家的固定出口 IP 白名单确认及 MYR UAT/生产 QA 结果。

这些缺口属于厂家合同与映射，不能通过猜字段或打开前端按钮解决。
