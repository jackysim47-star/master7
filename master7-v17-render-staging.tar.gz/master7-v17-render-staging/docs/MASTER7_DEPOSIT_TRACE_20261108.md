# MASTER7 deposit evidence view

Local candidate: `17.0.0-selfbuilt.106-deposit-evidence`.

The owner-only `GET /api/admin/deposits/trace?orderId=...` joins one stored
deposit order with its ledger entries, applicable audit events, sanitized
diagnostic fields and, for VPay and GSPAY, recovery-lease metadata. The owner
can open it from the deposit report or look up an order by ID. The endpoint is read-only and makes no
provider request or financial mutation.

- A balanced ledger requires exactly one member and one clearing entry, the
  order's member and currency, and the exact matching opposite amounts.
  Credited orders without balanced entries and uncredited orders with entries
  are marked for review. If the order changes during the separate reads, the
  view requests a refresh instead of deciding a mismatch.
- Callback history is incomplete. An existing callback-review audit is shown
  as recorded; absence is `unknown`, not proof that no callback arrived.
  Provider payment remains unverified until independently matched with provider
  evidence. A recovery lease is only a task record, not proof of payment.
- Only an owner can read financial trace details; staff continue using the
  shared backoffice with their existing permissions. The browser rejects stale
  order responses after a refresh or owner change. Checkout URLs, tokens,
  passwords, raw diagnostic payloads and lease claim tokens are not returned.
- This view does not query providers, alter ACK behavior, enable GSPAY USDT,
  post missing funds, or replace bank/provider reconciliation. Existing
  migrations through 0110 and backup/restore prerequisites remain in effect.
- Production deployment, real payment, recovery scheduling, secret changes and
  production sign-off remain outside this local candidate.
