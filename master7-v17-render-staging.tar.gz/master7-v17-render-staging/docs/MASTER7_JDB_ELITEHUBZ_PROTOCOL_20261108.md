# MASTER7 V17 · JDB / EliteHubz offline protocol work

Candidate: `17.0.0-selfbuilt.103-provider-protocols`
Date: 2026-11-08
Status: local protocol code and simulated tests only; no provider or production acceptance.

Validation: 728/728 full regression, 11/11 maintenance, 16/16 release
probes, 3/3 Render database adapter checks, TypeScript, ESLint and the local
Render-target build passed. The protocol-specific tests use fake transports.

## JDB

`lib/jdb-transfer-protocol.ts` implements isolated request/response handling for
Action 49 (catalogue), 12 (create player), 15 (verify player and balance), 11
(launch URL), 19 (deposit/withdraw), 55 (transfer query), and 29/64 (reports).
The client requires an explicitly supplied transport and configuration; the
portal does not instantiate it or route member or staff requests to it.

- `jdb_myr` and `spribe_myr` derive different player IDs and transfer serials.
  This does not create or verify a database mapping or independent ledger.
- Transfer input must carry an existing durable transaction serial. The client
  submits once and never automatically resends on timeout, duplicate or pending
  responses. Only an exact player, direction and amount match in Action 55 is
  reported as `matched`; even then `requiresLedgerReconciliation` is true.
  Action 55 does not return the serial or currency in its row, so the caller
  must independently verify player currency and reconcile platform postings.
- Action 15 requires the provider's `RM` code, agent, player ID and player
  level to match. Balances with a fraction of one sen retain a residual flag;
  they must not be rounded into the MYR member ledger.
- Report windows use the documented limits and an explicitly configured
  provider UTC offset. Raw IDs and decimal values are retained; `complete` is
  false because durable ingestion, reconciliation and coverage are not built.
- Callback semantics are not present in the available transfer documentation;
  no callback route was invented. Approved launch origins must be configured
  before the client returns a game URL.

The official introduction specifies space padding, whereas the JavaScript and
Java samples use zero padding. The client has no implicit choice: the padding
must be explicitly configured after the provider confirms the contract. Both
documented variants have offline vectors. Existing evidence records JDB error
9001 (unauthorized); it does not establish why authorization failed.

Public contract references: [Introduction](https://doc.jygrq.com/en/transfer/introduction),
[Action 19](https://doc.jygrq.com/en/transfer/functions/transactionManagement/action19),
[Action 55](https://doc.jygrq.com/en/transfer/functions/transactionManagement/action55),
[JavaScript sample](https://doc.jygrq.com/en/transfer/sampleCode/javascript),
and [currency codes](https://doc.jygrq.com/en/transfer/appendix/currencyCode).

## EliteHubz / VENUS

`lib/elitehubz-signature.ts` implements the v1.20.5 sorted-query and HMAC
construction, and validates the published example vector. The helper is not
wired to a request endpoint, wallet, callback or provider registry.

The supplied document contains transfer-wallet API material and describes
success code `0`. Its transaction history example does not establish all
fields needed to bind a payment to a player and currency. Confirm those details,
the authorized provider code, response signing,
test credentials and reference recovery with the provider before implementing
or enabling live money movement. Signature and timestamp verification alone do
not prevent a valid callback replay; durable event idempotency is still needed.

## Acceptance boundary

Both profiles remain unavailable in the customer portal. The new code does not
create a member wallet reservation, write a wallet posting, process a callback,
perform recovery or communicate with the production supplier. Before future
activation, complete the platform transaction state machine, independent player
and ledger mapping, signed callback or polling contract, UAT, reconciliation,
recovery and authorized release. Secret values previously exposed must be
rotated and supplied through the designated secret store.
