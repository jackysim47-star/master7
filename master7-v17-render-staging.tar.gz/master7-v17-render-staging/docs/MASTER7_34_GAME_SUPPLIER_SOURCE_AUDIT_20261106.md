# MASTER7 34 家游戏供应商源码核对

日期：2026-11-06（MYT）
范围：`/workspace/m7-integration67-v1` 当前源码；没有调用真实厂家凭据，没有创建玩家、转账或启动真实游戏。

## 结论

当前项目可以精确还原与用户所说 **34 家**对应的 34 个供应商按钮/素材基线。它不是 34 份厂家合同，也不是 34 家已连接证明：

- `docs/ASSETS_MANIFEST.csv` 第 23–56 行恰好登记 34 个 `public/assets/providers/*.webp`；
- 这 34 个文件与 `public/assets/app.js` 的 `apiSupplierEntries` 前 34 项完全相同；
- `docs/MASTER7_HANDOVER_20261105.md` 明确写着 “34 separate supplier buttons” 和 “34 supplier artwork files”；
- `app/portal.html` 仍显示 `34 SUPPLIERS`。

当前前端数组实际有 **38 项**。多出的 4 项是 `EPICWIN`、`VENUS`、`CLOTPLAY`、`godeezone`，它们没有独立的 34 家供应商图片，源码让它们使用通用 MASTER7 图标。因此，当前 38 项应解释为同一 UI 数组中的 34 个素材入口加 4 个额外目录入口，不能写成 38 家已经连接的厂家。仓库的 Git 根提交已经含全部 38 项，Git 历史本身不能证明这 4 项在什么时间加入。

34 个文件只有 23 个不同的 SHA-256；其中 12 个名称共用同一张 fallback 图片。因此图片数量也不能用来证明 34 个独立厂家连接。

源码中实际只有 **9 个目录来源**：7 个 integration gateway 目录加 2 个直接只读目录。它们正好分成：

- 34 家范围内 5 个：`megah5`、`jili`、`918kissh5`、`evo888h5`、`rectangle`；
- 额外 4 个：`epicwin`、`venus`、`clotplay`、`godeezone`。

在 34 家范围内：

- 目录 adapter：**5/34 有源码，29/34 缺少**；
- 启动 API：**1/34 有源码**；
- 游戏钱包 API：**1/34 有源码**；
- 退出结算流程：**1/34 有源码**；
- 唯一有启动、钱包和结算源码的是 `MegaH5`。其余目录即使能显示游戏，也没有启动、钱包或结算代码。

这里的“有源码”不等于真实生产验收通过。本次没有使用真实会员或厂家凭据，故没有把任何一家标成已完成真实下注验收。

## 34 家逐项矩阵

| # | 供应商（源码 ID） | 游戏目录 adapter | 启动 API | 游戏钱包 API | 退出/结算 API |
|---:|---|---|---|---|---|
| 1 | MegaH5 (`megah5`) | ✅ Gateway `/providers/megah5/games` | ✅ `/api/game-launch` → `/platform/megah5/session` | ✅ balance / deposit / withdraw / transfer-status | ✅ `/api/game-wallet/settle`、recover、平台账本 |
| 2 | JILI (`jili`) | 🟡 Gateway 只读目录 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 3 | 918KISS H5 (`918kissh5`) | 🟡 Gateway 只读目录 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 4 | GAMEPLAY INTERACTIVE (`gameplay`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 5 | LION KING (`lionking`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 6 | SUNCITY (`suncity`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 7 | PGSOFT (`pgsoft`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 8 | GFG / G4 (`gfg`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 9 | SA GAMING (`sagaming`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 10 | PS9 (`ps9`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 11 | DRAGOONSOFT (`dragoonsoft`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 12 | JDB (`jdb`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 13 | BG (`bg`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 14 | ALLBET (`allbet`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 15 | QUICKSPIN (`quickspin`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 16 | ASTAR (`astar`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 17 | META GAMING (`metagaming`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 18 | FUMA (`fuma`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 19 | YL (`yl`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 20 | FUNKY (`funky`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 21 | GAMITECH (`gamitech`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 22 | SPADE GAMING (`spadegaming`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 23 | TURBO (`turbo`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 24 | CT855 (`ct855`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 25 | PRAGMATIC PLAY (`pragmaticplay`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 26 | JOKER (`joker`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 27 | CG (`cg`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 28 | ATG (`atg`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 29 | RECTANGLE (`rectangle`) | 🟡 直接只读 `/api/v1/available-games` | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 30 | M8BET (`m8bet`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 31 | AWC (`awc`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 32 | EVO888H5 (`evo888h5`) | 🟡 Gateway 只读目录；失败时只保留旧缓存并进入维护 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 33 | COSMOPLAY (`cosmoplay`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |
| 34 | GEMINI UPDOWN (`geminiupdown`) | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 | ❌ 缺少 |

## 为什么“有 34 个按钮”仍然不能玩 34 家

`game-catalogue.ts` 把目录数据统一写成 `playable:false`，并给所有目录来源返回 `launchVerified:false` 与 `walletVerified:false`。`backend.ts` 只会对 `megah5` 覆盖这两个字段，并且 `/api/game-launch`、`/api/game-wallet/settle`、`/api/game-wallet/recover` 全部固定调用 MegaH5 流程。

因此，供应商图片、按钮、游戏封面或目录数量只能证明展示资料存在，不能证明已有厂家启动和资金结算连接。

## 额外 4 项（不计入 34 家）

| UI 项 | 目录 adapter | 启动 | 钱包 | 结算 |
|---|---|---|---|---|
| EPICWIN (`epicwin`) | 🟡 Gateway 只读目录 | ❌ | ❌ | ❌ |
| VENUS (`venus`) | 🟡 Gateway 只读目录 | ❌ | ❌ | ❌ |
| CLOTPLAY (`clotplay`) | 🟡 Gateway 只读目录 | ❌ | ❌ | ❌ |
| 其他游戏 (`godeezone`) | 🟡 直接只读目录 | ❌ | ❌ | ❌ |

## 让其余厂家真正可玩的逐家缺口

每一家至少要有经合同确认的产品映射，以及以下可实施资料和验收证据：

1. 游戏目录接口与稳定的 `(provider ID, game ID)`；
2. 玩家建立或登录、游戏启动与回跳接口；
3. 钱包模式（转账钱包或 seamless wallet）、余额和币种精度；
4. deposit / withdraw 或 bet / settle / rollback / cancel 的幂等协议；
5. 厂家回调签名、允许 IP、超时补查和断线恢复；
6. MYR 测试账号、测试游戏和允许的 UAT 验收步骤；
7. 余额前后、重复回调、退出、断线重连、并发和报表复算证据。

没有这些资料时，只能保留品牌按钮或目录，不能安全地复制 MegaH5 的启动、玩家 ID、密钥或资金流程给另一厂家。

## 源码证据

- 34 项资产清单：`docs/ASSETS_MANIFEST.csv:23-56`
- 34 按钮与 34 图片交接说明：`docs/MASTER7_HANDOVER_20261105.md:34-40`
- 当前 38 项 UI 数组：`public/assets/app.js:110-113`
- 额外 4 项使用通用图标：`public/assets/app.js:115`
- 7 个 gateway 目录与 2 个直接目录：`lib/game-catalogue.ts:8-22`
- 所有目录默认不可玩、launch/wallet 未验证：`lib/game-catalogue.ts:75-87`
- 直接目录明确为只读：`lib/direct-game-catalogues.ts:3-10`
- MegaH5 启动唯一实现：`lib/backend.ts:225-241`
- 三个通用前台路由实际固定到 MegaH5：`lib/backend.ts:431-433`
- MegaH5 钱包与结算状态机：`lib/megah5-wallet.ts:97-180`
- 旧整改文档也明确 34 张图只属历史索引，不能证明连接：`docs/MASTER7_全平台检测与整改交接_含游戏_20261106.md:97-99`

## 本地验证

执行：

```text
node --test tests/game-catalogue.test.mjs tests/direct-game-catalogues.test.mjs tests/megah5-wallet.test.mjs
```

结果：27 tests，27 pass，0 fail。测试证明现有只读目录和 MegaH5 钱包状态机的源码行为；它不构成 34 家真实生产启动验收。
