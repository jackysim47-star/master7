# MASTER7 V173 Owner Handover

版本：`17.0.0-selfbuilt.173-staff-setup-route`  
环境：staging

## 一个入口

以下两个地址按同一套应用入口设计，登录后由账号角色决定功能范围：

- `https://www.master7.best`
- `https://www.master7.site`

角色为 `Owner`、`Staff`、`Member`。域名 DNS/TLS 是否已在托管平台正确指向，仍须由域名平台做外部验证；本文件不代表 DNS 已经修改。

## 一次检查全部状态

Owner 或 Staff 登录后打开：

```text
GET /api/admin/handover-status
```

这个接口只读，不会调用厂商、创建订单、启动游戏、改变钱包或移动资金。它会集中显示：

- 两个入口域名和角色模型
- staging 环境与交易开关
- 游戏、充值、提款的 readiness
- Lebet、VPay、GSPAY、1MPAY 合同登记
- 当前生产 `NO-GO` 原因

## 当前交接规则

只要官方供应商合同、UAT 证据、DNS/TLS 验证或生产签收缺失，状态必须保持 `NO-GO`。不得把模板、目录或支付状态页当作真实游戏或真实充值已连接。

V15 资料仅作历史回滚参考，不在 V173 交接中删除或启用。
