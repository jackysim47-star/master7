# MegaH5 durable launch guard candidate .114

Local candidate only. No production migration, provider request or real-money
test was performed. The previous locally reproduced GameLogin vs settlement
race is addressed for new sessions by persisting a launch operation before the
provider request, under the same member lock used by settlement. Each wallet
session has at most one operation bound to its member and game. Neither a game
URL nor any token is stored.

`launching`, `issued`, and `unknown` remain unresolved and block automatic
settlement and recovery; no timer, browser closure, timeout, error or process
restart is treated as proof of provider session closure. A claim that loses to
settlement cannot send GameLogin. A contradictory unresolved launch combined
with a non-active wallet or invalid reservation requires reconciliation, and
cleanup cannot release the hold. Only a validated provider-supported close
contract or an audited reconciliation design may eventually close an operation;
this candidate does not invent one. It therefore intentionally cannot
automatically recover funds from a newly issued or ambiguous session.

Legacy sessions without a launch row retain existing settlement and recovery
behavior because the handover requires those operations to remain available.
Absence of a row is not evidence that an older provider game is closed: old
sessions must be inventoried and reconciled before live use. All new launches
remain hidden/disabled until actual launch, wallet and settlement acceptance.

Migration `0112_megah5_launch_operations.sql` adds a persistent table; encrypted
backup schema version is updated and old supported backups restore with explicit
missing launch-table coverage, not a production-ready restore receipt. Prevent
old and new instances from writing concurrently during any eventual migration.

1MPay additionally preserves pre-existing incomplete ledger entries and places
conflicting provider/payment results under review, under the same member guard.
Provider status vocabulary and callback retry behavior still require vendor
verification; the cautious policy may hold members pending reconciliation.
