# MASTER7 v152 918KISS catalogue safety release

Release: `17.0.0-selfbuilt.152-918kiss-catalogue-safety`

This release hardens the three isolated 918KISS H5 catalogue profiles:

- Normal MYR
- Normal MY1
- Free MYR

The portal rejects a profile refresh when normalization removes a malformed or
duplicate row, retaining the last complete snapshot. A missing supplier
availability field is treated as maintenance and is shown as suspended rather
than active.

The release keeps all 918KISS games non-playable. The supplier-specific player,
launch, wallet, transfer-status, exit, settlement and recovery contracts have
not been supplied or accepted. MY1 1:100 remains an internal candidate setting,
not a verified supplier money contract.

Payment providers, payment switches, production game switches, credentials,
service plans and DNS are unchanged.
