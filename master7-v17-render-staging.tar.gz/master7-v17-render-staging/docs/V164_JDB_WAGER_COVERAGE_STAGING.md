# MASTER7 v164 JDB wager coverage staging

Release: `17.0.0-selfbuilt.164-jdb-wager-coverage-staging`

## Scope

v164 adds a durable, fixture-only evidence boundary for JDB wager reports. It does not call JDB, poll a live supplier, launch a game, move wallet funds, calculate turnover, grant rewards, post accounting entries, or enable production play.

The staging path records only privacy-preserving SHA-256 fingerprints, nonnegative MYR amount fields, settled timestamps, classifications, and aggregate receipt counters. Provider player, bet, round, game, claim-token, and source-payload values are not returned by diagnostics. These records are review evidence and cannot feed accounting.

## Durable behavior

- Exact report pages use a canonical page digest and a unique window/page receipt. A retry after a lost response or a new lease generation returns the same receipt.
- Fixture pages are bounded to 500 rows; no live poller or unbounded provider page is enabled in this release.
- JDB report windows use the existing `wager_sync` recovery lease. Claim tokens plus monotonically increasing fence generations prevent stale or concurrent pollers from committing evidence.
- The receipt, identity, immutable version, observation, cursor review state, and lease release commit in one transaction. A fault rolls the entire batch back for safe retry.
- Coverage diagnostics merge observed intervals and expose gaps, overlaps, duplicate observations, late arrivals, changed results, and zero-value reversal candidates by window.
- `late` means a new identity first appears in a later receipt for the same exact report window. Historical `gameDate` rows are not called late merely because they are old.
- A changed zero-value result is a `reversal_candidate` only. It is never treated as a confirmed reversal or wallet correction.

## Fail-closed boundary

Every receipt fixes these claims to false:

- provider page completion and provider coverage completion;
- supplier report finality;
- official session closure verification;
- merchant authorization verification.

The read-only owner/staff endpoint `GET /api/admin/jdb-wager-coverage` also reports `turnoverConnected`, `rewardConnected`, `accountingConnected`, and `productionReady` as false. It returns aggregate windows and counters without supplier or member identifiers, payloads, amounts, digests, or lease tokens.

The `jdb_myr` profile remains unavailable. Catalogue availability, Play, launch, wallet transfer, settlement, recovery, turnover, rewards, and production acceptance remain false unless their separate official contracts and evidence are completed in a later release.

## Database and recovery

Migration `0121_jdb_wager_coverage_staging.sql` is additive for SQLite and PostgreSQL. It does not create, open, close, or otherwise mutate a provider profile. A staging claim requires a separately provisioned, exact `jdb_myr` production profile that is already closed; a missing or altered parent fails closed. The encrypted-backup manifest includes all JDB coverage tables. A v164 restore can identify a v163/`0120-provider-wallet-sweeps` archive as legacy with explicit missing JDB coverage tables instead of claiming complete coverage.

## Release state

This document describes source code and fixture validation only. v164 has not been deployed by this source change. No live supplier call, real-money acceptance event, DNS change, service-plan change, activation flag, or owner production sign-off is included.
