# Member wallet serialization candidate .111

This is a local candidate based on v18 `.110-payout-protection`. Nothing here
applies a migration to or changes a production service.

The member guard is a per-user row written first in a transaction. New
withdrawal and MegaH5 transfer reservations re-evaluate risk, current balance
and open operations while holding that guard; payout risk, current deposit
credit/review, and game settlement/recovery writes follow the same lock order.
A credited deposit that moves to review freezes new commitments for
reconciliation, while an uncredited review does not freeze unrelated funds.
Existing callbacks, settlement and recovery continue; a provider action that
was already authorized or sent cannot be recalled by a later freeze.

`member_wallet_guards` contains only a user ID and revision and is recreated on
demand. It is excluded from backup, like other transient locks. Financial
records, ledger, review evidence and reservations remain persistent backup
data. The SQLite migration is `0111_member_wallet_guards.sql`; Render creates
the table in its schema initialization.

## Limits and rollout

- Guarding depends on every financial writer using the same member lock. Future
  providers and direct administrative SQL must be audited separately.
- Do not allow old and new application versions to write financial state
  concurrently during rollout: older code does not acquire the guard. Plan a
  maintenance window, finish in-flight work, backup, migrate, and verify all
  workers before enabling any real transaction; retain a rollback plan.
- The risk and balance eligibility SQL mirrors the wallet state computation;
  the parity tests must be maintained whenever either changes.
- Zero-balance game authorization does not create a persistent provider session
  token: its post-commit window is still an in-flight boundary to be verified
  with the provider. No live session or wallet behavior is asserted here.
- Historical paid-but-uncredited deposits, true VPay/GSPAY/1MPay payments,
  payouts, 37 provider game sessions, backup restoration, production routing
  and final owner acceptance remain unverified.
