# VPay lost-reference recovery — local candidate `.116`

## Observed gap and source

VPay's public [Trader API](https://gateway.vpay.club/api/doc/trader_en)
lists `out_trade_no` as the required trader order number for `ORDER_GET`; the
request example also includes `trade_no`. The deployed gateway at commit
`28a6b4e0b81275f6d7194f5e251441c80117507d` currently requires both when the
portal queries it. Portal candidate `.115` skips stale `creating` or `unknown`
orders that have no provider reference. These facts do not prove that any
particular historical payment succeeded or that the merchant's production
configuration accepts the request with only the trader order number.

## Change

- Gateway candidate 1.13.2 accepts a query by the trader order number alone;
  it retains both identifiers when the provider reference is already known.
  Its read-only query credential and outbound API signature remain required.
- Portal candidate `.116` can query stale `creating` and `unknown` VPay MYR
  orders after 60 seconds, including when no callback or create response
  supplied a provider reference. Recently started requests, other currencies,
  and failed orders without a reference are not automatically added.
- A matching response must identify the original order, the original amount,
  and a provider transaction; an explicit merchant or currency must also
  match. The authenticated supplier query establishes the merchant context.
  A missing transaction reference stays pending. Conflicting data enters
  review rather than crediting.
- Bind the recovered reference under the member wallet guard without
  overwriting another value. Only an independently confirmed paid result can
  create the existing balanced, idempotent ledger. Existing recovery leases
  and the wallet guard coordinate duplicate workers and wallet writes.
- The member can refresh only their own stale order, including while new
  deposits are paused. Background recovery stays off unless configured.

All cooperating wallet writers must use the same guard. This candidate does
not automatically repair old ledgers or identify which historic order the
owner's paid receipt belongs to.

## Evidence and limits

Synthetic unit/integration tests and a fresh loopback-only PostgreSQL instance
were used. The local supplier simulation checked the actual gateway request
and signature; it was not a VPay server or real payment. The live V17 portal
was still `.99` during the read-only check, and neither code change nor the new
VPay key has been deployed or verified by this work. Confirm the merchant's
accepted query fields, signature time zone, source-IP allowlist, callback,
order association and paid status with VPay before real-money acceptance.

Preserve historical orders and wallet records, verify backup and isolated
restore, coordinate all running versions, and obtain separate production
sign-off. If deployed, the backward-compatible gateway change must precede the
portal change; old callback and recovery functionality must remain available.
