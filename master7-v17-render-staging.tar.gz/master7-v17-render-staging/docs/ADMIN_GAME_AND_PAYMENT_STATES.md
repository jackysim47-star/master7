# Individual game and deposit-channel states

Each supplier game, custom game card, and deposit channel has the same independent backoffice setting:

- `Maintenance`: shown in the customer catalogue with a maintenance label; game launch or real payment is still unavailable in staging.
- `Active`: shown as enabled in the catalogue or payment options. This setting alone never enables real-money processing or game launch.
- `Close`: hidden from the customer lobby/payment options.

Every change is saved separately and written to the audit log. The four deposit entries are VPAY, GSPAY, 1MPAY, and GSPAY+. Payment processing and withdrawals remain disabled until their provider integration and reconciliation UAT is completed. The supplier game catalogue remains read-only until launch, settlement, and provider UAT are completed.
