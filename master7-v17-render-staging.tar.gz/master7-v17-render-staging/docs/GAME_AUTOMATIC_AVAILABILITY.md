# Automatic game availability

The customer route is browser → MASTER7 server → the existing integration gateway → the supplier. Supplier URLs, GameLogin/CheckBalance/Deposit/Withdraw/CheckTransferStatus parameters, signatures, callback formats and response parsing are unchanged. No supplier secret is exposed in customer responses.

## Capability and acceptance

`availabilityMode: "automatic"` and `readOnlyAvailability: true` identify the new policy. `platformLaunchReady`/`launchReady` require the implemented MegaH5 adapter, trusted gateway URL, distinct valid game and wallet credentials, the existing gateway `/readiness` configuration contract, a complete fresh catalogue, and at least one game without supplier maintenance. `walletReady` requires the existing transfer and recovery contracts; it does not by itself imply that any game can launch.

The existing GET `/readiness` response is accepted only for the MASTER7 gateway, `configuration_only` scope and `fund_transfer` mode, with provider credentials, an isolated wallet token, and all three status/deposit/withdrawal channels configured without blockers. HTTP 200 or enabled flags alone are insufficient. No new gateway route, vendor request, vendor credential or gateway deployment is required by this change.

This endpoint cannot prove that Portal's peer credentials match Gateway, that the supplier will authorize a particular player, or that settlement has completed. Actual customer operations still pass their existing gateway authorization and supplier business-status checks. `launchVerified` and `walletVerified` remain false in capability/catalogue summaries. `settlementVerified` remains the existing recorded value and is never promoted by configuration. A successful customer launch response may carry `walletVerified: true` only after its actual wallet preparation succeeds, as before.

MegaH5 is the only implemented Portal launch/wallet adapter. The other 33 public platform entries remain available for browsing their connection/catalogue records; a catalogue alone cannot fabricate a launch or wallet implementation. Custom cards and mini games remain unavailable because no game engine is implemented.

## Retired switches and preserved safeguards

The legacy supplier artwork status, provider visible flag, per-game status/visible fields and Portal Mega transfer/live/settlement flags no longer control customer access. Existing values remain stored for export compatibility. Vendor maintenance and failed, stale, incomplete or malformed catalogues still prevent launch. Catalogue freshness expires after 300 seconds, including while another process holds a refresh lease; future timestamps are not accepted as indefinitely fresh.

The four owner availability write paths (`supplier-art.status`, `provider.visible`, `game-visibility.status/visible`, and custom-game toggle/status actions) return HTTP 410 before the rate-limit journal and make no database writes. A request mixing a retired switch with an artwork change is rejected as a whole. Artwork, category, free/paid classification, custom-card edit/delete and game ranking remain their existing editorial operations. Editorial upserts do not overwrite historical availability fields.

Member approval, CSRF, role checks and responsible-play restrictions remain required. Game-token/wallet-token separation, unique reservations, ambiguous-transfer holds, idempotency and recovery/settlement accounting are unchanged. Removing a Portal manual switch also cannot bypass an upstream gateway or supplier rejection. The existing gateway's own configured transfer/status contract is still checked honestly.

Health and operations reports do not initiate game capability or supplier probes. They consume a conservative in-process observation from the customer/catalogue path, valid for at most 30 seconds and bound to the current connection credentials. No observation, a restart, expiry or changed credentials reports games unavailable until checked. This observation never establishes settlement acceptance.

## Local validation boundary

Tests use only synthetic users, mock gateway responses and isolated SQLite databases. They cover legacy closed/disabled records with working API contracts, missing credentials/contracts, rejected supplier business statuses, maintenance, stale/incomplete catalogues, a refresh lease, no-write deprecated endpoints, editorial compatibility, absent mini-game engines, token scope, single-transfer retries, reservations and recovery. No production database, supplier session or real wallet transfer is used. Real supplier acceptance and PostgreSQL runtime validation are outside these local tests.
