# MASTER7 v162 fail-closed hardening release

Release: `17.0.0-selfbuilt.162-duitnow-qr-fail-closed`

## Change

- A generic company-bank image no longer counts as DuitNow QR configuration.
- The DuitNow QR customer entry remains unavailable until the data model and member API expose an explicit, validated QR-specific field.
- Bank Transfer continues to show every enabled company bank account and its optional bank image.
- The owner form now identifies the upload as a company-bank image and states that it does not enable DuitNow QR.

## Safety boundary

This release does not create a QR schema, enable manual-bank deposits, approve receipts, credit wallets, call a payment provider, or change any real-money switch. It removes an unsupported readiness inference and keeps the QR path closed.

## Regression

The cashier regression supplies both a generic image and an untrusted client-side `duitnowQrReady` claim. Neither may enable the QR form, while the same accounts remain available through Bank Transfer.

The release also tightens the documentation-only 918KISS MY1 profile diagnostic:
it requires provider currency `MY1`, settlement currency `MYR`, point units,
`100:1` provider-to-settlement ratios and the explicit multiply/divide transfer
direction. USD, USDT, reversed or `1:1` manifests stay incomplete. The adapter,
wallet and Play capabilities remain disabled regardless of manifest completeness.

The JILI adapter now checks the merchant-contract flag together with each
independent catalogue, closure and report flag before making a supplier request.
A lone feature flag cannot reach the transport. Existing runtime evidence still
has to satisfy the stricter combined gates, and no live supplier call is part of
this release.
