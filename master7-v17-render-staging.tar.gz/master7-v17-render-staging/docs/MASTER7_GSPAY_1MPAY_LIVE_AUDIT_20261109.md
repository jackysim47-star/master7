# MASTER7 GSPAY MYR / 1MPay MYR live deposit audit

Audit time: 2026-11-09 UTC  
Portal observed release: `17.0.0-selfbuilt.141-responsible-cashier-guard`  
Gateway observed release: `1.13.4`

## Decision

The implemented deposit contracts pass focused source tests, but neither
channel is currently open for new customer orders. Live status reports
`profile_orders_disabled` for both GSPAY MYR and 1MPay MYR. No production flag
was changed during this audit.

GSPAY has no authenticated live order, payment, callback or wallet-credit
evidence in the inspected request logs. It is therefore **NOT VERIFIED** for a
customer deposit.

1MPay has live route evidence for order creation and callback processing. Three
POST callbacks returned HTTP 200. In the exact deployed `.141` source, that
response is possible only after the callback is bound to the stored order, an
independent provider query reports `successful`, and the current order has two
matching balanced wallet-ledger legs. This is strong evidence that at least one
stored 1MPay transaction reached wallet credit at the observed callback time.
The request logs do not contain the order ID and the database cannot currently
be queried externally, so the specific transaction and provider settlement
cannot be signed off. Overall 1MPay production acceptance remains **NOT
VERIFIED**.

## Live status evidence

Portal `/api/version`:

- database: ready
- `newDepositsEnabled=true`
- `realPayments=false`
- `productionReady=false`
- release: `.141`

Portal channel status:

| Channel | Configured | New order | Query | Callback | Recovery | Acceptance |
|---|---:|---:|---:|---:|---:|---:|
| GSPAY MYR | yes | disabled | ready | ready | ready | not verified |
| 1MPay MYR | yes | disabled | ready | ready | ready | not verified |

Both channel responses identify `profile_orders_disabled` as the effective
blocker. Four successful owner-control POSTs to `/api/admin/deposit-controls`
were observed from `2026-11-09T22:06:06Z` through `22:06:11Z`. This is
consistent with the current per-channel pause.

Gateway `/health` and `/providers/gspay/status`:

- process healthy, version `1.13.4`
- GSPAY configured and transaction routes active
- gateway mode: UAT
- `productionQa=not_verified`
- `liveReady=false`

## Request evidence, 2026-11-02 through 2026-11-09 UTC

Only method, route, HTTP status and timestamp were inspected. No credential,
callback body or payment secret was exported.

### GSPAY MYR

| Route | Observed result | Meaning |
|---|---|---|
| `POST /api/payments/gspay/orders` | 2 × 401 | No authorized order creation observed |
| `POST /api/payments/gspay/orders/query` | 0 requests | No live portal query evidence |
| `GET /api/payment-callbacks/gspay/payment` | 1 × 200 | Discovery response only; not a payment callback |
| `POST /api/payment-callbacks/gspay/payment` | 1 × 401, 1 × 503 | No accepted, settled callback |

Failure point for the inspected evidence: **before a usable authenticated
order/payment flow**. There is no evidence that a GSPAY payment reached either
callback or wallet credit.

### 1MPay MYR

| Route | Observed result | Meaning |
|---|---|---|
| `POST /api/payments/1mpay/orders` | 1 × 201, 6 × 202, 3 × 401, 1 × 403, 2 × 409 | At least one validated checkout response was issued; several requests remained uncertain or were rejected |
| `POST /api/payments/1mpay/orders/query` | 5 × 200 | Route responded; HTTP 200 alone does not prove provider success because the response body may still be `awaiting_confirmation` |
| `POST /api/payment-callbacks/1mpay/payment` | 3 × 200, 3 × 401 | Three accepted settlement responses and three unauthorized attempts |
| callback discovery probes | 6 × 404 GET | Expected: this callback is POST-only |

The three HTTP 200 callback responses occurred at:

- `2026-11-07T05:01:02Z`
- `2026-11-07T08:04:57Z`
- `2026-11-07T08:05:10Z`

These may be retries for one transaction; request logs do not prove three
distinct credits.

## Contract path audit

### GSPAY

The portal-to-gateway contract is deliberate. The portal calls protected,
provider-compatible bridge paths. The gateway verifies the internal signature,
re-signs the provider request with the supplier credential, pins the supplier
origin, verifies the supplier query, and re-signs the result for the portal.
The callback bridge uses a separate bearer and signature trust boundary.

Verified in source/tests:

1. Idempotent platform order and exact MYR amount binding.
2. Pinned HTTPS checkout URL.
3. Signed callback plus an independent Get Payment query.
4. Member, order, amount, currency and provider-reference binding.
5. Atomic, idempotent two-leg ledger credit.
6. Query-only recovery for stored orders; no recovery resubmission.
7. New-order maintenance does not block existing callbacks or recovery.

No evidence-based GSPAY code correction was found in this audit.

### 1MPay

Verified in the exact `.141` source/tests:

1. `POST /fundtransfer/json` order contract with SHA-256/base64 token.
2. Provider transaction and validated HTTPS checkout persisted before redirect.
3. Signed callback bound to merchant, order, customer, amount and transaction.
4. Independent `GET /transquery/{trxno}/{token}` verification before credit.
5. Atomic, idempotent two-leg ledger credit and post-write confirmation.
6. Query-only recovery of stored references; no order resubmission.
7. New-order maintenance does not block existing callbacks or recovery.

The source cites 1MPay API Specification 1.3, but that supplier document is not
present in the supplied repository or attachments. Therefore the route and
signature implementation is source-tested, while final supplier-contract and
retry/settlement acceptance remains external evidence.

No evidence-based 1MPay code correction was found in this audit.

## Focused validation

Exact deployed portal `.141` source:

- GSPAY / 1MPay / recovery / cashier focused suite: **185 / 185 passed**
- `lib/gspay.ts` and `lib/onempay.ts` hashes match the current candidate copies

Gateway `1.13.4` source:

- GSPAY routing, signature, reliability and server suite: **54 / 54 passed**

Tests use synthetic supplier responses and do not replace real-money
acceptance.

## Evidence blockers

1. The Render Postgres external IP allowlist is empty. The hosted Render MCP
   query cannot read `deposit_orders` or `wallet_ledger`.
2. The one-off deposit-forensics credential is not available to this audit.
3. Request logs do not expose order IDs or callback bodies by design.
4. Both channel order switches are currently paused.
5. GSPAY has no accepted live POST callback or authorized order in the observed
   logs.
6. 1MPay lacks an exported order/ledger/provider-settlement reconciliation row
   and formal owner acceptance event.

## Required acceptance evidence

For GSPAY, perform one separately authorized controlled payment after the
supplier confirms the callback and query contract, then retain platform order,
provider transaction, callback, independent query, two wallet-ledger legs and
merchant settlement evidence.

For 1MPay, first extract the existing read-only incident snapshot to identify
the order behind the accepted callbacks. Match the order ID, provider
transaction, amount, provider query result and the two wallet-ledger legs. Do
not create another payment solely to investigate the existing case.

Until those records are matched, customer-facing status must remain
**NOT VERIFIED** and `realPayments=false`.
