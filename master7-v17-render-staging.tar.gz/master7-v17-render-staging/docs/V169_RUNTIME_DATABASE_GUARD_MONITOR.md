# V169 Runtime Database Guard Monitor

Release: `17.0.0-selfbuilt.169-runtime-guard-monitor`

## Change

Every Render portal instance now starts a mandatory runtime PostgreSQL guard
monitor after Nitro starts and outside the advisory-lock scheduler leader. The
startup transaction remains the first gate. The runtime monitor then reuses the
same frozen `assertCriticalDatabaseGuards` contract to verify all nine protected
triggers and the five unique guard functions every 60 seconds by default.

Each cycle creates a new PostgreSQL client with a fixed application name. The
connection and server statement timeouts default to 10 seconds, the client query
timeout is 11 seconds, lock waits are limited to two seconds, and client cleanup
is limited to two seconds. The next unreferenced timer is scheduled only after
the preceding connection, attestation and cleanup complete, so checks cannot
overlap or accumulate.

The interval can be set between 15 and 300 seconds with
`PORTAL_DATABASE_GUARD_MONITOR_INTERVAL_MS`. The server timeout can be set
between one and 30 seconds with
`PORTAL_DATABASE_GUARD_MONITOR_QUERY_TIMEOUT_MS`. Invalid values fall back to
the safe defaults. There is no monitor disable switch.

## Failure behavior

A client-construction, connection, metadata-query, attestation or cleanup
failure stops the monitor and exits the instance exactly once. The log contains
only a fixed phase and a constrained database error code; it never includes the
connection string, query, guard source or provider data. Render can restart the
instance, but the existing startup attestation continues to reject drift before
the service becomes ready. Runtime drift is detected, never repaired.

Successful verification is logged once when the monitor becomes ready. Later
successful cycles remain silent. The monitor uses an unreferenced idle timer and
does not replace Node's default SIGTERM or SIGINT behavior.

## Mobile navigation correction

The same release corrects the mobile member dock so Home and Games are separate
current destinations inside the lobby. Games, provider and category actions
retain Games as the only active `aria-current` item; Home restores Home, and the
other dock destinations keep their own state. The correction changes navigation
state only and does not mark any game or provider playable.

## Verification and scope

Synthetic tests cover immediate verification, post-completion scheduling,
non-overlap, idempotent stop, stop during an in-flight query, bounded cleanup,
sanitized connection/query/cleanup failures, exact-once exit, and per-instance
wiring outside scheduler leadership. The isolated PostgreSQL 18 suite replaces
an expected function body under the same name after a successful runtime check,
proves the next monitor cycle exits fail closed, proves the drift is not
repaired, and then restores the function explicitly.

Mobile navigation tests also verify a single active destination, distinct Home
and Games state, correct Wallet/Promotions/Support state, and Games retention
through provider and category entry points.

- no migration, table, column, backup format or backup data-contract change;
- backup schema remains `0122-acceptance-ledger-integrity` with 76 tables;
- no payment, payout, wallet, game-provider, DNS, credential, plan or
  production-control change;
- no live provider or customer transaction calls during validation.
