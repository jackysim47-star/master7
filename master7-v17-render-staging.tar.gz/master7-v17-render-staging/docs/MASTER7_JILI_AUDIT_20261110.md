# MASTER7 JILI 1:1 and 1:100 implementation audit

Review date: 2026-11-10. This is a source audit, not provider acceptance or production evidence.

## Proven by repository tests

| Boundary | `jili_myr_1to1` | `jili_my1_1to100` |
| --- | --- | --- |
| Profile, player, catalogue cache and ledger namespace | isolated | isolated |
| Platform ledger unit | MYR sen | MYR sen |
| Ratio application | explicit field units; no inferred conversion | explicit field units; no inferred conversion |
| Transfer submission | one attempt, then original-ID query | one attempt, then original-ID query |
| Withdrawal | sweep-all; receipt determines actual return | sweep-all; receipt determines actual return |
| Unknown provider result | reservation retained | reservation retained |
| Launch URL | HTTPS and exact-origin allowlist | HTTPS and exact-origin allowlist |
| Wager report | bounded window and profile-bound cursor | bounded window and profile-bound cursor |

The portal protocol preserves decimal amounts and 64-bit wager identifiers before JSON parsing. It checks the report agent, player, page, window, amount precision and duplicate bet IDs. The gateway exposes only an account-bound read-only catalogue; it has no launch, wallet, report or settlement route.

## Disabled-by-default acceptance gates

- Cash launch/recovery requires the merchant contract evidence digest.
- GetGameList rows remain in maintenance unless a separate evidence digest confirms the merchant account's list-to-launch availability meaning.
- Session closure requires a separate closure evidence digest plus explicit confirmation that issued launches are invalidated and late results are final. `KickMember` or offline status alone cannot certify closure.
- Wager transport requires a separate report evidence digest and explicit confirmation of BetAmount/PayoffAmount ledger semantics.
- Production launch additionally requires durable profile-specific catalogue, launch, wallet, settlement and recovery acceptance events.

## Vendor and UAT evidence still required

For each profile independently, JILI must confirm the merchant-bound legacy protocol, assigned endpoint and credentials, the transfer/query/balance/report unit of every amount field, permitted launch origins, closure behavior, token invalidation, late-round finality, report sign/ledger meaning and availability semantics. UAT must then capture a real catalogue response, player lifecycle, launch/return, deposit and sweep query receipts, zero and positive sweep outcomes, paginated wager rows, interrupted-request recovery and reconciliation to the platform wallet ledger.

Until that evidence is reviewed and the profile-specific acceptance events pass, neither profile is proven playable or suitable for real money. No source test can replace vendor certification or live UAT.
