# GSPAY MYR Deposit 与 Payout 接入边界

更新时间：2026-11-06 21:09 MYT
适用版本：`17.0.0-selfbuilt.69-payout-safe-support`

## MYR Deposit

MASTER7 已实现普通 MYR Payment：

- `POST https://api.thegspay.com/v2/integrations/operators/{auth_key}/payment`
- `GET https://api.thegspay.com/v2/integrations/operators/{auth_key}/getpayment`
- Payment callback：`/api/payment/gspay/callback`

建单签名为 MD5(`transaction_id + player_username + amount(2dp) + secret`)；callback / Get Payment 签名为 MD5(`payment_id + amount(2dp) + transaction_id + secret`)。只有 callback 完成验签、订单/会员/金额/厂家流水全部一致，并再经独立 Get Payment 确认成功，才能写入一组金额相反的钱包分录。

收银台 URL 只接受受信 HTTPS host，链接有效期为 2 分钟。不确定建单不会重发；10 分钟没有取得受信成功证据时转为过期/拒绝，不增加会员钱包。

## GSPAY Payout

本版已实现完整但默认关闭的 Payout adapter：

- `POST /v2/integrations/operators/{auth_key}/payout`
- `GET /v2/integrations/operators/{auth_key}/payout/status`
- Payout callback：`/api/payment/gspay/payout/callback`
- 建单签名：MD5(`transaction_id + player_username + amount(2dp) + account_number + secret`)
- 查单/callback 签名：MD5(`payout_id + account_number + amount(2dp) + transaction_id + secret`)

callback 不能单独把记录标记为已付。系统还会独立查单，并核对 payout ID、transaction ID、户名、账号、金额和签名。任何冲突都转人工复核；不确定提交保持余额预留，恢复任务只查单、不重发。

## 生产开启条件

GSPAY Deposit 与 Payout 是两个独立能力。Payout 要求下列条件全部成立：

1. 符合厂家格式的 Operator Authentication Key 和 Secret Key。
2. `master7.best` callback 改为可保留 POST 方法和正文的直接 Render 域名/反向代理，不能继续依赖 302 URL forwarding。
3. 厂家书面确认 MASTER7 可用的稳定出站 IP 范围已加白。单次观测的 IP 不作为固定保证。
4. 厂家提供 18 家马来西亚银行的准确 `bank_target` 值；映射必须完整且不重复。
5. `WITHDRAWAL_DATA_KEY`、`GSPAY_PAYOUT_ENABLED=true`、IP 确认标记、银行映射、活跃渠道与数据库 payout control 同时就绪。
6. Owner 安排受控真实验收，并保存厂家 BO、平台记录、callback、独立查单、钱包和结算证据。

凭证只存 Render 服务端环境变量，不进入 Git、前台、日志或文档。DuitNow 与 USDT 仍未启用。
