# MASTER7 MegaH5 activation audit — 2026-11-09

## Decision

**NOT VERIFIED / NOT PLAYABLE IN PRODUCTION.**

The Portal, integration gateway, MegaH5 catalogue and transfer-wallet code are
present. The live customer path remains correctly closed because production
session closure, wallet return and recovery have not been accepted end to end.
No production flag was enabled and no synthetic `PLAY` state was introduced.

## Live evidence

| Area | Evidence | Result |
|---|---|---|
| Portal process | `GET /health/live` returned HTTP 200; live release `17.0.0-selfbuilt.141-responsible-cashier-guard`; database ready | PASS |
| Gateway process | `GET /health` returned HTTP 200; gateway `1.13.4`; currency MYR | PASS |
| Gateway environment | Gateway reports `mode=uat` and production QA is not verified | NOT VERIFIED |
| Portal game control | `newGameLaunchesEnabled=false`; `liveGames=false`; `productionReady=false` | CLOSED |
| MegaH5 connection | Portal reports gateway credentials configured; gateway reports provider and isolated wallet credentials configured | CONFIGURED |
| Catalogue | 166 MegaH5 games; catalogue connected, complete, fresh and with no currently reported maintenance titles | PASS (read-only) |
| Public playability | Zero playable MegaH5 games; launch provider/profile are null | CLOSED |
| Acceptance evidence | Live Portal reports 0 accepted and 0 live profiles; MegaH5 launch, wallet, settlement and recovery evidence are false | NOT VERIFIED |
| Historical GameLogin | Four gateway `/platform/megah5/session` requests returned HTTP 200 on 2026-11-05 | UAT OBSERVATION ONLY |
| Historical balance | One gateway `/platform/megah5/balance` request returned HTTP 200 on 2026-11-05 | UAT OBSERVATION ONLY |
| Transfer in | No authenticated live acceptance record was found. The observed direct deposit probes returned HTTP 401. | NOT VERIFIED |
| Transfer out / recovery | No accepted production withdrawal or transfer-status record was found. | NOT VERIFIED |

The historical HTTP 200 session responses prove only that the signed UAT
`GameLogin` path once returned successfully. They do not prove a wager, result,
session close, returned balance or ledger reconciliation.

## Exact release blocker

The durable launch guard records `launching`, `issued` and `unknown` states.
Settlement and recovery refuse every launch operation whose state is not
`closed`. The current provider/gateway contract has no validated route or
callback that can prove the MegaH5 game session is closed, and the Portal has no
safe way to create that `closed` evidence. Browser closure, timeout or a returned
game URL are deliberately insufficient.

This prevents a real-money failure mode in which a member receives a game URL,
the Portal withdraws the provider balance too early, and a late wager or result
arrives after the wallet has been released. Enabling the launch flag without a
provider-backed close contract could leave a member's game reservation held for
manual reconciliation.

The capability endpoint also intentionally reports `launchVerified=false`,
`walletVerified=false` and `settlementVerified=false`. The launch route checks
those fields, so environment switches or a fresh catalogue alone cannot expose
`PLAY`.

## Network and whitelist evidence

A prior gateway egress diagnostic observed `74.220.52.132` on 2026-11-05 but
explicitly classified it as a currently observed address, not a fixed complete
range. Supplier material also contains a conflicting MegaH5 address
(`113.215.78.156` versus `13.215.78.156`) whose direction and correct value were
never confirmed. Catalogue and UAT GameLogin success show that allowlisting did
not block those particular calls; they do not establish a stable production
allowlist.

## Required supplier evidence before activation

1. Production merchant/environment confirmation for this exact MegaH5 account,
   MYR currency and Fund Transfer wallet mode.
2. Confirmed direction and complete stable egress allowlist for MASTER7's Render
   gateway, plus the supplier's inbound callback/source addresses if applicable.
3. An official session-close or player-offline contract that defines late and
   in-flight wagers, result finality, duplicate close requests, disconnects and
   unused launch URLs.
4. A controlled production acceptance run covering `CheckBalance -> Deposit ->
   GameLogin -> wager/result -> confirmed close -> Withdraw ->
   CheckTransferStatus`, with matching Portal wallet reservation, one game-result
   ledger entry and zero unreconciled provider balance.
5. Separate replay/timeout/restart recovery evidence and immutable evidence
   references for catalogue, launch, wallet, settlement and recovery.

Only after these records pass should the owner acceptance records be entered and
`PORTAL_NEW_GAME_LAUNCHES_ENABLED` be changed under a monitored smoke test.
Existing settlement and recovery must remain available throughout.

## Focused verification

- Portal MegaH5, launch, catalogue, acceptance, reservation and maintenance
  suites: **99/99 passed**.
- Integration gateway MegaH5 scope, transfer validation, catalogue, origin and
  authorization suites: **28/28 passed**.

These are local synthetic tests. They verify fail-closed behavior, idempotency,
reservation protection and recovery rules; they are not supplier production
acceptance.
