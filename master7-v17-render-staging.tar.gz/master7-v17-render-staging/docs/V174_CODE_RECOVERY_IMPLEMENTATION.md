# V174 recovery candidate

Baseline: 753ca2f4282f9270140fdac41a0fdbe128844c64. This is a code candidate,
not a deployment, provider acceptance, wallet approval or production signoff.

## Implemented slices

- MB-01: QA member ID validation accepts existing identifiers and registered
  `local:UUID` IDs. Bank/order/reference validators and database keys are unchanged.
  The integration regression registers a customer using a synthetic SMS transport,
  logs in with OTP, saves the actual registered ID, credits one balanced manual
  deposit, and confirms one manual withdrawal after an unknown result. No real
  SMS, payment, bank or provider transaction occurs in these fixtures.
- P0-03: the actual API route exposes a server composition factory. Only a
  server-provided closer paired with verified closure capability is forwarded.
  Dependency values are snapshotted; request fields cannot supply them. The
  default route has **no official closer** and remains closed for that capability.
  This does not implement the missing official MegaH5 transport.
- P0-06: a pure canonical-statement comparison engine and offline CLI report
  payment, bank and game-provider differences. They have no database handle,
  network transport, credit/debit command, or approval operation.
- P0-05 code gate: JDB now has a controlled, evidence-bound QA/Production
  runtime model. New launch requires the exact QA member (or Production
  acceptance), customer return origin, merchant contract and authorization,
  amount-unit, catalogue, session invalidation and late-result evidence. Old
  session recovery is independent of QA membership so removing a tester cannot
  strand an existing hold. Catalogue, recovery and report capabilities have
  separate fail-closed gates. No evidence, account, credential or switch was
  configured by this candidate, so the current runtime remains closed.
- P2 Owner review persistence and UI: canonical reports and append-only Owner
  annotations are stored by migration 0126. Detail reads and idempotent replays
  verify the exact report JSON SHA-256 and immutable report metadata before use.
  The Finance UI can request this integrity verification explicitly. Lists do
  not claim verification until the report body has been loaded and checked.
  These controls cannot post money, grant acceptance or change production state.
- Cloudflare D1 compatibility: a real workerd/D1 run reproduced withdrawal
  approval and manual payout start failing with `Expression tree is too large
  (maximum depth 100)`. Existing supplier-risk OR clauses are grouped without
  changing their conditions. The two cash-risk checks use a materialized CTE
  in the same statement and guarded batch, preserving Owner, member, balance,
  compliance, recipient, reservation and audit checks. No request-side risk
  cache, extra database table or early fund release is introduced.

## Cloudflare cash-path verification

    node --test tests/cloudflare-manual-bank.test.mjs

This test runs the real backend in disposable workerd/D1 with all SQLite
migrations, actual Owner activation/password login and member registration/OTP
login. SMS and bank evidence are synthetic. Only a disposable rate-limit fixture
is expired after proving send throttling, to avoid a 60-second test sleep.

The flow verifies local:UUID QA selection, one balanced Bank-In journal,
Owner-only/fingerprint/risk barriers, concurrent single approval, withdrawal
holds, unknown-state review, bank-proof confirmation and duplicate prevention.
The generated fixture worker and its OTP inspection capability exist only in a
temporary directory and are never production entry points. This is code/runtime
compatibility evidence, not bank, SMS, supplier or payment UAT acceptance.

The isolated PostgreSQL 18.6 verification additionally passes manual bank (6),
provider transfer wallet (9), and generic wallet protection (7) tests. The latter
two scripts previously attempted TRUNCATE CASCADE across immutable acceptance
history. Their reset now checks the fixed, loopback-only test database identity,
recreates its disposable schema, and reinstalls all migrations and protections.
It never disables a trigger to make fixtures pass. The production schema and
data are untouched. These 22 test results still use synthetic supplier adapters.

## Shared transfer-wallet D1 settlement compatibility

Independent JILI 1:1 and 1:100 workerd/D1 journeys reproduced another
expression-depth failure in `provider-transfer-wallet.ts` at final recovery
settlement. The provider return had already been submitted; the batch failed
before local posting and the original hold remained. This is separate from
manual-bank approval/start compatibility.

The finalizer now materializes the unchanged wallet-risk proof in the same SQL
statement and member-guarded batch. It retains confirmed transfer references,
closure proof, zero supplier balance, exact returned amount, single net posting
and evidence-bound hold deletion. No unknown funds are released early.

    node --test tests/cloudflare-jili-wallet.test.mjs tests/cloudflare-manual-bank.test.mjs

The two JILI profiles each use separate registration/OTP sessions, databases and
synthetic supplier accounts. A lost 53.75 MYR sweep is recovered by querying its
original transaction under launch maintenance and after removing the QA member.
Concurrent recovery posts exactly one 3.75 MYR net result; a later manual 20.00
MYR payout leaves 33.75 MYR from the original 50.00 MYR deposit. The 1:100 fixture
returns balances in game points and transfer/query amounts in MYR, independently
of the application's conversion helper.

This does not test real bets, supplier report completeness, merchant acceptance,
token invalidation or late-round finality. Those fixture claims remain synthetic.
JDB activation remains blocked pending authoritative account-specific evidence.
The former unconditional hard-disable has been replaced by strict evidence and
member gates, but no current environment satisfies those gates. Generic
acceptance, credentials or `mode=qa` alone still cannot authorize traffic.

## Canonical reconciliation input

Run the synthetic example with a **new** output directory:

    node scripts/reconcile-statements.mjs --input examples/reconciliation.synthetic.json --output /tmp/master7-reconciliation-example

This input is an explicitly mapped internal snapshot plus mapped external rows.
It is not a reader for arbitrary VPay/GSPAY/1MPay or bank exports. Official raw
statement mapping, fees/refunds, batch membership, opening/closing bank balances
and supplier-specific result semantics remain P1-01 dependencies. No inferred
mapping, fuzzy match or automatic balance correction is provided.

Amounts are integer minor-unit strings; timestamps are exact UTC ISO values;
coverage must be declared by provider/account/profile/balance class. Missing
coverage remains incomplete even if existing rows compare equally. A succeeded
payment requires its provider transaction ID and an internal ledger projection
with exactly one member leg, one clearing leg, matching member and opposite
amounts. A succeeded game result requires out/returned and closure evidence.
These fields are input evidence, not independent provider verification.

Outputs are a report, input/engine SHA-256 manifest, discrepancy CSV, unsigned
Owner review template and checksums. The result `matched_inputs` means only that
the supplied canonical rows compare equally. It is never UAT or release approval.
The CLI refuses an existing destination. All review fields remain pending/null.

## Per-profile acceptance sequence

All 43 lobby Supplier Profiles remain independent acceptance targets. Production
evidence can now be appended only after the same profile and same capability has
current, integrity-valid UAT PASS evidence. Evidence from another profile or a
different capability cannot satisfy the prerequisite. A later UAT failure,
revocation or integrity fault immediately removes that profile from the accepted
and live counts even when its immutable Production evidence remains available for
audit.

The prerequisite is checked both before the write and inside the same atomic
acceptance-ledger batch. This prevents a concurrent UAT revocation from racing a
Production promotion. The five durable capability streams remain `catalogue`,
`launch`, `wallet`, `settlement` and `recovery`; they are recorded separately for
UAT and Production. Runtime/adapter readiness remains a separate additional gate.

This is a sequencing and evidence-integrity control only. It does not create
official UAT evidence, enable any adapter, call a supplier, open a game, move a
wallet balance or promote the current `0 / 43` Supplier Acceptance status.

## External blockers retained

- P0-04: account-specific official MegaH5 closure, token invalidation and late
  round finality contract/transport. No endpoint or successful closure is invented.
- P0-05 external completion: official JDB merchant, unit, catalogue,
  closure/finality, report and recovery evidence plus authorized QA credentials
  and UAT. The controlled code gate is implemented, but no broad enable switch,
  secret value, provider call or UAT result is added.
- P1-01: official statement examples and per-source mapping/settlement rules.
- P1-02/03: confirmed Free Credit grant, expiry, units and result ownership rules.
  Free Credit remains outside the cash execution path; no cash guard is removed.
- Official raw-statement mappers and authorized source contracts remain external
  dependencies. The persisted review UI consumes canonical mapped inputs only;
  it does not make an unverified mapping official or turn a match into acceptance.

## Compatibility and rollback

Migration 0126 adds reconciliation report and append-only Owner review tables.
It does not alter member keys, wallets, payment orders, provider sessions or
acceptance tables. The management-only reconciliation endpoint is additive;
there is no Customer API or live configuration change. The additional dispatcher
factory is a server module seam, not a public action.
The per-profile acceptance sequence uses the existing append-only UAT and
Production streams and adds no migration or endpoint. Existing Production-only
evidence remains auditable but no longer qualifies as accepted until matching
current UAT evidence exists. Revoking UAT never deletes either history stream.
The JDB gate also adds no schema or public API. Reverting it restores the prior
unconditional runtime closure; preserve and recover any sessions created by a
future authorized QA rollout before such a rollback.
Reverting the D1 query compatibility change reinstates the reproduced approval
and payout-start failures on D1. Preserve all existing holds and bank evidence;
do not use a code rollback to cancel an unknown payment or release its funds.

Before any later approved rollout, preserve journals, reservations and original
transaction references. Reverting MB-01 makes `local:UUID` QA lists unusable again
but must not delete their data. Reverting the dispatcher seam removes its injected
closer and may block closure-dependent recovery; retain a compatible recovery
version for any sessions created in subsequent authorized testing. Reverting the
reporter or review UI must preserve all input/report/Owner evidence artifacts and
the additive 0126 tables. Never clear an
unknown hold, resubmit an ambiguous transfer or rewrite balances as rollback.
