# MegaH5 game launch and wallet settlement race

Status: **local synthetic reproduction; production occurrence not established**.

## Observed behavior

`launchMegaH5` prepares an active game wallet session and then sends a separate
`/platform/megah5/session` request. The member can simultaneously call
`/api/game-wallet/settle`, which sees that wallet session as active and can
transfer the provider balance back before the session request finishes.

Using the actual portal router, an in-memory SQLite database and synthetic
responses from a closed fixture, the following sequence was observed:

1. A member launch prepared an `active` wallet session and the synthetic game
   session response was held in flight.
2. A concurrent settlement returned HTTP 200 with `status=settled`.
3. The game session response was released. Launch returned HTTP 200, a game
   URL and the same wallet session ID even though that session was `settled`.

No real provider, wallet, or production data was accessed. This demonstrates an
untracked-launch window in the local implementation; it does not establish
that a real customer was affected or that money was lost.

## Implications and unknowns

The portal can deliver a game URL associated with a wallet session already
closed by settlement. Any subsequent provider-side game activity or balance
change may then require reconciliation. The actual impact depends on the
provider's live behavior, which has not been verified.

The existing integration contract does not establish that the provider session
is closed or invalidated on portal settlement, or how late/in-flight wagers,
prizes and callbacks are handled. These questions require provider evidence;
do not invent an API or assume closing a browser cancels an active game.

## Recommended remediation

- Persist a launch-operation state or lease linked to the wallet session and
  acquire it atomically under the same member wallet guard before calling the
  provider. Settlement must atomically check/claim against that state.
- Handle success, failure, timeout and process crash without assuming that an
  ambiguous provider request failed. Preserve the wallet/session and route
  uncertain outcomes to recovery or human reconciliation.
- Bind the launch response to the same member, wallet session and game; never
  report a successful launch for a session already settled or under review.
  A read-only active-status check immediately before returning a URL is not
  sufficient: settlement can occur between that check and delivery.
- Establish and verify the provider-supported session-close and in-flight wager
  contract before treating browser closure as final settlement. Continue to
  allow already authorized settlement, recovery and refunds.
- Cover both operation orderings, simultaneous requests, duplicate requests,
  timeout, process restart and late provider responses using an isolated real
  database and synthetic provider; verify one consistent wallet record and no
  untracked launch. Obtain separate live provider acceptance before exposure.

Until implemented and verified, this remains a release blocker for real-money
MegaH5 operation. The other providers have their own protocol and acceptance
requirements; this finding does not prove they share the same behavior.
