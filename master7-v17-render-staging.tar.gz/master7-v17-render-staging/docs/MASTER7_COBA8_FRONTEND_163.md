# MASTER7 v163 COBA8 front-end registration

Release: `17.0.0-selfbuilt.163-coba8-front-end-registered`

## Member front end

- COBA8 is registered as one distinct game-provider brand and one independent
  `coba8_myr` profile in the member Game Lobby.
- The lobby uses a neutral MASTER7-owned provider card derived from the existing
  premium lobby artwork. It contains no third-party logo or copied supplier art.
- Existing owner-curated 37-provider rankings migrate without changing their
  order; COBA8 is appended once as the 38th provider.

## Contract boundary

The supplied merchant login and API token are credentials, not an API contract.
The available environment could not retrieve official COBA8 documentation
through the supplier's Cloudflare challenge. The following remain unverified:
authentication and signature rules, base URLs, IP allowlists, catalogue, player,
launch, wallet, transfer/query, report/settlement, callback, session closure,
recovery, limits, errors and UAT acceptance.

`lib/coba8-contract-readiness.ts` reports the exact missing documentation fields
without reflecting any supplied credential value. A complete documentation
manifest remains documentation-only and still cannot enable an adapter.

## Safety state

COBA8 remains `contract_missing` and `adapter_unimplemented` in operational
terms. Catalogue, player, launch, Play, wallet, settlement and recovery are all
false. The release contains no COBA8 network request, player creation, game
launch or wallet movement, does not persist the supplied login or token, and
changes no real-money or live-game switch.
