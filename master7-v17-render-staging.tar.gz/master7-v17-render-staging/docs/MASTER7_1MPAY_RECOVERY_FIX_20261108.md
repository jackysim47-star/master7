# 1MPay recovery connection fix

Local candidate: `17.0.0-selfbuilt.107-1mpay-recovery`. This is not deployed
or evidence that any specific production deposit was recovered.

## Changes

- The payment recovery scheduler now starts when 1MPay alone is explicitly
  enabled with `ONE_MPAY_RECOVERY_ENABLED=true` and a valid private recovery
  token. VPay and GSPAY do not need to be enabled for this. It still calls the
  authenticated loopback recovery endpoint and does not create or resubmit a
  payment order. With 1MPay as the only enabled provider, the worker selects
  the 1MPay-only scope, which does not run other providers' payout recovery.
- A signed callback that matches the existing order's merchant, member,
  amount and transaction can save a previously absent provider reference
  before the independent query. If that query times out, recovery can retry the
  stored order. Saving the reference is not a wallet credit; success still
  requires the bound independent query and a balanced idempotent ledger.
- The missing-reference recovery check compares its observed reference again
  before moving an order to review. A newly received reference is not
  overwritten by an older scan. A stale query mismatch also cannot mark a
  newly changed reference for review.
- A credit audit event is inserted only when the matching order is actually
  credited with the same provider reference.

## Rollout boundary

All recovery switches remain opt-in. Before deploying, verify the effective
environment and outstanding orders: if `ONE_MPAY_RECOVERY_ENABLED` is already
`true` and the token is configured, this fix can start recovery and credit
existing successfully verified orders even when VPay and GSPAY are disabled.
Do not change live flags, provider configuration or data without the separate
production sign-off and recovery plan.

The known local scheduler defect has not been established as the cause of the
owner-reported historical paid-but-uncredited order. Match that order to the
provider transaction and ledger before any correction. GSPAY USDT remains
unimplemented pending its independent provider contract.
