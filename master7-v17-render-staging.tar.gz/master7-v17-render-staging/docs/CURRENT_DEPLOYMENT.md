# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.166-database-guard-attestation`.

This candidate has not been deployed by the source commit. Confirm the actual
Render release and deployment ID from the Portal service before cutover or
rollback. Portal service: `srv-dbl0iv7f3r2c73848ei0`.

The last recorded integration-gateway baseline remains release `1.17.0`,
deployment `dep-dbpchge417fc739h9b50`, commit
`c4aab70060439469f3c2e6081a57c0b40e630ff4`. Gateway service:
`srv-db6b7inlk1mc73ck6cmg`. The v166 candidate does not change the gateway.

## Critical database guard attestation

v166 verifies all nine critical PostgreSQL guard triggers on every portal
startup, including their table, name, enabled state, trigger function, trigger
shape and update-column binding. The attestation runs inside the existing
migration transaction and advisory lock after migrations and before catalog
seeding. Any missing, disabled, rebound or malformed guard aborts startup and
rolls back the transaction; startup never repairs drift silently. The external
PostgreSQL readiness gate imports the same frozen guard contract. See
`V166_DATABASE_GUARD_ATTESTATION.md`.

## Acceptance evidence integrity

v165 makes game-provider and production-acceptance event history immutable and
only permits each current projection to advance to the next latest revision.
Runtime reads derive the latest event from history and fail closed if the
projection disagrees. The PostgreSQL readiness gate requires migration 0122
and all acceptance-integrity triggers. See
`V165_ACCEPTANCE_LEDGER_INTEGRITY.md`.

## Current game registry

- The member lobby contains 38 distinct provider brands and 43 listed provider
  profiles.
- Implemented adapter profiles: 6.
- Launch-ready profiles: 0.
- Production-verified profiles: 0.
- Playable profiles: 0.

COBA8 remains registered as the 38th member-facing provider and independent
`coba8_myr` profile. Its official API contract is unavailable, so it remains
`contract_missing` with no catalogue, player, Play, launch, wallet, settlement
or recovery capability.

JDB remains unavailable for member Play. v164 adds durable fixture-only wager
coverage staging: exact page deduplication, lease fencing, transactional crash
retry, and aggregate gap/duplicate/late/revision/reversal-candidate diagnostics.
The storage keeps hashed identifiers plus review-only amounts and timestamps;
it cannot feed wallet, turnover, reward or accounting operations. Supplier finality, official session closure, merchant
authorization, production acceptance, launch, wallet, settlement and recovery
remain unverified and false. See `V164_JDB_WAGER_COVERAGE_STAGING.md`.

Unavailable provider cards now identify their accessible state as `Coming
soon`; only actually available cards retain game-entry semantics. This text
change does not alter readiness.

Catalogue presence, credentials, HTTP success, an implemented adapter, staged
report continuity, or a merchant login do not establish launch availability.
Production acceptance and runtime readiness remain independent fail-closed
gates.

## Other operational boundaries

Payment work remains paused. VPay, GSPAY and 1MPay code, credentials, callbacks,
activation flags, service plans and DNS are unchanged by v166. This candidate
does not enable any real-money payment, payout or live-game switch.

The verification totals for v166 must be recorded only after the complete
source verification finishes. No deployment or production acceptance is
claimed by this handover.

Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Portal automatic deployment is off; the recorded gateway automatic deployment
setting is on.
