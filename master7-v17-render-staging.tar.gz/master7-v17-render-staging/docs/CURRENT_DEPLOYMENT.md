# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.149-meta-catalogue-isolation`.

Baseline: live `17.0.0-selfbuilt.148-jili-transfer-wallet`, deployment `dep-dbp9m9p42hec73c0ng10`, source commit `587d8368d5e783970953541c7b0f9eb821bfedcb`.

META GAMING now has two isolated, read-only catalogue profiles for the Normal
MYR and Free Credit MYR accounts. Their gateway paths, cache keys, catalogue
account labels and player/ledger namespaces are separate. Both profiles remain
`adapter_unimplemented` and `playable=false`; this release does not enable a
launch, balance, transfer, settlement or recovery route. Remote META artwork is
not trusted until the supplier confirms an official image host, so the portal
uses the local provider artwork.

JILI now has a legacy transfer protocol, executable adapter, per-account runtime factory and the universal game-wallet API. Its 1:1 and 1:100 catalogues have separate cache keys and check the account, currency and ratio. Deposits are confirmed by querying the original account, transaction, direction and normalized amount. Returns use the supplier's all-funds transfer rather than a delayed balance. A zero return still needs a real supplier receipt. Unknown transfers remain reserved; recovery never resubmits them.

Migration `0120-provider-wallet-sweeps` adds immutable withdrawal-mode and adapter-contract fingerprints to operation rows. Existing operations default to their previous exact-amount protocol. Platform cash remains MYR sen; supplier units convert once at the adapter boundary. The backup schema is now 0120 and explicitly accepts 0119 archives. Restores include the new snapshots.

The executable protocol inventory is MegaH5, JDB and the new JILI implementation (four listed account profiles). JILI's merchant contract remains incomplete: the legacy specification is secondary, account amount units and closure finality are unconfirmed, no runtime secret was installed and no production acceptance was recorded. Implementation counts are not playable-game counts. 918KISS and the other merchant protocols remain unimplemented. MegaH5 has no production closure implementation. JDB's last supplier response was 9001.

There are 37 brand entries and 41 separate listed account profiles; production accepted profiles remain zero. No real game launch or real-money transfer occurred in this work. Payment work is paused; activation flags, credentials, pricing, instances and DNS are unchanged.

Deployment requires pre/post encrypted backups and isolated restore checks. Reverting to 147 is safe for this unactivated release only while no 148 sweep operation exists. Once sweeps exist, retain the 148-compatible recovery engine: an old engine does not understand them.

Portal service: `srv-dbl0iv7f3r2c73848ei0`.
Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Automatic deployment is off.
