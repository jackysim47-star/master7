# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.169-runtime-guard-monitor`.

This candidate has not been deployed by the source commit. Confirm the actual
Render release and deployment ID from the Portal service before cutover or
rollback. Portal service: `srv-dbl0iv7f3r2c73848ei0`.

The last recorded integration-gateway baseline remains release `1.17.0`,
deployment `dep-dbpchge417fc739h9b50`, commit
`c4aab70060439469f3c2e6081a57c0b40e630ff4`. Gateway service:
`srv-db6b7inlk1mc73ck6cmg`. The v169 candidate does not change the gateway.

## Runtime database guard monitor

v169 adds a mandatory per-instance PostgreSQL monitor after Nitro startup and
outside scheduler leadership. It opens a new bounded client for each check and
re-attests the nine critical triggers and five guard functions every 60 seconds
by default. Checks never overlap: the next unreferenced timer is created only
after the current connection, attestation and cleanup have completed.

Connection and server statement timeouts default to 10 seconds, the client
query timeout is one second longer, lock waits are bounded to two seconds, and
client cleanup is bounded to two seconds. A connection, metadata query,
attestation or cleanup failure emits one fixed, sanitized fail-closed message
and exits the instance once. Render then restarts it, where the existing startup
attestation prevents drifted definitions from becoming ready. The monitor never
repairs drift. Default Node SIGTERM/SIGINT behavior is preserved, and its idle
timer is unreferenced. See `V169_RUNTIME_DATABASE_GUARD_MONITOR.md`.

## Mobile dock navigation

The v169 member shell also gives Home and Games independent mobile-dock state.
Opening Games, a provider or a game category keeps Games as the single active
`aria-current` destination while the lobby section remains mounted. Home
returns the dock to Home, and Wallet, Promotions and Support retain their own
current-state indicators. This is a presentation and navigation correction; it
does not enable a provider, game launch or money flow.

## Guard function attestation

v168 freezes the definitions of the five unique PostgreSQL functions behind
the nine protected triggers. Portal startup and the external readiness gate
share the same contract and verify canonical `pg_proc.prosrc` SHA-256 values,
all behavior-relevant function metadata, and trigger `WHEN`, argument,
transition-table, constraint and parent fields. Drift aborts startup before
directory seeding and commit. One-time migration 0123 hardens all five
functions with a fixed safe search path and explicit runtime schema binding;
after 0123 is applied, drift is never repaired automatically. Custom restore
schemas remain supported. The backup data contract remains 0122/76 tables.
See `V168_GUARD_FUNCTION_ATTESTATION.md`.

## Startup log severity

v167 removes alert-severity words from the successful database-guard startup
message. It still reports `database guards 9/9 ready`; the nine-guard
attestation and its fail-closed behavior are unchanged. This prevents Render
from classifying a successful startup message as a critical log entry. See
`V167_GUARD_LOG_SEVERITY.md`.

## Critical database guard attestation

v166 verifies all nine critical PostgreSQL guard triggers on every portal
startup, including their table, name, enabled state, trigger function, trigger
shape and update-column binding. The attestation runs inside the existing
migration transaction and advisory lock after migrations and before catalog
seeding. Any missing, disabled, rebound or malformed guard aborts startup and
rolls back the transaction; startup never repairs drift silently. The external
PostgreSQL readiness gate imports the same frozen guard contract. See
`V166_DATABASE_GUARD_ATTESTATION.md`.

## Acceptance evidence integrity

v165 makes game-provider and production-acceptance event history immutable and
only permits each current projection to advance to the next latest revision.
Runtime reads derive the latest event from history and fail closed if the
projection disagrees. The PostgreSQL readiness gate requires migration 0122
and all acceptance-integrity triggers. See
`V165_ACCEPTANCE_LEDGER_INTEGRITY.md`.

## Current game registry

- The member lobby contains 38 distinct provider brands and 43 listed provider
  profiles.
- Implemented adapter profiles: 6.
- Launch-ready profiles: 0.
- Production-verified profiles: 0.
- Playable profiles: 0.

COBA8 remains registered as the 38th member-facing provider and independent
`coba8_myr` profile. Its official API contract is unavailable, so it remains
`contract_missing` with no catalogue, player, Play, launch, wallet, settlement
or recovery capability.

JDB remains unavailable for member Play. v164 adds durable fixture-only wager
coverage staging: exact page deduplication, lease fencing, transactional crash
retry, and aggregate gap/duplicate/late/revision/reversal-candidate diagnostics.
The storage keeps hashed identifiers plus review-only amounts and timestamps;
it cannot feed wallet, turnover, reward or accounting operations. Supplier finality, official session closure, merchant
authorization, production acceptance, launch, wallet, settlement and recovery
remain unverified and false. See `V164_JDB_WAGER_COVERAGE_STAGING.md`.

Unavailable provider cards now identify their accessible state as `Coming
soon`; only actually available cards retain game-entry semantics. This text
change does not alter readiness.

Catalogue presence, credentials, HTTP success, an implemented adapter, staged
report continuity, or a merchant login do not establish launch availability.
Production acceptance and runtime readiness remain independent fail-closed
gates.

## Other operational boundaries

Payment work remains paused. VPay, GSPAY and 1MPay code, credentials, callbacks,
activation flags, service plans and DNS are unchanged by v169. This candidate
does not enable any real-money payment, payout or live-game switch.

The verification totals for v169 must be recorded only after the complete
source verification finishes. No deployment or production acceptance is
claimed by this handover.

Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Portal automatic deployment is off; the recorded gateway automatic deployment
setting is on.
