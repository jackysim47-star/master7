# MASTER7 deployment handover

Candidate: `17.0.0-selfbuilt.146-member-front-clarity`

Live at candidate preparation: `17.0.0-selfbuilt.145-payment-callback-evidence`, deploy `dep-dbp762o8v5cc73dd893g`, commit `29e78a1ecf3e89a778798915732b04c7bcb1154e`.

This candidate refines the member front end with blue/white surfaces, larger service entrances, a shorter company hero and expandable company information. Existing payment, withdrawal, game and wallet routes retain their availability checks.

The incident report was reviewed and corrected: the latest direct VPay query returned `This deposit is not exist.`; business code `-1` alone cannot be classified as invalid signature. Earlier signature-rejection observations remain historical evidence.

No schema, capacity, DNS, secret, balance or payment/game/payout activation change is included in the portal candidate. Publication, validation and post-deploy results are recorded separately in the publication repository.

Portal service: `srv-dbl0iv7f3r2c73848ei0`.
Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Automatic deployment is off.
