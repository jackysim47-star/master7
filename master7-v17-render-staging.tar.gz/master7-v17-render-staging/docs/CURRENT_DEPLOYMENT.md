# MASTER7 current deployment handover

Date: 2026-11-07 MYT

Release in this archive: `17.0.0-selfbuilt.91-payment-network-bridge`

Portal service: `srv-dbl0iv7f3r2c73848ei0` / `master7-v17-staging`

Render workspace: `tea-dakfo2h594qs73du231g` / ahbi

Publication branch: `codex/v17-render-staging-20261104`

Auto deploy: off; releases are triggered and monitored manually.

The publication repository records the exact source commit, archive SHA-256,
Render deploy ID and post-deploy checks in
`MASTER7_GAME_AND_PAYMENT_ACCEPTANCE_20261107.md`.

## Current operating state

- PostgreSQL and the portal health endpoint are ready.
- `productionReady`, `transactionsEnabled`, `settlementVerified` and
  `liveGames` remain false until payment and game settlement acceptance passes.
- Customer registration and SMS OTP have live HTTP evidence. Owner/staff and
  member routes remain role-separated.
- Accounting close runs in MYT and provides daily, monthly, half-year and annual
  settled-cashflow reports. It is not a complete corporate general ledger.
- Support tickets, referral ownership, company-bank configuration, advertising,
  announcements, VIP, Rewards, benefits and marketing controls are present.
  Business content and disabled automation are not invented by the program.

## Payments

- VPay is configured for signed order/query/callback handling, but observed
  order attempts received provider business code `-1`. New orders remain off.
- 1MPay order/query/callback code is reachable. The observed callback did not
  prove a successfully paid order or balanced member-wallet settlement. New
  orders remain off.
- GSPAY+ MYR customer order, strict checkout URL validation, callback/query and
  once-only balanced settlement code are implemented. Release `.91` routes the
  Portal through the integration gateway using separate order, query/signing
  and callback credentials; supplier secrets remain in the gateway.
- The public supplier callback is the gateway `/callbacks/gspay/payment` route.
  The direct Render `/payment/return` route is used for the customer return.
  New orders remain closed until one controlled paid reconciliation passes.
- GSPAY identifies `52.221.96.227` as its callback source. The merchant
  backoffice records MASTER7 outbound IP `74.220.52.132`; current Render egress
  must match an accepted merchant whitelist entry before activation.
- GSPAY+ DuitNow, USDT and payout remain separate and disabled.
- Manual company-bank deposit code supports bank images, member receipt upload
  and review. A real company account and one controlled review/ledger acceptance
  are still required.
- No payout provider has passed production acceptance.

## Games

- The customer lobby contains exactly 34 provider entries.
- Retained catalogue records total 766 across MegaH5, JILI, 918KISS H5,
  Rectangle and EVO888H5. EVO888H5 is stale and all-maintenance.
- JDB and Pragmatic Play reach their adapters but are rejected by the suppliers.
  ATG is mapped to its assigned direct source and currently has no accepted
  catalogue.
- Catalogue availability is not launch, wallet, wager or exit-settlement
  acceptance. Current playable count is zero.
- Game checks use four explicit states: complete, acceptance pending, waiting
  for supplier/maintenance, and confirmed supplier error. Retained catalogue
  counts remain visible without being reported as launch-ready.

## Domains

- `https://master7.best/` currently redirects to the Render portal.
- `www.master7.best` has no verified DNS and cannot yet be used as a direct
  return/callback origin.
- `master7.site` and `www.master7.site` currently redirect to `/admin`.
- A provider callback must terminate directly on the application or use a proxy
  proven to preserve POST method and body; a simple 302 forward is insufficient.
- The integration gateway is release `1.13.0`; its current browser origins and
  default game return route no longer use the retired `.vip` domains.

## Release validation

- Full Portal suite: 400/400 passed.
- Render database adapter: 3/3 passed.
- Gateway suite: 103/103 passed.
- Focused `.91` GSPAY bridge, routing and activation tests: 29/29 passed.
- Focused `.89` game-check status presentation tests: 6/6 passed.
- Focused `.88` payment-readiness and `.87` game/payment/UI release suites: passed.
- Render production build: passed.
- `git diff --check`: passed.
- No automated release check creates a real payment, game transfer, wager,
  wallet credit or payout.
