# MASTER7 current deployment handover

Date: 2026-11-10 UTC

Candidate release in this source tree:
`17.0.0-selfbuilt.145-payment-callback-evidence`

Current live release at candidate preparation:
`17.0.0-selfbuilt.144-sponsor-withdrawal-lobby`

Candidate deployment status: **NOT DEPLOYED**

Portal service: `srv-dbl0iv7f3r2c73848ei0` / `master7-v17-staging`

Render workspace: `tea-dakfo2h594qs73du231g` / ahbi

Publication branch: `codex/v17-render-staging-20261104`

Automatic deployment is off. A release is triggered and monitored manually
after archive replay and release-bound validation pass. The Render deploy ID and
post-deploy observations belong in the publication repository receipt.

## Candidate scope

- Records an idempotent callback receipt only after provider authentication and
  exact order/member/amount/currency/reference binding:
  `vpay_callback_authenticated`, `gspay_callback_received`, and
  `1mpay_callback_verified`.
- Callback receipt evidence explicitly does not claim provider payment success.
  Wallet completion still requires an independently verified provider result,
  credited order state and balanced member/provider-clearing ledger legs.
- Adds 1MPay to the Render environment allowlist adapter; missing values remain
  undefined and browser/BO-prefixed values are never forwarded.
- Extends owner deposit trace and read-only incident evidence to distinguish
  callback delivery from payment and wallet settlement.
- Adds evidence-only incident reports from the live `.144` encrypted snapshot.

The candidate does not change database schema, Render capacity, DNS, production
secrets, payment switches, payout switches, game switches, balances or orders.

## Current evidence boundary

- VPay remains **FAIL** at provider `ORDER_GET` signature validation until the
  provider confirms the active key/trader binding or unpublished production rule.
- GSPAY remains **NOT VERIFIED** until callback registration, stable outbound-IP
  authorization and one controlled production acceptance are completed.
- 1MPay remains **NOT VERIFIED**. The current database contains four orders and
  zero wallet-ledger rows; one provider reference has a bound query result of
  `Fail`, while three orders lack provider references.
- All three new-order profiles remain paused. This candidate does not authorize
  a real deposit, callback replay or wallet credit.

## Data protection and rollback gate

The current live `.144` release has a fresh encrypted transaction-snapshot
backup with 71 tables and 449 records. SQLite and isolated PostgreSQL 18 restore
rehearsals verified all records with zero foreign-key violations and no
persistent restore writes. Online health reports `backupReady=true` and
`restoreReady=true`.

Release `.145` has no migration. Preserve the deployed `.144` archive and its
post-deploy backup as the rollback references.

## Candidate validation status

The final frozen source passed all release validation:

- Full regression: 1,258 / 1,258
- Maintenance checks: 12 / 12
- Release probes: 27 / 27
- Render database tests: 3 / 3
- TypeScript, ESLint and Render build: PASS
- Failed, skipped, cancelled and todo tests: 0

The 437-file regression-frozen source manifest was unchanged before and after
validation, with SHA-256
`860617875e354cc93d221482fe3ec67fe32bb5cb3fcf8108d814921a8c44a9fd`.
This documentation-only result update was then applied before packaging.
Deterministic archive construction and clean-extraction replay remain the final
publication gate. This file does not assert that `.145` is live.
