# MASTER7 current deployment handover

Date: 2026-11-09 UTC

Candidate release in this source tree:
`17.0.0-selfbuilt.144-sponsor-withdrawal-lobby`

Current live release at candidate preparation:
`17.0.0-selfbuilt.142-acceptance-mobile-ui`

Candidate deployment status: **NOT DEPLOYED**

Portal service: `srv-dbl0iv7f3r2c73848ei0` / `master7-v17-staging`

Render workspace: `tea-dakfo2h594qs73du231g` / ahbi

Publication branch: `codex/v17-render-staging-20261104`

Automatic deployment: off. A release is triggered and monitored manually only
after the source archive, validation and migration backup gates pass.

No Render deploy ID is recorded here because this candidate has not been
deployed. The exact commit, archive SHA-256, Render deploy ID and post-deploy
checks belong in the publication repository's post-deploy receipt and must not
be invented inside the pre-deploy archive.

## Candidate scope

- Premium member home, mobile navigation, wallet actions, promotions and the
  JILI, MEGAH5 and 918KISS sponsored-provider presentation.
- Independent artwork coverage for all 37 registered game brands.
- Company Bank withdrawal with Bank Account or approved Malaysian E-Wallet
  destination. E-Wallet requests remain manual owner-reviewed transfers and do
  not invoke an automatic provider payout.
- Additive PostgreSQL migration
  `0119-withdrawal-destination-methods`, including encrypted E-Wallet
  destination fields and backward-compatible bank defaults.
- JDB production readiness is evaluated against the selected JDB profile's own
  acceptance capabilities. The approved JDB HTTPS origin comparison accepts a
  harmless trailing slash while continuing to reject credentials, non-HTTPS
  URLs, query strings, fragments and nonstandard ports.
- Read-only live-evidence audits for GSPAY MYR, 1MPay MYR and MEGAH5.

The candidate does not change Render secrets, DNS, service capacity or runtime
activation flags.

## Acceptance boundary

- Current evidence does not certify all games as production-playable.
- JDB remains externally blocked until supplier access and the required
  profile-specific launch, wallet, settlement, recovery and reconciliation
  evidence pass.
- GSPAY MYR and 1MPay MYR remain **NOT VERIFIED** for complete real-money
  production acceptance. Configuration or HTTP route evidence is not a
  reconciled provider payment.
- No new real deposit, payout, game launch, wager or wallet settlement is
  authorized by this software candidate.
- Production readiness remains subject to the existing fail-closed runtime
  controls and exact release-bound acceptance evidence.

## Migration and rollback gate

The pre-deploy data protection gate has passed for the exact current live
`.142` release:

1. The encrypted transaction-snapshot backup captured all 71 configured
   tables and 446 records.
2. SQLite and isolated PostgreSQL 18 restore rehearsals both verified all 71
   tables and 446 records with zero foreign-key violations and no persistent
   production writes.
3. The public evidence receipt is
   `MASTER7_V17_142_PREDEPLOY_BACKUP_RESTORE_20261109_MYT.json` (SHA-256
   `8f8fd166a2156a265caa7273fdf0963255a8b4a6a9ff9be67daf19fff7050fbd`).
4. Preserve the `.142` source archive as the code rollback reference.

Migration `0119` only adds columns and gives existing withdrawal rows the
`bank` destination default. A code rollback must preserve the migrated
database and its history; do not delete the new columns or transaction records.
After deployment, create new `.144` backup, restore and rollback evidence
before any production-readiness sign-off.

## Candidate validation status

- Release/version smoke: 22 / 22 passed after the final `.144` version bump.
- Focused JDB, withdrawal, sponsor, artwork and stale-fixture suites passed in
  their respective implementation reviews.
- Full regression: 1,246 / 1,246 passed.
- Maintenance validation: 12 / 12 passed.
- Release probes: 27 / 27 passed.
- Render database compatibility: 3 / 3 passed.
- TypeScript, ESLint and Render build passed.
- A deterministic clean archive extraction and replay remains the final
  publication gate; this record does not assert deployment.

This file is a pre-deploy handover. It must not be cited as proof that `.144`
is live.
