# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.151-megah5-safety`.

Baseline: live `17.0.0-selfbuilt.150-jili-safety`, deployment
`dep-dbpbei8m7kps73aejtrg`, publication commit
`6aed6a0eb0ba7b9af4893c1712310313be2a61c9`.

Legacy MegaH5 is now treated as a MegaH5 brand feed through the META GAMING
opgateway while its historic account remains isolated from the newer META
normal and free-credit profiles. The gateway strictly validates and projects
the 166-game catalogue, GameLogin, balance and transfer response boundaries.
Malformed success bodies, duplicate games, unsafe URLs, wrong currencies and
invalid transaction records fail closed. Raw supplier fields are no longer
returned to the portal.

The live feed currently supplies an unconfirmed schedule-shaped `Maintenance`
value. Version 151 marks every such title unavailable instead of guessing its
meaning. Portal GameLogin also requires a server-only list of exact
supplier-approved HTTPS launch origins; an empty or invalid list blocks before
wallet reservation or supplier traffic. These controls do not enable Play,
transfers, settlement or recovery.

META GAMING now has two isolated, read-only catalogue profiles for the Normal
MYR and Free Credit MYR accounts. Their gateway paths, cache keys, catalogue
account labels and player/ledger namespaces are separate. Both profiles remain
`adapter_unimplemented` and `playable=false`; this release does not enable a
launch, balance, transfer, settlement or recovery route. Remote META artwork is
not trusted until the supplier confirms an official image host, so the portal
uses the local provider artwork.

JILI now has a legacy transfer protocol, executable adapter, per-account runtime factory and the universal game-wallet API. Its 1:1 and 1:100 catalogues have separate cache keys and check the account, currency and ratio. Deposits are confirmed by querying the original account, transaction, direction and normalized amount. Returns use the supplier's all-funds transfer rather than a delayed balance. A zero return still needs a real supplier receipt. Every unverified nonzero submit result remains unknown and reserved; recovery queries the original transaction and never resubmits it. Launch authorization now also requires the exact customer return origin before any reservation or supplier call.

Migration `0120-provider-wallet-sweeps` adds immutable withdrawal-mode and adapter-contract fingerprints to operation rows. Existing operations default to their previous exact-amount protocol. Platform cash remains MYR sen; supplier units convert once at the adapter boundary. The backup schema is now 0120 and explicitly accepts 0119 archives. Restores include the new snapshots.

The executable protocol inventory is MegaH5, JDB and JILI (four listed account
profiles). Implementation counts are not playable-game counts. MegaH5 still
lacks an accepted production merchant binding, approved launch origins,
PullLog/FlagLog wager ingestion and a complete round-closure/finality process.
JILI's account units and closure finality remain unconfirmed. 918KISS and the
other merchant protocols remain unimplemented. JDB's last supplier response
was 9001.

There are 37 brand entries and 42 separate listed account profiles; production accepted profiles remain zero. No real game launch or real-money transfer occurred in this work. Payment work is paused; activation flags, credentials, pricing, instances and DNS are unchanged.

Deployment requires pre/post encrypted backups and isolated restore checks. Reverting to 147 is safe for this unactivated release only while no 148 sweep operation exists. Once sweeps exist, retain the 148-compatible recovery engine: an old engine does not understand them.

Portal service: `srv-dbl0iv7f3r2c73848ei0`.
Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Automatic deployment is off.
