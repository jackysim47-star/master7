# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.153-provider-catalogue-safety`.

Baseline live: `17.0.0-selfbuilt.152-918kiss-catalogue-safety`, deployment
`dep-dbpc5og8v5cc73drg1r0`, publication commit
`0d818b1dc829a82c251715f3f62a4d88c498916c`, source commit
`c59c6ba83c6d651d6dbb294f3d6f8fe056293fb2`, source archive SHA-256
`941240970673ac478ef2bac7ff74eea8b65c10e2263264428cb6baf44e92ee15`.

Gateway baseline: release `1.16.0`, deployment `dep-dbpc4du7bikc73ck6cmg`,
commit `1a682dfa9de3013ff44c7fd9364103134f95a44c`.

The candidate isolates EPICWIN Normal MYR and Free MYR catalogue paths,
profiles, cache keys, account labels and currency checks. Gateway catalogue
rows are bounded and strictly projected. Malformed, duplicate or oversized
responses fail closed, remote artwork is not published, and the portal retains
the last complete snapshot instead of accepting a partial refresh.

META GAMING Normal and Free Credit MYR remain isolated. Unknown title
availability is always suspended, and unapproved remote artwork is withheld.
The provider currently rejects both production catalogue accounts with HTTP
403, so no META title is treated as connected or playable.

JDB catalogue rows without an explicit availability signal now default to
maintenance. The provider currently rejects Action 49 with status `9001`, so
JDB remains disconnected and non-playable. JILI's implemented adapter is now
reported truthfully as awaiting both its incomplete provider contract and
production acceptance, rather than as an unimplemented adapter.

There are 37 lobby brands and 42 listed profiles. Production-accepted profiles,
launch-ready profiles and playable profiles remain zero. This release adds no
player, Play, wallet, transfer, settlement or recovery route for EPICWIN, META
or JDB and does not enable any real-money game switch.

Payment work remains paused. VPay, GSPAY and 1MPay code, credentials, callbacks,
activation flags, service plans and DNS are unchanged.

Portal service: `srv-dbl0iv7f3r2c73848ei0`.
Gateway service: `srv-db6b7inlk1mc73ck6cmg`.
Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Portal automatic deployment is off; gateway automatic deployment is on.
