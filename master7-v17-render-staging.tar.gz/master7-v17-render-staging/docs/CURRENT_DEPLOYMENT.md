# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.154-provider-boundary-safety`.

Baseline live: `17.0.0-selfbuilt.153-provider-catalogue-safety`, deployment
`dep-dbpcipbm8hqs73dhl2bg`, publication commit
`593a90c87386ca11337ecd23aada65083843117b`, source commit
`aeaaeaceb2897911fd7934693f55840ee29fd99c`, source archive SHA-256
`38c762a1b209f6a7eafb6d9165c7b4bb951af98e022fc303f5ec01b3639c5ac6`.

Gateway baseline: release `1.17.0`, deployment `dep-dbpchge417fc739h9b50`,
commit `c4aab70060439469f3c2e6081a57c0b40e630ff4`.

The candidate strictly validates and projects the EVO888H5, CLOTPLAY,
Pragmatic Play and Venus Gaming catalogue boundaries. Malformed, duplicate,
oversized or partial catalogue results fail closed. Unapproved remote artwork
and private supplier fields are withheld from the public gateway response.

Catalogue presence does not establish launch availability. EVO888H5,
Pragmatic Play and Venus Gaming titles remain maintenance because their
reviewed catalogue evidence contains no accepted per-title availability
signal. CLOTPLAY requires consistent pagination and treats missing maintenance
as unavailable.

Current supplier evidence remains externally blocked:

- EVO888H5 returns provider code `130`: Render egress IP not in whitelist.
- Pragmatic Play returns HTTP `435` before a JSON business response.
- CLOTPLAY returns HTTP `403`.
- Venus Gaming returns a catalogue body without the response-signature headers
  required by its official contract.

The Portal retains the last complete EVO snapshot, marks it stale and
maintenance, and exposes no Play action.

There are 37 lobby brands and 42 listed profiles. Production-accepted profiles,
launch-ready profiles and playable profiles remain zero. This release adds no
player, Play, wallet, transfer, settlement or recovery route and does not
enable any real-money game switch.

Payment work remains paused. VPay, GSPAY and 1MPay code, credentials, callbacks,
activation flags, service plans and DNS are unchanged.

Portal service: `srv-dbl0iv7f3r2c73848ei0`.
Gateway service: `srv-db6b7inlk1mc73ck6cmg`.
Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Portal automatic deployment is off; gateway automatic deployment is on.
