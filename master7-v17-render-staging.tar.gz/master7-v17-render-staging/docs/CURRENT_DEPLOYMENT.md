# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.147-game-runtime-repair`.

Baseline at preparation: `17.0.0-selfbuilt.146-member-front-clarity`, deploy `dep-dbp7pf8m7kps73a3oabg`.

This release repairs the shared game runtime: normalized MYR accounting supports registered 1:100 cash profiles; startup, wallet reads and recovery resolve compiled per-profile adapters; accepted JDB runtime observations reach health without requiring every other provider. MegaH5 verification reads durable evidence and a provider-bound closure interface can record closure receipts before one return and a zero-balance check. No production closure implementation is installed without the account-specific supplier contract.

The customer directory has one card for each of the 37 brands. Multiple account profiles remain separate in that brand's selector, player mapping and ledger. There are still 41 listed account profiles. Selecting a ready account never silently changes a member's ratio or account.

Current executable protocol inventory remains MegaH5 and JDB. JILI, 918KISS and other incomplete merchant integrations remain blocked; a readable catalogue is not game acceptance. JDB's latest server query was rejected with provider code 9001. New game, payment and payout switches remain unchanged. There is no schema, capacity, DNS, secret or customer balance change in this candidate.

Validation and live deployment evidence are recorded in the publication repository. Synthetic supplier tests are distinguished from actual merchant acceptance.

Portal service: `srv-dbl0iv7f3r2c73848ei0`.
Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Automatic deployment is off.
