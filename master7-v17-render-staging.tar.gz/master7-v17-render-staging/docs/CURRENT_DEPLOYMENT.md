# MASTER7 deployment handover

Candidate source: `17.0.0-selfbuilt.163-coba8-front-end-registered`.

This candidate has not been deployed by the source commit. Confirm the actual
Render release and deployment ID from the Portal service before cutover or
rollback. Portal service: `srv-dbl0iv7f3r2c73848ei0`.

The last recorded integration-gateway baseline remains release `1.17.0`,
deployment `dep-dbpchge417fc739h9b50`, commit
`c4aab70060439469f3c2e6081a57c0b40e630ff4`. Gateway service:
`srv-db6b7inlk1mc73ck6cmg`. The v163 candidate does not change the gateway.

## Current game registry

- The member lobby contains 38 distinct provider brands and 43 listed provider
  profiles.
- Implemented adapter profiles: 6.
- Launch-ready profiles: 0.
- Production-verified profiles: 0.
- Playable profiles: 0.

COBA8 is registered as the 38th member-facing provider and as the independent
`coba8_myr` profile. It uses neutral MASTER7-owned artwork. Its official API
contract is unavailable, so it remains `contract_missing` with no catalogue,
player, Play, launch, wallet, settlement or recovery capability. A merchant
login or API token cannot enable those capabilities and is not stored in this
release.

Existing owner-curated 37-provider rankings are migration input only: their
order is preserved and COBA8 is appended once. They do not describe the current
38-provider lobby.

Catalogue presence, credentials, HTTP success and an implemented adapter do
not establish launch availability. Production acceptance, runtime readiness,
exact launch-origin review, wallet handling, settlement and recovery remain
independent fail-closed gates.

## Other operational boundaries

Payment work remains paused. VPay, GSPAY and 1MPay code, credentials, callbacks,
activation flags, service plans and DNS are unchanged by v163. This candidate
does not enable any real-money payment, payout or live-game switch.

The source verification for v163 passed maintenance tests 12/12, release probes
27/27, full regression 1357/1357 and database compatibility 3/3. TypeScript,
lint and the Render build also passed.

Workspace: `tea-dakfo2h594qs73du231g`.
Publication branch: `codex/v17-render-staging-20261104`.
Portal automatic deployment is off; the recorded gateway automatic deployment
setting is on.
