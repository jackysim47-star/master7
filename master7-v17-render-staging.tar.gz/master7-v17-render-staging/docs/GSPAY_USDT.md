# GSPAY+ USDT profile

`gspay_usdt` is a separate, fail-closed payment profile. It does not reuse the
existing GSPAY+ MYR credentials, callback, wallet, reconciliation or payout.

The profile status is available at `GET /api/payments/gspay/usdt/status` after
the backend wires the profile context. Order, callback, query, recovery, wallet
credit and payout routes are intentionally absent in this release. Credentials
alone are not an API contract.

The profile remains unavailable until provider-controlled evidence fixes and
tests all of the following:

- API and checkout origins;
- USDT asset network and decimal scale;
- order, signature and response fields;
- callback authentication and source restrictions;
- query/recovery binding and terminal status rules;
- wallet atomic units and two-sided ledger posting;
- production minimum-amount deposit and reconciliation.

All `GSPAY_USDT_*` values belong in Render secrets. They have no fallback to
the MYR `GSPAY_*` variables. USDT payout remains outside this profile until a
separate payout contract and acceptance exist.
