# MASTER7 FREE / PAID game zones

Release: `17.0.0-selfbuilt.55-game-zones`

The owner backoffice can assign every supplier title to one of two customer
display zones:

- `PAID` is the safe default for every new or unmapped supplier title.
- `FREE` appears only after the owner explicitly selects it for that title.

The customer game lobby has `ALL GAMES`, `FREE` and `PAID` filters. Every tile
shows its current zone, while the existing HOT, SLOT, LIVE, FISH, COCK, SPORT
and FAV category filters continue to work independently. The lobby still loads
twelve titles at a time so a large supplier catalogue does not make the page
unnecessarily long or slow.

Zone assignment controls presentation and discovery only. It never changes a
supplier's launch readiness, wallet mode, wager rules, balance, or settlement
state. A FREE-labelled game remains unavailable until its supplier launch and
wallet acceptance gates are independently verified.

Only the owner can change a zone. Every change is saved in `game_visibility`,
validated to `free` or `paid`, and written to the audit log. Staff can inspect
the state without changing it.
