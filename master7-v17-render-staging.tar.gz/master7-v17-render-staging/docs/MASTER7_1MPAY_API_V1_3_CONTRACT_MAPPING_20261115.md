# MASTER7 1MPay API v1.3 official-contract mapping

This evidence note maps the recovered official document to the current code. It
contains no merchant credential, API key, bank account or production response.

## Source identity

- Title: `1MPay Payment Gateway API Specifications`
- Release: `1.3`
- Prepared by: `Yun Siong`
- Date: `2026-06-23`
- Original PDF: 16 pages, 298,953 bytes
- Original PDF SHA-256:
  `cb537c2f84ba049bfe371f7dcc81ed9fc191a6b1b4459e0bc6fa71ac707eeb4b`
- Recovery source: the Owner-supplied Library reference linked from the MASTER7
  working Page. The PDF itself is not copied into the source candidate.

## Contract-to-code mapping

| Official v1.3 requirement | Current implementation | Verification |
|---|---|---|
| `POST /fundtransfer/json` | `lib/onempay.ts` `createOneMpayOrder` | `tests/onempay.test.mjs` |
| Required create fields | All nine required fields are posted; `bankcode` remains optional | exact request-field assertion |
| Create token: Base64 raw SHA-256 | `oneMpayOrderToken` | independent token formula test |
| Signed callback fields | callback validates merchant, amount, refid, customer, trxno and token | negative binding/signature tests |
| Late corrected callback after initial timeout/failure | existing durable order remains recoverable | late-success and recovery tests |
| `GET /transquery/{trxno}/{base64_token}` | independent status query before wallet credit | query path assertion |
| Query token is Base64 of callback token | `settle`, read-only evidence and recovery paths | double-Base64 assertion |
| Successful credit once only | balanced member/provider-clearing legs with idempotency guards | duplicate/concurrency tests |
| `/payout` | intentionally never invoked in Phase 1 | payout capability remains disabled |

## Evidence that is still missing

- Exact callback acknowledgement body expected by the active merchant contract.
- Active merchant/UAT account authorization and test balance.
- Registered callback and return URLs in the supplier back office.
- Supplier IP whitelist evidence.
- Official UAT create/callback/query records and supplier acceptance.
- External 1MPay statement sample and statement-to-ledger reconciliation.

Therefore this mapping changes the protocol-document status from `MISSING
EVIDENCE` to `RECOVERED AND CODE-MAPPED`. It does **not** change 1MPay official
UAT from `NOT TESTED`, payment acceptance from `0/3`, or production from
`NO-GO`.
