# MASTER7 提款记录与当前边界

更新时间：2026-11-06 21:09 MYT
适用版本：`17.0.0-selfbuilt.69-payout-safe-support`

## 已实现

- 只有已批准 Member 可以提交 MYR 提款。
- 支持 18 家马来西亚银行；完整户名和账号以 AES-256-GCM 加密，会员记录只显示尾四位。
- 提交前强制检查游戏钱包已结清、没有另一笔处理中提款，以及会员可用余额足够。
- 幂等键和指纹防止重复请求；数据库原子锁保证并发请求只有一条能够调用厂家。
- 不确定的网络超时保留余额预留并进入 `processing`；恢复任务只查单，绝不重发出款。
- Owner 可以查看完整提款记录；Staff 不能查看完整银行资料。Owner 只可取消/拒绝尚未提交厂家的 `pending` 记录。

| 用途 | 路径 | 当前行为 |
|---|---|---|
| 银行与 provider 列表 | `GET /api/withdrawal-banks` | 返回 VPay、GSPAY、1MPay 的真实能力状态；前台只显示 `enabled=true` |
| 会员记录 | `GET /api/withdrawals` | 本人最近 100 条及钱包状态 |
| 会员提交 | `POST /api/withdrawals` | 只允许已完整配置并受数据库开关控制的 payout provider |
| 后台记录 | `GET /api/admin/withdrawals` | Owner 只读，最多 500 条 |
| 取消未提交记录 | `POST /api/admin/withdrawals/status` | 只允许 `pending` 转 `rejected` / `cancelled`，并释放预留余额 |

## 三家公司的真实状态

- **VPay**：只有充值程序，没有已验证 payout 合约，提款保持关闭。
- **1MPay**：只有充值程序；单独公钥不足以完成查单、callback 和结算，提款保持关闭。
- **GSPAY**：Payout 程序已实现，包括建单签名、callback 验签、独立查单、全字段绑定、预留、失败释放和幂等恢复。生产开关默认关闭，资料不齐时不会显示给会员，也不会调用真实出款。

GSPAY 正式开启仍要同时满足：准确的生产密钥、厂家确认的固定出站 IP 白名单、18 家银行的完整 `bank_target` 对照、安全加密密钥、活跃 GSPAY 渠道、独立 payout 环境开关及数据库开关。所有条件完整后还需 Owner 安排一笔受控真实验收。
