# VPay and GSPAY MYR recovery candidate

Local candidate: `17.0.0-selfbuilt.108-payment-recovery`. This version is
not deployed and does not prove any actual payment or historical incident.

- A trusted, order-bound VPay callback can preserve a missing provider
  reference before the independent query. A timeout remains uncredited and
  eligible for recovery. A late create response or rejection cannot overwrite
  a callback-bound reference or incorrectly declare that order failed.
- Stale `creating` orders with a provider reference can be queried after
  60 seconds. GSPAY MYR can also query a stale `unknown` or `creating`
  order by platform transaction ID when its provider reference is missing.
  These queries never create a new order.
- Recovery candidates are restricted to MYR. GSPAY rejects an explicit
  non-MYR query response, and VPay/GSPAY wallet writes require the current
  order currency to be MYR. The separate USDT adapter remains unimplemented.
- Independent status, reference, member, amount and ledger checks still apply.
  A valid notification or saved reference is not payment acceptance.

## Verification and rollout

`scripts/verify-isolated-postgres-payments.mjs` exercises synthetic VPay,
GSPAY MYR and 1MPay callbacks/recovery on actual PostgreSQL. It refuses any
target except a fresh empty loopback database named
`master7_v16_recovery_test`, with an explicit confirmation environment
variable. Run with Node's `--experimental-transform-types` flag. It does not
contact providers or use real member data.

Before deployment, inspect effective recovery switches and pending orders.
Enabling recovery can query and credit existing orders that a provider
independently confirms as paid. Production deployment, real-money acceptance,
backup/restore and the owner-reported historical payment remain unverified.
