# MASTER7 游戏供应商资料核对：第 4–13 家（已脱敏）

日期：2026-11-06（MYT）
范围：GAMEPLAY、LION KING、SUNCITY、PGSOFT、GFG/G4、SA GAMING、PS9、DRAGOONSOFT、JDB、BG。
安全边界：本次只读取用户提供的附件与附件明确引用的官方文档；没有调用任何生产 API、没有创建玩家、没有启动游戏、没有转账或下注。本文不包含账号、密码、token、密钥、AES 参数或后台登录资料。

## 结论

这 10 家中，**JDB** 的附件与官方 transfer-wallet 文档已足够开始协议层 adapter 和离线 contract tests；仍需白名单、权限与 UAT 验收后才能上线。

其余 9 家目前主要只有生产凭证或配置交接，缺少可执行的完整 API 合同。凭证存在不能证明游戏目录、玩家、启动、钱包、回调或结算已经接通。

GFG/G4 与 SA GAMING 属于同一个 `336699` API 家族；它们可在取得完整厂家 API 手册后共用一套协议 adapter，并各自使用独立 provider profile。现有表格只有凭证字段和主机资料，不能据此猜签名或请求格式。

## 逐家矩阵

符号：✅ 文档足够开始实现；🟡 有线索或主机，但合同不完整；❌ 附件没有该能力合同。

| # | 供应商 | 已核实主机（仅 hostname） | 钱包模式 | 目录 | 玩家 | 启动 | 余额/转账 | 回调 | 报表 |
|---:|---|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| 4 | GAMEPLAY INTERACTIVE | `api.gp.gsoft888.net`、`launch-gp.gsoft888.net`、`gpbo.gsoft688.com` | 未正式说明 | ❌ | ❌ | 🟡 只有 launch host | ❌ | ❌ | ❌ |
| 5 | LION KING | `api.sungaming.games`、`www.lkagent.cc`、`dl.lk4u.xyz` | 未说明 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| 6 | SUNCITY | `mcsc-api.gopigeon888.com`、`mcsc-bk.goseagull888.com` | 未说明 | ❌ | 🟡 只有玩家前缀资料 | ❌ | ❌ | ❌ | ❌ |
| 7 | PGSOFT | `www.pgs-bo.com` | 未说明 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| 8 | GFG / G4 | `gsmd.336699bet.com`、`fetch.336699bet.com`，另有独立 BO host | 未说明 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| 9 | SA GAMING | `gsmd.336699bet.com`、`fetch.336699bet.com`、`bop.sa-bo.net` | 未说明 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| 10 | PS9 | `transfer.ps9games.com`、`admin99.ps9games.com` | Transfer wallet | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| 11 | DRAGOONSOFT | `api.sysonline.club`，另有 `aggp.ds1fv.fun` 子域 BO host | 未说明 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| 12 | JDB | `api.datgeni2e47.net`、`agent.datgeni2e47.net`；文档 host `doc.jygrq.com` | Transfer wallet | ✅ 静态游戏/供应商附录 | ✅ | ✅ | ✅ | ❌ 未提供 push/webhook 合同 | ✅ |
| 13 | BG | `n1api.linirn.com`、`n1api.trarot.com`，另有独立 BO host | 未说明 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |

## 逐家资料与缺口

### 4. GAMEPLAY INTERACTIVE

附件是生产凭证 PDF，包含 operator、currency、API host、launch host、BO host 与已订阅游戏等配置。附件提到生产测试应限制转账金额，但没有正式声明钱包模式。

缺少：endpoint path/method、请求与响应 schema、签名公式、玩家建立规则、余额与转账幂等、转账补查、游戏目录、启动参数、callback/rollback 及报表合同。

### 5. LION KING

附件是申请/凭证 workbook，包含生产 API host、BO host、下载 host、currency、账号序号、API secret 字段和 API-call IP 资料。

缺少：钱包模式、API 方法、签名串拼接规则、目录、玩家、启动、余额、转账、回调、错误码及报表合同。不能仅凭 secret 字段推断签名算法。

### 6. SUNCITY

附件是简短生产配置，包含 API host、BO host、商户资料、玩家账号前缀及后台/网吧管理资料。

缺少：钱包模式、endpoint、签名/加密、目录、玩家建立、启动、余额、转账、补查、回调与报表合同。

### 7. PGSOFT

附件只有 BO host、operator code/token、secret 字段、currency 和登录资料；没有 API base 或 launch host。

当前 gateway 虽保留 `/callbacks/pgsoft` 路由外壳，但 POST 固定返回 `CALLBACK_CONTRACT_NOT_ACTIVE`，它不是已接通的 PGSOFT callback。

缺少：官方 API/launch host、钱包模式、所有 endpoint/schema、签名公式、callback acknowledgement、重试/rollback、错误码与报表合同。

### 8. GFG / G4

附件属于 `336699` 家族，包含 provider code、operator code、secret 字段、currency、API host、日志 host 与独立 BO host。

缺少：完整 `336699` API 手册、钱包模式、endpoint/method、签名 canonicalization、目录、玩家、启动、余额、转账、callback、错误码、日志查询和报表 schema。

### 9. SA GAMING

附件与 GFG/G4 使用同一套 `336699` 凭证模板和 API/日志主机，另有 SA 的 BO host。它可与 GFG/G4 共用未来的协议 adapter，但必须保留独立 provider code/profile。

缺口与 GFG/G4 相同；现有 workbook 不能直接生成请求或通过验签。

### 10. PS9

附件明确写明 transfer wallet、MYR、API host、BO host、agent 与 token 字段。

缺少：endpoint path/method、请求/响应 schema、token 使用方式、签名/加密、玩家建立、游戏目录、启动、余额、deposit/withdraw、transaction query、callback、错误码与报表合同。不得在没有手册时向 transfer host 试请求。

### 11. DRAGOONSOFT

附件包含 API/BO 主机、agent、MYR、AES key 字段、sign key 字段与密码。表格标签提到 payload AES encryption 和 MD5 signing，但没有足够算法细节。

缺少：AES mode、IV、padding、字符编码、Base64/URL 编码规则、MD5 拼接顺序/canonicalization、timestamp/nonce、endpoint、钱包模式、目录、玩家、启动、余额、转账、补查、callback 与报表合同。

### 12. JDB

附件明确为 transfer wallet、MYR，并引用官方 transfer 文档。核对到的官方文档版本为 **3.93.1**：

- transport：`POST /apiRequest.do`；
- body：JSON，包含 `dc`、加密后的 `x`，以及按合同需要的 `parent`；
- `x`：业务 JSON 经 AES-CBC-128 加密后再作 Base64 URL encoding；请求有效期约 30 秒；
- Action 12：创建玩家；
- Action 11：取得游戏启动 URL；
- Action 15：玩家/余额查询；
- Action 19：deposit/withdraw；
- Action 55：转账结果补查；
- Actions 29/64：明细报表；
- Action 42：日报；
- Action 54：游戏结果；
- 官方资料另含静态游戏与供应商附录。

因此 JDB 可以开始独立 adapter、加解密测试、schema validation 与幂等状态机。生产启用前仍缺：厂家确认的出口 IP 白名单、生产 AES 参数/`parent` 规则、游戏权限清单、允许的零资金或 UAT 账号，以及 callback 模式确认。现有资料没有 push callback/webhook 合同，应先按 transaction query 与报表做补查设计，不能自行发明 callback。

### 13. BG

附件给出两个生产 API base 及 BO 资料，字段包括 ID/key/API key。

缺少：钱包模式、endpoint/method、签名公式、目录、玩家、启动、余额、转账、补查、callback、错误码与报表合同。两个 API base 的主备/区域选择规则也需厂家确认。

## 当前 MASTER7 源码状态

- Portal 的 catalogue source inventory 目前没有这 10 家的目录 adapter。
- Portal 没有这 10 家的玩家、启动、钱包或结算 dispatcher。
- PGSOFT 只有一个 fail-closed callback 路由外壳；POST 明确返回 503，不能计作 connected。
- 因此这 10 个品牌按钮目前只能作为独立供应商入口/状态项；在对应 adapter 与生产验收完成前不能显示“可玩”。

## 可直接发给厂家的资料请求

除 JDB 外，每家至少需要提供：

1. 当前生产与 UAT API 文档版本、base URL 与 endpoint 清单；
2. 钱包模式（transfer/seamless）及 MYR precision；
3. 玩家创建/登录、游戏目录、game launch、余额、资金/下注接口的完整 request/response schema；
4. 签名/加密公式、字段排序、编码、timestamp/nonce 与重放限制；
5. transfer 的唯一 transaction ID、超时补查、重复请求与回滚规则，或 seamless 的 bet/settle/rollback/cancel 幂等规则；
6. callback URL、验签、重试、成功 acknowledgement 与允许来源 IP；
7. 报表/对账接口、错误码表、maintenance 状态与限流；
8. MASTER7 的固定出口 IP 白名单确认、已授权 provider/game 清单与 MYR UAT/零资金验收账号。

JDB 只需补齐生产白名单、权限、`parent`/加密参数适用规则、callback 模式与 UAT 验收材料；无需重复索取已有的 v3.93.1 transfer API 合同。
