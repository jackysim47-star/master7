# V170 Manual Bank Payout Atomicity

Release: `17.0.0-selfbuilt.170-manual-bank-payout-atomicity`

## Change

Manual Company Bank payouts now require the complete bank transaction and audit
evidence chain before a provider payout can become `succeeded`, a withdrawal can
become `paid`, or its wallet reservation can be released.

The payout-start audit is created before the provider and withdrawal move to
`processing`. Its identifier is bound to a fresh authorization value. A primary
key collision therefore leaves the provider `prepared`, the withdrawal
`approved`, and the full wallet hold intact so the operation can be retried.

The paid audit also uses a fresh identifier. Evidence is accepted only when
exactly one audit row matches the bank transaction's event, target and recording
user, and that audit timestamp equals the bank transaction timestamp. A missing,
duplicated or conflicting receipt fails closed and never releases the hold.

## Retry and recovery behavior

An identical confirmation reuses the existing bank transaction. If a paid-audit
identifier collides with an unrelated row, the first request moves the payout to
review and keeps the withdrawal and hold unchanged. A later request with the
same evidence can create a new audit identifier and finish exactly once.
Different bank evidence remains a conflict and cannot debit or release funds.

The confirmation route can also repair the legacy partial state where the
provider payout is already `succeeded/accepted` but the withdrawal remains
`processing` and its wallet reservation remains held. Repair is allowed only
when the existing bank transaction, provider reference, amount, currency,
account, reference, proof hash and occurrence time all match. It attaches the
missing unique audit evidence, completes the withdrawal, and releases the hold
once. Any mismatch remains blocked for reconciliation.

## Verification

- targeted SQLite manual-bank suite: 19/19 passed;
- related regression checks: 74/74 passed;
- full regression: 1,412/1,412 passed;
- isolated PostgreSQL 18 manual-bank suite: 6/6 passed, including concurrent
  confirmation, legacy deterministic audit-ID collisions, and rollback-only
  backup/restore verification;
- TypeScript, lint and diff checks passed;
- independent review found no blocker.

## Scope

- no schema migration, table, column or backup-contract change;
- latest migration remains `0123-guard-function-schema-binding`;
- backup schema remains `0122-acceptance-ledger-integrity` with 76 tables;
- no live payment-provider, game-provider, customer-money or wallet call was
  made during validation;
- new deposits, new payouts, new game launches, real payments, live games and
  production readiness remain disabled pending external acceptance.
