# MASTER7 MYR deposit batch

The production portal enables the batch with `MYR_DEPOSIT_BATCH_ENFORCED=true`. VPay, GSPAY and 1MPay share this admission rule for new orders. Use the Payment channels panel or GET `/api/payments/myr-batch/status` to see the passed count and batch state. `/uat-preview` refreshes every two minutes. The portal process checks the same status every two minutes and logs aggregate changes independently of recovery.

## Provider verification

- **VPay** confirms the MASTER7 MYR Order and Deposit Query API allowlist for the Render gateway ranges `74.220.52.0/24` and `74.220.60.0/24`. Then verify a deposit.
- **GSPAY** confirms the approved MYR test procedure. Configure the relevant order and signing credentials in the approved environment before the test.
- **1MPay** supplies an approved successful test. Match the provider's signed callback and independent lookup to the portal order and credit.

Use one redacted evidence bundle per provider for all six production capabilities in the existing acceptance console. Record the same reference and SHA-256 for order, payment, callback, query/recovery, wallet credit and merchant settlement. Match the portal order, provider reference, MYR amount and exactly one member credit. Current domain evidence, the three payment credential records and existing release signoffs, including the rehearsal for this release must pass before the batch opens.

## Controlled tests before opening

The Owner's Payment channels panel can issue or revoke a one-order authorization. Select the provider, an approved test member ID, the agreed amount, 1–60 minutes of validity and a reference to the provider's approved test. For VPay also select the agreed trade code.

The authenticated test member uses the corresponding existing `POST /api/payments/{provider}/orders` route with the issued `requestKey`, the exact approved `amount` in MYR, and normal provider fields. VPay uses the approved `tradeCode` and the usual payer field. Preserve the current Origin and CSRF requirements. The request key is idempotent and applies only to that member and provider. The Owner route `POST /api/admin/myr-deposit-test` accepts `providerId`, `memberId`, string `amountMinor`, Unix-seconds `expiresAt`, `evidenceReference` and VPay's `tradeCode`. Revocation takes `providerId` and `revoke: true`.

Provider and maintenance controls apply during tests. A controlled order cannot override a paused channel or unconfigured provider. Keep the request key within the authorized test team.

## Pausing and recovery

Pause any of the three with the existing Owner deposit controls to pause all new MYR batch orders, including tests. Queries, signed callbacks, existing order recovery and wallet credits stay available. Before rolling back to a release without batch enforcement, use the Owner controls to pause all three individually. Confirm their deposit status routes report new ordering unavailable before changing the release.
