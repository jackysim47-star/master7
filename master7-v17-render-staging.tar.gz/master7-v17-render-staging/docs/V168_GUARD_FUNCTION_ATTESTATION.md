# V168 Guard Function Attestation

Release: `17.0.0-selfbuilt.168-guard-function-attestation`

## Change

Portal startup and the external PostgreSQL readiness gate now use one frozen
contract for the five unique functions behind the nine protected database
triggers. The contract verifies the canonical SHA-256 of `pg_proc.prosrc` and
the function schema, name, identity arguments, language, trigger return type,
kind, volatility, parallel safety, security mode, leakproof flag, strict flag,
set-returning flag and per-function configuration.

Migration `0123-guard-function-schema-binding` performs the one-time v168
upgrade of all five guard functions. It pins each function to
`search_path=pg_catalog, pg_temp`; the four acceptance functions resolve their
ledger tables through `TG_TABLE_SCHEMA` and identifier-quoted dynamic SQL.
This prevents a session-local `pg_temp` table from shadowing the protected
ledger while preserving production and custom restore schemas.

The attestation also verifies that each trigger has no `WHEN` clause, no
arguments, no transition tables, no constraint binding and no parent trigger.
The existing enabled state, event shape, table binding, function binding and
update-column checks remain active.

Function source canonicalization changes CRLF line endings to LF and trims
outer whitespace only. Every internal source byte remains part of the hash.
Schema binding remains relative to the table schema during startup, so an
isolated restore rehearsal can use its custom schema. The external readiness
gate continues to require the production `public` schema.

## Failure behavior

Attestation runs after migration `0123-guard-function-schema-binding` and before
directory seeding and `COMMIT`. The 0123 upgrade creates the hardened function
definitions once. After its migration marker exists, any function-body,
function-metadata or trigger metadata drift aborts startup and rolls back the
transaction without replacing or repairing the drifted definition.

The PostgreSQL 18 isolation suite replaces an expected function body under the
same name, changes security/configuration/volatility metadata, and adds trigger
`WHEN` and argument drift. Each case must fail closed, remain drifted after the
failed startup, be explicitly restored, and then pass attestation. It also
proves that an extra differently named trigger is rejected and that a `pg_temp`
shadow ledger cannot redirect the acceptance guards.

## Provenance and scope

The previous `0120` definition originated in baseline commit `fb9c96d`; the
previous `0122` definitions originated in the v165 commit `091507b`. Historical
0122 stays unchanged. Migration 0123 updates the four acceptance function
bodies and fixes `proconfig` on all five functions while preserving their guard
rules.

- no table, column, backup format or backup data-contract change;
- the required migration set adds 0123, while the backup manifest/schema
  version remains `0122-acceptance-ledger-integrity` with 76 tables;
- no payment, payout, wallet, game-provider, DNS, credential, plan or
  production-control change;
- no live provider or customer transaction calls during validation.
