# MASTER7 payout protection candidate .110

This local candidate builds on v17 `.109-transaction-consistency`. It does
not change a production service or prove actual bank transfer completion.

- VPay and GSPAY payout finalization checks the provider and withdrawal binding
  and reserves, uses guarded transitions and reads back the committed state.
- A failed, reversed or contradictory provider observation goes to review; a
  pending withdrawal is held and a paid withdrawal remains debited. Status
  queries with missing or contradictory fields are not treated as failures.
- Owner cancellation of a never-submitted withdrawal and the adapter's claim
  serialize on the same payout record. Missing legacy payout evidence,
  mismatched reservations, and historical state conflicts require review.
- Wallet availability fails closed when payout/withdrawal history is
  inconsistent. No historical orders or balances are automatically rewritten.

## Operational restrictions

Provider failures no longer automatically release funds: this intentionally
changes the behavior of recovery of already submitted transactions. Before any
deployment, inventory effective flags and outstanding records and establish a
manual, audited reconciliation process; otherwise members may remain held.

The wallet availability check and creation of a new financial reservation are
not coordinated with all concurrent risk changes through a common member lock.
The code does not establish safe resolution for already released legacy payouts
or reverse spending already in flight. Account-level guard/hold design, all
financial exit paths, historical case reconciliation and true provider
acceptance remain required. Do not use this candidate as approval to enable
real payouts. All production changes and real-money tests remain unperformed.
