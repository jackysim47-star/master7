# MASTER7 V17.160 META GAMING Adapter Candidate

Release: `17.0.0-selfbuilt.160-meta-gaming-adapter`

This release adds isolated, disabled-by-default META GAMING runtime support for `metagaming_normal_myr` and `metagaming_free_myr`. The portal and gateway preserve profile, account, player, ledger and peer-token isolation for player, launch, balance, transfer, status, session, unfinished-report and report-acknowledgement operations.

All META runtime capabilities remain closed until their matching gateway flags, provider authorization, amount semantics, session finality, report acknowledgement and controlled UAT evidence are complete. This release does not make either profile launch-ready, verified or playable.
