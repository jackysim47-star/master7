# MASTER7 encrypted backup and recovery

Release `17.0.0-selfbuilt.53-encrypted-backup` adds an owner-only logical backup for the MASTER7 portal database.

## Backup format

- Format: `MASTER7-ENCRYPTED-BACKUP-1`
- Content encryption: AES-256-GCM with a fresh random key and IV per backup
- Key wrapping: RSA-OAEP-SHA256 with the MASTER7 recovery public key
- Compression: gzip before encryption
- Integrity: SHA-256 for ciphertext, plaintext and each table
- Scope: 30 application tables used to restore members, credentials, referrals, payment and wallet records, operations, content, audit history, settings and cached provider catalogue data
- Session policy: password sessions, OTP challenges and rate-limit buckets are excluded. All users must sign in again after a restore.

The private recovery key and its passphrase are stored outside the source tree and deployment archive. Only the public key is deployed. A stolen deployment therefore cannot decrypt an exported backup.

## Create a backup

An approved owner can use **System readiness → Create encrypted backup**. The server reads the database, encrypts the payload before returning it, records `encrypted_backup_created` in the audit log and downloads a JSON envelope.

The same operation is available through `POST /api/admin/backup` with the owner's authenticated session, CSRF token and body:

```json
{"action":"create"}
```

Store the downloaded envelope, encrypted private key and passphrase in separate controlled locations.

## Verify and rehearse recovery

Run the verifier in a controlled non-production workspace:

```bash
node scripts/verify-encrypted-backup.mjs \
  /secure/path/master7-encrypted-backup.json \
  /secure/path/master7-backup-private.pem \
  /secure/path/private-key-passphrase.txt \
  /secure/path/master7-restore-receipt.json
```

The verifier checks every cryptographic hash, decrypts and decompresses the payload, builds a clean database from the current migrations, restores all 30 tables, compares every row count, runs foreign-key validation and confirms the excluded authentication tables remain empty. The receipt contains hashes and counts only; it contains no customer rows or credentials.

After a successful independent rehearsal, the owner records the receipt through `POST /api/admin/backup` with `action: "record_rehearsal"`. The System readiness page then shows both backup and recovery rehearsal as ready.

## Render database protection

Render PostgreSQL automatic backups and recovery retention depend on the database plan. This encrypted logical backup is an independent application-level copy. Keep both layers enabled and perform a restore rehearsal after schema changes and on a regular operations schedule.
