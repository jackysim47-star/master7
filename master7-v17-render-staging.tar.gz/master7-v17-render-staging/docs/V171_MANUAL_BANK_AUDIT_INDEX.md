# V171 Manual Bank Audit Evidence Index

Release: `17.0.0-selfbuilt.171-manual-bank-audit-index`

## Change

Migration `0124-manual-bank-audit-evidence-index` adds the non-unique partial
index `audit_manual_bank_payout_paid_evidence` to the audit table:

```sql
CREATE INDEX IF NOT EXISTS audit_manual_bank_payout_paid_evidence
  ON audit(target,user_id,created_at)
  WHERE event='manual_bank_payout_paid';
```

Manual-bank payout verification always filters on the literal
`manual_bank_payout_paid` event before it matches the transaction target,
recording user and timestamp. The partial index therefore covers the evidence
count and exact-timestamp lookups while excluding unrelated audit events. This
avoids full audit-table scans as the operational history grows and limits the
write cost to the relevant paid-evidence rows.

## Integrity behavior

The index is deliberately non-unique. The payout evidence logic treats a
duplicate paid audit as conflicting evidence and fails closed for review.
Enforcing uniqueness at the database layer would change that behavior into a
constraint error, could prevent migration on a database that already contains
duplicate evidence, and would remove the application's ability to report the
corruption explicitly. The index improves lookup performance without weakening
or replacing the existing exact-cardinality checks.

## Verification

- SQLite query-plan checks confirm that both paid-evidence queries use the
  covering partial index instead of scanning the audit table;
- isolated PostgreSQL 18 catalog checks confirm the index is non-unique,
  partial, and ordered as `target,user_id,created_at`;
- the Render startup migration creates the index and records migration `0124`
  exactly once, with a second startup remaining idempotent;
- readiness validation requires the new migration marker after migration
  `0123-guard-function-schema-binding`;
- targeted migration, readiness and query-plan checks passed 23/23;
- SQLite manual-bank checks passed 19/19 and isolated PostgreSQL 18
  manual-bank checks passed 6/6;
- backup/report checks passed 19/19, Render database checks passed 3/3,
  maintenance checks passed 12/12 and release probes passed 27/27;
- TypeScript, lint and diff checks passed.

## Scope

- no application business state, payment status, wallet balance, reservation
  or ledger row is changed;
- no deposit, payout, game-launch, real-payment, live-game or production-ready
  flag is changed;
- no table or column is added, removed or rebuilt, and the database table count
  remains 76;
- backup schema remains `0122-acceptance-ledger-integrity`; the encrypted
  backup format and backup table inventory are unchanged;
- critical database guard attestation remains 9/9 triggers and 5/5 functions;
- validation made no live payment-provider, game-provider, customer-money or
  wallet call;
- this release is a staging candidate and is not production live.
