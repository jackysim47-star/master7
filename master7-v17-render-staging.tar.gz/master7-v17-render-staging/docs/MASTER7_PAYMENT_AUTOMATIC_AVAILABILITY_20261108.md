# MASTER7 automatic deposit availability

This change removes the portal's duplicate manual availability controls for customer deposits. The existing vendor API addresses, request parameters, signatures, callbacks and order/ledger safeguards are unchanged. It does not configure production services or certify settlement.

## Customer and backoffice behavior

- VPay deposit availability requires complete local configuration and the existing authenticated gateway configuration contract: provider, environment, merchant, callback/return URLs, payment readiness and supported trade codes must match.
- GSPAY and 1MPay deposit availability follows complete configuration. Their available documentation does not supply a separate, non-transactional connection probe. The API therefore reports `availabilityBasis: configuration`; this is not a claim of verified vendor connectivity or settlement.
- Legacy `*_ORDERS_ENABLED` values and `payment_channel_controls.status` no longer restrict new deposit orders. They are retained for compatibility and historical data; they do not require an operator action.
- Provider status, health and public/admin channel listings use the same deposit capability calculations. They return `availabilityMode: automatic`, `readOnly: true`, an explicit `availabilityBasis`, and a `reason`. Compatibility status fields are derived from current availability, not the old database control.
- The old admin channel mutation endpoint returns HTTP 405 and `PAYMENT_AVAILABILITY_AUTOMATIC` after authentication, approval, Origin, CSRF and owner checks. It performs no database writes, including rate-counter writes.
- Only approved members can create customer deposits. Amount/currency validation, ownership, responsible-play limits, request throttling, signature checks, independent reconciliation and idempotent ledger writes remain in force. Backoffice deposit records stay read-only.
- `verified` and `settlementVerified` remain false without actual acceptance evidence. Payout, balance and recovery controls are unchanged.

## Remaining payout and balance boundaries

- VPay payout already has a portal adapter; its separate payout credentials/configuration and submission controls are preserved. Portal balance remains unimplemented. An existing gateway snapshot contains an admin-only `/admin/vpay/balance` route calling `TRADER_BALANCE`; this alone does not establish a validated portal response contract or justify sharing a broad gateway admin credential.
- GSPAY payout and balance adapters already exist. Payout requires exact vendor `bank_target` mappings for the current 18 supported banks, confirmed server IP authorization, credentials, withdrawal-data protection and its existing submission controls. The supplied payout screenshots document the `bank_target` field, but the reviewed material did not establish the complete merchant-specific mapping. Values must not be inferred from another provider's bank codes.
- The supplied `1mpay (9).pdf`, API Specification 1.3 dated 23 June 2026, includes payout creation, bank codes and envelope encryption in section 9 (pages 11–15). It does not document a merchant-balance query. It does not explicitly establish payout callback/query final-state semantics, ambiguous submission recovery without `trxno`, or whether deposit sections 7–8 apply unchanged to payouts. The portal therefore retains its unimplemented payout/balance capability rather than inventing those contracts.

All validation for this change uses synthetic responses and isolated SQLite databases. No real customer order, payout, wallet transfer or provider acceptance is performed.
