# MASTER7 v154 supplier catalogue boundary safety release

Release: `17.0.0-selfbuilt.154-provider-boundary-safety`

This release hardens the read-only catalogue boundary for EVO888H5, CLOTPLAY,
Pragmatic Play and Venus Gaming.

- EVO validates the response envelope, game IDs, names, duplicates and maximum
  size, hides raw provider bodies and keeps unknown title availability closed.
- CLOTPLAY validates pagination, row fields, duplicates, maximum size and exact
  page completeness. Missing maintenance stays closed.
- Pragmatic Play no longer treats catalogue presence as proof that a title is
  available.
- Venus Gaming titles remain maintenance and unapproved remote thumbnails are
  withheld.
- The Portal keeps EVO titles suspended and preserves the last complete
  snapshot when a malformed refresh is received.

The suppliers remain blocked externally: EVO code 130, Pragmatic HTTP 435,
CLOTPLAY HTTP 403 and missing Venus response-signature headers. These conditions
cannot be bypassed safely and no Play action is exposed.

No player, launch, balance, wallet, transfer, settlement, recovery or payment
operation is enabled by this release. VPay, GSPAY, 1MPay, payment switches,
credentials, service plans and DNS are unchanged.
