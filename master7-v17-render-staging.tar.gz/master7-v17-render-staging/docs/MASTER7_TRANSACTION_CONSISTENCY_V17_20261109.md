# MASTER7 transaction consistency candidate .109

This local candidate is based on v16 `.108-payment-recovery`. It does not
change production configuration or certify any provider.

## GSPAY MYR deposit order creation

A provider create response may race a callback or recovery. After the
conditional update, re-read the order and only return the checkout URL if
the status, provider reference, URL and expiry match the response. A credited
order requires a verified ledger; all other outcomes require confirmation.

## MegaH5 game wallet

A stale recovery response must not overwrite a later session state or other
transfer reference. A settlement only releases its reservation after its
settled session and game-result ledger agree on member, amount and MYR. An
inconsistent state stays held or requires manual reconciliation; do not treat
a response alone as evidence that a provider transfer succeeded. The wallet
calculates available funds only from matching settled results, fails closed on
invalid game ledger data, and the finance report excludes invalid results.

## Known production blockers

- VPay and GSPAY payout success/failure observations can race across workers.
  A stale failure can release the reservation before a late successful payout;
  restoring the hold may conflict with a newer member operation. A complete
  fix needs account-level risk holds, all spending exits, conflict handling and
  data migration. This candidate does not repair that issue.
- The shared payment recovery job may also inspect historical payouts when
  VPay or GSPAY recovery is enabled. Review effective flags and existing
  outstanding transactions before any deployment or operational change.
- GSPAY USDT recovery is not implemented; the MYR ledger is not a USDT ledger.
- No evidence here proves a historic deposit failed at callback or wallet.
  Real provider evidence, live settlement, all 37 game profiles, production
  DNS/TLS, database binding, backups/restoration and sign-off remain unverified.
- Treat previously shared credentials as exposed and rotate via the relevant
  provider and secret manager before production acceptance.
