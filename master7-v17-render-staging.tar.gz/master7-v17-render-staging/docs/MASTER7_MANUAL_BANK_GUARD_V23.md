# Manual bank review guard — local candidate `.115`

This local candidate is based on the v22 `.114` source release. It does not
describe the currently deployed service or confirm any actual bank payment.

## Change

- Serialize approval and rejection through the member wallet guard. Lock and
  recheck the pending order and receipt before recording a decision.
- Bind the decision to the original member, amount and MYR currency. If the
  order changes while review waits, no decision or ledger entry is made.
- Preserve any existing journal and move the order to reconciliation when a
  partial journal, receipt problem or bank reference mismatch is found. The
  reviewer receives a conflict rather than a success response.
- Only report approval after a member entry and an equal, opposite clearing
  entry have been verified against the current order. The ledger, status and
  audit record are written in one database transaction.

The protection assumes all concurrently running writers use the member guard.
An older service or external writer that bypasses it must not be assumed safe.
Staff must independently verify payment against the actual bank statement;
receipt images and automated tests do not prove that money was received.

## Local verification

- Five SQLite tests cover partial journal review, changed member/amount and
  idempotent normal approval. The historical source failed four of these tests.
- A fresh loopback-only PostgreSQL database tested concurrent reviewers, a
  journal arriving while review waits, changed amount, and transaction rollback
  on audit failure: five tests including the parent suite passed.
- A production build and full regression are separately recorded in the
  accompanying handover; no production data was used.

## Remaining acceptance

The current V17 service still runs `.99` as observed on 2026-11-08 19:17 UTC.
This patch has not been deployed, and manual-bank payment and wallet credit
have not been verified with an actual transfer. Backup, isolated restore,
rollback, version coordination and separate production sign-off remain open.
Keep existing orders and evidence; never blindly duplicate credits.

VPay, GSPAY and 1MPay have their own independent payment and reconciliation
requirements. A newly generated VPay key is not proof that the gateway is
using it or that callbacks, wallet credit and provider settlement work.
