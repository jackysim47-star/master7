# MASTER7 供应商资料核对：第 14–23 家（已脱敏）

日期：2026-11-06（MYT）
范围：ALLBET、QUICKSPIN、ASTAR、META GAMING、FUMA、YL、FUNKY、GAMITECH、SPADE GAMING、TURBO。
安全边界：仅离线读取用户提供的附件与附件中明确引用的资料地址；没有调用生产 API、创建玩家、启动游戏、转账或下注。本文不包含账号、密码、operator code、secret、token、白名单 IP 或其他凭据值。

## 结论

这十家不能套用同一个游戏启动或钱包程序。附件可确认至少五个协议/主机家族；只有 ALLBET、QUICKSPIN、ASTAR 明确属于同一 `336699bet.com` 家族。现有文件主要是生产凭据交付单，并不是实现所需的完整 API 合同。

- **0/10** 有足够资料完成并验收 catalogue + player + launch + wallet + callback 全链路；
- **3/10**（ALLBET、QUICKSPIN、ASTAR）有相同的凭据模板与主机，但没有方法、签名或业务 schema；
- **1/10**（FUMA）明确写明 transfer wallet，仍缺全部方法和签名合同；
- META GAMING 提供 production/staging 函数入口和游戏素材目录，但没有函数清单、请求/响应、签名或钱包合同；
- **2/10**（GAMITECH、SPADE GAMING）明确是 transfer / balance-transfer；TURBO 只有 transfer-wallet 内部服务线索；
- YL、FUNKY 的钱包模式未说明，且仅有生产主机与凭据字段。

## 逐家证据矩阵

| # | 供应商 | 附件证据 | 官方/厂家主机（仅主机名） | 钱包模式 | 目录 | 玩家 | 启动 | 余额/转账 | 回调/报表 | 当前可实施性 |
|---:|---|---|---|---|---|---|---|---|---|---|
| 14 | ALLBET | `ALLBET_AK_- MASTER7 MYR- Client Copy _2_.xlsx` | `gsmd.336699bet.com`、`fetch.336699bet.com`；后台 `ams.allbetgaming.net` | 未说明 | ❌ 无 schema | ❌ | ❌ | ❌ | ❌ | 凭据存在；合同缺失 |
| 15 | QUICKSPIN | `QUICKSPIN_FI_- MASTER7 MYR- Client Copy _3_.xlsx` | `gsmd.336699bet.com`、`fetch.336699bet.com`；后台 `ui.adminfg.com` | 未说明 | ❌ 无 schema | ❌ | ❌ | ❌ | ❌ | 凭据存在；合同缺失 |
| 16 | ASTAR | `ASTAR_YX_- MASTER7 MYR- Client Copy _2_.xlsx` | `gsmd.336699bet.com`、`fetch.336699bet.com`；后台 `astar222.net` | 未说明 | ❌ 无 schema | ❌ | ❌ | ❌ | ❌ | 凭据存在；合同缺失 |
| 17 | META GAMING | `_PROD_META GAMING MASTER7 _5_.txt`、`_PROD_META GAMING master7 BONUS KEY _1_.txt` | production `smapi.xystem138.com`；staging `smakermicsvc.back138.com`；后台 `mtgbo.sm-metagsys.com` / `mtgbo.back138.com` | 文件只标注 Normal API / Free Credit API，不能据此确定钱包模式 | 🟡 仅 Google Drive 游戏清单/图片目录 | ❌ | ❌ | ❌ | ❌ | 有环境入口与素材；函数合同缺失 |
| 18 | FUMA | `_PROD_FUMA MASTER7 _3_.csv`、`_PROD_FUMA EVMASTER7 BONUS KEY.csv` | `api.fumagames.com` | **Transfer**（附件明确） | ❌ 无 schema | ❌ | ❌ | ❌ | ❌ | 有基础凭据与钱包类型；合同缺失 |
| 19 | YL | `_PROD_YL _MASTER75566.docx` 及相同副本 | `yl368.ylgaming.net`；后台 `ap626.ylgaming.net` | 未说明 | ❌ | ❌ | ❌ 只有 `{website}/{api}` 模板 | ❌ | ❌ | 有主机与凭据；合同缺失 |
| 20 | FUNKY | `_PROD_Funky MASTER7MYR.txt` | `cfbb7e4b9e25.funplayfky.com`；报表 `rs5kf13akf3f.funplayfky.com`；后台 `bo.funkygames.io` | 未说明 | ❌ | ❌ | ❌ | ❌ | 🟡 只有报表主机 | 有主机与凭据；合同缺失 |
| 21 | GAMITECH | `Export_ApiKey_187019_master7myr _1_.xlsx` | `vendor-api.888star.xyz/v1`；后台 `portal.888star.xyz` | **TransferMode** | ❌ | ❌ | ❌ | ❌ | ❌ | 有生产 base 与钱包类型；合同缺失 |
| 22 | SPADE GAMING | `_PROD_SPADE GAMING MASTER7 _2_.xlsx` 及相同副本 | `merchantapi.silverkirin88.com/api`、`lobby.silverkirinplay.com`；后台 `backoffice.silverkirin88.com` | **Balance Transfer** | ❌ | 🟡 仅方向说明 | 🟡 只有 `auth` URL 模式 | 🟡 只有回调方向 | 🟡 无 schema/验签 | MIF 线索存在；完整合同缺失 |
| 23 | TURBO | `_PROD_Turbo MASTER7 _2_.txt` 及相同副本 | 只提供内部 `turbogames-transfer-wallet-service` callback 名称 | transfer-wallet 线索 | ❌ | ❌ | ❌ | ❌ | 🟡 只有内部 callback 名称 | 缺公开 base 与全部合同 |

## 336699 家族：ALLBET、QUICKSPIN、ASTAR

三份工作簿格式一致，均包含 provider、operator、secret、API URL、log URL 和后台入口等字段。可确认它们适合在未来由一个协议 adapter 加三个 provider profile 实现，但当前文件没有：

1. 请求方法、路径和 content type；
2. 签名字段、拼接顺序、编码、时间戳与 nonce 规则；
3. 游戏列表、玩家建立、游戏启动、余额和资金转移 schema；
4. transfer / seamless 钱包声明；
5. bet、settle、rollback、cancel 或 deposit、withdraw、query 的幂等规则；
6. 回调验签、允许 IP、重试和报表对账规则；
7. UAT 账号与零资金验收步骤。

附件给出的两个 API/日志地址是明文 HTTP。生产实现前必须由厂家确认可用的 HTTPS endpoint 与证书要求，不能把后台登录地址当作 API 地址，也不能从主机名猜测业务路径。

## META GAMING

附件提供 production 与 staging 的 `.../api/opgateway/v1/op/{FUNCTION NAME}` 模板、后台入口、MYR、白名单提示，以及 Google Drive 的游戏清单和图片目录。这些资料可以用于素材整理和未来环境配置，但 `{FUNCTION NAME}` 仍是占位符，未提供：

- 函数名称清单及每个函数的 HTTP method；
- normal / free-credit 两套凭据的职责边界与钱包模型；
- player、launch、balance、transfer 或 seamless callback 的请求/响应；
- 签名、时间戳、重放防护和响应验签；
- game list 中稳定 game ID 与前台 `metagaming` ID 的映射；
- 断线、重复请求、回滚、补查和报表对账规则。

附件引用的 Google Drive 地址被标为游戏清单和 thumbnail 素材，不是 API 合同，不能据此开放游戏启动。

## FUMA

两份 CSV 均指向同一生产 API 主机，标明 MYR 与 **Transfer**。它们是账号/凭据行，没有 endpoint 或 schema。因此实现前仍需厂家提供：

- catalogue、create/check player、launch URL、balance；
- deposit、withdraw、transaction query 的完整合同和唯一 transaction ID 规则；
- 签名/加密、响应验签、超时与不确定结果补查；
- 退出时 withdraw、玩家在线状态、重复交易与余额不足处理；
- UAT 或获准的零资金生产验收流程、固定出口 IP 白名单；
- 报表、对账和人工差异处理接口。

## YL、FUNKY、GAMITECH、SPADE GAMING、TURBO

### YL

附件只给出 `.../api/{website}/{api}` 模板及商户配置字段，没有列出 `{api}` 的合法方法。需厂家提供方法白名单、认证/签名、目录/玩家/启动/钱包 schema、回调、错误码、MYR 精度、白名单与 UAT。

### FUNKY

附件分别给出 production API、report API 与后台主机，但没有 endpoint。需补完整 API/report 路径、HTTP 方法、认证与签名、玩家/游戏/钱包合同、报表分页和时间规则、回调验签与 UAT。

### GAMITECH

附件明确 Production、MYR、`TransferMode` 与 `/v1` base，但没有 OpenAPI 或方法说明。需补 catalogue、player、launch、balance、deposit、withdraw、query、交易 ID 幂等、回调/报表和签名规范。附件提示生产调用可能计费，因此不能靠生产账号试错猜接口。

### SPADE GAMING

附件明确 `Balance Transfer`、Merchant API base、游戏 `auth` URL 模式、ticket `createToken` 模式，并要求商户提供 withdraw、deposit、account-info 服务端接口。当前仍缺这些请求的 method、字段、响应、签名、幂等、重试及报表合同；只有 URL 模式不能生成安全 adapter。

### TURBO

附件只有 Token 字段与一个内部 `transfer-wallet-service` callback 名称，没有公开 API base、调用方向或 schema。需补目录、玩家、启动、余额/转账/补查、callback 验签、幂等/回滚、报表、厂家出口 IP 和 UAT。

## 共同上线门槛

每一家必须独立满足以下状态后，前台才可显示“可进入”：

```text
credentialsConfigured
ipWhitelistVerified
catalogueVerified
playerVerified
launchVerified
walletVerified
callbackOrTransferQueryVerified
reconciliationVerified
productionQaPassed
```

只有品牌图片或生产凭据不能替代上述验收。当前源码也没有这十家的 catalogue、launch、wallet 或 settlement adapter；它们只能作为独立供应商入口保持 fail-closed。
