# MASTER7 918KISS H5 runtime contract gap

Date: 2026-11-10  
Scope: `918kiss_normal_myr`, `918kiss_normal_my1_1to100`, `918kiss_free_myr`

## Finding

The available source and handover evidence supports three isolated read-only
catalogues. It does not contain an authoritative 918KISS H5 player, launch,
wallet, transaction-query, session-closure, settlement or recovery contract.
No executable adapter can be implemented safely from the current evidence.

The existing gateway's `GetGameList` request and MD5 signing shape establish
only the catalogue operation already implemented. They do not establish the
operation name, fields, signing tail or result semantics of any runtime method.

The gateway currently exposes only:

```text
GET /providers/918kissh5/games?account=normal
GET /providers/918kissh5/games?account=my1
GET /providers/918kissh5/games?account=free
```

The portal deliberately keeps all three profiles `adapter_unimplemented`,
`enabled=false` and non-playable. The internal MY1 `unitScale=100` rule is a
candidate platform conversion rule; it is not supplier confirmation that MY1
means MYR at 1:100.

## Evidence checked

- Portal registry, catalogue, launch, wallet, acceptance and unit-conversion
  code and tests.
- Integration gateway 918KISS catalogue module, routes and tests.
- All 84 uploaded attachments (including extracted DOCX, XLSX and PDF text),
  repository documentation, handover files, acceptance CSVs, matching Git
  material and 114 workspace archives containing `918KISS`, `KISS H5`,
  `kissh5`, `MY1`, `opgateway` or the three account/profile labels.
- `MASTER7_918KISS_验收记录_20261110.md`, which proves only `GetGameList` and
  enumerates the absent runtime operations.
- `MASTER7_918KISS_CATALOGUE_SAFETY_152.md`, which explicitly says the runtime
  contracts have not been supplied or accepted.
- `MASTER7_VENDOR_ACTIONS_20261107.md`, which asks the supplier for the missing
  launch, wallet, query, exit, settlement, currency and account semantics.
- `MASTER7_GAME_CONTRACT_DISCOVERY_20261110_MYT.json`, which marks Live22
  kick/unfinished-round methods as another provider's compatibility reference;
  they cannot be copied into a 918KISS adapter.

Catalogue operator configuration and artwork URLs were not treated as runtime
contract evidence. No supplier call, game launch, wallet movement or
deployment was made during this audit.

## Exact missing vendor fields

The code exposes the same list as machine-readable, profile-isolated
diagnostics in `lib/kissh5-contract-readiness.ts`. Values are never echoed by
the validator.

### Document provenance

`document.document_id`, `document.api_version`, `document.environment`,
`document.merchant_scope`, `document.base_urls`,
`document.operation_names`, `document.ip_allowlist_rule`, `document.sha256`

### Authentication and request signing

`authentication.scheme`, `authentication.credential_fields`,
`authentication.signature_algorithm`,
`authentication.canonical_request_rule`, `authentication.signed_fields`,
`authentication.timestamp_field`, `authentication.clock_skew_seconds`,
`authentication.nonce_or_replay_rule`, `authentication.test_vectors`

### Player registration and lookup

`player.create.endpoint`, `player.create.method`,
`player.create.required_fields`, `player.create.success_codes`,
`player.create.error_codes`, `player.create.idempotency_rule`,
`player.lookup.endpoint`, `player.lookup.method`,
`player.lookup.required_fields`, `player.namespace_rule`

### Game launch and return

`launch.endpoint`, `launch.method`, `launch.required_fields`,
`launch.response_url_field`, `launch.url_ttl_seconds`,
`launch.return_url_field`, `launch.game_id_field`,
`launch.session_id_field`, `launch.delivery_modes`, `launch.token_field`,
`launch.token_expiry_rule`, `launch.token_revocation_rule`,
`launch.success_codes`, `launch.error_codes`

### Wallet balance and funds movement

`wallet.mode`, `wallet.balance.endpoint`, `wallet.balance.method`,
`wallet.balance.required_fields`, `wallet.balance.amount_field`,
`wallet.balance.currency_field`, `wallet.funds_flow.operations`,
`wallet.funds_flow.required_fields`,
`wallet.funds_flow.transaction_id_field`,
`wallet.funds_flow.idempotency_field`, `wallet.funds_flow.duplicate_rule`,
`wallet.funds_flow.success_codes`, `wallet.funds_flow.error_codes`

The supplier must first confirm `wallet.mode` as `transfer` or `seamless`.
`wallet.funds_flow.operations` must then name the matching transfer operations
or the matching wager/settle/cancel callbacks. A catalogue credential is not a
wallet credential or wallet contract.

### Transaction query and terminal states

`wallet.transaction_query.endpoint`, `wallet.transaction_query.method`,
`wallet.transaction_query.required_fields`,
`wallet.transaction_query.pending_statuses`,
`wallet.transaction_query.terminal_success_statuses`,
`wallet.transaction_query.terminal_failure_statuses`,
`wallet.transaction_query.not_found_rule`,
`wallet.transaction_query.late_success_rule`,
`wallet.transaction_query.binding_fields`

### Callback and report contract

`reports.endpoint`, `reports.method`, `reports.required_fields`,
`reports.round_id_field`, `reports.bet_id_field`,
`reports.transaction_id_field`, `reports.signed_fields`,
`reports.source_ip_rule`, `reports.ack_schema`, `reports.retry_policy`,
`reports.deduplication_field`, `reports.replay_window_seconds`,
`reports.pagination_rule`, `reports.ordering_rule`

### Exit and session closure

`session.exit.endpoint`, `session.exit.method`,
`session.exit.required_fields`, `session.exit.final_status_field`,
`session.exit.success_codes`, `session.exit.error_codes`,
`session.return_url_rule`, `session.disconnect_rule`,
`session.duplicate_exit_rule`, `session.kick.endpoint`,
`session.kick.method`, `session.kick.required_fields`,
`session.offline_status.endpoint`, `session.offline_status.method`,
`session.offline_status.required_fields`,
`session.unfinished_rounds.endpoint`, `session.unfinished_rounds.method`,
`session.unfinished_rounds.required_fields`,
`session.issued_token_invalidation_rule`, `session.late_result_finality_rule`

### Settlement and recovery

`settlement.finality_rule`, `settlement.reversal_rule`,
`settlement.reconciliation_fields`, `recovery.timeout_rule`,
`recovery.retry_policy`, `recovery.polling_policy`

### Limits, maintenance and acceptance vectors

`limits.request_rate_rule`, `limits.amount_bounds_rule`,
`maintenance.status_endpoint`, `maintenance.behavior`,
`acceptance.uat_account_scope`, `acceptance.uat_test_cases`,
`acceptance.production_vectors`

### Fields required separately for every profile

`profile.profile_id`, `profile.account_variant`,
`profile.provider_account_scope`, `profile.provider_currency`,
`profile.settlement_currency`, `profile.amount_unit`,
`profile.amount_precision`, `profile.conversion_ratio`,
`profile.rounding_rule`, `profile.balance_class`, `profile.game_scope`

The required bindings are independent:

| Portal profile | Account variant | Known label | Still requires supplier confirmation |
|---|---|---|---|
| `918kiss_normal_myr` | `normal` | MYR, cash | account scope, unit, precision, ratio, game scope and every runtime operation above |
| `918kiss_normal_my1_1to100` | `my1` | MY1 label, cash | actual provider and settlement currencies, MY1 meaning, ratio, directions, rounding, game scope and every runtime operation above |
| `918kiss_free_myr` | `free` | MYR, free credit | funding, spend, cash conversion, expiry, settlement, game scope and every runtime operation above |

The MY1 profile additionally requires:

`profile.my1_definition`, `profile.my1_to_myr_ratio`,
`profile.conversion_direction`, `profile.conversion_rounding_rule`

For `918kiss_normal_my1_1to100`, ratio orientation is always provider points to
settlement major units: `100:1` means **100 MY1 points = MYR 1.00**. A transfer
from the MYR wallet to MY1 therefore multiplies by 100; returning MY1 to the
MYR wallet divides by 100. The manifest must bind provider currency `MY1`,
settlement currency `MYR`, amount unit `points`, both ratio fields to `100:1`,
and direction
`MYR_TO_MY1_MULTIPLY_100;MY1_TO_MYR_DIVIDE_100`. USD, USDT, reversed ratios or
`1:1` evidence cannot complete this profile.

The free-credit profile additionally requires:

`profile.free_credit_source`, `profile.free_credit_spend_rule`,
`profile.free_credit_cash_conversion_rule`,
`profile.free_credit_expiry_rule`, `profile.free_credit_settlement_rule`

## Code change

The new validator reports missing or malformed field names without reflecting
submitted values. A syntactically complete documentation manifest still
returns:

```text
documentationOnly = true
adapterImplemented = false
launchAllowed = false
walletAllowed = false
playAllowed = false
```

Production acceptance diagnostics now include the exact 918KISS contract gap
for each profile. Existing acceptance evidence, catalogue success, credentials
or an internal conversion test cannot enable Play.

## Required next evidence

Obtain the official versioned supplier documentation for each account scope,
including sample request/response and error payloads, then have the provider
confirm the merchant/environment binding in writing. Only after that evidence
passes review should a disabled adapter be implemented and exercised in a
non-money test environment. Production Play remains subject to separate launch,
wallet, settlement, recovery and operational acceptance.

