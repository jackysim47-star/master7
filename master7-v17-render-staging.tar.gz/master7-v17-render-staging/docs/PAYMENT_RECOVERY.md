# Payment recovery and capability controls

This release separates deposit, payout and balance capabilities. A configured
deposit adapter does not imply payout, balance, wallet settlement or production
acceptance. All capability responses keep `verified` and
`settlementVerified` false until a separate production acceptance is recorded.

## Deposit recovery

VPay, ordinary GSPAY MYR and 1MPay deposits can be recovered by an independent
provider status query when a callback is lost. Recovery never creates or
resubmits an order. It credits only after the provider query matches the stored
provider reference when present, portal order, member, exact MYR amount and
configured merchant. Stale GSPAY MYR orders without a provider reference can
be queried by their portal transaction ID after 60 seconds. The wallet write is one unique `member` entry and one equal opposite
`provider_clearing` entry. VPay and GSPAY hold changed member eligibility for
review. Mismatched bindings or inconsistent ledger evidence also require review.

Recovery is off unless a private token and at least one provider's recovery
switch are explicitly enabled. Each provider is controlled independently:

| Variable | Meaning |
| --- | --- |
| `PAYMENT_RECOVERY_TOKEN` | Private loopback bearer, at least 32 characters |
| `VPAY_RECOVERY_ENABLED=true` | Permit VPay status recovery |
| `GSPAY_RECOVERY_ENABLED=true` | Permit ordinary GSPAY MYR status recovery |
| `ONE_MPAY_RECOVERY_ENABLED=true` | Permit 1MPay MYR status recovery |
| `PAYMENT_RECOVERY_INTERVAL_MS` | 60,000–3,600,000 ms; default 120,000 |

The worker calls only `POST /api/internal/payment-recovery` on loopback. The
provider-specific order switches remain independent; recovery may confirm an
existing order while new orders are closed.

When only 1MPay recovery is enabled, the worker adds the protected
`?provider=1mpay` scope and does not scan or reconcile VPay or GSPAY payouts.
When VPay or GSPAY recovery is enabled, the existing shared recovery behavior
continues, including eligible existing payout status recovery.

For 1MPay, a fully authenticated callback bound to the stored order can
preserve its previously missing provider reference before an independent query.
This does not credit the wallet; a timeout leaves the order eligible for a
later query. A reference that appears while the worker is checking a missing
reference is not moved to review on the stale observation. Orders with no
usable reference still need review. A running process and configured worker
are required; an enabled environment variable alone is not evidence of a
successful recovery or real-money acceptance.

## Balance and payout

`GSPAY_BALANCE_QUERY_ENABLED=true` permits an owner-only, read-only call to the
documented operator balance endpoint. It cannot enable orders or mark settlement
verified.

VPay and 1MPay payout submission remain disabled because their complete payout,
callback and independent-query contracts have not been accepted. GSPAY has a
separate payout adapter, but it is fail-closed until the explicit runtime flag,
provider IP whitelist confirmation, encryption key, complete 18-bank target
mapping, active channel and database payout control are all present.

GSPAY payout recovery queries only existing `submitting` or `processing` rows.
It never creates or resubmits a payout. A callback must pass its own auth and
signature checks and then a separate signed status query must bind the payout
ID, transaction ID, account name, account number and exact MYR amount before a
reservation can be finalized or released. Unknown network outcomes keep the
reservation held. GSPAY DuitNow and USDT remain disabled.
