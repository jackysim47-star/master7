# Payment recovery and capability controls

This release separates deposit, payout and balance capabilities. A configured
deposit adapter does not imply payout, balance, wallet settlement or production
acceptance. All capability responses keep `verified` and
`settlementVerified` false until a separate production acceptance is recorded.

## Deposit recovery

VPay and ordinary GSPAY MYR deposits can be recovered by an independent
provider status query when a callback is lost. Recovery never creates or
resubmits an order. It credits only after the provider query matches the stored
provider reference, portal order, member, exact MYR amount and configured
merchant. The wallet write is one unique `member` entry and one equal opposite
`provider_clearing` entry. Changed member eligibility, mismatched bindings or
an inconsistent ledger moves the order to review.

Recovery is off unless all of these deployment values are set explicitly:

| Variable | Meaning |
| --- | --- |
| `PAYMENT_RECOVERY_TOKEN` | Private loopback bearer, at least 32 characters |
| `VPAY_RECOVERY_ENABLED=true` | Permit VPay status recovery |
| `GSPAY_RECOVERY_ENABLED=true` | Permit ordinary GSPAY MYR status recovery |
| `PAYMENT_RECOVERY_INTERVAL_MS` | 60,000–3,600,000 ms; default 120,000 |

The worker calls only `POST /api/internal/payment-recovery` on loopback. The
provider-specific order switches remain independent; recovery may confirm an
existing order while new orders are closed.

## Balance and payout

`GSPAY_BALANCE_QUERY_ENABLED=true` permits an owner-only, read-only call to the
documented operator balance endpoint. It cannot enable orders or mark settlement
verified.

VPay and 1MPay payout submission remain disabled because their complete payout,
callback and independent-query contracts have not been accepted. GSPAY has a
separate payout adapter, but it is fail-closed until the explicit runtime flag,
provider IP whitelist confirmation, encryption key, complete 18-bank target
mapping, active channel and database payout control are all present.

GSPAY payout recovery queries only existing `submitting` or `processing` rows.
It never creates or resubmits a payout. A callback must pass its own auth and
signature checks and then a separate signed status query must bind the payout
ID, transaction ID, account name, account number and exact MYR amount before a
reservation can be finalized or released. Unknown network outcomes keep the
reservation held. GSPAY DuitNow and USDT remain disabled.
