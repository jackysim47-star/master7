# Payment recovery and capability controls

This release separates deposit, payout and balance capabilities. A configured
deposit adapter does not imply payout, balance, wallet settlement or production
acceptance. All capability responses keep `verified` and
`settlementVerified` false until a separate production acceptance is recorded.

## Deposit recovery

VPay and ordinary GSPAY MYR deposits can be recovered by an independent
provider status query when a callback is lost. Recovery never creates or
resubmits an order. It credits only after the provider query matches the stored
provider reference, portal order, member, exact MYR amount and configured
merchant. The wallet write is one unique `member` entry and one equal opposite
`provider_clearing` entry. Changed member eligibility, mismatched bindings or
an inconsistent ledger moves the order to review.

Recovery is off unless all of these deployment values are set explicitly:

| Variable | Meaning |
| --- | --- |
| `PAYMENT_RECOVERY_TOKEN` | Private loopback bearer, at least 32 characters |
| `VPAY_RECOVERY_ENABLED=true` | Permit VPay status recovery |
| `GSPAY_RECOVERY_ENABLED=true` | Permit ordinary GSPAY MYR status recovery |
| `PAYMENT_RECOVERY_INTERVAL_MS` | 60,000–3,600,000 ms; default 120,000 |

The worker calls only `POST /api/internal/payment-recovery` on loopback. The
provider-specific order switches remain independent; recovery may confirm an
existing order while new orders are closed.

## Balance and payout

`GSPAY_BALANCE_QUERY_ENABLED=true` permits an owner-only, read-only call to the
documented operator balance endpoint. It cannot enable orders or mark settlement
verified.

Provider payout submission is disabled for VPay, GSPAY and 1MPay. The database
control has a fail-closed constraint and this release contains no provider
submission function. GSPAY DuitNow, USDT and payout callbacks remain disabled;
1MPay payout is not implemented without a complete callback and query contract.
