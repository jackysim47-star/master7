# MASTER7 V17.159 Premium Mobile Frontend

Release: `17.0.0-selfbuilt.159-premium-mobile`

The member frontend uses a clearer water-blue, deep-blue and white mobile presentation. The header, wallet actions, Deposit, Withdraw and Support entry points, compact hero, sponsored providers, game directory and fixed bottom navigation have larger tap targets and more readable spacing at 393px.

Customer-facing English fallbacks from V17.158 remain in place. This release changes presentation only; it does not enable payment orders, game launch, wallet transfer, settlement, payout, or any unverified provider profile.
