# MASTER7 v155 game catalogue integrity release

Release: `17.0.0-selfbuilt.155-catalogue-integrity`

This release completes the next read-only catalogue integrity pass for the
configured game suppliers.

- Every non-direct supplier response must identify the exact requested
  supplier. Malformed, duplicate, oversized or explicitly incomplete refreshes
  preserve the last trusted snapshot under maintenance instead of publishing a
  partial list.
- JILI 1:1 and 1:100 use independent account caches and profile readiness.
  Unknown per-title availability remains maintenance, and the sponsored JILI
  entry opens the exact selected profile instead of an invalid brand ID.
- 918KISS artwork uses the verified image URL stored for the exact profile and
  game, rather than guessing a path from the game code.
- Rectangle and GodeeZone direct catalogues reject unsafe IDs, names,
  categories, duplicates and incomplete sets.
- JDB and RSGHub explicitly attest catalogue completeness. RSGHub verifies the
  response timestamp, rejects unsafe names and withholds unapproved remote
  artwork.

The public lobby remains truthful: 37 brands and 42 profiles may be listed,
but no profile is Play-enabled until its supplier contract, launch, wallet,
settlement and production acceptance evidence all pass.

No player, launch, balance, wallet, transfer, settlement, recovery or payment
operation is enabled by this release. VPay, GSPAY, 1MPay, payment switches,
credentials, service plans, DNS and database schema are unchanged.
