# MASTER7 V17.158 Customer English Fallbacks

Release: `17.0.0-selfbuilt.158-customer-english-fallbacks`

The member portal now renders English fallback copy throughout the lobby, deposit, withdrawal, wallet, VIP, rewards, events, support, authentication and play-settings surfaces when English is selected. Dynamic VIP, Rewards and Events states are locale-aware, including unavailable and empty states. Support notifications and marketing unsubscribe copy also follow the selected language.

Chinese and Bahasa Melayu dictionaries, admin/backoffice copy, payment and game logic, APIs, runtime controls and production flags are unchanged. Deliberate language labels such as `中文` remain in the language selectors.
