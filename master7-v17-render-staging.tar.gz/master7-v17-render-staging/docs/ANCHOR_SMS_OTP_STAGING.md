# SEVEN member SMS OTP on Render staging

Member registration now requires a Malaysian mobile number verified through Anchor SMS. Owner/staff backoffice login remains ID plus password. OTP codes expire after five minutes, allow five attempts, are one-use, and are stored only as HMAC digests. IP and phone send limits are enforced. The sender uses Anchor's HTTPS token endpoint (`/auth/getToken`) followed by its bearer-authenticated SMS endpoint (`/mt/sendMtSms`). Only provider response `201` with `statusCode: 001` is treated as accepted for submission; it does not prove handset delivery.

## Render secret configuration

Add these values to the `master7-v17-staging` service's secret environment settings. Do not put them in GitHub, source files, screenshots, or chat.

| Secret | Value to obtain from Anchor |
| --- | --- |
| `ANCHOR_SMS_API_BASE_URL` | HTTPS API base URL from the Anchor SMS account/API guide, without a path or query |
| `ANCHOR_SMS_USERNAME` | API username |
| `ANCHOR_SMS_PASSWORD` | API password |
| `ANCHOR_SMS_SENDER_ID` | Sender ID / originating number authorized for this account |
| `OTP_HASH_SECRET` | A new random secret of at least 32 characters, generated for this app; not the Anchor password |

Save the variables as Render secrets and redeploy. `/health` and `/api/auth/options` expose only the boolean `smsOtpReady`; they never reveal secret values. If any value is missing, OTP sends fail closed with `503`, and the member registration endpoint will not accept a registration without a valid challenge.

## Acceptance still needed

Automated tests exercise token retrieval, request format, accepted/rejected provider responses, expiry, wrong-code attempts, replay prevention, Malaysian number normalization, and fail-closed behavior using a mock provider. No live message was sent. Before treating this as live SMS verification, the account owner must set the secrets, verify the approved sender ID and exact API base URL with Anchor, then send one consented test OTP to an authorized test phone and confirm delivery and code verification. A `001` response only means Anchor accepted the request for processing.
