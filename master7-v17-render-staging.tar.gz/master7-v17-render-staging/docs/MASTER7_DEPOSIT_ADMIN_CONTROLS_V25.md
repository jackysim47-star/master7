# Independent deposit controls — local candidate `.117`

An owner can pause new VPay MYR, GSPAY MYR, 1MPay MYR or manual-bank deposits
independently from the shared management console. Staff can view the controls.
Each change is authorized server-side and written with an audit record.

The default is the existing automatic configuration. Resuming automatic mode
does not bypass the global maintenance switch, provider settings, access checks,
or provider readiness. GSPAY USDT remains separately unavailable pending its
contract; this change does not claim that it is connected or accepted.

A pause blocks new requests that reach the check after the pause is visible.
A request that has already passed the check may finish; this is not a
cross-instance drain or cancellation mechanism. Existing callbacks, order
queries and recovery are not disabled by these controls. The settings are stored
in the existing backed-up `settings` table; this change adds no new table.

The control does not provide a safe mixed-version rollout. Older `.99`
instances do not use these overrides and may continue to process new orders or
background tasks. The database binding, backups, restores, all writer versions,
vendor retries and production sign-off still require independent verification.
The GSPAY direct-mode startup configuration discrepancy remains unresolved;
neither this interface nor a green status certifies any real payment.
