# MASTER7｜WhatsApp Business 百万联系人模块

日期：2026-11-06（MYT）
程序版本：`17.0.0-selfbuilt.74-whatsapp-business-queue`
正式号码：`+601166336686`
Provider：Meta WhatsApp Business Cloud API
Webhook：`https://master7.best/api/marketing/whatsapp/webhook`

程序、数据库迁移、后台界面、派送 worker、Webhook 验签与自动退订已经完成。当前正式发送状态保持 `Waiting`；没有配置下列 Meta 正式值、批准模板、已核实受众额度和有效联系人同意前，系统不会提交消息。

## 交付范围

后台可保存最多 1,000,000 个去重后的马来西亚手机号码，并以活动为单位建立发送队列。队列只选择具有完整同意时间、来源及证明的 `opted_in` 联系人，永久排除 `unknown` 和 `opted_out`。每一活动与联系人组合只建立一条 delivery，避免重复排队。

发送程序只调用 Meta 官方 Graph API，并且只发送已获批准的 WhatsApp 模板。系统记录 `queued / submitting / unknown / sent / delivered / read / failed / opted_out`，使用已验签的 Webhook 更新送达结果。网络超时或回包无法确认时记录为 `unknown`，不会自动盲目重发。

1,000,000 是后台名单和程序容量，不代表 Meta 已批准向 1,000,000 位不同收件人发送。正式可发送人数取 `WHATSAPP_RECIPIENT_LIMIT` 的已核实值；活动中已同意人数超过该值时，系统拒绝启动。

## Render 必须配置的值

以下值只放在 Render service environment，不得写入 Git、网页、活动导出、截图或审计日志：

| 环境变量 | 来源与要求 |
|---|---|
| `WHATSAPP_SENDING_ENABLED` | 验收完成后才设为 `true`；此前保持 `false`。 |
| `WHATSAPP_GRAPH_API_VERSION` | 当前受 Meta 支持的 Graph API 版本，例如 `v27.0`；上线时按 Meta 当前版本核实。 |
| `WHATSAPP_PHONE_NUMBER_ID` | WhatsApp Manager / App 中正式号码对应的 Phone Number ID。它不是电话号码。 |
| `WHATSAPP_WABA_ID` | WhatsApp Business Account ID。 |
| `WHATSAPP_ACCESS_TOKEN` | 具有 WhatsApp 权限的永久 System User access token。 |
| `WHATSAPP_APP_SECRET` | Meta App Secret，用于校验 `X-Hub-Signature-256`。 |
| `WHATSAPP_WEBHOOK_VERIFY_TOKEN` | 自行产生的随机 verify token，至少 32 字符；Meta Webhook 设置必须填写相同值。 |
| `WHATSAPP_BUSINESS_NUMBER` | 必须是 `+601166336686`；程序拒绝其他发送号码。 |
| `WHATSAPP_TEMPLATE_NAME` | Meta 已批准的营销模板名称，只接受小写字母、数字与下划线。 |
| `WHATSAPP_TEMPLATE_LANGUAGE` | 模板获批语言代码，例如 `zh_CN`、`en` 或 `ms`；必须与 Meta 版本完全一致。 |
| `WHATSAPP_RECIPIENT_LIMIT` | WhatsApp Manager 中已核实的实际 recipient tier，范围 1–1,000,000；不得填写希望达到的数量。 |
| `WHATSAPP_WORKER_TOKEN` | 独立随机内部 token，至少 32 字符，不与 Meta token 共用。 |
| `WHATSAPP_WORKER_INTERVAL_MS` | 内部队列检查间隔；使用部署默认值或经压测后的受控值。 |
| `WHATSAPP_WORKER_BATCH_SIZE` | 每轮领取数量，程序上限 100；按实际 throughput 逐步调整。 |

Meta App 还需具备 WhatsApp 相关权限，并在 Webhook 产品中订阅消息状态及客户回复事件。号码、企业验证、付款账户、模板与发送质量必须在 Meta 端保持有效。

## 获批模板的固定变量顺序

当前程序传给模板 body 的四个参数固定如下；Meta 模板必须按同一顺序建立并获批：

1. `{{1}}`：活动祝福语或主要文案（`message`）
2. `{{2}}`：福利说明（`benefit`；没有内容时传 `-`）
3. `{{3}}`：注册链接（`https://master7.best/register`，有 referral 时附带 `?ref=...`）
4. `{{4}}`：个人退订链接（`https://master7.best/unsubscribe?token=...`）

模板名称、语言和四个变量会在活动启动时形成快照。后台不能用任意自由文字绕过模板审批。图片若要随模板发送，必须先在 Meta 模板或受支持的媒体 header 流程完成审批与验收；上传一张后台图片不会自动变成可发送的 WhatsApp 媒体。

## Webhook 设置与验收

在 Meta App 中设置 Callback URL：

```text
https://master7.best/api/marketing/whatsapp/webhook
```

Verify Token 使用 Render 的 `WHATSAPP_WEBHOOK_VERIFY_TOKEN`。POST 回调必须携带正确的 `X-Hub-Signature-256`；程序使用原始请求体与 `WHATSAPP_APP_SECRET` 验签。假签名、损坏 JSON 和重复 event 不得改变 delivery。

正式启动前依次验收：

1. 后台状态显示 configured、enabled、template 及 recipient tier 都 ready，且不显示任何 secret。
2. 使用公司内部、明确同意的号码创建小批量活动。
3. 每位联系人只出现一次提交；未同意与已退订号码为零提交。
4. Meta 返回 message ID 后，Webhook 能依序更新 `sent → delivered → read`，失败能保存安全错误代码。
5. 收件人回复 `STOP`、`unsubscribe`、`停止`、`退订` 或 `取消订阅` 后立即成为 `opted_out`，其待发送项目被取消；后续导入不能恢复同意。
6. 记录模板版本、活动人数、Meta recipient tier、发送速率、费用与验收时间，再逐步扩大，不直接从小批量跳至 1,000,000。

## 同意、额度与费用

- 电话号码格式有效不代表持有人同意接收营销信息。导入只有 `phone` 一列的名单时，应保持 `unknown`，直至能提供同意时间、来源与证明。
- Meta 会依号码质量和历史表现限制每日可联系的不同收件人数。常见层级会从 250 逐步提升至 2,000、10,000、100,000 和 Unlimited；实际层级以当前 WhatsApp Manager 为准。
- Throughput 与 recipient tier 是不同限制。程序速率必须取后台活动设置、Meta 当前吞吐与 recipient tier 中较小的安全值。
- Meta 接受 API 请求并不表示已送达；只以经过验签的 Webhook 作为送达、已读或失败依据。
- 官方 WhatsApp Business 营销消息通常会产生 Meta 费用。MASTER7 不能承诺 1,000,000 条正式消息免费发送。
- 导入、排队或发送前必须遵守适用的马来西亚隐私、通讯与营销规则，并保留可查证的同意与退订记录。

## 当前联系人文件说明

2026-11-06 提供的 CSV 经汇总检查为 123,676 个唯一、格式有效的马来西亚手机号码；没有空白、格式错误或重复。该文件只有 `phone` 一列，没有同意或退订字段，因此不能据此把号码直接标为 `opted_in` 或正式发送。详见 `MASTER7_WHATSAPP_CONTACT_DATA_QUALITY_20261106.md`。

## Meta 官方资料

- [Getting opt-in](https://developers.facebook.com/documentation/business-messaging/whatsapp/getting-opt-in)
- [Messaging limits](https://developers.facebook.com/documentation/business-messaging/whatsapp/messaging-limits)
- [Throughput](https://developers.facebook.com/documentation/business-messaging/whatsapp/throughput)
- [Create a Webhook endpoint](https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/create-webhook-endpoint/)
- [WhatsApp Business Phone Number Message API](https://developers.facebook.com/documentation/business-messaging/whatsapp/reference/whatsapp-business-phone-number/message-api)
- [Messages Webhook reference](https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/reference/messages)
- [WhatsApp error codes](https://developers.facebook.com/documentation/business-messaging/whatsapp/support/error-codes)
- [Message templates overview](https://developers.facebook.com/documentation/business-messaging/whatsapp/templates/overview)
