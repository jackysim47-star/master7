# MASTER7 充值、提款、游戏与模板交接

**核查时间** 2026-11-06 22:38–22:45 MYT，另核对随后收到的 Lucky7 手机录屏。适用范围为 MASTER7 当前部署和下一版验收。线上测试站运行 `.71` V17。用户此前要求以 V15 作为交接目标，当前没有 V15 回退上线证据。以下保留实际版本与目标版本的区别。

## 1. 现在卡在哪里

| 项目 | 本次证据 | 交接状态 |
|---|---|---|
| 顾客前台 | `www.master7.best` 的 A、AAAA、CNAME 查询均无答案。`master7.best` 根域返回 HTTP 302，跳到 Render 测试站。测试站首页返回 HTTP 200。 | 正式 `www` 入口待绑定并验证 DNS、HTTPS 和手机访问。根域跳转与 `www` 解析分开验收。 |
| 员工后台 | `www.master7.site` 返回 HTTP 302，跳到测试站 `/admin`。历史资料也出现 `admin.master7.best`。 | 本轮证实 `.site` 的跳转。交接前固定唯一后台域名，按用户批准的域名验收员工登录。 |
| VPay 充值 | 状态接口报生产通道 Active。22:35:29 和 22:35:39 MYT，两次既有建单请求分别在网关返回 `502`，门户对应返回 `202`。 | 已确认失败在网关建单链路。门户代码将结果不确定的订单留在待确认，付款页不会随 `202` 返回。现有日志没有上游 HTTP 状态或厂家业务码。 |
| 1MPAY 充值 | 状态接口报生产通道 Active。已解包核对到 `/fundtransfer/json` 建单、查单和回调实现。所查时段的门户日志没有匹配到 1MPAY 建单请求。 | 商户支付页、付款、钱包和对账仍需逐项验收。缺少对应请求，无法定位用户本次卡在哪一步。 |
| VPay、1MPAY 提款 | 门户的两个提款适配器都显示未接通、提交关闭。VPay 集成网关另有管理员出款路由，但状态接口显示提款关闭且回调转发配置缺项。 | 供应商有提款 API。当前会员按钮尚未连通实际出款。 |
| 游戏 | `GET /api/games` 返回 766 款，618 标记 Active，148 标记 Suspended。当前代码只接 **MegaH5** 启动与游戏钱包。其 166 款目录条目为 Active。匿名时全目录 `playable=false`。所查日志未匹配到 `/api/game-launch` 或 MegaH5 会话 POST。 | JILI、918KISS H5、Rectangle、EVO888 H5 等目录不能据此标为可玩。MegaH5 还要用已批准会员验证启动和退出结算。 |
| 整体资金状态 | VPay、1MPAY 充值已启用，游戏开关已开。门户显示 `settlementVerified=false`、`productionReady=false`。 | 已启用是当前观测。用户原交接要求是由本人决定启用时点。上线验收须明确实际开关与签收状态。 |

证据：[门户健康](https://master7-v17-staging.onrender.com/health) · [VPay 状态](https://master7-v17-staging.onrender.com/api/payments/vpay/status) · [1MPAY 状态](https://master7-v17-staging.onrender.com/api/payments/1mpay/status) · [游戏目录](https://master7-v17-staging.onrender.com/api/games) · [门户日志](https://dashboard.render.com/web/srv-dbl0iv7f3r2c73848ei0/logs) · [网关日志](https://dashboard.render.com/web/srv-db6b7inlk1mc73ck6cmg/logs) · [DNS 查询](https://dns.google/resolve?name=www.master7.best&type=A)

## 2. 按钮和模板以 Lucky7 录屏为验收参考

录屏显示 `lucky7.net` 的手机钱包。同一页先选 **Top Up** 或 **Send**，下方显示历史记录。Top Up 页先填金额，再选 DuitNow QR、电子钱包、FPX 或银行转账。录屏可见 Kaazpay 账单、Rapidpay 选银行页面，以及单独的站内银行转账说明和上传凭证。Send 页在站内输入 MYR 金额、选择已保存的银行账户，也可进入添加银行账户。界面显示资格、最低额提示，以及待处理、取消或已批准记录。录屏能核对交互和画面，无法确认 Lucky7 私有 API 或它使用的后台软件。录屏中的订单号、余额和银行账户资料省略。

| 按钮 | MASTER7 当前行为 | 下一版验收行为 |
|---|---|---|
| 充值 `Deposit / Top Up / Tambah Nilai` | 首页并列展示支付公司。VPay 要填金额、通道及付款人。两家建单成功后页面再显示 `Open payment page`，会员要再点一次。 | 钱包首页只保留 **充值** 和 **提款** 两个主按钮。充值页先填 MYR 金额，再显示实际可用的付款方式和渠道。点一次「继续付款」后，由后台建单，并在当前页打开厂家返回的该笔付款链接。只有确实需要的付款人、银行或通道字段才显示。 |
| 提款 `Withdraw / Send / Pengeluaran` | `/api/withdrawals` 有会员提款流程和状态，但 VPay、1MPAY 的供应商提款适配未接通。 | 会员在 MASTER7 选择或新增本人马来西亚银行账户、填金额、确认并查看状态。后台处理审核、保留金额、出款、查单和对账。余额、最低额、提款条件由 MASTER7 已确认的设置决定。 |
| 游戏厂商图块 | 目录可展示多家。现有前端对非 MegaH5 给等待提示。MegaH5 在已批准会员点游戏时发起平台请求并尝试打开新窗口。 | 首页每厂商一张图块，标明 `FREE / 免费` 或付费区。点厂商进入该厂商可玩的游戏页或已验收的厂商大厅。点具体游戏时，由 MASTER7 服务端开游戏会话并打开返回的游戏链接。维护或未接通图块明确标状态。退出后显示结算及退回钱包结果。 |
| 登录与错误提示 | 充值与开游戏均要求已批准的 MASTER7 会员。MegaH5 还受弹窗、未结算游戏钱包、可用游戏和网络地址等条件约束。 | 只提示会员登录 MASTER7。付款页面或银行页面的付款验证由对应机构处理。支付公司商户后台、游戏厂商运营后台属于员工端。失败或等待状态显示发生在哪一步及安全的下一步。 |

当前部署的充值区 CSS 使用深蓝底与金色。`.71` 发布记录重点为前台路由兼容、旧链接和 favicon，当前包中依然有独立支付公司卡片和二次付款链接，尚未达到录屏所示的钱包交互。目标模板为 **MASTER7 水蓝、金、白**，沿用参考的分组、操作顺序和状态呈现。Lucky7 的颜色、品牌、支付公司与金额门槛仅供对照。

证据：用户录屏 `1000120121.mp4` · [当前发布记录及构建包](https://github.com/jackysim47-star/master7/commit/bac36137b3fe2cfc26cb64422ac7e91acd9c4258)

## 3. 已查到的 API 与接线缺口

| 模块 | 已确认 API | 交接要求 |
|---|---|---|
| VPay 充值 | MASTER7 `POST /api/payments/vpay/orders` → 集成网关 `POST /platform/vpay/order` → VPay Trader REST 的 `TRADER_ORDER`。独立查单用 `ORDER_GET`，付款通知由网关接收后转发。 | 用两条 `502` 的脱敏诊断定位上游 HTTP 状态、厂家业务码及是否取得外部单号。待确认订单先查单和对账，防止重复建单。验收付款页、回调、查询、钱包单次入账与结算。 |
| VPay 提款 | VPay Trader REST 的 `MONEY_OUT` 提交、`MONEY_GET` 查单。当前网关代码已有管理员提交及查询路由，通知走提款专用回调。 | 先核对商户提款权限、银行码、回调转发及出款开关，再接到 MASTER7 提款状态机。记录出款及失败、超时后的查询结果。 |
| 1MPAY 充值 | 1MPay API 1.3 的 `POST /fundtransfer/json` 返回付款 URL，`GET /transquery/{trxno}/{base64_token}` 查询。POST 通知走本次建单指定的 `post_url`。 | 当前代码要求付款 URL 在允许的供应商域和路径上。先从既有订单或获准 UAT 查 `trxno`、返回 URL、签名与状态。付款页面打开、付款成功与钱包入账分别留证。 |
| 1MPAY 提款 | 1MPay API 1.3 第 9 节 `POST /payout`。外层含商户标识与密封数据所需字段，收款银行、账户、金额及通知地址在业务参数里。 | 按该商户合同核对密钥封装、银行码、回调及验真规则。独立出款状态查询和重复提交约定需要商户文件或厂家确认后再实现。 |
| MegaH5 游戏 | MASTER7 `POST /api/game-launch` → `POST /platform/megah5/session` → 厂家 `GameLogin`，成功时用返回的游戏 URL。现有代码有进出游戏钱包、余额查询和退回处理。 | 用已批准会员、可用 MegaH5 游戏验证一次完整启动及退出。区分弹窗未开、没有发请求、厂家拒绝、游戏钱包处理中和回钱包失败。核对厂家返回地址，代码还有旧 `.vip` 的默认值，运行配置未在本轮确认。 |
| 其他游戏厂商 | 本轮确认 JILI、918KISS H5、Rectangle 有活动目录，EVO888 H5 条目在维护状态。目录不是启动协议。 | 每家按授权商户资料单独拿到启动或 SSO、玩家映射、钱包模式、余额、交易查询和回调协议，完成后再开放该厂商按钮。 |

VPay 和 1MPAY 的收款、提款与商户结算分别验收。普通网页跳转不能证明付款或出款成功。根域回调路径的 GET 也观察到 `302`，这条结果只说明域名转址行为。正式回调要直接验证实际配置的 POST 路由、验签、独立查单及唯一入账。不要根据 GET 结果改动当前两家已配置的回调。

来源：[VPay 官方 Trader API](https://gateway.vpay.club/api/doc/trader_en) · [1MPay API 1.3](https://chatgpt.com/library?file_id=libfile_fde3_f-5759dcf91b548191a8d7b867d8519a73_d20b3cd80aec8191a04f49e80462f2e8&account_id=personal) · [网关部署对应实现](https://github.com/jackysim47-star/master7/blob/7f65d6a2527229f347bcd521d7c07ed8eb717c5f/master7-gateway/server.js) · [三家支付交接资料](https://chatgpt.com/library?file_id=libfile_fde3_f-c23e5e8135f48191823f00dd5dd26ec4_d20b3cd80aec8191a04f49e80462f2e8&account_id=personal)

录屏供应商的公开资料方面，Rapidpays 发布了 `POST /rapidpay_api/create_bill/` 建单文档。未核实 Lucky7 自有钱包 API 或录屏中 Kaazpay 商户对应的接入合同。这个公开文档只用于对照「服务端建单后打开付款页」的交互，MASTER7 仍按指定的 VPay、1MPAY、GSPAY 分别接线。来源：[Rapidpays API 2.7.0](https://www.rapidpays.com/Api)

## 4. XBTECH 可参考的功能范围

前一份 XBTECH 研究记录了公开候选页面的账户、语言、VIP、活动、电子、真人、体育、彩票、下载、客服和银行帮助菜单。候选页面同时使用其他品牌，归属未确认，本轮复查首页和活动页返回 502。XBTECH Studio 公开官网展示网站和定制系统业务。现有证据不足以认定两者是同一家博彩供应商，也没有可验证的 XBTECH 员工后台或完整模板。因此前台菜单可参考已有公开记录，后台应以 MASTER7 的需求和授权演示验收。最新录屏补齐的是 **Lucky7 钱包**，不用于认定 XBTECH 私有功能。

| 后台模块 | 交接范围与验收证据 |
|---|---|
| 登录与会员 | 老板和员工使用同一后台入口，员工 ID 与密码，重设密码与操作权限。会员查询、状态、资料及历史记录。用测试账号留登录、拒绝、停用及脱敏截图。 |
| 总览与财务 | 注册会员、充值人数及金额、提款、营业记录和 MYT 日期筛选。钱包账本、订单状态、支付渠道、异常与对账。报表和 CSV 要与同一数据源核对。 |
| 游戏与运营 | 厂商、图块、排序、分类、免费及付费、维护控制、游戏钱包流水、优惠、VIP、推荐与提成。用真实接线状态及测试流水证明每个可用功能。 |
| 内容与客服 | 横幅、公告、三语、下载、教程、公司社媒、WhatsApp、WeChat、Telegram 和 Line。AI 客服独立开关与转人工，客服权限与资金操作分开。 |
| 安全、备份和监控 | 审计、只读巡检、授权日志、旧资料备份、独立恢复验证与回滚。旧数据保全和新站部署分开签收。 |

来源：[XBTECH 研究与菜单索引](https://chatgpt.com/library?file_id=libfile_fde3_f-276fbfbb3a548191bf606b6f9d23f1da_d20b3cd80aec8191a04f49e80462f2e8&account_id=personal) · [XBTECH Studio 官网](https://xbtechstudio.com/)

## 5. 昨天的 MASTER7 功能交付清单

| 要求 | 当前证据 | 签收项 |
|---|---|---|
| 两个正式入口、V15 目标 | `.71` V17 在 Render 运行。`www` 正式前台 DNS 未就绪。 | 固定前后台各一条入口，部署目标版本与回滚点写清楚。手机与电脑分别核对最终 HTTPS 地址。 |
| 前台 OTP 小锁、后台 ID 与密码 | 健康接口报告 OTP 已配置。公开后台有登录入口。 | 客户注册、登录、OTP 到达及有效期，员工登录和密码重设分别实测。前后入口显示公司名称和 Logo。 |
| 水蓝、金、白及中英马来文 | 当前源码有多语资源和深蓝、金色充值卡。 | 同一模板覆盖手机与电脑的首页、钱包、游戏、登录和后台关键页，三语各验一遍。 |
| 马来西亚 MYR 钱包、三家充值 | VPay、1MPAY Active，GSPAY 关闭且配置未完成。 | 每家分别验付款链接、独立查单、钱包只入一次、后台订单同状态及结算。 |
| 提款与马来西亚银行 | 现有申请界面及后台记录有源码。两家提款适配未接通。 | 会员银行账户选择、资格与金额提示、审批、出款、失败恢复、账本和对账。 |
| 厂商按钮、免费/付费、三段赞助教学 | 有厂商和游戏目录。现有可启动代码仅 MegaH5。 | 每家独立 Logo/入口、FREE 标记、三段教程位置与资源、移动端游戏启动和退出退回余额。 |
| Android APK、iPhone 安装、客服与社媒 | 当前模板已有 Android APK 下载链接和 iPhone Safari Web App 安装入口。现有模板也有客服、社媒和 AI 设置相关代码。 | 真机验证下载与安装，逐个验证公司账号 URL、客服对话和转人工。iPhone 当前设计为 Web App。 |
| 后台营销、VIP、代理与数据保护 | 代码有运营与营销界面、VIP/福利、推荐和佣金预览以及备份入口。 | 验证名单导入字段、去重、发送权限、退订与统计。核对优惠规则和佣金是否真实入账。旧会员与余额单独验恢复、回滚和一致性。 |

来源：[昨日全功能与源码交接](https://chatgpt.com/library?file_id=libfile_050ab62937208191afbbd7f20e842639&account_id=personal) · [部署交接](https://github.com/jackysim47-star/master7/blob/bac36137b3fe2cfc26cb64422ac7e91acd9c4258/HANDOVER.md)

## 6. 交接验收顺序

1. 固定正式前台、后台与部署版本。保全并验证可恢复的备份。先验 `www` DNS、证书、路由和手机打开。
2. 按 Lucky7 录屏做统一钱包，分别演示充值与提款。把实际供应商状态映射成可用、维护、待确认、成功或失败。手机一次「继续付款」打开该笔付款页面。后台保存安全的失败原因和订单关联。
3. VPay 从现有 `502` 入手，1MPAY 从既有订单或获准 UAT 入手。以服务端确认、钱包唯一入账、后台一致和结算记录签收。提款独立验证两家供应商权限和状态闭环。
4. 先验证 MegaH5 会员启动及退回钱包，再逐家补齐其他厂商启动和钱包协议。任何没有实测通过的图块维持明确的不可用状态。
5. 提交手机和电脑截图、脱敏请求和订单证据、三语验收表、备份恢复记录及开关清单，按用户确认的时点交接运营权限。

## 7. 本次核查记录

- 门户发布 `dep-dbmu83egekts73efpavg` 于 22:29:56 MYT 成为 live。部署提交 `bac36137b3fe2cfc26cb64422ac7e91acd9c4258`。按部署命令解包检查，归档 SHA-256 与发布记录一致。
- 集成网关 `dep-dbmu87utlv9c73c0g5o0` 于 22:29:15 MYT 成为 live。提交 `7f65d6a2527229f347bcd521d7c07ed8eb717c5f`。网关健康范围为进程状态，版本 1.10.1。
- 日志检查范围从 22:00 MYT 起至本轮查询。VPay 的两组 `202 / 502` 是既有请求，不能关联到特定用户。支付状态和目录用公开 GET 核对。未登录会员进行充值、提款或游戏启动，也未改动部署与资金开关。

部署记录：[门户](https://dashboard.render.com/web/srv-dbl0iv7f3r2c73848ei0/deploys/dep-dbmu83egekts73efpavg) · [集成网关](https://dashboard.render.com/web/srv-db6b7inlk1mc73ck6cmg/deploys/dep-dbmu87utlv9c73c0g5o0)
