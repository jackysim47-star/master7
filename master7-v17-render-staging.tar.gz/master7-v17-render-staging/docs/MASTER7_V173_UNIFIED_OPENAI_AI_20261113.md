# MASTER7 V173 Unified OpenAI AI Gateway

## Purpose

V173 now has one server-side OpenAI-compatible gateway for non-transactional AI
tasks. The gateway can support customer replies, read-only operations and
handover summaries, and translation assistance.

It is not a game, payment, payout or wallet adapter. Lebet, VPay, GSPAY and
1MPAY still require their own official contracts, credentials, callbacks,
UAT evidence and acceptance records.

## Render configuration

Set these values only in the Render service environment; never commit or send
the key through chat:

```text
OPENAI_ENABLED=false
OPENAI_API_BASE_URL=https://api.openai.com/v1
OPENAI_API_KEY=
OPENAI_MODEL=
```

The existing `SUPPORT_AI_*` names remain as a temporary compatibility fallback.
When both names are present, `OPENAI_*` takes precedence.

## Safety boundary

- API keys are server-only and are not returned by `/api/admin/ai-status`.
- The gateway has no tools and cannot submit deposits, payouts, game launches,
  wallet transfers, approvals or settlement changes.
- Prompts redact passwords, OTPs, bank-number-like values, tokens and keys.
- Provider errors, timeouts, missing configuration and invalid responses return
  to the built-in multilingual rules fallback.
- Money, account-security, complaint and unavailable-record cases remain for
  staff review.
- The V173 staging game/payment/payout switches remain closed.

## Read-only status

Owner or Staff may read:

```text
GET /api/admin/ai-status
```

The response reports provider readiness, model configuration, allowed task
names and the non-transaction boundary without returning secrets.

## Acceptance

The implementation is staging-ready after the source tests, typecheck, lint
and Render build pass. Configuring an OpenAI key only enables the AI layer; it
does not change Lebet/payment readiness or the V173 production `NO-GO` status.
