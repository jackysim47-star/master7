# GSPAY post-credit status conflict — local `.118` candidate

A signed GSPAY payment callback binds the payment reference, order and amount,
but the documented signature does not bind the `completed` and `success`
fields. A contradictory or incomplete notification on an already credited
order now triggers an independent provider query rather than changing the
wallet based on the notification alone.

- If the independently bound query confirms success, retain the existing
  balanced ledger and acknowledge; an ordinary duplicate success remains
  idempotent.
- If the query reports a terminal failure or nonterminal state after credit,
  preserve the ledger, move the same order to review under the member lock,
  and prevent spending while it requires reconciliation.
- A query binding conflict holds only the matching current credited snapshot;
  a stale result cannot freeze a changed member, amount or reference.
- A query failure returns a retryable response and does not alter the ledger.
  Member refresh of a credited order also performs the independent query.

All verification uses synthetic replies and isolated data. The supplier has
not confirmed every state transition or retry behavior, and no real reversal or
payment acceptance is asserted. Existing payments, real callbacks and wallet
records still need provider-side reconciliation.

The earlier GSPAY direct-host startup discrepancy is not fixed by this change.
Its legacy shared channel status can affect payout; changing it safely requires
an independent payout authorization design and separate acceptance. This local
candidate has not been deployed, and the previous mixed-version, database,
backup, domain and production sign-off conditions remain open.
