# MASTER7 V17 · v8 release gate

Candidate release: `17.0.0-selfbuilt.100-maintenance-gate`.

This package is a fail-closed deployment candidate. It does not authorize a production deployment, real payment, payout, game launch or provider settlement.

## Build gate

Render must run the complete local gate before producing the Node bundle:

```bash
npm run verify:render
```

The command runs the dedicated maintenance matrix, read-only probe tests, all regression tests, Render TypeScript validation, ESLint, the Render database adapter test and the Render-target build. Any failure stops the build.

The startup migration transaction takes a PostgreSQL advisory lock before applying schema or seed changes. This prevents concurrent instances from racing the same migration during scaling.

## Runtime safety

Set all three variables explicitly to `false` for the first deployment:

```text
PORTAL_NEW_DEPOSITS_ENABLED=false
PORTAL_NEW_GAME_LAUNCHES_ENABLED=false
PORTAL_NEW_PAYOUTS_ENABLED=false
```

`/health` and `/api/payment-channels` expose whether all three controls were explicitly configured. An unset value remains closed but fails the release probe, so an accidental default cannot count as deployment evidence.

Render instance health must use `GET /health/live`. It checks the application and database only and never contacts a payment or game provider. The broader `/health` route remains an operational-readiness endpoint and may wait for provider capability checks.

## Post-deploy read-only probe

Run this against the Render candidate URL before mapping a production domain:

```bash
PRODUCTION_BASE_URL=https://candidate.example \
  npm run probe:production
```

The probe sends unauthenticated `GET` requests only. It rejects redirects, credential-bearing URLs, cacheable responses, release drift, implicit maintenance configuration, active payment or payout channels, fewer or more than 37 provider positions, and any unverified playable provider. It does not submit a payment, launch a game, alter a wallet or write a rate-limit record.

## Database evidence gate

Create a dedicated read-only PostgreSQL credential available only to the release operator, then run:

```bash
PORTAL_READINESS_DATABASE_URL='postgresql://read-only-role@private-host/database' \
  npm run probe:database
```

The gate uses one `REPEATABLE READ READ ONLY` transaction and always rolls it back. It reads schema metadata, the migration ledger, and the latest backup/restore evidence. It never reads member, wallet, deposit or withdrawal rows and never prints the connection URL, database name, role name or receipt contents.

The gate requires:

- the exact classified runtime tables and required migration markers;
- a database role without database/schema creation or table-write privileges;
- a current transaction-snapshot encrypted backup bound to this release;
- a complete rollback-only restore rehearsal in a separately named PostgreSQL restore/test database;
- receipt hashes, schema version, row totals and timestamps that match the most recent backup audit.

Creating another backup invalidates the previous restore receipt until that new backup is rehearsed. A synthetic hash or legacy/incomplete receipt cannot mark recovery ready.

## Render target

The reviewed Blueprint candidate uses:

- health check `/health/live`;
- autoscaling min `1`, max `5`, CPU `70%`, memory `75%`;
- `PG_POOL_MAX=3`;
- auto-deploy disabled;
- the complete `verify:render` build gate;
- all three new-operation switches explicitly closed.

Blueprint sync changes live service settings immediately even when auto-deploy is disabled. Review the diff, preserve existing secrets, capture the database backup and rollback checkpoint, and obtain the separate production change approval before syncing it.

After deployment, keep new operations closed while running the public probe, database evidence gate, DNS/TLS checks and controlled provider acceptance. Existing callbacks, order queries, settlement and recovery paths remain available under their existing authentication and idempotency controls.
