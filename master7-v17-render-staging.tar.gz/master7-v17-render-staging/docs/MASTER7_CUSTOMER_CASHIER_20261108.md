# MASTER7 customer cashier and interface repair — 8 November 2026

Source release: `17.0.0-selfbuilt.98-customer-cashier`.

## Customer behavior

The deposit page starts with three independent VPay, GSPAY+ and 1MPAY brand entries. A brand opens its own cashier dialog and reads that provider's status immediately. An unrelated bank-account or wallet request cannot delay the selected provider's form. An unavailable provider is never silently replaced with another provider. Manual bank receipt submission remains a separate secondary entry; wallet balances and existing payment records remain separate from the cashier.

The cashier preserves each existing order contract. VPay requires amount, trade code and payer name. GSPAY+ and 1MPAY use the existing amount/request-key payloads. A validated checkout URL opens in the same tab for all three, with a visible fallback link when navigation is interrupted. Existing exact checkout host/path/query rules remain enforced. The portal does not invent a provider landing page or claim a payment completed because a browser returned.

Requests have a submission guard. Ambiguous results retain their original request key and link to existing records; the UI does not automatically repeat a POST. Only the existing terminal-state rules release an attempt. Cached attempts are bound to the current member and storage key. A delayed response after logout or an account change cannot populate another member's cashier, cache or checkout navigation. The original member's key is preserved. Cache metadata is not sent to a vendor, and checkout URLs are not newly persisted in browser storage.

Login/approval failures, local conflicts, validation failures, definitive provider rejection and unconfirmed results are displayed distinctly. Known 409 codes have Chinese, English and Bahasa Melayu explanations. These include request-in-progress, idempotency mismatch, daily/weekly/monthly limits, cooling-off and self-exclusion. Those protections remain operational.

## Confirmed backend defect and bounded fix

A saved, less restrictive deposit limit has an existing 24-hour effective-time rule. Before this release, a direct first deposit POST after that time could reserve against the old allowance unless the member had already loaded the settings page. The failed reservation applied the matured change only while explaining the failure, then incorrectly returned `DEPOSIT_LIMIT`.

The reservation path now calls the existing `applyMaturedLimits` before its atomic allowance check. It does not change the saved limit, effective time, cooling-off or self-exclusion. Regression coverage demonstrates the old 409 and corrected 201 for the same matured-limit scenario, rejection before the effective time, and continued rejection during an active self-exclusion.

Original-order recovery remains protected: a duplicate request before an order exists is blocked as in-progress; a creating order returns unconfirmed; a created order returns the existing checkout. The test sequence invokes the simulated provider create endpoint once and writes no wallet ledger entries.

The five observed production VPay create-request 409 responses on 8 November between 05:14 and 05:18 UTC identify a local platform conflict, not a directly forwarded vendor 409. Their specific cause is not known from request logs. The matured-limit defect is independently reproduced; it must not be represented as the proven cause of those five requests.

The three create routes now emit a fixed `payment_order_conflict` diagnostic containing only provider, HTTP 409 and an allowlisted code. No account, amount, payer name, request key, credential, provider response body or checkout URL is logged. Response semantics and original vendor contracts are unchanged.

## Frontend and backoffice cleanup

- Hide unimplemented Events competition, deposit-wheel, jackpot and lucky-draw previews/editors. Retain the actual local lobby preferences and existing-message shortcuts.
- Hide unimplemented Rewards missions, referral milestones and coupon previews/editors. Retain actual daily check-in, non-cash points and history. Saving the remaining settings preserves all hidden configuration JSON.
- Remove the five reserved custom-game slots' UI, bindings and loaders, the duplicate static suite directory, and a permanently disabled marketing placeholder. Keep stored data, backend compatibility, all 34 vendor brands, the three payment brands and actual per-campaign marketing actions.
- Retain the complete owner manual and customer guides; remove duplicate admin quick guides.
- Align owner-only navigation/backup/export visibility with existing server permissions. Fix the mobile sidebar rule that could override hidden links. Staff Live Chat now reaches the existing ticket surface.
- Rename the records-only withdrawal section accurately. Display game-wallet capability reasons separately from settlement acceptance.
- Prevent stale financial report responses from overwriting a newly selected period. Make VIP fixed level/color fields read-only, and preserve other editable rules.
- Correct ticket refresh pagination and member-scoped manual-bank display state; remove obsolete hidden category/supplier controls.

## Verification and limits

Local behavior regressions exercise the actual frontend functions, real SQLite routing and simulated vendor responses under a network guard. Full candidate CI must run all tests, including the hosted-identity boundary, and build the actual Render application before the archive is promoted. Release receipts identify the exact source commit, archive hash and complete test results.

No test here creates a production payment order, submits a payout, starts a game, transfers customer funds or credits a wallet. Three configured payment adapters do not establish real settlement acceptance. Four fresh catalogues do not establish four playable platforms. This source retains the existing game-adapter coverage and honest acceptance fields.

Local Chromium visual execution was blocked by the environment's socket restriction; an escalation for an in-memory test page was rejected by its approval policy. The offline browser script is not counted as a passing test. Public browser/served-asset verification after deployment and synthetic interaction tests are separate evidence; neither is an authenticated member payment acceptance.
