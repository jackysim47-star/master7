# MASTER7 iPhone Web App

Release `17.0.0-selfbuilt.54-ios-web-app` supplies the iPhone entry requested by the XBTECH handover checklist without claiming an unsigned native App Store application.

## Customer installation

1. Open `https://master7.best/` with Safari on the iPhone.
2. Tap Safari's **Share** button.
3. Choose **Add to Home Screen**.
4. Confirm the name `MASTER7` and tap **Add**.

The lobby also contains an **iPhone 安装** button with the same Chinese, English and Bahasa Melayu instructions.

## Installed behavior

- Opens in standalone mode from the iPhone home screen.
- Uses the MASTER7 name, theme colour and icon.
- Starts at the protected member sign-in page.
- Keeps authentication, registration, wallet, deposit, withdrawal and support requests on the live server.
- Displays a local no-network page only when a navigation request cannot reach the server.

## Security and cache boundary

The service worker caches only the public interface shell: stylesheet, JavaScript, public logo, manifest, favicon and offline page. It does not intercept or cache `/api/` requests or `/downloads/` files. Navigation remains network-first, so account state and authorization cannot be served from an offline copy.

## Native iPhone package boundary

This release is an installable Safari Web App. A native iOS IPA or App Store release requires an Apple Developer account, bundle identifier, signing certificate, provisioning profile and Apple review. No native package is represented as complete without those materials.
