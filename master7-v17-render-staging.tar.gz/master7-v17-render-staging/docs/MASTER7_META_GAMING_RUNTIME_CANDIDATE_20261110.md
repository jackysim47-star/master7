# META GAMING runtime candidate

This change compiles independent server-side adapters for
`metagaming_normal_myr` and `metagaming_free_myr`. It does not enable either
profile, publish a Play button, or record supplier acceptance.

## Safety boundary

- Normal and free-credit use different profile, player and ledger namespaces.
- The account is derived from the compiled profile and is checked again by the
  integration gateway. A browser cannot select credentials or an API origin.
- Player/launch, wallet, recovery and report requests use four different peer
  tokens. Aliased or malformed tokens reject the entire secret document.
- All submission switches are false unless a server-side profile document
  records merchant-contract evidence, session-closure evidence and an
  authorized QA member or production acceptance.
- Only English is implemented. The portal sends the gateway's reviewed `en`
  value for provider English `en-us`. Customer returns require the exact
  `https://www.master7.best` origin, and provider launch URLs require an exact
  configured HTTPS origin.
- Deposit and withdrawal responses do not contain transaction IDs. Their
  result stays `unknown` until `CheckTransferStatus` returns the original
  account-bound reference and exact amount.
- `PullLog` has no requested-time-window coverage receipt. Pages therefore
  remain `complete:false`; the adapter never calls `FlagLog` automatically.
- The free-credit profile is executable for isolated protocol testing but is
  rejected by the existing cash-ledger seeding gate.

## Remaining external blockers

The supplier must clear the current HTTP 403/allowlist response and confirm
merchant amount semantics, issued-URL invalidation, late-result finality and
report acknowledgement. Controlled QA and production evidence are still
required before any capability can be enabled.
