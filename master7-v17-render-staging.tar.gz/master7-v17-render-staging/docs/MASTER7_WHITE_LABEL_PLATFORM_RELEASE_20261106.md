# MASTER7 white-label platform release · 2026-11-06 MYT

Release: `17.0.0-selfbuilt.72-white-label-platform`

## Customer experience

- The outer lobby contains the fixed 34 supplier platforms. It never expands
  the internal game catalogue into hundreds of customer-facing cards.
- HOT, SLOT, LIVE, FISH, COCK, SPORT and FAV filter platform entries. A
  supplier may appear in more than one evidenced category; COCK stays empty
  until a supplier confirms that classification.
- The three free sponsored placements remain separate from the 34-platform
  directory. Each sponsored placement and each platform has independent art.
- Platform clicks show the actual connection, maintenance or pending state.
  No platform is marked playable without a platform-level launch adapter.
- The public platform summary reads local cache and control state. Opening the
  lobby does not wait for supplier catalogue requests.

## Member and backoffice flow

- Member sign-in uses MASTER7 ID, password and an OTP sent to the registered
  Malaysian mobile. Owner and staff sign in separately on `/admin`.
- Deposit and withdrawal initiation stays member-only. Company banks, receipt
  review, deposit records and withdrawal review stay in the backoffice.
- The backoffice includes all 34 benefit scopes, company advertising, built-in
  first-response support, Telegram outbound-alert status, referral management
  and MYT accounting reports.
- Telegram credentials remain server-only. The panel reports `Waiting` until
  valid Render environment values are supplied.

## Preserved boundaries

- Supplier and internal game IDs are not renamed or reassigned.
- Internal per-title catalogue controls remain available to backoffice code,
  but the customer API returns `games: []`.
- Payment and game switches keep their deployed values; this release does not
  turn a disabled financial or supplier channel on or off.
- Benefit calculations and claim records remain preview-only. Wallet credit,
  wager ingestion, turnover enforcement and VIP publication stay blocked until
  their production contracts are verified.

## Validation

- Full Node test suite, TypeScript, JavaScript syntax and ESLint.
- Render database-adapter tests and the Render production build.
- Public API assertions for exactly 34 platforms, no internal titles and no
  supplier fetches from the customer lobby.
- Authentication assertions for member OTP, owner/staff routes, role-specific
  logout destinations and trailing-slash routes.
