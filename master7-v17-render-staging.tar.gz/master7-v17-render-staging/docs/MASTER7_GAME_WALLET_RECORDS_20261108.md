# MASTER7 V17 game wallet records and payment boundaries

Local candidate: `17.0.0-selfbuilt.105-game-wallet-records`. This candidate is
not deployed and does not certify production payments or game settlement.

## What changed

- Members can read only their own existing generic profile session, reserved
  amount and related transfer records. This is a read-only view: a visible
  profile, session or provider transfer does not mean the supplier, launch,
  settlement or recovery is live.
- The shared owner/staff backoffice shows generic sessions, their latest
  transfer reference, and unmatched game reservations for investigation. It
  does not expose a new money-moving button.
- A late browser response cannot replace the current member's wallet or
  selected profile. Closing a game window refers to the member, profile and
  session captured at launch; an obsolete session identifier cannot settle or
  recover a later MegaH5 session. Requests that omit the optional session
  identifier retain the previous behavior.
- The MYR deposit report now restricts totals, provider breakdown and details
  to MYR; it cannot add any future USDT minor units to MYR totals.
- No new provider was wired to a wallet adapter. Generic profile settlement and
  recovery remain unavailable; the JDB and VENUS protocol work is not live.

## Payment channel status

VPay, GSPAY MYR and 1MPay have separate local order, callback, provider-query,
recovery and MYR ledger code paths. Their real provider payment, callback and
wallet credit remain unverified until matched end-to-end evidence exists.
GSPAY USDT has a separate, disabled profile, without an order or credit adapter.
Its network, precision, currency accounting, signing, callback and query
contract require provider confirmation; it must never be credited as MYR.

Production recovery configuration and scheduling must be verified separately.
In particular, 1MPay can acknowledge an authenticated callback whose
independent provider query has not established success; recovery is needed to
revisit any unresolved order. Provider retry and acknowledgement behavior must
be confirmed from its contract before making changes.

Historical paid-but-uncredited funds require matching the provider reference,
amount, currency, merchant, time, platform order, callback/query and balanced
ledger before any financial correction. Local simulated tests do not reconcile
production transactions.

## Operational requirements

Migration `0110-game-provider-adapter-core`, backups and a verified isolated
restore remain prerequisites for rollout. Keep previous data and unresolved
reservations. Rotate credentials previously shared in chat and supply replacements
through the existing secret manager. Real traffic, provider activation,
production changes and production acceptance require separate sign-off.
