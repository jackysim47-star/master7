# Deposit evidence and game acceptance candidate .113

Local candidate only; it does not modify production, execute real payments or
certify providers. VPay and GSPAY MYR order creation, callback and query only
report an existing credit after one consistent current-order and balanced-ledger
check. Provider response identity, MYR amount and reference must match the
validated order. Checkout links must match the stored order.

Under the member guard, a prior incomplete or conflicting ledger is kept
unchanged and the order is marked review. Conflicting provider success/failure
observations preserve existing ledger and require review. GSPAY review
callbacks now use HTTP 409 instead of an OK acknowledgment. The provider's
actual ACK and retry contract is not verified; confirm it before any rollout.

Unverified provider catalogues remain visible but cannot be marked playable
or launched. Existing game settlement/recovery remains available. MegaH5
zero-balance launch is blocked because the current schema cannot track such a
provider session durably. The launch-versus-settlement race is reproduced
locally and remains unresolved; see MASTER7_GAME_LAUNCH_SETTLEMENT_RACE.md.
A provider close-session/in-flight wager contract must also be confirmed.

GSPAY USDT has an independent placeholder only; the supplied material does not
confirm its network, precision, API, callback or conversion/ledger contract.
Do not use MYR assumptions to enable it.

Use a maintenance window and prevent old/new financial writers running at the
same time when evaluating deployment. No live payment, vendor settlement,
production migration or owner signoff is asserted by local tests.
