# MASTER7 v165 acceptance ledger integrity

Release: `17.0.0-selfbuilt.165-acceptance-ledger-integrity`

## Scope

v165 hardens the durable evidence used to decide whether game-provider and
production capabilities have passed acceptance. It does not contact a provider,
enable a payment channel, launch a game, change DNS, or open any production
feature flag.

## Durable behavior

- Migration 0122 requires every acceptance history to start at revision 1 and
  remain contiguous, and rejects updates and deletes of acceptance events.
- PostgreSQL statement triggers reject `TRUNCATE` on both event tables and both
  current-projection tables; readiness requires all four guards to be enabled.
- Each current projection can only be inserted at the latest event or advanced
  exactly one revision to the latest event; projection deletion is rejected.
- Acceptance reads independently derive the true latest event from history and
  fail closed when a projection is missing, stale, or points elsewhere.
- Acceptance writes compare optimistic concurrency tokens with the true latest
  event and refuse to write through a damaged projection.
- PostgreSQL startup readiness requires migration 0122 and the enabled wallet
  and acceptance-integrity triggers.

## Backup and recovery

The encrypted-backup schema version is `0122-acceptance-ledger-integrity`.
The table manifest remains unchanged. An archive with the exact v164
`0121-jdb-wager-coverage-staging` manifest remains recoverable with complete
table coverage; altered manifests are rejected. A current production backup and
isolated restore rehearsal are still required before readiness can pass.

## Release state

This document describes source code and local or isolated-database validation.
Production acceptance, provider certification, real-money payment evidence,
DNS cutover, activation flags, and owner sign-off remain separate fail-closed
requirements.
