# MASTER7 deposit rejection and retry recovery

Release: `17.0.0-selfbuilt.75-deposit-rejection-recovery`

This release separates a provider's explicit business rejection from an
ambiguous transport outcome for VPay and 1MPay deposit creation.

- A non-zero provider result that completed normally and issued neither a
  provider order reference nor a checkout destination is stored as `failed`.
  The member may make a new explicit attempt with a new idempotency key.
- Timeouts, network failures, malformed replies and replies that include a
  provider order reference remain `unknown`. The same idempotency key is kept
  and no second payment order is submitted automatically.
- Historical `unknown` orders are changed to `failed` only when that member's
  sanitized audit fact proves the same explicit rejection and the order still
  has no provider reference or checkout URL.
- The member interface clears a stored attempt only for `credited`, `failed`,
  `expired` or `cancelled` records. Its provider request timeout is 35 seconds,
  which covers the current server request budget.

The release does not change provider credentials, IP allowlists, channel
switches, callback secrets, settlement flags, wallet balances or payout
settings. Tests use synthetic provider responses and do not create or pay a
real order.
