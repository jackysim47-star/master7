# MASTER7 v157 member guide polish

Release: `17.0.0-selfbuilt.157-member-guide-polish`

This release completes the English-first water-blue member presentation started
in v156.

- Customer quick guides use clear English text throughout the member portal.
- The guide summary uses `Member guide · How it works` instead of the former
  Chinese technical label.
- Member guides now use a subtle white and water-blue card with navy text,
  matching the customer shell instead of the old black technical panel.
- Administrative guide styling and all backoffice functions remain unchanged.

At 393 px viewport width the customer page remains free of horizontal overflow.
Game and payment availability, launch controls, wallet controls and real-money
switches are unchanged and remain subject to their existing acceptance gates.
