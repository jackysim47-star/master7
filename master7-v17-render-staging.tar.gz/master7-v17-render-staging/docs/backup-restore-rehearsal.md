# Encrypted backup restore rehearsal

The portal backup is a release-bound logical backup. Its envelope and recovery
receipt include the application release, schema version, schema SHA-256,
creation time, verification time, table manifest and content hashes.

Create the backup in the owner portal and store the JSON file away from the
application database. Keep the matching RSA private key and its passphrase in
a separate secret store.

Run the lightweight SQLite verification first:

```sh
node scripts/verify-encrypted-backup.mjs BACKUP.json PRIVATE.pem PASSPHRASE.txt RECEIPT.json
```

For a PostgreSQL rehearsal, provision or select a database whose name includes
`restore`, `rehearsal`, `sandbox` or `test`. It must not be the URL configured in
`PORTAL_POSTGRES_URL` or `DATABASE_URL`.

```sh
export MASTER7_RESTORE_DATABASE_URL='postgres://.../master7_restore_2026'
pnpm backup:restore-dry-run -- BACKUP.json PRIVATE.pem PASSPHRASE.txt RECEIPT.json --confirm-isolated
```

The PostgreSQL tool creates a random schema inside one transaction, restores
and counts every table, checks that authentication sessions remain empty, and
always rolls the transaction back. A successful receipt therefore contains
`persistentWrites: false`; the tool has no path that persists the rehearsal.

Upload the current receipt through the owner recovery control. Readiness only
applies when the receipt matches the running release and schema hashes and is
still within the configured freshness window.
