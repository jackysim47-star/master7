# Encrypted backup restore rehearsal

The portal backup is a release-bound logical backup. Its envelope and recovery
receipt include the application release, schema version, schema SHA-256,
creation time, verification time, table manifest and content hashes.

## Coverage and compatibility

The current `0107-benefit-claim-reviews` contract contains 51 durable tables.
It includes `marketing_webhook_events`, which preserves callback deduplication
and opt-out event history, as well as the voucher workflow and benefit review
fields. The schema hash includes the exact ordered table manifest; adding the
previously omitted event table changes that hash without inventing a database
migration version.

Each table is paged in complete primary-key order, including all columns of
composite keys. Regression tests compare those keys with the actual release
migrations and export 2,005 rows sharing the same key prefix for each composite
table, checking that changing legal index plans cannot repeat or omit rows.

Four transient tables are deliberately empty after restoration:
`password_sessions`, `otp_challenges`, `rate_limits`, and
`responsible_play_locks`. People must sign in again. The responsible-play lock
row only serializes transactions and is recreated by the next operation;
`responsible_play_profiles` and `responsible_play_deposit_reservations` remain
in the backup, preserving limits, cooling-off/self-exclusion windows, pending
limit changes, and outstanding reservations.

The deployed 50-table 0107 manifest with schema SHA-256
`2648becd21723884358bcaf90f5928dc19c7cc58dcf090c87ca1db3c00c34d69`
is also accepted for recovery. Its receipt retains the old hash and uses
`status: "verified_legacy_coverage"`, `coverageComplete: false`, and
`missingTables: ["marketing_webhook_events"]`. Those missing records cannot be
recreated from the old file. Such a receipt does not satisfy the current
readiness contract. Other versions or unrecognized manifests fail closed;
this compatibility rule does not claim support for every historical backup.

## Capture consistency

On Render, `RenderD1Compat.withReadSnapshot` acquires one client from the pool
and starts `BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY`. Every table and
page is read through that client. The scoped reader accepts only the allowed
backup page SELECT form and has no write or batch method. Ordinary application
requests keep their existing pool path; this does not start a transaction on a
shared request connection or change session-wide isolation settings.

Once the rows are collected, the exporter rolls back the read-only transaction
and releases the client before hashing, gzip compression or RSA/AES encryption.
The owner route writes its backup-created audit event afterwards through the
ordinary database object. Begin/read failures still attempt rollback and discard
the client; rollback failures request client destruction. Release failures also
fail the export. No failure silently retries through non-snapshot reads.

The encrypted payload, envelope and metadata use
`readConsistency: "transaction_snapshot"` when the snapshot capability was used.
Sources without that capability, including native D1 and simple test adapters,
use `readConsistency: "unverified"`. Historical files missing this field are
also treated as unverified. The restore tools check envelope/payload consistency
and carry that value into their receipt; their existing restore-status and
readiness rules are unchanged. A successful restore receipt alone is not proof
that an unverified capture was consistent during concurrent writes.

PostgreSQL repeatable read fixes the snapshot at the first non-transaction-control
statement and reuses it for later reads. It must use one acquired client, not
`pool.query` across clients. Native D1 `withSession` provides sequential
consistency, which is not a substitute for this snapshot contract. See the
[PostgreSQL isolation documentation](https://www.postgresql.org/docs/current/transaction-iso.html),
[node-postgres transaction guidance](https://node-postgres.com/features/transactions),
and [D1 database API](https://developers.cloudflare.com/d1/worker-api/d1-database/).

## Run an isolated rehearsal

Use an authorized encrypted backup JSON file, its matching RSA private key,
and the private-key passphrase. Keep the file away from the application
database and the private key/passphrase in a separate secret store. Creating
a backup through the owner API writes an audit event; it is a separate
authorized action from running these local verification commands.

Run the lightweight SQLite verification first:

```sh
node scripts/verify-encrypted-backup.mjs BACKUP.json PRIVATE.pem PASSPHRASE.txt RECEIPT.json
```

This verifier builds a fresh in-memory database from every ordered SQL
migration in `drizzle/`, including 0105 and 0107. It restores only the exact
recognized manifest, checks each table's row count and all foreign keys, and
checks that the four transient tables remain empty. The database is discarded
when the process exits; only the optional receipt file is written.

For a PostgreSQL rehearsal, provision or select a database whose name includes
`restore`, `rehearsal`, `sandbox` or `test`. It must not be the URL configured in
`PORTAL_POSTGRES_URL` or `DATABASE_URL`. The name and URL checks are safeguards,
not proof of isolation: verify the target and use credentials scoped to that
disposable database. No application server or background worker should use it.

```sh
export MASTER7_RESTORE_DATABASE_URL='postgres://.../master7_restore_2026'
pnpm backup:restore-dry-run -- BACKUP.json PRIVATE.pem PASSPHRASE.txt RECEIPT.json --confirm-isolated
```

The PostgreSQL tool creates a random schema inside one transaction, restores
and counts every table, checks foreign keys through normal PostgreSQL inserts,
and checks the four transient tables. It uses the same schema initializer as
Render startup, so incremental marketing and benefit-review columns are
present. Initializer transaction commands become savepoint operations. Other
top-level transaction commands, including ones inside SQL batches, are rejected.
Payment activation options are not passed to the initializer; its seed data is
cleared before the backup rows are inserted.

The outer transaction rolls back after either success or failure, and the
connection is always closed. A rollback failure prevents a success receipt.
A successful PostgreSQL receipt includes `persistentWrites: false`. No backup
file is ever executed as code or used as SQL schema.

## Evidence and recording the result

The local regression suite creates an encrypted backup from synthetic SQLite
records with a temporary test RSA key. It verifies current 51-table restoration,
known legacy 50-table restoration, explicit transient-table exclusion, and
rejection of incompatible schemas and broken foreign keys. A coverage assertion
requires every release table to be either durable or explicitly transient.
The PostgreSQL unit tests exercise the actual initializer's SQL and the
savepoint/rollback lifecycle with a mock client; they do not replace a rehearsal
against an isolated PostgreSQL engine.

Snapshot regression tests also run two connections to a temporary SQLite WAL
database. Another connection commits row additions, deletions and updates after
the first export page; all exported pages and another table retain the original
snapshot. The PostgreSQL client contract is checked for single-client use,
read-only BEGIN, rollback/discard/release failure paths, and rejection of
statements retained after release. These local tests do not claim to have tested
concurrent PostgreSQL transactions on a running server.

Synthetic test success does not verify a production backup. Production recovery
evidence still requires a current backup file, the matching private key and
passphrase, successful restoration on the intended database engine, and review
of the resulting counts and business invariants. The exporter reads tables in
pages; point-in-time capture requires the snapshot-capable path described above.
An `unverified` file taken while writes are occurring does not by itself prove
point-in-time consistency. The `createdAt` timestamp describes file creation,
not an exact database snapshot timestamp.

After an actual authorized rehearsal, the owner API can record the receipt via
`POST /api/admin/backup` with `action: "record_rehearsal"`. That operation writes
the recovery setting and an audit event. It records supplied evidence; it does
not perform another restore. Readiness requires status `verified`, matching
running release/schema/key fingerprints, current table count, zero foreign-key
violations, and timestamps within the configured freshness window. Running the
local scripts neither calls this endpoint nor changes online readiness.
