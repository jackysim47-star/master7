# MASTER7 v166 database guard attestation

Release: `17.0.0-selfbuilt.166-database-guard-attestation`

## Purpose

Migration markers prove that a guard was installed once. They do not prove
that the physical PostgreSQL trigger still exists, remains enabled, or still
invokes the intended function. v166 adds a fail-closed attestation on every
portal database initialization.

## Startup contract

The portal verifies nine critical triggers covering provider-wallet contract
immutability and both acceptance ledgers. Each trigger must match the frozen
contract for:

- public table and trigger name;
- enabled state `O`;
- public trigger-function name;
- PostgreSQL trigger type;
- exact `UPDATE OF` columns where applicable.

The check runs after migrations 0120 and 0122 and before directory seeding,
inside the existing transaction and migration advisory lock. Missing,
disabled, duplicate, wrong-table, rebound, malformed, or wrongly scoped
triggers abort startup and roll back all work in that transaction. The startup
path never recreates or enables a drifted trigger automatically.

The PostgreSQL readiness gate imports this same frozen contract so startup and
external evidence cannot drift onto different trigger lists.

## Schema and operational scope

This release adds no table or migration. Backup schema remains
`0122-acceptance-ledger-integrity`, with its existing schema hash and 76-table
coverage. v166 does not change payment credentials, provider endpoints,
wallet balances, payment or game submission flags, DNS, or service plans.

## Verification

Unit tests cover the exact nine-trigger contract, ordering before seed,
idempotent second startup, rollback, and rejection of missing, disabled,
duplicate, wrong-table, wrong-function, wrong-schema, wrong-type, and wrong
column-binding evidence. The isolated PostgreSQL 18 test additionally damages
live trigger metadata after the migration marker exists, proves that restart
fails closed, restores the trigger explicitly, and proves that restart passes.

All provider and money paths remain closed during validation.
