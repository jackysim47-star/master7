# MASTER7 V173 Safe Layered Upload Policy

## Scope

This change separates non-financial artwork uploads from member payment-receipt
uploads in the V173 staging handover.

The following artwork categories can be activated after the existing server-side
image checks pass:

- company bank artwork;
- supplier artwork;
- lobby advertisements;
- custom-game artwork.

The server checks owner/staff authorization, JPEG/PNG/WebP data, the upload size
limit and valid image data. This policy does not call a payment provider or a
game provider.

## Receipt boundary

Member payment receipts are never automatically approved, credited or settled.
They remain pending for human review at `/api/admin/manual-bank/review`. AI may
help suggest a review result, but it cannot write wallet credit.

The receipt auto-approval value is hard-coded to `false` in
`lib/upload-policy.ts`; an environment value cannot override that boundary.

## Configuration

```dotenv
MASTER7_UPLOAD_APPROVAL_MODE=layered_safe
MASTER7_ASSET_AUTO_APPROVAL=true
MASTER7_RECEIPT_AUTO_APPROVAL=false
```

The read-only staff endpoint is:

```text
GET /api/admin/upload-policy
```

It exposes policy state only and never returns credentials.

## Deployment boundary

The package targets `v173_staging`. It does not deploy to Render, change DNS or
enable game, payment, payout or settlement switches. Lebet and payment-provider
contracts, credentials, UAT evidence and production sign-off remain external
requirements for a real production handover.
