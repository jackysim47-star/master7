# MASTER7 v156 member frontend polish

Release: `17.0.0-selfbuilt.156-member-polish`

This release gives the customer portal one consistent water-blue, blue and
white presentation while preserving every existing availability and money
control.

- Mobile member services use four large, readable Deposit, Withdraw, Games
  and Support entrances instead of a compressed menu.
- The company hero is shorter on mobile, the game-lobby heading has stronger
  contrast, and provider artwork, cards, spacing and typography share stable
  proportions.
- The bottom navigation grows to a touch-friendly height, adapts to four or
  five visible destinations and leaves safe page clearance above it.
- Sponsored providers remain independent, horizontally scrollable placements
  with a visible three-position cue.
- Mobile payment profiles are compact single-column rows with clearer labels.
- The retired Android APK promotion is removed from the member sign-in flow.
- Public catalogue wording uses customer-facing availability such as
  `Coming soon` and `Play coming soon`; internal API state labels and the
  `0 CONNECTED` counter are no longer presented as customer features.

At 393 px viewport width the page remains 393 px wide with no horizontal
overflow. The primary service buttons measure about 180 × 119 px, the mobile
dock is 70 px high and the compact brand hero is 237 px high.

This release does not enable games, deposits, payouts or real-money
operations. Supplier acceptance, launch, wallet, settlement and production
evidence remain required before Play can be enabled. Payment channels and
their operational flags remain unchanged.
