# MASTER7 V17 maintenance acceptance

Run the dedicated gate before every release candidate:

```bash
npm run test:maintenance
```

The suite uses migrated in-memory SQLite databases and in-process provider fixtures. It never contacts a payment or game provider and never moves real funds.

| Group | Acceptance boundary | Automated coverage |
|---|---|---|
| A · Deposits | VPay, GSPAY, 1MPay and Manual Bank cannot create new orders; existing queries, callbacks and deposit recovery remain available. | `maintenance-deposit.test.mjs` |
| B · Games | Universal launch and direct MegaH5 session preparation are blocked; an existing game can still settle. | `maintenance-game.test.mjs` |
| C · Payouts | New payout submission is blocked; an existing payout remains queryable and can complete through a verified callback or recovery query. | `maintenance-payout.test.mjs` |
| D · Mixed modes | Deposit, game and payout controls affect only their own operation. | `maintenance-matrix.test.mjs` |
| E · Existing transactions | Existing manual deposits, provider orders, payout records and game sessions remain intact; retries do not duplicate ledger entries. | All four files |
| F · Recovery | Deposit recovery, game transfer recovery and payout status recovery continue while new operations are closed. | Deposit, game and payout files |

Passing this suite proves the local maintenance boundary. It does not prove live provider connectivity, real-money settlement, production database recovery, DNS/TLS readiness or production sign-off.

For a release candidate, also run the complete build gate and the two read-only post-deploy gates described in `MASTER7_V8_RELEASE_GATE.md`:

```bash
npm run verify:render
PRODUCTION_BASE_URL=https://candidate.example npm run probe:production
PORTAL_READINESS_DATABASE_URL='postgresql://dedicated-read-only-role@private-host/database' npm run probe:database
```
