// Read-only gate: a legacy binary must not interpret another supplier's wallet
// as MegaH5. Run on the exact bound database before considering a legacy rollback.
import pg from 'pg';
const url=process.env.PORTAL_POSTGRES_URL??process.env.DATABASE_URL;if(!url)throw Error('The bound database is required');
const client=new pg.Client({connectionString:url,ssl:process.env.PGSSLMODE==='disable'?false:{rejectUnauthorized:true,...(process.env.PGSSL_CA?{ca:process.env.PGSSL_CA.replaceAll('\\n','\n')}:{})}});
await client.connect();try{
 await client.query('BEGIN READ ONLY');
 const result=await client.query("SELECT COUNT(*)::text records FROM game_wallet_sessions WHERE provider<>'megah5' OR profile_id IS NOT NULL");
 const operations=await client.query('SELECT COUNT(*)::text records FROM provider_wallet_operations');
 const safe=result.rows[0].records==='0'&&operations.rows[0].records==='0';await client.query('ROLLBACK');
 console.log(JSON.stringify({readOnly:true,legacyRollbackSafe:safe,providerSessions:result.rows[0].records,operationRows:operations.rows[0].records,reason:safe?'No new provider records exist':'Retain the newer wallet implementation and its recovery routes; do not roll back to a MegaH5-only binary'}));if(!safe)process.exitCode=2;
}catch(error){try{await client.query('ROLLBACK');}catch{}throw error;}finally{await client.end();}
