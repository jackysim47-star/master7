
function argument(name){const index=process.argv.indexOf(name);return index>=0?process.argv[index+1]:undefined;}
const date=argument('--date');
if(date&&!/^\d{4}-\d{2}-\d{2}$/.test(date)){console.error('Use --date YYYY-MM-DD (MYT).');process.exit(2);}
const endpoint=(process.env.ACCOUNTING_CLOSE_BASE_URL??process.env.RENDER_EXTERNAL_URL??'').replace(/\/$/,'')+'/api/internal/accounting-close',token=process.env.ACCOUNTING_JOB_TOKEN??'',idempotency=argument('--idempotency-key')??(date?`manual:${date}`:undefined);
if(!endpoint.startsWith('https://')&&!endpoint.startsWith('http://127.0.0.1:')){console.error('ACCOUNTING_CLOSE_BASE_URL or RENDER_EXTERNAL_URL must be an HTTPS origin.');process.exit(2);}
if(token.length<32){console.error('ACCOUNTING_JOB_TOKEN must contain at least 32 characters.');process.exit(2);}
const response=await fetch(endpoint,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${token}`,...(idempotency?{'Idempotency-Key':idempotency}:{})},body:JSON.stringify(date?{date}:{}),redirect:'error'}),raw=await response.text();
if(!response.ok){console.error(`Accounting close failed with HTTP ${response.status}.`);process.exit(1);}
let data;try{data=JSON.parse(raw);}catch{console.error('Accounting close returned invalid JSON.');process.exit(1);}
console.log(JSON.stringify(data,null,2));
