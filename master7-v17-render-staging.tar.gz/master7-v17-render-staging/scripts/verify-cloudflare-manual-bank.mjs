// Disposable Cloudflare workerd + D1 verification. Never deployed; synthetic funds only.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash, randomBytes, randomUUID } from 'node:crypto';

const source = process.env.MASTER7_VERIFICATION_SOURCE ?? fileURLToPath(new URL('../', import.meta.url));
assert.ok(source, 'MASTER7_VERIFICATION_SOURCE must name the candidate source directory');
const profileFlag = process.argv.indexOf('--game-profile');
const gameProfile = profileFlag === -1 ? '' : process.argv[profileFlag + 1];
assert.ok(profileFlag === -1 || ['jili_myr_1to1', 'jili_my1_1to100', 'metagaming_normal_myr'].includes(gameProfile), 'Only explicitly isolated supplier fixtures are supported');
const paymentFlag = process.argv.indexOf('--payment-provider');
const paymentProvider = paymentFlag === -1 ? '' : process.argv[paymentFlag + 1];
assert.ok(paymentFlag === -1 || ['vpay', 'gspay', '1mpay'].includes(paymentProvider), 'Only the three independent MYR payment fixtures are supported');
assert.ok(!(gameProfile && paymentProvider), 'Supplier and payment verification must remain independent');
const isMeta = gameProfile === 'metagaming_normal_myr', providerId = isMeta ? 'metagaming' : 'jili';
const require = createRequire(join(source, 'package.json'));
const runtimeRequire = createRequire(require.resolve('wrangler/package.json'));
const { Miniflare } = runtimeRequire('miniflare');
const { build } = runtimeRequire('esbuild');
const directory = mkdtempSync(join(tmpdir(), 'master7-candidate-d1-bank-'));
const setupCode = randomBytes(32).toString('base64url');
const fixtureCapability = randomBytes(32).toString('base64url');
const ownerPassword = randomBytes(32).toString('base64url');
const memberPassword = randomBytes(32).toString('base64url');
const origin = 'https://portal.example.test';
const checks = [];
let gameJourneyCompleted = false;
let paymentJourneyCompleted = false;
let paymentObservation = null;
let mf;

function statements(source) {
  const result = []; let text = '', quote = '', trigger = false;
  for (let i = 0; i < source.length; i++) {
    const char = source[i];
    if (quote) {
      text += char;
      if (char === quote) {
        if (source[i + 1] === quote) { text += source[++i]; } else quote = '';
      }
      continue;
    }
    if (["'", '"', '`'].includes(char)) { quote = char; text += char; continue; }
    if (char === ';' && (!trigger || /\bEND\s*$/i.test(text.trim()))) {
      if (text.trim()) result.push(text.trim()); text = ''; trigger = false; continue;
    }
    text += char;
    if (!trigger && /^\s*CREATE\s+TRIGGER\b/i.test(text)) trigger = true;
  }
  if (text.trim()) result.push(text.trim());
  return result;
}

try {
  const entry = join(directory, 'worker.ts');
  const output = join(directory, 'worker.mjs');
  writeFileSync(entry, `
import {handle} from ${JSON.stringify(resolve(source, 'lib/backend.ts'))};
import {createCloudflareJiliFixture} from ${JSON.stringify(resolve(source, 'tests/fixtures/cloudflare-jili.ts'))};
import {createCloudflareMetaFixture} from ${JSON.stringify(resolve(source, 'tests/fixtures/cloudflare-meta.ts'))};
import {createCloudflarePaymentFixture} from ${JSON.stringify(resolve(source, 'tests/fixtures/cloudflare-payments.ts'))};
// Freeze only this disposable worker's clock. Otherwise registration and the
// next OTP attempt can straddle a minute bucket and invalidate the rate test.
const isolatedNow=Date.now();Date.now=()=>isolatedNow;
let syntheticOtp = '';
let supplier;
let payment;
function isolatedDatabase(db) {
  function wrap(statement, sql) {
    return { raw: statement, sql,
      bind(...args) { return wrap(statement.bind(...args), sql); },
      async first(...args) { try { return await statement.first(...args); } catch(e) { console.error('ISOLATED_D1_FIRST', sql.slice(0,120), String(e), String(e?.cause)); throw e; } },
      async all(...args) { try { return await statement.all(...args); } catch(e) { console.error('ISOLATED_D1_ALL', sql.slice(0,120), String(e), String(e?.cause)); throw e; } },
      async run(...args) { try { return await statement.run(...args); } catch(e) { console.error('ISOLATED_D1_RUN', sql.slice(0,120), String(e), String(e?.cause)); throw e; } }
    };
  }
  return { prepare:sql=>wrap(db.prepare(sql),sql), async batch(items) {
    try { return await db.batch(items.map(s=>s.raw)); }
    catch(e) { console.error('ISOLATED_D1_BATCH', items.map(s=>s.sql.slice(0,120)), String(e), String(e?.cause)); throw e; }
  }};
}
export default {async fetch(req,env) {
  if(supplier===undefined) supplier=env.TEST_GAME_PROFILE==='metagaming_normal_myr'?createCloudflareMetaFixture(env.TEST_GAME_PROFILE,env.FIXTURE_CAPABILITY):createCloudflareJiliFixture(env.TEST_GAME_PROFILE,env.FIXTURE_CAPABILITY);
  if(payment===undefined) payment=env.TEST_PAYMENT_PROVIDER?createCloudflarePaymentFixture(env.TEST_PAYMENT_PROVIDER):null;
  if(new URL(req.url).pathname==='/__isolated_fixture/supplier' && supplier) return supplier.control(req);
  if(new URL(req.url).pathname==='/__isolated_fixture/otp') {
    if(req.headers.get('x-fixture-capability')!==env.FIXTURE_CAPABILITY) return new Response(null,{status:403});
    return Response.json({otp:syntheticOtp});
  }
  const context={
    db:isolatedDatabase(env.DB),identity:null,ownerEmail:'owner@example.test',ownerLoginId:'master7_owner',
    ownerSetupHash:env.SETUP_HASH,ownerSetupExpires:Math.floor(Date.now()/1000)+3600,
    newDepositsEnabled:'true',newPayoutsEnabled:'true',newGameLaunchesEnabled:'false',
    manualComplianceEnforced:'true',withdrawalDataKey:env.DATA_KEY,
    anchorApiBaseUrl:'https://sms.synthetic.test',anchorUsername:'synthetic',
    anchorPassword:'synthetic',anchorSenderId:'TEST',otpHashSecret:env.OTP_SECRET,
    smsFetch:async url=>{
      if(new URL(url).hostname!=='sms.synthetic.test') throw Error('external SMS forbidden');
      syntheticOtp=/\\b(\\d{6})\\b/.exec(new URL(url).searchParams.get('text'))?.[1]??'';
      return Response.json({status:201,data:[{statusCode:'001',umgTxId:'synthetic-d1-sms'}]},{status:201});
    },
    ...(supplier?.context()??{}),...(payment?.context()??{})
  };
  if(new URL(req.url).pathname==='/__isolated_fixture/payment' && payment) {
    if(req.headers.get('x-fixture-capability')!==env.FIXTURE_CAPABILITY) return new Response(null,{status:403});
    if(req.method==='GET') return Response.json(payment.observation());
    const data=await req.json();return handle(payment.callbackRequest(String(data.orderId??'')),context);
  }
  return handle(req,context);
}};
`);
  await build({ entryPoints: [entry], outfile: output, bundle: true, format: 'esm', platform: 'neutral', target: 'es2022', external: ['node:*'] });
  mf = new Miniflare({ rootPath: directory, modulesRoot: directory, modules: true, scriptPath: output,
    compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'], d1Databases: ['DB'],
    bindings: { SETUP_HASH: createHash('sha256').update(setupCode).digest('hex'), FIXTURE_CAPABILITY: fixtureCapability, TEST_GAME_PROFILE: gameProfile, TEST_PAYMENT_PROVIDER: paymentProvider,
      OTP_SECRET: randomBytes(32).toString('hex'), DATA_KEY: randomBytes(48).toString('base64url') } });
  const db = await mf.getD1Database('DB');
  const migrations = readdirSync(join(source, 'drizzle')).filter(n => n.endsWith('.sql')).sort();
  for (const name of migrations) {
    const sql = readFileSync(join(source, 'drizzle', name), 'utf8').replaceAll('--> statement-breakpoint', '')
      .replace(/^\s*--.*$/gm, '').replace(/^\s*(?:BEGIN|COMMIT|ROLLBACK)\s*;\s*$/gmi, '');
    for (const statement of statements(sql)) await db.prepare(statement).run();
  }
  checks.push('all SQLite migrations applied to disposable D1');
  const jars = { owner: { cookie: '', csrf: '' }, member: { cookie: '', csrf: '' } };
  async function call(who, path, data) {
    const jar = jars[who];
    const response = await mf.dispatchFetch(origin + path, { method: data === undefined ? 'GET' : 'POST',
      headers: { origin, 'content-type': 'application/json', cookie: jar.cookie, 'x-csrf-token': jar.csrf, 'cf-connecting-ip': who === 'member' ? '192.0.2.10' : '192.0.2.11' },
      ...(data === undefined ? {} : { body: JSON.stringify(data) }) });
    if (response.headers.has('set-cookie')) jar.cookie = response.headers.get('set-cookie').split(';')[0];
    const body = await response.json();
    if (path === '/api/session' && body.csrf) jar.csrf = body.csrf;
    return { status: response.status, body };
  }
  function status(actual, expected) { assert.equal(actual.status, expected, JSON.stringify(actual)); return actual.body; }
  status(await call('owner', '/api/auth/activate', { code: setupCode, password: ownerPassword }), 201);
  status(await call('owner', '/api/auth/login', { username: 'master7_owner', password: ownerPassword }), 200);
  assert.equal(status(await call('owner', '/api/session'), 200).user.role, 'owner');
  checks.push('real Owner activation and password session');
  const account = { username: 'registered_d1_member', password: memberPassword, phone: '0123456789' };
  async function otp() {
    const response = await mf.dispatchFetch(origin + '/__isolated_fixture/otp', { headers: { 'x-fixture-capability': fixtureCapability } });
    return (await response.json()).otp;
  }
  const sent = status(await call('member', '/api/auth/otp/send', account), 200);
  status(await call('member', '/api/auth/register', { ...account, challengeId: sent.challengeId, otp: await otp() }), 201);
  const member = await db.prepare('SELECT id,role,approved FROM users WHERE username=?').bind(account.username).first();
  assert.match(member.id, /^local:/); assert.equal(member.role, 'member'); assert.equal(member.approved, 1);
  checks.push('registration creates immutable local:UUID member');
  assert.equal((await call('member', '/api/auth/otp/send', { ...account, purpose: 'login' })).status, 429);
  // Only age the disposable rate-limit fixture; application code and real rate limits are untouched.
  await db.prepare('UPDATE rate_limits SET expires_at=0').run();
  const login = status(await call('member', '/api/auth/otp/send', { ...account, purpose: 'login' }), 200);
  const loginPayload = { ...account, challengeId: login.challengeId, otp: await otp() };
  status(await call('member', '/api/auth/otp/login', loginPayload), 200);
  assert.equal(status(await call('member', '/api/session'), 200).user.id, member.id);
  status(await call('member', '/api/auth/otp/login', loginPayload), 400);
  assert.equal((await call('member', '/api/admin/manual-bank')).status, 403);
  checks.push('member OTP login, replay denial, send rate limit and Owner authorization');
  await db.prepare("INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES(?,'passed','passed',1,'disposable-reviewed-fixture',0,0)").bind(member.id).run();
  const image = 'data:image/png;base64,' + Buffer.from([137,80,78,71,13,10,26,10,...new Array(40).fill(1)]).toString('base64');
  const bank = status(await call('owner', '/api/admin/manual-bank/account', { bankName: 'Synthetic D1 Bank', accountName: 'Synthetic Test Only', accountNumber: '1234567890', enabled: true, imageData: image }), 200);
  status(await call('owner', '/api/admin/manual-bank/settings', { mode: 'qa', qaMemberIds: [member.id] }), 200);
  assert.deepEqual(status(await call('owner', '/api/admin/manual-bank'), 200).configuration.qaMemberIds, [member.id]);
  assert.equal(status(await call('member', '/api/manual-bank/accounts'), 200).items.length, 1);
  const request = { bankId: bank.id, amount: '50.00', receiptData: image, requestKey: randomUUID() };
  const deposit = status(await call('member', '/api/manual-bank/deposits', request), 201);
  const proof = (reference, amount) => ({ bankAccountId: bank.id, bankReference: reference, bankAmount: amount, currency: 'MYR', bankOccurredAt: Math.floor(Date.now()/1000)-10, proofData: image, bankConfirmed: true });
  const approval = { id: deposit.id, action: 'approve', ...proof('D1-SYNTHETIC-IN', '50.00') };
  status(await call('owner', '/api/admin/manual-bank/review', approval), 200);
  status(await call('owner', '/api/admin/manual-bank/review', approval), 409);
  assert.equal(status(await call('member', '/api/wallet'), 200).availableMinor, '5000');
  const journal = await db.prepare('SELECT COUNT(*) n,SUM(amount_minor) total FROM wallet_ledger WHERE order_id=?').bind(deposit.id).first();
  assert.equal(journal.n, 2); assert.equal(journal.total, 0);
  checks.push('QA whitelist accepts registered ID; Bank-In creates exactly one balanced journal');
  if(paymentProvider){
    await db.prepare('UPDATE payment_channel_controls SET status=? WHERE provider_id=?').bind('active',paymentProvider).run();
    const paymentSpec=paymentProvider==='vpay'
      ?{path:'/api/payments/vpay/orders',query:'/api/payments/vpay/orders/query',data:{amount:'20.00',requestKey:randomUUID(),tradeCode:'2',payerName:'Synthetic D1 Member'}}
      :paymentProvider==='gspay'
       ?{path:'/api/payments/gspay/orders',query:'/api/payments/gspay/orders/query',data:{amount:'20.00',requestKey:randomUUID()}}
       :{path:'/api/payments/1mpay/orders',query:'/api/payments/1mpay/orders/query',data:{amount:'20.00',requestKey:randomUUID()}};
    const created=status(await call('member',paymentSpec.path,paymentSpec.data),201);
    assert.equal(created.status,'awaiting_payment');assert.ok(created.payUrl);assert.ok(created.id);
    assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').bind(created.id).first()).n,0);
    async function paymentCallback(expected){
      const response=await mf.dispatchFetch(origin+'/__isolated_fixture/payment',{method:'POST',headers:{'x-fixture-capability':fixtureCapability,'content-type':'application/json'},body:JSON.stringify({orderId:created.id})});
      const body=await response.text();assert.ok(expected.includes(response.status),JSON.stringify({status:response.status,body}));return body;
    }
    await paymentCallback([502,503]);
    assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').bind(created.id).first()).n,0);
    const queried=status(await call('member',paymentSpec.query,{orderId:created.id}),200);assert.equal(queried.status,'credited');
    await paymentCallback([200]);
    const providerJournal=await db.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=? ORDER BY account_code').bind(created.id).all();
    assert.deepEqual(providerJournal.results.map(row=>row.account_code),['member','provider_clearing']);
    assert.deepEqual(providerJournal.results.map(row=>String(row.amount_minor)),['2000','-2000']);
    assert.ok(providerJournal.results.every(row=>row.currency==='MYR'&&row.user_id===member.id));
    assert.equal(status(await call('member','/api/wallet'),200).balanceMinor,'7000');
    const beforeFinance=(await db.prepare('SELECT COUNT(*) n,SUM(amount_minor) total FROM wallet_ledger').first());
    const finance=status(await call('owner','/api/admin/finance-center?period=today'),200);
    assert.equal(finance.reconciliation.memberWallet.status,'matched');
    assert.equal(finance.reconciliation.memberWallet.doubleEntryDifferenceMinor,'0');
    assert.equal(finance.reconciliation.paymentProvider.differenceMinor,null);
    assert.equal(finance.reconciliation.settlementVerified,false);
    const afterFinance=(await db.prepare('SELECT COUNT(*) n,SUM(amount_minor) total FROM wallet_ledger').first());assert.deepEqual(afterFinance,beforeFinance);
    const observationResponse=await mf.dispatchFetch(origin+'/__isolated_fixture/payment',{headers:{'x-fixture-capability':fixtureCapability}});
    assert.equal(observationResponse.status,200);paymentObservation=await observationResponse.json();
    assert.equal(paymentObservation.createCalls,1);assert.ok(paymentObservation.queryCalls>=2);assert.equal(paymentObservation.forcedQueryFailures,1);assert.equal(paymentObservation.externalCalls,0);
    checks.push(`${paymentProvider}: independent create/callback/query-recovery/wallet/ledger/idempotency path`);
    checks.push(`${paymentProvider}: internal double-entry reconciliation matched; external provider statement remains unavailable and no balance mutation occurred`);
    paymentJourneyCompleted=true;
  }
  if (gameProfile) {
    async function fixture(action, extra = {}) {
      const r = await mf.dispatchFetch(origin + '/__isolated_fixture/supplier', {
        method: action ? 'POST' : 'GET',
        headers: { 'x-fixture-capability': fixtureCapability, 'content-type': 'application/json' },
        ...(action ? { body: JSON.stringify({ action, ...extra }) } : {}),
      });
      assert.equal(r.status, 200); return r.json();
    }
    await fixture('configure', { memberId: member.id });
    const launch = status(await call('member', '/api/game-launch', { profileId: gameProfile, providerId, gameCode: '1', idempotencyKey: randomUUID(), language: 'en' }), 200);
    assert.equal(launch.profileId, gameProfile); assert.match(launch.launchUrl, /^https:\/\/games\.example\.test\//);
    assert.equal(status(await call('member', '/api/wallet'), 200).availableMinor, '0');
    await fixture('prepare-lost-sweep');
    const session = { profileId: gameProfile, sessionId: launch.walletSessionId };
    assert.equal(status(await call('member', '/api/game-wallet/settle', session), 503).code, 'GAME_WITHDRAWAL_UNKNOWN');
    assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id=?').bind(launch.walletSessionId).first()).n, 1);
    assert.equal((await db.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').first()).n, 0);
    await fixture('pause-and-hide-query');
    status(await call('member', '/api/game-launch', { profileId: gameProfile, providerId, gameCode: '1', idempotencyKey: randomUUID(), language: 'en' }), 503);
    assert.equal(status(await call('member', '/api/game-wallet/recover', session), 200).status, 'withdraw_unknown');
    assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id=?').bind(launch.walletSessionId).first()).n, 1);
    await fixture('restore-query');
    const concurrentRecovery = await Promise.all([
      call('member', '/api/game-wallet/recover', session), call('member', '/api/game-wallet/recover', session),
    ]);
    assert.ok(concurrentRecovery.some(r => r.status === 200 && r.body.status === 'settled'), JSON.stringify(concurrentRecovery));
    assert.ok(concurrentRecovery.every(r => [200, 409].includes(r.status)), JSON.stringify(concurrentRecovery));
    assert.equal(status(await call('member', '/api/game-wallet/recover', session), 200).status, 'settled');
    assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id=?').bind(launch.walletSessionId).first()).n, 0);
    const result = await db.prepare('SELECT COUNT(*) n,SUM(amount_minor) net FROM game_wallet_ledger WHERE session_id=?').bind(launch.walletSessionId).first();
    assert.equal(result.n, 1); assert.equal(result.net, 375);
    assert.equal(status(await call('member', '/api/wallet'), 200).availableMinor, '5375');
    const observed = await fixture();
    assert.equal(observed.transferCount, 2);
    if (isMeta) {
      assert.equal(observed.calls.filter(x => x.method === 'deposit').length, 1);
      assert.equal(observed.calls.filter(x => x.method === 'withdraw').length, 1);
      assert.equal(observed.calls.find(x => x.method === 'deposit').amount, '50.00');
      const depositIndex = observed.calls.findIndex(x => x.method === 'deposit');
      const confirmationIndex = observed.calls.findIndex((x, index) => index > depositIndex && x.method === 'transfer-status');
      const launchIndex = observed.calls.findIndex(x => x.method === 'launch');
      assert.ok(depositIndex >= 0 && confirmationIndex > depositIndex && launchIndex > confirmationIndex, JSON.stringify(observed.calls));
      checks.push(gameProfile + ': independent META transfer/status/launch/closure/lost-return recovery/net-ledger path');
      checks.push(gameProfile + ': concurrent recovery preserves one return and one result posting');
    } else {
      assert.equal(observed.calls.filter(x => x.method === 'ExchangeTransferByAgentId' && x.direction === '2').length, 1);
      assert.equal(observed.calls.filter(x => x.method === 'ExchangeTransferByAgentId' && x.direction === '1').length, 1);
      assert.equal(observed.calls.find(x => x.method === 'ExchangeTransferByAgentId' && x.direction === '2').amount, '50.00');
      checks.push(gameProfile + ': independent JILI transfer/launch/closure/lost-sweep recovery/net-ledger path');
      checks.push(gameProfile + ': concurrent recovery preserves one sweep and one result posting');
    }
    gameJourneyCompleted = true;
  }
  const withdrawal = status(await call('member', '/api/withdrawals', { providerId: 'manual_bank', bankCode: 'maybank', accountHolder: 'Synthetic Registered Member', accountNumber: '223456789012', amount: '20.00', requestKey: randomUUID() }), 201).withdrawal;
  const paymentCredit=paymentJourneyCompleted?2000:0;
  assert.equal(status(await call('member', '/api/wallet'), 200).availableMinor, String((gameJourneyCompleted ? 3375 : 3000)+paymentCredit));
  const review = status(await call('owner', '/api/admin/withdrawals'), 200).items.find(x => x.id === withdrawal.id);
  const approve = { id: withdrawal.id, approvalFingerprint: review.approvalFingerprint, ownerNote: 'Disposable Cloudflare D1 QA only' };
  status(await call('member', '/api/admin/withdrawals/approve', approve), 403);
  status(await call('owner', '/api/admin/withdrawals/approve', { ...approve, approvalFingerprint: '0'.repeat(64) }), 409);
  // Corrupt only this disposable fixture to verify the unchanged review barrier.
  await db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('synthetic-review',?,'synthetic-review','fixture','manual_bank',1,'MYR','fixture','review',0,0)").bind(member.id).run();
  await db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('synthetic-review-member','synthetic-review',?,'member',1,'MYR',0)").bind(member.id).run();
  status(await call('owner', '/api/admin/withdrawals/approve', approve), 409);
  assert.equal((await db.prepare('SELECT status FROM withdrawal_requests WHERE id=?').bind(withdrawal.id).first()).status, 'pending');
  assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id=?').bind(withdrawal.id).first()).n, 1);
  await db.prepare("DELETE FROM wallet_ledger WHERE order_id='synthetic-review'").run();
  await db.prepare("DELETE FROM deposit_orders WHERE id='synthetic-review'").run();
  const parallelApprovals = await Promise.all([call('owner', '/api/admin/withdrawals/approve', approve), call('owner', '/api/admin/withdrawals/approve', approve)]);
  assert.deepEqual(parallelApprovals.map(x => x.status).sort(), [202, 409]);
  assert.equal((await db.prepare("SELECT COUNT(*) n FROM audit WHERE event='withdrawal_approved_v1' AND target=?").bind(withdrawal.id).first()).n, 1);
  checks.push('Owner-only approval, exact fingerprint, review barrier and concurrent single approval');
  status(await call('owner', '/api/admin/manual-bank/payout/start', { id: withdrawal.id, bankAccountId: bank.id }), 202);
  status(await call('owner', '/api/admin/manual-bank/payout/unknown', { id: withdrawal.id }), 200);
  assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id=?').bind(withdrawal.id).first()).n, 1);
  const heldWallet = status(await call('member', '/api/wallet'), 200);
  assert.equal(heldWallet.availableMinor, '0');
  assert.equal(heldWallet.balanceMinor, String((gameJourneyCompleted ? 5375 : 5000)+paymentCredit));
  assert.equal(heldWallet.reconciliationRequired, true);
  status(await call('owner', '/api/admin/manual-bank/payout/confirm', { id: withdrawal.id }), 400);
  const confirmation = { id: withdrawal.id, ...proof('D1-SYNTHETIC-OUT', '20.00') };
  status(await call('owner', '/api/admin/manual-bank/payout/confirm', confirmation), 200);
  assert.equal(status(await call('owner', '/api/admin/manual-bank/payout/confirm', confirmation), 200).idempotent, true);
  assert.equal(status(await call('member', '/api/wallet'), 200).balanceMinor, String((gameJourneyCompleted ? 3375 : 3000)+paymentCredit));
  assert.equal((await db.prepare('SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id=?').bind(withdrawal.id).first()).n, 0);
  assert.equal((await db.prepare('SELECT id FROM users WHERE username=?').bind(account.username).first()).id, member.id);
  checks.push('Bank-Out freezes balance, preserves unknown hold and completes idempotently');
  status(await call('owner', '/api/admin/manual-bank/acceptance', { depositId: deposit.id, withdrawalId: withdrawal.id, bankConfirmed: true }), 200);
  checks.push('synthetic evidence links Bank-In and Bank-Out');
  const audit = await db.prepare('SELECT event,COUNT(*) n FROM audit GROUP BY event ORDER BY event').all();
  console.log(JSON.stringify({ result: 'passed', runtime: 'Cloudflare workerd + disposable D1', source,
    observed_at: new Date().toISOString(), migrations: migrations.length, clock: 'fixed inside disposable worker only', checks,
    ...(gameProfile ? { gameProfile, supplierCallsAreSynthetic: true, gameJourneyCompleted } : {}),
    ...(paymentProvider ? {paymentProvider,paymentCallsAreSynthetic:true,paymentJourneyCompleted,paymentObservation} : {}),
    syntheticAmountMinor: { bankIn: '5000', ...(paymentJourneyCompleted?{providerDeposit:'2000'}:{}), bankOut: '2000', endingBalance: String((gameJourneyCompleted ? 3375 : 3000)+paymentCredit), ...(gameJourneyCompleted ? { gameOut: '5000', gameReturned: '5375', gameNet: '375' } : {}) }, auditEvents: audit.results,
    limitations: ['synthetic SMS only', 'synthetic bank evidence only', 'disposable compliance fixture', 'rate-limit fixture aged after rejection check', gameProfile ? (isMeta ? 'synthetic META transport and closure evidence only; no bet or official finality verification' : 'synthetic JILI transport and closure evidence only; no bet or official finality verification') : 'no supplier calls', ...(paymentProvider?['synthetic payment-provider transport only','not payment-provider UAT acceptance']:[]), 'no remote database access', 'no production deployment', 'not UAT acceptance'] }, null, 2));
} finally {
  if (mf) await mf.dispose();
  rmSync(directory, { recursive: true, force: true });
}
