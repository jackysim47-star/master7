#!/usr/bin/env node
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {validateUatPackageManifest} from '../lib/uat-package.ts';

const MAX_BYTES=1024*1024;

export async function main(args=process.argv.slice(2)){
 try{
  const positional=args[0]==='--'?args.slice(1):args;
  if(positional.length!==1||positional[0].startsWith('-'))throw new Error('Provide exactly one UAT manifest JSON path');
  const data=await readFile(positional[0]);if(data.byteLength>MAX_BYTES)throw new Error('UAT manifest exceeds 1 MiB');
  let manifest;try{manifest=JSON.parse(data.toString('utf8'));}catch{throw new Error('UAT manifest is not valid JSON');}
  const result=validateUatPackageManifest(manifest);process.stdout.write(`${JSON.stringify(result)}\n`);return result.readyForRestrictedUat?0:1;
 }catch(error){process.stdout.write(`${JSON.stringify({schemaValid:false,readyForRestrictedUat:false,error:error instanceof Error?error.message:'UAT package validation failed',accepted:false,live:false,productionReady:false})}\n`);return 1;}
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)process.exitCode=await main();
