// Display and log the batch status using a read-only loopback request.
export function startMyrDepositBatchMonitor(options = {}, fetchImpl = fetch, report = console.info) {
 const enabled = options.enabled ?? process.env.MYR_DEPOSIT_BATCH_ENFORCED;
 const port = Number(options.port ?? process.env.PORT ?? process.env.NITRO_PORT ?? 3000);
 if (enabled !== 'true' || !Number.isSafeInteger(port) || port < 1 || port > 65535) {
  return { run: async () => {}, stop() {} };
 }
 let running = false, stopped = false, last = '';
 function publish(state, count, reason, providers = {}) {
  const entry = { event: 'myr_deposit_batch_status', state, passedCount: count, reason, providers };
  const value = JSON.stringify(entry);
  if (!stopped && value !== last) {
   last = value;
   report(value);
  }
 }
 async function run() {
  if (running || stopped) return;
  running = true;
  try {
   const response = await fetchImpl(`http://127.0.0.1:${port}/api/payments/myr-batch/status`, {
    method: 'GET', headers: { Accept: 'application/json' }, redirect: 'error', signal: AbortSignal.timeout(12000),
   });
   if (!response.ok) throw new Error('MYR batch status unavailable');
   const { myrDepositBatch: batch } = await response.json();
   const reasons = ['myr_batch_paused', 'myr_batch_open', 'myr_batch_acceptance_pending', 'myr_batch_signoff_pending', 'myr_batch_runtime_pending'];
   if (!['waiting', 'paused', 'open'].includes(batch?.state) || !reasons.includes(batch.reason)
       || !Number.isInteger(batch.passedCount) || batch.passedCount < 0 || batch.passedCount > 3) {
    throw new Error('Invalid MYR batch status');
   }
   publish(batch.state, batch.passedCount, batch.reason,
    { vpay: batch.providers?.vpay === true, gspay: batch.providers?.gspay === true, '1mpay': batch.providers?.['1mpay'] === true });
  } catch {
   publish('unavailable', null, 'myr_batch_status_unavailable');
  } finally {
   running = false;
  }
 }
 const first = setTimeout(run, 10000);
 const periodic = setInterval(run, 120000);
 first.unref?.();
 periodic.unref?.();
 return { run, stop() { stopped = true; clearTimeout(first); clearInterval(periodic); } };
}
