// Dispatch only previously approved WhatsApp template campaigns through the
// authenticated loopback endpoint. Deployment alone cannot activate sending:
// both the explicit switch and a private worker token are required.
export function startWhatsAppDispatch(options = {}, fetchImpl = fetch) {
  const enabled = String(options.enabled ?? process.env.WHATSAPP_SENDING_ENABLED ?? "") === "true";
  const token = String(options.token ?? process.env.WHATSAPP_WORKER_TOKEN ?? "");
  const port = String(options.port ?? process.env.PORT ?? process.env.NITRO_PORT ?? "3000");
  const requestedInterval = Number(options.intervalMs ?? process.env.WHATSAPP_WORKER_INTERVAL_MS ?? 5000);
  const intervalMs = Number.isSafeInteger(requestedInterval) && requestedInterval >= 1000 && requestedInterval <= 60000
    ? requestedInterval
    : 5000;
  const requestedStartup = Number(options.startupDelayMs ?? 12000);
  const startupDelayMs = Number.isSafeInteger(requestedStartup) && requestedStartup >= 1000 && requestedStartup <= 60000
    ? requestedStartup
    : 12000;
  const tokenBytes = Buffer.byteLength(token);

  if (!enabled || tokenBytes < 32 || tokenBytes > 1024 || !/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535) {
    return { run: async () => {}, stop() {} };
  }

  let running = false;
  let stopped = false;
  const run = async () => {
    if (running || stopped) return;
    running = true;
    try {
      const response = await fetchImpl(`http://127.0.0.1:${Number(port)}/api/internal/whatsapp-dispatch`, {
        method: "POST",
        headers: { Accept: "application/json", Authorization: `Bearer ${token}` },
        redirect: "error",
        signal: AbortSignal.timeout(50000),
      });
      await response.body?.cancel();
      if (!response.ok) console.error("WhatsApp campaign dispatch unavailable");
    } catch {
      console.error("WhatsApp campaign dispatch unavailable");
    } finally {
      running = false;
    }
  };

  const startup = setTimeout(run, startupDelayMs);
  const periodic = setInterval(run, intervalMs);
  startup.unref?.();
  periodic.unref?.();
  return {
    run,
    stop() {
      stopped = true;
      clearTimeout(startup);
      clearInterval(periodic);
    },
  };
}
