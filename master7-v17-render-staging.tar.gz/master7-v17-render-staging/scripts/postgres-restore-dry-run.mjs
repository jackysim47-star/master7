import {constants,createDecipheriv,createHash,privateDecrypt,randomBytes} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {basename} from 'node:path';
import {gunzipSync} from 'node:zlib';
import pg from 'pg';
import {BACKUP_EXCLUDED_TABLES,BACKUP_FORMAT,BACKUP_TABLES,backupRestoreContract} from '../lib/encrypted-backup.ts';
import {assertIsolatedRestoreTarget} from '../lib/restore-safety.mjs';
import {initializeRehearsalSchema,withRollbackOnlyTransaction} from './restore-postgres-schema.mjs';

const rawArgs=process.argv.slice(2),confirmed=rawArgs.includes('--confirm-isolated'),args=rawArgs.filter(value=>value!=='--confirm-isolated');
const [backupPath,privateKeyPath,passphrasePath,receiptPath]=args;
if(!confirmed||!backupPath||!privateKeyPath||!passphrasePath)throw new Error('Usage: node scripts/postgres-restore-dry-run.mjs BACKUP PRIVATE_KEY PASSPHRASE [RECEIPT] --confirm-isolated');
const connectionString=process.env.MASTER7_RESTORE_DATABASE_URL;
const target=assertIsolatedRestoreTarget(connectionString,[process.env.PORTAL_POSTGRES_URL,process.env.DATABASE_URL]);
const hash=value=>createHash('sha256').update(value).digest('hex'),backupBytes=readFileSync(backupPath),envelope=JSON.parse(backupBytes.toString('utf8'));
if(envelope.format!==BACKUP_FORMAT)throw new Error('Unsupported backup format');
const contract=backupRestoreContract(envelope.schemaVersion,envelope.schemaSha256);
const ciphertext=Buffer.from(envelope.ciphertext,'base64');if(hash(ciphertext)!==envelope.ciphertextSha256)throw new Error('Ciphertext hash mismatch');
const contentKey=privateDecrypt({key:readFileSync(privateKeyPath),passphrase:readFileSync(passphrasePath,'utf8').trim(),oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64'));
const decipher=createDecipheriv('aes-256-gcm',contentKey,Buffer.from(envelope.iv,'base64'));decipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));
const plaintext=gunzipSync(Buffer.concat([decipher.update(ciphertext),decipher.final()]));if(hash(plaintext)!==envelope.plaintextSha256)throw new Error('Plaintext hash mismatch');
const payload=JSON.parse(plaintext.toString('utf8'));
if(payload.format!==envelope.format||payload.release!==envelope.release||payload.schemaVersion!==envelope.schemaVersion||payload.schemaSha256!==envelope.schemaSha256)throw new Error('Envelope and payload metadata mismatch');
const readConsistency=payload.readConsistency??'unverified';
if(!['transaction_snapshot','unverified'].includes(readConsistency)||readConsistency!==(envelope.readConsistency??'unverified'))throw new Error('Backup read consistency metadata mismatch');
const manifestNames=payload.manifest?.tables?.map(item=>item.name)??[];
if(payload.manifest?.tableCount!==contract.tables.length||manifestNames.length!==contract.tables.length||manifestNames.some((name,index)=>name!==contract.tables[index]))throw new Error('Backup table manifest does not match this release');
for(const table of payload.manifest.tables){const rows=payload.tables[table.name];if(!Array.isArray(rows)||rows.length!==table.rows||hash(JSON.stringify(rows))!==table.sha256)throw new Error(`Manifest mismatch for ${table.name}`);}

const client=new pg.Client({connectionString,ssl:process.env.PGSSLMODE==='disable'?false:{rejectUnauthorized:process.env.PGSSL_REJECT_UNAUTHORIZED!=='false',...(process.env.PGSSL_CA?{ca:process.env.PGSSL_CA.replaceAll('\\n','\n')}:{})},connectionTimeoutMillis:10_000});
const receipt=await withRollbackOnlyTransaction(client,async()=>{
 const rehearsalSchema=`restore_${randomBytes(8).toString('hex')}`;
 await client.query(`CREATE SCHEMA "${rehearsalSchema}"`);
 await client.query(`SET LOCAL search_path TO "${rehearsalSchema}", pg_catalog`);
 await initializeRehearsalSchema(client,readFileSync(new URL('../db/render-schema.sql',import.meta.url),'utf8'),JSON.parse(readFileSync(new URL('../db/vendor-directory.json',import.meta.url),'utf8')));
 const quoted=BACKUP_TABLES.map(name=>`"${name}"`).join(',');await client.query(`TRUNCATE ${quoted} CASCADE`);
 for(const table of contract.tables){
  for(const row of payload.tables[table]){
   const columns=Object.keys(row);if(!columns.length)continue;
   for(const column of columns)if(!/^[a-z][a-z0-9_]*$/.test(column))throw new Error(`Unsafe column name in ${table}`);
   const values=columns.map(column=>{const value=row[column];return value&&typeof value==='object'?JSON.stringify(value):value??null;}),marks=values.map((_,index)=>`$${index+1}`).join(','),columnSql=columns.map(column=>`"${column}"`).join(',');
   await client.query(`INSERT INTO "${table}"(${columnSql}) VALUES(${marks})`,values);
  }
 }
 await client.query('SET CONSTRAINTS ALL IMMEDIATE');
 const restored=[];for(const table of contract.tables){const result=await client.query(`SELECT COUNT(*)::bigint count FROM "${table}"`),count=Number(result.rows[0].count),expected=payload.manifest.tables.find(item=>item.name===table).rows;if(count!==expected)throw new Error(`Restore count mismatch for ${table}`);restored.push({name:table,rows:count});}
 const excludedCounts={};for(const table of BACKUP_EXCLUDED_TABLES){const result=await client.query(`SELECT COUNT(*)::bigint count FROM "${table}"`);excludedCounts[table]=Number(result.rows[0].count);}
 if(Object.values(excludedCounts).some(Number))throw new Error('Ephemeral authentication or lock data was restored unexpectedly');
 const coverageComplete=contract.missingTables.length===0;
 return {status:coverageComplete?'verified':'verified_legacy_coverage',coverageComplete,missingTables:contract.missingTables,readConsistency,format:envelope.format,release:envelope.release,schemaVersion:envelope.schemaVersion,schemaSha256:envelope.schemaSha256,backupFile:basename(backupPath),backupSha256:hash(backupBytes),createdAt:envelope.createdAt,verifiedAt:new Date().toISOString(),publicKeySha256:envelope.publicKeySha256,plaintextSha256:envelope.plaintextSha256,tableCount:restored.length,totalRecords:restored.reduce((sum,item)=>sum+item.rows,0),tables:restored,excludedTables:excludedCounts,foreignKeyViolations:0,restoreTarget:`isolated PostgreSQL transaction on ${target.host}/${target.database}`,persistentWrites:false};
});
if(!receipt)throw new Error('Restore rehearsal did not produce a receipt');
if(receiptPath)writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n',{mode:0o600});
process.stdout.write(JSON.stringify({status:receipt.status,coverageComplete:receipt.coverageComplete,missingTables:receipt.missingTables,readConsistency,release:receipt.release,schemaSha256:receipt.schemaSha256,tableCount:receipt.tableCount,totalRecords:receipt.totalRecords,persistentWrites:false})+'\n');
