const DEFAULT_INTERVAL_MS=5*60*1000;

export async function triggerAccountingClose({endpoint,token,fetchImpl=fetch,signal}={}){
 if(typeof endpoint!=='string'||!endpoint.startsWith('http'))throw new Error('Accounting close endpoint is required');
 if(typeof token!=='string'||token.length<32)throw new Error('ACCOUNTING_JOB_TOKEN must contain at least 32 characters');
 const response=await fetchImpl(endpoint,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${token}`},body:'{}',signal,redirect:'error'});
 const raw=await response.text();let data={};try{data=raw?JSON.parse(raw):{};}catch{}
 if(!response.ok)throw new Error(`Accounting close returned HTTP ${response.status}`);
 return data;
}

export function startAccountingCloseScheduler(options={}){
 const token=options.token??process.env.ACCOUNTING_JOB_TOKEN??'';
 if(token.length<32){console.warn('MASTER7 accounting close scheduler disabled: ACCOUNTING_JOB_TOKEN is not configured.');return {enabled:false,stop(){}};}
 const port=options.port??process.env.PORT??'10000',endpoint=options.endpoint??`http://127.0.0.1:${port}/api/internal/accounting-close`,intervalMs=options.intervalMs??DEFAULT_INTERVAL_MS,startupDelayMs=options.startupDelayMs??15_000,fetchImpl=options.fetchImpl??fetch;
 let stopped=false,running=false;
 const execute=async()=>{if(stopped||running)return;running=true;const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),30_000);timeout.unref?.();try{const result=await triggerAccountingClose({endpoint,token,fetchImpl,signal:controller.signal});if(result?.status!=='not_due')console.log(`MASTER7 accounting close check: ${result?.status??'completed'} (${result?.closed??0} period(s)).`);}catch(error){console.error('MASTER7 accounting close check failed:',error instanceof Error?error.message:'unknown error');}finally{clearTimeout(timeout);running=false;}};
 const startup=setTimeout(execute,startupDelayMs),interval=setInterval(execute,intervalMs);startup.unref?.();interval.unref?.();
 return {enabled:true,execute,stop(){stopped=true;clearTimeout(startup);clearInterval(interval);}};
}
