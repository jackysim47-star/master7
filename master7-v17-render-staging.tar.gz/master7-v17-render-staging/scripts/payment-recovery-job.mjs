// Poll only independently verifiable deposit statuses. Each provider switch
// and the internal bearer token are opt-in, so deployment alone cannot start
// provider traffic or enable new payment orders.
export function startPaymentRecovery(options={},fetchImpl=fetch){
 const token=options.token??process.env.PAYMENT_RECOVERY_TOKEN??'';
 const vpay=String(options.vpayEnabled??process.env.VPAY_RECOVERY_ENABLED??'')==='true';
 const gspay=String(options.gspayEnabled??process.env.GSPAY_RECOVERY_ENABLED??'')==='true';
 const oneMpay=String(options.oneMpayEnabled??process.env.ONE_MPAY_RECOVERY_ENABLED??'')==='true';
 const port=String(options.port??process.env.PORT??process.env.NITRO_PORT??'3000');
 const requested=Number(options.intervalMs??process.env.PAYMENT_RECOVERY_INTERVAL_MS??120000);
 const intervalMs=Number.isSafeInteger(requested)&&requested>=60000&&requested<=3600000?requested:120000;
 const tokenBytes=Buffer.byteLength(token);if(tokenBytes<32||tokenBytes>1024||(!vpay&&!gspay&&!oneMpay)||!/^[0-9]{1,5}$/.test(port)||Number(port)<1||Number(port)>65535)return {run:async()=>{},stop(){}};
 // Preserve the existing shared recovery behavior for VPay/GSPAY. A newly
 // enabled 1MPay-only worker must not also run their payout recovery.
 const scope=oneMpay&&!vpay&&!gspay?'?provider=1mpay':'';
 let running=false,stopped=false;
 const run=async()=>{
  if(running||stopped)return;running=true;
  try{
   const response=await fetchImpl(`http://127.0.0.1:${Number(port)}/api/internal/payment-recovery${scope}`,{method:'POST',headers:{Accept:'application/json',Authorization:'Bearer '+token},redirect:'error',signal:AbortSignal.timeout(50000)});
   await response.body?.cancel();if(!response.ok)console.error('Payment recovery unavailable');
  }catch{console.error('Payment recovery unavailable');}finally{running=false;}
 };
 const first=setTimeout(run,10000),periodic=setInterval(run,intervalMs);first.unref?.();periodic.unref?.();
 return {run,stop(){stopped=true;clearTimeout(first);clearInterval(periodic);}};
}
