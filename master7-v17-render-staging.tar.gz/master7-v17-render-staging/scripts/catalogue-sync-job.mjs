// Refresh the persisted catalogue while the Node web service is running.
// The fixed loopback endpoint exposes only read-only supplier catalogue work.
export function startCatalogueSync(options={},fetchImpl=fetch){
 const token=options.token??process.env.GAME_CATALOGUE_SYNC_TOKEN??'';
 const port=String(options.port??process.env.PORT??process.env.NITRO_PORT??'3000');
 if(token.length<32||!/^\d{1,5}$/.test(port)||Number(port)<1||Number(port)>65535)return {run:async()=>{},stop(){}};
 let running=false,stopped=false;
 const run=async()=>{
  if(running||stopped)return;running=true;
  try{const r=await fetchImpl(`http://127.0.0.1:${Number(port)}/api/internal/catalogue-sync`,{method:'GET',headers:{Accept:'application/json',Authorization:'Bearer '+token},redirect:'error',signal:AbortSignal.timeout(25000)});await r.body?.cancel();if(!r.ok)console.error('Catalogue refresh unavailable');}
  catch{console.error('Catalogue refresh unavailable');}finally{running=false;}
 };
 const first=setTimeout(run,4000),periodic=setInterval(run,60000);first.unref?.();periodic.unref?.();
 return {run,stop(){stopped=true;clearTimeout(first);clearInterval(periodic);}};
}
