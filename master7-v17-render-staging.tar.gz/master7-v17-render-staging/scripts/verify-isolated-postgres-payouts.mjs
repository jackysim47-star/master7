import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {encryptWithdrawalValue} from '../lib/withdrawal-secrets.ts';
import {withdrawalWalletState,cancelWithdrawal} from '../lib/withdrawals.ts';
import {recoverVPayPayouts,submitVPayPayout,handleVPayPayoutCallback} from '../lib/vpay-payout.ts';
import {gspayPayoutResultSignature,recoverGSPayPayouts,handleGSPayCallback} from '../lib/gspay.ts';

// Never use an existing or remote database: these tests initialize its schema.
const connection=process.env.MASTER7_ISOLATED_PAYOUT_TEST_DATABASE_URL??'';
const target=new URL(connection);
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v18_payout_test'||target.search||target.hash||!target.port)throw Error('A fresh loopback-only master7_v18_payout_test database is required');
if(process.env.MASTER7_ISOLATED_PAYOUT_POSTGRES_CONFIRM!=='master7_v18_payout_test')throw Error('Explicit isolated test database confirmation is required');
const dataKey='synthetic-withdrawal-key-'.padEnd(48,'w'),authKey='a'.repeat(32),secretKey='b'.repeat(32);
function gate(){let signal,release;return {ready:new Promise(r=>{signal=r;}),wait:new Promise(r=>{release=r;}),signal:()=>signal(),release:()=>release()};}

test('payout outcomes remain consistent on isolated PostgreSQL',async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:8});
 const previousUrl=process.env.PORTAL_POSTGRES_URL,previousSsl=process.env.PGSSLMODE,originalFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=originalFetch;if(previousUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=previousUrl;if(previousSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=previousSsl;});
 const identity=await pool.query("SELECT current_database() AS name,COUNT(*)::int AS tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,'master7_v18_payout_test');assert.equal(identity.rows[0].tables,0,'test database must be empty');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat();
 await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES ('test-owner','test-owner','owner',1,'test',0)");
 async function seed(label,provider,status='processing'){
  const user=`u-${label}`,withdrawal=`withdraw-${label}`,payout=`P7${label.replaceAll('-','')}12345678901234567890`,request=`request-${label}`;
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'test',0)",[user]);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES($1,$2,$3,'fixture','vpay',10000,'MYR','bank','credited',0,0)",[`deposit-${label}`,user,`fund-${label}`]);
  await pool.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES($1,$3,$4,'member',10000,'MYR',0),($2,$3,$4,'provider_clearing',-10000,'MYR',0)",[`member-${label}`,`clear-${label}`,`deposit-${label}`,user]);
  await pool.query("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES($1,$2,$3,$4,$4,'maybank','Maybank',$5,$6,'9012',2000,'MYR',$7,'',0,0)",[withdrawal,user,request,provider,encryptWithdrawalValue('Synthetic User',dataKey),encryptWithdrawalValue('123456789012',dataKey),status==='prepared'?'pending':'processing']);
  await pool.query("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES($1,'withdrawal',$2,2000,0)",[user,withdrawal]);
  const account=createHash('sha256').update('123456789012').digest('hex'),fingerprint=createHash('sha256').update(JSON.stringify({provider,userId:user,amount:'2000',bank:'maybank',account})).digest('hex');
  await pool.query("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,created_at,updated_at) VALUES($1,$2,$3,$4,$5,2000,'MYR',$6,$7,0,0)",[payout,withdrawal,provider,request,fingerprint,status,status==='prepared'?'not_submitted':'accepted']);
  return {user,withdrawal,payout};
 }
 async function state(f){
  const rows=await pool.query('SELECT p.status payout,w.status withdrawal,(SELECT COUNT(*)::int FROM wallet_reservations WHERE reference_id=w.id) reservations FROM provider_payouts p JOIN withdrawal_requests w ON w.id=p.withdrawal_id WHERE p.id=$1',[f.payout]);
  const wallet=await withdrawalWalletState(db,f.user);return {...rows.rows[0],balance:wallet.balanceMinor,available:wallet.availableMinor,held:wallet.withdrawalHeldMinor};
 }
 function vpayContext(fetchImpl){return {db,gatewayUrl:'https://master7-integration-gateway.onrender.com',payoutToken:'p'.repeat(40),callbackToken:'c'.repeat(40),vpayTraderId:'123',withdrawalDataKey:dataKey,fetchImpl};}
 function gspayContext(fetchImpl){return {db,apiBase:'https://api.thegspay.com',authKey,secretKey,returnUrl:'https://master7-v17-staging.onrender.com/payment/return',withdrawalDataKey:dataKey,fetchImpl};}
 const vpayReply=(id,state)=>Response.json({provider:'vpay',result:{code:0,data:{out_money_id:id,state,amount:'20.00'}}});
 const gspayReply=(id,reference,completed,success)=>Response.json({code:200,data:JSON.stringify([{payout_id:reference,transaction_id:id,account_name:'Synthetic User',account_number:'123456789012',amount:'20.00',completed,payout_success:success,signature:gspayPayoutResultSignature(reference,'123456789012','20.00',id,secretKey)}])});
 for(const provider of ['vpay','gspay'])for(const first of ['success','failure'])await t.test(`${provider} ${first} before a conflicting late response`,async()=>{
  const f=await seed(`${provider}-${first}`,provider),one=gate(),two=gate();let calls=0;
  const fetchImpl=async()=>{const n=++calls,g=n===1?one:two;g.signal();await g.wait;const success=n===1?first==='success':first!=='success';return provider==='vpay'?vpayReply(f.payout,success?'3':'2'):gspayReply(f.payout,provider==='gspay'&&first==='success'?'12340001':'12340002',true,success);};
  const c=provider==='vpay'?vpayContext(fetchImpl):gspayContext(fetchImpl),recover=provider==='vpay'?recoverVPayPayouts:recoverGSPayPayouts;
  const p1=recover(c);await one.ready;const p2=recover(c);await two.ready;one.release();await p1;two.release();await p2;
  const actual=await state(f);
  if(first==='success'){assert.equal(actual.withdrawal,'paid');assert.equal(actual.balance,'8000');assert.equal(actual.available,actual.payout==='review'?'0':'8000');assert.equal(actual.reservations,0);assert.ok(['succeeded','review'].includes(actual.payout));}
  else{assert.equal(actual.payout,'review');assert.equal(actual.withdrawal,'processing');assert.equal(actual.balance,'10000');assert.equal(actual.available,'0');assert.equal(actual.held,'2000');assert.equal(actual.reservations,1);}
 });
 for(const provider of ['vpay','gspay'])await t.test(`${provider} historical succeeded payout with processing withdrawal remains held after callback`,async()=>{
  const f=await seed(`${provider}-legacy-inconsistent`,provider),reference=provider==='vpay'?f.payout:'12340004';
  await pool.query("UPDATE provider_payouts SET status='succeeded',provider_reference=$2 WHERE id=$1",[f.payout,reference]);
  if(provider==='vpay'){
   const c=vpayContext(async()=>vpayReply(f.payout,'3'));
   await handleVPayPayoutCallback(new Request('https://portal.example.test/api/payment-callbacks/vpay/withdrawal',{method:'POST',headers:{Authorization:'Bearer '+c.callbackToken,'Content-Type':'application/json'},body:JSON.stringify({trader_id:'123',out_money_id:f.payout,state:'3',amount:'20.00'})}),c);
  }else{
   const c=gspayContext(async()=>gspayReply(f.payout,reference,true,true));
   const body={auth_key:authKey,payout_id:reference,transaction_id:f.payout,account_name:'Synthetic User',account_number:'123456789012',amount:'20.00',completed:true,payout_success:true,signature:gspayPayoutResultSignature(reference,'123456789012','20.00',f.payout,secretKey)};
   await handleGSPayCallback(new Request('https://portal.example.test/api/payment/gspay/payout/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),c);
  }
  const actual=await state(f);assert.equal(actual.withdrawal,'processing');assert.equal(actual.balance,'10000');assert.equal(actual.available,'0');assert.equal(actual.reservations,1);
 });
 await t.test('GSPAY missing status fields remain held and never imply rejection',async()=>{
  const f=await seed('gspay-missing-fields','gspay');const c=gspayContext(async()=>Response.json({code:200,data:JSON.stringify([{payout_id:'12340003',transaction_id:f.payout,account_name:'Synthetic User',account_number:'123456789012',amount:'20.00',signature:gspayPayoutResultSignature('12340003','123456789012','20.00',f.payout,secretKey)}])}));
  await recoverGSPayPayouts(c);const actual=await state(f);assert.equal(actual.withdrawal,'processing');assert.equal(actual.available,'8000');assert.equal(actual.reservations,1);assert.notEqual(actual.payout,'failed');
 });
 await t.test('cancel wins before provider claim and no VPay request is sent',async()=>{
  const f=await seed('cancel-before-claim','vpay','prepared');let calls=0;const c=vpayContext(async()=>{calls++;throw Error('Unexpected provider submission');});
  const cancellation=await cancelWithdrawal({id:f.withdrawal,status:'cancelled',ownerNote:'test'},{db,user:{id:'test-owner',username:'test-owner',role:'owner',approved:1}});assert.equal(cancellation.status,200);
  const result=await submitVPayPayout({payoutId:f.payout,withdrawalId:f.withdrawal,userId:f.user,accountHolder:'Synthetic User',accountNumber:'123456789012',bankCode:'maybank',amountMinor:'2000'},c);
  assert.notEqual(result.status,'succeeded');assert.equal(calls,0);const actual=await state(f);assert.equal(actual.withdrawal,'cancelled');assert.equal(actual.available,'10000');assert.equal(actual.reservations,0);
 });
 await t.test('simultaneous cancellation and payout claim serialize on PostgreSQL',async()=>{
  for(let i=0;i<6;i++){
   const f=await seed(`cancel-race-${i}`,'vpay','prepared'),g=gate();let calls=0;
   const c=vpayContext(async()=>{calls++;g.signal();await g.wait;throw Error('synthetic timeout');});
   const submission=submitVPayPayout({payoutId:f.payout,withdrawalId:f.withdrawal,userId:f.user,accountHolder:'Synthetic User',accountNumber:'123456789012',bankCode:'maybank',amountMinor:'2000'},c);
   const cancellation=await cancelWithdrawal({id:f.withdrawal,status:'cancelled',ownerNote:'test'},{db,user:{id:'test-owner',username:'test-owner',role:'owner',approved:1}});
   g.release();await submission;const actual=await state(f);
   if(cancellation.status===200){assert.equal(calls,0);assert.equal(actual.withdrawal,'cancelled');assert.equal(actual.reservations,0);assert.equal(actual.available,'10000');}
   else{assert.equal(cancellation.status,409);assert.equal(calls,1);assert.equal(actual.withdrawal,'processing');assert.equal(actual.reservations,1);assert.equal(actual.available,'8000');}
  }
 });
 await t.test('claimed VPay submission prevents cancellation while provider response is in flight',async()=>{
  const f=await seed('claim-before-cancel','vpay','prepared'),g=gate();let calls=0;const c=vpayContext(async(input)=>{const path=new URL(String(input)).pathname;if(path==='/platform/vpay/withdrawal'){calls++;g.signal();await g.wait;throw Error('synthetic timeout');}throw Error('Unexpected provider route');});
  const submission=submitVPayPayout({payoutId:f.payout,withdrawalId:f.withdrawal,userId:f.user,accountHolder:'Synthetic User',accountNumber:'123456789012',bankCode:'maybank',amountMinor:'2000'},c);await g.ready;
  const cancellation=await cancelWithdrawal({id:f.withdrawal,status:'cancelled',ownerNote:'test'},{db,user:{id:'test-owner',username:'test-owner',role:'owner',approved:1}});assert.equal(cancellation.status,409);g.release();await submission;
  assert.equal(calls,1);const actual=await state(f);assert.equal(actual.withdrawal,'processing');assert.equal(actual.available,'8000');assert.equal(actual.reservations,1);
 });
});
