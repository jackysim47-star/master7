import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {handleOneMpay,oneMpayCallbackToken,oneMpayCustomer} from '../lib/onempay.ts';

// Only a fresh, explicitly approved loopback database may ever be initialized.
const name='master7_v20_callback_test';
const target=new URL(process.env.MASTER7_ISOLATED_CALLBACK_DATABASE_URL??'');
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!==`/${name}`||target.search||target.hash||!target.port)throw Error('A fresh loopback-only callback test database is required');
if(process.env.MASTER7_ISOLATED_CALLBACK_CONFIRM!==name)throw Error('Explicit isolated callback database confirmation is required');
const gate=()=>{let signal,release;return {ready:new Promise(resolve=>{signal=resolve;}),wait:new Promise(resolve=>{release=resolve;}),signal:()=>signal(),release:()=>release()};};

test('1MPay acknowledgment follows query and persisted wallet state on isolated PostgreSQL',async t=>{
 const connection=target.toString(),pool=new pg.Pool({connectionString:connection,ssl:false,max:5});
 const oldUrl=process.env.PORTAL_POSTGRES_URL,oldSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(oldUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=oldUrl;if(oldSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=oldSsl;});
 const identity=await pool.query("SELECT current_database() name,COUNT(*)::int tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,name);assert.equal(identity.rows[0].tables,0,'test database must be empty');
 await initializePortalDatabase(pool,await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8')));
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected network request');};
 const db=new RenderD1Compat(),merchant='TESTMERCHANT',secret='fixture-secret-12345678';
 const baseContext={db,user:null,apiBase:'https://api.1mpay.net',merchant,secretKey:secret,callbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',returnUrl:'https://master7-v17-staging.onrender.com/payment/return'};
 async function seed(user,id){
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'fixture',0)",[user]);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES($1,$2,$3,'fixture','1mpay',2000,'MYR','bank','unknown',0,0)",[id,user,'request-'+id]);
 }
 async function state(id){
  const order=(await pool.query('SELECT status,provider_trade_no FROM deposit_orders WHERE id=$1',[id])).rows[0];
  const entries=(await pool.query('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=$1 ORDER BY account_code',[id])).rows.map(x=>({...x,amount_minor:String(x.amount_minor)}));
  return {order,entries};
 }
 function fixture(user,refid,trxno,control={}){
  const customer=oneMpayCustomer(user),token=oneMpayCallbackToken(merchant,'20.00',refid,customer,secret,trxno);
  const callback=()=>handleOneMpay(new Request('https://portal.example.test/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({merchant,amount:'20.00',refid,customer,trxno,status:'Successful',token})}),context);
  const context={...baseContext,fetchImpl:async input=>{
   assert.equal(new URL(String(input)).origin,'https://api.1mpay.net');assert.ok(new URL(String(input)).pathname.startsWith('/transquery/'));
   if(control.queryGate){control.queryGate.signal();await control.queryGate.wait;}
   return Response.json({merchant,amount:'20.00',refid,customer,trxno,currency:'MYR',status:control.status??'Successful',token});
  }};
  return {callback,context};
 }
 const balanced=user=>[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:user},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:user}];
 async function markReview(user,id){
  const client=await pool.connect();try{await client.query('BEGIN');await client.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);await client.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);await client.query("UPDATE deposit_orders SET status='review' WHERE id=$1 AND user_id=$2",[id,user]);await client.query('COMMIT');}catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}
 }
 await t.test('unconfirmed query is not acknowledged; a later confirmation credits once even with repeated callbacks',async()=>{
  const user='callback-pending-user',id='M7pending-callback',reference='pending-trade';await seed(user,id);
  const control={status:'Pending'},f=fixture(user,id,reference,control);
  const pending=await f.callback();assert.equal(pending.status,503);assert.notEqual(await pending.text(),'ok');
  assert.deepEqual(await state(id),{order:{status:'unknown',provider_trade_no:reference},entries:[]});
  control.status='Successful';const responses=await Promise.all([f.callback(),f.callback(),f.callback()]);
  for(const response of responses){assert.equal(response.status,200);assert.equal(await response.text(),'ok');}
  assert.deepEqual(await state(id),{order:{status:'credited',provider_trade_no:reference},entries:balanced(user)});
 });
 await t.test('a concurrent review before first credit prevents a success acknowledgment and ledger writes',async sub=>{
  const user='callback-review-user',id='M7review-callback',reference='review-trade';await seed(user,id);const queryGate=gate(),f=fixture(user,id,reference,{queryGate});sub.after(()=>queryGate.release());
  const pending=f.callback();await queryGate.ready;await markReview(user,id);queryGate.release();
  const result=await pending;assert.equal(result.status,503);assert.notEqual(await result.text(),'ok');
  assert.deepEqual(await state(id),{order:{status:'review',provider_trade_no:reference},entries:[]});
 });
 await t.test('a concurrent review of an already credited order cannot receive a stale success acknowledgment',async sub=>{
  const user='callback-credited-user',id='M7credited-callback',reference='credited-trade';await seed(user,id);
  const first=await fixture(user,id,reference).callback();assert.equal(first.status,200);assert.equal(await first.text(),'ok');
  const queryGate=gate(),f=fixture(user,id,reference,{queryGate});sub.after(()=>queryGate.release());
  const pending=f.callback();await queryGate.ready;await markReview(user,id);queryGate.release();
  const result=await pending;assert.equal(result.status,503);assert.notEqual(await result.text(),'ok');
  assert.deepEqual(await state(id),{order:{status:'review',provider_trade_no:reference},entries:balanced(user)});
 });
});
