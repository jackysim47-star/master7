import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {mkdtempSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,createPublicKey,generateKeyPairSync,randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import pg from 'pg';
import {initializePortalDatabase,ACCEPTANCE_LEDGER_INTEGRITY_MIGRATION} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {GameProviderAcceptanceError,getGameProviderAcceptanceReadiness,recordGameProviderAcceptance} from '../lib/game-provider-acceptance.ts';
import {ProductionAcceptanceError,getProductionAcceptanceReadiness,recordProductionAcceptance} from '../lib/production-acceptance.ts';
import {BACKUP_TABLES,createEncryptedPortalBackup} from '../lib/encrypted-backup.ts';

const connection=process.env.MASTER7_ISOLATED_ACCEPTANCE_DATABASE_URL??'';let target;
try{target=new URL(connection);}catch{throw Error('A fresh loopback-only acceptance database is required');}
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v165_acceptance_test'||target.search||target.hash||!target.port||process.env.MASTER7_ISOLATED_ACCEPTANCE_CONFIRM!=='master7_v165_acceptance_test')throw Error('A fresh loopback-only acceptance database is required');

test('acceptance ledgers are immutable, contiguous and fail closed on PostgreSQL 18',{timeout:90000},async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:6}),oldUrl=process.env.PORTAL_POSTGRES_URL,oldSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(oldUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=oldUrl;if(oldSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=oldSsl;});
 const identity=(await pool.query("SELECT current_database() name,current_setting('server_version_num')::int version,(SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public')::int tables")).rows[0];
 assert.equal(identity.name,'master7_v165_acceptance_test');assert.ok(identity.version>=180000,`PostgreSQL 18 required, got ${identity.version}`);assert.equal(identity.tables,0,'Refuse nonempty database');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);await initializePortalDatabase(pool,schema,directory);
 assert.equal((await pool.query('SELECT COUNT(*)::int n FROM portal_schema_migrations WHERE version=$1',[ACCEPTANCE_LEDGER_INTEGRITY_MIGRATION])).rows[0].n,1);
 const requiredTriggers=['game_provider_acceptance_events_immutable','game_provider_acceptance_events_no_truncate','production_acceptance_events_immutable','production_acceptance_events_no_truncate','game_provider_acceptance_current_monotonic','game_provider_acceptance_current_no_truncate','production_acceptance_current_monotonic','production_acceptance_current_no_truncate'];
 const triggers=(await pool.query(`SELECT t.tgname name,t.tgenabled enabled FROM pg_catalog.pg_trigger t WHERE NOT t.tgisinternal AND t.tgname=ANY($1::text[]) ORDER BY t.tgname`,[requiredTriggers])).rows;
 assert.deepEqual(triggers.map(row=>row.name),[...requiredTriggers].sort());assert.ok(triggers.every(row=>row.enabled==='O'));
 await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner','owner',1,'fixture',0)");
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};const db=new RenderD1Compat(),owner={id:'owner',role:'owner'};

 const game={profileId:'megah5_myr',capability:'catalogue',environment:'production',result:'passed',evidenceSha256:'a'.repeat(64),evidenceReference:'pg18:game-race',observedAt:100,expectedEventId:null};
 const gameRace=await Promise.allSettled([recordGameProviderAcceptance(db,owner,game,101),recordGameProviderAcceptance(db,owner,{...game,evidenceSha256:'b'.repeat(64)},101)]);
 assert.equal(gameRace.filter(item=>item.status==='fulfilled').length,1);const gameLoser=gameRace.find(item=>item.status==='rejected');assert.ok(gameLoser?.reason instanceof GameProviderAcceptanceError);assert.equal(gameLoser.reason.code,'STALE_ACCEPTANCE');
 const gameFirst=gameRace.find(item=>item.status==='fulfilled').value,gameSecond=await recordGameProviderAcceptance(db,owner,{...game,result:'revoked',evidenceSha256:'c'.repeat(64),evidenceReference:'pg18:game-2',expectedEventId:gameFirst.id},102);assert.ok(gameSecond.id);
 await assert.rejects(()=>pool.query(`INSERT INTO game_provider_acceptance_events(id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at) VALUES('gap-game','megah5_myr',3,'launch','production','passed',$1,'pg18:gap','owner',103,103)`,['d'.repeat(64)]),/contiguous/);
 await assert.rejects(()=>pool.query('UPDATE game_provider_acceptance_events SET result=$1 WHERE id=$2',['passed',gameFirst.id]),/immutable/);await assert.rejects(()=>pool.query('TRUNCATE game_provider_acceptance_current'),/truncated/);await assert.rejects(()=>pool.query('TRUNCATE game_provider_acceptance_current,game_provider_acceptance_events CASCADE'),/immutable|truncated/);
 const gameOrphan='55555555-5555-4555-8555-555555555555';await pool.query(`INSERT INTO game_provider_acceptance_events(id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at) VALUES($1,'megah5_myr',3,'catalogue','production','passed',$2,'pg18:orphan','owner',103,103)`,[gameOrphan,'e'.repeat(64)]);
 assert.equal((await getGameProviderAcceptanceReadiness(db)).integrityReady,false);await assert.rejects(()=>recordGameProviderAcceptance(db,owner,{...game,expectedEventId:gameOrphan},104),error=>error instanceof GameProviderAcceptanceError&&error.code==='ACCEPTANCE_INTEGRITY_ERROR');await pool.query("UPDATE game_provider_acceptance_current SET event_id=$1 WHERE profile_id='megah5_myr' AND capability='catalogue' AND environment='production'",[gameOrphan]);assert.equal((await getGameProviderAcceptanceReadiness(db)).integrityReady,true);

 const production={category:'domain',subjectId:'www.master7.best',capability:'dns_tls_routing',environment:'production',result:'passed',evidenceSha256:'1'.repeat(64),evidenceReference:'pg18:production-race',observedAt:100,expectedEventId:null};
 const productionRace=await Promise.allSettled([recordProductionAcceptance(db,owner,production,101),recordProductionAcceptance(db,owner,{...production,evidenceSha256:'2'.repeat(64)},101)]);
 assert.equal(productionRace.filter(item=>item.status==='fulfilled').length,1);const productionLoser=productionRace.find(item=>item.status==='rejected');assert.ok(productionLoser?.reason instanceof ProductionAcceptanceError);assert.equal(productionLoser.reason.code,'STALE_ACCEPTANCE');
 await assert.rejects(()=>pool.query(`INSERT INTO production_acceptance_events(id,category,subject_id,capability,environment,revision,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at) VALUES('gap-production','domain','www.master7.site','dns_tls_routing','production',3,'passed',$1,'pg18:gap','owner',103,103)`,['3'.repeat(64)]),/contiguous/);
 await assert.rejects(()=>pool.query('TRUNCATE production_acceptance_current'),/truncated/);await assert.rejects(()=>pool.query('TRUNCATE production_acceptance_current,production_acceptance_events CASCADE'),/immutable|truncated/);assert.equal((await getProductionAcceptanceReadiness(db)).integrityReady,true);

 const restoreDirectory=mkdtempSync(join(tmpdir(),'master7-v165-acceptance-restore-')),passphrase=randomBytes(24).toString('hex'),{publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem',cipher:'aes-256-cbc',passphrase}}),fingerprint=createHash('sha256').update(createPublicKey(publicKey).export({type:'spki',format:'der'})).digest('hex');
 try{
  const {envelope}=await createEncryptedPortalBackup(db,'synthetic-v165-acceptance',{publicKey,publicKeySha256:fingerprint});for(const [name,value] of [['backup.json',JSON.stringify(envelope)],['private.pem',privateKey],['passphrase',passphrase]])writeFileSync(join(restoreDirectory,name),value,{mode:0o600});
  await pool.query('DROP DATABASE IF EXISTS master7_v165_acceptance_restore WITH (FORCE)');await pool.query('CREATE DATABASE master7_v165_acceptance_restore');const restoreUrl=new URL(connection);restoreUrl.pathname='/master7_v165_acceptance_restore';let output='';
  const status=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,[fileURLToPath(new URL('./postgres-restore-dry-run.mjs',import.meta.url)),join(restoreDirectory,'backup.json'),join(restoreDirectory,'private.pem'),join(restoreDirectory,'passphrase'),join(restoreDirectory,'receipt.json'),'--confirm-isolated'],{env:{...process.env,MASTER7_RESTORE_DATABASE_URL:restoreUrl.href,PORTAL_POSTGRES_URL:connection,PGSSLMODE:'disable'}});child.stdout.on('data',value=>output+=value);child.stderr.on('data',value=>output+=value);child.on('error',reject);child.on('exit',resolve);});
  assert.equal(status,0,output);const receipt=JSON.parse(readFileSync(join(restoreDirectory,'receipt.json'),'utf8'));assert.equal(receipt.coverageComplete,true);assert.equal(receipt.tableCount,BACKUP_TABLES.length);assert.equal(receipt.persistentWrites,false);assert.equal(receipt.tables.find(item=>item.name==='game_provider_acceptance_events').rows,3);assert.equal(receipt.tables.find(item=>item.name==='production_acceptance_events').rows,1);
  const restored=new pg.Client({connectionString:restoreUrl.href,ssl:false});await restored.connect();try{assert.equal((await restored.query("SELECT COUNT(*)::int n FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")).rows[0].n,0);}finally{await restored.end();}
  await pool.query('DROP DATABASE master7_v165_acceptance_restore WITH (FORCE)');
 }finally{rmSync(restoreDirectory,{recursive:true,force:true});}
});
