import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {mkdtempSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,createPublicKey,generateKeyPairSync,randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import pg from 'pg';
import {initializePortalDatabase,assertCriticalDatabaseGuards,CRITICAL_DATABASE_GUARDS,ACCEPTANCE_LEDGER_INTEGRITY_MIGRATION} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {GameProviderAcceptanceError,getGameProviderAcceptanceReadiness,recordGameProviderAcceptance} from '../lib/game-provider-acceptance.ts';
import {ProductionAcceptanceError,getProductionAcceptanceReadiness,recordProductionAcceptance} from '../lib/production-acceptance.ts';
import {BACKUP_TABLES,createEncryptedPortalBackup} from '../lib/encrypted-backup.ts';
import {startRuntimeDatabaseGuardMonitor} from './runtime-database-guard-monitor.mjs';

const connection=process.env.MASTER7_ISOLATED_ACCEPTANCE_DATABASE_URL??'';let target;
try{target=new URL(connection);}catch{throw Error('A fresh loopback-only acceptance database is required');}
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v169_acceptance_test'||target.search||target.hash||!target.port||process.env.MASTER7_ISOLATED_ACCEPTANCE_CONFIRM!=='master7_v169_acceptance_test')throw Error('A fresh loopback-only acceptance database is required');

test('acceptance ledgers are immutable, contiguous and fail closed on PostgreSQL 18',{timeout:90000},async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:6}),oldUrl=process.env.PORTAL_POSTGRES_URL,oldSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(oldUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=oldUrl;if(oldSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=oldSsl;});
 const identity=(await pool.query("SELECT current_database() name,current_setting('server_version_num')::int version,(SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public')::int tables")).rows[0];
 assert.equal(identity.name,'master7_v169_acceptance_test');assert.ok(identity.version>=180000,`PostgreSQL 18 required, got ${identity.version}`);assert.equal(identity.tables,0,'Refuse nonempty database');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);await initializePortalDatabase(pool,schema,directory);
 assert.equal((await pool.query('SELECT COUNT(*)::int n FROM portal_schema_migrations WHERE version=$1',[ACCEPTANCE_LEDGER_INTEGRITY_MIGRATION])).rows[0].n,1);
 const attestation=await assertCriticalDatabaseGuards(pool);assert.equal(attestation.criticalDatabaseGuardsReady,true);assert.equal(attestation.criticalDatabaseGuardCount,9);assert.equal(attestation.criticalDatabaseGuardFunctionCount,5);
 const requiredTriggers=CRITICAL_DATABASE_GUARDS.map(item=>item.triggerName);
 const triggers=(await pool.query(`SELECT t.tgname name,t.tgenabled enabled FROM pg_catalog.pg_trigger t WHERE NOT t.tgisinternal AND t.tgname=ANY($1::text[]) ORDER BY t.tgname`,[requiredTriggers])).rows;
 assert.deepEqual(triggers.map(row=>row.name),[...requiredTriggers].sort());assert.ok(triggers.every(row=>row.enabled==='O'));

 const rejectFunctionDefinition=(await pool.query("SELECT pg_get_functiondef(p.oid) definition FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='reject_provider_wallet_contract_mutation' AND pg_get_function_identity_arguments(p.oid)='' ")).rows[0]?.definition;
 assert.ok(rejectFunctionDefinition);
 const rejectDrift=async(mutate,restore=async()=>pool.query(rejectFunctionDefinition))=>{
  await mutate();
  await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
  await assert.rejects(()=>assertCriticalDatabaseGuards(pool),/Critical database guard attestation failed/);
  await restore();
  assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardFunctionCount,5);
 };
 await rejectDrift(()=>pool.query("CREATE OR REPLACE FUNCTION reject_provider_wallet_contract_mutation() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RETURN NEW; END $$"));
 await rejectDrift(()=>pool.query('ALTER FUNCTION reject_provider_wallet_contract_mutation() SECURITY DEFINER'),()=>pool.query('ALTER FUNCTION reject_provider_wallet_contract_mutation() SECURITY INVOKER'));
 await rejectDrift(()=>pool.query("ALTER FUNCTION reject_provider_wallet_contract_mutation() SET search_path TO pg_catalog"),()=>pool.query('ALTER FUNCTION reject_provider_wallet_contract_mutation() SET search_path TO pg_catalog, pg_temp'));
 await rejectDrift(()=>pool.query('ALTER FUNCTION reject_provider_wallet_contract_mutation() STABLE'),()=>pool.query('ALTER FUNCTION reject_provider_wallet_contract_mutation() VOLATILE'));

 const scheduledMonitorChecks=[],monitorExits=[],monitorErrors=[];
 const runtimeMonitor=startRuntimeDatabaseGuardMonitor({connectionString:connection,ssl:false,clientFactory:()=>new pg.Client({connectionString:connection,ssl:false}),schedule:callback=>{scheduledMonitorChecks.push(callback);return callback;},cancel:()=>{},exit:code=>monitorExits.push(code),logger:{log:()=>{},error:message=>monitorErrors.push(message)}});
 assert.equal(await runtimeMonitor.ready,true);assert.equal(scheduledMonitorChecks.length,1);
 await pool.query("CREATE OR REPLACE FUNCTION reject_provider_wallet_contract_mutation() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RETURN NEW; END $$");
 assert.equal(await scheduledMonitorChecks.shift()(),false);assert.deepEqual(monitorExits,[1]);assert.deepEqual(monitorErrors,['MASTER7 runtime database guard monitor fail-closed (ATTESTATION:UNKNOWN); exiting.']);
 await assert.rejects(()=>assertCriticalDatabaseGuards(pool),/Critical database guard attestation failed/);
 assert.match((await pool.query("SELECT prosrc source FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='reject_provider_wallet_contract_mutation' AND pg_get_function_identity_arguments(p.oid)='' ")).rows[0].source,/RETURN NEW/);
 await pool.query(rejectFunctionDefinition);assert.equal((await assertCriticalDatabaseGuards(pool)).criticalDatabaseGuardFunctionCount,5);await runtimeMonitor.stop();

 await pool.query('ALTER TABLE provider_wallet_operations DISABLE TRIGGER provider_wallet_contract_immutable');
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
 await pool.query('ALTER TABLE provider_wallet_operations ENABLE TRIGGER provider_wallet_contract_immutable');
 assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);

 const missingDefinition=(await pool.query("SELECT pg_get_triggerdef(t.oid) definition FROM pg_catalog.pg_trigger t JOIN pg_catalog.pg_class c ON c.oid=t.tgrelid WHERE c.relname='production_acceptance_current' AND t.tgname='production_acceptance_current_no_truncate' AND NOT t.tgisinternal")).rows[0]?.definition;
 assert.ok(missingDefinition);await pool.query('DROP TRIGGER production_acceptance_current_no_truncate ON production_acceptance_current');
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
 await pool.query(missingDefinition);assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);

 const reboundDefinition=(await pool.query("SELECT pg_get_triggerdef(t.oid) definition FROM pg_catalog.pg_trigger t JOIN pg_catalog.pg_class c ON c.oid=t.tgrelid WHERE c.relname='provider_wallet_operations' AND t.tgname='provider_wallet_contract_immutable' AND NOT t.tgisinternal")).rows[0]?.definition;
 assert.ok(reboundDefinition);await pool.query("CREATE OR REPLACE FUNCTION v169_noop_guard() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RETURN NEW; END $$");
 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');
 await pool.query('CREATE TRIGGER provider_wallet_contract_immutable BEFORE UPDATE OF withdrawal_mode,adapter_contract_sha256 ON provider_wallet_operations FOR EACH ROW EXECUTE FUNCTION v169_noop_guard()');
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');await pool.query(reboundDefinition);await pool.query('DROP FUNCTION v169_noop_guard()');
 assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);

 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');
 await pool.query('CREATE TRIGGER provider_wallet_contract_immutable BEFORE UPDATE OF last_error_code ON provider_wallet_operations FOR EACH ROW EXECUTE FUNCTION reject_provider_wallet_contract_mutation()');
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');await pool.query(reboundDefinition);
 assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);

 await pool.query("CREATE OR REPLACE FUNCTION v169_late_mutation_guard() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,pg_temp AS $$ BEGIN NEW.withdrawal_mode='all'; RETURN NEW; END $$");
 await pool.query('CREATE TRIGGER zzz_provider_wallet_late_mutation BEFORE UPDATE ON provider_wallet_operations FOR EACH ROW EXECUTE FUNCTION v169_late_mutation_guard()');
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed \(invalid 0 of 9; unexpected 1;/);
 await assert.rejects(()=>assertCriticalDatabaseGuards(pool),/Critical database guard attestation failed \(invalid 0 of 9; unexpected 1;/);
 await pool.query('DROP TRIGGER zzz_provider_wallet_late_mutation ON provider_wallet_operations');await pool.query('DROP FUNCTION v169_late_mutation_guard()');
 assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);

 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');
 await pool.query('CREATE TRIGGER provider_wallet_contract_immutable BEFORE UPDATE OF withdrawal_mode,adapter_contract_sha256 ON provider_wallet_operations FOR EACH ROW WHEN (false) EXECUTE FUNCTION reject_provider_wallet_contract_mutation()');
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');await pool.query(reboundDefinition);
 assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);

 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');
 await pool.query("CREATE TRIGGER provider_wallet_contract_immutable BEFORE UPDATE OF withdrawal_mode,adapter_contract_sha256 ON provider_wallet_operations FOR EACH ROW EXECUTE FUNCTION reject_provider_wallet_contract_mutation('unexpected')");
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
 await pool.query('DROP TRIGGER provider_wallet_contract_immutable ON provider_wallet_operations');await pool.query(reboundDefinition);
 assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);

 await pool.query('DROP TRIGGER production_acceptance_current_no_truncate ON production_acceptance_current');
 await pool.query('CREATE TRIGGER production_acceptance_current_no_truncate BEFORE TRUNCATE ON production_acceptance_events FOR EACH STATEMENT EXECUTE FUNCTION guard_production_acceptance_current()');
 await assert.rejects(()=>initializePortalDatabase(pool,schema,directory),/Critical database guard attestation failed/);
 await pool.query('DROP TRIGGER production_acceptance_current_no_truncate ON production_acceptance_events');await pool.query(missingDefinition);
 assert.equal((await initializePortalDatabase(pool,schema,directory)).criticalDatabaseGuardsReady,true);
 await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner','owner',1,'fixture',0)");

 const shadowClient=await pool.connect();
 try{
  await shadowClient.query('BEGIN');
  await shadowClient.query('SET LOCAL search_path TO pg_temp, public');
  await shadowClient.query('CREATE TEMP TABLE game_provider_acceptance_events(profile_id TEXT,capability TEXT,environment TEXT,revision INTEGER)');
  await shadowClient.query("INSERT INTO game_provider_acceptance_events VALUES('megah5_myr','catalogue','production',1)");
  await shadowClient.query('SAVEPOINT shadow_insert');
  await assert.rejects(()=>shadowClient.query(`INSERT INTO public.game_provider_acceptance_events(id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
   VALUES('shadow-gap','megah5_myr',2,'catalogue','production','passed',$1,'pg18:shadow','owner',1,1)`,['9'.repeat(64)]),/contiguous/);
  await shadowClient.query('ROLLBACK TO SAVEPOINT shadow_insert');
  assert.equal((await shadowClient.query("SELECT COUNT(*)::int n FROM public.game_provider_acceptance_events WHERE id='shadow-gap'")).rows[0].n,0);
 }finally{
  try{await shadowClient.query('ROLLBACK');shadowClient.release();}
  catch{shadowClient.release(true);}
 }

 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};const db=new RenderD1Compat(),owner={id:'owner',role:'owner'};

 const game={profileId:'megah5_myr',capability:'catalogue',environment:'production',result:'passed',evidenceSha256:'a'.repeat(64),evidenceReference:'pg18:game-race',observedAt:100,expectedEventId:null};
 const gameRace=await Promise.allSettled([recordGameProviderAcceptance(db,owner,game,101),recordGameProviderAcceptance(db,owner,{...game,evidenceSha256:'b'.repeat(64)},101)]);
 assert.equal(gameRace.filter(item=>item.status==='fulfilled').length,1);const gameLoser=gameRace.find(item=>item.status==='rejected');assert.ok(gameLoser?.reason instanceof GameProviderAcceptanceError);assert.equal(gameLoser.reason.code,'STALE_ACCEPTANCE');
 const gameFirst=gameRace.find(item=>item.status==='fulfilled').value,gameSecond=await recordGameProviderAcceptance(db,owner,{...game,result:'revoked',evidenceSha256:'c'.repeat(64),evidenceReference:'pg18:game-2',expectedEventId:gameFirst.id},102);assert.ok(gameSecond.id);
 await assert.rejects(()=>pool.query(`INSERT INTO game_provider_acceptance_events(id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at) VALUES('gap-game','megah5_myr',3,'launch','production','passed',$1,'pg18:gap','owner',103,103)`,['d'.repeat(64)]),/contiguous/);
 await assert.rejects(()=>pool.query('UPDATE game_provider_acceptance_events SET result=$1 WHERE id=$2',['passed',gameFirst.id]),/immutable/);await assert.rejects(()=>pool.query('TRUNCATE game_provider_acceptance_current'),/truncated/);await assert.rejects(()=>pool.query('TRUNCATE game_provider_acceptance_current,game_provider_acceptance_events CASCADE'),/immutable|truncated/);
 const gameOrphan='55555555-5555-4555-8555-555555555555';await pool.query(`INSERT INTO game_provider_acceptance_events(id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at) VALUES($1,'megah5_myr',3,'catalogue','production','passed',$2,'pg18:orphan','owner',103,103)`,[gameOrphan,'e'.repeat(64)]);
 assert.equal((await getGameProviderAcceptanceReadiness(db)).integrityReady,false);await assert.rejects(()=>recordGameProviderAcceptance(db,owner,{...game,expectedEventId:gameOrphan},104),error=>error instanceof GameProviderAcceptanceError&&error.code==='ACCEPTANCE_INTEGRITY_ERROR');await pool.query("UPDATE game_provider_acceptance_current SET event_id=$1 WHERE profile_id='megah5_myr' AND capability='catalogue' AND environment='production'",[gameOrphan]);assert.equal((await getGameProviderAcceptanceReadiness(db)).integrityReady,true);

 const production={category:'domain',subjectId:'www.master7.best',capability:'dns_tls_routing',environment:'production',result:'passed',evidenceSha256:'1'.repeat(64),evidenceReference:'pg18:production-race',observedAt:100,expectedEventId:null};
 const productionRace=await Promise.allSettled([recordProductionAcceptance(db,owner,production,101),recordProductionAcceptance(db,owner,{...production,evidenceSha256:'2'.repeat(64)},101)]);
 assert.equal(productionRace.filter(item=>item.status==='fulfilled').length,1);const productionLoser=productionRace.find(item=>item.status==='rejected');assert.ok(productionLoser?.reason instanceof ProductionAcceptanceError);assert.equal(productionLoser.reason.code,'STALE_ACCEPTANCE');
 await assert.rejects(()=>pool.query(`INSERT INTO production_acceptance_events(id,category,subject_id,capability,environment,revision,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at) VALUES('gap-production','domain','www.master7.site','dns_tls_routing','production',3,'passed',$1,'pg18:gap','owner',103,103)`,['3'.repeat(64)]),/contiguous/);
 await assert.rejects(()=>pool.query('TRUNCATE production_acceptance_current'),/truncated/);await assert.rejects(()=>pool.query('TRUNCATE production_acceptance_current,production_acceptance_events CASCADE'),/immutable|truncated/);assert.equal((await getProductionAcceptanceReadiness(db)).integrityReady,true);

 const restoreDirectory=mkdtempSync(join(tmpdir(),'master7-v169-acceptance-restore-')),passphrase=randomBytes(24).toString('hex'),{publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem',cipher:'aes-256-cbc',passphrase}}),fingerprint=createHash('sha256').update(createPublicKey(publicKey).export({type:'spki',format:'der'})).digest('hex');
 try{
  const {envelope}=await createEncryptedPortalBackup(db,'synthetic-v169-acceptance',{publicKey,publicKeySha256:fingerprint});for(const [name,value] of [['backup.json',JSON.stringify(envelope)],['private.pem',privateKey],['passphrase',passphrase]])writeFileSync(join(restoreDirectory,name),value,{mode:0o600});
  await pool.query('DROP DATABASE IF EXISTS master7_v169_acceptance_restore WITH (FORCE)');await pool.query('CREATE DATABASE master7_v169_acceptance_restore');const restoreUrl=new URL(connection);restoreUrl.pathname='/master7_v169_acceptance_restore';let output='';
  const status=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,[fileURLToPath(new URL('./postgres-restore-dry-run.mjs',import.meta.url)),join(restoreDirectory,'backup.json'),join(restoreDirectory,'private.pem'),join(restoreDirectory,'passphrase'),join(restoreDirectory,'receipt.json'),'--confirm-isolated'],{env:{...process.env,MASTER7_RESTORE_DATABASE_URL:restoreUrl.href,PORTAL_POSTGRES_URL:connection,PGSSLMODE:'disable'}});child.stdout.on('data',value=>output+=value);child.stderr.on('data',value=>output+=value);child.on('error',reject);child.on('exit',resolve);});
  assert.equal(status,0,output);const receipt=JSON.parse(readFileSync(join(restoreDirectory,'receipt.json'),'utf8'));assert.equal(receipt.coverageComplete,true);assert.equal(receipt.tableCount,BACKUP_TABLES.length);assert.equal(receipt.persistentWrites,false);assert.equal(receipt.tables.find(item=>item.name==='game_provider_acceptance_events').rows,3);assert.equal(receipt.tables.find(item=>item.name==='production_acceptance_events').rows,1);
  const restored=new pg.Client({connectionString:restoreUrl.href,ssl:false});await restored.connect();try{assert.equal((await restored.query("SELECT COUNT(*)::int n FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")).rows[0].n,0);}finally{await restored.end();}
  await pool.query('DROP DATABASE master7_v169_acceptance_restore WITH (FORCE)');
 }finally{rmSync(restoreDirectory,{recursive:true,force:true});}
});
