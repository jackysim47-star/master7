import {constants,createDecipheriv,createHash,privateDecrypt} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {basename,join} from 'node:path';
import {gunzipSync} from 'node:zlib';

const [backupPath,privateKeyPath,passphrasePath,receiptPath]=process.argv.slice(2);
if(!backupPath||!privateKeyPath||!passphrasePath)throw new Error('Usage: node scripts/verify-encrypted-backup.mjs BACKUP PRIVATE_KEY PASSPHRASE [RECEIPT]');
const hash=value=>createHash('sha256').update(value).digest('hex'),envelope=JSON.parse(readFileSync(backupPath,'utf8'));
if(envelope.format!=='MASTER7-ENCRYPTED-BACKUP-1')throw new Error('Unsupported backup format');
const ciphertext=Buffer.from(envelope.ciphertext,'base64');
if(hash(ciphertext)!==envelope.ciphertextSha256)throw new Error('Ciphertext hash mismatch');
const contentKey=privateDecrypt({key:readFileSync(privateKeyPath),passphrase:readFileSync(passphrasePath,'utf8').trim(),oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64'));
const decipher=createDecipheriv('aes-256-gcm',contentKey,Buffer.from(envelope.iv,'base64'));decipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));
const plaintext=gunzipSync(Buffer.concat([decipher.update(ciphertext),decipher.final()]));
if(hash(plaintext)!==envelope.plaintextSha256)throw new Error('Plaintext hash mismatch');
const payload=JSON.parse(plaintext.toString('utf8'));
if(payload.format!==envelope.format||payload.release!==envelope.release)throw new Error('Envelope and payload metadata mismatch');
for(const table of payload.manifest.tables){const rows=payload.tables[table.name];if(!Array.isArray(rows)||rows.length!==table.rows||hash(JSON.stringify(rows))!==table.sha256)throw new Error(`Manifest mismatch for ${table.name}`);}

const root=new URL('..',import.meta.url).pathname,migrations=['0000_broken_bloodscream.sql','0001_orange_owl.sql','0002_lobby_ads.sql','0003_game_visibility.sql','0004_sponsored_brands.sql','0005_custom_game_cards.sql','0006_malaysia_member_phone.sql','0007_vpay_uat_wallet.sql','0008_member_sms_otp.sql','0009_game_payment_statuses.sql','0010_game_visibility_artwork.sql','0011_provider_artwork.sql','0012_close_defaults_and_brand_directory.sql','0013_api_supplier_artwork.sql','0014_withdrawal_requests.sql','0019_game_catalogue_sync.sql','0020_manual_bank_deposits.sql','0021_api_supplier_status.sql','0022_referrals.sql','0023_marketing_campaigns.sql','0024_megah5_transfer_wallet.sql'],db=new DatabaseSync(':memory:');
for(const migration of migrations)db.exec(readFileSync(join(root,'drizzle',migration),'utf8'));
const tableNames=payload.manifest.tables.map(item=>item.name);for(const table of tableNames)if(!/^[a-z][a-z0-9_]*$/.test(table))throw new Error('Unsafe table name');
db.exec('PRAGMA foreign_keys=OFF; BEGIN');
try{
 for(const table of [...tableNames].reverse())db.exec(`DELETE FROM ${table}`);
 for(const table of tableNames){
  const available=new Set(db.prepare(`PRAGMA table_info(${table})`).all().map(item=>item.name)),rows=payload.tables[table];
  for(const row of rows){const columns=Object.keys(row);for(const column of columns)if(!available.has(column))throw new Error(`Restore schema missing ${table}.${column}`);const marks=columns.map(()=>'?').join(','),sql=`INSERT INTO ${table}(${columns.join(',')}) VALUES(${marks})`,values=columns.map(column=>{const value=row[column];if(typeof value==='boolean')return value?1:0;if(value&&typeof value==='object')return JSON.stringify(value);return value??null;});db.prepare(sql).run(...values);}
 }
 db.exec('COMMIT; PRAGMA foreign_keys=ON');
}catch(error){db.exec('ROLLBACK');throw error;}
const foreignKeyViolations=db.prepare('PRAGMA foreign_key_check').all();if(foreignKeyViolations.length)throw new Error(`Foreign key validation failed: ${foreignKeyViolations.length}`);
const restored=tableNames.map(name=>({name,rows:Number(db.prepare(`SELECT COUNT(*) count FROM ${name}`).get().count)}));for(const item of restored){const expected=payload.manifest.tables.find(table=>table.name===item.name)?.rows;if(item.rows!==expected)throw new Error(`Restore count mismatch for ${item.name}`);}
const excludedCounts=Object.fromEntries((payload.restorePolicy?.excludedTables??[]).map(name=>[name,Number(db.prepare(`SELECT COUNT(*) count FROM ${name}`).get().count)]));if(Object.values(excludedCounts).some(Number))throw new Error('Ephemeral authentication data was restored unexpectedly');
const receipt={status:'verified',format:envelope.format,release:envelope.release,backupFile:basename(backupPath),backupSha256:hash(readFileSync(backupPath)),createdAt:envelope.createdAt,verifiedAt:new Date().toISOString(),publicKeySha256:envelope.publicKeySha256,plaintextSha256:envelope.plaintextSha256,tableCount:restored.length,totalRecords:restored.reduce((sum,item)=>sum+item.rows,0),tables:restored,excludedTables:excludedCounts,foreignKeyViolations:0,restoreTarget:'isolated in-memory SQLite schema'};
if(receiptPath)writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n',{mode:0o600});
process.stdout.write(JSON.stringify({status:receipt.status,release:receipt.release,tableCount:receipt.tableCount,totalRecords:receipt.totalRecords,foreignKeyViolations:receipt.foreignKeyViolations})+'\n');
