import {constants,createDecipheriv,createHash,privateDecrypt} from 'node:crypto';
import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {basename,join} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {ACCEPTANCE_PROTECTED_TABLES,BACKUP_EXCLUDED_TABLES,BACKUP_FORMAT,BACKUP_TABLES,backupRestoreContract,orderBackupRestoreRows} from '../lib/encrypted-backup.ts';

const [backupPath,privateKeyPath,passphrasePath,receiptPath]=process.argv.slice(2);
if(!backupPath||!privateKeyPath||!passphrasePath)throw new Error('Usage: node scripts/verify-encrypted-backup.mjs BACKUP PRIVATE_KEY PASSPHRASE [RECEIPT]');
const hash=value=>createHash('sha256').update(value).digest('hex'),envelope=JSON.parse(readFileSync(backupPath,'utf8'));
if(envelope.format!==BACKUP_FORMAT)throw new Error('Unsupported backup format');
const contract=backupRestoreContract(envelope.schemaVersion,envelope.schemaSha256);
const ciphertext=Buffer.from(envelope.ciphertext,'base64');
if(hash(ciphertext)!==envelope.ciphertextSha256)throw new Error('Ciphertext hash mismatch');
const contentKey=privateDecrypt({key:readFileSync(privateKeyPath),passphrase:readFileSync(passphrasePath,'utf8').trim(),oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64'));
const decipher=createDecipheriv('aes-256-gcm',contentKey,Buffer.from(envelope.iv,'base64'));decipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));
const plaintext=gunzipSync(Buffer.concat([decipher.update(ciphertext),decipher.final()]));
if(hash(plaintext)!==envelope.plaintextSha256)throw new Error('Plaintext hash mismatch');
const payload=JSON.parse(plaintext.toString('utf8'));
if(payload.format!==envelope.format||payload.release!==envelope.release||payload.schemaVersion!==envelope.schemaVersion||payload.schemaSha256!==envelope.schemaSha256)throw new Error('Envelope and payload metadata mismatch');
const readConsistency=payload.readConsistency??'unverified';
if(!['transaction_snapshot','unverified'].includes(readConsistency)||readConsistency!==(envelope.readConsistency??'unverified'))throw new Error('Backup read consistency metadata mismatch');
const manifestNames=payload.manifest?.tables?.map(item=>item.name)??[];
if(payload.manifest?.tableCount!==contract.tables.length||manifestNames.length!==contract.tables.length||manifestNames.some((name,index)=>name!==contract.tables[index]))throw new Error('Backup table manifest does not match this release');
for(const table of payload.manifest.tables){const rows=payload.tables[table.name];if(!Array.isArray(rows)||rows.length!==table.rows||hash(JSON.stringify(rows))!==table.sha256)throw new Error(`Manifest mismatch for ${table.name}`);}

const root=new URL('..',import.meta.url).pathname,migrations=readdirSync(join(root,'drizzle')).filter(name=>/^\d{4}_.+\.sql$/.test(name)).sort(),db=new DatabaseSync(':memory:');
for(const migration of migrations)db.exec(readFileSync(join(root,'drizzle',migration),'utf8'));
const tableNames=payload.manifest.tables.map(item=>item.name);for(const table of tableNames)if(!/^[a-z][a-z0-9_]*$/.test(table))throw new Error('Unsafe table name');
db.exec('PRAGMA foreign_keys=OFF; BEGIN');
try{
 for(const table of ACCEPTANCE_PROTECTED_TABLES)if(Number(db.prepare(`SELECT COUNT(*) count FROM ${table}`).get().count)!==0)throw new Error(`Fresh restore schema unexpectedly contains protected acceptance rows in ${table}`);
 for(const table of [...BACKUP_TABLES].reverse())if(!ACCEPTANCE_PROTECTED_TABLES.includes(table))db.exec(`DELETE FROM ${table}`);
 for(const table of tableNames){
  const available=new Set(db.prepare(`PRAGMA table_info(${table})`).all().map(item=>item.name)),rows=orderBackupRestoreRows(table,payload.tables[table]);
  for(const row of rows){const columns=Object.keys(row);for(const column of columns)if(!available.has(column))throw new Error(`Restore schema missing ${table}.${column}`);const marks=columns.map(()=>'?').join(','),sql=`INSERT INTO ${table}(${columns.join(',')}) VALUES(${marks})`,values=columns.map(column=>{const value=row[column];if(typeof value==='boolean')return value?1:0;if(value&&typeof value==='object')return JSON.stringify(value);return value??null;});db.prepare(sql).run(...values);}
 }
 db.exec('COMMIT; PRAGMA foreign_keys=ON');
}catch(error){db.exec('ROLLBACK');throw error;}
const foreignKeyViolations=db.prepare('PRAGMA foreign_key_check').all();if(foreignKeyViolations.length)throw new Error(`Foreign key validation failed: ${foreignKeyViolations.length}`);
const restored=tableNames.map(name=>({name,rows:Number(db.prepare(`SELECT COUNT(*) count FROM ${name}`).get().count)}));for(const item of restored){const expected=payload.manifest.tables.find(table=>table.name===item.name)?.rows;if(item.rows!==expected)throw new Error(`Restore count mismatch for ${item.name}`);}
const excludedCounts=Object.fromEntries(BACKUP_EXCLUDED_TABLES.map(name=>[name,Number(db.prepare(`SELECT COUNT(*) count FROM ${name}`).get().count)]));if(Object.values(excludedCounts).some(Number))throw new Error('Ephemeral authentication or lock data was restored unexpectedly');
const coverageComplete=contract.missingTables.length===0;
const receipt={status:coverageComplete?'verified':'verified_legacy_coverage',coverageComplete,missingTables:contract.missingTables,readConsistency,format:envelope.format,release:envelope.release,schemaVersion:envelope.schemaVersion,schemaSha256:envelope.schemaSha256,backupFile:basename(backupPath),backupSha256:hash(readFileSync(backupPath)),createdAt:envelope.createdAt,verifiedAt:new Date().toISOString(),publicKeySha256:envelope.publicKeySha256,plaintextSha256:envelope.plaintextSha256,tableCount:restored.length,totalRecords:restored.reduce((sum,item)=>sum+item.rows,0),tables:restored,excludedTables:excludedCounts,foreignKeyViolations:0,restoreTarget:'isolated in-memory SQLite schema'};
if(receiptPath)writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n',{mode:0o600});
process.stdout.write(JSON.stringify({status:receipt.status,coverageComplete,missingTables:contract.missingTables,readConsistency,release:receipt.release,tableCount:receipt.tableCount,totalRecords:receipt.totalRecords,foreignKeyViolations:receipt.foreignKeyViolations})+'\n');
