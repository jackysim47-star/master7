import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {claimMegaLaunch,markMegaLaunchIssued,markMegaLaunchUnknown,settleMegaWallet,recoverMegaWallet,MegaWalletError} from '../lib/megah5-wallet.ts';

// A fresh disposable loopback database, independently named and explicitly
// confirmed, is mandatory: this script must never run against a real database.
const connection=process.env.MASTER7_ISOLATED_LAUNCH_DATABASE_URL??'';
const target=new URL(connection);
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v22_launch_test'||target.search||target.hash||!target.port)throw Error('A fresh loopback-only master7_v22_launch_test database is required');
if(process.env.MASTER7_ISOLATED_LAUNCH_CONFIRM!=='master7_v22_launch_test')throw Error('Explicit isolated test database confirmation is required');

function gate(){let signal,release;return {ready:new Promise(r=>{signal=r;}),wait:new Promise(r=>{release=r;}),signal:()=>signal(),release:()=>release()};}
function timeout(p){return Promise.race([p,new Promise((_,reject)=>setTimeout(()=>reject(Error('test gate timeout')),10000))]);}

test('MegaH5 launch and settlement use one durable transaction boundary on isolated PostgreSQL',async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:6});
 const previousUrl=process.env.PORTAL_POSTGRES_URL,previousSsl=process.env.PGSSLMODE,originalFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=originalFetch;if(previousUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=previousUrl;if(previousSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=previousSsl;});
 const identity=await pool.query("SELECT current_database() AS name,COUNT(*)::int AS tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,'master7_v22_launch_test');assert.equal(identity.rows[0].tables,0,'test database must be empty');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat();
 async function seed(user,id){
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'fixture',0)",[user]);
  await pool.query("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES($1,$2,'megah5',$3,'55021','active',2000,$4,0,0)",[id,user,'player-'+user,'dep-'+id]);
  await pool.query("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES($1,'game',$2,2000,0)",[user,id]);
 }
 async function state(id){
  const s=await pool.query('SELECT status,amount_returned_minor FROM game_wallet_sessions WHERE id=$1',[id]);
  const l=await pool.query('SELECT amount_minor,currency FROM game_wallet_ledger WHERE session_id=$1',[id]);
  const r=await pool.query('SELECT amount_minor FROM wallet_reservations WHERE reference_id=$1',[id]);
  const ops=await pool.query('SELECT state,game_code FROM megah5_launch_operations WHERE wallet_session_id=$1 ORDER BY created_at,id',[id]);
  return {status:s.rows[0].status,returned:s.rows[0].amount_returned_minor==null?null:String(s.rows[0].amount_returned_minor),ledger:l.rows.map(x=>({amount:String(x.amount_minor),currency:x.currency})),reserved:r.rows.map(x=>String(x.amount_minor)),ops:ops.rows};
 }
 function context(user,withdrawGate){
  let withdrawals=0;
  return {db,user:{id:user,username:user,role:'member',approved:1},gatewayUrl:'https://master7-integration-gateway.onrender.com',gameToken:'g'.repeat(40),walletToken:'w'.repeat(40),fetchImpl:async(input,init)=>{
   const path=new URL(String(input)).pathname;
   if(path==='/platform/megah5/balance')return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:'15.50',Currency:'MYR'}});
   if(path==='/platform/megah5/withdraw'){withdrawals++;if(withdrawGate){withdrawGate.signal();await withdrawGate.wait;}return Response.json({provider:'megah5',operation:'withdraw',referenceId:JSON.parse(init.body).referenceId,result:{Status:200}});}
   throw Error('Unexpected synthetic provider route');
  },withdrawalCount:()=>withdrawals};
 }
 async function rejects409(p){await assert.rejects(p,e=>e instanceof MegaWalletError&&e.status===409);}
 await t.test('a claimed launch blocks settlement before any provider withdrawal',async()=>{
  const user='launch-first-user',id='launch-first-session';await seed(user,id);const c=context(user),claim=await claimMegaLaunch(c,id,'55021');assert.ok(claim.id);
  await rejects409(()=>settleMegaWallet(c,id));assert.equal(c.withdrawalCount(),0);
  const s=await state(id);assert.equal(s.status,'active');assert.deepEqual(s.ledger,[]);assert.deepEqual(s.reserved,['2000']);assert.deepEqual(s.ops,[{state:'launching',game_code:'55021'}]);
 });
 await t.test('a settlement already claimed blocks a concurrent launch',async()=>{
  const user='settle-first-user',id='settle-first-session';await seed(user,id);const withdraw=gate(),c=context(user,withdraw);
  const pending=settleMegaWallet(c,id);await timeout(withdraw.ready);await rejects409(()=>claimMegaLaunch(c,id,'55021'));withdraw.release();
  assert.equal((await pending).status,'settled');const s=await state(id);assert.equal(s.status,'settled');assert.deepEqual(s.ledger,[{amount:'-450',currency:'MYR'}]);assert.deepEqual(s.reserved,[]);assert.deepEqual(s.ops,[]);
 });
 await t.test('two concurrent launch claims cannot issue two provider calls',async()=>{
  const user='duplicate-user',id='duplicate-session';await seed(user,id);const c=context(user);
  const outcomes=await Promise.allSettled([claimMegaLaunch(c,id,'55021'),claimMegaLaunch(c,id,'55021')]);
  assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,1);assert.equal(outcomes.filter(x=>x.status==='rejected').length,1);
  assert.equal((await state(id)).ops.length,1);
 });
 await t.test('unknown launch remains held after application database reconnection',async()=>{
  const user='unknown-user',id='unknown-session';await seed(user,id);const c=context(user),claim=await claimMegaLaunch(c,id,'55021');
  await markMegaLaunchUnknown(c,claim.id,id);await closeRenderPool();await rejects409(()=>settleMegaWallet(c,id));await rejects409(()=>recoverMegaWallet(c,id));
  const s=await state(id);assert.equal(s.status,'active');assert.deepEqual(s.reserved,['2000']);assert.deepEqual(s.ledger,[]);assert.deepEqual(s.ops,[{state:'unknown',game_code:'55021'}]);assert.equal(c.withdrawalCount(),0);
 });
 await t.test('issued launch remains unresolved and cannot be settled automatically',async()=>{
  const user='issued-user',id='issued-session';await seed(user,id);const c=context(user),claim=await claimMegaLaunch(c,id,'55021');await markMegaLaunchIssued(c,claim.id,id);
  await rejects409(()=>settleMegaWallet(c,id));const s=await state(id);assert.equal(s.status,'active');assert.deepEqual(s.reserved,['2000']);assert.deepEqual(s.ops,[{state:'issued',game_code:'55021'}]);assert.deepEqual(s.ledger,[]);
 });
 await t.test('simultaneous launch and settlement serialize on the same member guard',async()=>{
  const user='contended-user',id='contended-session';await seed(user,id);const c=context(user),owner=await pool.connect();
  await owner.query("INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0)",[user]);
  await owner.query('BEGIN');await owner.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);
  const launching=claimMegaLaunch(c,id,'55021'),settling=settleMegaWallet(c,id);
  const both=Promise.allSettled([launching,settling]);
  try{
   let waiters=0;
   for(let attempt=0;attempt<100;attempt++){
    const result=await pool.query("SELECT COUNT(*)::int AS n FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid() AND wait_event_type='Lock' AND query LIKE '%member_wallet_guards%'");
    waiters=result.rows[0].n;if(waiters>=2)break;await new Promise(resolve=>setTimeout(resolve,25));
   }
   assert.ok(waiters>=2,'both operations must wait concurrently on the member guard');
   await owner.query('COMMIT');
  }catch(error){await owner.query('ROLLBACK');await both;throw error;}finally{owner.release();}
  const [launch,settle]=await both,s=await state(id);
  assert.equal([launch,settle].filter(x=>x.status==='fulfilled').length,1);
  if(launch.status==='fulfilled'){
   assert.equal(settle.status,'rejected');assert.equal(s.status,'active');assert.deepEqual(s.ledger,[]);assert.deepEqual(s.reserved,['2000']);assert.deepEqual(s.ops,[{state:'launching',game_code:'55021'}]);assert.equal(c.withdrawalCount(),0);
  }else{
   assert.equal(settle.status,'fulfilled');assert.equal(settle.value.status,'settled');assert.equal(s.status,'settled');assert.deepEqual(s.ledger,[{amount:'-450',currency:'MYR'}]);assert.deepEqual(s.reserved,[]);assert.deepEqual(s.ops,[]);assert.equal(c.withdrawalCount(),1);
  }
 });
 await t.test('legacy wallet without a launch operation can still settle and recover',async()=>{
  const user='legacy-user',id='legacy-session';await seed(user,id);const c=context(user);assert.equal((await recoverMegaWallet(c,id)).status,'active');
  assert.equal((await settleMegaWallet(c,id)).status,'settled');const s=await state(id);assert.equal(s.status,'settled');assert.deepEqual(s.reserved,[]);assert.deepEqual(s.ledger,[{amount:'-450',currency:'MYR'}]);assert.deepEqual(s.ops,[]);
 });
});
