import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";
import { initializePortalDatabase } from "../lib/render-migrations.mjs";
import { renderPaymentActivationOptions } from "../lib/render-payment-activation.mjs";
import { postgresPoolRuntimeOptions, registerPostgresPoolErrorHandler } from "../lib/postgres-pool-config.mjs";

const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
if (!connectionString) {
  console.error("PORTAL_POSTGRES_URL is required; refusing ephemeral storage.");
  process.exit(1);
}

const ssl = process.env.PGSSLMODE === "disable"
  ? false
  : {
      rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== "false",
      ...(process.env.PGSSL_CA ? { ca: process.env.PGSSL_CA.replaceAll("\\n", "\n") } : {}),
    };

const pool = registerPostgresPoolErrorHandler(new pg.Pool({
  connectionString,
  ssl,
  ...postgresPoolRuntimeOptions(process.env),
}));

try {
  const schema = await readFile(resolve("db/render-schema.sql"), "utf8");
  const directoryEntries = JSON.parse(await readFile(resolve("db/vendor-directory.json"), "utf8"));
  const paymentActivation = renderPaymentActivationOptions(process.env);
  const result = await initializePortalDatabase(pool, schema, directoryEntries, paymentActivation);
  console.log(`MASTER7 V17 Render staging database ready; status migration ${result.migrated ? "applied" : "already applied"}; database guards ${result.criticalDatabaseGuardCount}/9 ready; guard functions ${result.criticalDatabaseGuardFunctionCount}/5 attested; ${result.seededBrandCount} closed directory entries available.`);
} catch (error) {
  console.error("MASTER7 V17 staging database initialization failed:", error instanceof Error ? error.message : "unknown error");
  await pool.end();
  process.exit(1);
}

const vpayCheckExpiry = Date.parse("2026-11-21T23:56:00Z");
const expectedVpayGateway = "https://master7-integration-gateway.onrender.com";
if (process.env.RENDER_SERVICE_ID === "srv-dbrkn8rl550s73cnur8g" &&
    process.env.VPAY_GATEWAY_URL === expectedVpayGateway && Date.now() < vpayCheckExpiry) {
  const allowedErrors = new Set(["unauthorized", "vpay_balance_query_disabled", "vpay_invalid_balance_response",
    "vpay_balance_query_failed", "vpay_order_not_found", "vpay_query_rejected", "vpay_invalid_credentials",
    "vpay_invalid_signature"]);
  async function vpayReadOnlyRequest(path, token, payload) {
    if (typeof token !== "string" || token.length < 32 || token.length > 1024) {
      return { state: "peer_not_configured" };
    }
    try {
      const response = await fetch(`${expectedVpayGateway}${path}`, {
        method: "POST",
        redirect: "error",
        signal: AbortSignal.timeout(6000),
        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      });
      const value = await response.json().catch(() => null);
      const message = typeof value?.result?.msg === "string" ? value.result.msg : "";
      return {
        http: response.status,
        readSucceeded: response.ok && value?.provider === "vpay",
        providerCode: /^-?\d{1,6}$/.test(String(value?.result?.code)) ? Number(value.result.code) : null,
        upstreamHttp: Number.isInteger(value?.upstreamStatus) ? value.upstreamStatus : null,
        code: allowedErrors.has(value?.error) ? value.error : null,
        ipRejected: /(?:ip|address).{0,55}(?:not allowed|not in|invalid|forbidden|white.?list|allow.?list)|(?:白名单|IP.{0,15}(?:拒绝|禁止|未授权))/i.test(message),
      };
    } catch {
      return { state: "connection_failed" };
    }
  }
  try {
    const { rows } = await pool.query({
      text: "SELECT id FROM deposit_orders WHERE provider = 'vpay' AND status = 'failed' AND created_at BETWEEN $1 AND $2 ORDER BY created_at DESC LIMIT 1",
      values: [Date.parse("2026-11-21T22:31:15Z") / 1000, Date.parse("2026-11-21T22:32:04Z") / 1000],
      query_timeout: 2000,
    });
    const recentId = rows[0]?.id;
    const [balance, orderLookup] = await Promise.all([
      vpayReadOnlyRequest("/platform/vpay/balance", process.env.VPAY_BALANCE_TOKEN, {}),
      typeof recentId === "string" && /^[A-Za-z0-9_-]{1,50}$/.test(recentId)
        ? vpayReadOnlyRequest("/platform/vpay/order-query", process.env.VPAY_QUERY_TOKEN, { outTradeNo: recentId })
        : { state: "recent_reference_unavailable" },
    ]);
    console.log("MASTER7_VPAY_APPROVAL_RECHECK", JSON.stringify({ balance, orderLookup }));
  } catch {
    console.warn("MASTER7_VPAY_APPROVAL_RECHECK unavailable");
  }
}

await pool.end();
await import("../.output/server/index.mjs");

const [
  { startSchedulerLeadership },
  { startRuntimeDatabaseGuardMonitor },
  { startCatalogueSync },
  { startAccountingCloseScheduler },
  { startPaymentRecovery },
  { startWhatsAppDispatch },
] = await Promise.all([
  import("./scheduler-leader.mjs"),
  import("./runtime-database-guard-monitor.mjs"),
  import("./catalogue-sync-job.mjs"),
  import("./accounting-close-job.mjs"),
  import("./payment-recovery-job.mjs"),
  import("./whatsapp-dispatch-job.mjs"),
]);

startRuntimeDatabaseGuardMonitor({
  connectionString,
  ssl,
  intervalMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_INTERVAL_MS,
  queryTimeoutMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_QUERY_TIMEOUT_MS,
});

startSchedulerLeadership({
  connectionString,
  ssl,
  startWorkers: () => [
    startCatalogueSync(),
    startAccountingCloseScheduler(),
    startPaymentRecovery(),
    startWhatsAppDispatch(),
  ],
});
