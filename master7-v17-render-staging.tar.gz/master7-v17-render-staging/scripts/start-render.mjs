import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";
import { initializePortalDatabase } from "../lib/render-migrations.mjs";

const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
if (!connectionString) {
  console.error("PORTAL_POSTGRES_URL is required; refusing ephemeral storage.");
  process.exit(1);
}

const pool = new pg.Pool({
  connectionString,
  ssl: process.env.PGSSLMODE === "disable"
    ? false
    : {
        rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== "false",
        ...(process.env.PGSSL_CA ? { ca: process.env.PGSSL_CA.replaceAll("\\n", "\n") } : {}),
      },
  max: Number(process.env.PG_POOL_MAX ?? 5),
  connectionTimeoutMillis: 10_000,
});

try {
  const schema = await readFile(resolve("db/render-schema.sql"), "utf8");
  const directoryEntries = JSON.parse(await readFile(resolve("db/vendor-directory.json"), "utf8"));
  const oneMpayEnabled = process.env.ONE_MPAY_ORDERS_ENABLED === 'true'
    && process.env.ONE_MPAY_API_BASE_URL === 'https://api.1mpay.net'
    && /^[A-Za-z0-9_-]{6,64}$/.test(process.env.ONE_MPAY_MERCHANT ?? '')
    && (process.env.ONE_MPAY_SECRET_KEY ?? '').length >= 16
    && process.env.ONE_MPAY_CALLBACK_URL === 'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment'
    && process.env.ONE_MPAY_RETURN_URL === 'https://master7-v17-staging.onrender.com/payment/return';
  const result = await initializePortalDatabase(pool, schema, directoryEntries, { oneMpayEnabled });
  console.log(`MASTER7 V17 Render staging database ready; status migration ${result.migrated ? "applied" : "already applied"}; ${result.seededBrandCount} closed directory entries available.`);
} catch (error) {
  console.error("MASTER7 V17 staging database initialization failed:", error instanceof Error ? error.message : "unknown error");
  await pool.end();
  process.exit(1);
}

await pool.end();
await import("../.output/server/index.mjs");
