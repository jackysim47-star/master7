import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";
import { initializePortalDatabase } from "../lib/render-migrations.mjs";
import { renderPaymentActivationOptions } from "../lib/render-payment-activation.mjs";
import { postgresPoolRuntimeOptions, registerPostgresPoolErrorHandler } from "../lib/postgres-pool-config.mjs";

const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
if (!connectionString) {
  console.error("PORTAL_POSTGRES_URL is required; refusing ephemeral storage.");
  process.exit(1);
}

const ssl = process.env.PGSSLMODE === "disable"
  ? false
  : {
      rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== "false",
      ...(process.env.PGSSL_CA ? { ca: process.env.PGSSL_CA.replaceAll("\\n", "\n") } : {}),
    };

const pool = registerPostgresPoolErrorHandler(new pg.Pool({
  connectionString,
  ssl,
  ...postgresPoolRuntimeOptions(process.env),
}));

try {
  const schema = await readFile(resolve("db/render-schema.sql"), "utf8");
  const directoryEntries = JSON.parse(await readFile(resolve("db/vendor-directory.json"), "utf8"));
  const paymentActivation = renderPaymentActivationOptions(process.env);
  const result = await initializePortalDatabase(pool, schema, directoryEntries, paymentActivation);
  console.log(`MASTER7 V17 Render staging database ready; status migration ${result.migrated ? "applied" : "already applied"}; database guards ${result.criticalDatabaseGuardCount}/9 ready; guard functions ${result.criticalDatabaseGuardFunctionCount}/5 attested; ${result.seededBrandCount} closed directory entries available.`);
} catch (error) {
  console.error("MASTER7 V17 staging database initialization failed:", error instanceof Error ? error.message : "unknown error");
  await pool.end();
  process.exit(1);
}

const depositBatchExpiresAt = Date.parse("2026-11-22T03:18:00Z");
let recent1MpayRows = null;
if (process.env.RENDER_SERVICE_ID === "srv-dbrkn8rl550s73cnur8g" && Date.now() < depositBatchExpiresAt) {
  const vpayIncident = Date.parse("2026-11-22T02:18:59Z") / 1000;
  const firstCheckout = Date.parse("2026-11-21T22:30:45Z") / 1000;
  const allowedVpayReasons = new Set([
    "vpay_ip_not_allowed", "vpay_notify_url_not_allowed", "vpay_return_url_not_allowed",
    "vpay_domain_not_allowed", "vpay_allowlist_rejected", "vpay_order_permission_rejected",
    "vpay_channel_rejected", "vpay_invalid_credentials", "vpay_invalid_signature",
    "vpay_amount_rejected", "vpay_order_rejected", "vpay_payment_configuration_incomplete",
  ]);
  try {
    const [attempts, orders, gspay] = await Promise.all([
      pool.query({ text: "SELECT target FROM audit WHERE event='payment_order_diagnostic' AND created_at BETWEEN $1 AND $2 ORDER BY created_at LIMIT 16", values: [vpayIncident - 4, vpayIncident + 12], query_timeout: 2000 }),
      pool.query({
        text: `SELECT d.id, d.user_id, d.amount_minor::text, d.currency, d.provider_trade_no, d.status, d.created_at,
          d.checkout_url IS NOT NULL AS checkout_present, EXISTS (
            SELECT 1 FROM wallet_ledger AS credit JOIN wallet_ledger AS clearing ON clearing.order_id = credit.order_id
            WHERE credit.order_id = d.id AND credit.user_id = d.user_id AND clearing.user_id = d.user_id
              AND credit.currency = 'MYR' AND clearing.currency = 'MYR' AND credit.account_code = 'member'
              AND clearing.account_code = 'provider_clearing' AND credit.amount_minor = d.amount_minor
              AND clearing.amount_minor = -d.amount_minor
          ) AS paired_ledger
          FROM deposit_orders AS d WHERE d.provider = '1mpay' AND d.created_at >= $1
          ORDER BY d.created_at DESC LIMIT 3`,
        values: [firstCheckout], query_timeout: 2000,
      }),
      pool.query({ text: "SELECT COUNT(*)::integer AS count FROM deposit_orders WHERE provider = 'gspay' AND created_at >= $1", values: [firstCheckout], query_timeout: 2000 }),
    ]);
    const vpay = attempts.rows.flatMap(row => {
      let f;
      try { f = JSON.parse(row.target); } catch { return []; }
      if (f?.provider !== "vpay") return [];
      return [{ gatewayError: allowedVpayReasons.has(f.gatewayError) ? f.gatewayError : null,
        providerCode: Number.isSafeInteger(f.providerCode) ? f.providerCode : null }];
    });
    recent1MpayRows = orders.rows.filter(row => row.provider_trade_no !== null);
    const oneMpay = orders.rows.map(row => ({ atUnix: Number(row.created_at), storedStatus: row.status,
      checkoutPresent: row.checkout_present === true, pairedLedger: row.paired_ledger === true }));
    console.log("MASTER7_THREE_PAYMENT_LOCAL", JSON.stringify({ vpay, oneMpay, gspayOrders: gspay.rows[0]?.count }));
  } catch {
    console.warn("MASTER7_THREE_PAYMENT_LOCAL unavailable");
  }
}

await pool.end();
await import("../.output/server/index.mjs");

if (recent1MpayRows?.length) {
  const capturedRows = recent1MpayRows;
  void import("../lib/onempay.ts").then(async ({ readOneMpayDepositProviderEvidence }) => {
    const db = { prepare(sql) {
      if (sql !== "SELECT id,user_id,amount_minor,currency,provider_trade_no,status FROM deposit_orders WHERE provider='1mpay' AND provider_trade_no IS NOT NULL ORDER BY created_at,id LIMIT 4") {
        throw new Error("readonly_probe_scope");
      }
      return { all: async () => ({ results: capturedRows }) };
    } };
    const report = await readOneMpayDepositProviderEvidence({
      db, user: null, apiBase: process.env.ONE_MPAY_API_BASE_URL, merchant: process.env.ONE_MPAY_MERCHANT,
      secretKey: process.env.ONE_MPAY_SECRET_KEY, callbackUrl: process.env.ONE_MPAY_CALLBACK_URL,
      returnUrl: process.env.ONE_MPAY_RETURN_URL, portalOrigins: ["https://www.master7.best", "https://master7.best"],
    });
    const safeStatuses = new Set(["successful", "pending", "fail", "failed", "timeout", "unrecognized"]);
    const outcomes = new Set(["invalid_stored_binding", "provider_binding_mismatch", "provider_query_bound", "provider_query_unavailable"]);
    console.log("MASTER7_THREE_PAYMENT_PROVIDER", JSON.stringify({
      configured: report.configured === true, checked: report.providerQueriesExecuted,
      results: report.items.map((v, i) => ({ atUnix: Number(capturedRows[i]?.created_at),
        result: outcomes.has(v.outcome) ? v.outcome : null,
        supplierStatus: safeStatuses.has(v.providerStatus) ? v.providerStatus : null,
        paid: v.paymentVerified === true })),
    }));
  }).catch(() => console.warn("MASTER7_THREE_PAYMENT_PROVIDER unavailable"));
}

const [
  { startSchedulerLeadership },
  { startRuntimeDatabaseGuardMonitor },
  { startCatalogueSync },
  { startAccountingCloseScheduler },
  { startPaymentRecovery },
  { startWhatsAppDispatch },
] = await Promise.all([
  import("./scheduler-leader.mjs"),
  import("./runtime-database-guard-monitor.mjs"),
  import("./catalogue-sync-job.mjs"),
  import("./accounting-close-job.mjs"),
  import("./payment-recovery-job.mjs"),
  import("./whatsapp-dispatch-job.mjs"),
]);

startRuntimeDatabaseGuardMonitor({
  connectionString,
  ssl,
  intervalMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_INTERVAL_MS,
  queryTimeoutMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_QUERY_TIMEOUT_MS,
});

startSchedulerLeadership({
  connectionString,
  ssl,
  startWorkers: () => [
    startCatalogueSync(),
    startAccountingCloseScheduler(),
    startPaymentRecovery(),
    startWhatsAppDispatch(),
  ],
});
