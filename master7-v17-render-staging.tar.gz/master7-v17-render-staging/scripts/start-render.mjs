import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";
import { initializePortalDatabase } from "../lib/render-migrations.mjs";
import { renderPaymentActivationOptions } from "../lib/render-payment-activation.mjs";
import { postgresPoolRuntimeOptions, registerPostgresPoolErrorHandler } from "../lib/postgres-pool-config.mjs";

const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
if (!connectionString) {
  console.error("PORTAL_POSTGRES_URL is required; refusing ephemeral storage.");
  process.exit(1);
}

const ssl = process.env.PGSSLMODE === "disable"
  ? false
  : {
      rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== "false",
      ...(process.env.PGSSL_CA ? { ca: process.env.PGSSL_CA.replaceAll("\\n", "\n") } : {}),
    };

const pool = registerPostgresPoolErrorHandler(new pg.Pool({
  connectionString,
  ssl,
  ...postgresPoolRuntimeOptions(process.env),
}));

try {
  const schema = await readFile(resolve("db/render-schema.sql"), "utf8");
  const directoryEntries = JSON.parse(await readFile(resolve("db/vendor-directory.json"), "utf8"));
  const paymentActivation = renderPaymentActivationOptions(process.env);
  const result = await initializePortalDatabase(pool, schema, directoryEntries, paymentActivation);
  console.log(`MASTER7 V17 Render staging database ready; status migration ${result.migrated ? "applied" : "already applied"}; database guards ${result.criticalDatabaseGuardCount}/9 ready; guard functions ${result.criticalDatabaseGuardFunctionCount}/5 attested; ${result.seededBrandCount} closed directory entries available.`);
} catch (error) {
  console.error("MASTER7 V17 staging database initialization failed:", error instanceof Error ? error.message : "unknown error");
  await pool.end();
  process.exit(1);
}

await pool.end();
await import("../.output/server/index.mjs");

const checkSecret = process.env.MASTER7_MEGH5_WALLET_CHECK_KEY;
const checkOperator = process.env.MASTER7_MEGH5_WALLET_CHECK_OPERATOR;
const checkRun = process.env.MASTER7_MEGH5_WALLET_CHECK_RUN;
const checkExpiry = Number(process.env.MASTER7_MEGH5_WALLET_CHECK_EXPIRY);
if (process.env.RENDER_SERVICE_ID === "srv-dbl0iv7f3r2c73848ei0"
  && checkSecret && checkOperator && checkRun && checkExpiry > Date.now()
  && checkExpiry < Date.now() + 40 * 60_000) {
  delete process.env.MASTER7_MEGH5_WALLET_CHECK_KEY;
  delete process.env.MASTER7_MEGH5_WALLET_CHECK_OPERATOR;
  try {
    const { runWalletCheck } = await import("./megah5-uat-wallet-check.mjs");
    console.log("MASTER7_MEGAH5_UAT_WALLET_CHECK", JSON.stringify(await runWalletCheck(checkOperator, checkSecret, checkRun)));
  } catch {
    console.log("MASTER7_MEGAH5_UAT_WALLET_CHECK", JSON.stringify({ outcome: "check_failed" }));
  }
}

const [
  { startSchedulerLeadership },
  { startRuntimeDatabaseGuardMonitor },
  { startCatalogueSync },
  { startAccountingCloseScheduler },
  { startPaymentRecovery },
  { startWhatsAppDispatch },
] = await Promise.all([
  import("./scheduler-leader.mjs"),
  import("./runtime-database-guard-monitor.mjs"),
  import("./catalogue-sync-job.mjs"),
  import("./accounting-close-job.mjs"),
  import("./payment-recovery-job.mjs"),
  import("./whatsapp-dispatch-job.mjs"),
]);

startRuntimeDatabaseGuardMonitor({
  connectionString,
  ssl,
  intervalMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_INTERVAL_MS,
  queryTimeoutMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_QUERY_TIMEOUT_MS,
});

startSchedulerLeadership({
  connectionString,
  ssl,
  startWorkers: () => [
    startCatalogueSync(),
    startAccountingCloseScheduler(),
    startPaymentRecovery(),
    startWhatsAppDispatch(),
  ],
});
