import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";
import { initializePortalDatabase } from "../lib/render-migrations.mjs";
import { renderPaymentActivationOptions } from "../lib/render-payment-activation.mjs";
import { postgresPoolRuntimeOptions, registerPostgresPoolErrorHandler } from "../lib/postgres-pool-config.mjs";

const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
if (!connectionString) {
  console.error("PORTAL_POSTGRES_URL is required; refusing ephemeral storage.");
  process.exit(1);
}

const ssl = process.env.PGSSLMODE === "disable"
  ? false
  : {
      rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== "false",
      ...(process.env.PGSSL_CA ? { ca: process.env.PGSSL_CA.replaceAll("\\n", "\n") } : {}),
    };

const pool = registerPostgresPoolErrorHandler(new pg.Pool({
  connectionString,
  ssl,
  ...postgresPoolRuntimeOptions(process.env),
}));

try {
  const schema = await readFile(resolve("db/render-schema.sql"), "utf8");
  const directoryEntries = JSON.parse(await readFile(resolve("db/vendor-directory.json"), "utf8"));
  const paymentActivation = renderPaymentActivationOptions(process.env);
  const result = await initializePortalDatabase(pool, schema, directoryEntries, paymentActivation);
  console.log(`MASTER7 V17 Render staging database ready; status migration ${result.migrated ? "applied" : "already applied"}; database guards ${result.criticalDatabaseGuardCount}/9 ready; ${result.seededBrandCount} closed directory entries available.`);
} catch (error) {
  console.error("MASTER7 V17 staging database initialization failed:", error instanceof Error ? error.message : "unknown error");
  await pool.end();
  process.exit(1);
}

await pool.end();
await import("../.output/server/index.mjs");

const [
  { startSchedulerLeadership },
  { startCatalogueSync },
  { startAccountingCloseScheduler },
  { startPaymentRecovery },
  { startWhatsAppDispatch },
] = await Promise.all([
  import("./scheduler-leader.mjs"),
  import("./catalogue-sync-job.mjs"),
  import("./accounting-close-job.mjs"),
  import("./payment-recovery-job.mjs"),
  import("./whatsapp-dispatch-job.mjs"),
]);

startSchedulerLeadership({
  connectionString,
  ssl,
  startWorkers: () => [
    startCatalogueSync(),
    startAccountingCloseScheduler(),
    startPaymentRecovery(),
    startWhatsAppDispatch(),
  ],
});
