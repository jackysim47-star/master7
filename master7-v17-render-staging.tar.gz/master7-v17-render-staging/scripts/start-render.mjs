import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";

const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
if (!connectionString) {
  console.error("PORTAL_POSTGRES_URL is required; refusing ephemeral storage.");
  process.exit(1);
}

const pool = new pg.Pool({
  connectionString,
  ssl: process.env.PGSSLMODE === "disable" ? false : { rejectUnauthorized: true },
  max: Number(process.env.PG_POOL_MAX ?? 5),
  connectionTimeoutMillis: 10_000,
});

try {
  await pool.query("SELECT 1");
  const schema = await readFile(resolve("db/render-schema.sql"), "utf8");
  await pool.query(schema);
  console.log("MASTER7 V17 Render staging database ready; schema created without importing legacy data.");
} catch (error) {
  console.error("MASTER7 V17 staging database initialization failed:", error instanceof Error ? error.message : "unknown error");
  await pool.end();
  process.exit(1);
}

await pool.end();
await import("../.output/server/index.mjs");
