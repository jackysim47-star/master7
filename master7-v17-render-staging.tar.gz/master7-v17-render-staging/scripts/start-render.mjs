import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";
import { initializePortalDatabase } from "../lib/render-migrations.mjs";
import { renderPaymentActivationOptions } from "../lib/render-payment-activation.mjs";
import { postgresPoolRuntimeOptions, registerPostgresPoolErrorHandler } from "../lib/postgres-pool-config.mjs";

const connectionString = process.env.PORTAL_POSTGRES_URL ?? process.env.DATABASE_URL;
if (!connectionString) {
  console.error("PORTAL_POSTGRES_URL is required; refusing ephemeral storage.");
  process.exit(1);
}

const ssl = process.env.PGSSLMODE === "disable"
  ? false
  : {
      rejectUnauthorized: process.env.PGSSL_REJECT_UNAUTHORIZED !== "false",
      ...(process.env.PGSSL_CA ? { ca: process.env.PGSSL_CA.replaceAll("\\n", "\n") } : {}),
    };

const pool = registerPostgresPoolErrorHandler(new pg.Pool({
  connectionString,
  ssl,
  ...postgresPoolRuntimeOptions(process.env),
}));

try {
  const schema = await readFile(resolve("db/render-schema.sql"), "utf8");
  const directoryEntries = JSON.parse(await readFile(resolve("db/vendor-directory.json"), "utf8"));
  const paymentActivation = renderPaymentActivationOptions(process.env);
  const result = await initializePortalDatabase(pool, schema, directoryEntries, paymentActivation);
  console.log(`MASTER7 V17 Render staging database ready; status migration ${result.migrated ? "applied" : "already applied"}; database guards ${result.criticalDatabaseGuardCount}/9 ready; guard functions ${result.criticalDatabaseGuardFunctionCount}/5 attested; ${result.seededBrandCount} closed directory entries available.`);
} catch (error) {
  console.error("MASTER7 V17 staging database initialization failed:", error instanceof Error ? error.message : "unknown error");
  await pool.end();
  process.exit(1);
}

// Read the latest reported VPay attempt. Only allowlisted provider diagnostics are logged.
const diagnosticExpiry = Date.parse("2026-11-21T12:20:00Z");
if ((process.env.RENDER_SERVICE_ID === "srv-dbrkn8rl550s73cnur8g" ||
     process.env.RENDER_EXTERNAL_HOSTNAME === "master7-v17-production.onrender.com") &&
    Date.now() < diagnosticExpiry) {
  const incidentTime = Date.parse("2026-11-21T11:38:43Z") / 1000;
  try {
    const { rows } = await pool.query({
      text: "SELECT created_at, target FROM audit WHERE event = 'payment_order_diagnostic' AND created_at BETWEEN $1 AND $2 ORDER BY created_at LIMIT 8",
      values: [incidentTime - 6, incidentTime + 12],
      query_timeout: 2000,
    });
    const reasons = new Set([
      "vpay_ip_not_allowed", "vpay_notify_url_not_allowed", "vpay_return_url_not_allowed",
      "vpay_domain_not_allowed", "vpay_allowlist_rejected", "vpay_order_permission_rejected",
      "vpay_channel_rejected", "vpay_invalid_credentials", "vpay_invalid_signature",
      "vpay_amount_rejected", "vpay_order_rejected", "vpay_payment_configuration_incomplete",
    ]);
    const number = (value, min, max) =>
      typeof value === "number" && Number.isInteger(value) && value >= min && value <= max
        ? value : null;
    const records = rows.flatMap(row => {
      let facts;
      try { facts = JSON.parse(row.target); } catch { return []; }
      if (facts?.provider !== "vpay") return [];
      return [{
        atUnix: Number(row.created_at),
        gatewayError: reasons.has(facts.gatewayError) ? facts.gatewayError : null,
        gatewayHttp: number(facts.httpStatus, 100, 599),
        upstreamHttp: number(facts.upstreamStatus, 100, 599),
        providerCode: number(facts.providerCode, -999999, 999999),
      }];
    });
    console.log("VPAY_RECENT_INCIDENT", JSON.stringify(records));
  } catch {
    console.warn("VPAY_RECENT_INCIDENT unavailable");
  }
}

await pool.end();
await import("../.output/server/index.mjs");

const [
  { startSchedulerLeadership },
  { startRuntimeDatabaseGuardMonitor },
  { startCatalogueSync },
  { startAccountingCloseScheduler },
  { startPaymentRecovery },
  { startWhatsAppDispatch },
] = await Promise.all([
  import("./scheduler-leader.mjs"),
  import("./runtime-database-guard-monitor.mjs"),
  import("./catalogue-sync-job.mjs"),
  import("./accounting-close-job.mjs"),
  import("./payment-recovery-job.mjs"),
  import("./whatsapp-dispatch-job.mjs"),
]);

startRuntimeDatabaseGuardMonitor({
  connectionString,
  ssl,
  intervalMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_INTERVAL_MS,
  queryTimeoutMs: process.env.PORTAL_DATABASE_GUARD_MONITOR_QUERY_TIMEOUT_MS,
});

startSchedulerLeadership({
  connectionString,
  ssl,
  startWorkers: () => [
    startCatalogueSync(),
    startAccountingCloseScheduler(),
    startPaymentRecovery(),
    startWhatsAppDispatch(),
  ],
});
