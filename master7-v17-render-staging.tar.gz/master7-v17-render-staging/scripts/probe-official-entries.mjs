#!/usr/bin/env node
import {pathToFileURL} from 'node:url';

// This probe has no credential input and never submits an order or a callback.
export const OFFICIAL_ENTRIES=Object.freeze([
 Object.freeze({id:'customer',origin:'https://www.master7.best',required:true}),
 Object.freeze({id:'staff',origin:'https://www.master7.site',required:true}),
]);
const REDIRECTS=new Set([301,302,303,307,308]);
const PAGE_PATHS=new Set(['/','/signin','/admin','/admin/login']);
const MAX_BYTES=512_000;

async function bodyText(response){
 const reader=response.body?.getReader();if(!reader)return '';
 const chunks=[];let size=0;
 try{for(;;){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>MAX_BYTES){await reader.cancel();throw new Error('response_too_large');}chunks.push(value);}}
 finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
 return new TextDecoder().decode(bytes);
}
function safeError(error,aborted){
 if(aborted||error?.name==='AbortError')return 'request_timeout';
 if(error?.message==='response_too_large')return 'response_too_large';
 const code=error?.cause?.code;
 return ['ENOTFOUND','EAI_AGAIN','ECONNREFUSED','ETIMEDOUT','CERT_HAS_EXPIRED','ERR_TLS_CERT_ALTNAME_INVALID'].includes(code)?code:'network_or_tls_error';
}
async function inspectUrl(origin,path,{fetchImpl,timeoutMs,expectedRelease,kind}){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs),redirects=[];
 let url=new URL(path,origin);
 try{
  for(let attempt=0;attempt<4;attempt++){
   const response=await fetchImpl(url,{method:'GET',credentials:'omit',redirect:'manual',headers:{Accept:kind==='health'?'application/json':'text/html'},signal:controller.signal});
   if(REDIRECTS.has(response.status)){
    const location=response.headers.get('location');await response.body?.cancel();
    let target;try{target=new URL(location??'',url);}catch{return {verified:false,status:response.status,reason:'invalid_redirect',redirects};}
    const sameOrigin=target.origin===origin;
    redirects.push({status:response.status,sameOrigin,targetOrigin:target.origin});
    // Health must be direct. For pages, follow only a small set of same-origin routes.
    if(kind==='health'||!sameOrigin||!PAGE_PATHS.has(target.pathname)||target.username||target.password||target.search||target.hash)return {verified:false,status:response.status,reason:kind==='health'?'health_redirect':'page_forwarding_or_unexpected_redirect',redirects};
    url=target;continue;
   }
   if(response.status!==200){await response.body?.cancel();return {verified:false,status:response.status,reason:'unexpected_http_status',redirects};}
   const contentType=response.headers.get('content-type')??'';
   if(!contentType.toLowerCase().includes(kind==='health'?'application/json':'text/html')){await response.body?.cancel();return {verified:false,status:200,reason:'unexpected_content_type',redirects};}
   const text=await bodyText(response);
   if(kind==='page')return {verified:/<title>MASTER7(?:\s|\s*·)/i.test(text),status:200,reason:/<title>MASTER7(?:\s|\s*·)/i.test(text)?'master7_page_observed':'unexpected_page',redirects};
   let data;try{data=JSON.parse(text);}catch{return {verified:false,status:200,reason:'invalid_json',redirects};}
   const release=typeof data?.release==='string'&&/^17\.0\.0-[a-zA-Z0-9.-]{1,100}$/.test(data.release)?data.release:null;
   const verified=data?.status==='ok'&&data?.database==='ready'&&data?.scope==='portal-liveness'&&release===expectedRelease;
   return {verified,status:200,reason:verified?'expected_release_observed':'liveness_or_release_mismatch',release,redirects};
  }
  return {verified:false,reason:'redirect_limit',redirects};
 }catch(error){return {verified:false,reason:safeError(error,controller.signal.aborted),redirects};}
 finally{clearTimeout(timer);}
}

export async function probeOfficialEntries({fetchImpl=fetch,timeoutMs=15_000,expectedRelease}={}){
 if(typeof expectedRelease!=='string'||!/^17\.0\.0-[a-zA-Z0-9.-]{1,100}$/.test(expectedRelease))throw new Error('An exact MASTER7 release is required');
 if(!Number.isSafeInteger(timeoutMs)||timeoutMs<10||timeoutMs>60_000)throw new Error('Invalid timeout');
 const entries=await Promise.all(OFFICIAL_ENTRIES.map(async entry=>{
  const [page,liveness]=await Promise.all([
   inspectUrl(entry.origin,'/',{fetchImpl,timeoutMs,expectedRelease,kind:'page'}),
   inspectUrl(entry.origin,'/health/live',{fetchImpl,timeoutMs,expectedRelease,kind:'health'}),
  ]);
  return {...entry,verified:page.verified&&liveness.verified,page,liveness};
 }));
 return {scope:'official_entry_transport_only',readOnly:true,generatedAt:new Date().toISOString(),expectedRelease,
  networkReady:entries.filter(entry=>entry.required).every(entry=>entry.verified),entries,
  callbackDeliveryVerified:false,realPaymentVerified:false,walletCreditVerified:false,productionReady:false,
  limitations:['No callback POST or payment is submitted.','TLS is verified by the execution environment trust chain; independent origin-certificate verification is separate.','Entry transport is not real-money acceptance.']};
}

export async function main(args=process.argv.slice(2),env=process.env){
 try{
  if(args.length)throw new Error('No URL arguments are accepted; only fixed official origins are probed');
  const result=await probeOfficialEntries({expectedRelease:env.MASTER7_EXPECTED_RELEASE,timeoutMs:env.PROBE_TIMEOUT_MS===undefined?15_000:Number(env.PROBE_TIMEOUT_MS)});
  process.stdout.write(JSON.stringify(result)+'\n');return result.networkReady?0:1;
 }catch(error){process.stdout.write(JSON.stringify({networkReady:false,readOnly:true,error:error.message})+'\n');return 1;}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)process.exitCode=await main();
