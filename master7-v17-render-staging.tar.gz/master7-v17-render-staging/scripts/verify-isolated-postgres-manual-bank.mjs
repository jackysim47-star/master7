import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {mkdtempSync,writeFileSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {generateKeyPairSync,createPublicKey,createHash,randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import {createEncryptedPortalBackup,BACKUP_TABLES} from '../lib/encrypted-backup.ts';
import pg from 'pg';
import {initializePortalDatabase,MANUAL_BANK_FUNDS_MIGRATION} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {manualBankPost,manualBankReadiness} from '../lib/manual-bank.ts';
import {manualBankPayoutPost} from '../lib/manual-bank-payouts.ts';
import {approveWithdrawal,submitWithdrawal,listAdminWithdrawals,withdrawalWalletState} from '../lib/withdrawals.ts';
import {walletGuardStatements,walletGuardedReservation} from '../lib/wallet-guard.ts';

const connection=process.env.MASTER7_ISOLATED_BANK_DATABASE_URL??'';let target;try{target=new URL(connection);}catch{throw Error('A fresh loopback-only manual bank database is required');}
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v130_bank_test'||target.search||target.hash||!target.port||process.env.MASTER7_ISOLATED_BANK_CONFIRM!=='master7_v130_bank_test')throw Error('A fresh loopback-only manual bank database is required');
const image='data:image/png;base64,'+Buffer.from([137,80,78,71,13,10,26,10,...new Array(40).fill(1)]).toString('base64');

test('manual company bank funds preserve evidence on isolated PostgreSQL',{timeout:60000},async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:8}),previousUrl=process.env.PORTAL_POSTGRES_URL,previousSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(previousUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=previousUrl;if(previousSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=previousSsl;});
 const identity=(await pool.query("SELECT current_database() name,(SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public')::int tables")).rows[0];assert.equal(identity.name,'master7_v130_bank_test');assert.equal(identity.tables,0,'Refuse a nonempty database');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);await initializePortalDatabase(pool,schema,directory);
 assert.equal((await pool.query('SELECT COUNT(*)::int n FROM portal_schema_migrations WHERE version=$1',[MANUAL_BANK_FUNDS_MIGRATION])).rows[0].n,1);
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};const db=new RenderD1Compat(),key='synthetic-bank-data-key-'+ 'x'.repeat(40);
 const user=(id,role)=>({id,username:id,role,approved:1});
 const owner=user('owner','owner'),staff=user('staff','staff'),alice=user('alice','member'),bob=user('bob','member');
 const ctx=who=>({db,user:who,newDepositsEnabled:'true',newPayoutsEnabled:'true',dataKey:key});
 const post=(path,data,who=owner)=>manualBankPost(path,data,ctx(who));
 const json=async response=>({status:response.status,data:await response.json()});
 async function reset(){
  // Keep the immutable provider/production acceptance history created by
  // initialization. Only test-owned manual-bank state is reset between cases.
  await pool.query(`BEGIN;
   DELETE FROM wallet_ledger;
   DELETE FROM wallet_reservations;
   DELETE FROM manual_bank_transactions;
   DELETE FROM manual_deposit_requests;
   DELETE FROM provider_payouts;
   DELETE FROM withdrawal_requests;
   DELETE FROM deposit_orders;
   DELETE FROM company_bank_accounts;
   DELETE FROM manual_compliance_reviews WHERE user_id IN ('alice','bob');
   DELETE FROM audit WHERE user_id IN ('owner','staff','alice','bob');
   DELETE FROM settings WHERE id LIKE 'manual_bank:%';
   COMMIT;`);
  for(const u of [owner,staff,alice,bob])await db.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,1,'fixture',0) ON CONFLICT(id) DO UPDATE SET username=excluded.username,role=excluded.role,approved=1,csrf='fixture'").bind(u.id,u.username,u.role).run();
  await pool.query("INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('alice','passed','passed',1,'a',0,0),('bob','passed','passed',1,'b',0,0)");
  const result=await json(await post('/api/admin/manual-bank/account',{bankName:'Synthetic Bank',accountName:'Synthetic Company',accountNumber:'1234567890',enabled:true,imageData:image}));assert.equal(result.status,200);bankId=result.data.id;assert.equal((await post('/api/admin/manual-bank/settings',{mode:'qa',qaMemberIds:['alice','bob']})).status,200);
 }
 let bankId;
 const evidence=(reference='PG-BANK-REF',amount='50.00')=>({bankAccountId:bankId,bankReference:reference,bankAmount:amount,currency:'MYR',bankOccurredAt:Math.floor(Date.now()/1000)-10,proofData:image,bankConfirmed:true});
 async function create(who=alice){const r=await json(await post('/api/manual-bank/deposits',{bankId,amount:'50.00',receiptData:image,requestKey:crypto.randomUUID()},who));assert.equal(r.status,201,JSON.stringify(r));return r.data.id;}
 const review=(id,reference='PG-BANK-REF',who=staff)=>post('/api/admin/manual-bank/review',{id,action:'approve',...evidence(reference)},who);
 await t.test('concurrent staff approvals post only one balanced journal',async()=>{
  await reset();const id=await create(),results=await Promise.all([review(id),review(id,'PG-BANK-OTHER',owner)]);assert.deepEqual(results.map(x=>x.status).sort(),[200,409]);assert.equal((await pool.query('SELECT COUNT(*)::int n,SUM(amount_minor)::text net FROM wallet_ledger WHERE order_id=$1',[id])).rows[0].n,2);assert.equal((await withdrawalWalletState(db,'alice')).availableMinor,'5000');assert.equal((await pool.query('SELECT COUNT(*)::int n FROM manual_bank_transactions')).rows[0].n,1);
 });
 await t.test('simultaneous reuse across members cannot credit both orders',async()=>{
  await reset();const a=await create(),b=await create(bob);const results=await Promise.all([review(a),review(b,'pg bank ref')]);assert.deepEqual(results.map(x=>x.status).sort(),[200,409]);assert.equal((await pool.query("SELECT COUNT(*)::int n FROM deposit_orders WHERE status='credited'")).rows[0].n,1);assert.equal((await pool.query("SELECT COUNT(*)::int n FROM deposit_orders WHERE status='review'")).rows[0].n,1);assert.equal((await pool.query('SELECT COUNT(*)::int n FROM wallet_ledger')).rows[0].n,2);
 });
 await t.test('bank replacement and an old-account deposit remain independently traceable',async()=>{
  await reset();const id=await create(),old=bankId;const replaced=await json(await post('/api/admin/manual-bank/account',{id:old,bankName:'Synthetic Bank',accountName:'Synthetic Company',accountNumber:'9999999999',enabled:true}));assert.equal(replaced.status,200);assert.notEqual(replaced.data.id,old);assert.equal((await review(id)).status,200);assert.equal((await pool.query('SELECT account_number FROM company_bank_accounts WHERE id=$1',[old])).rows[0].account_number,'1234567890');assert.equal((await pool.query('SELECT bank_account_id FROM manual_deposit_requests WHERE deposit_order_id=$1',[id])).rows[0].bank_account_id,old);
 });
 await t.test('manual payout confirmation races debit once and keeps balance projections consistent',async()=>{
  await reset();const depositId=await create();assert.equal((await review(depositId)).status,200);
  const payouts={manual_bank:{enabled:true,reason:'Synthetic bank',submit:async()=>{throw Error('Manual approval must never transfer externally');}}},withdrawCtx=who=>({...ctx(who),payouts});
  const made=await json(await submitWithdrawal({providerId:'manual_bank',bankCode:'maybank',accountHolder:'Alice Example',accountNumber:'223456789012',amount:'20.00',requestKey:crypto.randomUUID()},withdrawCtx(alice)));assert.equal(made.status,201,JSON.stringify(made));const id=made.data.withdrawal.id;
  const list=await json(await listAdminWithdrawals(withdrawCtx(owner))),item=list.data.items.find(x=>x.id===id);assert.equal((await approveWithdrawal({id,approvalFingerprint:item.approvalFingerprint,ownerNote:'Isolated synthetic QA'},withdrawCtx(owner))).status,202);
   const payoutId=(await pool.query('SELECT id FROM provider_payouts WHERE withdrawal_id=$1',[id])).rows[0].id;
   await pool.query("INSERT INTO audit(id,user_id,event,target,created_at) VALUES($1,'owner','unrelated_event','unrelated_target',0),($2,'owner','unrelated_event','unrelated_target',0)",[`manual_bank_payout_started_${payoutId}`,`manual_bank_payout_paid_${payoutId}`]);
   const start=await manualBankPayoutPost('/api/admin/manual-bank/payout/start',{id,bankAccountId:bankId},ctx(owner));assert.equal(start.status,202,JSON.stringify(await start.json()));
  const body={id,...evidence('PG-PAYOUT-REF','20.00')},results=await Promise.all([manualBankPayoutPost('/api/admin/manual-bank/payout/confirm',body,ctx(owner)),manualBankPayoutPost('/api/admin/manual-bank/payout/confirm',body,ctx(owner))]);assert.deepEqual(results.map(x=>x.status),[200,200]);
   assert.equal((await pool.query("SELECT COUNT(*)::int n FROM manual_bank_transactions WHERE direction='withdrawal'")).rows[0].n,1);assert.equal((await pool.query("SELECT COUNT(*)::int n FROM audit a JOIN manual_bank_transactions b ON b.id=a.target WHERE b.payout_id=$1 AND a.event='manual_bank_payout_paid' AND a.user_id=b.recorded_by AND a.created_at=b.recorded_at",[payoutId])).rows[0].n,1);assert.equal((await pool.query('SELECT COUNT(*)::int n FROM wallet_reservations')).rows[0].n,0);assert.equal((await withdrawalWalletState(db,'alice')).availableMinor,'3000');
  const accepted=await post('/api/admin/manual-bank/acceptance',{depositId,withdrawalId:id,bankConfirmed:true});assert.equal(accepted.status,200,JSON.stringify(await accepted.json()));assert.equal(await manualBankReadiness(db),true);
  await db.batch([...walletGuardStatements(db,'alice'),walletGuardedReservation(db,{userId:'alice',kind:'withdrawal',referenceId:'synthetic-next',amountMinor:'100',createdAt:0})]);assert.equal((await pool.query("SELECT COUNT(*)::int n FROM wallet_reservations WHERE reference_id='synthetic-next'")).rows[0].n,1);
 });
 await t.test('bank evidence and account versions restore in isolated PostgreSQL then roll back',async()=>{
  await pool.query("INSERT INTO company_bank_accounts(id,bank_name,account_name,account_number,enabled,position,updated_by,updated_at,supersedes_id) VALUES('0','Synthetic Bank','Synthetic Company','9999999999',1,0,'owner',0,$1)",[bankId]);
  await pool.query("UPDATE company_bank_accounts SET enabled=0 WHERE id=$1",[bankId]);
  const dir=mkdtempSync(join(tmpdir(),'master7-v130-bank-restore-')),passphrase=randomBytes(24).toString('hex'),{publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem',cipher:'aes-256-cbc',passphrase}}),fingerprint=createHash('sha256').update(createPublicKey(publicKey).export({type:'spki',format:'der'})).digest('hex');
  try{
   const {envelope}=await createEncryptedPortalBackup(db,'synthetic-manual-bank-130',{publicKey,publicKeySha256:fingerprint});
   assert.equal(envelope.readConsistency,'transaction_snapshot');assert.equal(envelope.manifest.tables.find(x=>x.name==='manual_bank_transactions').rows,2);
   for(const [name,value] of [['backup.json',JSON.stringify(envelope)],['private.pem',privateKey],['passphrase',passphrase]])writeFileSync(join(dir,name),value,{mode:0o600});
   await pool.query('CREATE DATABASE master7_v130_bank_restore');
   const restoreUrl=new URL(connection);restoreUrl.pathname='/master7_v130_bank_restore';
   const script=fileURLToPath(new URL('./postgres-restore-dry-run.mjs',import.meta.url));let output='';
   const status=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,[script,join(dir,'backup.json'),join(dir,'private.pem'),join(dir,'passphrase'),join(dir,'receipt.json'),'--confirm-isolated'],{env:{...process.env,MASTER7_RESTORE_DATABASE_URL:restoreUrl.href,PGSSLMODE:'disable'}});child.stdout.on('data',x=>output+=x);child.stderr.on('data',x=>output+=x);child.on('error',reject);child.on('exit',resolve);});
   assert.equal(status,0,output);const receipt=JSON.parse(readFileSync(join(dir,'receipt.json'),'utf8'));assert.equal(receipt.coverageComplete,true);assert.equal(receipt.persistentWrites,false);assert.equal(receipt.foreignKeyViolations,0);assert.equal(receipt.tableCount,BACKUP_TABLES.length);assert.equal(receipt.tables.find(x=>x.name==='manual_bank_transactions').rows,2);
   const isolated=new pg.Client({connectionString:restoreUrl.href,ssl:false});await isolated.connect();try{assert.equal((await isolated.query("SELECT COUNT(*)::int n FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")).rows[0].n,0);}finally{await isolated.end();}
  }finally{rmSync(dir,{recursive:true,force:true});}
 });
 assert.equal((await pool.query("SELECT COUNT(*)::int n FROM provider_payout_controls WHERE provider_id<>'manual_bank' AND submission_enabled<>0")).rows[0].n,0);
});
