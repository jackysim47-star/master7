import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {manualBankPost} from '../lib/manual-bank.ts';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

// Never initialize anything except an empty, explicitly named local database.
const name='master7_manual_bank_guard_test';
const target=new URL(process.env.MASTER7_ISOLATED_MANUAL_BANK_DATABASE_URL??'');
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!==`/${name}`||target.search||target.hash||!target.port)throw Error('An isolated loopback manual-bank test database is required');
if(process.env.MASTER7_ISOLATED_MANUAL_BANK_CONFIRM!==name)throw Error('Explicit isolated manual-bank confirmation is required');
const gate=()=>{let signal,release;return {ready:new Promise(resolve=>{signal=resolve;}),wait:new Promise(resolve=>{release=resolve;}),signal:()=>signal(),release:()=>release()};};

test('manual-bank review protects ledger and races in isolated PostgreSQL',async t=>{
 const connection=target.toString(),pool=new pg.Pool({connectionString:connection,ssl:false,max:8});
 const oldUrl=process.env.PORTAL_POSTGRES_URL,oldSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(oldUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=oldUrl;if(oldSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=oldSsl;});
 const identity=await pool.query("SELECT current_database() name,COUNT(*)::int tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,name);assert.equal(identity.rows[0].tables,0,'test database must be empty');
 await initializePortalDatabase(pool,await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8')));
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat();
 const staff1={id:'staff1',username:'staff1',role:'staff',approved:1},staff2={id:'staff2',username:'staff2',role:'staff',approved:1};
 await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('staff1','staff1','staff',1,'fixture',0),('staff2','staff2','staff',1,'fixture',0)");
 await pool.query("INSERT INTO company_bank_accounts(id,bank_name,account_name,account_number,enabled,position,updated_by,updated_at) VALUES('bank','Fixture','Fixture','1234567890',1,0,'staff1',0)");
 async function seed(id,user){
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'fixture',0)",[user]);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES($1,$2,$3,'fixture','manual_bank',2000,'MYR','bank','pending',0,0)",[id,user,'request-'+id]);
  await pool.query("INSERT INTO manual_deposit_requests(deposit_order_id,bank_account_id,receipt_data,created_at,updated_at) VALUES($1,'bank','data:image/png;base64,fixture',0,0)",[id]);
 }
 async function state(id){
  const order=(await pool.query('SELECT status,amount_minor FROM deposit_orders WHERE id=$1',[id])).rows[0];
  const request=(await pool.query('SELECT reviewed_by FROM manual_deposit_requests WHERE deposit_order_id=$1',[id])).rows[0];
  const entries=(await pool.query('SELECT account_code,amount_minor,user_id FROM wallet_ledger WHERE order_id=$1 ORDER BY account_code',[id])).rows;
  const events=(await pool.query('SELECT event,user_id FROM audit WHERE target=$1 ORDER BY event',[id])).rows;
  return {order,request,entries,events};
 }
 const review=(id,user,dbOverride=db,action='approve')=>manualBankPost('/api/admin/manual-bank/review',{id,action},{db:dbOverride,user});
 const gatedDb=control=>({prepare:db.prepare.bind(db),async batch(statements){control.signal();await control.wait;return db.batch(statements);}});
 const announcedDb=control=>({prepare:db.prepare.bind(db),batch(statements){control.signal();return db.batch(statements);}});
 await t.test('two reviewers approving the same order create one complete journal',{timeout:15000},async sub=>{
  const id='concurrent-review',user='concurrent-member';await seed(id,user);
  const a=gate(),b=gate();sub.after(()=>{a.release();b.release();});
  const first=review(id,staff1,gatedDb(a)),second=review(id,staff2,gatedDb(b));
  await Promise.all([a.ready,b.ready]);a.release();b.release();
  const responses=await Promise.all([first,second]);assert.deepEqual(responses.map(r=>r.status).sort(),[200,409]);
  const result=await state(id);assert.equal(result.order.status,'credited');assert.ok(['staff1','staff2'].includes(result.request.reviewed_by));
  assert.deepEqual(result.entries,[{account_code:'member',amount_minor:'2000',user_id:user},{account_code:'provider_clearing',amount_minor:'-2000',user_id:user}]);
  assert.deepEqual(result.events,[{event:'manual_bank_deposit_approved',user_id:result.request.reviewed_by}]);
 });
 await t.test('a ledger appearing while review waits is preserved and flagged',{timeout:15000},async sub=>{
  const id='existing-ledger',user='ledger-member';await seed(id,user);
  const c=gate(),client=await pool.connect();let finished=false;
  sub.after(async()=>{c.release();if(!finished)await client.query('ROLLBACK');client.release();});
  await client.query('BEGIN');await client.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);await client.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);
  const pending=review(id,staff1,announcedDb(c));await c.ready;
  await client.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('partial-ledger',$1,$2,'member',1999,'MYR',0)",[id,user]);
  await client.query('COMMIT');finished=true;const response=await pending;assert.equal(response.status,409);
  const result=await state(id);assert.equal(result.order.status,'review');assert.equal(result.request.reviewed_by,'staff1');
  assert.deepEqual(result.entries,[{account_code:'member',amount_minor:'1999',user_id:user}]);assert.deepEqual(result.events,[{event:'manual_bank_deposit_review',user_id:'staff1'}]);
  const wallet=await withdrawalWalletState(db,user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 });
 await t.test('an order changed while review waits receives no credit',{timeout:15000},async sub=>{
  const id='changed-order',user='changed-member';await seed(id,user);
  const c=gate(),client=await pool.connect();let finished=false;
  sub.after(async()=>{c.release();if(!finished)await client.query('ROLLBACK');client.release();});
  await client.query('BEGIN');await client.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);await client.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);
  const pending=review(id,staff1,announcedDb(c));await c.ready;
  await client.query('UPDATE deposit_orders SET amount_minor=2100 WHERE id=$1',[id]);await client.query('COMMIT');finished=true;
  const response=await pending;assert.equal(response.status,409);
  assert.deepEqual(await state(id),{order:{status:'pending',amount_minor:'2100'},request:{reviewed_by:null},entries:[],events:[]});
 });
 await t.test('audit insertion failure rolls back the complete approval',{timeout:15000},async()=>{
  const id='audit-failure',user='audit-member';await seed(id,user);
  await pool.query("CREATE FUNCTION manual_bank_test_reject_audit() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.target='audit-failure' THEN RAISE EXCEPTION 'synthetic audit failure'; END IF; RETURN NEW; END $$");
  await pool.query('CREATE TRIGGER manual_bank_test_reject_audit BEFORE INSERT ON audit FOR EACH ROW EXECUTE FUNCTION manual_bank_test_reject_audit()');
  await assert.rejects(review(id,staff1),/synthetic audit failure/);
  assert.deepEqual(await state(id),{order:{status:'pending',amount_minor:'2000'},request:{reviewed_by:null},entries:[],events:[]});
 });
});
