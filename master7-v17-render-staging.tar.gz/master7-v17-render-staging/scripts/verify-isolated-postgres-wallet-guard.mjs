import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {encryptWithdrawalValue} from '../lib/withdrawal-secrets.ts';
import {submitWithdrawal,withdrawalWalletState} from '../lib/withdrawals.ts';
import {handleVPayPayoutCallback} from '../lib/vpay-payout.ts';
import {prepareMegaWallet,recoverMegaWallet} from '../lib/megah5-wallet.ts';
import {handleVPay} from '../lib/vpay.ts';
import {gspayPlayerUsername,gspayResultSignature,recoverGSPayDeposits} from '../lib/gspay.ts';
import {megaCapabilityFixture} from '../tests/fixtures/megah5-capability.mjs';

// This script must never connect to a production or non-empty database.
const connection=process.env.MASTER7_ISOLATED_GUARD_TEST_DATABASE_URL??'';
const target=new URL(connection);
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v19_guard_test'||target.search||target.hash||!target.port)throw Error('A fresh loopback-only master7_v19_guard_test database is required');
if(process.env.MASTER7_ISOLATED_GUARD_POSTGRES_CONFIRM!=='master7_v19_guard_test')throw Error('Explicit isolated test database confirmation is required');
const dataKey='synthetic-withdrawal-key-'.padEnd(48,'w');
function gate(){let signal,release,timer;const ready=new Promise((resolve,reject)=>{timer=setTimeout(()=>reject(Error('Guard concurrency checkpoint timed out')),10000);signal=()=>{clearTimeout(timer);resolve();};});const wait=new Promise(resolve=>{release=resolve;setTimeout(resolve,15000).unref();});return {ready,wait,signal:()=>signal(),release:()=>release()};}

// Pause an actual D1 batch after its PostgreSQL guard UPDATE obtains the row
// lock, or signal just before another transaction tries to obtain that lock.
function instrumentDb(db,{afterGuard,beforeGuard,failReservation,reservationBatch,revisionProbe}={}){
 let reservationActive=false;
 return {prepare(sql){
  const source=db.prepare(sql),bind=source.bind.bind(source);
  source.bind=(...args)=>{
   const statement=bind(...args),execute=statement.execute.bind(statement);
   statement.__guardTestSql=sql;
   statement.execute=async client=>{
    const isGuard=/^\s*UPDATE\s+member_wallet_guards\b/i.test(sql)&&(!reservationBatch||reservationActive);
    const entersGuard=/^\s*INSERT\s+INTO\s+member_wallet_guards\b/i.test(sql)&&(!reservationBatch||reservationActive);
    if(entersGuard&&beforeGuard)beforeGuard.signal();
    if(failReservation&&/\bINSERT\s+INTO\s+wallet_reservations\b/i.test(sql))throw Error('synthetic transaction failure');
    const result=await execute(client);
    if(isGuard&&revisionProbe){const row=await client.query('SELECT revision FROM member_wallet_guards WHERE user_id=$1',[revisionProbe.user]);revisionProbe.during=BigInt(row.rows[0].revision);}
    if(isGuard&&afterGuard){afterGuard.signal();await afterGuard.wait;}
    return result;
   };
   return statement;
  };
  return source;
 },batch:async items=>{reservationActive=items.some(item=>/\bINSERT\s+INTO\s+wallet_reservations\b/i.test(item.__guardTestSql??''));try{return await db.batch(items);}finally{reservationActive=false;}}};
}

test('account guard serializes risk changes and wallet spending on isolated PostgreSQL',{timeout:60000},async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:10});
 const previousUrl=process.env.PORTAL_POSTGRES_URL,previousSsl=process.env.PGSSLMODE,originalFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=originalFetch;if(previousUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=previousUrl;if(previousSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=previousSsl;});
 const identity=await pool.query("SELECT current_database() AS name,COUNT(*)::int AS tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,'master7_v19_guard_test');assert.equal(identity.rows[0].tables,0,'test database must be empty');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat();
 async function seed(label){
  const user=`u-${label}`,withdrawal=`old-withdraw-${label}`,payout=`P7${label.replaceAll('-','')}12345678901234567890`,request=`old-request-${label}`;
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'test',0)",[user]);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES($1,$2,$3,'fixture','vpay',10000,'MYR','bank','credited',0,0)",[`deposit-${label}`,user,`fund-${label}`]);
  await pool.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES($1,$3,$4,'member',10000,'MYR',0),($2,$3,$4,'provider_clearing',-10000,'MYR',0)",[`member-${label}`,`clear-${label}`,`deposit-${label}`,user]);
  await pool.query("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES($1,$2,$3,'vpay','VPay','maybank','Maybank',$4,$5,'9012',2000,'MYR','paid','',0,0)",[withdrawal,user,request,encryptWithdrawalValue('Synthetic User',dataKey),encryptWithdrawalValue('123456789012',dataKey)]);
  const account=createHash('sha256').update('123456789012').digest('hex'),fingerprint=createHash('sha256').update(JSON.stringify({provider:'vpay',userId:user,amount:'2000',bank:'maybank',account})).digest('hex');
  await pool.query("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,provider_reference,created_at,updated_at) VALUES($1,$2,'vpay',$3,$4,2000,'MYR','succeeded','accepted',$1,0,0)",[payout,withdrawal,request,fingerprint]);
  await pool.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);
  return {user,withdrawal,payout,deposit:`deposit-${label}`,trade:`trade-${label}`};
 }
 function input(label){return {providerId:'vpay',bankCode:'maybank',accountHolder:'Synthetic User',accountNumber:'123456789012',amount:'20.00',requestKey:`guard-request-${label}-001`};}
 function context(f,view,onSubmit){return {db:view,user:{id:f.user,username:f.user,role:'member',approved:1},dataKey,payouts:{vpay:{enabled:true,reason:'fixture',submit:onSubmit}}};}
 function failureCallback(f,view){
  const callbackToken='c'.repeat(40),c={db:view,gatewayUrl:'https://master7-integration-gateway.onrender.com',payoutToken:'p'.repeat(40),callbackToken,vpayTraderId:'123',withdrawalDataKey:dataKey,fetchImpl:async()=>Response.json({provider:'vpay',result:{code:0,data:{out_money_id:f.payout,state:'2',amount:'20.00'}}})};
  return handleVPayPayoutCallback(new Request('https://portal.example.test/api/payment-callbacks/vpay/withdrawal',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({trader_id:'123',out_money_id:f.payout,state:'2',amount:'20.00'})}),c);
 }
 async function seedSecondCredit(f,label){
  await pool.query('UPDATE deposit_orders SET provider_trade_no=$2 WHERE id=$1',[f.deposit,f.trade]);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES($1,$2,$3,'fixture','manual_bank',3000,'MYR','bank','credited',0,0)",[`second-deposit-${label}`,f.user,`second-fund-${label}`]);
  await pool.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES($1,$3,$4,'member',3000,'MYR',0),($2,$3,$4,'provider_clearing',-3000,'MYR',0)",[`second-member-${label}`,`second-clear-${label}`,`second-deposit-${label}`,f.user]);
 }
 function depositReviewCallback(f,view){
  const callbackToken='d'.repeat(40),c={db:view,user:null,gatewayUrl:'https://master7-integration-gateway.onrender.com',orderToken:'o'.repeat(40),queryToken:'q'.repeat(40),callbackToken,mode:'production',vpayTraderId:'123',returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async()=>Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:f.deposit,trade_no:f.trade,amount:'100.00',currency:'MYR',state:'4',trader_id:'123'}}})};
  return handleVPay(new Request('https://portal.example.test/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({trader_id:'123',out_trade_no:f.deposit,trade_no:f.trade,state:'4',amount:'100.00'})}),c);
 }
 function gameContext(f,view,onDeposit){return {db:view,user:{id:f.user,username:f.user,role:'member',approved:1},gatewayUrl:'https://master7-integration-gateway.onrender.com',gameToken:'g'.repeat(40),walletToken:'w'.repeat(40),newGameLaunchesEnabled:'true',fetchImpl:async (input,init)=>{const path=new URL(String(input)).pathname;if(path==='/readiness')return Response.json(megaCapabilityFixture());if(path==='/platform/megah5/balance')return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:'0.00',Currency:'MYR'}});if(path==='/platform/megah5/deposit'){onDeposit();return Response.json({provider:'megah5',operation:'deposit',referenceId:JSON.parse(init.body).referenceId,result:{Status:200}});}throw Error('Unexpected synthetic game route');}};}
 async function counts(f){const result=await pool.query("SELECT (SELECT COUNT(*)::int FROM withdrawal_requests WHERE user_id=$1 AND status<>'paid') withdrawals,(SELECT COUNT(*)::int FROM wallet_reservations WHERE user_id=$1) reservations",[f.user]);return result.rows[0];}
 async function seedGspayHistory(f,label){
  const order=`G7${label.replaceAll('-','')}1234567890`,payment=label==='withdrawal'?'87654321':'87654322';
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES($1,$2,$3,'fixture','gspay',1200,'MYR','payment','unknown',$4,0,0)",[order,f.user,`gs-history-${label}`,payment]);
  await pool.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES($1,$2,$3,'member',1200,'MYR',0)",[`gs-member-${label}`,order,f.user]);
  return {order,payment};
 }
 function gspayMismatch(f,history,view){
  const authKey='a'.repeat(32),secretKey='b'.repeat(32);
  return recoverGSPayDeposits({db:view,user:null,apiBase:'https://api.thegspay.com',authKey,secretKey,returnUrl:'https://master7-v17-staging.onrender.com/payment/return',recoveryEnabled:'true',fetchImpl:async input=>{
   const url=new URL(String(input));assert.equal(url.searchParams.get('transaction_id'),history.order);
   return Response.json({code:200,data:JSON.stringify([{payment_id:history.payment,transaction_id:history.order,player_username:gspayPlayerUsername(f.user),amount:'12.00',currency:'USDT',completed:true,success:true,signature:gspayResultSignature(history.payment,'12.00',history.order,secretKey)}])});
  }});
 }
 await t.test('risk commits first: no new withdrawal and no provider request',async()=>{
  const f=await seed('risk-first'),hold=gate(),attempt=gate();let calls=0;
  const risk=failureCallback(f,instrumentDb(db,{afterGuard:hold}));
  await hold.ready;
  const spend=submitWithdrawal(input('risk-first'),context(f,instrumentDb(db,{beforeGuard:attempt}),async()=>{calls++;return {status:'processing'};}));
  await attempt.ready;hold.release();await risk;const response=await spend;
  assert.ok(response.status>=400);assert.equal(calls,0);assert.deepEqual(await counts(f),{withdrawals:0,reservations:0});
  const wallet=await withdrawalWalletState(db,f.user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 });
 await t.test('spend commits first: new withdrawal remains recoverable after later risk',async()=>{
  const f=await seed('spend-first'),hold=gate(),attempt=gate();let calls=0;
  const spend=submitWithdrawal(input('spend-first'),context(f,instrumentDb(db,{afterGuard:hold,reservationBatch:true}),async()=>{calls++;return {status:'processing'};}));
  await hold.ready;const risk=failureCallback(f,instrumentDb(db,{beforeGuard:attempt}));
  await attempt.ready;hold.release();const response=await spend;await risk;
  assert.ok(response.status<400);assert.equal(calls,1);assert.deepEqual(await counts(f),{withdrawals:1,reservations:1});
  const wallet=await withdrawalWalletState(db,f.user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 });
 await t.test('risk commits first: game entry cannot transfer member funds',async()=>{
  const f=await seed('game-risk-first'),hold=gate(),attempt=gate();let calls=0;
  const risk=failureCallback(f,instrumentDb(db,{afterGuard:hold}));await hold.ready;
  const start=prepareMegaWallet(gameContext(f,instrumentDb(db,{beforeGuard:attempt}),()=>{calls++;}),'55021').then(value=>({value}),error=>({error}));
  await attempt.ready;hold.release();await risk;const outcome=await start;
  assert.ok(outcome.error);assert.equal(calls,0);assert.deepEqual(await counts(f),{withdrawals:0,reservations:0});
  const sessions=await pool.query('SELECT COUNT(*)::int AS n FROM game_wallet_sessions WHERE user_id=$1',[f.user]);assert.equal(sessions.rows[0].n,0);
 });
 await t.test('game claim commits first: later risk retains existing session for recovery',async()=>{
  const f=await seed('game-spend-first'),hold=gate(),attempt=gate();let calls=0;
  const start=prepareMegaWallet(gameContext(f,instrumentDb(db,{afterGuard:hold,reservationBatch:true}),()=>{calls++;}),'55021');await hold.ready;
  const risk=failureCallback(f,instrumentDb(db,{beforeGuard:attempt}));await attempt.ready;hold.release();
  const result=await start;await risk;assert.equal(calls,1);assert.equal(result.amountOutMinor,'8000');
  assert.deepEqual(await counts(f),{withdrawals:0,reservations:1});const wallet=await withdrawalWalletState(db,f.user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 });
 await t.test('reviewed credited deposit blocks new withdrawal and game despite another valid credit',async()=>{
  const f=await seed('credit-review');await seedSecondCredit(f,'credit-review');
  const result=await depositReviewCallback(f,db);assert.ok(result.status>=400);
  const wallet=await withdrawalWalletState(db,f.user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
  let payoutCalls=0,gameCalls=0;const payout=await submitWithdrawal(input('credit-review'),context(f,db,async()=>{payoutCalls++;return {status:'processing'};}));assert.ok(payout.status>=400);
  await assert.rejects(()=>prepareMegaWallet(gameContext(f,db,()=>{gameCalls++;}),'55021'));
  assert.equal(payoutCalls,0);assert.equal(gameCalls,0);assert.deepEqual(await counts(f),{withdrawals:0,reservations:0});
 });
 await t.test('deposit review commits first in a race and blocks a new withdrawal',async()=>{
  const f=await seed('credit-race');await seedSecondCredit(f,'credit-race');const hold=gate(),attempt=gate();let calls=0;
  const risk=depositReviewCallback(f,instrumentDb(db,{afterGuard:hold}));await hold.ready;
  const spend=submitWithdrawal(input('credit-race'),context(f,instrumentDb(db,{beforeGuard:attempt}),async()=>{calls++;return {status:'processing'};}));await attempt.ready;
  hold.release();await risk;const result=await spend;assert.ok(result.status>=400);assert.equal(calls,0);assert.deepEqual(await counts(f),{withdrawals:0,reservations:0});
 });
 await t.test('a game withdrawal already in recovery can settle after deposit review',async()=>{
  const f=await seed('credit-recover');await seedSecondCredit(f,'credit-recover');const session='existing-credit-recover';
  await pool.query("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,withdraw_reference,expected_return_minor,created_at,updated_at) VALUES($1,$2,'megah5','player-fixture','55021','withdraw_unknown',2000,'dep-existing','wd-existing',1500,0,0)",[session,f.user]);
  await pool.query("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES($1,'game',$2,2000,0)",[f.user,session]);
  await depositReviewCallback(f,db);
  const c={...gameContext(f,db,()=>{throw Error('Unexpected deposit');}),fetchImpl:async input=>{assert.equal(new URL(String(input)).pathname,'/platform/megah5/transfer-status');return Response.json({provider:'megah5',operation:'transfer_status',result:{Status:200,Trans:{Amount:'15.00',Currency:'MYR'}}});}};
  const recovered=await recoverMegaWallet(c,session);assert.equal(recovered.status,'settled');assert.equal(recovered.session.resultMinor,'-500');
  const wallet=await withdrawalWalletState(db,f.user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
  const r=await pool.query('SELECT count(*)::int AS n FROM wallet_reservations WHERE user_id=$1',[f.user]);assert.equal(r.rows[0].n,0);
 });
 for(const kind of ['withdrawal','game'])await t.test(`GSPAY historical ledger review wins the guard before ${kind}`,async()=>{
  const f=await seed(`gspay-${kind}`),history=await seedGspayHistory(f,kind),hold=gate(),attempt=gate();let calls=0;
  const before=await withdrawalWalletState(db,f.user);assert.equal(before.availableMinor,'8000');assert.equal(before.reconciliationRequired,undefined);
  const risk=gspayMismatch(f,history,instrumentDb(db,{afterGuard:hold}));await hold.ready;
  const pending=kind==='withdrawal'
   ?submitWithdrawal(input(`gspay-${kind}`),context(f,instrumentDb(db,{beforeGuard:attempt}),async()=>{calls++;return {status:'processing'};})).then(value=>({value}),error=>({error}))
   :prepareMegaWallet(gameContext(f,instrumentDb(db,{beforeGuard:attempt}),()=>{calls++;}),'55021').then(value=>({value}),error=>({error}));
  await attempt.ready;hold.release();const summary=await risk,result=await pending;
  assert.equal(summary.review,1);assert.equal(calls,0);assert.ok(result.error||(result.value instanceof Response&&result.value.status>=400));
  assert.deepEqual(await counts(f),{withdrawals:0,reservations:0});
  const row=await pool.query('SELECT status FROM deposit_orders WHERE id=$1',[history.order]);assert.equal(row.rows[0].status,'review');
  const ledger=await pool.query('SELECT account_code,amount_minor FROM wallet_ledger WHERE order_id=$1',[history.order]);assert.equal(ledger.rows.length,1);assert.equal(ledger.rows[0].account_code,'member');assert.equal(String(ledger.rows[0].amount_minor),'1200');
  const wallet=await withdrawalWalletState(db,f.user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 });
 await t.test('transaction error rolls back guard and reservation',async()=>{
  const f=await seed('rollback'),probe={user:f.user,during:null};let calls=0;
  await assert.rejects(()=>submitWithdrawal(input('rollback'),context(f,instrumentDb(db,{failReservation:true,reservationBatch:true,revisionProbe:probe}),async()=>{calls++;return {status:'processing'};})),/synthetic transaction failure/);
  const after=await pool.query('SELECT revision FROM member_wallet_guards WHERE user_id=$1',[f.user]);
  assert.notEqual(probe.during,null);assert.equal(BigInt(after.rows[0].revision),probe.during-1n);assert.equal(calls,0);assert.deepEqual(await counts(f),{withdrawals:0,reservations:0});
 });
});
