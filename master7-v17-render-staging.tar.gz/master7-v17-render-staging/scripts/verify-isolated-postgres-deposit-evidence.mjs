import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {readDepositIncidentSnapshot} from '../lib/deposit-incident-evidence.ts';

const connection=process.env.MASTER7_ISOLATED_INCIDENT_DATABASE_URL??'';
let target;try{target=new URL(connection);}catch{throw Error('A fresh isolated incident database is required');}
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v127_incident_test'||target.search||target.hash||!target.port||process.env.MASTER7_ISOLATED_INCIDENT_CONFIRM!=='master7_v127_incident_test')throw Error('A fresh isolated incident database is required');

test('deposit evidence reads remain consistent and read-only on isolated PostgreSQL',{timeout:60000},async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:5});t.after(()=>pool.end());
 const identity=(await pool.query("SELECT current_database() name,(SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public')::int tables")).rows[0];assert.equal(identity.name,'master7_v127_incident_test');assert.equal(identity.tables,0,'refuse a nonempty database');
 await initializePortalDatabase(pool,await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8')));
 await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('fixture-member','fixture-member','member',1,'fixture',0); INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fixture-order','fixture-member','fixture-request','fixture','vpay',2000,'MYR','fixture','unknown',1,1)");
 await t.test('an ongoing concurrent credit cannot produce a mixed order and ledger snapshot',async()=>{
  let changed=false;
  const wrapped={async connect(){const c=await pool.connect();return {async query(sql,args){const r=await c.query(sql,args);if(sql.includes('FROM deposit_orders ORDER')&&!changed){changed=true;await pool.query("BEGIN; INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('member-leg','fixture-order','fixture-member','member',2000,'MYR',2),('clearing-leg','fixture-order','fixture-member','provider_clearing',-2000,'MYR',2); UPDATE deposit_orders SET status='credited',updated_at=2 WHERE id='fixture-order'; COMMIT");}return r;},release:destroy=>c.release(destroy)};}};
  const before=await readDepositIncidentSnapshot(wrapped);assert.equal(changed,true);assert.equal(before.items[0].status,'unknown');assert.deepEqual(before.items[0].ledger.rows,[]);assert.equal(before.summary[0].status,'unknown');assert.equal(before.items[0].finding,'after_order_payment_and_callback_not_verified');
  const after=await readDepositIncidentSnapshot(pool);assert.equal(after.items[0].status,'credited');assert.equal(after.items[0].ledger.verifiedCredit,true);assert.equal(after.items[0].finding,'wallet_credit_recorded_frontend_not_verified');assert.equal(after.items[0].frontendBalanceVerified,false);
 });
 await t.test('PostgreSQL rejects writes within the actual evidence transaction',async()=>{
  let enforced=false;
  const wrapped={async connect(){const c=await pool.connect();return {async query(sql,args){const r=await c.query(sql,args);if(sql.startsWith('BEGIN')){assert.equal((await c.query('SHOW transaction_read_only')).rows[0].transaction_read_only,'on');await c.query('SAVEPOINT synthetic_write_check');await assert.rejects(c.query("UPDATE deposit_orders SET status='failed' WHERE id='fixture-order'"),e=>e.code==='25006');await c.query('ROLLBACK TO SAVEPOINT synthetic_write_check');enforced=true;}return r;},release:destroy=>c.release(destroy)};}};
  const report=await readDepositIncidentSnapshot(wrapped);assert.equal(enforced,true);assert.equal(report.items[0].status,'credited');assert.equal((await pool.query("SELECT status FROM deposit_orders WHERE id='fixture-order'")).rows[0].status,'credited');
 });
 await t.test('a provider rejection is traceable while secret fields and receipt data stay excluded',async()=>{
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('rejected-order','fixture-member','rejected-request','fixture','1mpay',2000,'MYR','fixture','unknown',3,3)");
  await pool.query("INSERT INTO audit(id,user_id,event,target,created_at) VALUES('rejection-audit','fixture-member','payment_order_diagnostic',$1,4)",[JSON.stringify({orderId:'rejected-order',provider:'1mpay',kind:'ORDER_RESPONSE',providerCode:-1,secretKey:'EXCLUDED-SYNTHETIC-KEY'})]);
  const report=await readDepositIncidentSnapshot(pool),item=report.items.find(i=>i.orderId==='rejected-order');assert.equal(item.finding,'B_provider_order_rejected');assert.equal(item.diagnostics[0].id,'rejection-audit');assert.equal(item.providerPaymentVerified,false);assert.doesNotMatch(JSON.stringify(report),/EXCLUDED-SYNTHETIC-KEY/);
 });
});
