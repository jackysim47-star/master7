#!/usr/bin/env node
import {pathToFileURL} from 'node:url';

const REQUESTS=[
 ['liveness','/health/live',200],['health','/health',200],['version','/api/version',200],['channels','/api/payment-channels',200],
 ['vpay','/api/payments/vpay/status',200],['gspay','/api/payments/gspay/status',200],['gspay_usdt','/api/payments/gspay/usdt/status',200],['1mpay','/api/payments/1mpay/status',200],
 ['withdrawals','/api/withdrawal-banks',200],['games','/api/games',200],['invalidGame','/api/games?provider=__probe_invalid__',400],
];
const CLOSED_HEALTH_FLAGS=['productionReady','settlementVerified','transactionsEnabled','realPayments','payoutsEnabled','liveGames','newDepositsEnabled','newGameLaunchesEnabled','newPayoutsEnabled'];
const PAYMENT_PROVIDERS=['vpay','gspay','1mpay'];
const PAYMENT_PROFILES=['vpay','gspay','gspay_usdt','1mpay'];
const REQUIRED_READINESS_BLOCKERS=['deposit_provider_not_ready','payout_provider_not_ready','payment_settlement_not_verified','game_launch_or_settlement_not_ready','official_domain_tls_not_verified','credential_rotation_not_verified','production_signoff_not_verified'];
const GAME_PROVIDER_IDS=['megah5','jili','918kissh5','gameplay','lionking','suncity','pgsoft','gfg','sagaming','ps9','dragoonsoft','jdb','bg','allbet','quickspin','astar','metagaming','fuma','yl','funky','gamitech','spadegaming','turbo','ct855','pragmaticplay','joker','cg','atg','rectangle','m8bet','awc','evo888h5','cosmoplay','geminiupdown','epicwin','venus','clotplay','coba8'];

export function validateBaseUrl(value){
 const raw=String(value??'').trim();if(!raw)throw new Error('A base URL is required');
 let url;try{url=new URL(raw);}catch{throw new Error('The base URL is invalid');}
 if(!['http:','https:'].includes(url.protocol))throw new Error('The base URL must use HTTP or HTTPS');
 if(url.username||url.password)throw new Error('The base URL must not contain credentials');
 if(url.search||url.hash)throw new Error('The base URL must not contain a query or fragment');
 if(url.pathname!==''&&url.pathname!=='/')throw new Error('The base URL must contain only an origin');
 url.pathname='/';return url;
}

function check(checks,name,pass){checks.push({name,pass:pass===true});}
function isObject(value){return value!==null&&typeof value==='object'&&!Array.isArray(value);}
function allFalse(value){return isObject(value)&&Object.values(value).every(item=>item===false);}
function paymentMapClosed(value){return allFalse(value)&&PAYMENT_PROFILES.every(profile=>value[profile]===false);}

export function evaluateProductionReadiness({liveness,health,version,channels,providerStatuses,withdrawals,games,invalidGame},{expectedReleasePrefix}={}){
 const checks=[];
 check(checks,'liveness.status',liveness?.status==='ok');
 check(checks,'liveness.database',liveness?.database==='ready');
 check(checks,'liveness.scope',liveness?.scope==='portal-liveness');
 check(checks,'liveness.releaseMatchesHealth',liveness?.release===health?.release);
 check(checks,'health.status',health?.status==='ok');
 check(checks,'health.database',health?.database==='ready');
 check(checks,'health.maintenanceControlsConfigured',health?.maintenanceControlsConfigured?.deposits===true&&health?.maintenanceControlsConfigured?.gameLaunches===true&&health?.maintenanceControlsConfigured?.payouts===true);
 for(const flag of CLOSED_HEALTH_FLAGS)check(checks,`health.${flag}`,health?.[flag]===false);
 check(checks,'health.providerOrdersEnabled',paymentMapClosed(health?.providerOrdersEnabled));
 check(checks,'health.providerPayoutsEnabled',paymentMapClosed(health?.providerPayoutsEnabled));
 check(checks,'health.backupReady',typeof health?.backupReady==='boolean');
 check(checks,'health.restoreReady',typeof health?.restoreReady==='boolean'&&(!health.restoreReady||health.backupReady===true));
 const expectedReadinessBlockers=[...REQUIRED_READINESS_BLOCKERS,...(health?.backupReady===true?[]:['encrypted_backup_not_ready']),...(health?.restoreReady===true?[]:['restore_rehearsal_not_verified'])];
 check(checks,'health.readinessBlockers',Array.isArray(health?.readinessBlockers)&&health.readinessBlockers.length===expectedReadinessBlockers.length&&expectedReadinessBlockers.every(item=>health.readinessBlockers.includes(item)));
 check(checks,'health.providerCapabilities',PAYMENT_PROVIDERS.every(provider=>health?.providerCapabilities?.[provider]?.deposit?.enabled===false&&Array.isArray(health?.providerCapabilities?.[provider]?.deposit?.blockers)&&health.providerCapabilities[provider].deposit.blockers.includes('new_deposits_paused'))&&health?.providerCapabilities?.gspay_usdt?.deposit?.enabled===false&&health.providerCapabilities.gspay_usdt.deposit.implemented===false&&health.providerCapabilities.gspay_usdt.deposit.blockers?.includes('deposit_adapter_not_implemented'));
 if(expectedReleasePrefix)check(checks,'health.releasePrefix',typeof health?.release==='string'&&health.release.startsWith(expectedReleasePrefix));
 check(checks,'version.releaseMatchesHealth',version?.release===health?.release&&version?.sourceRelease===health?.sourceRelease);

 check(checks,'providerStatuses.closed',PAYMENT_PROVIDERS.every(provider=>{
  const status=providerStatuses?.[provider];return status?.provider===provider&&status?.readOnly===true&&status?.enabled===false&&status?.orderReady===false&&status?.realPayments===false&&status?.queryReady===true&&status?.callbacksReady===true&&status?.capabilities?.deposit?.enabled===false&&Array.isArray(status?.capabilities?.deposit?.blockers)&&status.capabilities.deposit.blockers.includes('new_deposits_paused');
 }));
 const usdtStatus=providerStatuses?.gspay_usdt;
 check(checks,'providerStatuses.gspayUsdtClosed',usdtStatus?.provider==='gspay'&&usdtStatus?.profileId==='gspay_usdt'&&usdtStatus?.currency==='USDT'&&usdtStatus?.readOnly===true&&usdtStatus?.enabled===false&&usdtStatus?.orderReady===false&&usdtStatus?.queryReady===false&&usdtStatus?.callbacksReady===false&&usdtStatus?.realPayments===false&&usdtStatus?.capabilities?.deposit?.implemented===false&&usdtStatus.capabilities.deposit.blockers?.includes('deposit_adapter_not_implemented'));

 check(checks,'paymentChannels.readOnly',channels?.readOnly===true);
 check(checks,'paymentChannels.maintenanceControlsConfigured',channels?.maintenanceControlsConfigured?.deposits===true&&channels?.maintenanceControlsConfigured?.gameLaunches===true&&channels?.maintenanceControlsConfigured?.payouts===true);
 check(checks,'paymentChannels.transactionsEnabled',channels?.transactionsEnabled===false);
 check(checks,'paymentChannels.realPayments',channels?.realPayments===false);
 check(checks,'paymentChannels.payoutsEnabled',channels?.payoutsEnabled===false);
 check(checks,'paymentChannels.providerOrdersEnabled',paymentMapClosed(channels?.providerOrdersEnabled));
 check(checks,'paymentChannels.providerPayoutsEnabled',paymentMapClosed(channels?.providerPayoutsEnabled));
 const channelItems=Array.isArray(channels?.items)?channels.items:[];
 const channelIds=channelItems.map(item=>String(item?.provider_id??''));
 check(checks,'paymentChannels.itemsPresent',channelItems.length===PAYMENT_PROFILES.length&&new Set(channelIds).size===PAYMENT_PROFILES.length&&PAYMENT_PROFILES.every(profile=>channelIds.includes(profile)));
 check(checks,'paymentChannels.itemsClosed',channelItems.every(item=>item?.enabled===false&&item?.status==='unavailable'&&item?.channelStatus==='unavailable'&&item?.settlementVerified===false&&item?.capabilities?.deposit?.enabled===false&&Array.isArray(item?.capabilities?.deposit?.blockers)&&(item.provider_id==='gspay_usdt'?item.capabilities.deposit.blockers.includes('deposit_adapter_not_implemented'):item.capabilities.deposit.blockers.includes('new_deposits_paused'))));

 check(checks,'withdrawals.currency',withdrawals?.currency==='MYR');
 check(checks,'withdrawals.closed',withdrawals?.enabled===false&&Array.isArray(withdrawals?.providers)&&PAYMENT_PROVIDERS.every(provider=>withdrawals.providers.some(item=>item?.id===provider&&item?.enabled===false)));

 check(checks,'games.readOnlyAvailability',games?.readOnlyAvailability===true);
 const providers=Array.isArray(games?.providers)?games.providers:[];
 const providerPositions=providers.length||Number(games?.platformCount??games?.providerPositions??0);
 check(checks,'games.providerPositions',providerPositions===38);
 const ids=providers.map(item=>String(item?.id??'')),positions=providers.map(item=>Number(item?.position)).sort((a,b)=>a-b);
 check(checks,'games.providerIds',ids.length===GAME_PROVIDER_IDS.length&&new Set(ids).size===GAME_PROVIDER_IDS.length&&GAME_PROVIDER_IDS.every(id=>ids.includes(id))&&!ids.includes('godeezone'));
 check(checks,'games.positions',positions.length===38&&positions.every((position,index)=>position===index+1));
 check(checks,'games.newProviders',['epicwin','venus','clotplay','coba8'].every(id=>ids.includes(id)));
 check(checks,'games.liveReady',games?.liveReady===false);
 check(checks,'games.playable',games?.playable===false);
 const verifiedProviders=new Set(providers.filter(item=>item?.launchVerified===true&&item?.walletVerified===true).map(item=>String(item.id??item.provider??'')));
 check(checks,'games.unverifiedProvidersClosed',providers.every(item=>item?.playable!==true||(item?.launchVerified===true&&item?.walletVerified===true)));
 check(checks,'games.launchesClosed',providers.every(item=>item?.platformLaunchReady===false&&item?.launchReady===false));
 check(checks,'games.unverifiedReadyClosed',providers.every(item=>{
  const ready=item?.playable===true||item?.platformLaunchReady===true||item?.launchReady===true||item?.platformStatus==='ready'||item?.operationalStatus==='ready';
  return !ready||(item?.launchVerified===true&&item?.walletVerified===true&&item?.settlementVerified===true);
 }));
 const gameItems=Array.isArray(games?.games)?games.games:[];
 check(checks,'games.unverifiedTitlesClosed',gameItems.every(item=>item?.playable!==true||verifiedProviders.has(String(item?.provider??''))));
 check(checks,'games.invalidProviderRejected',invalidGame?.status===400);
 return {ok:checks.every(item=>item.pass),scope:'maintenance_safety_only',maintenanceVerified:checks.every(item=>item.pass),productionReady:false,release:typeof health?.release==='string'?health.release:null,providerPositions,channelCount:channelItems.length,checks};
}

async function getJson(fetchImpl,url,timeoutMs,expectedStatus){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{
  const response=await fetchImpl(url,{method:'GET',headers:{Accept:'application/json'},redirect:'error',signal:controller.signal});
  if(response.status!==expectedStatus)throw new Error(`Probe endpoint returned unexpected HTTP ${response.status}`);
  if(!(response.headers.get('cache-control')??'').toLowerCase().split(',').map(value=>value.trim()).includes('no-store'))throw new Error('Probe endpoint is missing Cache-Control: no-store');
  const contentType=response.headers.get('content-type')??'';if(!contentType.toLowerCase().includes('application/json'))throw new Error('Probe endpoint did not return JSON');
  try{return {status:response.status,data:await response.json()};}catch{throw new Error('Probe endpoint returned invalid JSON');}
 }catch(error){
  if(error?.name==='AbortError')throw new Error('Probe endpoint timed out');
  throw error;
 }finally{clearTimeout(timer);}
}

export async function probeProductionReadiness({baseUrl,fetchImpl=fetch,timeoutMs=15_000,expectedReleasePrefix}={}){
 const origin=validateBaseUrl(baseUrl);if(!Number.isFinite(timeoutMs)||timeoutMs<10||timeoutMs>60_000)throw new Error('Probe timeout is invalid');
 const responses=await Promise.all(REQUESTS.map(([,path,status])=>getJson(fetchImpl,new URL(path,origin),timeoutMs,status)));
 const result=Object.fromEntries(REQUESTS.map(([key],index)=>[key,responses[index]]));
 const providerStatuses=Object.fromEntries(PAYMENT_PROFILES.map(profile=>[profile,result[profile].data]));
 return evaluateProductionReadiness({liveness:result.liveness.data,health:result.health.data,version:result.version.data,channels:result.channels.data,providerStatuses,withdrawals:result.withdrawals.data,games:result.games.data,invalidGame:result.invalidGame},{expectedReleasePrefix});
}

function cliBaseUrl(args){const index=args.indexOf('--base-url');return index>=0?args[index+1]:process.env.PRODUCTION_BASE_URL;}
export async function main(args=process.argv.slice(2),env=process.env){
 try{
  const timeoutMs=env.PROBE_TIMEOUT_MS===undefined?15_000:Number(env.PROBE_TIMEOUT_MS);
  const result=await probeProductionReadiness({baseUrl:cliBaseUrl(args),timeoutMs,expectedReleasePrefix:env.EXPECTED_RELEASE_PREFIX||undefined});
  process.stdout.write(JSON.stringify(result)+'\n');return result.ok?0:1;
 }catch(error){process.stdout.write(JSON.stringify({ok:false,error:error instanceof Error?error.message:'Production readiness probe failed'})+'\n');return 1;}
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)process.exitCode=await main();
