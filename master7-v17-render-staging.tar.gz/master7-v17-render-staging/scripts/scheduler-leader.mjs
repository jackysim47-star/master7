import pg from "pg";

const DEFAULT_RETRY_MS = 15_000;
const DEFAULT_HEARTBEAT_MS = 30_000;
const LOCK_NAMESPACE = 1_297_304_916;
const LOCK_RESOURCE = 17;

function boundedInterval(value, fallback) {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= 1_000 && parsed <= 300_000 ? parsed : fallback;
}

function safeCode(error) {
  return typeof error?.code === "string" && /^[A-Z0-9_]{1,32}$/.test(error.code)
    ? error.code
    : "UNKNOWN";
}

function stopWorkers(workers) {
  for (const worker of workers.splice(0)) {
    try { worker?.stop?.(); } catch {}
  }
}

export function startSchedulerLeadership(options = {}) {
  const connectionString = String(options.connectionString ?? "");
  const startWorkers = options.startWorkers;
  if (!connectionString || typeof startWorkers !== "function") {
    return { enabled: false, ready: Promise.resolve(false), isLeader: () => false, stop: async () => {} };
  }

  const retryMs = boundedInterval(options.retryMs, DEFAULT_RETRY_MS);
  const heartbeatMs = boundedInterval(options.heartbeatMs, DEFAULT_HEARTBEAT_MS);
  const clientFactory = options.clientFactory ?? (() => new pg.Client({ connectionString, ssl: options.ssl }));
  const logger = options.logger ?? console;
  let stopped = false;
  let attempting = false;
  let activeClient = null;
  let workers = [];
  let retryTimer;
  let heartbeatTimer;
  const closedClients = new WeakSet();

  const closeClient = async client => {
    if (!client || closedClients.has(client)) return;
    closedClients.add(client);
    try { await client.end(); } catch {}
  };

  const scheduleRetry = () => {
    if (stopped || retryTimer || activeClient) return;
    retryTimer = setTimeout(() => {
      retryTimer = undefined;
      void attempt();
    }, retryMs);
    retryTimer.unref?.();
  };

  const loseLeadership = async (client, error) => {
    if (client !== activeClient) {
      await closeClient(client);
      scheduleRetry();
      return;
    }
    activeClient = null;
    clearInterval(heartbeatTimer);
    heartbeatTimer = undefined;
    stopWorkers(workers);
    await closeClient(client);
    if (!stopped) logger.error?.(`MASTER7 scheduler leadership lost (${safeCode(error)}); retrying.`);
    scheduleRetry();
  };

  const attempt = async () => {
    if (stopped || attempting || activeClient) return false;
    attempting = true;
    let client;
    try {
      client = clientFactory();
      const onError = error => { void loseLeadership(client, error); };
      client.on?.("error", onError);
      await client.connect();
      const result = await client.query(
        "SELECT pg_try_advisory_lock($1::integer,$2::integer) AS acquired",
        [LOCK_NAMESPACE, LOCK_RESOURCE],
      );
      if (result?.rows?.[0]?.acquired !== true || stopped) {
        if (result?.rows?.[0]?.acquired === true) {
          try { await client.query("SELECT pg_advisory_unlock($1::integer,$2::integer)", [LOCK_NAMESPACE, LOCK_RESOURCE]); } catch {}
        }
        await closeClient(client);
        scheduleRetry();
        return false;
      }
      activeClient = client;
      const started = startWorkers();
      workers = Array.isArray(started) ? started.filter(Boolean) : [];
      heartbeatTimer = setInterval(async () => {
        try { await client.query("SELECT 1"); }
        catch (error) { await loseLeadership(client, error); }
      }, heartbeatMs);
      heartbeatTimer.unref?.();
      logger.log?.("MASTER7 scheduler leadership acquired.");
      return true;
    } catch (error) {
      if (client === activeClient) {
        await loseLeadership(client, error);
      } else {
        await closeClient(client);
        if (!stopped) logger.error?.(`MASTER7 scheduler leadership unavailable (${safeCode(error)}); retrying.`);
        scheduleRetry();
      }
      return false;
    } finally {
      attempting = false;
    }
  };

  const ready = attempt();
  return {
    enabled: true,
    ready,
    isLeader: () => activeClient !== null,
    async stop() {
      stopped = true;
      clearTimeout(retryTimer);
      clearInterval(heartbeatTimer);
      retryTimer = undefined;
      heartbeatTimer = undefined;
      stopWorkers(workers);
      const client = activeClient;
      activeClient = null;
      if (client) {
        try { await client.query("SELECT pg_advisory_unlock($1::integer,$2::integer)", [LOCK_NAMESPACE, LOCK_RESOURCE]); } catch {}
        await closeClient(client);
      }
    },
  };
}
