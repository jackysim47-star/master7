#!/usr/bin/env node
import {pathToFileURL} from 'node:url';
import pg from 'pg';
import {BACKUP_EXCLUDED_TABLES,BACKUP_FORMAT,BACKUP_SCHEMA_SHA256,BACKUP_SCHEMA_VERSION,BACKUP_TABLES} from '../lib/encrypted-backup.ts';
import {BACKUP_PUBLIC_KEY_SHA256} from '../lib/backup-public-key.ts';
import {
 API_SUPPLIER_STATUS_MIGRATION,BENEFIT_CLAIM_REVIEW_MIGRATION,COMPANY_BANK_ARTWORK_MIGRATION,
 CONNECTED_SERVICES_MIGRATION,FIXED_VOUCHER_RETIREMENT_MIGRATION,GAME_ACCESS_ZONE_MIGRATION,
 GAME_PROVIDER_ADAPTER_CORE_MIGRATION,MEGAH5_LAUNCH_OPERATIONS_MIGRATION,
 GSPAY_PAYOUT_ACTIVATION_MIGRATION,GSPAY_USDT_PROFILE_MIGRATION,MANUAL_BANK_MIGRATION,MANUAL_COMPLIANCE_MIGRATION,
 MARKETING_CONTACT_SCALE_MIGRATION,NEW_MEMBER_VOUCHER_MIGRATION,ONE_MPAY_CHANNEL_MIGRATION,
 OPERATIONS_AUTOMATION_MIGRATION,PAYMENT_ACCEPTANCE_GUARD_MIGRATION,PAYMENT_CHANNEL_ACTIVATION_MIGRATIONS,
 PAYMENT_PROVIDERS_MIGRATION,PAYOUT_CONTROL_MIGRATION,PORTAL_STATUS_MIGRATION,RESPONSIBLE_PLAY_MIGRATION,
 REWARDS_HUB_MIGRATION,SUPPORT_MARKETING_MIGRATION,VOUCHER_MANUAL_WORKFLOW_MIGRATION,
 WHATSAPP_CAMPAIGN_DELIVERY_MIGRATION,
} from '../lib/render-migrations.mjs';

export const REQUIRED_TABLES=Object.freeze([...BACKUP_TABLES,...BACKUP_EXCLUDED_TABLES].sort());
export const REQUIRED_MIGRATIONS=Object.freeze([
 PORTAL_STATUS_MIGRATION,CONNECTED_SERVICES_MIGRATION,PAYMENT_PROVIDERS_MIGRATION,MANUAL_BANK_MIGRATION,
 API_SUPPLIER_STATUS_MIGRATION,GAME_ACCESS_ZONE_MIGRATION,PAYMENT_ACCEPTANCE_GUARD_MIGRATION,
 MARKETING_CONTACT_SCALE_MIGRATION,OPERATIONS_AUTOMATION_MIGRATION,SUPPORT_MARKETING_MIGRATION,
 PAYOUT_CONTROL_MIGRATION,WHATSAPP_CAMPAIGN_DELIVERY_MIGRATION,REWARDS_HUB_MIGRATION,
 RESPONSIBLE_PLAY_MIGRATION,COMPANY_BANK_ARTWORK_MIGRATION,NEW_MEMBER_VOUCHER_MIGRATION,
 VOUCHER_MANUAL_WORKFLOW_MIGRATION,FIXED_VOUCHER_RETIREMENT_MIGRATION,BENEFIT_CLAIM_REVIEW_MIGRATION,
 MANUAL_COMPLIANCE_MIGRATION,GSPAY_USDT_PROFILE_MIGRATION,GAME_PROVIDER_ADAPTER_CORE_MIGRATION,MEGAH5_LAUNCH_OPERATIONS_MIGRATION,
].sort());
export const OPTIONAL_MIGRATIONS=Object.freeze([
 ONE_MPAY_CHANNEL_MIGRATION,...Object.values(PAYMENT_CHANNEL_ACTIVATION_MIGRATIONS),GSPAY_PAYOUT_ACTIVATION_MIGRATION,
].sort());

const sha256=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const parse=value=>{try{return typeof value==='string'?JSON.parse(value):null;}catch{return null;}};
const fresh=(value,maxAgeSeconds,nowMs)=>{const epoch=Date.parse(value);return Number.isFinite(epoch)&&epoch<=nowMs+300_000&&epoch>=nowMs-maxAgeSeconds*1000;};
const check=(checks,id,pass)=>checks.push({id,pass:pass===true});

export function evaluatePostgresReadinessEvidence(input,{expectedRelease,nowMs=Date.now()}={}){
 if(typeof expectedRelease!=='string'||!expectedRelease)throw new Error('Expected release is required');
 const checks=[],role=input.role??{},tables=(input.tables??[]).map(row=>String(row.name)),migrations=input.migrations??[],versions=migrations.map(row=>String(row.version)),knownMigrations=new Set([...REQUIRED_MIGRATIONS,...OPTIONAL_MIGRATIONS]);
 check(checks,'database_role_read_only',role.transaction_read_only==='on'&&role.can_create_database===false&&role.can_create_schema===false&&role.can_write_tables===false);
 check(checks,'required_tables',REQUIRED_TABLES.every(name=>tables.includes(name)));
 check(checks,'no_unclassified_tables',tables.every(name=>REQUIRED_TABLES.includes(name)));
 check(checks,'required_migrations',REQUIRED_MIGRATIONS.every(version=>versions.includes(version)));
 check(checks,'no_unknown_migrations',versions.every(version=>knownMigrations.has(version)));
 check(checks,'migration_timestamps',migrations.every(row=>Number.isSafeInteger(Number(row.applied_at))&&Number(row.applied_at)>0&&Number(row.applied_at)<=Math.floor(nowMs/1000)+300));

 const backup=parse(input.backupAudit?.target),backupAuditAt=Number(input.backupAudit?.created_at),backupReady=!!backup&&backup.format===BACKUP_FORMAT&&backup.release===expectedRelease&&backup.schemaVersion===BACKUP_SCHEMA_VERSION&&backup.schemaSha256===BACKUP_SCHEMA_SHA256&&backup.publicKeySha256===BACKUP_PUBLIC_KEY_SHA256&&backup.readConsistency==='transaction_snapshot'&&backup.tableCount===BACKUP_TABLES.length&&Number.isSafeInteger(backup.totalRecords)&&backup.totalRecords>=0&&sha256(backup.backupSha256)&&sha256(backup.plaintextSha256)&&sha256(backup.ciphertextSha256)&&fresh(backup.createdAt,7*86400,nowMs)&&Number.isSafeInteger(backupAuditAt)&&backupAuditAt>=Math.floor(nowMs/1000)-7*86400&&backupAuditAt<=Math.floor(nowMs/1000)+300;
 check(checks,'current_encrypted_backup',backupReady);

 const restore=parse(input.restoreSetting?.value),createdAt=Date.parse(restore?.createdAt??''),verifiedAt=Date.parse(restore?.verifiedAt??''),restoreReady=backupReady&&!!restore&&restore.status==='verified'&&restore.format===BACKUP_FORMAT&&restore.release===expectedRelease&&restore.schemaVersion===BACKUP_SCHEMA_VERSION&&restore.schemaSha256===BACKUP_SCHEMA_SHA256&&restore.publicKeySha256===BACKUP_PUBLIC_KEY_SHA256&&restore.coverageComplete===true&&Array.isArray(restore.missingTables)&&restore.missingTables.length===0&&restore.readConsistency==='transaction_snapshot'&&restore.persistentWrites===false&&restore.restoreTargetKind==='isolated_postgresql_transaction'&&sha256(restore.restoreTargetSha256)&&restore.foreignKeyViolations===0&&restore.tableCount===BACKUP_TABLES.length&&restore.totalRecords===backup.totalRecords&&restore.createdAt===backup.createdAt&&restore.backupSha256===backup.backupSha256&&restore.plaintextSha256===backup.plaintextSha256&&fresh(restore.createdAt,30*86400,nowMs)&&fresh(restore.verifiedAt,30*86400,nowMs)&&Number.isFinite(createdAt)&&Number.isFinite(verifiedAt)&&verifiedAt>=createdAt;
 check(checks,'bound_restore_rehearsal',restoreReady);
 return {ok:checks.every(item=>item.pass),release:expectedRelease,checks,schema:{requiredTables:REQUIRED_TABLES.length,requiredMigrations:REQUIRED_MIGRATIONS.length},evidence:{backupCreatedAt:backupReady?backup.createdAt:null,restoreVerifiedAt:restoreReady?restore.verifiedAt:null}};
}

export async function runPostgresReadinessGate(client,options){
 let began=false,result,error,rollbackError;
 try{
  await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');began=true;
  await client.query("SET LOCAL statement_timeout='10000ms'");
  await client.query("SET LOCAL lock_timeout='2000ms'");
  await client.query("SET LOCAL idle_in_transaction_session_timeout='15000ms'");
  const role=(await client.query(`SELECT current_setting('transaction_read_only') transaction_read_only,
    has_database_privilege(current_user,current_database(),'CREATE') can_create_database,
    has_schema_privilege(current_user,'public','CREATE') can_create_schema,
    EXISTS(SELECT 1 FROM unnest($1::text[]) table_name WHERE
      has_table_privilege(current_user,format('%I.%I','public',table_name),'INSERT') OR
      has_table_privilege(current_user,format('%I.%I','public',table_name),'UPDATE') OR
      has_table_privilege(current_user,format('%I.%I','public',table_name),'DELETE') OR
      has_table_privilege(current_user,format('%I.%I','public',table_name),'TRUNCATE') OR
      has_table_privilege(current_user,format('%I.%I','public',table_name),'TRIGGER')) can_write_tables`,[REQUIRED_TABLES])).rows[0];
  const tables=(await client.query("SELECT c.relname name FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p') ORDER BY c.relname")).rows;
  const migrations=(await client.query('SELECT version,applied_at FROM portal_schema_migrations ORDER BY version')).rows;
  const backupCandidates=(await client.query("SELECT target,created_at FROM audit WHERE event='encrypted_backup_created' AND created_at=(SELECT MAX(created_at) FROM audit WHERE event='encrypted_backup_created')")).rows;
  const backupAudit=backupCandidates.map(row=>({row,metadata:parse(row.target)})).filter(item=>item.metadata&&fresh(item.metadata.createdAt,30*86400,options?.nowMs??Date.now())).sort((a,b)=>Date.parse(b.metadata.createdAt)-Date.parse(a.metadata.createdAt))[0]?.row??null;
  const restoreSetting=(await client.query("SELECT value FROM settings WHERE id='backup_restore_rehearsal'")).rows[0]??null;
  result=evaluatePostgresReadinessEvidence({role,tables,migrations,backupAudit,restoreSetting},options);
 }catch(cause){error=cause;}
 finally{if(began)try{await client.query('ROLLBACK');}catch(cause){rollbackError=cause;}}
 if(error&&rollbackError)throw new AggregateError([error,rollbackError],'PostgreSQL readiness gate failed');
 if(error)throw error;if(rollbackError)throw rollbackError;if(!result)throw new Error('PostgreSQL readiness gate did not complete');return result;
}

async function main(){
 const connectionString=process.env.PORTAL_READINESS_DATABASE_URL,expectedRelease=process.env.MASTER7_EXPECTED_RELEASE;
 if(!connectionString||!expectedRelease){process.stdout.write(JSON.stringify({ok:false,error:'Readiness gate configuration is incomplete'})+'\n');return 1;}
 const client=new pg.Client({connectionString,application_name:'master7-readiness-gate',ssl:process.env.PGSSLMODE==='disable'?false:{rejectUnauthorized:process.env.PGSSL_REJECT_UNAUTHORIZED!=='false',...(process.env.PGSSL_CA?{ca:process.env.PGSSL_CA.replaceAll('\\n','\n')}:{})},connectionTimeoutMillis:10_000});
 try{await client.connect();const result=await runPostgresReadinessGate(client,{expectedRelease});process.stdout.write(JSON.stringify(result)+'\n');return result.ok?0:1;}
 catch{process.stdout.write(JSON.stringify({ok:false,error:'PostgreSQL readiness gate failed'})+'\n');return 1;}
 finally{try{await client.end();}catch{}}
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)process.exitCode=await main();
