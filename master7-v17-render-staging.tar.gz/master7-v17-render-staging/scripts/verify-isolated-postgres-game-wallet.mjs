import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {settleMegaWallet,recoverMegaWallet,MegaWalletError} from '../lib/megah5-wallet.ts';
import {withdrawalWalletState,clearStaleReservation} from '../lib/withdrawals.ts';

// Only an explicitly confirmed, fresh local throwaway database may be used.
const connection=process.env.MASTER7_ISOLATED_GAME_TEST_DATABASE_URL??'';
const target=new URL(connection);
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v17_game_race_test'||target.search||target.hash||!target.port)throw Error('A fresh loopback-only master7_v17_game_race_test database is required');
if(process.env.MASTER7_ISOLATED_GAME_POSTGRES_CONFIRM!=='master7_v17_game_race_test')throw Error('Explicit isolated test database confirmation is required');

function gate(){let signal,release;return {ready:new Promise(r=>{signal=r;}),wait:new Promise(r=>{release=r;}),signal:()=>signal(),release:()=>release()};}
const ok=result=>Response.json({provider:'megah5',result:{Status:200,...result}});
const ambiguous=()=>Response.json({provider:'unexpected',result:{Status:200}});

test('MegaH5 recovery and settlement races preserve ledger and reservations on isolated PostgreSQL',async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:5});
 const previousUrl=process.env.PORTAL_POSTGRES_URL,previousSsl=process.env.PGSSLMODE,originalFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=originalFetch;if(previousUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=previousUrl;if(previousSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=previousSsl;});
 const identity=await pool.query("SELECT current_database() AS name,COUNT(*)::int AS tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,'master7_v17_game_race_test');assert.equal(identity.rows[0].tables,0,'test database must be empty');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat();
 async function seed(user,id){
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'fixture',0)",[user]);
  await pool.query("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES($1,$2,'megah5',$3,'fixture','active',2000,$4,0,0)",[id,user,'player-'+user,'dep-'+id]);
  await pool.query("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES($1,'game',$2,2000,0)",[user,id]);
 }
 async function state(id){
  const s=await pool.query('SELECT status,amount_returned_minor FROM game_wallet_sessions WHERE id=$1',[id]);
  const l=await pool.query('SELECT amount_minor,currency FROM game_wallet_ledger WHERE session_id=$1',[id]);
  const r=await pool.query('SELECT amount_minor FROM wallet_reservations WHERE reference_id=$1',[id]);
  return {status:s.rows[0].status,returned:s.rows[0].amount_returned_minor==null?null:String(s.rows[0].amount_returned_minor),ledger:l.rows.map(x=>({amount:String(x.amount_minor),currency:x.currency})),reserved:r.rows.map(x=>String(x.amount_minor))};
 }
 function context(user,withdraw,query){return {db,user:{id:user,username:user,role:'member',approved:1},gatewayUrl:'https://master7-integration-gateway.onrender.com',gameToken:'g'.repeat(40),walletToken:'w'.repeat(40),fetchImpl:async (input,init)=>{
  const path=new URL(String(input)).pathname;
  if(path==='/platform/megah5/balance')return ok({CurrentBalance:'15.50',Currency:'MYR'});
  if(path==='/platform/megah5/withdraw'){withdraw.signal();await withdraw.wait;return Response.json({provider:'megah5',operation:'withdraw',referenceId:JSON.parse(init.body).referenceId,result:{Status:200}});}
  if(path==='/platform/megah5/transfer-status'){if(query){query.signal();await query.wait;}return ambiguous();}
  throw Error('Unexpected synthetic provider route');
 }};}
 await t.test('unconfirmed recovery before withdrawal response retains reservation and cannot report settlement',async()=>{
  const user='race-review-user',id='race-review-session';await seed(user,id);const withdraw=gate(),c=context(user,withdraw);
  const pending=settleMegaWallet(c).then(value=>({value}),error=>({error}));await withdraw.ready;
  await assert.rejects(()=>recoverMegaWallet(c),e=>e instanceof MegaWalletError&&e.status===409);
  withdraw.release();const result=await pending;assert.ok(result.error instanceof MegaWalletError);assert.equal(result.error.status,409);
  assert.deepEqual(await state(id),{status:'manual_review',returned:null,ledger:[],reserved:['2000']});
 });
 await t.test('an unsettled conflicting game result blocks availability and keeps reservation',async()=>{
  const user='race-conflict-user',id='race-conflict-session';await seed(user,id);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('conflict-deposit',$1,'conflict-request','fixture','vpay',2000,'MYR','bank','credited',0,0)",[user]);
  await pool.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('conflict-member','conflict-deposit',$1,'member',2000,'MYR',0),('conflict-clearing','conflict-deposit',$1,'provider_clearing',-2000,'MYR',0)",[user]);
  await pool.query("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('conflicting-result',$1,$2,'game_result',999,'MYR',0)",[id,user]);
  const before=await withdrawalWalletState(db,user);assert.equal(before.balanceMinor,'2000');assert.equal(before.availableMinor,'0');assert.equal(before.heldMinor,'2000');assert.equal(before.reconciliationRequired,true);
  const withdraw=gate(),c=context(user,withdraw);const pending=settleMegaWallet(c).then(value=>({value}),error=>({error}));await withdraw.ready;withdraw.release();
  const result=await pending;assert.ok(result.error instanceof MegaWalletError);assert.equal(result.error.status,409);
  await clearStaleReservation(db,user);
  assert.deepEqual(await state(id),{status:'withdraw_pending',returned:null,ledger:[{amount:'999',currency:'MYR'}],reserved:['2000']});
  const after=await withdrawalWalletState(db,user);assert.equal(after.balanceMinor,'2000');assert.equal(after.availableMinor,'0');assert.equal(after.heldMinor,'2000');assert.equal(after.reconciliationRequired,true);
 });
 await t.test('late unconfirmed recovery cannot revert a successfully settled wallet',async()=>{
  const user='race-settled-user',id='race-settled-session';await seed(user,id);const withdraw=gate(),query=gate(),c=context(user,withdraw,query);
  const pending=settleMegaWallet(c);await withdraw.ready;
  const recovery=recoverMegaWallet(c).then(value=>({value}),error=>({error}));await query.ready;
  withdraw.release();const result=await pending;assert.equal(result.status,'settled');assert.equal(result.session.resultMinor,'-450');
  query.release();const late=await recovery;assert.ok(late.error instanceof MegaWalletError);assert.equal(late.error.status,409);
  assert.deepEqual(await state(id),{status:'settled',returned:'1550',ledger:[{amount:'-450',currency:'MYR'}],reserved:[]});
 });
});
