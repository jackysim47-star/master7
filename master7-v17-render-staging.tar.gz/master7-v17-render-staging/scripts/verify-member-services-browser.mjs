// Isolated UI verification. Uses real backend queries in a temporary SQLite DB.
// The cookie below selects synthetic identities; this does not test login/OTP.
import assert from 'node:assert/strict';
import {createServer} from 'node:https';
import {execFileSync} from 'node:child_process';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync,mkdirSync,mkdtempSync,rmSync} from 'node:fs';
import {resolve,extname} from 'node:path';
import {handle} from '../lib/backend.ts';

const root=resolve(import.meta.dirname,'..'),output=process.env.MEMBER_UI_OUTPUT||'/dev/shm/master7-member-ui';mkdirSync(output,{recursive:true});
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'playwright');
const sql=new DatabaseSync(':memory:');
for(const name of readdirSync(resolve(root,'drizzle')).filter(x=>x.endsWith('.sql')).sort())sql.exec(readFileSync(resolve(root,'drizzle',name),'utf8'));
for(const [id,role] of [['alice','member'],['bob','member'],['owner','owner']])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,1,?,0)').run(id,id,role,'csrf-'+id);
class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=statements.map(s=>sql.prepare(s.text).run(...s.args));sql.exec('COMMIT');return result;}catch(e){sql.exec('ROLLBACK');throw e;}}};
const tlsDir=mkdtempSync('/dev/shm/master7-ui-tls-');
execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',tlsDir+'/key.pem','-out',tlsDir+'/cert.pem','-days','1','-subj','/CN=127.0.0.1'],{stdio:'ignore'});
const server=createServer({key:readFileSync(tlsDir+'/key.pem'),cert:readFileSync(tlsDir+'/cert.pem')},async(req,res)=>{
 try{
  const origin='https://127.0.0.1:'+server.address().port,url=new URL(req.url,origin);
  if(url.pathname.startsWith('/api/')){
   const id=/m7fixture=(alice|bob|owner)/.exec(req.headers.cookie||'')?.[1],chunks=[];for await(const chunk of req)chunks.push(chunk);
   const response=await handle(new Request(url,{method:req.method,headers:req.headers,...(['GET','HEAD'].includes(req.method)?{}:{body:Buffer.concat(chunks)})}),{db,identity:id?{userId:id,email:id+'@example.test'}:null,ownerEmail:'',newDepositsEnabled:'false',newPayoutsEnabled:'false',newGameLaunchesEnabled:'false'});
   let data=await response.text();if(url.pathname.startsWith('/api/tickets')&&req.method==='POST')console.log('CHAT_HTTP',url.pathname,response.status,data.slice(0,350));if(url.pathname==='/api/session'){const session=JSON.parse(data);if(session.user)session.authMethod='password';data=JSON.stringify(session);}
   res.writeHead(response.status,Object.fromEntries(response.headers));res.end(data);return;
  }
  const file=url.pathname.startsWith('/assets/')||['/manifest.webmanifest','/service-worker.js','/offline.html'].includes(url.pathname)?resolve(root,'public','.'+url.pathname):resolve(root,'app/portal.html');
  if(!file.startsWith(root+'/')){res.writeHead(403);res.end();return;}
  const mime={'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};
  res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(readFileSync(file));
 }catch(e){res.writeHead(500);res.end(String(e));}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='https://127.0.0.1:'+server.address().port,browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const errors=[];let contexts=[];
async function pageFor(user,width,height){
 const context=await browser.newContext({viewport:{width,height},serviceWorkers:'block',ignoreHTTPSErrors:true});contexts.push(context);
 await context.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort());
 if(user)await context.addCookies([{name:'m7fixture',value:user,url:origin}]);
 const page=await context.newPage();page.on('pageerror',e=>{errors.push(e.message);console.log('PAGE_ERROR',e.message);});await page.goto(origin+(user==='owner'?'/admin':'/lobby'),{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>typeof state!=='undefined'&&state.user?.role===(location.pathname==='/admin'?'owner':'member'),{},{timeout:15000});console.log('READY',user,width);return page;
}
async function noOverflow(page){assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'page must fit viewport');}
try{
 const phone=await pageFor('alice',390,844);
 await phone.locator('#memberMenuToggle').waitFor({state:'visible'});await noOverflow(phone);
 await phone.screenshot({path:output+'/member-phone.png'});
 await phone.evaluate(()=>openDepositCashier('vpay'));await phone.locator('#depositCashier[open]').waitFor();await phone.screenshot({path:output+'/member-phone-cashier.png'});await phone.keyboard.press('Escape');
 await phone.locator('#memberMenuToggle').click();await phone.locator('#memberMenuDialog[open]').waitFor();
 assert.equal(await phone.locator('#memberMenuDialog [data-member-destination="admin"]').count(),0);
 await phone.screenshot({path:output+'/member-phone-menu.png'});
 await phone.keyboard.press('Escape');assert.equal(await phone.locator('#memberMenuToggle').getAttribute('aria-expanded'),'false');await phone.locator('#memberMenuToggle').click();
 await phone.locator('#memberMenuDialog [data-member-destination="member-verification"]').click();await phone.locator('#manualComplianceRequest').waitFor({state:'visible'});
 await phone.locator('#memberChatLauncher').click();await phone.locator('#memberChatInput').fill('你好');await phone.locator('#memberChatSend').click();
 await phone.waitForFunction(()=>document.getElementById('memberChatMessages').textContent.includes('你可以问我'));
 await phone.locator('#memberChatInput').fill('身份审核在哪里？');await phone.locator('#memberChatSend').click();
 await phone.waitForFunction(()=>document.getElementById('memberChatMessages').textContent.includes('菜单 → 身份审核'));
 await phone.screenshot({path:output+'/member-phone-chat.png'});
 const owner=await pageFor('owner',1440,1000);
 await owner.evaluate(()=>selected('support'));await owner.waitForFunction(()=>document.getElementById('tickets').textContent.includes('你好'));
 const ticket=sql.prepare("SELECT id FROM tickets WHERE user_id='alice'").get();
 await phone.locator('#memberChatHuman').click();await phone.waitForFunction(()=>document.getElementById('memberChatFeedback').textContent.includes('Human support requested'));
 const posted=await owner.evaluate(async id=>api('/api/tickets/reply','POST',{ticketId:id,message:'客服已收到你的留言，会在这里跟进。'}),ticket.id);assert.equal(posted.status,'ok');
 await phone.locator('#memberChatRefresh').click();await phone.waitForFunction(()=>document.getElementById('memberChatMessages').textContent.includes('客服已收到你的留言'));
 await owner.evaluate(()=>selected('admin'));await owner.locator('.admin-internal-sidebar').waitFor({state:'visible'});await noOverflow(owner);await owner.screenshot({path:output+'/admin-desktop.png'});
 const palette=await owner.locator('#adminStats .stat').first().evaluate(el=>({background:getComputedStyle(el).backgroundColor,font:getComputedStyle(el.querySelector('strong')).fontSize}));assert.equal(palette.background,'rgb(255, 255, 255)');assert.ok(parseFloat(palette.font)>=22);
 await owner.setViewportSize({width:390,height:844});await owner.waitForFunction(()=>document.querySelector('.admin-internal-sidebar').getBoundingClientRect().right<=0);await noOverflow(owner);await owner.screenshot({path:output+'/admin-phone.png'});await owner.locator('#adminMenuToggle').click();await owner.waitForFunction(()=>Math.abs(document.querySelector('.admin-internal-sidebar').getBoundingClientRect().left)<1);await owner.screenshot({path:output+'/admin-phone-menu.png'});await owner.locator('#adminMenuClose').click();await owner.setViewportSize({width:1440,height:1000});
 await owner.evaluate(()=>loadSupportAutomation());await owner.locator('#supportAiEnabled').waitFor({state:'attached'});assert.equal(await owner.locator('#supportAiEnabled').isChecked(),true);
 await owner.evaluate(()=>api('/api/admin/support-settings','POST',{aiEnabled:false,humanHandoff:true}));
 assert.equal((await phone.evaluate(()=>api('/api/support/status'))).aiRepliesEnabled,false);
 const desktop=await pageFor('bob',1440,1000);await noOverflow(desktop);await desktop.screenshot({path:output+'/member-desktop.png'});
 await desktop.locator('#memberChatLauncher').click();assert.ok(!(await desktop.locator('#memberChatMessages').innerText()).includes('你好'));
 await desktop.locator('#memberChatInput').fill('Hello');await desktop.locator('#memberChatSend').click();await desktop.waitForFunction(()=>document.getElementById('memberChatFeedback').textContent.includes('Message saved'));
 assert.equal(sql.prepare("SELECT COUNT(*) n FROM replies r JOIN tickets t ON t.id=r.ticket_id WHERE t.user_id='bob'").get().n,0);
 await phone.evaluate(()=>{state.user={id:'bob',username:'bob',role:'member',approved:true};window.Master7MemberServices.sessionChanged(state.user);});
 assert.equal(await phone.locator('#memberChatDialog').evaluate(el=>el.open),false);assert.equal(await phone.locator('#memberChatMessages').innerText(),'');
 await desktop.locator('#memberChatClose').click();await desktop.setViewportSize({width:360,height:800});await desktop.locator('#locale').selectOption('zh');await noOverflow(desktop);await desktop.locator('#memberMenuToggle').click();assert.equal(await desktop.locator('#memberMenuTitle').innerText(),'我的账户');await desktop.keyboard.press('Escape');
 await desktop.locator('#locale').selectOption('ms');await desktop.locator('#memberMenuToggle').click();assert.equal(await desktop.locator('#memberMenuTitle').innerText(),'Akaun saya');await desktop.keyboard.press('Escape');
 await desktop.evaluate(()=>{state.user=null;window.Master7MemberServices.sessionChanged(null);});assert.equal(await desktop.locator('#memberMenuToggle').isVisible(),false);assert.equal(await desktop.locator('#memberChatMessages').innerText(),'');
 assert.equal(sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 assert.deepEqual(errors,[],'no uncaught browser errors');
 console.log(JSON.stringify({passed:true,viewports:['360×800','390×844','1440×1000'],inboxRoundTrip:true,humanHandoff:true,aiOff:true,crossMemberIsolation:true,languages:['en','zh','ms'],walletWrites:0,output}));
}finally{for(const context of contexts)await context.close();await browser.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));sql.close();rmSync(tlsDir,{recursive:true,force:true});}
