import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {createVPayOrder,handleVPay,recoverVPayDeposits} from '../lib/vpay.ts';
import {createGSPayOrder,handleGSPayCallback,gspayPlayerUsername,gspayResultSignature,recoverGSPayDeposits} from '../lib/gspay.ts';
import {handleOneMpay,oneMpayCallbackToken,oneMpayCustomer,recoverOneMpayDeposits} from '../lib/onempay.ts';

// Destructive schema initialization is permitted only on a fresh, explicitly
// named local test database. This script refuses production or existing data.
const connection=process.env.MASTER7_ISOLATED_TEST_DATABASE_URL??'';
const target=new URL(connection);
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v16_recovery_test'||target.search||target.hash||!target.port)throw Error('A fresh loopback-only master7_v16_recovery_test database is required');
if(process.env.MASTER7_ISOLATED_POSTGRES_CONFIRM!=='master7_v16_recovery_test')throw Error('Explicit isolated test database confirmation is required');

test('isolated PostgreSQL payment callbacks and recoveries keep a single balanced ledger',async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:5});
 const previousUrl=process.env.PORTAL_POSTGRES_URL,previousSsl=process.env.PGSSLMODE,originalFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=originalFetch;if(previousUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=previousUrl;if(previousSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=previousSsl;});
 const identity=await pool.query("SELECT current_database() AS name,COUNT(*)::int AS tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,'master7_v16_recovery_test');assert.equal(identity.rows[0].tables,0,'test database must be empty');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat();
 await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES ('vp_user','vp_user','member',1,'fixture',0),('gs_user','gs_user','member',1,'fixture',0),('mp_user','mp_user','member',1,'fixture',0)");
 async function insert(id,user,provider,status='unknown'){
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES($1,$2,$3,'fixture',$4,2000,'MYR','bank',$5,NULL,0,0)",[id,user,'request-'+id,provider,status]);
 }
 async function ledger(id){
  const result=await pool.query('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=$1 ORDER BY account_code',[id]);return result.rows.map(row=>({...row,amount_minor:String(row.amount_minor)}));
 }

 await t.test('VPay saves a trusted callback reference after a query timeout and credits once on recovery',async()=>{
  const id='vp-pg-order',reference='vp-pg-trade',trader='fixture-trader',callbackToken='c'.repeat(40),gateway='https://master7-integration-gateway.onrender.com';await insert(id,'vp_user','vpay');
  let timeout=true,calls=0;const context={db,user:null,gatewayUrl:gateway,orderToken:'o'.repeat(40),queryToken:'q'.repeat(40),callbackToken,mode:'production',vpayTraderId:trader,returnUrl:'https://master7-v17-staging.onrender.com/payment/return',recoveryEnabled:'true',fetchImpl:async(input,init)=>{calls++;assert.equal(new URL(String(input)).pathname,'/platform/vpay/order-query');assert.equal(init.method,'POST');if(timeout)throw Error('synthetic timeout');return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:id,trade_no:reference,amount:'20.00',currency:'MYR',state:'3',trader_id:trader}}});}};
  const callback=await handleVPay(new Request('https://portal.example.test/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({out_trade_no:id,trade_no:reference,amount:'20.00',state:'3',trader_id:trader})}),context);
  assert.equal(callback.status,502);assert.equal((await pool.query('SELECT provider_trade_no FROM deposit_orders WHERE id=$1',[id])).rows[0].provider_trade_no,reference);assert.deepEqual(await ledger(id),[]);
  timeout=false;assert.equal((await recoverVPayDeposits(context)).credited,1);assert.equal((await recoverVPayDeposits(context)).scanned,0);assert.equal(calls,2);
  assert.deepEqual(await ledger(id),[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:'vp_user'},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:'vp_user'}]);
 });

 await t.test('a late VPay create rejection cannot override a reference bound by a callback',async()=>{
  const trader='fixture-trader',callbackToken='c'.repeat(40),gateway='https://master7-integration-gateway.onrender.com',reference='pg-race-reference';
  let release,signal,orderId='';const pending=new Promise(resolve=>{release=resolve;}),started=new Promise(resolve=>{signal=resolve;});
  const context={db,user:{id:'vp_user',username:'vp_user',role:'member',approved:1,csrf:'fixture'},gatewayUrl:gateway,orderToken:'o'.repeat(40),queryToken:'q'.repeat(40),callbackToken,enabled:'true',newDepositsEnabled:'true',mode:'production',vpayTraderId:trader,returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async(input,init)=>{
   const path=new URL(String(input)).pathname;if(path==='/platform/vpay/config')return Response.json({provider:'vpay',mode:'production',paymentReady:true,traderId:trader,notifyUrl:gateway+'/callbacks/vpay/payment',returnUrl:context.returnUrl,tradeCodes:['2']});
   if(path==='/platform/vpay/order'){orderId=JSON.parse(init.body).outTradeNo;signal();await pending;return Response.json({provider:'vpay',result:{code:-1,data:{}}});}
   assert.equal(path,'/platform/vpay/order-query');return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:orderId,trade_no:reference,trader_id:trader,amount:'20.00',currency:'MYR',state:'2'}}});
  }};
  const creating=createVPayOrder({amount:'20.00',tradeCode:'2',payerName:'fixture',requestKey:'pg-race-request-001'},context);await started;
  const callback=await handleVPay(new Request('https://portal.example.test/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({out_trade_no:orderId,trade_no:reference,amount:'20.00',state:'3',trader_id:trader})}),{...context,user:null});assert.equal(callback.status,502);release();
  const result=await creating;assert.equal(result.status,202);assert.equal((await result.json()).status,'awaiting_confirmation');const row=(await pool.query('SELECT status,provider_trade_no FROM deposit_orders WHERE id=$1',[orderId])).rows[0];assert.deepEqual(row,{status:'creating',provider_trade_no:reference});assert.deepEqual(await ledger(orderId),[]);
 });

 await t.test('GSPAY recovers an unknown order with no provider ID and concurrent workers cannot duplicate credit',async()=>{
  const id='G7pg-recovery-order',payment='35802335',authKey='a'.repeat(32),secret='b'.repeat(32);await insert(id,'gs_user','gspay');
  let calls=0,release,signal;const pending=new Promise(resolve=>{release=resolve;}),started=new Promise(resolve=>{signal=resolve;});
  const context={db,user:null,apiBase:'https://api.thegspay.com',authKey,secretKey:secret,returnUrl:'https://master7-v17-staging.onrender.com/payment/return',recoveryEnabled:'true',fetchImpl:async input=>{calls++;const url=new URL(String(input));assert.equal(url.searchParams.get('transaction_id'),id);signal();await pending;return Response.json({code:200,data:JSON.stringify([{payment_id:payment,transaction_id:id,player_username:gspayPlayerUsername('gs_user'),amount:'20.00',currency:'MYR',completed:true,success:true,signature:gspayResultSignature(payment,'20.00',id,secret)}])});}};
  const first=recoverGSPayDeposits(context);await started;const second=await recoverGSPayDeposits(context);release();const settled=await first;
  assert.equal(settled.credited,1);assert.equal(second.scanned,0);assert.equal(calls,1);assert.equal((await pool.query('SELECT provider_trade_no FROM deposit_orders WHERE id=$1',[id])).rows[0].provider_trade_no,payment);
  assert.deepEqual(await ledger(id),[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:'gs_user'},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:'gs_user'}]);
 });

 for(const outcome of ['credited','failed','review'])await t.test(`GSPAY delayed create response cannot expose checkout after callback ${outcome}`,async sub=>{
  const payment={credited:'35802336',failed:'35802337',review:'35802338'}[outcome],authKey='a'.repeat(32),secret='b'.repeat(32),player=gspayPlayerUsername('gs_user');
  let release,signal,orderId='',queries=0;const pending=new Promise(resolve=>{release=resolve;}),started=new Promise(resolve=>{signal=resolve;});sub.after(()=>release());
  const context={db,user:{id:'gs_user',username:'gs_user',role:'member',approved:1},apiBase:'https://api.thegspay.com',authKey,secretKey:secret,enabled:'true',newDepositsEnabled:'true',returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async(input,init)=>{
   const url=new URL(String(input));assert.equal(url.origin,'https://api.thegspay.com');
   if(url.pathname.endsWith('/payment')){orderId=JSON.parse(init.body).transaction_id;signal();await pending;return Response.json({code:200,data:JSON.stringify([{payment_id:payment,payment_url:`https://secured.gspay.online/channel?id=${payment}&key=${'c'.repeat(32)}`}])});}
   assert.ok(url.pathname.endsWith('/getpayment'));assert.equal(url.searchParams.get('transaction_id'),orderId);queries++;
   return Response.json({code:200,data:JSON.stringify([{payment_id:payment,transaction_id:orderId,player_username:outcome==='review'?'other-player':player,amount:'20.00',currency:'MYR',completed:true,success:outcome!=='failed',signature:gspayResultSignature(payment,'20.00',orderId,secret)}])});
  }};
  const creating=createGSPayOrder({amount:'20.00',requestKey:`gspay-pg-race-${outcome}-0001`},context);await started;
  const callback=await handleGSPayCallback(new Request('https://portal.example.test/api/payment/gspay/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({auth_key:authKey,success:true,completed:true,payment_id:payment,transaction_id:orderId,player_username:player,amount:'20.00',signature:gspayResultSignature(payment,'20.00',orderId,secret)})}),{...context,user:null});
  assert.equal(callback.status,outcome==='review'?503:200,JSON.stringify({queries,row:(await pool.query('SELECT status,provider_trade_no FROM deposit_orders WHERE id=$1',[orderId])).rows[0]}));assert.equal(queries,1);
  assert.equal((await pool.query('SELECT status FROM deposit_orders WHERE id=$1',[orderId])).rows[0].status,outcome);
  release();const result=await creating,body=await result.json();assert.equal(result.status,outcome==='credited'?200:202);assert.equal(body.status,outcome==='credited'?'credited':'awaiting_confirmation');assert.equal(body.payUrl,null);
  const row=(await pool.query('SELECT status,provider_trade_no,checkout_url FROM deposit_orders WHERE id=$1',[orderId])).rows[0];assert.equal(row.status,outcome);assert.equal(row.checkout_url,null);assert.equal(row.provider_trade_no,outcome==='review'?null:payment);
  assert.deepEqual(await ledger(orderId),outcome==='credited'?[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:'gs_user'},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:'gs_user'}]:[]);
 });

 await t.test('1MPay retains a signed callback reference and later completes one balanced credit',async()=>{
  const id='M7pg-recovery-order',reference='mp-pg-trade',merchant='TESTMERCHANT',secret='fixture-secret-12345678',customer=oneMpayCustomer('mp_user');await insert(id,'mp_user','1mpay');
  let timeout=true,calls=0;const context={db,user:null,apiBase:'https://api.1mpay.net',merchant,secretKey:secret,callbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',returnUrl:'https://master7-v17-staging.onrender.com/payment/return',recoveryEnabled:'true',fetchImpl:async()=>{calls++;if(timeout)throw Error('synthetic timeout');return Response.json({merchant,amount:'20.00',refid:id,customer,trxno:reference,currency:'MYR',status:'Successful',token:oneMpayCallbackToken(merchant,'20.00',id,customer,secret,reference)});}};
  const callback=await handleOneMpay(new Request('https://portal.example.test/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({merchant,amount:'20.00',refid:id,customer,trxno:reference,status:'Successful',token:oneMpayCallbackToken(merchant,'20.00',id,customer,secret,reference)})}),context);
  assert.equal(callback.status,503);assert.equal((await pool.query('SELECT provider_trade_no FROM deposit_orders WHERE id=$1',[id])).rows[0].provider_trade_no,reference);assert.deepEqual(await ledger(id),[]);
  await pool.query('UPDATE deposit_orders SET updated_at=0 WHERE id=$1',[id]);timeout=false;assert.equal((await recoverOneMpayDeposits(context)).credited,1);assert.equal((await recoverOneMpayDeposits(context)).scanned,0);assert.equal(calls,2);
  assert.deepEqual(await ledger(id),[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:'mp_user'},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:'mp_user'}]);
  const missing='M7pg-missing-ref';await insert(missing,'mp_user','1mpay');const missingResult=await recoverOneMpayDeposits(context);assert.equal(missingResult.review,1);assert.equal((await pool.query('SELECT status FROM deposit_orders WHERE id=$1',[missing])).rows[0].status,'review');
 });

 await t.test('the current ledger schema rejects a non-MYR deposit',async()=>{
  await assert.rejects(pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('bad-currency','gs_user','bad-currency','fixture','gspay',2000,'USDT','bank','unknown',0,0)"),/check constraint/i);
 });
});
