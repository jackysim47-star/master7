import {readFile,mkdir,writeFile,rename,rm,stat,lstat} from 'node:fs/promises';
import {resolve,dirname,join} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {reconcileStatements} from '../lib/reconciliation.ts';

const hash=b=>createHash('sha256').update(b).digest('hex');
const csv=value=>{const s=String(value??'');return '"'+(/^[=+\-@\t\r]/.test(s)?"'"+s:s).replaceAll('"','""')+'"';};
async function run(){
 const args=process.argv.slice(2);
 if(args.length!==4||args[0]!=='--input'||args[2]!=='--output')throw Error('Usage: node scripts/reconcile-statements.mjs --input canonical.json --output NEW_REPORT_DIRECTORY');
 const source=resolve(args[1]),destination=resolve(args[3]);
 const info=await stat(source);if(!info.isFile()||info.size>10*1024*1024)throw Error('Input must be a JSON file of at most 10 MiB');
 const raw=await readFile(source);if(raw.length>10*1024*1024)throw Error('Input exceeds 10 MiB');
 const report=reconcileStatements(JSON.parse(raw.toString('utf8')));
 // Refuse to replace existing artifacts, including symlinks. Use an atomic
 // publication from an owned temporary directory; never remove user output.
 try{await lstat(destination);throw Error('Output directory already exists');}catch(e){if(e.code!=='ENOENT')throw e;}
 await mkdir(dirname(destination),{recursive:true});
 const temporary=join(dirname(destination),'.reconciliation-'+randomUUID());await mkdir(temporary);
 try{
  const engine=await readFile(new URL('../lib/reconciliation.ts',import.meta.url));
  await writeFile(join(temporary,'reconciliation_report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  await writeFile(join(temporary,'input_manifest.json'),JSON.stringify({sourceReference:source,inputSha256:hash(raw),engineSha256:hash(engine),snapshotId:report.internalSnapshotId,sourceCommit:report.sourceCommit,scope:report.scope},null,2)+'\n',{flag:'wx'});
  const columns=['domain','scope','classification','reasonCode','internalReferences','externalReferences','amountDifferenceMinor','evidenceReferences','reviewStatus'];
  const rows=report.discrepancies.map(d=>columns.map(k=>csv(Array.isArray(d[k])?d[k].join(';'):d[k])).join(','));
  await writeFile(join(temporary,'discrepancies.csv'),columns.join(',')+'\n'+rows.join('\n')+'\n',{flag:'wx'});
  await writeFile(join(temporary,'owner_review.json'),JSON.stringify({runId:report.runId,status:'pending',verifiedBy:null,observedAtMYT:null,decision:null,evidenceReferences:[],financialActions:[]},null,2)+'\n',{flag:'wx'});
  const files=['reconciliation_report.json','input_manifest.json','discrepancies.csv','owner_review.json'];
  await writeFile(join(temporary,'SHA256SUMS.txt'),(await Promise.all(files.map(async f=>hash(await readFile(join(temporary,f)))+'  '+f))).join('\n')+'\n',{flag:'wx'});
  await mkdir(destination); // Atomic exclusive reservation also closes the existence-check race.
  await rename(temporary,destination);
 }catch(e){await rm(temporary,{recursive:true,force:true});throw e;}
 process.stdout.write(JSON.stringify({runId:report.runId,result:report.result,output:destination,financialActions:[]})+'\n');
}
run().catch(()=>{process.stderr.write('Reconciliation failed: invalid input or unavailable output; no financial actions were performed.\n');process.exitCode=1;});
