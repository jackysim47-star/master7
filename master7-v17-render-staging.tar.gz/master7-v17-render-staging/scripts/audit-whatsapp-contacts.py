#!/usr/bin/env python3
"""Aggregate-only quality audit for a WhatsApp contact CSV.

The script never prints or writes contact values. It reports only counts,
rates, column names, and a file checksum so the source remains inspectable.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path


PHONE_NAMES = {"phone", "mobile", "mobile_number", "phone_number", "msisdn", "contact"}
CONSENT_NAMES = {
    "consent",
    "opt_in",
    "optin",
    "marketing_consent",
    "whatsapp_consent",
    "consent_at",
    "opt_in_at",
}
SUPPRESSION_NAMES = {
    "opt_out",
    "optout",
    "unsubscribe",
    "unsubscribed",
    "suppressed",
    "suppression",
    "do_not_contact",
    "dnc",
}
MY_MOBILE = re.compile(r"^601\d{8,9}$")
PLAUSIBLE_E164 = re.compile(r"^[1-9]\d{7,14}$")


def normalized_header(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.strip().lower()).strip("_")


def normalized_phone(value: str) -> tuple[str, str]:
    raw = value.strip()
    digits = re.sub(r"\D", "", raw)
    source_format = "other"
    if digits.startswith("0060"):
        digits = digits[2:]
        source_format = "0060"
    elif raw.startswith("+") and digits.startswith("60"):
        source_format = "+60"
    elif digits.startswith("60"):
        source_format = "60"
    elif digits.startswith("0"):
        digits = "60" + digits[1:]
        source_format = "local_0"
    elif digits.startswith("1") and len(digits) in {9, 10}:
        digits = "60" + digits
        source_format = "bare_local"
    return digits, source_format


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def audit(path: Path) -> dict[str, object]:
    with path.open("rb") as binary_source:
        newline_sample = binary_source.read(1024 * 1024)
    if b"\r\n" in newline_sample:
        line_endings = "CRLF"
    elif b"\n" in newline_sample:
        line_endings = "LF"
    elif b"\r" in newline_sample:
        line_endings = "CR"
    else:
        line_endings = "unknown"
    with path.open("r", encoding="utf-8-sig", newline="") as source:
        first_line = source.readline()
        if not first_line:
            raise ValueError("CSV is empty")
        delimiter_counts = {delimiter: first_line.count(delimiter) for delimiter in (",", ";", "\t", "|")}
        delimiter = max(delimiter_counts, key=delimiter_counts.get)
        if delimiter_counts[delimiter] == 0:
            delimiter = ","
        source.seek(0)
        reader = csv.reader(source, delimiter=delimiter)
        headers = next(reader)
        normalized_headers = [normalized_header(header) for header in headers]
        phone_indexes = [index for index, name in enumerate(normalized_headers) if name in PHONE_NAMES]
        if not phone_indexes and len(headers) == 1:
            phone_indexes = [0]
        if len(phone_indexes) != 1:
            raise ValueError(f"Expected one phone column; found {len(phone_indexes)}")
        phone_index = phone_indexes[0]

        total_rows = 0
        blank_rows = 0
        malformed_rows = 0
        blank_phone = 0
        exact_counts: Counter[str] = Counter()
        normalized_counts: Counter[str] = Counter()
        format_counts: Counter[str] = Counter()
        valid_my = 0
        valid_my_normalized: set[str] = set()
        plausible_foreign = 0
        invalid = 0

        for row in reader:
            total_rows += 1
            if not row or all(not cell.strip() for cell in row):
                blank_rows += 1
                continue
            if len(row) != len(headers):
                malformed_rows += 1
            value = row[phone_index] if phone_index < len(row) else ""
            if not value.strip():
                blank_phone += 1
                continue
            exact_counts[value] += 1
            normalized, source_format = normalized_phone(value)
            format_counts[source_format] += 1
            if normalized:
                normalized_counts[normalized] += 1
            if MY_MOBILE.fullmatch(normalized):
                valid_my += 1
                valid_my_normalized.add(normalized)
            elif PLAUSIBLE_E164.fullmatch(normalized):
                plausible_foreign += 1
            else:
                invalid += 1

    nonblank_phone = total_rows - blank_rows - blank_phone
    exact_duplicate_rows = sum(count - 1 for count in exact_counts.values() if count > 1)
    normalized_duplicate_rows = sum(count - 1 for count in normalized_counts.values() if count > 1)
    consent_columns = [headers[index] for index, name in enumerate(normalized_headers) if name in CONSENT_NAMES]
    suppression_columns = [headers[index] for index, name in enumerate(normalized_headers) if name in SUPPRESSION_NAMES]

    def rate(count: int, denominator: int = nonblank_phone) -> float:
        return round(count / denominator * 100, 4) if denominator else 0.0

    return {
        "file": {
            "name": path.name,
            "bytes": path.stat().st_size,
            "sha256": file_sha256(path),
            "encoding": "UTF-8/ASCII-compatible",
            "line_endings": line_endings,
            "delimiter": "single-column" if len(headers) == 1 else delimiter,
        },
        "schema": {
            "column_count": len(headers),
            "headers": headers,
            "phone_column": headers[phone_index],
            "consent_columns": consent_columns,
            "suppression_columns": suppression_columns,
        },
        "rows": {
            "data_rows": total_rows,
            "blank_rows": blank_rows,
            "malformed_rows": malformed_rows,
            "blank_phone_rows": blank_phone,
            "nonblank_phone_rows": nonblank_phone,
        },
        "uniqueness": {
            "unique_exact_phone_values": len(exact_counts),
            "exact_duplicate_rows": exact_duplicate_rows,
            "exact_duplicate_rate_pct": rate(exact_duplicate_rows),
            "unique_normalized_phone_values": len(normalized_counts),
            "normalized_duplicate_rows": normalized_duplicate_rows,
            "normalized_duplicate_rate_pct": rate(normalized_duplicate_rows),
        },
        "validity": {
            "valid_malaysian_mobile_rows": valid_my,
            "valid_malaysian_mobile_rate_pct": rate(valid_my),
            "plausible_foreign_e164_rows": plausible_foreign,
            "plausible_foreign_e164_rate_pct": rate(plausible_foreign),
            "invalid_phone_rows": invalid,
            "invalid_phone_rate_pct": rate(invalid),
            "source_format_counts": dict(sorted(format_counts.items())),
        },
        "campaign_readiness": {
            "has_explicit_consent_field": bool(consent_columns),
            "has_opt_out_or_suppression_field": bool(suppression_columns),
            "eligible_by_phone_format_only": len(valid_my_normalized),
            "eligible_by_phone_format_only_note": "Format validity is not proof of WhatsApp ownership or marketing consent.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit(args.csv_path)
    payload = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.write_text(payload, encoding="utf-8")
    else:
        print(payload, end="")


if __name__ == "__main__":
    main()
