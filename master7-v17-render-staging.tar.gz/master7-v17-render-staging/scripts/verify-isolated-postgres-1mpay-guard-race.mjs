import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {handleOneMpay,oneMpayCallbackToken,oneMpayCustomer} from '../lib/onempay.ts';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

// Schema initialization is allowed only for a fresh explicitly named local DB.
const name='master7_v22_1mpay_guard_test';
const target=new URL(process.env.MASTER7_ISOLATED_1MPAY_GUARD_DATABASE_URL??'');
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!==`/${name}`||target.search||target.hash||!target.port)throw Error('A fresh loopback-only 1MPay guard test database is required');
if(process.env.MASTER7_ISOLATED_1MPAY_GUARD_CONFIRM!==name)throw Error('Explicit isolated 1MPay guard confirmation is required');
const gate=()=>{let signal,release;return {ready:new Promise(resolve=>{signal=resolve;}),wait:new Promise(resolve=>{release=resolve;}),signal:()=>signal(),release:()=>release()};};

test('1MPay guarded callback reconciles lock-time ledger changes on isolated PostgreSQL',async t=>{
 const connection=target.toString(),pool=new pg.Pool({connectionString:connection,ssl:false,max:6});
 const oldUrl=process.env.PORTAL_POSTGRES_URL,oldSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(oldUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=oldUrl;if(oldSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=oldSsl;});
 const identity=await pool.query("SELECT current_database() name,COUNT(*)::int tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,name);assert.equal(identity.rows[0].tables,0,'test database must be empty');
 await initializePortalDatabase(pool,await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8')));
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat(),merchant='TESTMERCHANT',secret='fixture-secret-12345678';
 async function seed(user,id,reference){
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'fixture',0)",[user]);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES($1,$2,$3,'fixture','1mpay',2000,'MYR','bank','unknown',$4,0,0)",[id,user,'request-'+id,reference]);
 }
 async function state(id){
  const order=(await pool.query('SELECT status,provider_trade_no FROM deposit_orders WHERE id=$1',[id])).rows[0];
  const entries=(await pool.query('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=$1 ORDER BY account_code',[id])).rows.map(x=>({...x,amount_minor:String(x.amount_minor)}));
  return {order,entries};
 }
 function announceBatchDb(control){let announced=false;return {prepare:db.prepare.bind(db),batch(statements){if(!announced){announced=true;control.signal();}return db.batch(statements);}};}
 function callback(user,refid,trxno,dbOverride=db,control={}){
  const customer=oneMpayCustomer(user),token=oneMpayCallbackToken(merchant,'20.00',refid,customer,secret,trxno);
  const context={db:dbOverride,user:null,apiBase:'https://api.1mpay.net',merchant,secretKey:secret,callbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async input=>{
   const url=new URL(String(input));assert.equal(url.origin,'https://api.1mpay.net');assert.ok(url.pathname.startsWith('/transquery/'));
   if(control.queryGate){control.queryGate.signal();await control.queryGate.wait;}
   return Response.json({merchant,amount:'20.00',refid,customer,trxno,currency:'MYR',status:control.queryStatus??'Successful',token});
  }};
  return ()=>handleOneMpay(new Request('https://portal.example.test/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({merchant,amount:'20.00',refid,customer,trxno,status:'Successful',token})}),context);
 }
 await t.test('wrong existing member leg committed while callback waits stays untouched and requires review',{timeout:15000},async sub=>{
  const user='mp-guard-user',id='M7guard-callback',reference='mp-guard-ref';await seed(user,id,reference);
  // An additional valid deposit demonstrates that the review blocks other funds.
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('safe-mp-credit',$1,'safe-mp-request','fixture','manual_bank',5000,'MYR','bank','credited',0,0)",[user]);
  await pool.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('safe-mp-member','safe-mp-credit',$1,'member',5000,'MYR',0),('safe-mp-clear','safe-mp-credit',$1,'provider_clearing',-5000,'MYR',0)",[user]);
  const control=gate(),client=await pool.connect();let finished=false;
  sub.after(async()=>{control.release();if(!finished)await client.query('ROLLBACK');client.release();});
  await client.query('BEGIN');await client.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);await client.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);
  const pending=callback(user,id,reference,announceBatchDb(control))();await control.ready;
  await client.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('mp-guard-conflict',$1,$2,'member',1999,'MYR',0)",[id,user]);
  await client.query('COMMIT');finished=true;const response=await pending;
  assert.notEqual(response.status,200);assert.notEqual(await response.text(),'ok');
  assert.deepEqual(await state(id),{order:{status:'review',provider_trade_no:reference},entries:[{account_code:'member',amount_minor:'1999',currency:'MYR',user_id:user}]});
  const wallet=await withdrawalWalletState(db,user);assert.equal(wallet.balanceMinor,'5000');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 });
 await t.test('a failed order observed after a successful query starts cannot be credited',{timeout:15000},async sub=>{
  const user='mp-late-success-user',id='M7late-success',reference='mp-late-success-ref';await seed(user,id,reference);
  const queryGate=gate();sub.after(()=>queryGate.release());
  const pending=callback(user,id,reference,db,{queryGate})();await queryGate.ready;
  const client=await pool.connect();try{await client.query('BEGIN');await client.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);await client.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);await client.query("UPDATE deposit_orders SET status='failed' WHERE id=$1 AND user_id=$2",[id,user]);await client.query('COMMIT');}catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}
  queryGate.release();const response=await pending;assert.notEqual(response.status,200);assert.notEqual(await response.text(),'ok');
  assert.deepEqual(await state(id),{order:{status:'review',provider_trade_no:reference},entries:[]});
 });
 await t.test('a pending query arriving after concurrent credit preserves ledger and raises review',{timeout:15000},async sub=>{
  const user='mp-late-pending-user',id='M7late-pending',reference='mp-late-pending-ref';await seed(user,id,reference);
  const queryGate=gate();sub.after(()=>queryGate.release());
  const pending=callback(user,id,reference,db,{queryGate,queryStatus:'Pending'})();await queryGate.ready;
  const credited=await callback(user,id,reference)();assert.equal(credited.status,200);assert.equal(await credited.text(),'ok');
  queryGate.release();const response=await pending;assert.notEqual(response.status,200);assert.notEqual(await response.text(),'ok');
  assert.deepEqual(await state(id),{order:{status:'review',provider_trade_no:reference},entries:[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:user},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:user}]});
  const wallet=await withdrawalWalletState(db,user);assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 });
 await t.test('concurrent valid duplicate callbacks yield exactly one balanced ledger',{timeout:15000},async()=>{
  const user='mp-duplicate-user',id='M7duplicate-guard',reference='mp-duplicate-ref';await seed(user,id,reference);
  const send=callback(user,id,reference),responses=await Promise.all([send(),send(),send()]);
  assert.ok(responses.some(response=>response.status===200));
  assert.deepEqual(await state(id),{order:{status:'credited',provider_trade_no:reference},entries:[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:user},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:user}]});
 });
});
