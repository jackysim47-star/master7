import {initializePortalDatabase} from '../lib/render-migrations.mjs';

export async function withRollbackOnlyTransaction(client,restore){
 let began=false;
 try{
  await client.connect();
  await client.query('BEGIN');began=true;
  return await restore();
 }finally{
  // A rollback error must prevent a successful receipt. Closing is attempted
  // even when rollback fails, so the connection cannot retain the transaction.
  try{if(began)await client.query('ROLLBACK');}
  finally{await client.end();}
 }
}

// Inspect statement starts, including batches, without treating function bodies,
// quoted values or comments as SQL transaction boundaries. Fail closed on an
// ambiguous literal instead of letting a future schema file commit the rehearsal.
function assertNoTransactionControl(sql){
 let i=0,start=true;
 while(i<sql.length){
  if(/\s/.test(sql[i])){i++;continue;}
  if(sql.startsWith('--',i)){const end=sql.indexOf('\n',i+2);i=end<0?sql.length:end+1;continue;}
  if(sql.startsWith('/*',i)){
   let depth=1;i+=2;
   while(i<sql.length&&depth){if(sql.startsWith('/*',i)){depth++;i+=2;}else if(sql.startsWith('*/',i)){depth--;i+=2;}else i++;}
   if(depth)throw new Error('Unterminated restore bootstrap SQL comment');
   continue;
  }
  if(sql[i]===';'){start=true;i++;continue;}
  if(start){
   const word=sql.slice(i).match(/^[a-z_]+/i)?.[0]??'';
   if(/^(?:BEGIN|START|COMMIT|END|ROLLBACK|ABORT|SAVEPOINT|RELEASE|PREPARE)$/i.test(word))throw new Error('Unsupported restore bootstrap transaction statement');
   start=false;
  }
  if(sql[i]==="'"||sql[i]==='"'){
   const quote=sql[i],escapes=quote==="'"&&/[eE]/.test(sql[i-1]??'')&&!/[a-z0-9_$]/i.test(sql[i-2]??'');
   let closed=false;i++;
   while(i<sql.length){
    if(sql[i]==='\\'&&quote==="'"){
     if(!escapes)throw new Error('Ambiguous restore bootstrap SQL literal');
     i+=2;continue;
    }
    if(sql[i]===quote){if(sql[i+1]===quote){i+=2;continue;}i++;closed=true;break;}
    i++;
   }
   if(!closed)throw new Error('Unterminated restore bootstrap SQL literal');
   continue;
  }
  const tag=sql[i]==='$'?sql.slice(i).match(/^\$(?:[a-z_][a-z0-9_]*)?\$/i)?.[0]:null;
  if(tag){const end=sql.indexOf(tag,i+tag.length);if(end<0)throw new Error('Unterminated restore bootstrap SQL body');i=end+tag.length;continue;}
  i++;
 }
}

// The caller already owns a rollback-only transaction in a fresh schema.
// Reuse the production schema initializer without allowing its transaction
// boundaries to commit or abort that outer transaction.
export async function initializeRehearsalSchema(client,schema,directoryEntries){
 let active=false;
 const isolated={
  async query(sql,params){
   if(typeof sql!=='string')throw new Error('Restore bootstrap requires SQL text');
   const statement=String(sql).trim().replace(/;$/,'').toUpperCase();
   if(statement==='BEGIN'){
    if(active)throw new Error('Nested restore bootstrap transaction');
    active=true;
    return client.query('SAVEPOINT master7_restore_bootstrap');
   }
   if(statement==='COMMIT'){
    if(!active)throw new Error('Restore bootstrap has no active savepoint');
    const result=await client.query('RELEASE SAVEPOINT master7_restore_bootstrap');
    active=false;
    return result;
   }
   if(statement==='ROLLBACK'){
    if(!active)throw new Error('Restore bootstrap has no active savepoint');
    await client.query('ROLLBACK TO SAVEPOINT master7_restore_bootstrap');
    const result=await client.query('RELEASE SAVEPOINT master7_restore_bootstrap');
    active=false;
    return result;
   }
   assertNoTransactionControl(sql);
   return client.query(sql,params);
  },
  release(){},
 };
 const result=await initializePortalDatabase({connect:async()=>isolated},schema,directoryEntries);
 if(active)throw new Error('Restore bootstrap did not finish its savepoint');
 return result;
}
