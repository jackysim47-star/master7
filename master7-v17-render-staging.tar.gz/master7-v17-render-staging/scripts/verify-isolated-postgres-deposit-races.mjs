import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {initializePortalDatabase} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {handleVPay} from '../lib/vpay.ts';
import {handleGSPayCallback,gspayPlayerUsername,gspayResultSignature} from '../lib/gspay.ts';

// Never initialize anything except an explicitly confirmed, fresh loopback DB.
const name='master7_v21_deposit_race_test';
const target=new URL(process.env.MASTER7_ISOLATED_DEPOSIT_RACE_DATABASE_URL??'');
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!==`/${name}`||target.search||target.hash||!target.port)throw Error('A fresh loopback-only deposit race database is required');
if(process.env.MASTER7_ISOLATED_DEPOSIT_RACE_CONFIRM!==name)throw Error('Explicit isolated deposit race confirmation is required');
const gate=()=>{let signal,release;return {ready:new Promise(resolve=>{signal=resolve;}),wait:new Promise(resolve=>{release=resolve;}),signal:()=>signal(),release:()=>release()};};

test('VPay and GSPAY callbacks bind current orders and ledgers on isolated PostgreSQL',async t=>{
 const pool=new pg.Pool({connectionString:target.toString(),ssl:false,max:6});
 const oldUrl=process.env.PORTAL_POSTGRES_URL,oldSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(oldUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=oldUrl;if(oldSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=oldSsl;});
 const identity=await pool.query("SELECT current_database() name,COUNT(*)::int tables FROM information_schema.tables WHERE table_schema='public'");
 assert.equal(identity.rows[0].name,name);assert.equal(identity.rows[0].tables,0,'test database must be empty');
 await initializePortalDatabase(pool,await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8')));
 process.env.PORTAL_POSTGRES_URL=target.toString();process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};
 const db=new RenderD1Compat(),gateway='https://master7-integration-gateway.onrender.com',returnUrl='https://master7-v17-staging.onrender.com/payment/return';
 const trader='fixture-trader',callbackToken='c'.repeat(40),authKey='a'.repeat(32),secret='b'.repeat(32);
 async function seed(user,id,provider,reference,status='unknown'){
  await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'fixture',0)",[user]);
  await pool.query("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES($1,$2,$3,'fixture',$4,2000,'MYR','bank',$5,$6,0,0)",[id,user,'request-'+id,provider,status,reference]);
  if(status==='credited')await pool.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES($1,$2,$3,'member',2000,'MYR',0),($4,$2,$3,'provider_clearing',-2000,'MYR',0)",['member-'+id,id,user,'clearing-'+id]);
 }
 async function ledger(id){return (await pool.query('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=$1 ORDER BY account_code',[id])).rows.map(x=>({...x,amount_minor:String(x.amount_minor)}));}
 async function markReview(user,id){
  const client=await pool.connect();try{await client.query('BEGIN');await client.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);await client.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);await client.query("UPDATE deposit_orders SET status='review' WHERE id=$1 AND user_id=$2",[id,user]);await client.query('COMMIT');}catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}
 }
 // Pause only after the callback has read an actual old order snapshot. The
 // rest of the callback executes against the real database after the change.
 function staleReadDb(provider,control){
  let paused=false;
  return {prepare(sql){const statement=db.prepare(sql);const match=provider==='vpay'?sql==='SELECT * FROM deposit_orders WHERE id=? AND provider=?':sql==="SELECT * FROM deposit_orders WHERE id=? AND provider='gspay'";
   if(!match)return statement;
   return {bind(...args){const bound=statement.bind(...args);return {async first(){const row=await bound.first();if(!paused){paused=true;control.signal();await control.wait;}return row;}};}};
  },batch:db.batch.bind(db)};
 }
 // Let a callback complete its preliminary order/ledger read, then announce
 // its real batch before it waits on a guard held by the other PG connection.
 function announceBatchDb(control){
  let announced=false;
  return {prepare:db.prepare.bind(db),batch(statements){if(!announced){announced=true;control.signal();}return db.batch(statements);}};
 }
 function fixture(provider,user,id,reference,{dbOverride=db,queryGate=null}={}){
  if(provider==='vpay'){
   const context={db:dbOverride,user:null,gatewayUrl:gateway,orderToken:'o'.repeat(40),queryToken:'q'.repeat(40),callbackToken,mode:'production',vpayTraderId:trader,returnUrl,fetchImpl:async input=>{
    assert.equal(new URL(String(input)).pathname,'/platform/vpay/order-query');if(queryGate){queryGate.signal();await queryGate.wait;}
    return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:id,trade_no:reference,amount:'20.00',currency:'MYR',state:'3',trader_id:trader}}});
   }};
   return ()=>handleVPay(new Request('https://portal.example.test/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({out_trade_no:id,trade_no:reference,amount:'20.00',state:'3',trader_id:trader})}),context);
  }
  const player=gspayPlayerUsername(user),signature=gspayResultSignature(reference,'20.00',id,secret);
  const context={db:dbOverride,user:null,apiBase:'https://api.thegspay.com',authKey,secretKey:secret,returnUrl,fetchImpl:async input=>{
   const url=new URL(String(input));assert.equal(url.origin,'https://api.thegspay.com');assert.ok(url.pathname.endsWith('/getpayment'));assert.equal(url.searchParams.get('transaction_id'),id);
   if(queryGate){queryGate.signal();await queryGate.wait;}
   return Response.json({code:200,data:JSON.stringify([{payment_id:reference,transaction_id:id,player_username:player,amount:'20.00',currency:'MYR',completed:true,success:true,signature}])});
  }};
  return ()=>handleGSPayCallback(new Request('https://portal.example.test/api/payment/gspay/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({auth_key:authKey,completed:true,success:true,payment_id:reference,transaction_id:id,player_username:player,amount:'20.00',signature})}),context);
 }
 for(const [provider,reference] of [['vpay','race-ref-vpay'],['gspay','35803371']]){
  await t.test(`${provider}: a reviewed order cannot receive a stale success acknowledgment`,{timeout:15000},async sub=>{
   const user=`${provider}-review-user`,id=`${provider}-review-order`;await seed(user,id,provider,reference,'credited');
   const control=gate();sub.after(()=>control.release());const callback=fixture(provider,user,id,reference,{dbOverride:staleReadDb(provider,control)});
   const pending=callback();await control.ready;await markReview(user,id);control.release();const response=await pending;
   assert.notEqual(response.status,200);const order=(await pool.query('SELECT status FROM deposit_orders WHERE id=$1',[id])).rows[0];assert.equal(order.status,'review');
   assert.deepEqual(await ledger(id),[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:user},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:user}]);
  });
  for(const change of ['amount','owner'])await t.test(`${provider}: ${change} changed during authenticated query cannot post or acknowledge`,{timeout:15000},async sub=>{
   const user=`${provider}-${change}-user`,id=`${provider}-${change}-order`,ref=provider==='vpay'?`vpay-${change}-ref`:change==='amount'?'35803372':'35803373';await seed(user,id,provider,ref);
   const control=gate();sub.after(()=>control.release());const callback=fixture(provider,user,id,ref,{queryGate:control});const pending=callback();await control.ready;
   if(change==='amount')await pool.query('UPDATE deposit_orders SET amount_minor=3000 WHERE id=$1',[id]);
   else{const other=`${provider}-other-user`;await pool.query("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES($1,$1,'member',1,'fixture',0)",[other]);await pool.query('UPDATE deposit_orders SET user_id=$1 WHERE id=$2',[other,id]);}
   control.release();const response=await pending;assert.notEqual(response.status,200);assert.deepEqual(await ledger(id),[]);
  });
  await t.test(`${provider}: an incomplete ledger committed while the callback waits on the member guard cannot be credited`,{timeout:15000},async sub=>{
   const user=`${provider}-guard-user`,id=`${provider}-guard-order`,ref=provider==='vpay'?'vpay-guard-reference':'35803375';await seed(user,id,provider,ref);
   const control=gate(),client=await pool.connect();let finished=false;
   sub.after(async()=>{control.release();if(!finished)await client.query('ROLLBACK');client.release();});
   await client.query('BEGIN');await client.query('INSERT INTO member_wallet_guards(user_id,revision) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING',[user]);await client.query('UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id=$1',[user]);
   const callback=fixture(provider,user,id,ref,{dbOverride:announceBatchDb(control)}),pending=callback();await control.ready;
   // An earlier writer owns the same guard and commits a partial/wrong entry.
   // The callback must reevaluate in its own transaction after acquiring it.
   await client.query("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES($1,$2,$3,'member',1999,'MYR',0)",['broken-'+id,id,user]);
   await client.query('COMMIT');finished=true;const response=await pending;
   assert.notEqual(response.status,200);
   assert.equal((await pool.query('SELECT status FROM deposit_orders WHERE id=$1',[id])).rows[0].status,'review');
   assert.deepEqual(await ledger(id),[{account_code:'member',amount_minor:'1999',currency:'MYR',user_id:user}]);
  });
  await t.test(`${provider}: concurrent duplicate callbacks post only one balanced ledger`,{timeout:15000},async()=>{
   const user=`${provider}-duplicate-user`,id=`${provider}-duplicate-order`,ref=provider==='vpay'?'vpay-duplicate-ref':'35803374';await seed(user,id,provider,ref);
   const callback=fixture(provider,user,id,ref),responses=await Promise.all([callback(),callback(),callback()]);
   assert.ok(responses.some(response=>response.status===200));const order=(await pool.query('SELECT status FROM deposit_orders WHERE id=$1',[id])).rows[0];assert.equal(order.status,'credited');
   assert.deepEqual(await ledger(id),[{account_code:'member',amount_minor:'2000',currency:'MYR',user_id:user},{account_code:'provider_clearing',amount_minor:'-2000',currency:'MYR',user_id:user}]);
  });
 }
});
