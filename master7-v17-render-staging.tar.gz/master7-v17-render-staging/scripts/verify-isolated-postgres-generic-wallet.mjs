import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import pg from 'pg';
import {setTimeout as delay} from 'node:timers/promises';
import {initializePortalDatabase,GENERIC_GAME_WALLET_RISK_MIGRATION} from '../lib/render-migrations.mjs';
import {RenderD1Compat,closeRenderPool} from '../lib/render-d1.ts';
import {withdrawalWalletState,clearStaleReservation} from '../lib/withdrawals.ts';
import {walletGuardStatements,walletGuardedRiskCheck,walletGuardedReservation} from '../lib/wallet-guard.ts';
import {genericGameWalletConsistency} from '../lib/game-wallet-consistency.ts';
import {seedWalletMembers,seedGenericSession,seedGenericPosting} from '../tests/fixtures/game-wallet-consistency.mjs';

const connection=process.env.MASTER7_ISOLATED_GAME_WALLET_DATABASE_URL??'';
let target;try{target=new URL(connection);}catch{throw Error('A fresh loopback-only game wallet test database is required');}
if(!['postgres:','postgresql:'].includes(target.protocol)||target.hostname!=='127.0.0.1'||target.username!=='postgres'||target.password||target.pathname!=='/master7_v126_game_wallet_test'||target.search||target.hash||!target.port||process.env.MASTER7_ISOLATED_GAME_WALLET_CONFIRM!=='master7_v126_game_wallet_test')throw Error('A fresh loopback-only game wallet test database is required');

test('generic game funds remain protected on isolated PostgreSQL',{timeout:60000},async t=>{
 const pool=new pg.Pool({connectionString:connection,ssl:false,max:6}),oldUrl=process.env.PORTAL_POSTGRES_URL,oldSsl=process.env.PGSSLMODE,oldFetch=globalThis.fetch;
 t.after(async()=>{await closeRenderPool();await pool.end();globalThis.fetch=oldFetch;if(oldUrl===undefined)delete process.env.PORTAL_POSTGRES_URL;else process.env.PORTAL_POSTGRES_URL=oldUrl;if(oldSsl===undefined)delete process.env.PGSSLMODE;else process.env.PGSSLMODE=oldSsl;});
 const identity=(await pool.query("SELECT current_database() name,(SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public')::int tables")).rows[0];
 assert.equal(identity.name,'master7_v126_game_wallet_test');assert.equal(identity.tables,0,'refuse a nonempty database');
 const schema=await readFile(new URL('../db/render-schema.sql',import.meta.url),'utf8'),directory=JSON.parse(await readFile(new URL('../db/vendor-directory.json',import.meta.url),'utf8'));
 await initializePortalDatabase(pool,schema,directory);
 process.env.PORTAL_POSTGRES_URL=connection;process.env.PGSSLMODE='disable';globalThis.fetch=async()=>{throw Error('Unexpected external request');};const db=new RenderD1Compat();
 async function reset(){await pool.query('TRUNCATE game_provider_profiles,users CASCADE');await seedWalletMembers(db);}
 async function assertBlocked(){const w=await withdrawalWalletState(db,'alice');assert.equal(w.balanceMinor,'10000');assert.equal(w.availableMinor,'0');assert.equal(w.reconciliationRequired,true);const r=await db.batch([...walletGuardStatements(db,'alice'),walletGuardedRiskCheck(db,'alice'),walletGuardedReservation(db,{userId:'alice',kind:'withdrawal',referenceId:'new-withdraw',amountMinor:'100',createdAt:1})]);assert.equal(r[2].meta.changes,0);assert.equal(r[3].meta.changes,0);}

 await t.test('indexes are present and the additive migration is idempotent',async()=>{
  const names=(await pool.query("SELECT indexname FROM pg_indexes WHERE schemaname='public'")).rows.map(r=>r.indexname);for(const name of ['game_provider_sessions_user_status','game_wallet_transfers_user_status','game_transactions_user_status'])assert.ok(names.includes(name));
  assert.equal((await pool.query('SELECT COUNT(*)::int n FROM portal_schema_migrations WHERE version=$1',[GENERIC_GAME_WALLET_RISK_MIGRATION])).rows[0].n,1);
  await initializePortalDatabase(pool,schema,directory);assert.equal((await pool.query('SELECT COUNT(*)::int n FROM portal_schema_migrations WHERE version=$1',[GENERIC_GAME_WALLET_RISK_MIGRATION])).rows[0].n,1);
 });
 await t.test('a closed unknown transfer blocks new spending while other members remain available',async()=>{
  await reset();await seedGenericSession(db,{status:'failed',reserved:null});await assertBlocked();assert.equal((await withdrawalWalletState(db,'bob')).availableMinor,'10000');
 });
 await t.test('valid open holds and clean rejected transactions keep their exact cash treatment',async()=>{
  await reset();await seedGenericSession(db);assert.equal((await withdrawalWalletState(db,'alice')).availableMinor,'6000');assert.equal((await genericGameWalletConsistency(db,'alice')).reconciliationRequired,false);
  await reset();await seedGenericSession(db,{status:'failed',reserved:null,transferStatus:'failed',closedAt:3});assert.equal((await withdrawalWalletState(db,'alice')).availableMinor,'10000');
 });
 await t.test('partial and balanced generic postings remain nonspendable until canonical projection exists',async()=>{
  for(const legs of ['none','partial','balanced']){await reset();const s=await seedGenericSession(db,{status:'settled',reserved:null,noTransfer:true,closedAt:2});await seedGenericPosting(db,s,{legs});await assertBlocked();}
 });
 await t.test('cash reservations are not cleaned while generic transfers still need review',async()=>{
  await reset();await seedGenericSession(db,{status:'failed',reserved:null});await pool.query("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('old','alice','megah5','player','1','deposit_failed',2000,'old-deposit',0,0); INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('alice','game','old',2000,0)");await clearStaleReservation(db,'alice');assert.equal((await pool.query("SELECT COUNT(*)::int n FROM wallet_reservations WHERE user_id='alice'")).rows[0].n,1);await assertBlocked();
 });
 await t.test('a new spend waiting on the member guard reevaluates a newly committed inconsistency',{timeout:15000},async()=>{
  await reset();await pool.query("INSERT INTO member_wallet_guards(user_id,revision) VALUES('alice',0)");
  const writer=await pool.connect();let committed=false,signal;const started=new Promise(resolve=>{signal=resolve;});let pending;
  try{
   await writer.query('BEGIN');await writer.query("UPDATE member_wallet_guards SET revision=revision+1 WHERE user_id='alice'");
   const waiting={prepare:sql=>db.prepare(sql),async batch(statements){const c=await pool.connect();try{await c.query('BEGIN');signal((await c.query('SELECT pg_backend_pid() pid')).rows[0].pid);const result=[];for(const statement of statements)result.push(await statement.execute(c));await c.query('COMMIT');return result;}catch(error){await c.query('ROLLBACK');throw error;}finally{c.release();}}};
   pending=waiting.batch([...walletGuardStatements(waiting,'alice'),walletGuardedRiskCheck(waiting,'alice'),walletGuardedReservation(waiting,{userId:'alice',kind:'withdrawal',referenceId:'concurrent-withdraw',amountMinor:'100',createdAt:1})]);const waiterPid=await started;
   let lockObserved=false;for(let attempt=0;attempt<50;attempt++){const row=(await pool.query('SELECT wait_event_type FROM pg_stat_activity WHERE pid=$1',[waiterPid])).rows[0];if(row?.wait_event_type==='Lock'){lockObserved=true;break;}await delay(20);}assert.equal(lockObserved,true,'the second commitment must actually wait on the member guard');
   const transactionDb={prepare(sql){return {bind(...values){const statement=db.prepare(sql).bind(...values);return {run:()=>statement.execute(writer)};}};}};
   await seedGenericSession(transactionDb,{status:'failed',reserved:null});await writer.query('COMMIT');committed=true;
   const result=await pending;assert.equal(result[2].meta.changes,0);assert.equal(result[3].meta.changes,0);assert.equal((await pool.query('SELECT COUNT(*)::int n FROM wallet_reservations')).rows[0].n,0);await assertBlocked();
  }finally{if(!committed)await writer.query('ROLLBACK');writer.release();if(pending)await pending.catch(()=>{});}
 });
});
