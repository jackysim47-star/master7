import pg from "pg";
import { assertCriticalDatabaseGuards } from "../lib/render-migrations.mjs";

export const DEFAULT_RUNTIME_DATABASE_GUARD_INTERVAL_MS = 60_000;
export const DEFAULT_RUNTIME_DATABASE_GUARD_QUERY_TIMEOUT_MS = 10_000;
export const DEFAULT_RUNTIME_DATABASE_GUARD_CLEANUP_TIMEOUT_MS = 2_000;

function boundedMilliseconds(value, fallback, minimum, maximum) {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= minimum && parsed <= maximum ? parsed : fallback;
}

function safeCode(error) {
  return typeof error?.code === "string" && /^[A-Z0-9_]{1,32}$/.test(error.code)
    ? error.code
    : "UNKNOWN";
}

function defaultSchedule(callback, delay) {
  const timer = setTimeout(callback, delay);
  timer.unref?.();
  return timer;
}

async function closeClientWithin(client, timeoutMs) {
  if (!client?.end) return;
  let timeout;
  const timedOut = new Promise((_, reject) => {
    timeout = setTimeout(() => {
      try { client.connection?.stream?.destroy?.(); } catch {}
      const error = new Error("Runtime database guard client cleanup timed out");
      error.code = "CLEANUP_TIMEOUT";
      reject(error);
    }, timeoutMs);
  });
  try {
    await Promise.race([Promise.resolve().then(() => client.end()), timedOut]);
  } finally {
    clearTimeout(timeout);
  }
}

export function startRuntimeDatabaseGuardMonitor(options = {}) {
  const connectionString = String(options.connectionString ?? "");
  if (!connectionString) throw new Error("Runtime database guard monitor requires a PostgreSQL connection");

  const intervalMs = boundedMilliseconds(options.intervalMs, DEFAULT_RUNTIME_DATABASE_GUARD_INTERVAL_MS, 15_000, 300_000);
  const queryTimeoutMs = boundedMilliseconds(options.queryTimeoutMs, DEFAULT_RUNTIME_DATABASE_GUARD_QUERY_TIMEOUT_MS, 1_000, 30_000);
  const cleanupTimeoutMs = boundedMilliseconds(options.cleanupTimeoutMs, DEFAULT_RUNTIME_DATABASE_GUARD_CLEANUP_TIMEOUT_MS, 100, 5_000);
  const clientFactory = options.clientFactory ?? (() => new pg.Client({
    connectionString,
    ssl: options.ssl,
    application_name: "master7-runtime-database-guard-monitor",
    connectionTimeoutMillis: queryTimeoutMs,
    statement_timeout: queryTimeoutMs,
    lock_timeout: Math.min(2_000, queryTimeoutMs),
    query_timeout: queryTimeoutMs + 1_000,
  }));
  const logger = options.logger ?? console;
  const schedule = options.schedule ?? defaultSchedule;
  const cancel = options.cancel ?? clearTimeout;
  const exit = options.exit ?? (code => process.exit(code));
  let stopped = false;
  let failed = false;
  let running = false;
  let successLogged = false;
  let timer;
  let currentRun;

  const failClosed = (category, error) => {
    if (failed || stopped) return;
    failed = true;
    stopped = true;
    if (timer !== undefined) {
      try { cancel(timer); } catch {}
    }
    timer = undefined;
    try { logger.error?.(`MASTER7 runtime database guard monitor fail-closed (${category}:${safeCode(error)}); exiting.`); } catch {}
    exit(1);
  };

  const scheduleNext = () => {
    if (stopped || failed || running || timer !== undefined) return;
    try {
      timer = schedule(() => {
        timer = undefined;
        currentRun = runCheck();
        return currentRun;
      }, intervalMs);
    } catch (error) {
      timer = undefined;
      failClosed("SCHEDULE", error);
    }
  };

  const runCheck = async () => {
    if (stopped || failed || running) return false;
    running = true;
    let client;
    let clientEventError;
    let failure;
    const onClientError = error => { clientEventError ??= error; };
    try {
      try {
        client = clientFactory();
        client?.on?.("error", onClientError);
        await client.connect();
        if (clientEventError) throw clientEventError;
      } catch (error) {
        failure = { category: "CONNECT", error };
      }
      if (!failure) {
        try {
          const result = await assertCriticalDatabaseGuards(client, { schemaName: "public" });
          if (result.criticalDatabaseGuardCount !== 9 || result.criticalDatabaseGuardFunctionCount !== 5) {
            throw new Error("Runtime database guard contract count mismatch");
          }
          if (clientEventError) throw clientEventError;
        } catch (error) {
          failure = { category: "ATTESTATION", error };
        }
      }
    } finally {
      try {
        await closeClientWithin(client, cleanupTimeoutMs);
      } catch (error) {
        failure ??= { category: "CLEANUP", error };
      }
      failure ??= clientEventError ? { category: "CLIENT", error: clientEventError } : undefined;
      try { client?.off?.("error", onClientError); } catch {}
      running = false;
      currentRun = undefined;
    }
    if (failure) {
      failClosed(failure.category, failure.error);
      return false;
    }
    if (!stopped && !successLogged) {
      successLogged = true;
      try { logger.log?.("MASTER7 runtime database guard monitor ready; database guards 9/9 ready; guard functions 5/5 attested."); } catch {}
    }
    scheduleNext();
    return !failed;
  };

  currentRun = runCheck();
  return {
    enabled: true,
    intervalMs,
    queryTimeoutMs,
    cleanupTimeoutMs,
    ready: currentRun,
    isRunning: () => running,
    hasFailed: () => failed,
    async stop() {
      if (stopped) {
        if (currentRun) await currentRun;
        return;
      }
      stopped = true;
      if (timer !== undefined) {
        try { cancel(timer); } catch {}
      }
      timer = undefined;
      if (currentRun) await currentRun;
    },
  };
}
