import {existsSync,readFileSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

export const EXPECTED_RELEASE='17.0.0-selfbuilt.174-uat-preview';
export const STAGING_ORIGIN='https://master7-v17-staging.onrender.com';
export const OFFICIAL_ENTRY_ORIGINS=Object.freeze(['https://www.master7.best','https://www.master7.site']);
export const REQUIRED_FILES=Object.freeze([
 'package.json',
 '.env.example',
 'lib/backend.ts',
 'lib/openai-gateway.ts',
 'lib/upload-policy.ts',
 'lib/integration-contracts.ts',
 'lib/handover-status.ts',
 'tests/production-readiness-probe.test.mjs',
 'tests/openai-gateway.test.mjs',
 'tests/upload-policy.test.mjs',
]);
export const SAFE_SWITCHES=Object.freeze([
 'PORTAL_MEGA_TRANSFERS_ENABLED',
 'PORTAL_MEGA_LIVE_GAMES_ENABLED',
 'PORTAL_MEGA_SETTLEMENT_VERIFIED',
 'GSPAY_ORDERS_ENABLED',
 'GSPAY_USDT_ORDERS_ENABLED',
 'ONE_MPAY_ORDERS_ENABLED',
 'VPAY_RECOVERY_ENABLED',
 'PORTAL_NEW_DEPOSITS_ENABLED',
 'PORTAL_NEW_GAME_LAUNCHES_ENABLED',
 'PORTAL_NEW_PAYOUTS_ENABLED',
]);

function parseEnv(text){
 const values={};
 for(const line of String(text??'').split(/\r?\n/)){
  const match=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if(!match||line.trimStart().startsWith('#'))continue;
  let value=match[2];
  if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1);
  values[match[1]]=value;
 }
 return values;
}

function sourceValue(key,env,example){
 const value=env?.[key]??example[key];
 return typeof value==='string'&&value.trim()!==''?value.trim():undefined;
}

function exactHttpsOrigin(value){
 if(typeof value!=='string'||!value)return false;
 try{
  const url=new URL(value);
  return url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&url.pathname==='/'&&!url.search&&!url.hash&&url.href===url.origin+'/';
 }catch{return false;}
}

function originList(value){
 return String(value??'').split(/[\s,]+/).map(item=>item.trim()).filter(Boolean);
}

function check(id,status,scope,details){return Object.freeze({id,status,scope,details});}

export function evaluateAutoSetup({root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),env=process.env,envExampleText}={}){
 const exampleText=envExampleText??(existsSync(join(root,'.env.example'))?readFileSync(join(root,'.env.example'),'utf8'):'');
 const example=parseEnv(exampleText),checks=[];
 const missing=REQUIRED_FILES.filter(file=>!existsSync(join(root,file)));
 checks.push(check('source_files',missing.length?'BLOCKED':'PASS','safe_staging',missing.length?`missing required files: ${missing.join(', ')}`:'required source and test files are present'));

 const configuredRelease=sourceValue('MASTER7_EXPECTED_RELEASE',env,example);
 checks.push(check('release',configuredRelease===EXPECTED_RELEASE?'PASS':'BLOCKED','safe_staging',configuredRelease===EXPECTED_RELEASE?'V173 release matches the selected baseline':'configured release is missing or differs from the selected V173 baseline'));

 const publicOrigin=sourceValue('PUBLIC_ORIGIN',env,example);
 const stagingOriginReady=exactHttpsOrigin(publicOrigin)&&publicOrigin===STAGING_ORIGIN;
 checks.push(check('staging_origin',stagingOriginReady?'PASS':'BLOCKED','safe_staging',stagingOriginReady?'PUBLIC_ORIGIN is the approved staging origin':'PUBLIC_ORIGIN is missing, malformed or not the approved staging origin'));
 const allowed=originList(sourceValue('PORTAL_ALLOWED_ORIGINS',env,example));
 checks.push(check('allowed_origins',allowed.includes(STAGING_ORIGIN)?'PASS':'BLOCKED','safe_staging',allowed.includes(STAGING_ORIGIN)?'staging origin is explicitly allowlisted':'staging origin is not explicitly allowlisted'));
 checks.push(check('official_entries','NOT_VERIFIED','production',`DNS/TLS and final routing for ${OFFICIAL_ENTRY_ORIGINS.join(' and ')} are external evidence and are not changed by Auto Setup`));

 const unsafe=SAFE_SWITCHES.filter(key=>sourceValue(key,env,example)!=='false');
 checks.push(check('safe_switches',unsafe.length?'BLOCKED':'PASS','safe_staging',unsafe.length?'one or more game/payment/recovery switches are missing or not explicitly false':'all protected game/payment/recovery switches are explicitly false'));
 const intakeFile=join(root,'lib/integration-contracts.ts');
 const intakeSource=existsSync(intakeFile)?readFileSync(intakeFile,'utf8'):'';
 const intakeReady=intakeSource.includes('contract_missing')&&intakeSource.includes('documentationOnly')&&intakeSource.includes('gameBrandCount')&&intakeSource.includes('primaryPaymentProfileCount')&&intakeSource.includes('uatPackage')&&intakeSource.includes('evidenceRecordFields')&&intakeSource.includes('excludedProviderCandidates');
 checks.push(check('contract_intake',intakeReady?'PASS':'BLOCKED','safe_staging',intakeReady?'documentation-only contract intake, 38/43/payment scope and UAT evidence schema are present':'documentation-only contract intake, scope metadata or UAT evidence schema is missing or incomplete'));
 const aiGatewayFile=join(root,'lib/openai-gateway.ts');
 const aiGatewaySource=existsSync(aiGatewayFile)?readFileSync(aiGatewayFile,'utf8'):'';
 const aiGatewayReady=aiGatewaySource.includes('transactionAutomation: false')&&aiGatewaySource.includes('serverOnly: true')&&aiGatewaySource.includes('OPENAI_TASKS');
 checks.push(check('ai_gateway',aiGatewayReady?'PASS':'BLOCKED','safe_staging',aiGatewayReady?'unified server-only AI gateway is present without transaction tools':'unified AI gateway is missing or does not declare the safe non-transaction boundary'));
 const uploadPolicyFile=join(root,'lib/upload-policy.ts');
 const uploadPolicySource=existsSync(uploadPolicyFile)?readFileSync(uploadPolicyFile,'utf8'):'';
 const uploadMode=sourceValue('MASTER7_UPLOAD_APPROVAL_MODE',env,example);
 const assetAutoApproval=sourceValue('MASTER7_ASSET_AUTO_APPROVAL',env,example);
 const receiptAutoApproval=sourceValue('MASTER7_RECEIPT_AUTO_APPROVAL',env,example);
 const uploadPolicyReady=uploadMode==='layered_safe'&&assetAutoApproval==='true'&&receiptAutoApproval==='false'&&uploadPolicySource.includes('const receiptAutoApproval = false');
 checks.push(check('upload_policy',uploadPolicyReady?'PASS':'BLOCKED','safe_staging',uploadPolicyReady?'safe layered upload policy is explicit; receipt auto-approval is hard-disabled':'upload policy is missing or receipt auto-approval is not explicitly disabled'));
 checks.push(check('supplier_evidence','NOT_VERIFIED','production','official Lebet and payment contracts/UAT evidence are not present in the source package'));
 checks.push(check('production_signoff','NOT_VERIFIED','production','DNS/TLS, monitoring, rollback and owner/operations signoff are not verified'));

 const stagingChecks=checks.filter(item=>item.scope==='safe_staging');
 const stagingReady=stagingChecks.every(item=>item.status==='PASS');
 return Object.freeze({
  tool:'master7-v173-auto-setup',
  release:EXPECTED_RELEASE,
  environment:'staging',
  status:stagingReady?'STAGING_READY':'BLOCKED',
  productionStatus:'NO-GO',
  checks:Object.freeze(checks),
  summary:Object.freeze({safeChecks:stagingChecks.length,safePassed:stagingChecks.filter(item=>item.status==='PASS').length,productionNotVerified:checks.filter(item=>item.scope==='production').length}),
  boundaries:Object.freeze(['read-only preflight','no provider calls','no database writes','no DNS or deployment changes','no real-money capability']),
 });
}

export function formatAutoSetupReport(result){
 const lines=[
  '# MASTER7 V173 Auto Setup Preflight',
  '',
  `- Release: \`${result.release}\``,
  `- Environment: \`${result.environment}\``,
  `- Staging setup: **${result.status}**`,
  `- Production: **${result.productionStatus}**`,
  '',
  '## Checks',
  '',
  ...result.checks.map(item=>`- [${item.status}] \`${item.id}\` — ${item.details}`),
  '',
  '## Boundaries',
  '',
  ...result.boundaries.map(item=>`- ${item}`),
  '',
  '没有厂商合同、UAT、DNS/TLS 和正式签收证据时，生产状态不会被 Auto Setup 改为 GO。',
 ];
 return lines.join('\n');
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const result=evaluateAutoSetup();
 process.stdout.write(process.argv.includes('--json')?JSON.stringify(result,null,2)+'\n':formatAutoSetupReport(result)+'\n');
 if(result.status==='BLOCKED')process.exitCode=1;
}
