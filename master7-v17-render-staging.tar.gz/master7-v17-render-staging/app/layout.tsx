export default function Layout({children}:{children:React.ReactNode}){return <html lang="zh-Hans"><body>{children}</body></html>;}
