const FRONTEND_ALIASES = new Set([
  '/games',
  '/home',
  '/index.html',
  '/lobby',
  '/player',
  '/player/games',
]);

function canonicalFrontendPath(pathname: string) {
  let decoded: string;
  try {
    decoded = decodeURIComponent(pathname);
  } catch {
    return null;
  }

  const withoutAccidentalBackticks = decoded.replace(/`+\/?$/u, '');
  if (withoutAccidentalBackticks !== decoded) {
    const canonical = withoutAccidentalBackticks.replace(/\/+$/u, '') || '/';
    return FRONTEND_ALIASES.has(canonical) ? '/' : canonical;
  }

  const comparable = decoded.replace(/\/+$/u, '') || '/';
  return FRONTEND_ALIASES.has(comparable) ? '/' : null;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const target = canonicalFrontendPath(url.pathname);
  if (!target) {
    return new Response('Not found', {
      status: 404,
      headers: {
        'Cache-Control': 'no-store',
        'Content-Type': 'text/plain; charset=utf-8',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  }

  url.pathname = target;
  return new Response(null, {
    status: 308,
    headers: {
      'Cache-Control': 'no-store',
      Location: url.toString(),
    },
  });
}

