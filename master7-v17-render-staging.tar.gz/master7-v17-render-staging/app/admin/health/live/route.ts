import { GET as backendGET } from '../../../api/[...path]/route';

export const dynamic = 'force-dynamic';

export function GET(request: Request) {
  const url = new URL(request.url);
  url.pathname = '/health/live';
  return backendGET(new Request(url, {
    method: 'GET',
    headers: request.headers,
  }));
}
