export function GET(request:Request){
 const target=new URL('/admin',request.url);
 target.search=new URL(request.url).search;
 return new Response(null,{status:302,headers:{Location:target.toString(),'Cache-Control':'no-store'}});
}
