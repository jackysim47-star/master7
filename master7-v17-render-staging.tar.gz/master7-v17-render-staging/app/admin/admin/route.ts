export function GET(request:Request){
 const search=new URL(request.url).search;
 return new Response(null,{status:302,headers:{Location:'/admin'+search,'Cache-Control':'no-store'}});
}
