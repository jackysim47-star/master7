import html from './portal.html?raw';
import { env } from 'cloudflare:workers';
import { readLocalSession } from '../lib/password-auth';

export const dynamic='force-dynamic';
const customerHosts=new Set(['master7.best','www.master7.best']);
const adminHosts=new Set(['master7.site','www.master7.site']);

export async function GET(req:Request){
 const url=new URL(req.url);
 const host=(req.headers.get('x-forwarded-host')??url.host).split(',')[0].trim().split(':')[0].toLowerCase();
 const admin=url.pathname==='/admin'||url.pathname.startsWith('/admin/');
 const authEntry=['/signin','/register'].includes(url.pathname);
 if(admin&&customerHosts.has(host)){
  const target=new URL(url.pathname+url.search,'https://www.master7.site');
  return new Response(null,{status:308,headers:{Location:target.href,'Cache-Control':'no-store'}});
 }
 if(url.pathname==='/'&&adminHosts.has(host)){
  return new Response(null,{status:308,headers:{Location:'/admin','Cache-Control':'no-store'}});
 }
 const local=env.DB?await readLocalSession(req,env.DB):null;
 if(url.pathname==='/'&&!local)return new Response(null,{status:303,headers:{Location:'/signin','Cache-Control':'no-store'}});
 if(authEntry&&local)return new Response(null,{status:303,headers:{Location:local.user.role==='owner'||local.user.role==='staff'?'/admin':'/','Cache-Control':'no-store'}});
 const page=admin?html.replace('id="home" class="section active"','id="home" class="section"').replace('id="admin" class="section"','id="admin" class="section active"'):html;
 const body=authEntry?page.replace('<body>','<body class="auth-entry">'):page;
 return new Response(body,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self' https://connect.facebook.net; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://www.facebook.com; media-src 'self'; connect-src 'self' https://www.facebook.com https://connect.facebook.net; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'"}});
}

