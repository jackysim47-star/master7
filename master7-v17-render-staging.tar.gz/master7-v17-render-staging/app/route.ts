import html from './portal.html?raw';
import { env } from 'cloudflare:workers';
import { readLocalSession } from '../lib/password-auth';

export const dynamic='force-dynamic';

export async function GET(req:Request){
 const url=new URL(req.url);
 const admin=url.pathname==='/admin';
 const authEntry=['/signin','/register'].includes(url.pathname);
 const local=env.DB?await readLocalSession(req,env.DB):null;
 if(url.pathname==='/'&&!local)return new Response(null,{status:303,headers:{Location:'/signin','Cache-Control':'no-store'}});
 if(authEntry&&local)return new Response(null,{status:303,headers:{Location:local.user.role==='owner'||local.user.role==='staff'?'/admin':'/','Cache-Control':'no-store'}});
 const page=admin?html.replace('id="home" class="section active"','id="home" class="section"').replace('id="admin" class="section"','id="admin" class="section active"'):html;
 const body=authEntry?page.replace('<body>','<body class="auth-entry">'):page;
 return new Response(body,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'"}});
}

