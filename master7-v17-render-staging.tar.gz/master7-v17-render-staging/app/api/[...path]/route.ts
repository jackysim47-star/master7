import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
import { handle } from '../../../lib/backend';
export const dynamic='force-dynamic';
function trustedOrigins(config:Record<string,string>){
 const candidates=[config.RENDER_EXTERNAL_URL,config.PUBLIC_ORIGIN,...String(config.PORTAL_ALLOWED_ORIGINS??'').split(',')];
 return [...new Set(candidates.flatMap(value=>{try{const url=new URL(String(value??'').trim());return url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&(!url.pathname||url.pathname==='/')&&!url.search&&!url.hash?[url.origin]:[];}catch{return [];}}))];
}
async function dispatch(req:Request){if(!env.DB)return Response.json({error:'Database unavailable'},{status:503});const config=env as unknown as Record<string,string>;return handle(req,{db:env.DB,identity:await getChatGPTUser(),ownerEmail:config.OWNER_EMAIL??'',ownerLoginId:config.OWNER_LOGIN_ID,allowedOrigins:trustedOrigins(config),ownerSetupHash:config.OWNER_SETUP_TOKEN_HASH,ownerSetupExpires:Number(config.OWNER_SETUP_EXPIRES_AT??0),ownerResetHash:config.OWNER_RESET_TOKEN_HASH,ownerResetExpires:Number(config.OWNER_RESET_EXPIRES_AT??0),ownerResetIssuedAt:Number(config.OWNER_RESET_ISSUED_AT??0)});}
export const GET=dispatch;
export const POST=dispatch;
