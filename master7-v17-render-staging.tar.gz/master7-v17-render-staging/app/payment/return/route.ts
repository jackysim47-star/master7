export { GET } from '../../route';
