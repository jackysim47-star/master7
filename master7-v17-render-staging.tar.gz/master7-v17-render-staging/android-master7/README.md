# MASTER7 Android

Official Android WebView wrapper for the MASTER7 customer portal.

- Application ID: `com.master7.portal`
- Version: `17.0.52` (`170052`)
- Minimum Android: 8.0 (API 26)
- Primary origin: `https://master7.best/`
- Verified fallback origin: `https://master7-v17-staging.onrender.com/`
- HTTPS only; SSL errors are never bypassed.
- File upload is supported for receipt workflows.

The release keystore is stored outside this source directory and must be retained for future upgrades.
