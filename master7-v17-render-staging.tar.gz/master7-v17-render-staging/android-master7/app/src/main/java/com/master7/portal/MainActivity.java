package com.master7.portal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Set;

public final class MainActivity extends Activity {
    private static final String PRIMARY_URL = "https://www.master7.best/";
    private static final String FALLBACK_URL = "https://master7-v17-staging.onrender.com/";
    private static final Set<String> INTERNAL_HOSTS = Set.of("www.master7.best", "master7.best", "master7-v17-staging.onrender.com");
    private WebView webView;
    private ValueCallback<Uri[]> pendingFiles;
    private boolean fallbackUsed = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 11, 20));
        getWindow().setNavigationBarColor(Color.rgb(8, 11, 20));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 11, 20));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setUserAgentString(settings.getUserAgentString() + " MASTER7-Android/17.0.52");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new PortalClient());
        webView.setWebChromeClient(new PortalChromeClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> openExternal(url));
        if (state == null) {
            Uri deepLink = getIntent().getData();
            webView.loadUrl(deepLink != null && isInternal(deepLink) ? deepLink.toString() : PRIMARY_URL);
        } else webView.restoreState(state);
    }

    private boolean isInternal(Uri uri) { return "https".equalsIgnoreCase(uri.getScheme()) && INTERNAL_HOSTS.contains(uri.getHost()); }
    private void openExternal(String value) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value))); }
        catch (ActivityNotFoundException ignored) { }
    }
    private void useFallback() {
        if (!fallbackUsed) { fallbackUsed = true; webView.loadUrl(FALLBACK_URL); }
        else webView.loadDataWithBaseURL(null, "<html><body style='background:#080b14;color:#fff;font-family:sans-serif;padding:32px'><h2>MASTER7</h2><p>Connection unavailable. Please check your internet and try again.</p></body></html>", "text/html", "UTF-8", null);
    }

    private final class PortalClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl(); if (isInternal(uri)) return false; openExternal(uri.toString()); return true;
        }
        @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) useFallback();
        }
        @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
            if (request.isForMainFrame() && response.getStatusCode() >= 400) useFallback();
        }
        @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel(); useFallback();
        }
    }

    private final class PortalChromeClient extends WebChromeClient {
        @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (pendingFiles != null) pendingFiles.onReceiveValue(null);
            pendingFiles = callback;
            try { startActivityForResult(params.createIntent(), 7007); return true; }
            catch (ActivityNotFoundException error) { pendingFiles = null; return false; }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7007 && pendingFiles != null) { pendingFiles.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); pendingFiles = null; }
    }
    @Override protected void onSaveInstanceState(Bundle out) { webView.saveState(out); super.onSaveInstanceState(out); }
    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) { webView.loadUrl("about:blank"); webView.destroy(); } super.onDestroy(); }
}
