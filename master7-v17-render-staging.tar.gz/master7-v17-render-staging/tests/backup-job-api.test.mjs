import test from 'node:test';
import assert from 'node:assert/strict';
import {BACKUP_FORMAT,BACKUP_SCHEMA_SHA256,BACKUP_SCHEMA_VERSION,BACKUP_TABLES} from '../lib/encrypted-backup.ts';
import {BACKUP_PUBLIC_KEY_SHA256} from '../lib/backup-public-key.ts';
import {handle,RELEASE} from '../lib/backend.ts';
import {backupLockClaim} from '../lib/backup-operations.ts';

const token='backup-job-test-token-'.padEnd(48,'x');

test('backup lease claim always fits a signed PostgreSQL INTEGER',()=>{
 const claim=backupLockClaim('backup-lock-0');
 assert.equal(claim,1649370090);
 assert.ok(Number.isSafeInteger(claim)&&claim>=1&&claim<=2147483647);
});

function fixture(){
 const audits=[],settings=new Map([['payment_flag','closed'],['game_flag','closed'],['payout_flag','closed']]),leases=new Map(),owner={id:'owner',username:'owner',role:'owner',approved:1,csrf:'owner-csrf',created_at:1};let gate=null;
 class Statement{
  constructor(sql,args=[]){this.sql=sql;this.args=args;}
  bind(...args){return new Statement(this.sql,args);}
  async first(){
   if(this.sql.startsWith('INSERT INTO rate_limits(id,count,expires_at) VALUES(?,?,?)')){const [id,count,expiresAt,stamp]=this.args,current=leases.get(id);if(!Number.isInteger(count)||count<1||count>2147483647)throw Object.assign(Error('PostgreSQL INTEGER out of range'),{code:'22003'});if(current&&current.expiresAt>stamp)return null;leases.set(id,{count,expiresAt});return {count};}
   if(this.sql.startsWith('INSERT INTO rate_limits(id,count,expires_at) VALUES(?,1,?)')){const [id,expiresAt]=this.args,current=leases.get(id),count=(current?.count??0)+1;leases.set(id,{count,expiresAt});return {count};}
   if(this.sql==="SELECT value FROM settings WHERE id='backup_restore_rehearsal'")return settings.has('backup_restore_rehearsal')?{value:settings.get('backup_restore_rehearsal')}:null;
   if(this.sql==='SELECT * FROM users WHERE id=?')return this.args[0]===owner.id?owner:null;
   throw Error('Unexpected first SQL: '+this.sql);
  }
  async all(){
   if(/^SELECT \* FROM [a-z0-9_]+ ORDER BY [a-z0-9_,]+ LIMIT \? OFFSET \?$/.test(this.sql))return {results:[]};
   if(this.sql.startsWith("SELECT target,created_at FROM audit WHERE event='encrypted_backup_created'")){const rows=audits.filter(x=>x.event==='encrypted_backup_created'),max=Math.max(-1,...rows.map(x=>x.created_at));return {results:rows.filter(x=>x.created_at===max).map(x=>({target:x.target,created_at:x.created_at}))};}
   throw Error('Unexpected all SQL: '+this.sql);
  }
  async run(){
   if(this.sql==='INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)'){const [id,user_id,event,target,created_at]=this.args;audits.push({id,user_id,event,target,created_at});return {};}
   if(this.sql.startsWith('DELETE FROM rate_limits WHERE id=? AND count=?')){const [id,count,expiresAt]=this.args,current=leases.get(id);if(current?.count===count&&current?.expiresAt===expiresAt)leases.delete(id);return {};}
   if(this.sql.startsWith('DELETE FROM rate_limits WHERE expires_at < ?')){for(const [id,x] of leases)if(x.expiresAt<this.args[0])leases.delete(id);return {};}
   if(this.sql.startsWith("INSERT INTO settings(id,value) VALUES('backup_restore_rehearsal',?)")){settings.set('backup_restore_rehearsal',this.args[0]);return {};}
   throw Error('Unexpected run SQL: '+this.sql);
  }
 }
 const db={prepare:sql=>new Statement(sql),async batch(items){for(const item of items)await item.run();return [];},async withReadSnapshot(read){if(gate)await gate.promise;return read(db);}};
 return {db,audits,settings,leases,block(){let release;gate={promise:new Promise(resolve=>{release=resolve;})};return ()=>{gate=null;release();};}};
}

async function job(f,data,auth=`Bearer ${token}`,method='POST'){
 const response=await handle(new Request('https://portal.example.test/api/jobs/backup?ignored=1',{method,headers:{authorization:auth,'content-type':'application/json'},body:method==='POST'?JSON.stringify(data):undefined}),{db:f.db,identity:null,ownerEmail:'',backupJobToken:token});const text=await response.text();return {response,data:JSON.parse(text)};
}

function receipt(f,backup){const evidence=JSON.parse(f.audits.findLast(x=>x.event==='encrypted_backup_created').target);return {action:'record_rehearsal',status:'verified',format:BACKUP_FORMAT,release:RELEASE,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,backupSha256:evidence.backupSha256,plaintextSha256:evidence.plaintextSha256,publicKeySha256:BACKUP_PUBLIC_KEY_SHA256,tableCount:BACKUP_TABLES.length,totalRecords:backup.manifest.totalRecords,foreignKeyViolations:0,coverageComplete:true,missingTables:[],readConsistency:'transaction_snapshot',persistentWrites:false,restoreTarget:'isolated PostgreSQL transaction on localhost/master7_restore_test',createdAt:backup.createdAt,verifiedAt:new Date(Date.now()+1000).toISOString()};}

test('backup job fails closed without an exact JSON bearer request',async()=>{const f=fixture();for(const auth of ['',`Bearer wrong`,'Basic '+token])assert.equal((await job(f,{action:'create'},auth)).response.status,401);assert.equal((await job(f,{action:'create'},`Bearer ${token}`,'GET')).response.status,405);const nonJson=await handle(new Request('https://portal.example.test/api/jobs/backup',{method:'POST',headers:{authorization:`Bearer ${token}`},body:'{}'}),{db:f.db,identity:null,ownerEmail:'',backupJobToken:token});assert.equal(nonJson.status,415);assert.equal(f.audits.length,0);});

test('machine backup and idempotent rehearsal preserve closed money and game flags',async()=>{
 const f=fixture(),flags=['payment_flag','game_flag','payout_flag'].map(key=>f.settings.get(key)),created=await job(f,{action:'create'});assert.equal(created.response.status,200);assert.equal(created.response.headers.get('cache-control'),'no-store');assert.equal(created.data.release,RELEASE);assert.equal(created.data.readConsistency,'transaction_snapshot');assert.equal(created.data.manifest.tableCount,BACKUP_TABLES.length);assert.equal(f.audits[0].user_id,'system:backup-job');assert.equal(JSON.stringify({created:created.data,audits:f.audits}).includes(token),false);
 const evidence=receipt(f,created.data),invalid=await job(f,{...evidence,foreignKeyViolations:1});assert.equal(invalid.response.status,400);assert.equal(f.audits.length,1);
 const first=await job(f,evidence);assert.deepEqual(first.data,{status:'ok',verified:true});assert.equal(f.audits.length,2);assert.equal(f.audits[1].user_id,'system:backup-job');const replay=await job(f,evidence);assert.deepEqual(replay.data,{status:'ok',verified:true,idempotent:true});assert.equal(f.audits.length,2);assert.deepEqual(['payment_flag','game_flag','payout_flag'].map(key=>f.settings.get(key)),flags);assert.equal(f.leases.size,0);
});

test('shared lease rejects concurrency and owner backup route still works',async()=>{
 const f=fixture(),release=f.block(),running=job(f,{action:'create'});await new Promise(resolve=>setTimeout(resolve,20));assert.equal((await job(f,{action:'create'})).response.status,409);release();assert.equal((await running).response.status,200);
 const response=await handle(new Request('https://portal.example.test/api/admin/backup',{method:'POST',headers:{origin:'https://portal.example.test','content-type':'application/json','x-csrf-token':'owner-csrf'},body:'{"action":"create"}'}),{db:f.db,identity:{userId:'owner',email:'owner@example.test'},ownerEmail:'owner@example.test',allowedOrigins:['https://portal.example.test']});assert.equal(response.status,200);assert.equal((await response.json()).format,BACKUP_FORMAT);assert.equal(f.audits.findLast(x=>x.event==='encrypted_backup_created').user_id,'owner');
});
