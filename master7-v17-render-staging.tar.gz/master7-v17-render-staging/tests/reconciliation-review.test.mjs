import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {
 getReconciliationRuns,recordReconciliationRun,recordReconciliationReview,ReconciliationReviewError,
} from '../lib/reconciliation-review.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function fixture(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());sqlite.exec('PRAGMA foreign_keys=ON');
 for(const name of ['0000_broken_bloodscream.sql','0007_vpay_uat_wallet.sql','0126_reconciliation_owner_reviews.sql'])sqlite.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 sqlite.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner','owner',1,'o',1),('staff','staff','staff',1,'s',1),('member','member','member',1,'m',1)");
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(list){sqlite.exec('BEGIN');try{const out=[];for(const statement of list)out.push(await statement.run());sqlite.exec('COMMIT');return out;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 return {sqlite,db};
}

const actor=(role='owner')=>({id:role,role});
function input(){
 const row={id:'internal-vpay-1',domain:'payment',provider:'vpay',account:'merchant',reference:'VPAY-1',amountMinor:'1000',currency:'MYR',status:'succeeded',direction:'credit',balanceClass:'cash',occurredAt:'2026-11-15T01:00:00.000Z',evidenceReference:'internal:vpay:1',transactionId:'tx-vpay-1',memberId:'member',ledger:{memberMinor:'1000',clearingMinor:'-1000',memberEntries:1,clearingEntries:1,memberId:'member'}};
 return {schemaVersion:'master7-reconciliation-v1',mappingVersion:'vpay-map-1',ruleVersion:'rules-1',sourceCommit:'7'.repeat(40),internalSnapshotId:'snapshot-1',period:{startUtc:'2026-11-15T00:00:00.000Z',endUtcExclusive:'2026-11-16T00:00:00.000Z'},internalRecords:[row],externalRecords:[{...row,id:'external-vpay-1',evidenceReference:'external:vpay:1'}],coverage:[{domain:'payment',provider:'vpay',account:'merchant',balanceClass:'cash',complete:true,evidenceReference:'coverage:vpay:1'}]};
}

test('canonical report persistence is deterministic, idempotent and never posts money',async t=>{
 const {sqlite,db}=fixture(t),before=sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n;
 const first=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100);
 assert.equal(first.result,'matched_inputs');assert.equal(first.idempotent,false);assert.deepEqual(first.financialActions,[]);assert.equal(first.acceptanceGranted,false);
 const replay=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},101);
 assert.equal(replay.runId,first.runId);assert.equal(replay.idempotent,true);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM reconciliation_runs').get().n,1);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,before);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='reconciliation_run_recorded'").get().n,1);
});

test('Owner review is append-only, concurrency guarded and cannot grant acceptance',async t=>{
 const {sqlite,db}=fixture(t),run=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100),payload={runId:'',expectedRevision:0,decision:'acknowledged',note:'Owner checked the matched source references.',evidenceReference:'owner:review:vpay-1',requestKey:'review-request-0001'};payload.runId=run.runId;
 const saved=await recordReconciliationReview(db,actor(),payload,110);
 assert.equal(saved.revision,1);assert.equal(saved.idempotent,false);assert.deepEqual(saved.financialActions,[]);assert.equal(saved.acceptanceGranted,false);assert.equal(saved.productionStateChanged,false);
 const replay=await recordReconciliationReview(db,actor(),payload,111);assert.equal(replay.idempotent,true);assert.equal(replay.revision,1);
 await assert.rejects(()=>recordReconciliationReview(db,actor(),{...payload,requestKey:'review-request-0002',decision:'needs_follow_up'},112),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='STALE_REVIEW');
 const second=await recordReconciliationReview(db,actor(),{...payload,expectedRevision:1,requestKey:'review-request-0002',decision:'needs_follow_up',note:'External settlement evidence still needs follow-up.'},113);assert.equal(second.revision,2);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM reconciliation_review_events').get().n,2);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('staff can read but only Owner can record or review',async t=>{
 const {db}=fixture(t),run=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100);
 const list=await getReconciliationRuns(db,actor('staff'),{limit:20});assert.equal(list.items.length,1);assert.equal(list.items[0].runId,run.runId);assert.equal(list.readOnlyReports,true);assert.equal(list.acceptanceGranted,false);
 await assert.rejects(()=>getReconciliationRuns(db,actor('member'),{}),error=>error instanceof ReconciliationReviewError&&error.status===403);
 await assert.rejects(()=>recordReconciliationReview(db,actor('staff'),{runId:run.runId,expectedRevision:0,decision:'acknowledged',note:'Staff must not persist this review.',evidenceReference:'staff:review',requestKey:'review-request-0003'},101),error=>error instanceof ReconciliationReviewError&&error.status===403);
});

test('stored report corruption is rejected on detail reads and idempotent replay',async t=>{
 const {sqlite,db}=fixture(t),canonical=input(),run=await recordReconciliationRun(db,actor(),{input:canonical,evidenceReference:'uat:vpay:statement-1'},100);
 const stored=sqlite.prepare('SELECT report_json FROM reconciliation_runs WHERE run_id=?').get(run.runId).report_json;
 sqlite.prepare('UPDATE reconciliation_runs SET report_json=? WHERE run_id=?').run(stored+' ',run.runId);
 await assert.rejects(()=>getReconciliationRuns(db,actor(),{runId:run.runId}),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='RECONCILIATION_INTEGRITY_ERROR');
 await assert.rejects(()=>recordReconciliationRun(db,actor(),{input:canonical,evidenceReference:'uat:vpay:statement-1'},101),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='RECONCILIATION_INTEGRITY_ERROR');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('stored report metadata cannot drift away from its immutable report',async t=>{
 const {sqlite,db}=fixture(t),run=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100);
 sqlite.prepare("UPDATE reconciliation_runs SET mapping_version='tampered-map' WHERE run_id=?").run(run.runId);
 await assert.rejects(()=>getReconciliationRuns(db,actor(),{runId:run.runId}),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='RECONCILIATION_INTEGRITY_ERROR');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM reconciliation_review_events').get().n,0);
});

test('Owner cannot acknowledge a report whose stored bytes no longer match its digest',async t=>{
 const {sqlite,db}=fixture(t),run=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100);
 const payload={runId:run.runId,expectedRevision:0,decision:'acknowledged',note:'Owner checked the source references.',evidenceReference:'owner:review:integrity',requestKey:'review-integrity-0001'};
 const stored=sqlite.prepare('SELECT report_json FROM reconciliation_runs WHERE run_id=?').get(run.runId).report_json;
 sqlite.prepare('UPDATE reconciliation_runs SET report_json=? WHERE run_id=?').run(stored+' ',run.runId);
 await assert.rejects(()=>recordReconciliationReview(db,actor(),payload,110),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='RECONCILIATION_INTEGRITY_ERROR');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM reconciliation_review_events').get().n,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='reconciliation_owner_review_recorded'").get().n,0);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('Owner cannot review a report whose persisted metadata conflicts with the report',async t=>{
 const {sqlite,db}=fixture(t),run=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100);
 sqlite.prepare("UPDATE reconciliation_runs SET mapping_version='tampered-map' WHERE run_id=?").run(run.runId);
 await assert.rejects(()=>recordReconciliationReview(db,actor(),{runId:run.runId,expectedRevision:0,decision:'needs_follow_up',note:'Owner requires external statement evidence.',evidenceReference:'owner:review:metadata',requestKey:'review-integrity-0002'},110),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='RECONCILIATION_INTEGRITY_ERROR');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM reconciliation_review_events').get().n,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='reconciliation_owner_review_recorded'").get().n,0);
});

test('review retry does not hide report corruption after the original acknowledgement',async t=>{
 const {sqlite,db}=fixture(t),run=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100);
 const payload={runId:run.runId,expectedRevision:0,decision:'acknowledged',note:'Owner checked the original report.',evidenceReference:'owner:review:retry',requestKey:'review-integrity-0003'};
 await recordReconciliationReview(db,actor(),payload,110);
 const stored=sqlite.prepare('SELECT report_json FROM reconciliation_runs WHERE run_id=?').get(run.runId).report_json;
 sqlite.prepare('UPDATE reconciliation_runs SET report_json=? WHERE run_id=?').run(stored+' ',run.runId);
 await assert.rejects(()=>recordReconciliationReview(db,actor(),payload,111),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='RECONCILIATION_INTEGRITY_ERROR');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM reconciliation_review_events').get().n,1);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='reconciliation_owner_review_recorded'").get().n,1);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

for(const field of ['report_json','mapping_version'])test(`report ${field} change between validation and insertion cannot create an Owner review`,async t=>{
 const {sqlite,db}=fixture(t),run=await recordReconciliationRun(db,actor(),{input:input(),evidenceReference:'uat:vpay:statement-1'},100);
 const batch=db.batch;
 db.batch=async list=>{
  if(field==='report_json')sqlite.prepare("UPDATE reconciliation_runs SET report_json=report_json||' ' WHERE run_id=?").run(run.runId);
  else sqlite.prepare("UPDATE reconciliation_runs SET mapping_version='changed-before-commit' WHERE run_id=?").run(run.runId);
  return batch(list);
 };
 await assert.rejects(()=>recordReconciliationReview(db,actor(),{runId:run.runId,expectedRevision:0,decision:'acknowledged',note:'Owner checked the original report.',evidenceReference:'owner:review:race',requestKey:'review-integrity-race'},110),error=>error instanceof ReconciliationReviewError&&error.status===409&&error.code==='RECONCILIATION_INTEGRITY_ERROR');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM reconciliation_review_events').get().n,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='reconciliation_owner_review_recorded'").get().n,0);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});
