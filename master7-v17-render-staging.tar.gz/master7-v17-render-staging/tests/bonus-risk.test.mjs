import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {BONUS_RISK_SETTING_ID,BonusRiskError,bonusRiskReport,loadBonusRiskConfig,saveBonusRiskConfig} from '../lib/bonus-risk.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function fixture(){
 const sqlite=new DatabaseSync(':memory:');
 sqlite.exec(`
  CREATE TABLE settings(id TEXT PRIMARY KEY,value TEXT NOT NULL);
  CREATE TABLE users(id TEXT PRIMARY KEY,username TEXT NOT NULL,phone TEXT,role TEXT,approved INTEGER,csrf TEXT,created_at INTEGER);
  CREATE TABLE deposit_orders(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,request_key TEXT NOT NULL,fingerprint TEXT NOT NULL,provider TEXT NOT NULL,amount_minor INTEGER NOT NULL,currency TEXT NOT NULL,trade_code TEXT NOT NULL,status TEXT NOT NULL,provider_trade_no TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
  CREATE TABLE benefit_claims(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,benefit_rule_id TEXT NOT NULL,request_key TEXT NOT NULL,deposit_order_id TEXT,rules_snapshot_json TEXT NOT NULL,deposit_minor INTEGER NOT NULL,reward_minor INTEGER NOT NULL,turnover_required_minor INTEGER NOT NULL,expires_at INTEGER NOT NULL,status TEXT NOT NULL,wallet_credit_status TEXT NOT NULL,turnover_source_status TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
  CREATE TABLE referral_relationships(member_id TEXT PRIMARY KEY,referrer_id TEXT NOT NULL,code TEXT NOT NULL,created_at INTEGER NOT NULL);
  CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL);
 `);
 return {sqlite,db:{prepare:sql=>new Statement(sqlite,sql)}};
}

function seed(sqlite){
 const user=sqlite.prepare("INSERT INTO users(id,username,phone,role,approved,csrf,created_at) VALUES(?,?,?,'member',1,'private-csrf',0)");
 for(const [id,name] of [['hunter','hunter-visible'],['cycle-a','cycle-a-visible'],['cycle-b','cycle-b-visible'],['referrer','referrer-visible'],['down-1','down-1-visible'],['down-2','down-2-visible']])user.run(id,name,`private-phone-${id}`);
 sqlite.prepare("INSERT INTO users(id,username,phone,role,approved,csrf,created_at) VALUES('staff-risk','staff-risk-visible','private-phone-staff','staff',1,'private-csrf',0)").run();
 const deposit=sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES(?,?,?,?, 'vpay',1000,'MYR','1',?,?,?,?)");
 for(const [index,status] of ['failed','unknown','credited'].entries())deposit.run(`deposit-${index}`,'hunter',`private-request-${index}`,`private-fingerprint-${index}`,status,`private-provider-reference-${index}`,99000+index,99000+index);
 const claim=sqlite.prepare("INSERT INTO benefit_claims(id,user_id,benefit_rule_id,request_key,deposit_order_id,rules_snapshot_json,deposit_minor,reward_minor,turnover_required_minor,expires_at,status,wallet_credit_status,turnover_source_status,created_at,updated_at) VALUES(?,?,?,?,?,'private-rules',1000,100,2000,200000,'awaiting_acceptance','disabled','not_connected',?,?)");
 claim.run('claim-1','hunter','rule-1','private-claim-key-1','deposit-2',99500,99500);
 claim.run('claim-2','hunter','rule-2','private-claim-key-2','deposit-2',99501,99501);
 const referral=sqlite.prepare('INSERT INTO referral_relationships(member_id,referrer_id,code,created_at) VALUES(?,?,?,?)');
 referral.run('cycle-a','cycle-b','private-code-a',99600);referral.run('cycle-b','cycle-a','private-code-b',99601);
 referral.run('down-1','referrer','private-code-ref',99700);referral.run('down-2','referrer','private-code-ref',99701);
 sqlite.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES('rate-1','hunter','write_rate_limited','private-request-target',99800)").run();
 sqlite.prepare("INSERT INTO audit(id,user_id,event,target,created_at) VALUES('rate-staff','staff-risk','write_rate_limited','private-staff-target',99801)").run();
}

test('bonus hunter produces explainable manual-review cases only from connected objective signals',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);
 await saveBonusRiskConfig(db,{version:1,mode:'monitor_only',thresholds:{depositAttempts:2,failedOrUnknownDeposits:2,referralFanout:2,benefitClaims:2,benefitClaimsPerDeposit:2,writeRateLimits:1}});
 const report=await bonusRiskReport(db,{now:100000,hours:24,limit:100});
 assert.equal(report.reportType,'bonus_hunter_monitor_v1');
 assert.equal(report.mode,'monitor_only');
 assert.equal(report.readOnly,true);
 assert.deepEqual(report.enforcement,{automaticAction:false,autoBan:false,autoFreeze:false,autoDeduct:false,autoReject:false,autoPayoutHold:false});
 const rules=new Set(report.cases.map(item=>item.ruleId));
 for(const rule of ['deposit_failed_unknown_velocity','deposit_attempt_velocity','referral_fanout_velocity','referral_cycle','benefit_claim_velocity','benefit_same_deposit_stacking','write_rate_limit_velocity'])assert.ok(rules.has(rule),rule);
 for(const item of report.cases){assert.equal(item.reviewStatus,'unreviewed');assert.equal(item.disposition,'manual_review');assert.equal(item.automaticAction,false);assert.ok(item.evidence.count>=1);assert.ok(item.evidence.firstObservedAt<=item.evidence.lastObservedAt);assert.deepEqual(Object.keys(item.member).sort(),['id','username']);}
 assert.ok(report.cases.every(item=>item.member.id!=='staff-risk'),'staff operations must never become member Bonus Hunter cases');
 const readiness=new Map(report.readiness.map(item=>[item.id,item]));
 assert.equal(readiness.size,14);
 for(const id of ['multi_account','withdrawal_risk','turnover_compliance','game_pattern','provider_reconciliation','bank_reconciliation','chargeback_refund','case_management','real_time_alert'])assert.equal(readiness.get(id).source,'not_connected',id);
 assert.equal(readiness.get('deposit_fraud').source,'deposit_orders');
 assert.equal(readiness.get('bonus_stacking').source,'benefit_claims');
 assert.equal(report.coverage.exhaustive,false);assert.equal(report.coverage.strategy,'bounded_latest_rows');
 const serialized=JSON.stringify(report);
 assert.doesNotMatch(serialized,/private-phone|private-csrf|private-request|private-fingerprint|private-provider-reference|private-claim-key|private-code|private-rules|receipt_data|account_number|secret/i);
 sqlite.close();
});

test('bonus hunter applies strict range, severity and result limits',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);
 await saveBonusRiskConfig(db,{thresholds:{depositAttempts:2,failedOrUnknownDeposits:2,referralFanout:2,benefitClaims:2,benefitClaimsPerDeposit:2,writeRateLimits:1}});
 const low=await bonusRiskReport(db,{now:100000,hours:1,limit:2,severity:'low'});
 assert.equal(low.cases.length,2);assert.equal(low.counts.returned,2);assert.ok(low.cases.every(item=>item.severity==='low'));assert.equal(low.filters.limit,2);assert.ok(low.counts.availableBeforeLimit>=2);
 await assert.rejects(()=>bonusRiskReport(db,{hours:0}),error=>error instanceof BonusRiskError&&error.status===400);
 await assert.rejects(()=>bonusRiskReport(db,{hours:721}),/Invalid hours/);
 await assert.rejects(()=>bonusRiskReport(db,{limit:201}),/Invalid limit/);
 await assert.rejects(()=>bonusRiskReport(db,{severity:'critical'}),/Invalid severity/);
 sqlite.close();
});

test('bonus risk settings stay monitor-only and corrupted storage fails closed to defaults',async()=>{
 const {sqlite,db}=fixture();
 const saved=await saveBonusRiskConfig(db,{thresholds:{depositAttempts:12,failedOrUnknownDeposits:5,referralFanout:30,benefitClaims:8,benefitClaimsPerDeposit:3,writeRateLimits:4}});
 assert.equal(saved.mode,'monitor_only');assert.equal(saved.thresholds.depositAttempts,12);
 assert.equal((await loadBonusRiskConfig(db)).thresholds.referralFanout,30);
 await assert.rejects(()=>saveBonusRiskConfig(db,{mode:'auto_ban'}),/monitor_only/);
 sqlite.prepare('UPDATE settings SET value=? WHERE id=?').run('{broken',BONUS_RISK_SETTING_ID);
 const fallback=await loadBonusRiskConfig(db);assert.equal(fallback.mode,'monitor_only');assert.equal(fallback.thresholds.depositAttempts,8);
 sqlite.close();
});
