import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handleVPay} from '../lib/vpay.ts';

// All gateway replies are synthetic. This suite never contacts VPay.
const origin='https://portal.example.test';
const gateway='https://master7-integration-gateway.onrender.com';
const traderId='fixture-trader';
const orderToken='order-token-'.padEnd(40,'o');
const queryToken='query-token-'.padEnd(40,'q');
const callbackToken='callback-token-'.padEnd(40,'c');

function fixture(t,{status='created'}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 for(const id of ['alice','bob'])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,\'member\',1,?,0)').run(id,id,'csrf-'+id);
 const orderId='fixture-vpay-order',tradeNo='fixture-vpay-trade';
 sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES(?,?,?,?,'vpay',2000,'MYR','2',?,?,0,0)").run(orderId,'alice','fixture-vpay-request','fixture-fingerprint',status,tradeNo);
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sql.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.text).all(...this.args)};}
  async run(){return sql.prepare(this.text).run(...this.args);}
 }
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const results=statements.map(statement=>sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return results;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={queries:0};
 const context={db,user:null,gatewayUrl:gateway,orderToken,queryToken,callbackToken,enabled:'true',mode:'production',vpayTraderId:traderId,returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async(input,init)=>{
  state.queries++;const url=new URL(String(input));assert.equal(url.origin,gateway);assert.equal(url.pathname,'/platform/vpay/order-query');assert.equal(init.method,'POST');assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+queryToken);
  const request=JSON.parse(init.body);assert.deepEqual(request,{outTradeNo:orderId,tradeNo});
  return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:orderId,trade_no:tradeNo,amount:'20.00',state:'3',trader_id:traderId}}});
 }};
 async function callback(){
  const response=await handleVPay(new Request(origin+'/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({out_trade_no:orderId,trade_no:tradeNo,amount:'20.00',state:'3',trader_id:traderId})}),context);
  return {status:response.status,body:await response.text()};
 }
 t.after(()=>sql.close());return {sql,state,orderId,tradeNo,callback};
}

test('a verified VPay callback writes exactly one user-bound balanced ledger',async t=>{
 const f=fixture(t),response=await f.callback();assert.deepEqual(response,{status:200,body:'SUCCESS'});assert.equal(f.state.queries,1);
 const rows=f.sql.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=? ORDER BY account_code').all(f.orderId);
 assert.deepEqual(rows.map(row=>({...row})),[{account_code:'member',amount_minor:2000,currency:'MYR',user_id:'alice'},{account_code:'provider_clearing',amount_minor:-2000,currency:'MYR',user_id:'alice'}]);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'credited');
 assert.deepEqual(await f.callback(),{status:200,body:'SUCCESS'});assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,2);
});

test('partial or foreign-user VPay ledgers are held for review before any financial write',async t=>{
 for(const [name,seed] of [
  ['partial',sql=>sql.prepare("INSERT INTO wallet_ledger VALUES('partial',?,'alice','member',2000,'MYR',0)").run('fixture-vpay-order')],
  ['foreign-user',sql=>sql.exec("INSERT INTO wallet_ledger VALUES('foreign-member','fixture-vpay-order','bob','member',2000,'MYR',0),('foreign-clearing','fixture-vpay-order','bob','provider_clearing',-2000,'MYR',0)")],
 ])await t.test(name,async sub=>{
  const f=fixture(sub);seed(f.sql);const before=f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,response=await f.callback();
  assert.deepEqual(response,{status:503,body:'LEDGER_REVIEW'});assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,before);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare("SELECT COUNT(*) count FROM audit WHERE event='deposit_credited'").get().count,0);
 });
});

test('a credited VPay order with an invalid ledger is moved to review without querying or writing',async t=>{
 const f=fixture(t,{status:'credited'});f.sql.prepare("INSERT INTO wallet_ledger VALUES('bad',?,'alice','member',1,'MYR',0)").run(f.orderId);const response=await f.callback();
 assert.deepEqual(response,{status:503,body:'LEDGER_REVIEW'});assert.equal(f.state.queries,0);assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
});

test('an order already held for review cannot write or acknowledge settlement',async t=>{
 const f=fixture(t,{status:'review'}),response=await f.callback();assert.deepEqual(response,{status:503,body:'LEDGER_REVIEW'});assert.equal(f.state.queries,0);assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
});
