import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handleVPay,refreshVPayOrder,recoverVPayDeposits} from '../lib/vpay.ts';
import {handle} from '../lib/backend.ts';
import {PAYMENT_RECOVERY_MAX_ATTEMPTS,escalateExhaustedPaymentRecoveries} from '../lib/payment-recovery.ts';

// All gateway replies are synthetic. This suite never contacts VPay.
const origin='https://portal.example.test';
const gateway='https://master7-integration-gateway.onrender.com';
const traderId='fixture-trader';
const orderToken='order-token-'.padEnd(40,'o');
const queryToken='query-token-'.padEnd(40,'q');
const callbackToken='callback-token-'.padEnd(40,'c');

function fixture(t,{status='created'}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 for(const id of ['alice','bob'])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,\'member\',1,?,0)').run(id,id,'csrf-'+id);
 const orderId='fixture-vpay-order',tradeNo='fixture-vpay-trade';
 sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES(?,?,?,?,'vpay',2000,'MYR','2',?,?,0,0)").run(orderId,'alice','fixture-vpay-request','fixture-fingerprint',status,tradeNo);
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sql.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.text).all(...this.args)};}
  async run(){return sql.prepare(this.text).run(...this.args);}
 }
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const results=statements.map(statement=>sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return results;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={queries:0,configReads:0,queryPatch:data=>data,failQuery:false,requests:[]};
 const context={db,user:null,gatewayUrl:gateway,orderToken,queryToken,callbackToken,enabled:'true',newDepositsEnabled:'true',mode:'production',vpayTraderId:traderId,returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async(input,init)=>{
  const url=new URL(String(input));assert.equal(url.origin,gateway);
  if(url.pathname==='/platform/vpay/config'){state.configReads++;assert.equal(init.method,'GET');assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+queryToken);return Response.json({provider:'vpay',mode:'production',paymentReady:true,traderId,notifyUrl:gateway+'/callbacks/vpay/payment',returnUrl:context.returnUrl,tradeCodes:['2']});}
  state.queries++;assert.equal(url.pathname,'/platform/vpay/order-query');assert.equal(init.method,'POST');assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+queryToken);
  if(state.failQuery)throw Error('synthetic provider timeout');
  const request=JSON.parse(init.body);state.requests.push(request);assert.equal(request.outTradeNo,orderId);if(Object.hasOwn(request,'tradeNo'))assert.equal(request.tradeNo,tradeNo);
  return Response.json({provider:'vpay',result:{code:0,data:state.queryPatch({out_trade_no:orderId,trade_no:tradeNo,amount:'20.00',state:'3',trader_id:traderId})}});
 }};
 async function callback(patch={},authorization='Bearer '+callbackToken){
  const response=await handleVPay(new Request(origin+'/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:authorization,'Content-Type':'application/json'},body:JSON.stringify({out_trade_no:orderId,trade_no:tradeNo,amount:'20.00',state:'3',trader_id:traderId,...patch})}),context);
  return {status:response.status,body:await response.text()};
 }
 t.after(()=>sql.close());return {sql,state,orderId,tradeNo,callback,context};
}

test('a verified VPay callback writes exactly one user-bound balanced ledger',async t=>{
 const f=fixture(t),response=await f.callback();assert.deepEqual(response,{status:200,body:'SUCCESS'});assert.equal(f.state.queries,1);
 const rows=f.sql.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=? ORDER BY account_code').all(f.orderId);
 assert.deepEqual(rows.map(row=>({...row})),[{account_code:'member',amount_minor:2000,currency:'MYR',user_id:'alice'},{account_code:'provider_clearing',amount_minor:-2000,currency:'MYR',user_id:'alice'}]);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'credited');
 assert.equal(f.sql.prepare("SELECT COUNT(*) count FROM audit WHERE event='vpay_callback_authenticated' AND target=?").get(f.orderId).count,1);
 assert.deepEqual(await f.callback(),{status:200,body:'SUCCESS'});assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,2);
 assert.equal(f.sql.prepare("SELECT COUNT(*) count FROM audit WHERE event='vpay_callback_authenticated' AND target=?").get(f.orderId).count,1);
});
test('VPay successful deposit updates only the paying member wallet and records',async t=>{
 const f=fixture(t);assert.equal((await f.callback()).status,200);
 async function read(path,id){const user={id,username:id,role:'member',approved:1,csrf:'csrf-'+id};const response=await handleVPay(new Request(origin+path),{...f.context,user});assert.equal(response.status,200);return response.json();}
 const alice=await read('/api/wallet','alice'),bob=await read('/api/wallet','bob');
 assert.equal(alice.balanceMinor,'2000');assert.equal(bob.balanceMinor,'0');
 const aliceRecords=await read('/api/payment-records','alice'),bobRecords=await read('/api/payment-records','bob');
 assert.ok(aliceRecords.items.some(item=>item.id===f.orderId));assert.ok(bobRecords.items.every(item=>item.id!==f.orderId));
});

test('VPay explicitly confirmed MYR credits once and duplicate notifications remain idempotent',async t=>{
 const f=fixture(t);f.state.queryPatch=data=>({...data,currency:'MYR'});
 for(let i=0;i<3;i++)assert.deepEqual(await f.callback(),{status:200,body:'SUCCESS'});
 assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
 assert.equal(f.sql.prepare('SELECT SUM(amount_minor) total FROM wallet_ledger').get().total,0);
 assert.equal(f.sql.prepare("SELECT amount_minor FROM wallet_ledger WHERE account_code='member'").get().amount_minor,2000);
});

test('concurrent VPay success notifications create one balanced credit',async t=>{
 const f=fixture(t),responses=await Promise.all([f.callback(),f.callback(),f.callback()]);
 assert.ok(responses.every(response=>response.status===200&&response.body==='SUCCESS'));
 const rows=f.sql.prepare('SELECT account_code,amount_minor FROM wallet_ledger WHERE order_id=? ORDER BY account_code').all(f.orderId);
 assert.deepEqual(rows.map(row=>({...row})),[{account_code:'member',amount_minor:2000},{account_code:'provider_clearing',amount_minor:-2000}]);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'credited');
});

test('VPay independently queried currency, amount and order bindings fail closed',async t=>{
 for(const [field,value] of [['currency','USD'],['amount','21.00'],['out_trade_no','another-order'],['trade_no','another-trade']])await t.test(field,async sub=>{
  const f=fixture(sub);f.state.queryPatch=data=>({...data,[field]:value});
  assert.deepEqual(await f.callback(),{status:503,body:'LEDGER_REVIEW'});assert.equal(f.state.queries,1);
  assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
  assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
  assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='deposit_credited'").get().n,0);
 });
});

test('VPay callback authentication and original order bindings reject invalid notifications without crediting',async t=>{
 const cases=[
  {name:'wrong gateway token',authorization:'Bearer invalid',status:401},
  {name:'wrong amount',patch:{amount:'21.00'},status:502},
  {name:'wrong order',patch:{out_trade_no:'another-order'},status:404},
  {name:'wrong transaction',patch:{trade_no:'another-trade'},status:502},
 ];
 for(const scenario of cases)await t.test(scenario.name,async sub=>{
  const f=fixture(sub),response=await f.callback(scenario.patch,scenario.authorization);assert.equal(response.status,scenario.status);
  assert.equal(f.state.queries,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
  assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_callback_authenticated'").get().n,0);
 });
});

test('partial or foreign-user VPay ledgers are held for review before any financial write',async t=>{
 for(const [name,seed] of [
  ['partial',sql=>sql.prepare("INSERT INTO wallet_ledger VALUES('partial',?,'alice','member',2000,'MYR',0)").run('fixture-vpay-order')],
  ['foreign-user',sql=>sql.exec("INSERT INTO wallet_ledger VALUES('foreign-member','fixture-vpay-order','bob','member',2000,'MYR',0),('foreign-clearing','fixture-vpay-order','bob','provider_clearing',-2000,'MYR',0)")],
 ])await t.test(name,async sub=>{
  const f=fixture(sub);seed(f.sql);const before=f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,response=await f.callback();
  assert.deepEqual(response,{status:503,body:'LEDGER_REVIEW'});assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,before);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare("SELECT COUNT(*) count FROM audit WHERE event='deposit_credited'").get().count,0);
 });
});

test('a credited VPay order with an invalid ledger is moved to review without querying or writing',async t=>{
 const f=fixture(t,{status:'credited'});f.sql.prepare("INSERT INTO wallet_ledger VALUES('bad',?,'alice','member',1,'MYR',0)").run(f.orderId);const response=await f.callback();
 assert.deepEqual(response,{status:503,body:'LEDGER_REVIEW'});assert.equal(f.state.queries,0);assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
});

test('an order already held for review cannot write or acknowledge settlement',async t=>{
 const f=fixture(t,{status:'review'}),response=await f.callback();assert.deepEqual(response,{status:503,body:'LEDGER_REVIEW'});assert.equal(f.state.queries,0);assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
});

test('member refresh is owner-bound and can recover a deposit while new orders are closed',async t=>{
 const f=fixture(t);f.context.enabled='false';f.context.user={id:'bob',username:'bob',role:'member',approved:1};
 let response=await refreshVPayOrder({orderId:f.orderId},f.context);assert.equal(response.status,404);assert.equal(f.state.queries,0);
 f.context.user={id:'alice',username:'alice',role:'member',approved:1};response=await refreshVPayOrder({orderId:f.orderId},f.context);assert.equal(response.status,200);assert.deepEqual(await response.json(),{id:f.orderId,status:'credited'});assert.equal(f.state.queries,1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger WHERE order_id=?').get(f.orderId).count,2);
});

test('VPay recovery is default-off and independently credits exactly one balanced ledger when enabled',async t=>{
 const f=fixture(t);f.context.enabled='false';
 let summary=await recoverVPayDeposits(f.context);assert.equal(summary.enabled,false);assert.equal(f.state.queries,0);
 f.context.recoveryEnabled='true';summary=await recoverVPayDeposits(f.context);assert.equal(summary.enabled,true);assert.equal(summary.credited,1);assert.equal(summary.queried,1);assert.equal(f.state.queries,1);
 summary=await recoverVPayDeposits(f.context);assert.equal(summary.scanned,0);assert.equal(f.state.queries,1);
 const rows=f.sql.prepare('SELECT account_code,amount_minor,user_id FROM wallet_ledger WHERE order_id=? ORDER BY account_code').all(f.orderId);assert.deepEqual(rows.map(row=>({...row})),[{account_code:'member',amount_minor:2000,user_id:'alice'},{account_code:'provider_clearing',amount_minor:-2000,user_id:'alice'}]);
});

test('disabled provider querying still escalates exhausted recovery locally without a financial write',async t=>{
 const f=fixture(t,{status:'unknown'});f.sql.prepare("INSERT INTO payment_recovery_leases(provider,order_id,claim_token,locked_until,last_checked_at,attempts) VALUES('vpay',?,'old',0,0,?)").run(f.orderId,PAYMENT_RECOVERY_MAX_ATTEMPTS);
 const first=await recoverVPayDeposits(f.context),second=await recoverVPayDeposits(f.context);
 assert.equal(first.enabled,false);assert.equal(first.escalated,1);assert.equal(second.escalated,0);assert.equal(f.state.queries,0);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'unknown');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('an exhausted VPay recovery remains eligible for a late verified callback exactly once',async t=>{
 const f=fixture(t,{status:'unknown'});f.sql.prepare("INSERT INTO payment_recovery_leases(provider,order_id,claim_token,locked_until,last_checked_at,attempts) VALUES('vpay',?,'old',0,0,?)").run(f.orderId,PAYMENT_RECOVERY_MAX_ATTEMPTS);
 assert.equal(await escalateExhaustedPaymentRecoveries(f.context.db,'vpay',100000),1);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'unknown');
 assert.equal((await f.callback()).status,200);assert.equal((await f.callback()).status,200);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').get(f.orderId).n,2);
 assert.equal(f.sql.prepare('SELECT SUM(amount_minor) n FROM wallet_ledger WHERE order_id=?').get(f.orderId).n,0);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='payment_recovery_manual_review' AND target=?").get(f.orderId).n,1);
});

test('VPay keeps a trusted callback reference when the independent query times out, then recovers once',async t=>{
 const f=fixture(t,{status:'unknown'});f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL WHERE id=?').run(f.orderId);
 assert.equal((await f.callback({},'Bearer wrong')).status,401);assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(f.orderId).provider_trade_no,null);
 f.state.failQuery=true;assert.deepEqual(await f.callback(),{status:502,body:'PENDING'});assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(f.orderId).provider_trade_no,f.tradeNo);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_callback_authenticated' AND target=?").get(f.orderId).n,1);
 f.state.failQuery=false;f.context.recoveryEnabled='true';const first=await recoverVPayDeposits(f.context),second=await recoverVPayDeposits(f.context);assert.equal(first.credited,1);assert.equal(second.scanned,0);assert.equal(f.state.queries,2);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

for(const status of ['creating','unknown'])test(`VPay recovers a stale ${status} order using its own ID when the provider reference was lost`,async t=>{
 const f=fixture(t,{status});f.context.recoveryEnabled='true';f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL,updated_at=0 WHERE id=?').run(f.orderId);
 const result=await recoverVPayDeposits(f.context);assert.equal(result.credited,1);assert.deepEqual(f.state.requests,[{outTradeNo:f.orderId}]);
 assert.deepEqual({...f.sql.prepare('SELECT status,provider_trade_no FROM deposit_orders WHERE id=?').get(f.orderId)},{status:'credited',provider_trade_no:f.tradeNo});
 assert.equal((await recoverVPayDeposits(f.context)).scanned,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('VPay missing-reference recovery retains a matching pending reference and never credits before paid',async t=>{
 const f=fixture(t,{status:'unknown'});f.context.recoveryEnabled='true';f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL,updated_at=0 WHERE id=?').run(f.orderId);f.state.queryPatch=data=>({...data,state:'2'});
 const result=await recoverVPayDeposits(f.context);assert.equal(result.pending,1);assert.deepEqual(f.state.requests,[{outTradeNo:f.orderId}]);
 assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(f.orderId).provider_trade_no,f.tradeNo);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

for(const [field,value] of [['out_trade_no','another-order'],['amount','21.00'],['currency','USD'],['trader_id','other-trader']])test(`VPay missing-reference recovery holds a mismatched ${field} without credit`,async t=>{
 const f=fixture(t,{status:'unknown'});f.context.recoveryEnabled='true';f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL,updated_at=0 WHERE id=?').run(f.orderId);f.state.queryPatch=data=>({...data,[field]:value});
 const result=await recoverVPayDeposits(f.context);assert.equal(result.review,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('VPay missing-reference recovery waits when the provider omits its transaction reference',async t=>{
 const f=fixture(t,{status:'unknown'});f.context.recoveryEnabled='true';f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL,updated_at=0 WHERE id=?').run(f.orderId);f.state.queryPatch=data=>{delete data.trade_no;return data;};
 const result=await recoverVPayDeposits(f.context);assert.equal(result.pending,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(f.orderId).provider_trade_no,null);
});

test('VPay recovery does not race a recently started request with no provider reference',async t=>{
 const f=fixture(t,{status:'creating'});f.context.recoveryEnabled='true';f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL,updated_at=? WHERE id=?').run(Math.floor(Date.now()/1000),f.orderId);
 const result=await recoverVPayDeposits(f.context);assert.equal(result.scanned,0);assert.equal(f.state.queries,0);
});

test('VPay member refresh recovers only the owners stale missing-reference order while new deposits are paused',async t=>{
 const f=fixture(t,{status:'unknown'});f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL,updated_at=0 WHERE id=?').run(f.orderId);
 f.context.enabled='false';f.context.newDepositsEnabled='false';f.context.user={id:'bob',username:'bob',role:'member',approved:1};
 assert.equal((await refreshVPayOrder({orderId:f.orderId},f.context)).status,404);assert.equal(f.state.queries,0);
 f.context.user={id:'alice',username:'alice',role:'member',approved:1};const response=await refreshVPayOrder({orderId:f.orderId},f.context);
 assert.equal(response.status,200);assert.equal((await response.json()).status,'credited');assert.deepEqual(f.state.requests,[{outTradeNo:f.orderId}]);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('VPay does not automatically query failed orders that never received a provider reference',async t=>{
 const f=fixture(t,{status:'failed'});f.context.recoveryEnabled='true';f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL,updated_at=0 WHERE id=?').run(f.orderId);
 const result=await recoverVPayDeposits(f.context);assert.equal(result.scanned,0);assert.equal(f.state.queries,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('a future non-MYR VPay order cannot be queried or credited as MYR',async t=>{
 const f=fixture(t);f.sql.exec("PRAGMA ignore_check_constraints=ON; UPDATE deposit_orders SET currency='USDT'; PRAGMA ignore_check_constraints=OFF;");f.context.recoveryEnabled='true';
 const recovered=await recoverVPayDeposits(f.context);assert.equal(recovered.scanned,0);assert.equal(f.state.queries,0);
 assert.deepEqual(await f.callback(),{status:409,body:'CURRENCY_MISMATCH'});f.context.user={id:'alice',username:'alice',role:'member',approved:1};assert.equal((await refreshVPayOrder({orderId:f.orderId},f.context)).status,409);assert.equal(f.state.queries,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('VPay cannot post MYR if the order currency changes during the provider query',async t=>{
 const f=fixture(t);f.state.queryPatch=data=>{f.sql.exec("PRAGMA ignore_check_constraints=ON; UPDATE deposit_orders SET currency='USDT'; PRAGMA ignore_check_constraints=OFF;");return data;};
 const response=await f.callback();assert.notEqual(response.status,200);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);assert.notEqual(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'credited');
});

test('VPay recovery holds independently successful funds when member eligibility changed',async t=>{
 const f=fixture(t);f.context.recoveryEnabled='true';f.sql.prepare('UPDATE users SET approved=0 WHERE id=?').run('alice');
 const summary=await recoverVPayDeposits(f.context);assert.equal(summary.review,1);assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) count FROM wallet_ledger WHERE order_id=?').get(f.orderId).count,0);
});

test('VPay profile switch blocks new orders while query and callback capability remain ready',async t=>{
 const f=fixture(t);f.context.enabled='false';const response=await handleVPay(new Request(origin+'/api/payments/vpay/status'),f.context),status=await response.json();
 assert.equal(status.orderReady,false);assert.equal(status.queryReady,true);assert.equal(status.callbacksReady,true);assert.equal(status.recoveryReady,false);assert.equal(status.payoutReady,false);assert.equal(status.balanceReady,false);assert.equal(status.reason,'profile_orders_disabled');assert.equal(status.capabilities.deposit.configured,true);assert.equal(status.capabilities.deposit.enabled,false);assert.equal(status.capabilities.payout.submissionEnabled,false);assert.equal(status.capabilities.balance.implemented,false);assert.equal(status.availabilityMode,'automatic');assert.equal(status.readOnly,true);assert.equal(f.state.queries,0);assert.equal(f.state.configReads,1);
});

test('router continues verified VPay callbacks for an existing order with the review gate enabled',async t=>{
 const f=fixture(t),config={db:f.context.db,identity:null,ownerEmail:'',manualComplianceEnforced:'true',vpayGatewayUrl:gateway,vpayOrderToken:orderToken,vpayQueryToken:queryToken,vpayCallbackToken:callbackToken,vpayMode:'production',vpayTraderId:traderId,vpayReturnUrl:f.context.returnUrl,vpayFetch:f.context.fetchImpl};
 f.sql.prepare("INSERT INTO settings(id,value) VALUES('deposit_control:vpay','paused')").run();
 async function send(){return handle(new Request(origin+'/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({out_trade_no:f.orderId,trade_no:f.tradeNo,amount:'20.00',state:'3',trader_id:traderId})}),config);}
 assert.equal((await send()).status,200);assert.equal((await send()).status,200);
 assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('closing new deposits leaves a preexisting VPay callback and wallet credit recoverable once',async t=>{
 const f=fixture(t);f.context.newDepositsEnabled='false';f.context.user={id:'alice',username:'alice',role:'member',approved:1};
 const response=await handleVPay(new Request(origin+'/api/payments/vpay/status'),f.context),status=await response.json();assert.equal(status.orderReady,false);assert.equal(status.queryReady,true);assert.equal(status.callbacksReady,true);
 const queried=await refreshVPayOrder({orderId:f.orderId},f.context);assert.equal(queried.status,200);assert.deepEqual(await queried.json(),{id:f.orderId,status:'credited'});
 assert.equal((await f.callback()).status,200);assert.equal((await f.callback()).status,200);assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('VPay never confirms a credited callback after the order changes to review during verification',async t=>{
 const f=fixture(t);assert.equal((await f.callback()).status,200);
 const original=f.context.db.prepare;let injected=false;
 f.context.db.prepare=text=>{if(!injected&&text.includes('SELECT o.id FROM deposit_orders o')){injected=true;f.sql.prepare("UPDATE deposit_orders SET status='review' WHERE id=?").run(f.orderId);}return original(text);};
 const response=await f.callback();assert.equal(response.status,503);assert.equal(response.body,'LEDGER_REVIEW');assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('VPay refresh never reports credited after an independent query races with review',async t=>{
 const f=fixture(t);assert.equal((await f.callback()).status,200);f.context.user={id:'alice',username:'alice',role:'member',approved:1};
 f.state.queryPatch=data=>{f.sql.prepare("UPDATE deposit_orders SET status='review' WHERE id=?").run(f.orderId);return data;};
 const response=await refreshVPayOrder({orderId:f.orderId},f.context);assert.equal(response.status,409);assert.equal((await response.json()).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('VPay cannot post funds when order amount or member changes during the verified query',async t=>{
 for(const field of ['amount','member'])await t.test(field,async sub=>{
  const f=fixture(sub);f.state.queryPatch=data=>{if(field==='amount')f.sql.prepare('UPDATE deposit_orders SET amount_minor=2100 WHERE id=?').run(f.orderId);else f.sql.prepare("UPDATE deposit_orders SET user_id='bob' WHERE id=?").run(f.orderId);return data;};
  const response=await f.callback();assert.notEqual(response.status,200);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);assert.notEqual(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'credited');
 });
});

test('VPay failed query holds a historical partial member ledger for review instead of releasing the member',async t=>{
 const f=fixture(t);f.sql.prepare("INSERT INTO wallet_ledger VALUES('partial-failed',?,'alice','member',2000,'MYR',0)").run(f.orderId);
 f.state.queryPatch=data=>({...data,state:'1'});const response=await f.callback();
 assert.equal(response.status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,1);
 f.context.user={id:'alice',username:'alice',role:'member',approved:1};const wallet=await handleVPay(new Request(origin+'/api/wallet'),f.context);const state=await wallet.json();assert.equal(state.reconciliationRequired,true);assert.equal(state.availableMinor,'0');
});

test('VPay failure query racing with a credited order preserves its ledger and moves it to review',async t=>{
 const f=fixture(t);f.state.queryPatch=data=>{
  f.sql.prepare("INSERT INTO wallet_ledger VALUES('race-member',?,'alice','member',2000,'MYR',0)").run(f.orderId);
  f.sql.prepare("INSERT INTO wallet_ledger VALUES('race-clearing',?,'alice','provider_clearing',-2000,'MYR',0)").run(f.orderId);
  f.sql.prepare("UPDATE deposit_orders SET status='credited' WHERE id=?").run(f.orderId);
  return {...data,state:'1'};
 };
 const response=await f.callback();assert.equal(response.status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);assert.equal(f.sql.prepare('SELECT SUM(amount_minor) n FROM wallet_ledger').get().n,0);
});

test('VPay never marks credited when a conflicting ledger appears before the posting transaction',async t=>{
 const f=fixture(t),original=f.context.db.batch;let injected=false;
 f.context.db.batch=async statements=>{if(!injected&&statements.some(statement=>statement.text.includes('INSERT INTO wallet_ledger'))){injected=true;f.sql.prepare("INSERT INTO wallet_ledger VALUES('conflict-ledger',?,'alice','member',1,'MYR',0)").run(f.orderId);}return original(statements);};
 const response=await f.callback();assert.equal(response.status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,1);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='deposit_credited'").get().n,0);
 f.context.user={id:'alice',username:'alice',role:'member',approved:1};const wallet=await handleVPay(new Request(origin+'/api/wallet'),f.context),state=await wallet.json();assert.equal(state.reconciliationRequired,true);assert.equal(state.availableMinor,'0');
});

test('VPay success after an already failed order goes to review without automatic credit',async t=>{
 const f=fixture(t,{status:'failed'});const response=await f.callback();assert.equal(response.status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_late_success_review'").get().n,1);
});

test('VPay success query racing with a failure preserves the contradiction for review',async t=>{
 const f=fixture(t);f.state.queryPatch=data=>{f.sql.prepare("UPDATE deposit_orders SET status='failed' WHERE id=?").run(f.orderId);return data;};const response=await f.callback();assert.equal(response.status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});
