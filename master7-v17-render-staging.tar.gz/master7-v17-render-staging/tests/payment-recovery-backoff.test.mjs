import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {postgresSql} from '../lib/render-sql.mjs';
import {PAYMENT_RECOVERY_MAX_ATTEMPTS,claimPaymentRecovery,escalateExhaustedPaymentRecoveries,finishPaymentRecovery,paymentRecoveryBackoffSeconds,recoveryCandidates} from '../lib/payment-recovery.ts';

function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf',0)").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text)};
 const order=(id,provider='vpay')=>sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,'alice',?,?,?,2000,'MYR','payment','unknown',0,0)").run(id,'request-'+id,'fingerprint-'+id,provider);
 t.after(()=>sql.close());return {sql,db,order};
}

test('payment recovery backoff grows deterministically and caps at six hours',()=>{
 assert.equal(PAYMENT_RECOVERY_MAX_ATTEMPTS,12);
 assert.deepEqual([0,1,2,3,4,5,6,7,8,9,10,40].map(paymentRecoveryBackoffSeconds),[60,120,240,480,960,1920,3840,7680,15360,21600,21600,21600]);
});

test('a lease cannot be reclaimed before its backoff and concurrent claims yield one owner',async t=>{
 const f=fixture(t);f.order('backoff-order');
 f.sql.prepare("INSERT INTO payment_recovery_leases(provider,order_id,claim_token,locked_until,last_checked_at,attempts) VALUES('vpay','backoff-order','old',0,100,1)").run();
 assert.equal(await claimPaymentRecovery(f.db,'vpay','backoff-order',219),null);
 const [first,second]=await Promise.all([claimPaymentRecovery(f.db,'vpay','backoff-order',220),claimPaymentRecovery(f.db,'vpay','backoff-order',220)]);
 assert.equal([first,second].filter(Boolean).length,1);assert.equal(f.sql.prepare("SELECT attempts FROM payment_recovery_leases WHERE order_id='backoff-order'").get().attempts,2);
 await finishPaymentRecovery(f.db,'vpay','backoff-order',first??second,220);
 assert.equal((await recoveryCandidates(f.db,'vpay',25,459)).length,0);
 assert.equal((await recoveryCandidates(f.db,'vpay',25,460)).length,1);
});

test('exhausted and historical high-attempt leases enter one manual queue without changing the order',async t=>{
 const f=fixture(t);f.order('exhausted-order');f.order('legacy-order');
 for(const [id,attempts] of [['exhausted-order',PAYMENT_RECOVERY_MAX_ATTEMPTS],['legacy-order',435]])f.sql.prepare("INSERT INTO payment_recovery_leases(provider,order_id,claim_token,locked_until,last_checked_at,attempts) VALUES('vpay',?,'old',0,0,?)").run(id,attempts);
 assert.equal((await recoveryCandidates(f.db,'vpay',25,100000)).length,0);
 assert.equal(await claimPaymentRecovery(f.db,'vpay','legacy-order',100000),null);
 assert.equal(await escalateExhaustedPaymentRecoveries(f.db,'vpay',100000),2);
 assert.equal(await escalateExhaustedPaymentRecoveries(f.db,'vpay',100001),0);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='payment_recovery_manual_review'").get().n,2);
 assert.deepEqual(f.sql.prepare("SELECT id,status FROM deposit_orders ORDER BY id").all().map(row=>({...row})),[{id:'exhausted-order',status:'unknown'},{id:'legacy-order',status:'unknown'}]);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});


test('PostgreSQL translation preserves atomic claim guards and idempotent escalation',async()=>{
 const prepared=[];
 const db={prepare(text){return {bind(...args){prepared.push({text,args});return {async first(){return null;},async all(){return {results:[]};}};}};}};
 await claimPaymentRecovery(db,'vpay','postgres-order',1000);
 await escalateExhaustedPaymentRecoveries(db,'vpay',1000);
 await recoveryCandidates(db,'vpay',25,1000);
 assert.equal(prepared.length,3);
 const translated=prepared.map(({text,args})=>{
  const sql=postgresSql(text),numbers=[...sql.matchAll(/\$(\d+)/g)].map(match=>Number(match[1]));
  assert.equal(sql.includes('?'),false);
  assert.equal(Math.max(...numbers),args.length);
  return sql;
 });
 assert.match(translated[0],/ON CONFLICT\(provider,order_id\) DO UPDATE/);
 assert.match(translated[0],/payment_recovery_leases\.attempts<\$6/);
 assert.match(translated[0],/RETURNING claim_token/);
 assert.match(translated[1],/ON CONFLICT\(id\) DO NOTHING RETURNING id/);
 assert.match(translated[1],/r\.attempts>=\$3/);
 assert.match(translated[2],/r\.attempts IS NULL OR r\.attempts<\$5/);
});
