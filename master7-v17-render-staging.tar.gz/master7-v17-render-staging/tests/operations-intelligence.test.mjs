import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {operationsIntelligenceReport,operationsWindow} from '../lib/operations-intelligence.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}

function fixture(){
 const sqlite=new DatabaseSync(':memory:');
 sqlite.exec(`
  CREATE TABLE users(id TEXT PRIMARY KEY,role TEXT,approved INTEGER,created_at INTEGER);
  CREATE TABLE deposit_orders(id TEXT PRIMARY KEY,user_id TEXT,provider TEXT,amount_minor INTEGER,status TEXT,created_at INTEGER,updated_at INTEGER);
  CREATE TABLE withdrawal_requests(id TEXT PRIMARY KEY,user_id TEXT,amount_minor INTEGER,status TEXT,created_at INTEGER,updated_at INTEGER);
  CREATE TABLE company_bank_accounts(id TEXT PRIMARY KEY,enabled INTEGER,account_name TEXT,account_number TEXT);
  CREATE TABLE manual_deposit_requests(deposit_order_id TEXT PRIMARY KEY,receipt_data TEXT);
  CREATE TABLE tickets(id TEXT PRIMARY KEY,user_id TEXT,status TEXT,created_at INTEGER,message TEXT);
  CREATE TABLE game_wallet_sessions(id TEXT PRIMARY KEY,status TEXT,created_at INTEGER,player_id TEXT);
  CREATE TABLE game_catalogue_cache(provider_id TEXT PRIMARY KEY,status TEXT,checked_at INTEGER,last_success_at INTEGER,complete INTEGER);
  CREATE TABLE providers(id TEXT PRIMARY KEY,visible INTEGER);
  CREATE TABLE marketing_campaigns(id TEXT PRIMARY KEY,status TEXT,message TEXT);
  CREATE TABLE marketing_contacts(id TEXT PRIMARY KEY,consent_status TEXT,phone TEXT);
  CREATE TABLE wallet_ledger(id TEXT PRIMARY KEY,order_id TEXT,user_id TEXT,account_code TEXT,amount_minor INTEGER);
  CREATE TABLE benefit_claims(id TEXT PRIMARY KEY,status TEXT);
  CREATE TABLE commission_periods(id TEXT PRIMARY KEY,status TEXT,total_commission_minor INTEGER);
 `);
 return {sqlite,db:{prepare:sql=>new Statement(sqlite,sql)}};
}

test('operations intelligence exposes aggregate evidence and never performs an action',async()=>{
 const {sqlite,db}=fixture();
 sqlite.exec(`
  INSERT INTO users VALUES('u1','member',1,1100),('u2','member',0,900),('owner','owner',1,1);
  INSERT INTO deposit_orders VALUES('d1','u1','manual_bank',1000,'credited',1200,1200),('d2','u1','vpay',2000,'unknown',1300,1300),('d3','u2','vpay',3000,'failed',1400,1400),('d4','u2','manual_bank',4000,'pending',1500,1500);
  INSERT INTO withdrawal_requests VALUES('w1','u1',500,'pending',1600,1600);
  INSERT INTO manual_deposit_requests VALUES('d4','private-receipt');
  INSERT INTO tickets VALUES('t1','u1','open',1700,'private-ticket-message');
  INSERT INTO game_wallet_sessions VALUES('g1','manual_review',1800,'private-player-id');
  INSERT INTO game_catalogue_cache VALUES('bad','unavailable',1800,0,0),('good','available',1800,1700,1);
  INSERT INTO providers VALUES('bad',1),('good',1);
  INSERT INTO marketing_campaigns VALUES('c1','draft','private-campaign-message');
  INSERT INTO marketing_contacts VALUES('m1','opted_in','private-phone');
  INSERT INTO wallet_ledger VALUES('l1','d1','u1','member',1000),('l2','d1','u1','provider_clearing',-1000);
  INSERT INTO benefit_claims VALUES('b1','awaiting_acceptance');
  INSERT INTO commission_periods VALUES('p1','preview',88);
 `);
 const report=await operationsIntelligenceReport(db,{period:'day',start:1000,end:2000,label:'test'},{productionReady:false,paymentsReady:false,payoutsReady:false,settlementVerified:false,gamesReady:false,whatsappReady:false,supportAiProviderReady:false,expectedCatalogueIds:['bad','good']},2001);
 assert.equal(report.reportType,'operations_intelligence_v1');
 assert.equal(report.assistant.mode,'deterministic_rules');
 assert.equal(report.assistant.readOnly,true);
 assert.deepEqual(report.control,{actionsEnabled:false,approvalRequiredForAllActions:true,automaticWalletCredit:false,automaticDepositApproval:false,automaticWithdrawalApproval:false,automaticPayout:false,automaticAccountSanction:false,automaticCampaignSend:false});
 assert.equal(report.metrics.deposits.creditedMinor,'1000');
 assert.equal(report.metrics.companyBank.status,'not_configured');
 assert.equal(report.metrics.reconciliation.status,'matched');
 assert.equal(report.metrics.rewards.walletPostingEnabled,false);
 const ids=new Set(report.recommendations.map(item=>item.id));
 for(const id of ['configure_company_bank','review_manual_deposits','review_pending_deposits','reconcile_unknown_deposits','review_withdrawals','complete_production_readiness','complete_payment_acceptance','complete_payout_acceptance','verify_settlement','complete_game_acceptance','review_game_wallet_sessions','answer_support_tickets','repair_catalogue_connections','inspect_failed_deposits','complete_whatsapp_setup'])assert.ok(ids.has(id),id);
 assert.ok(report.recommendations.every(item=>item.approvalRequired&&item.automaticAction===false));
 const serialized=JSON.stringify(report);
 assert.doesNotMatch(serialized,/private-receipt|private-ticket-message|private-player-id|private-campaign-message|private-phone/);
 sqlite.close();
});

test('operations intelligence identifies internal ledger mismatches without inventing external settlement',async()=>{
 const {sqlite,db}=fixture();
 sqlite.exec(`
  INSERT INTO users VALUES('u1','member',1,1100);
  INSERT INTO deposit_orders VALUES('d1','u1','vpay',1000,'credited',1200,1200);
  INSERT INTO wallet_ledger VALUES('l1','d1','u1','member',900),('l2','d1','u1','provider_clearing',-900);
 `);
 const report=await operationsIntelligenceReport(db,{period:'week',start:1000,end:2000,label:'week'},{productionReady:false,paymentsReady:true,payoutsReady:true,settlementVerified:false,gamesReady:true,whatsappReady:true},2001);
 assert.equal(report.metrics.reconciliation.status,'mismatch');
 assert.equal(report.metrics.reconciliation.creditedMinor,'1000');
 assert.ok(report.recommendations.some(item=>item.id==='review_wallet_reconciliation'&&item.severity==='critical'));
 assert.equal(report.summary.status,'critical');
 sqlite.close();
});

test('settled money uses updated time and reconciliation is checked per order',async()=>{
 const {sqlite,db}=fixture();
 sqlite.exec(`
  INSERT INTO users VALUES('u1','member',1,100),('u2','member',1,100);
  INSERT INTO company_bank_accounts VALUES('bank',1,'private-name','private-number');
  INSERT INTO deposit_orders VALUES('d1','u1','vpay',1000,'credited',100,1200),('d2','u2','vpay',1000,'credited',100,1300);
  INSERT INTO wallet_ledger VALUES('l1','d1','u1','member',900),('l2','d1','u1','provider_clearing',-900),('l3','d2','u2','member',1100),('l4','d2','u2','provider_clearing',-1100);
  INSERT INTO withdrawal_requests VALUES('w1','u1',500,'paid',100,1400);
  INSERT INTO providers VALUES('good',1);
  INSERT INTO game_catalogue_cache VALUES('good','available',1900,1900,1);
 `);
 const report=await operationsIntelligenceReport(db,{period:'day',start:1000,end:2000,label:'settled'},{productionReady:true,paymentsReady:true,payoutsReady:true,settlementVerified:true,gamesReady:true,whatsappReady:true,expectedCatalogueIds:['good']},2001);
 assert.equal(report.metrics.deposits.createdOrders,0);
 assert.equal(report.metrics.deposits.creditedOrders,2);
 assert.equal(report.metrics.deposits.creditedMinor,'2000');
 assert.equal(report.metrics.withdrawals.createdOrders,0);
 assert.equal(report.metrics.withdrawals.paidOrders,1);
 assert.equal(report.metrics.withdrawals.paidMinor,'500');
 assert.equal(report.metrics.reconciliation.status,'mismatch');
 assert.equal(report.metrics.reconciliation.mismatchOrders,2);
 assert.ok(report.recommendations.some(item=>item.id==='review_wallet_reconciliation'));
 sqlite.close();
});

test('empty settlement and configured catalogue inventory remain no-activity and no-data',async()=>{
 const {sqlite,db}=fixture();
 const report=await operationsIntelligenceReport(db,{period:'day',start:1000,end:2000,label:'empty'},{productionReady:false,expectedCatalogueIds:['good']},2001);
 assert.equal(report.metrics.reconciliation.status,'no_activity');
 assert.equal(report.metrics.reconciliation.matched,null);
 assert.equal(report.metrics.catalogue.status,'no_data');
 assert.equal(report.recommendations.some(item=>item.id==='review_wallet_reconciliation'),false);
 assert.ok(report.recommendations.some(item=>item.id==='repair_catalogue_connections'));
 assert.notEqual(report.summary.status,'ready');
 sqlite.close();
});

test('current backlogs remain visible even when records were created before the report window',async()=>{
 const {sqlite,db}=fixture();
 sqlite.exec(`
  INSERT INTO users VALUES('u1','member',1,100);
  INSERT INTO company_bank_accounts VALUES('bank',1,'private-name','private-number');
  INSERT INTO deposit_orders VALUES('old-deposit','u1','vpay',1000,'unknown',100,100);
  INSERT INTO withdrawal_requests VALUES('old-withdrawal','u1',500,'pending',100,100);
  INSERT INTO game_wallet_sessions VALUES('old-game','manual_review',100,'private-player');
  INSERT INTO providers VALUES('good',1);
  INSERT INTO game_catalogue_cache VALUES('good','available',1900,1900,1);
 `);
 const report=await operationsIntelligenceReport(db,{period:'day',start:1000,end:2000,label:'backlog'},{productionReady:true,paymentsReady:true,payoutsReady:true,settlementVerified:true,gamesReady:true,whatsappReady:true,expectedCatalogueIds:['good']},2001);
 assert.equal(report.metrics.deposits.createdOrders,0);assert.equal(report.metrics.deposits.unknown,1);assert.equal(report.metrics.deposits.createdUnknown,0);
 assert.equal(report.metrics.withdrawals.createdOrders,0);assert.equal(report.metrics.withdrawals.pending,1);assert.equal(report.metrics.withdrawals.createdPending,0);
 assert.equal(report.metrics.gameWallet.sessions,0);assert.equal(report.metrics.gameWallet.reviewRequired,1);assert.equal(report.metrics.gameWallet.createdReviewRequired,0);
 for(const id of ['reconcile_unknown_deposits','review_withdrawals','review_game_wallet_sessions'])assert.ok(report.recommendations.some(item=>item.id===id),id);
 assert.notEqual(report.summary.status,'ready');
 sqlite.close();
});

test('fresh but incomplete catalogue snapshots remain degraded',async()=>{
 const {sqlite,db}=fixture();
 sqlite.exec(`
  INSERT INTO company_bank_accounts VALUES('bank',1,'private-name','private-number');
  INSERT INTO providers VALUES('partial',1);
  INSERT INTO game_catalogue_cache VALUES('partial','available',1900,1900,0);
 `);
 const report=await operationsIntelligenceReport(db,{period:'day',start:1000,end:2000,label:'incomplete'},{productionReady:true,paymentsReady:true,payoutsReady:true,settlementVerified:true,gamesReady:true,whatsappReady:true,expectedCatalogueIds:['partial']},2001);
 assert.equal(report.metrics.catalogue.status,'degraded');
 assert.equal(report.metrics.catalogue.freshAvailableCatalogues,0);
 assert.equal(report.metrics.catalogue.incompleteCatalogues,1);
 assert.ok(report.recommendations.some(item=>item.id==='repair_catalogue_connections'&&item.evidence.incompleteCatalogues===1));
 assert.notEqual(report.summary.status,'ready');
 sqlite.close();
});

test('operations intelligence validates its reporting bounds',async()=>{
 const {sqlite,db}=fixture();
 await assert.rejects(()=>operationsIntelligenceReport(db,{period:'day',start:2000,end:1000,label:'bad'}),/Invalid operations report window/);
 await assert.rejects(()=>operationsIntelligenceReport(db,{period:'month',start:0,end:86400*33,label:'too long'}),/Invalid operations report window/);
 sqlite.close();
});

test('operations windows use Malaysia days, Monday weeks and calendar months',()=>{
 const at=Math.floor(Date.parse('2026-11-07T02:00:00.000Z')/1000);
 const day=operationsWindow('day',at),week=operationsWindow('week',at),month=operationsWindow('month',at);
 assert.equal(new Date(day.start*1000).toISOString(),'2026-11-06T16:00:00.000Z');
 assert.equal(new Date(week.start*1000).toISOString(),'2026-11-01T16:00:00.000Z');
 assert.equal(new Date(month.start*1000).toISOString(),'2026-10-31T16:00:00.000Z');
 assert.equal(day.end,at+1);assert.equal(week.period,'week');assert.equal(month.label,'2026-11');
 assert.throws(()=>operationsWindow('year',at),/Invalid operations report period/);
});
