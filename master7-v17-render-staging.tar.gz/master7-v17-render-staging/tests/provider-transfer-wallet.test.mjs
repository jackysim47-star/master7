import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readdirSync,readFileSync} from 'node:fs';
import {launchTransferWallet,settleTransferWallet,recoverTransferWallet,memberTransferWallet,adminTransferWalletRecords,ProviderTransferError} from '../lib/provider-transfer-wallet.ts';
import {withdrawalWalletState,clearStaleReservation} from '../lib/withdrawals.ts';
import {memberMegaWalletState} from '../lib/megah5-wallet.ts';
import {getGameProviderProfile} from '../lib/game-provider-registry.ts';
import {walletMinorToGameAmount,gameAmountToWalletMinor} from '../lib/game-unit-conversion.ts';

function harness(){
 const sqlite=new DatabaseSync(':memory:');for(const name of readdirSync(new URL('../drizzle',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 for(const id of ['alice','bob'])sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,'member',1,'synthetic-csrf',0)").run(id,id);
 sqlite.exec("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES('jdb_myr','jdb','Synthetic JDB','jdb','transfer','cash','MYR',1,1,'uat','uat',0,0),('spribe_myr','spribe','Synthetic SPRIBE','jdb','transfer','cash','MYR',1,1,'uat','uat',0,0)");
 for(const id of ['alice','bob']){sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,'fixture','manual_bank',2000,'MYR','fixture','credited',0,0)").run('credit-'+id,id,'credit-request-'+id);sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES(?,?,?,'member',2000,'MYR',0),(?,?,?,'provider_clearing',-2000,'MYR',0)").run('member-'+id,'credit-'+id,id,'clearing-'+id,'credit-'+id,id);}
 class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}async first(){return sqlite.prepare(this.sql).get(...this.args)??null;}async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}async run(){return sqlite.prepare(this.sql).run(...this.args);}}
 let queue=Promise.resolve();const db={prepare:sql=>new Statement(sql),batch(statements){const result=queue.then(async()=>{sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const s of statements)results.push(await s.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}});queue=result.catch(()=>{});return result;}};
 const state={balances:new Map(),calls:[],deposit:'confirmed',withdrawal:'confirmed',query:'confirmed',closed:true,residual:false,currency:'MYR',launch:'confirmed',waitDeposit:null,transferRefs:new Map()};
 const adapter={key:'jdb',executable:true,
  async listGames(c){state.calls.push(['games',c.profile.profileId]);return[{providerGameId:'0:101',name:'Synthetic slot',category:'slot',maintenance:false}];},
  async createOrVerifyPlayer(c,m){return {providerPlayerId:'player-'+c.profile.profileId+'-'+m.userId,created:false};},
  async queryBalance(c,i){state.calls.push(['balance',c.profile.profileId,i.providerPlayerId]);return {amountMinor:state.balances.get(i.providerPlayerId)??'0',currency:state.currency,residual:state.residual};},
  async closeGame(c,i){state.calls.push(['close',c.profile.profileId,i.providerPlayerId,i.requestClosure]);return state.closed?{state:'closed',evidenceCode:'SYNTHETIC_FACTORY_CLOSED'}:{state:'playing'};},
  async depositToGame(c,i){state.calls.push(['deposit',c.profile.profileId,{...i}]);if(state.waitDeposit)await state.waitDeposit;if(state.deposit==='rejected')return {state:'rejected'};state.balances.set(i.providerPlayerId,i.amountMinor);state.transferRefs.set(i.platformTransactionId,'D-1');if(state.deposit==='throw')throw Error('Synthetic timeout after accepted deposit');return {state:state.deposit,providerTransactionId:state.deposit==='confirmed'?'D-1':undefined};},
  async launchGame(c,i){state.calls.push(['launch',c.profile.profileId,{...i}]);if(state.launch==='throw')throw Error('Synthetic launch timeout');return {launchUrl:'https://games.example.test/single-use-session'};},
  async withdrawFromGame(c,i){state.calls.push(['withdrawal',c.profile.profileId,{...i}]);if(state.withdrawal==='rejected')return {state:'rejected'};state.balances.set(i.providerPlayerId,'0');state.transferRefs.set(i.platformTransactionId,'W-1');if(state.withdrawal==='throw')throw Error('Synthetic withdrawal timeout');return{state:state.withdrawal,providerTransactionId:state.withdrawal==='confirmed'?'W-1':undefined};},
  async queryTransfer(c,i){state.calls.push(['query',c.profile.profileId,{...i}]);return {state:state.query,providerTransactionId:state.query==='confirmed'?state.transferRefs.get(i.platformTransactionId):undefined};},
  async fetchWagers(){return{items:[],complete:false};},async handleCallback(){throw Error('Transfer wallet has no seamless callback');},
 };
 const ctx=(member='alice',profile='jdb_myr')=>({db,user:{id:member,username:member,role:'member',approved:1},profile:{profileId:profile,providerId:profile==='jdb_myr'?'jdb':'spribe',displayName:profile,walletMode:'transfer',currency:'MYR',unitScale:1,adapterKey:'jdb',envPrefix:'SYNTHETIC',playerNamespace:profile,ledgerNamespace:profile,listedInLobby:true},adapter,newGameLaunchesEnabled:'true',launchAuthorized:true});
 const input=(key='synthetic-request-1')=>({gameCode:'0:101',requestKey:key,language:'en',ip:'192.0.2.8',returnUrl:'https://portal.example.test/'});
 const latest=()=>sqlite.prepare('SELECT * FROM game_wallet_sessions ORDER BY created_at DESC,id DESC LIMIT 1').get();
 return{sqlite,db,state,ctx,input,latest,close:()=>sqlite.close()};
}
const rejects=code=>e=>e instanceof ProviderTransferError&&e.code===code;

function sweepHarness(){
 const h=harness(),base=h.ctx(),sweep={returned:'1575',mode:'confirmed',query:'confirmed',postBalance:'0',receiptAmount:undefined,receipts:new Map()};
 const adapter={...base.adapter,withdrawalMode:'all',transferContractFingerprint:'a'.repeat(64),
  async withdrawAllFromGame(c,i){h.state.calls.push(['sweep',c.profile.profileId,{...i}]);const value={state:'confirmed',providerTransactionId:'SW-1',amountMinor:sweep.returned};sweep.receipts.set(i.platformTransactionId,value);h.state.balances.set(i.providerPlayerId,sweep.postBalance);if(sweep.mode==='throw')throw Error('Synthetic accepted sweep response lost');return sweep.mode==='confirmed'?value:{state:'unknown'};},
  async queryWithdrawAll(c,i){h.state.calls.push(['sweep-query',c.profile.profileId,{...i}]);return sweep.query==='confirmed'?{...sweep.receipts.get(i.platformTransactionId),...(sweep.receiptAmount===undefined?{}:{amountMinor:sweep.receiptAmount})}:{state:'unknown'};},
 };
 return {...h,sweep,c:{...base,adapter}};
}
test('a sweep returns the actual receipt amount even when the displayed supplier balance is stale zero',async()=>{
 const h=sweepHarness();try{await launchTransferWallet(h.c,h.input());const s=h.latest();h.state.balances.set(s.player_id,'0');await settleTransferWallet(h.c,s.id);await recoverTransferWallet(h.c,s.id);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1575');assert.equal(h.state.calls.filter(x=>x[0]==='sweep').length,1);assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,0);assert.equal(h.sqlite.prepare('SELECT amount_minor FROM game_wallet_ledger').get().amount_minor,-425);}finally{h.close();}
});
test('a confirmed zero sweep requires a real original transaction and is not mistaken for a skipped exact withdrawal',async()=>{
 const h=sweepHarness();try{h.sweep.returned='0';await launchTransferWallet(h.c,h.input());await settleTransferWallet(h.c,h.latest().id);const operation=h.sqlite.prepare('SELECT * FROM provider_wallet_operations').get();assert.equal(operation.withdrawal_mode,'all');assert.equal(operation.withdrawal_attempts,1);assert.equal(operation.withdrawal_provider_reference,'SW-1');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');assert.equal(h.state.calls.filter(x=>x[0]==='sweep').length,1);assert.equal(h.sqlite.prepare('SELECT amount_minor FROM game_wallet_ledger').get().amount_minor,-2000);}finally{h.close();}
});
test('a timed-out sweep recovers its original reference with no amount guessed from a stale balance',async()=>{
 const h=sweepHarness();try{h.sweep.mode='throw';await launchTransferWallet(h.c,h.input());const id=h.latest().id;await assert.rejects(()=>settleTransferWallet(h.c,id),rejects('GAME_WITHDRAWAL_UNKNOWN'));assert.equal(h.latest().expected_return_minor,null);assert.equal((await adminTransferWalletRecords(h.db))[0].lastTransfer.amountMinor,null);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');h.sweep.query='unknown';await recoverTransferWallet(h.c,id);assert.equal(h.latest().expected_return_minor,null);h.sweep.query='confirmed';await recoverTransferWallet(h.c,id);const submit=h.state.calls.find(x=>x[0]==='sweep')[2],queries=h.state.calls.filter(x=>x[0]==='sweep-query');assert.ok(queries.every(x=>x[2].platformTransactionId===submit.platformTransactionId&&!('amountMinor' in x[2])));assert.equal(h.state.calls.filter(x=>x[0]==='sweep').length,1);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1575');}finally{h.close();}
});
test('concurrent sweep returns submit once and create one final ledger',async()=>{
 const h=sweepHarness();try{await launchTransferWallet(h.c,h.input());const id=h.latest().id,results=await Promise.allSettled([settleTransferWallet(h.c,id),settleTransferWallet(h.c,id)]);assert.ok(results.some(x=>x.status==='fulfilled'));assert.equal(h.state.calls.filter(x=>x[0]==='sweep').length,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1575');}finally{h.close();}
});
test('a prepared sweep resumes the durable original reference without a balance-based amount',async()=>{
 const h=sweepHarness();try{await launchTransferWallet(h.c,h.input());const id=h.latest().id;h.sqlite.prepare("UPDATE provider_wallet_operations SET closure_state='confirmed',closure_evidence=?,launch_state='closed',withdrawal_state='prepared' WHERE session_id=?").run('b'.repeat(64),id);h.sqlite.prepare("UPDATE game_wallet_sessions SET status='withdraw_pending',withdraw_reference='original-sweep',expected_return_minor=NULL WHERE id=?").run(id);await recoverTransferWallet(h.c,id);assert.equal(h.state.calls.find(x=>x[0]==='sweep')[2].platformTransactionId,'original-sweep');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1575');}finally{h.close();}
});
test('a confirmed sweep keeps funds reserved until the post-return balance is zero and rejects a changed receipt',async()=>{
 const h=sweepHarness();try{h.sweep.postBalance='100';await launchTransferWallet(h.c,h.input());const s=h.latest();await assert.rejects(()=>settleTransferWallet(h.c,s.id),rejects('GAME_RETURN_NOT_ZERO'));assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');h.sweep.receiptAmount='9999';await assert.rejects(()=>recoverTransferWallet(h.c,s.id),rejects('GAME_RETURN_RECEIPT_REVIEW'));assert.equal(h.latest().expected_return_minor,1575);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);h.sweep.receiptAmount=undefined;h.state.balances.set(s.player_id,'0');await recoverTransferWallet(h.c,s.id);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1575');assert.equal(h.state.calls.filter(x=>x[0]==='sweep').length,1);}finally{h.close();}
});
test('switching the withdrawal protocol or merchant unit contract cannot alter an existing session',async()=>{
 const h=sweepHarness();try{await launchTransferWallet(h.c,h.input());const id=h.latest().id,calls=h.state.calls.length;await assert.rejects(()=>settleTransferWallet({...h.c,adapter:{...h.c.adapter,withdrawalMode:'exact'}},id),rejects('GAME_TRANSFER_MODE_REVIEW'));await assert.rejects(()=>settleTransferWallet({...h.c,adapter:{...h.c.adapter,transferContractFingerprint:'b'.repeat(64)}},id),rejects('GAME_TRANSFER_CONTRACT_REVIEW'));assert.equal(h.state.calls.length,calls);assert.throws(()=>h.sqlite.prepare("UPDATE provider_wallet_operations SET withdrawal_mode='exact' WHERE session_id=?").run(id),/immutable/);assert.throws(()=>h.sqlite.prepare('UPDATE provider_wallet_operations SET adapter_contract_sha256=? WHERE session_id=?').run('c'.repeat(64),id),/immutable/);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');}finally{h.close();}
});
test('a sweep receipt without an actual normalized amount never releases the wallet reservation',async()=>{
 const h=sweepHarness();try{h.sweep.returned=undefined;await launchTransferWallet(h.c,h.input());const id=h.latest().id;await assert.rejects(()=>settleTransferWallet(h.c,id),rejects('GAME_WITHDRAWAL_UNKNOWN'));await recoverTransferWallet(h.c,id);assert.equal(h.latest().expected_return_minor,null);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);}finally{h.close();}
});

for(const profileId of ['jili_my1_1to100','918kiss_normal_my1_1to100'])test(`${profileId}: game points settle into MYR once without multiplying the cash ledger`,async()=>{
 const h=harness();try{
  const p={...getGameProviderProfile(profileId),walletMode:'transfer'},base=h.ctx().adapter,points=new Map(),wire=[];
  h.sqlite.prepare("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES(?,?,?,?,'transfer','cash','MYR',100,1,'uat','uat',0,0)").run(p.profileId,p.providerId,p.displayName,p.adapterKey);
  const adapter={...base,key:p.adapterKey,
   async depositToGame(c,input){const receipt=await base.depositToGame(c,input);points.set(input.providerPlayerId,walletMinorToGameAmount(input.amountMinor,p.unitScale));wire.push({direction:'deposit',gameAmount:points.get(input.providerPlayerId),cashMinor:input.amountMinor});return receipt;},
   async queryBalance(c,input){const cash=gameAmountToWalletMinor(points.get(input.providerPlayerId)??'0',p.unitScale);return {...cash,currency:'MYR'};},
   async withdrawFromGame(c,input){wire.push({direction:'withdrawal',gameAmount:walletMinorToGameAmount(input.amountMinor,p.unitScale),cashMinor:input.amountMinor});const receipt=await base.withdrawFromGame(c,input);points.set(input.providerPlayerId,'0');return receipt;},
  },c={...h.ctx(),profile:p,adapter};
  await launchTransferWallet(c,h.input());const s=h.latest();
  assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');
  assert.deepEqual(wire[0],{direction:'deposit',gameAmount:'2000.00',cashMinor:'2000'});
  assert.equal((await memberTransferWallet(c)).gameUnitsPerMYR,100);
  points.set(s.player_id,'1575.00');
  await settleTransferWallet(c,s.id);await recoverTransferWallet(c,s.id);
  assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1575');
  assert.deepEqual(wire[1],{direction:'withdrawal',gameAmount:'1575.00',cashMinor:'1575'});
  assert.equal(wire.length,2);assert.equal(h.sqlite.prepare('SELECT amount_minor FROM game_wallet_ledger WHERE session_id=?').get(s.id).amount_minor,-425);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
  assert.deepEqual(h.sqlite.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{h.close();}
});

test('a changed account ratio blocks settlement and preserves its cash reservation',async()=>{
 const h=harness();try{
  const p={...getGameProviderProfile('jili_my1_1to100'),walletMode:'transfer'},c={...h.ctx(),profile:p,adapter:{...h.ctx().adapter,key:p.adapterKey}};
  h.sqlite.prepare("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES(?,?,?,?,'transfer','cash','MYR',100,1,'uat','uat',0,0)").run(p.profileId,p.providerId,p.displayName,p.adapterKey);
  await launchTransferWallet(c,h.input());const s=h.latest(),calls=h.state.calls.length;
  h.sqlite.prepare('UPDATE game_provider_profiles SET unit_numerator=1 WHERE id=?').run(p.profileId);
  await assert.rejects(()=>settleTransferWallet(c,s.id),rejects('GAME_PROFILE_RECONCILIATION_REQUIRED'));
  assert.equal(h.state.calls.length,calls);assert.equal((await withdrawalWalletState(h.db,'alice')).reconciliationRequired,true);
  await clearStaleReservation(h.db,'alice');assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
  h.sqlite.prepare('UPDATE game_provider_profiles SET unit_numerator=100 WHERE id=?').run(p.profileId);
  await settleTransferWallet(c,s.id);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2000');
 }finally{h.close();}
});

test('free-credit and spoofed ratio profiles cannot enter the cash transfer engine',async()=>{
 const h=harness();try{
  const free={...getGameProviderProfile('918kiss_free_myr'),walletMode:'transfer'};
  await assert.rejects(()=>launchTransferWallet({...h.ctx(),profile:free},h.input()),rejects('GAME_TRANSFER_PROFILE_UNAVAILABLE'));
  await assert.rejects(()=>launchTransferWallet({...h.ctx(),profile:{...h.ctx().profile,unitScale:100}},h.input()),rejects('GAME_TRANSFER_PROFILE_UNAVAILABLE'));
  assert.equal(h.state.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('transfer wallet posts a settled profit once and uses the original member ledger',async()=>{
 const h=harness();try{
  const c=h.ctx(),launch=await launchTransferWallet(c,h.input());assert.equal(launch.profileId,'jdb_myr');assert.equal(h.state.calls.filter(x=>x[0]==='deposit').length,1);
  assert.deepEqual(await withdrawalWalletState(h.db,'alice'),{balanceMinor:'2000',availableMinor:'0',heldMinor:'2000',withdrawalHeldMinor:'0',gameHeldMinor:'2000'});
  const s=h.latest();h.state.balances.set(s.player_id,'2350');c.newGameLaunchesEnabled='false';c.launchAuthorized=false;
  const settled=await settleTransferWallet(c,s.id);assert.equal(settled.session.resultMinor,'350');assert.equal((await settleTransferWallet(c,s.id)).status,'settled');assert.equal((await recoverTransferWallet(c,s.id)).status,'settled');
  assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2350');assert.equal(h.sqlite.prepare("SELECT COUNT(*) n FROM wallet_ledger WHERE account_code='member'").get().n,2);
 }finally{h.close();}
});
test('a total loss closes without an invented zero withdrawal and settles one loss ledger',async()=>{
 const h=harness();try{await launchTransferWallet(h.ctx(),h.input());const s=h.latest();h.state.balances.set(s.player_id,'0');const settled=await settleTransferWallet(h.ctx(),s.id);assert.equal(settled.session.resultMinor,'-2000');assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,0);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');}finally{h.close();}
});
test('a timed-out accepted deposit is recovered by its original reference without depositing again',async()=>{
 const h=harness();try{h.state.deposit='throw';await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input()),rejects('GAME_DEPOSIT_UNKNOWN'));const s=h.latest();assert.equal(s.status,'deposit_unknown');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');const c={...h.ctx(),newGameLaunchesEnabled:'false',launchAuthorized:false};const recovered=await recoverTransferWallet(c,s.id);assert.equal(recovered.status,'active');assert.equal(h.state.calls.filter(x=>x[0]==='deposit').length,1);const q=h.state.calls.find(x=>x[0]==='query')[2];assert.deepEqual(q,{userId:'alice',providerPlayerId:s.player_id,platformTransactionId:s.deposit_reference,amountMinor:'2000',currency:'MYR',direction:'deposit'});assert.equal((await settleTransferWallet(c,s.id)).session.resultMinor,'0');}finally{h.close();}
});
test('a missing or rejected query keeps a timed-out deposit reserved',async()=>{
 const h=harness();try{h.state.deposit='throw';await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input()));const s=h.latest();h.state.query='rejected';assert.equal((await recoverTransferWallet(h.ctx(),s.id)).status,'deposit_unknown');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);assert.equal(h.state.calls.filter(x=>x[0]==='deposit').length,1);}finally{h.close();}
});
test('definitively rejected new deposits release only their original reservation',async()=>{
 const h=harness();try{h.state.deposit='rejected';await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input()),rejects('GAME_DEPOSIT_REJECTED'));assert.equal(h.latest().status,'deposit_failed');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2000');assert.equal(h.state.calls.filter(x=>x[0]==='launch').length,0);}finally{h.close();}
});
test('withdrawal timeout is queried once by original amount and returns funds exactly once',async()=>{
 const h=harness();try{await launchTransferWallet(h.ctx(),h.input());const s=h.latest();h.state.balances.set(s.player_id,'1744');h.state.withdrawal='throw';await assert.rejects(()=>settleTransferWallet(h.ctx(),s.id),rejects('GAME_WITHDRAWAL_UNKNOWN'));assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');const r=await recoverTransferWallet({...h.ctx(),newGameLaunchesEnabled:'false'},s.id);assert.equal(r.status,'settled');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1744');assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,1);assert.equal(h.state.calls.find(x=>x[0]==='query')[2].amountMinor,'1744');}finally{h.close();}
});
test('a still-playing supplier cannot return funds even when the browser has closed',async()=>{
 const h=harness();try{await launchTransferWallet(h.ctx(),h.input());h.state.closed=false;await assert.rejects(()=>settleTransferWallet(h.ctx(),h.latest().id),rejects('GAME_PROVIDER_STILL_OPEN'));assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,0);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');}finally{h.close();}
});
test('an unknown game launch cannot be marked closed by an unrelated offline check',async()=>{
 const h=harness();try{h.state.launch='throw';await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input()),rejects('GAME_LAUNCH_UNKNOWN'));const s=h.latest();await assert.rejects(()=>settleTransferWallet(h.ctx(),s.id),rejects('GAME_LAUNCH_CLOSURE_REVIEW'));assert.equal((await recoverTransferWallet(h.ctx(),s.id)).status,'active');assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,0);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');}finally{h.close();}
});
test('foreign currency and sub-sen residuals retain funds for reconciliation',async()=>{
 for(const patch of [{currency:'USD'},{residual:true}]){const h=harness();try{await launchTransferWallet(h.ctx(),h.input());Object.assign(h.state,patch);await assert.rejects(()=>settleTransferWallet(h.ctx(),h.latest().id),rejects('GAME_BALANCE_RECONCILIATION_REQUIRED'));assert.equal(h.latest().status,'manual_review');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,0);}finally{h.close();}}
});
test('member, profile and player bindings cannot be exchanged during recovery',async()=>{
 const h=harness();try{await launchTransferWallet(h.ctx(),h.input());const s=h.latest();await assert.rejects(()=>recoverTransferWallet(h.ctx('bob'),s.id),rejects('GAME_SESSION_NOT_FOUND'));await assert.rejects(()=>recoverTransferWallet(h.ctx('alice','spribe_myr'),s.id),rejects('GAME_SESSION_NOT_FOUND'));h.sqlite.prepare("UPDATE game_provider_players SET provider_player_id='different-player' WHERE user_id='alice'").run();await assert.rejects(()=>recoverTransferWallet(h.ctx(),s.id),rejects('GAME_PLAYER_BINDING_REVIEW'));assert.equal((await withdrawalWalletState(h.db,'alice')).reconciliationRequired,true);}finally{h.close();}
});
test('concurrent launch claims reserve once and submit one deposit',async()=>{
 const h=harness();try{let release;h.state.waitDeposit=new Promise(r=>release=r);const first=launchTransferWallet(h.ctx(),h.input());for(let i=0;i<30&&!h.state.calls.some(x=>x[0]==='deposit');i++)await new Promise(r=>setTimeout(r,1));if(!h.state.calls.some(x=>x[0]==='deposit'))await first;await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input('another-key')));release();await first;assert.equal(h.state.calls.filter(x=>x[0]==='deposit').length,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);}finally{h.close();}
});
test('concurrent settlements never submit two supplier withdrawals',async()=>{
 const h=harness();try{await launchTransferWallet(h.ctx(),h.input());const s=h.latest();h.state.balances.set(s.player_id,'1500');const results=await Promise.allSettled([settleTransferWallet(h.ctx(),s.id),settleTransferWallet(h.ctx(),s.id)]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1500');}finally{h.close();}
});
test('maintenance and acceptance checks reject new sessions before contacting a supplier',async()=>{
 const h=harness();try{await assert.rejects(()=>launchTransferWallet({...h.ctx(),newGameLaunchesEnabled:'false'},h.input()),rejects('GAMES_MAINTENANCE'));await assert.rejects(()=>launchTransferWallet({...h.ctx(),launchAuthorized:false},h.input()),rejects('GAME_ACCEPTANCE_REQUIRED'));assert.equal(h.state.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);}finally{h.close();}
});
test('a reused request key cannot launch twice or move to another member',async()=>{
 const h=harness();try{await launchTransferWallet(h.ctx(),h.input());await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input()),rejects('GAME_REQUEST_ALREADY_CLAIMED'));await assert.rejects(()=>launchTransferWallet(h.ctx('bob'),h.input()),rejects('GAME_REQUEST_KEY_CONFLICT'));assert.equal(h.state.calls.filter(x=>x[0]==='launch').length,1);}finally{h.close();}
});

test('MegaH5 reads cannot select a different provider session in the shared ledger',async()=>{
 const h=harness();try{const made=await launchTransferWallet(h.ctx(),h.input());const own=await memberTransferWallet(h.ctx());assert.equal(own.session.id,made.walletSessionId);const mega=await memberMegaWalletState({db:h.db,user:h.ctx().user});assert.equal(mega.session,null);assert.equal(mega.wallet.availableMinor,'0');}finally{h.close();}
});

test('stale-hold cleanup requires the supplier closure and transfer receipt, even with a terminal ledger',async()=>{
 const h=harness();try{await launchTransferWallet(h.ctx(),h.input());const s=h.latest();h.sqlite.prepare("UPDATE game_wallet_sessions SET status='settled',amount_returned_minor=2000,expected_return_minor=2000 WHERE id=?").run(s.id);h.sqlite.prepare("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('unproven-settlement',?,'alice','game_result',0,'MYR',0)").run(s.id);await clearStaleReservation(h.db,'alice');assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'0');assert.equal((await withdrawalWalletState(h.db,'alice')).reconciliationRequired,true);}finally{h.close();}
});
test('a proven terminal hold can be cleaned after a restored settlement without another vendor call',async()=>{
 const h=harness();try{const made=await launchTransferWallet(h.ctx(),h.input());await settleTransferWallet(h.ctx(),made.walletSessionId);const before=h.state.calls.length;h.sqlite.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('alice','game',?,2000,0)").run(made.walletSessionId);await clearStaleReservation(h.db,'alice');assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal(h.state.calls.length,before);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2000');}finally{h.close();}
});

test('a cooling-off committed during supplier reads stops funding and releases the unsubmitted hold',async()=>{
 const h=harness();try{const list=h.ctx().adapter.listGames;h.ctx().adapter.listGames=async(...args)=>{const result=await list(...args);h.sqlite.prepare("INSERT INTO responsible_play_profiles(user_id,cooling_off_until,last_change_id,created_at,updated_at) VALUES('alice',?,'synthetic-pause',0,0)").run(Math.floor(Date.now()/1000)+3600);return result;};await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input()),rejects('GAME_ACCESS_CHANGED'));assert.equal(h.state.calls.filter(x=>x[0]==='deposit').length,0);assert.equal(h.state.calls.filter(x=>x[0]==='launch').length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2000');}finally{h.close();}
});
test('approval revoked after funding prevents launch and returns the same reserved cash instead',async()=>{
 const h=harness();try{const c=h.ctx(),deposit=c.adapter.depositToGame;c.adapter.depositToGame=async(...args)=>{const result=await deposit(...args);h.sqlite.prepare("UPDATE users SET approved=0 WHERE id='alice'").run();return result;};await assert.rejects(()=>launchTransferWallet(c,h.input()),rejects('GAME_ACCESS_CHANGED'));assert.equal(h.state.calls.filter(x=>x[0]==='launch').length,0);assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,1);assert.equal(h.latest().status,'settled');assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2000');}finally{h.close();}
});

test('compliance revoked during supplier verification prevents funding without trapping the main wallet',async()=>{
 const h=harness();try{h.sqlite.exec("INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('alice','passed','passed',1,'synthetic-review',0,0)");const c={...h.ctx(),manualComplianceEnforced:true},verify=c.adapter.queryBalance;c.adapter.queryBalance=async(...args)=>{const result=await verify(...args);h.sqlite.exec("UPDATE manual_compliance_reviews SET aml_status='failed',version=2 WHERE user_id='alice'");return result;};await assert.rejects(()=>launchTransferWallet(c,h.input()),rejects('GAME_ACCESS_CHANGED'));assert.equal(h.state.calls.filter(x=>x[0]==='deposit').length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2000');}finally{h.close();}
});

test('an interrupted pre-submit deposit can be cancelled without querying or moving supplier money',async()=>{
 const h=harness();try{const original=h.db.batch;h.db.batch=items=>{if(items.some(item=>item.sql.includes("SET deposit_state='submitting'")))return Promise.reject(Error('Synthetic interruption before claim'));return original(items);};await assert.rejects(()=>launchTransferWallet(h.ctx(),h.input()));h.db.batch=original;const s=h.latest();assert.equal(s.status,'deposit_pending');assert.equal((await memberTransferWallet(h.ctx())).session.status,'deposit_pending');assert.equal((await recoverTransferWallet(h.ctx(),s.id)).status,'deposit_failed');assert.equal(h.state.calls.filter(x=>['deposit','query'].includes(x[0])).length,0);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'2000');assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);}finally{h.close();}
});
test('an interrupted prepared withdrawal resumes the original claim once',async()=>{
 const h=harness();try{const made=await launchTransferWallet(h.ctx(),h.input());h.state.balances.set(h.latest().player_id,'1500');const original=h.db.batch;h.db.batch=items=>{if(items.some(item=>item.sql.includes("SET withdrawal_state='submitting'")))return Promise.reject(Error('Synthetic interruption before return claim'));return original(items);};await assert.rejects(()=>settleTransferWallet(h.ctx(),made.walletSessionId));h.db.batch=original;assert.equal(h.latest().status,'withdraw_pending');assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,0);assert.equal((await recoverTransferWallet({...h.ctx(),newGameLaunchesEnabled:'false'},made.walletSessionId)).status,'settled');assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,1);assert.equal((await withdrawalWalletState(h.db,'alice')).availableMinor,'1500');}finally{h.close();}
});
test('an interrupted zero return finalizes its existing closure without inventing a withdrawal',async()=>{
 const h=harness();try{const made=await launchTransferWallet(h.ctx(),h.input());h.state.balances.set(h.latest().player_id,'0');const original=h.db.batch;h.db.batch=items=>{if(items.some(item=>item.sql.includes('SET zero_balance_verified=1')))return Promise.reject(Error('Synthetic interruption before zero finalization'));return original(items);};await assert.rejects(()=>settleTransferWallet(h.ctx(),made.walletSessionId));h.db.batch=original;assert.equal(h.latest().status,'withdraw_pending');assert.equal((await recoverTransferWallet(h.ctx(),made.walletSessionId)).session.resultMinor,'-2000');assert.equal(h.state.calls.filter(x=>x[0]==='withdrawal').length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);}finally{h.close();}
});
