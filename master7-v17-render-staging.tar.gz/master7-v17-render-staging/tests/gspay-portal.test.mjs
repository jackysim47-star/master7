import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {gspayOrderSignature,gspayResultSignature} from '../lib/gspay.ts';

// Every provider reply in this suite is synthetic. No test contacts GSPAY.
const origin='https://portal.example.test';
const apiBase='https://api.thegspay.com';
const gatewayBase='https://master7-integration-gateway.onrender.com';
const authKey='a'.repeat(32),secretKey='b'.repeat(32),checkoutKey='c'.repeat(32);
const callbackToken='d'.repeat(32);
const returnUrl='https://master7-v17-staging.onrender.com/payment/return';
const fixedPaymentId='35802335';

function fixture(t,{base=apiBase,callbackToken:callbackCredential}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 for(const [id,role,approved=1] of [['alice','member'],['bob','member'],['owner','owner']])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,0)').run(id,id,role,approved,'csrf-'+id);
 sql.prepare("UPDATE payment_channel_controls SET status='active' WHERE provider_id='gspay'").run();
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sql.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.text).all(...this.args)};}
  async run(){return sql.prepare(this.text).run(...this.args);}
 }
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={createCalls:0,queryCalls:0,fetchCalls:0,orders:new Map(),completed:true,success:true,createPatch:value=>value,queryPatch:value=>value,queryResponse:value=>Response.json(value),checkout:`https://secured.gspay.online/channel?id=${fixedPaymentId}&key=${checkoutKey}`,throwCreate:false};
 const config={db,identity:null,ownerEmail:'owner@example.test',gspayApiBase:base,gspayAuthKey:authKey,gspaySecretKey:secretKey,gspayCallbackToken:callbackCredential,gspayOrdersEnabled:'true',gspayReturnUrl:returnUrl,gspayFetch:async(input,init={})=>{
  state.fetchCalls++;const url=new URL(String(input));assert.equal(url.origin,base);assert.equal(init.redirect,'error');assert.equal(new Headers(init.headers).get('authorization'),null);
  const createPath=`/v2/integrations/operators/${authKey}/payment`,queryPath=`/v2/integrations/operators/${authKey}/getpayment`;
  if(url.pathname===createPath){
   state.createCalls++;assert.equal(init.method,'POST');assert.equal(new Headers(init.headers).get('content-type'),'application/json');assert.equal(url.search,'');
   const data=JSON.parse(init.body);state.lastCreate=data;assert.deepEqual(Object.keys(data).sort(),['amount','player_username','signature','transaction_id']);assert.equal(data.amount,20);assert.match(data.transaction_id,/^G7[A-Za-z0-9_-]{30}$/);assert.match(data.player_username,/^m7[a-f0-9]{30}$/);assert.equal(data.signature,gspayOrderSignature(data.transaction_id,data.player_username,'20.00',secretKey));assert.ok(!init.body.includes(secretKey));
   state.orders.set(data.transaction_id,{...data,amountDecimal:'20.00',paymentId:fixedPaymentId});
   if(state.throwCreate)throw Error('synthetic timeout');
   return Response.json(state.createPatch({code:200,data:JSON.stringify([{payment_id:fixedPaymentId,payment_url:state.checkout}]),message:'ok'}));
  }
  assert.equal(url.pathname,queryPath);assert.equal(init.method,'GET');assert.equal(init.body,undefined);assert.deepEqual([...url.searchParams.keys()].sort(),['auth_key','transaction_id']);assert.equal(url.searchParams.get('auth_key'),authKey);const id=url.searchParams.get('transaction_id'),order=state.orders.get(id);assert.ok(order);state.queryCalls++;
  const result={payment_id:order.paymentId,transaction_id:id,player_username:order.player_username,amount:order.amountDecimal,completed:state.completed,success:state.success,remark:state.success?'paid':'pending',signature:gspayResultSignature(order.paymentId,order.amountDecimal,id,secretKey)};
  return state.queryResponse({code:200,data:JSON.stringify([state.queryPatch(result)]),message:'ok'});
 }};
 async function call(path,{who='alice',method='GET',data,headers={},extra={}}={}){
  const request=new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,...headers},...(data===undefined?{}:{body:JSON.stringify(data)})});
  const response=await handle(request,{...config,identity:who?{userId:who,email:who+'@example.test'}:null,...extra});
  return {status:response.status,data:response.headers.get('content-type')?.includes('application/json')?await response.json():await response.text()};
 }
 const create=(requestKey='synthetic-gspay-key-0001',options={})=>call('/api/payments/gspay/orders',{method:'POST',data:{amount:'20.00',requestKey},...options});
 async function callback(id,patch={},options={}){
  const order=state.orders.get(id);assert.ok(order);const values={auth_key:authKey,success:true,completed:true,payment_id:order.paymentId,transaction_id:id,player_username:order.player_username,amount:order.amountDecimal,remark:'paid',...patch};
  if(options.resign)values.signature=gspayResultSignature(String(values.payment_id),Number(values.amount).toFixed(2),String(values.transaction_id),secretKey);
  else if(values.signature===undefined)values.signature=gspayResultSignature(order.paymentId,order.amountDecimal,id,secretKey);
  const target=origin+'/api/payment/gspay/callback'+(options.queryAuth?`?auth_key=${encodeURIComponent(options.queryAuth)}`:'');
  const response=await handle(new Request(target,{method:'POST',headers:{'Content-Type':'application/json',...(options.headers??{})},body:JSON.stringify(values)}),{...config,identity:null});
  return {status:response.status,data:response.headers.get('content-type')?.includes('application/json')?await response.json():await response.text()};
 }
 const ledgerCount=()=>sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n;
 t.after(()=>sql.close());return {sql,db,state,config,call,create,callback,ledgerCount};
}

test('GSPAY MD5 helpers match fixed official-formula vectors',()=>{
 const secret='0123456789abcdef0123456789abcdef';
 assert.equal(gspayOrderSignature('dn67640','owen 9','15.00',secret),'e6356f05c23a2b7019bd34c01a347cee');
 assert.equal(gspayResultSignature('35802335','15.00','dn67640',secret),'4856ae2ff555080b76977a9edb9ab932');
});

test('order uses the exact official URL and JSON, parses the sample string-array data, and is idempotent',async t=>{
 const f=fixture(t),first=await f.create(),again=await f.create();assert.equal(first.status,201);assert.equal(again.data.id,first.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.ledgerCount(),0);
 assert.equal(first.data.providerTradeNo,fixedPaymentId);const checkout=new URL(first.data.payUrl);assert.equal(checkout.origin,'https://secured.gspay.online');assert.equal(checkout.pathname,'/channel');assert.equal(checkout.searchParams.get('id'),fixedPaymentId);assert.equal(checkout.searchParams.get('key'),checkoutKey);assert.equal(checkout.searchParams.get('return'),returnUrl);
 const stored=f.sql.prepare('SELECT status,provider_trade_no,expires_at_raw,created_at FROM deposit_orders WHERE id=?').get(first.data.id);assert.equal(stored.status,'created');assert.equal(stored.provider_trade_no,fixedPaymentId);assert.equal(Number(stored.expires_at_raw)-Number(stored.created_at),120);
 const conflict=await f.call('/api/payments/gspay/orders',{method:'POST',data:{amount:'21.00',requestKey:'synthetic-gspay-key-0001'}});assert.equal(conflict.status,409);assert.equal(f.state.createCalls,1);
});

test('status and order retain credential, ownership, Origin and CSRF checks',async t=>{
 const f=fixture(t);let status=await f.call('/api/payments/gspay/status',{who:null});assert.equal(status.status,200);assert.equal(status.data.enabled,true);assert.equal(status.data.orderReady,true);assert.equal(status.data.settlementVerified,false);assert.equal(f.state.fetchCalls,0);assert.ok(!JSON.stringify(status.data).includes(authKey));assert.ok(!JSON.stringify(status.data).includes(secretKey));
 assert.equal((await f.create(undefined,{who:null})).status,401);assert.equal((await f.create(undefined,{who:'owner'})).status,403);assert.equal((await f.create(undefined,{headers:{'X-CSRF-Token':'bad'}})).status,403);assert.equal((await f.create(undefined,{headers:{Origin:'https://attacker.example.test'}})).status,403);
 f.config.gspayAuthKey='a'.repeat(31)+'ａ';status=await f.call('/api/payments/gspay/status',{who:null});assert.equal(status.data.programConfigured,false);assert.equal(status.data.orderReady,false);assert.equal((await f.create()).status,503);assert.equal(f.state.fetchCalls,0);
});

test('untrusted checkout URLs and malformed official envelopes never reach the member',async t=>{
 const f=fixture(t);f.state.checkout=`https://attacker.example.test/channel?id=${fixedPaymentId}&key=${checkoutKey}`;const badHost=await f.create();assert.equal(badHost.status,202);assert.equal(badHost.data.payUrl,null);assert.equal(f.ledgerCount(),0);
 const row=f.sql.prepare("SELECT target FROM audit WHERE event='payment_order_diagnostic'").get();assert.ok(row);assert.ok(!row.target.includes(secretKey));assert.ok(!row.target.includes('attacker.example.test'));
 const g=fixture(t);g.state.createPatch=value=>({...value,data:JSON.stringify([JSON.parse(value.data)[0],JSON.parse(value.data)[0]])});const ambiguous=await g.create();assert.equal(ambiguous.status,202);assert.equal(ambiguous.data.payUrl,null);assert.equal(g.ledgerCount(),0);
});

test('the two-minute checkout expiry suppresses an expired URL without resubmitting',async t=>{
 const f=fixture(t),created=await f.create();f.sql.prepare('UPDATE deposit_orders SET expires_at_raw=? WHERE id=?').run(String(Math.floor(Date.now()/1000)-1),created.data.id);const retried=await f.create();assert.equal(retried.status,202);assert.equal(retried.data.payUrl,null);assert.equal(f.state.createCalls,1);assert.equal(f.ledgerCount(),0);
});

test('exact callback alias bypasses Origin and CSRF, independently queries, and credits one balanced ledger once',async t=>{
 const f=fixture(t),created=await f.create();const first=await f.callback(created.data.id);assert.equal(first.status,200);assert.equal(first.data,'ok');assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),2);
 const entries=f.sql.prepare('SELECT account_code,amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=? ORDER BY account_code').all(created.data.id);assert.deepEqual(entries.map(row=>({...row})),[{account_code:'member',amount_minor:2000,currency:'MYR',user_id:'alice'},{account_code:'provider_clearing',amount_minor:-2000,currency:'MYR',user_id:'alice'}]);assert.equal(entries.reduce((sum,row)=>sum+row.amount_minor,0),0);
 const duplicate=await f.callback(created.data.id);assert.equal(duplicate.status,200);assert.equal(duplicate.data,'ok');assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
});

test('gateway mode pins the bridge and requires an independent callback bearer before querying or crediting',async t=>{
 const f=fixture(t,{base:gatewayBase,callbackToken}),initial=await f.call('/api/payments/gspay/status',{who:null});assert.equal(initial.data.programConfigured,true,JSON.stringify(initial.data));const created=await f.create();assert.equal(created.status,201,JSON.stringify(created.data));
 let response=await f.callback(created.data.id);assert.equal(response.status,401);assert.equal(f.state.queryCalls,0);assert.equal(f.ledgerCount(),0);
 response=await f.callback(created.data.id,{}, {headers:{Authorization:`Bearer ${callbackToken}`}});assert.equal(response.status,200);assert.equal(response.data,'ok');assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),2);
 const status=await f.call('/api/payments/gspay/status',{who:null});assert.equal(status.data.programConfigured,true);assert.equal(status.data.capabilities.balance.configured,false);
});

test('callback authentication, MD5 and order binding failures cannot query or credit',async t=>{
 const cases=[{patch:{auth_key:'f'.repeat(32)},status:401},{patch:{signature:'0'.repeat(32)},status:401},{patch:{amount:'21.00'},resign:true,status:409},{patch:{player_username:'other'},resign:true,status:409},{patch:{payment_id:'999999'},resign:true,status:409}];
 for(const [index,item] of cases.entries()){
  await t.test(String(index),async sub=>{const f=fixture(sub),created=await f.create(),result=await f.callback(created.data.id,item.patch,{resign:item.resign});assert.equal(result.status,item.status);assert.equal(f.state.queryCalls,0);assert.equal(f.ledgerCount(),0);});
 }
});

test('pending callback hints cannot settle without an independently verified matching query',async t=>{
 const f=fixture(t),created=await f.create();f.state.completed=false;f.state.success=false;let result=await f.callback(created.data.id,{completed:false,success:false});assert.equal(result.status,503);assert.equal(result.data,'pending');assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'created');
 f.state.queryPatch=value=>({...value,signature:'0'.repeat(32)});result=await f.callback(created.data.id);assert.equal(result.status,503);assert.equal(f.state.queryCalls,2);assert.equal(f.ledgerCount(),0);
});

test('member query is owner-bound, uses exact GET parameters, and can reconcile after channel closure',async t=>{
 const f=fixture(t),created=await f.create();f.sql.prepare("UPDATE payment_channel_controls SET status='closed' WHERE provider_id='gspay'").run();assert.equal((await f.call('/api/payments/gspay/orders/query',{who:'bob',method:'POST',data:{orderId:created.data.id}})).status,404);assert.equal(f.state.queryCalls,0);
 const result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,200);assert.equal(result.data.status,'credited');assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),2);
});

test('an old ordinary Payment query stays pending until the provider confirms a terminal result',async t=>{
 const f=fixture(t),created=await f.create();f.state.completed=false;f.state.success=false;f.sql.prepare('UPDATE deposit_orders SET created_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-601,created.data.id);
 let result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,202);assert.equal(result.data.status,'awaiting_confirmation');assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'created');assert.equal(f.ledgerCount(),0);
 f.state.completed=true;f.state.success=true;result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,200);assert.equal(result.data.status,'credited');assert.equal(f.ledgerCount(),2);assert.equal(f.state.queryCalls,2);
 result=await f.callback(created.data.id);assert.equal(result.status,200);assert.equal(f.state.queryCalls,2);assert.equal(f.ledgerCount(),2);assert.equal(f.state.createCalls,1);
});

test('historical failed orders with independently verified success still require owner review',async t=>{
 const f=fixture(t),created=await f.create();f.sql.prepare("UPDATE deposit_orders SET status='failed',created_at=? WHERE id=?").run(Math.floor(Date.now()/1000)-601,created.data.id);
 let result=await f.callback(created.data.id);assert.equal(result.status,200);assert.equal(result.data,'ok');assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'review');assert.equal(f.ledgerCount(),0);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_late_success_review' AND target=?").get(created.data.id).n,1);assert.equal(f.state.queryCalls,1);
 result=await f.callback(created.data.id);assert.equal(result.status,200);assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),0);
});

test('atomic ledger failure rolls back both entries and a later callback retries safely',async t=>{
 const f=fixture(t),created=await f.create();f.sql.exec("CREATE TRIGGER fixture_fail_clearing BEFORE INSERT ON wallet_ledger WHEN NEW.account_code='provider_clearing' BEGIN SELECT RAISE(ABORT,'fixture failure'); END;");let response=await f.callback(created.data.id);assert.equal(response.status,503);assert.equal(f.ledgerCount(),0);assert.notEqual(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'credited');
 f.sql.exec('DROP TRIGGER fixture_fail_clearing');response=await f.callback(created.data.id);assert.equal(response.status,200);assert.equal(f.ledgerCount(),2);
});

test('an inconsistent existing ledger is held for review without a second financial entry',async t=>{
 const f=fixture(t),created=await f.create();f.sql.prepare("INSERT INTO wallet_ledger VALUES('bad',?,'alice','member',1,'MYR',0)").run(created.data.id);const response=await f.callback(created.data.id);assert.equal(response.status,503);assert.equal(f.ledgerCount(),1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'review');
});

test('ambiguous create timeout records one order and never silently resubmits it',async t=>{
 const f=fixture(t);f.state.throwCreate=true;const first=await f.create(),again=await f.create();assert.equal(first.status,202);assert.equal(again.data.id,first.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.ledgerCount(),0);
});

test('DuitNow stays disabled and an unconfigured payout callback fails closed before session',async t=>{
 const f=fixture(t),before=f.state.fetchCalls;
 let response=await handle(new Request(origin+'/api/payment/gspay/duitnow/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}),{...f.config,identity:null});assert.equal(response.status,410);assert.equal((await response.json()).enabled,false);
 response=await handle(new Request(origin+'/api/payment/gspay/payout/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}),{...f.config,identity:null});assert.equal(response.status,503);assert.equal(await response.text(),'unavailable');
 assert.equal(f.state.fetchCalls,before);assert.equal(f.ledgerCount(),0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM deposit_orders WHERE provider='gspay'").get().n,0);
});

test('unsigned failure hints cannot reject a successful payment; reversed and duplicate callbacks credit once',async t=>{
 const f=fixture(t),created=await f.create();
 // completed/success are not part of the provider's MD5 formula. Keep the original signature.
 const first=await f.callback(created.data.id,{completed:true,success:false});assert.equal(first.status,200);assert.equal(first.data,'ok');assert.equal(f.state.queryCalls,1);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'credited');assert.equal(f.ledgerCount(),2);
 for(const patch of [{completed:true,success:true},{completed:true,success:false},{completed:false,success:false}]){const repeated=await f.callback(created.data.id,patch);assert.equal(repeated.status,200);assert.equal(repeated.data,'ok');}
 assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
 const rows=f.sql.prepare('SELECT amount_minor,currency,user_id FROM wallet_ledger WHERE order_id=?').all(created.data.id);assert.equal(rows.reduce((sum,row)=>sum+row.amount_minor,0),0);assert.ok(rows.every(row=>row.currency==='MYR'&&row.user_id==='alice'));
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_deposit_credited' AND target=?").get(created.data.id).n,1);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_late_success_review' AND target=?").get(created.data.id).n,0);
});

for(const age of [0,601])for(const failure of ['timeout','invalid-json'])test(`callback query ${failure} at age ${age}s preserves the order and remains retryable`,async t=>{
 const f=fixture(t),created=await f.create();f.sql.prepare('UPDATE deposit_orders SET created_at=?,updated_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-age,123,created.data.id);
 const before={...f.sql.prepare('SELECT * FROM deposit_orders WHERE id=?').get(created.data.id)},normalResponse=f.state.queryResponse;
 f.state.queryResponse=failure==='timeout'?()=>{throw new Error('synthetic query timeout');}:()=>new Response('not-json',{headers:{'Content-Type':'application/json'}});
 let response=await f.callback(created.data.id);assert.equal(response.status,503);assert.equal(response.data,'pending');assert.equal(f.state.queryCalls,1);assert.deepEqual({...f.sql.prepare('SELECT * FROM deposit_orders WHERE id=?').get(created.data.id)},before);assert.equal(f.ledgerCount(),0);
 f.state.queryResponse=normalResponse;response=await f.callback(created.data.id,{completed:true,success:false});assert.equal(response.status,200);assert.equal(response.data,'ok');assert.equal(f.state.queryCalls,2);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'credited');assert.equal(f.ledgerCount(),2);
});

test('a true terminal provider failure is independently confirmed and later conflicting success stays in review',async t=>{
 const f=fixture(t),created=await f.create();f.state.success=false;
 let response=await f.callback(created.data.id,{completed:true,success:false});assert.equal(response.status,200);assert.equal(response.data,'ok');assert.equal(f.state.queryCalls,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'failed');assert.equal(f.ledgerCount(),0);
 response=await f.callback(created.data.id);assert.equal(response.status,200);assert.equal(response.data,'ok');assert.equal(f.state.queryCalls,2);assert.equal(f.ledgerCount(),0);
 f.state.success=true;response=await f.callback(created.data.id,{completed:true,success:false});assert.equal(response.status,200);assert.equal(response.data,'ok');assert.equal(f.state.queryCalls,3);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'review');assert.equal(f.ledgerCount(),0);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_late_success_review' AND target=?").get(created.data.id).n,1);
 response=await f.callback(created.data.id);assert.equal(response.status,200);assert.equal(f.state.queryCalls,3);assert.equal(f.ledgerCount(),0);
});

test('concurrent opposite callback hints cannot duplicate the balanced deposit ledger',async t=>{
 const f=fixture(t),created=await f.create();const replies=await Promise.all([f.callback(created.data.id,{completed:true,success:false}),f.callback(created.data.id)]);assert.ok(replies.every(response=>response.status===200));
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'credited');assert.equal(f.ledgerCount(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
 assert.equal(f.sql.prepare('SELECT SUM(amount_minor) amount FROM wallet_ledger WHERE order_id=?').get(created.data.id).amount,0);
});

test('an old order with an atomic ledger error stays retryable instead of becoming expired',async t=>{
 const f=fixture(t),created=await f.create();f.sql.prepare('UPDATE deposit_orders SET created_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-601,created.data.id);
 f.sql.exec("CREATE TRIGGER fixture_old_fail_clearing BEFORE INSERT ON wallet_ledger WHEN NEW.account_code='provider_clearing' BEGIN SELECT RAISE(ABORT,'fixture failure'); END;");
 let response=await f.callback(created.data.id);assert.equal(response.status,503);assert.equal(f.ledgerCount(),0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'created');
 f.sql.exec('DROP TRIGGER fixture_old_fail_clearing');response=await f.callback(created.data.id);assert.equal(response.status,200);assert.equal(f.ledgerCount(),2);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'credited');
});

test('an unknown old order without payment_id recovers by transaction_id without creating a second order',async t=>{
 const f=fixture(t);f.state.throwCreate=true;const created=await f.create();f.sql.prepare('UPDATE deposit_orders SET created_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-601,created.data.id);
 assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(created.data.id).provider_trade_no,null);
 const result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,200);assert.equal(result.data.status,'credited');assert.equal(f.state.queryCalls,1);assert.equal(f.state.createCalls,1);assert.equal(f.ledgerCount(),2);
 assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(created.data.id).provider_trade_no,fixedPaymentId);
 assert.equal((await f.create()).data.status,'credited');assert.equal(f.state.createCalls,1);assert.equal((await f.callback(created.data.id)).status,200);assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),2);
});

test('an unknown old order remains unknown while the provider query is pending',async t=>{
 const f=fixture(t);f.state.throwCreate=true;const created=await f.create();f.state.completed=false;f.state.success=false;f.sql.prepare('UPDATE deposit_orders SET created_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-601,created.data.id);
 const result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,202);assert.equal(result.data.status,'awaiting_confirmation');assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'unknown');assert.equal(f.state.queryCalls,1);assert.equal(f.ledgerCount(),0);
 const again=await f.create();assert.equal(again.data.id,created.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.ledgerCount(),0);
});

test('a no-reference order records only the independently verified failed payment reference',async t=>{
 const f=fixture(t);f.state.throwCreate=true;const created=await f.create();f.state.success=false;
 const result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,202);assert.equal(result.data.status,'failed');
 const order=f.sql.prepare('SELECT status,provider_trade_no FROM deposit_orders WHERE id=?').get(created.data.id);assert.equal(order.status,'failed');assert.equal(order.provider_trade_no,fixedPaymentId);assert.equal(f.ledgerCount(),0);assert.equal(f.state.createCalls,1);
});

test('incomplete or invalid query results do not invent a failed or review state',async t=>{
 const cases=[['missing-success',{success:undefined}],['missing-completed',{completed:undefined}],['bad-success',{success:'false'}],['bad-completed',{completed:2}],['inconsistent-flags',{completed:false,success:true}],['missing-payment-id',{payment_id:undefined}],['missing-transaction',{transaction_id:undefined}],['missing-player',{player_username:undefined}],['missing-amount',{amount:undefined}],['missing-signature',{signature:undefined}]];
 for(const [name,patch]of cases)await t.test(name,async sub=>{
  const f=fixture(sub),created=await f.create();f.sql.prepare('UPDATE deposit_orders SET created_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-601,created.data.id);f.state.queryPatch=value=>({...value,...patch});
  const before={...f.sql.prepare('SELECT * FROM deposit_orders WHERE id=?').get(created.data.id)},response=await f.callback(created.data.id);assert.equal(response.status,503);assert.equal(response.data,'pending');assert.deepEqual({...f.sql.prepare('SELECT * FROM deposit_orders WHERE id=?').get(created.data.id)},before);assert.equal(f.ledgerCount(),0);
 });
 for(const [name,envelope]of [['business-error',{code:404,message:'not available',data:null}],['empty-data',{code:200,data:[]}],['missing-reference',{code:200,data:{completed:true,success:false}}]])await t.test(name+'-without-reference',async sub=>{
  const f=fixture(sub);f.state.throwCreate=true;const created=await f.create();f.sql.prepare('UPDATE deposit_orders SET created_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-601,created.data.id);f.state.queryResponse=()=>Response.json(envelope);
  const result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,202);assert.equal(result.data.status,'awaiting_confirmation');assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'unknown');assert.equal(f.ledgerCount(),0);assert.equal(f.state.createCalls,1);assert.equal(f.state.queryCalls,1);
 });
});

test('identified query binding contradictions still require review and cannot credit',async t=>{
 for(const patch of [{transaction_id:'other-order'},{player_username:'another-player'},{amount:'21.00'},{payment_id:'99999999'},{signature:'0'.repeat(32)}])await t.test(Object.keys(patch)[0],async sub=>{
  const f=fixture(sub),created=await f.create();f.state.queryPatch=value=>({...value,...patch});const response=await f.callback(created.data.id);assert.equal(response.status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'review');assert.equal(f.ledgerCount(),0);
 });
});

test('documented boolean flags and existing zero/one string compatibility are preserved',async t=>{
 for(const [completed,success,expected]of [[1,1,'credited'],['1','1','credited'],[true,false,'failed'],['1','0','failed'],[0,0,'awaiting_confirmation']])await t.test(JSON.stringify([completed,success]),async sub=>{
  const f=fixture(sub),created=await f.create();f.state.queryPatch=value=>({...value,completed,success});const result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.data.status,expected);assert.equal(f.ledgerCount(),expected==='credited'?2:0);
 });
});

test('an aged member query transport failure remains unconfirmed with the original order unchanged',async t=>{
 const f=fixture(t),created=await f.create();f.sql.prepare('UPDATE deposit_orders SET created_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-601,created.data.id);const before={...f.sql.prepare('SELECT * FROM deposit_orders WHERE id=?').get(created.data.id)};f.state.queryResponse=()=>{throw new Error('synthetic query timeout');};
 const result=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:created.data.id}});assert.equal(result.status,202);assert.equal(result.data.status,'awaiting_confirmation');assert.deepEqual({...f.sql.prepare('SELECT * FROM deposit_orders WHERE id=?').get(created.data.id)},before);assert.equal(f.ledgerCount(),0);
});

for(const first of ['failure','success'])test(`concurrent bound failure and success preserve terminal accounting when ${first} lands first`,async t=>{
 const f=fixture(t),created=await f.create(),pending=[];f.state.queryResponse=envelope=>new Promise(resolve=>pending.push({envelope,resolve}));
 const waitForQueries=async count=>{for(let i=0;i<40&&pending.length<count;i++)await new Promise(setImmediate);assert.equal(pending.length,count);};
 f.state.success=false;const failure=f.callback(created.data.id,{completed:true,success:false});await waitForQueries(1);
 f.state.success=true;const success=f.callback(created.data.id);await waitForQueries(2);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'created');
 if(first==='failure'){
  pending[0].resolve(Response.json(pending[0].envelope));assert.equal((await failure).status,200);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'failed');
  pending[1].resolve(Response.json(pending[1].envelope));assert.equal((await success).status,200);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'review');assert.equal(f.ledgerCount(),0);
 }else{
  pending[1].resolve(Response.json(pending[1].envelope));assert.equal((await success).status,200);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'credited');
  pending[0].resolve(Response.json(pending[0].envelope));assert.equal((await failure).status,200);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(created.data.id).status,'credited');assert.equal(f.ledgerCount(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
 }
 assert.equal(f.state.queryCalls,2);assert.equal(f.state.createCalls,1);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_deposit_credited' AND target=?").get(created.data.id).n,first==='failure'?0:1);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_late_success_review' AND target=?").get(created.data.id).n,first==='failure'?1:0);
});
