import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {gspayPlayerUsername} from '../lib/gspay.ts';

const origin='https://portal.example.test',gateway='https://master7-integration-gateway.onrender.com';
const orderToken='portal-order-'+ 'a'.repeat(32),queryToken='portal-query-'+ 'b'.repeat(32),callbackToken='portal-callback-'+ 'c'.repeat(32);

function fixture(t,{queryReady=true,callbacksReady=true,enabled='true'}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf-alice',0),('owner','owner','owner',1,'csrf-owner',0)").run();
 sql.prepare("UPDATE payment_channel_controls SET status='active' WHERE provider_id='gspay'").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(items){sql.exec('BEGIN');try{const out=[];for(const item of items)out.push(await item.run());sql.exec('COMMIT');return out;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={configCalls:0,orderCalls:0,lastOrder:null,invalidCheckout:false};
 const config={db,identity:{userId:'alice',email:'alice@example.test'},ownerEmail:'owner@example.test',gspayGatewayUrl:gateway,gspayOrderToken:orderToken,gspayQueryToken:queryToken,gspayCallbackToken:callbackToken,gspayOrdersEnabled:enabled,gspayMode:'production',gspayFetch:async(url,options)=>{
  const path=new URL(url).pathname;assert.equal(new URL(url).origin,gateway);assert.equal(options.redirect,'error');
  if(path==='/platform/gspay/config'){state.configCalls++;assert.equal(options.headers.Authorization,'Bearer '+queryToken);return Response.json({provider:'gspay',currency:'MYR',mode:'production',providerBase:'https://api.thegspay.com',createProgramReady:true,orderReady:true,queryReady,callbacksReady,transactionRoutesActive:false});}
  assert.equal(path,'/platform/gspay/order');state.orderCalls++;assert.equal(options.headers.Authorization,'Bearer '+orderToken);const body=JSON.parse(options.body);state.lastOrder=body;assert.equal(body.currency,'MYR');assert.equal(body.contract,'gspay-myr-create-v1');assert.equal(body.playerUsername,gspayPlayerUsername('alice'));assert.equal(body.amount,'15.00');
  return Response.json({provider:'gspay_myr',contract:'gspay-myr-create-v1',upstreamStatus:200,result:{transactionId:body.transactionId,playerUsername:body.playerUsername,currency:'MYR',amount:'15.00',paymentId:'35802335',paymentUrl:state.invalidCheckout?'https://evil.example/pay':'https://secured.gspay.online/channel?id=35802335&key=c2e75176f9fc4ea280a9853a53e0ff69',responseSchemaVerified:true,fundsProcessed:false}});
 }};
 async function call(path,{method='GET',data,who='alice'}={}){const r=await handle(new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+who},...(data===undefined?{}:{body:JSON.stringify(data)})}),{...config,identity:who?{userId:who,email:who+'@example.test'}:null});return {status:r.status,data:await r.json()};}
 t.after(()=>sql.close());return {sql,state,config,call};
}

test('GSPAY status opens only when create, independent query and callback paths are all ready',async t=>{
 const ready=fixture(t),status=await ready.call('/api/payments/gspay/status',{who:null});assert.equal(status.status,200);assert.equal(status.data.enabled,true);assert.equal(status.data.orderReady,true);assert.equal(status.data.queryReady,true);assert.equal(status.data.callbacksReady,true);assert.equal(status.data.settlementVerified,false);assert.equal(status.data.liveReady,false);
});

test('GSPAY callback receiver is reachable, machine-authenticated and fail-closed',async t=>{
 const f=fixture(t),target=origin+'/api/payment-callbacks/gspay/payment';
 const discovery=await handle(new Request(target),f.config);assert.equal(discovery.status,200);assert.equal((await discovery.json()).active,false);
 const denied=await handle(new Request(target,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}),f.config);assert.equal(denied.status,401);
 const closed=await handle(new Request(target,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+callbackToken},body:'{}'}),f.config);assert.equal(closed.status,503);assert.equal((await closed.json()).error,'GSPAY_SETTLEMENT_DISABLED');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('GSPAY creates one idempotent checkout record and never credits the wallet on create',async t=>{
 const f=fixture(t),payload={amount:'15.00',requestKey:'gspay-request-key-000001'},first=await f.call('/api/payments/gspay/orders',{method:'POST',data:payload}),second=await f.call('/api/payments/gspay/orders',{method:'POST',data:payload});
 assert.equal(first.status,201);assert.equal(second.status,200);assert.equal(second.data.id,first.data.id);assert.equal(f.state.orderCalls,1);assert.equal(f.state.lastOrder.transactionId,first.data.id);assert.equal(first.data.providerTradeNo,'35802335');assert.equal(first.data.payUrl,'https://secured.gspay.online/channel?id=35802335&key=c2e75176f9fc4ea280a9853a53e0ff69');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM deposit_orders WHERE provider='gspay'").get().n,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 const record=await f.call('/api/payment-records');assert.equal(record.data.items[0].provider,'gspay');assert.equal(record.data.items[0].status,'created');
});

test('GSPAY stays closed before settlement contracts and makes no order request',async t=>{
 const f=fixture(t,{queryReady:false,callbacksReady:false}),status=await f.call('/api/payments/gspay/status',{who:null});assert.equal(status.data.enabled,false);assert.equal(status.data.createProgramReady,true);assert.equal(status.data.orderReady,true);assert.equal(status.data.queryReady,false);
 const order=await f.call('/api/payments/gspay/orders',{method:'POST',data:{amount:'15.00',requestKey:'gspay-request-key-000002'}});assert.equal(order.status,503);assert.equal(order.data.error,'GSPAY_SETTLEMENT_NOT_READY');assert.equal(f.state.orderCalls,0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM deposit_orders WHERE provider='gspay'").get().n,0);
});

test('GSPAY disabled switch and bad checkout destination fail closed without wallet credit',async t=>{
 const disabled=fixture(t,{enabled:'false'});const denied=await disabled.call('/api/payments/gspay/orders',{method:'POST',data:{amount:'15.00',requestKey:'gspay-request-key-000003'}});assert.equal(denied.status,503);assert.equal(disabled.state.configCalls,0);assert.equal(disabled.state.orderCalls,0);
 const bad=fixture(t);bad.state.invalidCheckout=true;const pending=await bad.call('/api/payments/gspay/orders',{method:'POST',data:{amount:'15.00',requestKey:'gspay-request-key-000004'}});assert.equal(pending.status,202);assert.equal(pending.data.payUrl,null);assert.equal(bad.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);assert.equal(bad.sql.prepare("SELECT status FROM deposit_orders WHERE provider='gspay'").get().status,'unknown');
});

test('GSPAY member ownership and input validation protect order and query records',async t=>{
 const f=fixture(t);assert.equal((await f.call('/api/payments/gspay/orders',{who:'owner',method:'POST',data:{amount:'15.00',requestKey:'gspay-request-key-000005'}})).status,403);
 for(const amount of ['0','-1','15.001','1e2','100000.01'])assert.equal((await f.call('/api/payments/gspay/orders',{method:'POST',data:{amount,requestKey:'gspay-invalid-key-00001'}})).status,400);
 const missing=await f.call('/api/payments/gspay/orders/query',{method:'POST',data:{orderId:'G7unknown000000'}});assert.equal(missing.status,404);assert.equal(f.state.orderCalls,0);
});
