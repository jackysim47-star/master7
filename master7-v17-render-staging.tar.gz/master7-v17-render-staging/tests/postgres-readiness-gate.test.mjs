import test from 'node:test';
import assert from 'node:assert/strict';
import {BACKUP_EXCLUDED_TABLES,BACKUP_FORMAT,BACKUP_SCHEMA_SHA256,BACKUP_SCHEMA_VERSION,BACKUP_TABLES} from '../lib/encrypted-backup.ts';
import {BACKUP_PUBLIC_KEY_SHA256} from '../lib/backup-public-key.ts';
import {OPTIONAL_MIGRATIONS,REQUIRED_MIGRATIONS,REQUIRED_TABLES,evaluatePostgresReadinessEvidence,runPostgresReadinessGate} from '../scripts/postgres-readiness-gate.mjs';

const release='17.0.0-readiness-fixture',nowMs=Date.parse('2026-11-08T12:00:00.000Z'),createdAt='2026-11-08T10:00:00.000Z',verifiedAt='2026-11-08T11:00:00.000Z';
const backup={format:BACKUP_FORMAT,release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,publicKeySha256:BACKUP_PUBLIC_KEY_SHA256,readConsistency:'transaction_snapshot',tableCount:BACKUP_TABLES.length,totalRecords:123,backupSha256:'a'.repeat(64),plaintextSha256:'b'.repeat(64),ciphertextSha256:'c'.repeat(64),createdAt};
const restore={status:'verified',format:BACKUP_FORMAT,release,schemaVersion:BACKUP_SCHEMA_VERSION,schemaSha256:BACKUP_SCHEMA_SHA256,publicKeySha256:BACKUP_PUBLIC_KEY_SHA256,coverageComplete:true,missingTables:[],readConsistency:'transaction_snapshot',persistentWrites:false,restoreTargetKind:'isolated_postgresql_transaction',restoreTargetSha256:'d'.repeat(64),foreignKeyViolations:0,tableCount:BACKUP_TABLES.length,totalRecords:123,backupSha256:backup.backupSha256,plaintextSha256:backup.plaintextSha256,createdAt,verifiedAt};

const fixture=()=>({
 role:{transaction_read_only:'on',can_create_database:false,can_create_schema:false,can_write_tables:false},
 tables:REQUIRED_TABLES.map(name=>({name})),
 migrations:[...REQUIRED_MIGRATIONS,...OPTIONAL_MIGRATIONS.slice(0,2)].sort().map(version=>({version,applied_at:Math.floor(nowMs/1000)-100})),
 backupAudit:{target:JSON.stringify(backup),created_at:Math.floor(Date.parse(createdAt)/1000)},
 restoreSetting:{value:JSON.stringify(restore)},
});

test('evidence gate accepts only the current schema, migration, backup and bound restore contract',()=>{
 const result=evaluatePostgresReadinessEvidence(fixture(),{expectedRelease:release,nowMs});
 assert.equal(result.ok,true);assert.equal(result.schema.requiredTables,67+5);assert.equal(result.schema.requiredTables,BACKUP_TABLES.length+BACKUP_EXCLUDED_TABLES.length);assert.ok(BACKUP_EXCLUDED_TABLES.includes('member_wallet_guards'));assert.ok(!BACKUP_TABLES.includes('member_wallet_guards'));assert.ok(BACKUP_TABLES.includes('megah5_launch_operations'));assert.ok(BACKUP_TABLES.includes('game_provider_acceptance_events'));assert.ok(BACKUP_TABLES.includes('game_provider_acceptance_current'));assert.ok(REQUIRED_TABLES.includes('member_wallet_guards'));assert.equal(result.schema.requiredMigrations,26);assert.ok(result.checks.every(item=>item.pass));
});

test('evidence gate fails closed for drift, a write-capable role or an unbound receipt',()=>{
 const missingTable=fixture();missingTable.tables.pop();assert.equal(evaluatePostgresReadinessEvidence(missingTable,{expectedRelease:release,nowMs}).checks.find(item=>item.id==='required_tables').pass,false);
 const missingMigration=fixture();missingMigration.migrations=missingMigration.migrations.filter(item=>item.version!==REQUIRED_MIGRATIONS[0]);assert.equal(evaluatePostgresReadinessEvidence(missingMigration,{expectedRelease:release,nowMs}).checks.find(item=>item.id==='required_migrations').pass,false);
 const unknownMigration=fixture();unknownMigration.migrations.push({version:'9999-unknown-migration',applied_at:Math.floor(nowMs/1000)-100});assert.equal(evaluatePostgresReadinessEvidence(unknownMigration,{expectedRelease:release,nowMs}).checks.find(item=>item.id==='no_unknown_migrations').pass,false);
 const writable=fixture();writable.role.can_write_tables=true;assert.equal(evaluatePostgresReadinessEvidence(writable,{expectedRelease:release,nowMs}).checks.find(item=>item.id==='database_role_read_only').pass,false);
 const forged=fixture();forged.restoreSetting.value=JSON.stringify({...restore,backupSha256:'f'.repeat(64),readConsistency:'unverified'});assert.equal(evaluatePostgresReadinessEvidence(forged,{expectedRelease:release,nowMs}).checks.find(item=>item.id==='bound_restore_rehearsal').pass,false);
});

class FakeClient{
 constructor(data=fixture()){this.data=data;this.sql=[];}
 async query(sql){
  this.sql.push(sql);
  if(sql.startsWith('BEGIN')||sql.startsWith('SET LOCAL')||sql==='ROLLBACK')return{rows:[]};
  if(sql.includes("current_setting('transaction_read_only')"))return{rows:[this.data.role]};
  if(sql.includes('FROM pg_catalog.pg_class'))return{rows:this.data.tables};
  if(sql.startsWith('SELECT version,applied_at'))return{rows:this.data.migrations};
  if(sql.includes("event='encrypted_backup_created'"))return{rows:[this.data.backupAudit]};
  if(sql.includes("id='backup_restore_rehearsal'"))return{rows:[this.data.restoreSetting]};
  throw new Error('Unexpected SQL');
 }
}

test('PostgreSQL gate performs metadata-only reads in one rollback-only transaction',async()=>{
 const client=new FakeClient(),result=await runPostgresReadinessGate(client,{expectedRelease:release,nowMs});assert.equal(result.ok,true);
 assert.equal(client.sql[0],'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');assert.equal(client.sql.at(-1),'ROLLBACK');
 const sql=client.sql.join('\n');assert.doesNotMatch(sql,/SELECT\s+\*\s+FROM\s+(?:users|wallet_ledger|deposit_orders)/i);assert.doesNotMatch(sql,/\b(?:INSERT|UPDATE|DELETE|TRUNCATE)\s+(?:INTO|FROM)?\s*(?:users|wallet_ledger|deposit_orders)/i);
 assert.ok(sql.includes('pg_catalog.pg_class'));assert.ok(sql.includes('portal_schema_migrations'));assert.ok(sql.includes("event='encrypted_backup_created'"));assert.ok(sql.includes("id='backup_restore_rehearsal'"));
});

test('PostgreSQL gate rolls back after a metadata-query failure',async()=>{
 const client=new FakeClient();client.query=async function(sql){this.sql.push(sql);if(sql.startsWith('BEGIN')||sql.startsWith('SET LOCAL')||sql==='ROLLBACK')return{rows:[]};throw new Error('postgres://private-user:private-password@internal/db');};
 await assert.rejects(()=>runPostgresReadinessGate(client,{expectedRelease:release,nowMs}),/private-password/);assert.equal(client.sql.at(-1),'ROLLBACK');
});
