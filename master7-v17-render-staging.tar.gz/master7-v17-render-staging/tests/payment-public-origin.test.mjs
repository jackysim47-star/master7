import {test} from 'node:test';
import assert from 'node:assert/strict';
import {
  customerPortalOriginForEndpoint,
  matchesCustomerPortalEndpoint,
  paymentReturnUrl,
  resolveCustomerPortalOrigin,
  stagingPortalOrigin,
} from '../lib/portal-origin.mjs';
import {vpayOrdersConfigured} from '../lib/vpay.ts';
import {gspayProgramConfigured} from '../lib/gspay.ts';
import {oneMpayConfigurationReady} from '../lib/onempay.ts';

const officialProductionOrigins=['https://master7.best','https://www.master7.best'];
const gateway='https://master7-integration-gateway.onrender.com';

function providerContexts(origin){
 const portalOrigins=[origin],returnUrl=`${origin}/payment/return`;
 return {
  vpay:{db:{},user:null,gatewayUrl:gateway,orderToken:'o'.repeat(32),queryToken:'q'.repeat(32),callbackToken:'c'.repeat(32),mode:'production',vpayTraderId:'3647',portalOrigins,returnUrl},
  gspay:{db:{},user:null,apiBase:gateway,authKey:'a'.repeat(32),secretKey:'b'.repeat(32),callbackToken:'c'.repeat(32),portalOrigins,returnUrl},
  oneMpay:{db:{},user:null,apiBase:'https://api.1mpay.net',merchant:'MERCHANT_1',secretKey:'s'.repeat(32),portalOrigins,callbackUrl:`${origin}/api/payment-callbacks/1mpay/payment`,returnUrl},
 };
}

test('staging remains the only fallback when no portal origin list is supplied',()=>{
 assert.equal(resolveCustomerPortalOrigin(undefined),stagingPortalOrigin);
 assert.equal(paymentReturnUrl(undefined),`${stagingPortalOrigin}/payment/return`);
 assert.equal(matchesCustomerPortalEndpoint(`${stagingPortalOrigin}/payment/return`,undefined,'/payment/return'),true);
 const c=providerContexts(stagingPortalOrigin);delete c.vpay.portalOrigins;delete c.gspay.portalOrigins;delete c.oneMpay.portalOrigins;
 assert.equal(vpayOrdersConfigured(c.vpay),true);
 assert.equal(gspayProgramConfigured(c.gspay),true);
 assert.equal(oneMpayConfigurationReady(c.oneMpay),true);
});

test('the verified staging endpoint remains accepted during an official-origin cutover',()=>{
 const c=providerContexts(stagingPortalOrigin);
 c.vpay.portalOrigins=['https://master7.best'];
 c.gspay.portalOrigins=['https://master7.best'];
 c.oneMpay.portalOrigins=['https://master7.best'];
 assert.equal(vpayOrdersConfigured(c.vpay),true);
 assert.equal(gspayProgramConfigured(c.gspay),true);
 assert.equal(oneMpayConfigurationReady(c.oneMpay),true);
});

for(const origin of officialProductionOrigins)test(`payment adapters accept the exact official customer origin ${origin}`,()=>{
 assert.equal(resolveCustomerPortalOrigin(origin),origin);
 assert.equal(resolveCustomerPortalOrigin(`${origin}/`),origin);
 const c=providerContexts(origin);
 assert.equal(vpayOrdersConfigured(c.vpay),true);
 assert.equal(gspayProgramConfigured(c.gspay),true);
 assert.equal(oneMpayConfigurationReady(c.oneMpay),true);
});

test('attacker origins, suffixes, schemes, ports, credentials, paths, queries and fragments fail closed',()=>{
 const invalid=[
  'http://www.master7.best','https://attacker.example','https://www.master7.best.attacker.example',
  'https://admin.master7.best','https://admin.master7.site','https://user@www.master7.best',
  'https://www.master7.best:443','https://www.master7.best:444','https://www.master7.best/path','https://www.master7.best?x=1',
  'https://www.master7.best#x','https://www.master7.best//',
 ];
 for(const value of invalid)assert.equal(resolveCustomerPortalOrigin(value),null,value);
 const origin='https://www.master7.best',c=providerContexts(origin);
 for(const endpoint of [
  'http://www.master7.best/payment/return','https://attacker.example/payment/return',
  'https://www.master7.best.attacker.example/payment/return','https://user@www.master7.best/payment/return',
  'https://www.master7.best:443/payment/return','https://www.master7.best:444/payment/return','https://www.master7.best/payment/return/extra',
  'https://www.master7.best/payment/return?next=https://attacker.example',
  'https://www.master7.best/payment/return#x',
 ]){
  assert.equal(matchesCustomerPortalEndpoint(endpoint,[origin],'/payment/return'),false,endpoint);
  assert.equal(vpayOrdersConfigured({...c.vpay,returnUrl:endpoint}),false,endpoint);
  assert.equal(gspayProgramConfigured({...c.gspay,returnUrl:endpoint}),false,endpoint);
 }
});

test('1MPay callback and return endpoints must use the same exact official origin and fixed paths',()=>{
 const www=providerContexts('https://www.master7.best').oneMpay;
 assert.equal(oneMpayConfigurationReady(www),true);
 assert.equal(oneMpayConfigurationReady({...www,callbackUrl:'https://master7.best/api/payment-callbacks/1mpay/payment'}),false);
 assert.equal(oneMpayConfigurationReady({...www,callbackUrl:'https://www.master7.best/api/payment-callbacks/1mpay/payment/extra'}),false);
 assert.equal(oneMpayConfigurationReady({...www,callbackUrl:'https://www.master7.best/api/payment-callbacks/1mpay/payment?x=1'}),false);
 assert.equal(oneMpayConfigurationReady({...www,callbackUrl:'https://user@www.master7.best/api/payment-callbacks/1mpay/payment'}),false);
 assert.equal(customerPortalOriginForEndpoint(www.callbackUrl,www.portalOrigins,'/api/payment-callbacks/1mpay/payment'),'https://www.master7.best');
});
