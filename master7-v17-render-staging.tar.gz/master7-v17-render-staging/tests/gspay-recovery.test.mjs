import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {gspayPlayerUsername,gspayResultSignature,recoverGSPayDeposits,queryGSPayBalance} from '../lib/gspay.ts';
import {handle} from '../lib/backend.ts';

const authKey='a'.repeat(32),secretKey='b'.repeat(32),paymentId='35802335';

function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf',0),('owner','owner','owner',1,'csrf',0)").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={calls:0,balanceCalls:0};
 const context={db,user:null,apiBase:'https://api.thegspay.com',authKey,secretKey,enabled:'false',returnUrl:'https://master7.best/payment/return',recoveryEnabled:'false',balanceEnabled:'false',fetchImpl:async input=>{
  state.calls++;const url=new URL(String(input));
  if(url.pathname===`/v2/integrations/operator/${authKey}/get/balance`){state.balanceCalls++;return Response.json({code:200,data:'123.40'});}
  const id=url.searchParams.get('transaction_id'),amount='20.00',player=gspayPlayerUsername('alice');
  return Response.json({code:200,data:JSON.stringify([{payment_id:paymentId,transaction_id:id,player_username:player,amount,completed:true,success:true,signature:gspayResultSignature(paymentId,amount,id,secretKey)}])});
 }};
 const insertOrder=()=>sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES('G7recover001','alice','recover-request-0001','fp','gspay',2000,'MYR','payment','created',?,0,0)").run(paymentId);
 t.after(()=>sql.close());return {sql,db,state,context,insertOrder};
}

test('GSPAY recovery is off by default and independently credits exactly one balanced ledger when enabled',async t=>{
 const f=fixture(t);f.insertOrder();
 let summary=await recoverGSPayDeposits(f.context);assert.equal(summary.enabled,false);assert.equal(f.state.calls,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 f.context.recoveryEnabled='true';summary=await recoverGSPayDeposits(f.context);assert.equal(summary.credited,1);assert.equal(f.state.calls,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);assert.equal(f.sql.prepare('SELECT SUM(amount_minor) total FROM wallet_ledger').get().total,0);
 summary=await recoverGSPayDeposits(f.context);assert.equal(summary.scanned,0);assert.equal(f.state.calls,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('GSPAY recovery holds a successful payment when the member is no longer eligible',async t=>{
 const f=fixture(t);f.insertOrder();f.sql.prepare("UPDATE users SET approved=0 WHERE id='alice'").run();f.context.recoveryEnabled='true';
 const summary=await recoverGSPayDeposits(f.context);assert.equal(summary.review,1);assert.equal(f.sql.prepare("SELECT status FROM deposit_orders WHERE id='G7recover001'").get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('GSPAY balance query is owner-only, default-off, read-only and never marks settlement verified',async t=>{
 const f=fixture(t);f.context.user={id:'owner',username:'owner',role:'owner',approved:1};
 let response=await queryGSPayBalance(f.context);assert.equal(response.status,503);assert.equal(f.state.calls,0);
 f.context.balanceEnabled='true';response=await queryGSPayBalance(f.context);assert.equal(response.status,200);assert.deepEqual(await response.json(),{provider:'gspay',currency:'MYR',balance:'123.40',readOnly:true,verified:false,settlementVerified:false});assert.equal(f.state.balanceCalls,1);
 f.context.user={id:'alice',username:'alice',role:'member',approved:1};response=await queryGSPayBalance(f.context);assert.equal(response.status,403);assert.equal(f.state.balanceCalls,1);
});

test('owner-only GSPAY balance candidate is mounted behind Origin and CSRF checks',async t=>{
 const f=fixture(t),origin='https://portal.example.test',config={db:f.db,identity:{userId:'owner',email:'owner@example.test'},ownerEmail:'owner@example.test',allowedOrigins:[origin],gspayApiBase:f.context.apiBase,gspayAuthKey:authKey,gspaySecretKey:secretKey,gspayReturnUrl:f.context.returnUrl,gspayBalanceEnabled:'true',gspayFetch:f.context.fetchImpl};
 let response=await handle(new Request(origin+'/api/admin/payments/gspay/balance',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'bad'},body:'{}'}),config);assert.equal(response.status,403);assert.equal(f.state.balanceCalls,0);
 response=await handle(new Request(origin+'/api/admin/payments/gspay/balance',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf'},body:'{}'}),config);assert.equal(response.status,200);const body=await response.json();assert.equal(body.balance,'123.40');assert.equal(body.verified,false);assert.equal(f.state.balanceCalls,1);
});
