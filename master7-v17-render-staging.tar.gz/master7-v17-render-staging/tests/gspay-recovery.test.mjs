import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {gspayPlayerUsername,gspayResultSignature,recoverGSPayDeposits,queryGSPayBalance,refreshGSPayOrder} from '../lib/gspay.ts';
import {handle} from '../lib/backend.ts';

const authKey='a'.repeat(32),secretKey='b'.repeat(32),paymentId='35802335';

function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf',0),('owner','owner','owner',1,'csrf',0)").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={calls:0,balanceCalls:0,patch:value=>value};
 const context={db,user:null,apiBase:'https://api.thegspay.com',authKey,secretKey,enabled:'false',returnUrl:'https://master7-v17-staging.onrender.com/payment/return',recoveryEnabled:'false',balanceEnabled:'false',fetchImpl:async input=>{
  state.calls++;const url=new URL(String(input));
  if(url.pathname===`/v2/integrations/operator/${authKey}/get/balance`){state.balanceCalls++;return Response.json({code:200,data:'123.40'});}
  const id=url.searchParams.get('transaction_id'),amount='20.00',player=gspayPlayerUsername('alice');
  return Response.json({code:200,data:JSON.stringify([state.patch({payment_id:paymentId,transaction_id:id,player_username:player,amount,completed:true,success:true,signature:gspayResultSignature(paymentId,amount,id,secretKey)})])});
 }};
 const insertOrder=({status='created',reference=paymentId,updatedAt=0}={})=>sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES('G7recover001','alice','recover-request-0001','fp','gspay',2000,'MYR','payment',?,?,0,?)").run(status,reference,updatedAt);
 t.after(()=>sql.close());return {sql,db,state,context,insertOrder};
}

test('GSPAY recovery is off by default and independently credits exactly one balanced ledger when enabled',async t=>{
 const f=fixture(t);f.insertOrder();
 let summary=await recoverGSPayDeposits(f.context);assert.equal(summary.enabled,false);assert.equal(f.state.calls,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 f.context.recoveryEnabled='true';summary=await recoverGSPayDeposits(f.context);assert.equal(summary.credited,1);assert.equal(f.state.calls,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);assert.equal(f.sql.prepare('SELECT SUM(amount_minor) total FROM wallet_ledger').get().total,0);
 summary=await recoverGSPayDeposits(f.context);assert.equal(summary.scanned,0);assert.equal(f.state.calls,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('GSPAY recovery holds a successful payment when the member is no longer eligible',async t=>{
 const f=fixture(t);f.insertOrder();f.sql.prepare("UPDATE users SET approved=0 WHERE id='alice'").run();f.context.recoveryEnabled='true';
 const summary=await recoverGSPayDeposits(f.context);assert.equal(summary.review,1);assert.equal(f.sql.prepare("SELECT status FROM deposit_orders WHERE id='G7recover001'").get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

for(const reason of ['late-success','member-ineligible','query-mismatch'])test(`GSPAY ${reason} review serializes the member risk update`,async t=>{
 const f=fixture(t);f.insertOrder({status:reason==='late-success'?'failed':'unknown'});f.context.recoveryEnabled='true';
 // Legacy partial journal: moving this order to review must block new wallet
 // commitments even if the member has unrelated, valid credited funds.
 f.sql.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('legacy-member','G7recover001','alice','member',2000,'MYR',0)").run();
 if(reason==='member-ineligible')f.sql.prepare("UPDATE users SET approved=0 WHERE id='alice'").run();
 if(reason==='query-mismatch')f.state.patch=value=>({...value,currency:'USDT'});
 const batches=[],original=f.db.batch;f.db.batch=async statements=>{batches.push(statements.map(statement=>statement.text));return original.call(f.db,statements);};
 const summary=await recoverGSPayDeposits(f.context);
 assert.equal(summary.review,1);assert.equal(f.sql.prepare("SELECT status FROM deposit_orders WHERE id='G7recover001'").get().status,'review');
 const guarded=batches.find(batch=>batch.some(statement=>/UPDATE deposit_orders SET status='review'/.test(statement)));
 assert.ok(guarded);assert.match(guarded[0],/INSERT INTO member_wallet_guards/);assert.match(guarded[1],/UPDATE member_wallet_guards/);
 assert.ok(f.sql.prepare("SELECT revision FROM member_wallet_guards WHERE user_id='alice'").get().revision>0);
});

test('a stale GSPAY review cannot change an order assigned to a different member',async t=>{
 const f=fixture(t);f.insertOrder({status:'unknown'});f.context.recoveryEnabled='true';
 f.sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('bob','bob','member',1,'csrf',0)").run();
 f.state.patch=value=>{f.sql.prepare("UPDATE deposit_orders SET user_id='bob' WHERE id='G7recover001'").run();return {...value,currency:'USDT'};};
 const summary=await recoverGSPayDeposits(f.context);assert.equal(summary.review,0);
 assert.deepEqual({...f.sql.prepare("SELECT user_id,status FROM deposit_orders WHERE id='G7recover001'").get()},{user_id:'bob',status:'unknown'});
});

for(const status of ['unknown','creating'])test(`GSPAY can recover a stale ${status} order without a provider reference using its portal order ID`,async t=>{
 const f=fixture(t);f.insertOrder({status,reference:null});f.context.recoveryEnabled='true';
 const result=await recoverGSPayDeposits(f.context);assert.equal(result.credited,1);assert.equal(result.queried,1);assert.equal(f.state.calls,1);
 assert.deepEqual({...f.sql.prepare("SELECT status,provider_trade_no FROM deposit_orders WHERE id='G7recover001'").get()},{status:'credited',provider_trade_no:paymentId});
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);assert.equal(f.sql.prepare('SELECT SUM(amount_minor) n FROM wallet_ledger').get().n,0);
 const repeat=await recoverGSPayDeposits(f.context);assert.equal(repeat.scanned,0);assert.equal(f.state.calls,1);
});

for(const status of ['unknown','creating'])test(`GSPAY waits before checking a newly ${status} order without a reference`,async t=>{
 const f=fixture(t);f.insertOrder({status,reference:null,updatedAt:Math.floor(Date.now()/1000)});f.context.recoveryEnabled='true';
 const result=await recoverGSPayDeposits(f.context);assert.equal(result.scanned,0);assert.equal(f.state.calls,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('a GSPAY no-reference query timeout keeps the order uncredited and can be retried',async t=>{
 const f=fixture(t);f.insertOrder({status:'unknown',reference:null});f.context.recoveryEnabled='true';f.state.patch=()=>{throw Error('synthetic query timeout');};
 let result=await recoverGSPayDeposits(f.context);assert.equal(result.errors,1);assert.deepEqual({...f.sql.prepare("SELECT status,provider_trade_no FROM deposit_orders WHERE id='G7recover001'").get()},{status:'unknown',provider_trade_no:null});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 f.sql.prepare("UPDATE payment_recovery_leases SET last_checked_at=0 WHERE order_id='G7recover001'").run();f.state.patch=value=>({...value,currency:'MYR'});
 result=await recoverGSPayDeposits(f.context);assert.equal(result.credited,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);assert.equal(f.state.calls,2);
});

test('GSPAY rejects an explicitly non-MYR provider query without crediting the MYR wallet',async t=>{
 const f=fixture(t);f.insertOrder({status:'unknown',reference:null});f.context.recoveryEnabled='true';f.state.patch=value=>({...value,currency:'USDT'});
 const result=await recoverGSPayDeposits(f.context);assert.equal(result.review,1);assert.equal(f.sql.prepare("SELECT status FROM deposit_orders WHERE id='G7recover001'").get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('a future non-MYR order is excluded from MYR recovery and manual status queries',async t=>{
 const f=fixture(t);f.insertOrder({status:'unknown',reference:null});f.sql.exec("PRAGMA ignore_check_constraints=ON; UPDATE deposit_orders SET currency='USDT'; PRAGMA ignore_check_constraints=OFF;");f.context.recoveryEnabled='true';
 const recovered=await recoverGSPayDeposits(f.context);assert.equal(recovered.scanned,0);assert.equal(f.state.calls,0);
 f.context.user={id:'alice',username:'alice',role:'member',approved:1};const response=await refreshGSPayOrder({orderId:'G7recover001'},f.context);assert.equal(response.status,409);assert.equal(f.state.calls,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('GSPAY cannot post MYR if the order currency changes during an independent query',async t=>{
 const f=fixture(t);f.insertOrder({status:'unknown',reference:null});f.context.recoveryEnabled='true';f.state.patch=value=>{f.sql.exec("PRAGMA ignore_check_constraints=ON; UPDATE deposit_orders SET currency='USDT'; PRAGMA ignore_check_constraints=OFF;");return value;};
 const result=await recoverGSPayDeposits(f.context);assert.equal(result.credited,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);assert.notEqual(f.sql.prepare("SELECT status FROM deposit_orders WHERE id='G7recover001'").get().status,'credited');
});

test('GSPAY balance query is owner-only, default-off, read-only and never marks settlement verified',async t=>{
 const f=fixture(t);f.context.user={id:'owner',username:'owner',role:'owner',approved:1};
 let response=await queryGSPayBalance(f.context);assert.equal(response.status,503);assert.equal(f.state.calls,0);
 f.context.balanceEnabled='true';response=await queryGSPayBalance(f.context);assert.equal(response.status,200);assert.deepEqual(await response.json(),{provider:'gspay',currency:'MYR',balance:'123.40',readOnly:true,verified:false,settlementVerified:false});assert.equal(f.state.balanceCalls,1);
 f.context.user={id:'alice',username:'alice',role:'member',approved:1};response=await queryGSPayBalance(f.context);assert.equal(response.status,403);assert.equal(f.state.balanceCalls,1);
});

test('owner-only GSPAY balance candidate is mounted behind Origin and CSRF checks',async t=>{
 const f=fixture(t),origin='https://portal.example.test',config={db:f.db,identity:{userId:'owner',email:'owner@example.test'},ownerEmail:'owner@example.test',allowedOrigins:[origin],gspayApiBase:f.context.apiBase,gspayAuthKey:authKey,gspaySecretKey:secretKey,gspayReturnUrl:f.context.returnUrl,gspayBalanceEnabled:'true',gspayFetch:f.context.fetchImpl};
 let response=await handle(new Request(origin+'/api/admin/payments/gspay/balance',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'bad'},body:'{}'}),config);assert.equal(response.status,403);assert.equal(f.state.balanceCalls,0);
 response=await handle(new Request(origin+'/api/admin/payments/gspay/balance',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf'},body:'{}'}),config);assert.equal(response.status,200);const body=await response.json();assert.equal(body.balance,'123.40');assert.equal(body.verified,false);assert.equal(f.state.balanceCalls,1);
});
