import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {defaultEngagementProgram,validateEngagementProgram} from '../lib/engagement.ts';
import {defaultRewardsHubProgram,validateRewardsHubProgram} from '../lib/rewards-hub.ts';

const plain=value=>JSON.parse(JSON.stringify(value));
const dataKey=name=>name.slice(5).replace(/-([a-z])/g,(_,letter)=>letter.toUpperCase());

// A small DOM fixture for the standalone assets; APIs are supplied by each test.
class Element {
 constructor(tag='div'){this.tagName=tag.toLowerCase();this.children=[];this.dataset={};this.listeners={};this.style={};this.value='';this.type='';this.hidden=false;this.disabled=false;this.checked=false;this.ownText='';}
 set textContent(value){this.ownText=String(value);this.children=[];}
 get textContent(){return this.ownText+this.children.map(child=>child.textContent??'').join('');}
 append(...items){for(const item of items){this.children.push(item);item.parentElement=this;}}
 replaceChildren(...items){this.ownText='';this.children=[];this.append(...items);}
 addEventListener(name,handler){this.listeners[name]=handler;}
 async dispatch(name){return this.listeners[name]?.({preventDefault(){},currentTarget:this});}
	 closest(tag){if(this.tagName===tag)return this;return this.parentElement?.closest?.(tag)??null;}
 matches(selector){
  if(selector.startsWith('#'))return this.id===selector.slice(1);
  if(selector.startsWith('.'))return (this.className||'').split(/\s+/).includes(selector.slice(1));
  const tag=selector.match(/^[a-z][a-z0-9-]*/i)?.[0];if(tag&&this.tagName!==tag)return false;
  if(selector.endsWith(':checked')&&!this.checked)return false;
  for(const [,key,operator,raw] of selector.matchAll(/\[([^\s\]=^]+)(?:(\^=|=)([^\]]*))?\]/g)){
   const actual=key.startsWith('data-')?this.dataset[dataKey(key)]:this[key],value=raw?.replace(/^["']|["']$/g,'');
   if(actual===undefined)return false;if(operator==='='&&String(actual)!==value)return false;if(operator==='^='&&!String(actual).startsWith(value))return false;
  }
  return Boolean(tag||selector.startsWith('['));
 }
 querySelectorAll(selector){const found=[];for(const child of this.children){if(child.matches?.(selector))found.push(child);found.push(...(child.querySelectorAll?.(selector)||[]));}return found;}
 querySelector(selector){return this.querySelectorAll(selector)[0]??null;}
}

function dom(){
 const root=new Element('body'),listeners={},document={readyState:'loading',createElement:tag=>new Element(tag),addEventListener:(name,handler)=>{listeners[name]=handler;},getElementById:id=>root.querySelector('#'+id),querySelector:selector=>selector.includes(':not(')?null:document.querySelectorAll(selector)[0]??null,querySelectorAll:selector=>{
  const space=selector.indexOf(' ');if(selector.startsWith('#')&&space>0)return document.getElementById(selector.slice(1,space))?.querySelectorAll(selector.slice(space+1))||[];
  return root.querySelectorAll(selector);
 }};
 const add=(id,tag='div',parent=root)=>{const element=new Element(tag);element.id=id;parent.append(element);return element;};
 return {root,document,add,get:document.getElementById,async start(){listeners.DOMContentLoaded?.();await Promise.resolve();await Promise.resolve();}};
}
function loadAsset(name,f,api,window={}){
 const source=readFileSync(new URL(`../public/assets/${name}.js`,import.meta.url),'utf8');
 vm.runInNewContext(source,{window,document:f.document,api,state:{user:{id:'synthetic-member',role:'member'}},localStorage:{getItem:()=>null,setItem(){}},Date,console});
 return window;
}
function engagementData(program){return {configured:true,program,providers:[{id:'megah5',name:'MEGAH5'},{id:'jili',name:'JILI'}],readiness:{personalizedLobby:{published:true},notificationCenter:{published:true,sound:false,sources:[{id:'tickets',enabled:true,source:'tickets_and_replies',scope:'member_scoped'},{id:'financial',enabled:true,source:'deposit_and_withdrawal_records',scope:'member_scoped'},{id:'system_status',enabled:true,source:'existing_readiness_status',scope:'public_status'}]}}};}

test('Events hides all four unimplemented engines and preserves their saved configuration when real display settings change',async()=>{
 const f=dom();for(const id of ['engagementPublicContent','engagementProgramState','engagementAdminContent','engagementManagerStatus'])f.add(id);
 const providerOption=f.add('fixtureMegaOption','option',f.add('benefitProvider','select'));providerOption.value='megah5';providerOption.textContent='MEGAH5';
 const program=defaultEngagementProgram();program.enabled=true;
 for(const key of ['tournament','depositSpin','jackpot','luckyDraw']){program[key].enabled=true;program[key].title=`Saved ${key} title`;program[key].prizeNote='Previously saved rules — preserve unchanged';}
 program.personalizedLobby={enabled:true,ownerCuratedProviders:['megah5'],maxItems:12};program.notificationCenter={enabled:true,tickets:true,financial:true,systemStatus:true,sound:false};
 const before=plain(program),requests=[],opened=[];let response=engagementData(program);
 const window=loadAsset('engagement',f,async(path,method='GET',body)=>{requests.push({path,method,body:plain(body??null)});if(method==='POST'){validateEngagementProgram(plain(body.program));response=engagementData(plain(body.program));}return response;},{openCatalogProvider:(...args)=>opened.push(args),selected:section=>opened.push(section)});
 await window.Master7Engagement.loadPublic();const text=f.get('engagementPublicContent').textContent;
 assert.match(text,/Personalized Lobby/);assert.match(text,/Notification Center/);assert.doesNotMatch(text,/Saved (tournament|depositSpin|jackpot|luckyDraw) title/);
 const cards=f.get('engagementPublicContent').querySelectorAll('.engagement-card');assert.equal(cards.length,2);
 const provider=f.get('engagementPublicContent').querySelector('.engagement-provider');provider.onclick();assert.deepEqual(opened[0],['megah5','MEGAH5']);
 await window.Master7Engagement.loadAdmin();const form=f.get('engagementManagerForm');
 assert.equal(form.querySelectorAll('[data-engagement-module]').length,0);assert.equal(form.querySelectorAll('fieldset').length,3);
 form.querySelector('[data-engagement-field="personalizedLobby.maxItems"]').value='6';form.querySelector('[data-engagement-field="notificationCenter.tickets"]').checked=false;
 await form.dispatch('submit');const saved=requests.find(request=>request.method==='POST').body.program;
 for(const key of ['tournament','depositSpin','jackpot','luckyDraw'])assert.deepEqual(saved[key],before[key]);
 assert.equal(saved.personalizedLobby.maxItems,6);assert.equal(saved.notificationCenter.tickets,false);assert.deepEqual(program,before,'editing the form never mutates the loaded configuration');
 assert.deepEqual(requests.filter(request=>request.method==='POST').map(request=>request.path),['/api/admin/engagement']);
});

function rewardsDom(){
 const f=dom();
 for(const id of ['rewardsProgramStatus','rewardsNotice','rewardsMemberArea','rewardsLoginNotice','rewardsPointsBalance','rewardsPointsName','rewardsWeek','rewardsCheckInMeta','rewardsLedger','rewardsManagerStatus','rewardsAdminActivity'])f.add(id);
 f.add('rewardsCheckIn','button');const form=f.add('rewardsManagerForm','form');
 for(const id of ['rewardsAdminEnabled','rewardsAdminPointsEnabled','rewardsAdminCheckinEnabled','rewardsAdminName','rewardsAdminPointsName'])f.add(id,'input',form);
 f.add('rewardsDayEditor','div',form);f.add('saveRewardsManager','button',form);f.add('reloadRewardsManager','button');
 for(const id of ['rewardsMissions','rewardsReferralMilestones','rewardsCoupons'])f.add(id,'div',f.add(id+'Panel','section'));
 for(const id of ['rewardsMissionEditor','rewardsMilestoneEditor','rewardsCouponEditor'])f.add(id,'div',f.add(id+'Panel','fieldset',form));
 f.add('addRewardsMilestone','button',f.get('rewardsMilestoneEditorPanel'));f.add('addRewardsCoupon','button',f.get('rewardsCouponEditorPanel'));
 return f;
}
function rewardsProgram(){const program=defaultRewardsHubProgram();program.enabled=true;program.pointsEnabled=true;program.checkIn={enabled:true,dailyPoints:[2,3,4,5,6,7,8]};program.missions.registration={enabled:true,rewardPoints:25};program.referralMilestones=[{id:'saved-referral',active:true,targetQualified:2,rewardPoints:50}];program.coupons=[{id:'saved-coupon',title:'Stored voucher',description:'Keep historic terms',active:true,expiresAt:2000000000,eligibility:{type:'min_credited_deposit',threshold:20}}];return program;}
function rewardsMember(done=false){return {points:{balance:done?9:7,ledger:[{source_type:'checkin',created_at:1762600000,points:done?2:7}]},checkIn:{enabled:true,checkedInToday:done,nextCycleDay:1,streak:done?2:1,dailyPoints:[2,3,4,5,6,7,8]}};}

test('Rewards removes preview interactions while preserving mission, milestone and coupon JSON on save',async()=>{
 const f=rewardsDom(),program=rewardsProgram(),before=plain(program),requests=[];let current={program,member:rewardsMember(),activity:{checkIns:1,ledgerEntries:1,issuedNonCashPoints:7}};
 const window=loadAsset('rewards',f,async(path,method='GET',body)=>{requests.push({path,method,body:plain(body??null)});if(method==='POST'){validateRewardsHubProgram(plain(body.program));current={...current,program:plain(body.program)};}return current;});
 await f.start();await window.Master7Rewards.loadAdmin();
 for(const id of ['rewardsMissions','rewardsReferralMilestones','rewardsCoupons']){assert.equal(f.get(id).closest('section').hidden,true);assert.equal(f.get(id).children.length,0);}
 for(const id of ['rewardsMissionEditor','rewardsMilestoneEditor','rewardsCouponEditor']){assert.equal(f.get(id).closest('fieldset').hidden,true);assert.equal(f.get(id).children.length,0);}
 assert.equal(f.get('addRewardsMilestone').listeners.click,undefined);assert.equal(f.get('addRewardsCoupon').listeners.click,undefined);
 f.get('rewardsAdminName').value='Updated check-in program';f.get('rewardsDayEditor').querySelector('[data-reward-field="day.0"]').value='11';
 await f.get('rewardsManagerForm').dispatch('submit');const saved=requests.find(request=>request.method==='POST').body.program;
 for(const key of ['missions','referralMilestones','coupons'])assert.deepEqual(saved[key],before[key]);
 assert.equal(saved.name,'Updated check-in program');assert.equal(saved.checkIn.dailyPoints[0],11);assert.deepEqual(program,before);
 assert.deepEqual(requests.filter(request=>request.method==='POST').map(request=>request.path),['/api/admin/rewards']);
});

test('Rewards keeps the member check-in action, non-cash balance and history after preview cleanup',async()=>{
 const f=rewardsDom(),program=rewardsProgram(),requests=[];let member=rewardsMember();
 const window=loadAsset('rewards',f,async(path,method='GET')=>{requests.push({path,method});if(method==='POST'){assert.equal(path,'/api/rewards/check-in');member=rewardsMember(true);return {member,points:2,idempotent:false,walletCredited:false};}return {program,member};});
 await f.start();await window.Master7Rewards.loadPublic();assert.equal(f.get('rewardsCheckIn').disabled,false);assert.equal(f.get('rewardsPointsBalance').textContent,'7');assert.match(f.get('rewardsLedger').textContent,/每日签到/);
 await f.get('rewardsCheckIn').dispatch('click');assert.equal(f.get('rewardsCheckIn').disabled,true);assert.equal(f.get('rewardsPointsBalance').textContent,'9');assert.match(f.get('rewardsLedger').textContent,/\+2/);
 assert.deepEqual(requests.filter(request=>request.method==='POST').map(request=>request.path),['/api/rewards/check-in']);
});
