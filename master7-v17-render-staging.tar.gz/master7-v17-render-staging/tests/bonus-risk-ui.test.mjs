import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const script=readFileSync(new URL('../public/assets/bonus-risk.js',import.meta.url),'utf8');
const styles=readFileSync(new URL('../public/assets/bonus-risk.css',import.meta.url),'utf8');
const portal=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');

test('bonus hunter UI is a monitor-only manual-review surface',()=>{
 assert.match(script,/\/api\/admin\/risk\/bonus-hunter/);
 assert.match(script,/Manual review/);
 assert.match(script,/No automatic action/);
 assert.match(script,/Connected sources only/);
 assert.match(script,/Cases shown/);
 assert.match(script,/state\.user\?\.role==='owner'/);
 assert.match(script,/source/);
 assert.match(portal,/href="#bonusHunterPanel"/);
 assert.match(portal,/id="bonusHunterPanel"(?![^>]*data-owner-only)/);
 assert.match(portal,/id="bonusRiskConfigPanel"[^>]*data-owner-only/);
 assert.match(portal,/source: not_connected/);
 assert.match(portal,/现有 bank \/ amount fingerprint 不会被当作回单证据/);
 assert.match(portal,/\/assets\/bonus-risk\.css\?v=/);
 assert.match(portal,/\/assets\/bonus-risk\.js\?v=/);
 assert.match(app,/bonusHunterPanel:\(\)=>window\.Master7BonusRisk\?\.load\(\)/);
 assert.doesNotMatch(script,/innerHTML|receipt_data|account_number|phone|password|secret|autoBan|freeze|deduct|rejectPayment/i);
});

test('bonus hunter UI includes a slow cyan status light and responsive layouts',()=>{
 assert.match(styles,/bonus-risk-live-light/);
 assert.match(styles,/#57f5da/);
 assert.match(styles,/2\.8s ease-in-out infinite/);
 assert.match(styles,/prefers-reduced-motion/);
 assert.match(styles,/@media\(max-width:560px\)/);
});
