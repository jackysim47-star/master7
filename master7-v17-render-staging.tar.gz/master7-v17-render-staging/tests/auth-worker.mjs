// Exercise the real Cloudflare runtime, D1, and native scrypt with disposable test credentials.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync,readFileSync,readdirSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {randomBytes,createHash} from 'node:crypto';
const require=createRequire(import.meta.url);
const runtimeRequire=createRequire(require.resolve('wrangler/package.json'));
const {Miniflare}=runtimeRequire('miniflare');
const {build}=runtimeRequire('esbuild');
const dir=mkdtempSync(join(tmpdir(),'master7-worker-auth-'));
const code=randomBytes(32).toString('base64url'),resetCode=randomBytes(32).toString('base64url'),resetIssuedAt=Math.floor(Date.now()/1000);
const password=randomBytes(24).toString('base64url');
const newPassword=randomBytes(24).toString('base64url');
const entry=join(dir,'worker.ts'),output=join(dir,'worker.mjs');
function splitMigration(source){
 const statements=[];let current='',quote='',trigger=false;
 for(let index=0;index<source.length;index+=1){
  const char=source[index];
  if(quote){
   current+=char;
   if(char===quote){
    if(source[index+1]===quote){current+=source[index+1];index+=1;}
    else quote='';
   }
   continue;
  }
  if(char==="'"||char==='"'||char==='`'){quote=char;current+=char;continue;}
  if(char===';'&&(!trigger||/\bEND\s*$/i.test(current.trim()))){
   if(current.trim())statements.push(current.trim());
   current='';trigger=false;continue;
  }
  current+=char;
  if(!trigger&&/^\s*CREATE\s+TRIGGER\b/i.test(current))trigger=true;
 }
 if(current.trim())statements.push(current.trim());
 return statements;
}
writeFileSync(entry,`import {handle} from ${JSON.stringify(resolve('lib/backend.ts'))}; export default {fetch(req,env){return handle(req,{db:{prepare:sql=>env.DB.prepare(sql),batch:async statements=>{try{return await env.DB.batch(statements);}catch(error){console.error('Disposable test database failure:',error.message);throw error;}}},identity:null,ownerEmail:'owner@example.test',ownerLoginId:'master7_owner',ownerSetupHash:env.SETUP_HASH,ownerSetupExpires:2000000000,ownerResetHash:env.RESET_HASH,ownerResetIssuedAt:Number(env.RESET_ISSUED),ownerResetExpires:2000000000});}};`);
let mf;
try{
 await build({entryPoints:[entry],outfile:output,bundle:true,format:'esm',platform:'neutral',target:'es2022',external:['node:*']});
 mf=new Miniflare({rootPath:dir,modulesRoot:dir,modules:true,scriptPath:output,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],bindings:{SETUP_HASH:createHash('sha256').update(code).digest('hex'),RESET_HASH:createHash('sha256').update(resetCode).digest('hex'),RESET_ISSUED:String(resetIssuedAt)}});
 const db=await mf.getD1Database('DB');
 for(const name of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort()){
  const migration=readFileSync(join('drizzle',name),'utf8')
   .replaceAll('--> statement-breakpoint','')
   .replace(/^\s*--.*$/gm,'')
   .replace(/^\s*(?:BEGIN|COMMIT|ROLLBACK)\s*;\s*$/gmi,'');
  for(const sql of splitMigration(migration))await db.prepare(sql).run();
 }
 let cookie='',csrf='';
 async function call(path,data){const response=await mf.dispatchFetch('https://portal.example.test'+path,{method:data===undefined?'GET':'POST',headers:{'content-type':'application/json',origin:'https://portal.example.test',cookie,'x-csrf-token':csrf},...(data===undefined?{}:{body:JSON.stringify(data)})});const next=response.headers.get('set-cookie');if(next)cookie=next.split(';')[0];return {status:response.status,body:await response.json()};}
 const start=performance.now();
 assert.equal((await call('/api/auth/activate',{code,password})).status,201);
 assert.equal((await call('/api/auth/activate',{code,password})).status,409);
 assert.equal((await call('/api/auth/login',{username:'master7_owner',password})).status,200);
 const session=await call('/api/session');assert.equal(session.body.user.role,'owner');csrf=session.body.csrf;
 assert.equal((await call('/api/admin/summary')).status,200);
 const oldCookie=cookie;
 assert.equal((await call('/api/auth/change-password',{currentPassword:password,newPassword})).status,200);
 cookie=oldCookie;assert.equal((await call('/api/admin/summary')).status,401);
 assert.equal((await call('/api/auth/login',{username:'master7_owner',password:newPassword})).status,200);
 const beforeResetCookie=cookie;
 await db.prepare('UPDATE password_credentials SET changed_at=?').bind(resetIssuedAt-10).run();
 const resetPassword=randomBytes(24).toString('base64url');
 const resets=await Promise.all([call('/api/auth/reset-owner',{code:resetCode,password:resetPassword}),call('/api/auth/reset-owner',{code:resetCode,password:resetPassword})]);
 assert.deepEqual(resets.map(x=>x.status).sort(),[200,409]);
 assert.equal((await db.prepare('SELECT version FROM password_credentials').first()).version,3);
 assert.equal((await db.prepare("SELECT count(*) n FROM audit WHERE event='owner_password_reset'").first()).n,1);
 cookie=beforeResetCookie;assert.equal((await call('/api/admin/summary')).status,401);
 assert.equal((await call('/api/auth/login',{username:'master7_owner',password:newPassword})).status,401);
 assert.equal((await call('/api/auth/login',{username:'master7_owner',password:resetPassword})).status,200);
 assert.equal((await call('/api/auth/options')).body.ownerResetAvailable,false);
 console.log(JSON.stringify({runtime:'Cloudflare workerd',result:'passed',checks:['activation','single-use','scrypt login','secure session','owner authorization','password change','old session revoked','new password login','concurrent reset single winner','single reset audit and version increment','reset revokes old session','old password rejected','reset password login','reset no longer available'],elapsedMs:Math.round(performance.now()-start)}));
}finally{if(mf)await mf.dispose();rmSync(dir,{recursive:true,force:true});}
