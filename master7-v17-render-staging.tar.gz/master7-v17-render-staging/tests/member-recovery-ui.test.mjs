import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8'),definitions=app.slice(0,app.indexOf('(async function start(){'));
function evaluate(hash='',pathname='/member-reset'){
 const changes=[],context=vm.createContext({URL,URLSearchParams,Date,setTimeout,clearTimeout,crypto:globalThis.crypto,TextEncoder,TextDecoder,location:{hash,pathname,search:'',origin:'https://fixture.test'},history:{replaceState(...args){changes.push(args);}},localStorage:{getItem(){return null;}},navigator:{},document:{getElementById(){return null;},querySelectorAll(){return [];},querySelector(){return null;},createElement(){return {};},addEventListener(){},body:{classList:{toggle(){},add(){},remove(){}}}},window:{addEventListener(){}}});
 vm.runInContext(definitions,context);return {changes,grant:JSON.parse(vm.runInContext('JSON.stringify(state.memberReset)',context))};
}
const fragment=(username,code)=>'#member-reset='+encodeURIComponent(new URLSearchParams({username,code}).toString());
test('member recovery consumes the private fragment before startup and removes it from the address',()=>{
 const code='R'.repeat(43),r=evaluate(fragment('master7',code));assert.deepEqual(r.grant,{username:'master7',code});assert.deepEqual(r.changes,[[null,'','/member-reset']]);
 assert.ok(app.indexOf('initialMemberReset=consumeMemberResetFragment()')<app.indexOf('const state ='));assert.ok(app.indexOf('initialMemberReset=consumeMemberResetFragment()')<app.indexOf('configureAdvertisingPixels'));
});
test('bad or misplaced member recovery fragments never retain a credential',()=>{
 for(const hash of ['#member-reset=broken',fragment('owner','short'),fragment('bad id','R'.repeat(43))]){const r=evaluate(hash);assert.equal(r.grant,null);assert.deepEqual(r.changes,[[null,'','/member-reset']]);}
 const wrong=evaluate(fragment('master7','R'.repeat(43)),'/signin');assert.equal(wrong.grant,null);assert.deepEqual(wrong.changes,[[null,'','/signin']]);
});
test('member recovery has an explicit route and never persists its grant in browser storage',()=>{
 assert.match(readFileSync(new URL('../app/member-reset/route.ts',import.meta.url),'utf8'),/export\s*\{\s*GET\s*,\s*HEAD\s*,\s*dynamic\s*\}\s*from\s*['"]\.\.\/route['"]/);
 assert.doesNotMatch(app,/(?:localStorage|sessionStorage)\.setItem\([^\n]*memberReset/);
 assert.match(app,/api\("\/api\/auth\/reset-member","POST"/);assert.match(app,/history\.replaceState\(null,"","\/signin"\);showAuth\("login"\);\$\("authUsername"\)\.value=result\.username/);
});
