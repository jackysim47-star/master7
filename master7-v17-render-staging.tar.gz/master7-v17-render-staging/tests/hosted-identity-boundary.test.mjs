import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const require=createRequire(import.meta.url);
const runtimeRequire=createRequire(require.resolve('wrangler/package.json'));
const {build}=runtimeRequire('esbuild');

class Statement{
 constructor(sql,database,args=[]){this.sql=sql;this.database=database;this.args=args;}
 bind(...args){return new Statement(this.sql,this.database,args);}
 async first(){return this.database.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.database.prepare(this.sql).all(...this.args)};}
 async run(){return this.database.prepare(this.sql).run(...this.args);}
}

test('Render route ignores caller-supplied OAI identity headers',async()=>{
 const directory=mkdtempSync(join(tmpdir(),'master7-route-identity-')),entry=join(directory,'entry.ts'),output=join(directory,'route.mjs');
 const sqlite=new DatabaseSync(':memory:');
 sqlite.exec('CREATE TABLE users(id TEXT PRIMARY KEY,username TEXT NOT NULL,role TEXT NOT NULL,approved INTEGER NOT NULL,csrf TEXT NOT NULL,created_at INTEGER NOT NULL)');
 const db={
  prepare(sql){return new Statement(sql,sqlite);},
  async batch(statements){sqlite.exec('BEGIN');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}
 };
 const routeEnvironment={
  DB:db,
  RENDER_EXTERNAL_URL:'https://portal.example.test',
  PUBLIC_ORIGIN:'https://portal.example.test',
  OWNER_EMAIL:'owner@example.test',
  // Even an accidental flag on a directly reachable Render service must not
  // turn caller-controlled headers into authentication assertions.
  OAI_HOSTED_IDENTITY_TRUSTED:'true'
 };
 globalThis.__master7RouteEnvironment=routeEnvironment;
 writeFileSync(entry,`import {GET,POST} from ${JSON.stringify(resolve('app/api/[...path]/route.ts'))};export {GET,POST};`);
 try{
  await build({
   entryPoints:[entry],outfile:output,bundle:true,format:'esm',platform:'node',target:'node22',external:['node:*'],
   plugins:[{name:'route-runtime-stubs',setup(builder){
    builder.onResolve({filter:/^cloudflare:workers$/},()=>({path:'cloudflare-workers',namespace:'master7-test'}));
    builder.onResolve({filter:/^next\/headers$/},()=>({path:'next-headers',namespace:'master7-test'}));
    builder.onResolve({filter:/^next\/navigation$/},()=>({path:'next-navigation',namespace:'master7-test'}));
    builder.onLoad({filter:/.*/,namespace:'master7-test'},args=>{
     if(args.path==='cloudflare-workers')return {contents:'export const env=globalThis.__master7RouteEnvironment;'};
     if(args.path==='next-headers')return {contents:'export async function headers(){return globalThis.__master7RouteHeaders??new Headers();}'};
     return {contents:'export function redirect(path){throw new Error(`Unexpected redirect to ${path}`);}'};
    });
   }}]
  });
  const route=await import(pathToFileURL(output).href);
  const invoke=async(method,path,headers={},body)=>{
   const request=new Request('https://portal.example.test'+path,{method,headers,...(body===undefined?{}:{body:JSON.stringify(body)})});
   globalThis.__master7RouteHeaders=request.headers;
   const response=await route[method](request);
   return {status:response.status,data:await response.json()};
  };
  const spoofed={'oai-authenticated-user-id':'attacker-owner','oai-authenticated-user-email':'owner@example.test'};
  const session=await invoke('GET','/api/session',spoofed);
  assert.equal(session.status,200);
  assert.equal(session.data.user,null);
  assert.equal(session.data.csrf,null);
  assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM users').get().count,0);

  const write=await invoke('POST','/api/admin/approve',{...spoofed,origin:'https://portal.example.test','content-type':'application/json','x-csrf-token':'attacker-token'},{userId:'target'});
  assert.equal(write.status,401);
  assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM users').get().count,0);

  // If a hosted deployment explicitly enables its trusted identity edge, a
  // first-seen identity still enters as an unapproved member, never as owner
  // merely because its asserted email matches OWNER_EMAIL.
  delete routeEnvironment.RENDER_EXTERNAL_URL;
  const hostedSession=await invoke('GET','/api/session',spoofed);
  assert.equal(hostedSession.status,200);
  assert.equal(hostedSession.data.user.role,'member');
  assert.equal(hostedSession.data.user.approved,false);
  assert.deepEqual({...sqlite.prepare('SELECT id,role,approved FROM users').get()},{id:'attacker-owner',role:'member',approved:0});
 }finally{
  delete globalThis.__master7RouteHeaders;
  delete globalThis.__master7RouteEnvironment;
  sqlite.close();
  rmSync(directory,{recursive:true,force:true});
 }
});
