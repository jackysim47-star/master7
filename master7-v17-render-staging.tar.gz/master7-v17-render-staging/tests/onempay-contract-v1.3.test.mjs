import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {oneMpayCallbackToken,oneMpayOrderToken} from '../lib/onempay.ts';

const contract=JSON.parse(readFileSync(new URL('./fixtures/onempay-api-v1.3-contract.json',import.meta.url),'utf8'));
const rawSha256Base64=value=>createHash('sha256').update(value).digest('base64');

test('1MPay contract evidence is pinned to the recovered official v1.3 document',()=>{
 assert.equal(contract.source.release,'1.3');
 assert.equal(contract.source.date,'2026-06-23');
 assert.equal(contract.source.original_sha256,'cb537c2f84ba049bfe371f7dcc81ed9fc191a6b1b4459e0bc6fa71ac707eeb4b');
 assert.equal(contract.deposit.method,'POST');
 assert.equal(contract.deposit.path,'/fundtransfer/json');
 assert.equal(contract.callback.method,'POST');
 assert.equal(contract.callback.late_status_correction_documented,true);
 assert.equal(contract.callback.acknowledgement_body,'MISSING EVIDENCE');
 assert.equal(contract.query.method,'GET');
 assert.equal(contract.query.path_template,'/transquery/{trxno}/{base64_token}');
 assert.equal(contract.payout.phase_1_policy,'NOT ENABLED');
});

test('1MPay implementation follows the official create, callback and query token formulas',()=>{
 const merchant='TESTMERCHANT',amount='20.00',refid='M7CONTRACT000000001',customer='M7CUSTOMER',apikey='fixture-secret-12345678',currency='MYR',trxno='TRX-CONTRACT-1';
 const createExpected=rawSha256Base64(merchant+amount+refid+customer+apikey+currency);
 const callbackExpected=rawSha256Base64(merchant+amount+refid+customer+apikey+trxno);
 assert.equal(oneMpayOrderToken(merchant,amount,refid,customer,apikey,currency),createExpected);
 assert.equal(oneMpayCallbackToken(merchant,amount,refid,customer,apikey,trxno),callbackExpected);
 assert.equal(Buffer.from(callbackExpected,'utf8').toString('base64'),Buffer.from(oneMpayCallbackToken(merchant,amount,refid,customer,apikey,trxno),'utf8').toString('base64'));
 assert.deepEqual(contract.deposit.required_fields.slice().sort(),['merchant','amount','refid','token','customer','currency','post_url','failed_return_url','return_url'].sort());
});
