import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';

function fixture(){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,?)").run('owner','owner','owner',1,'owner-csrf',1);
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,?)").run('member','member','member',1,'member-csrf',1);
 sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)").run('order-vpay','member','request-vpay','fingerprint','vpay',2000,'MYR','1','unknown',1,1);
 const activity={network:0};
 class Statement{
  constructor(query,args=[]){this.query=query;this.args=args;}
  bind(...args){return new Statement(this.query,args);}
  async first(){return sql.prepare(this.query).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.query).all(...this.args)};}
  async run(){return sql.prepare(this.query).run(...this.args);}
 }
 const db={prepare(query){return new Statement(query);},async batch(statements){for(const statement of statements)await statement.run();}};
 const context={db,identity:{userId:'owner',email:'owner@example.test'},ownerEmail:'owner@example.test',allowedOrigins:['https://portal.example.test'],vpayFetch:async()=>{activity.network++;throw Error('unexpected provider request');},gspayFetch:async()=>{activity.network++;throw Error('unexpected provider request');},oneMpayFetch:async()=>{activity.network++;throw Error('unexpected provider request');}};
 async function call(data,who='owner'){
  const user=sql.prepare('SELECT csrf FROM users WHERE id=?').get(who);
  const response=await handle(new Request('https://portal.example.test/api/admin/deposits/query',{method:'POST',headers:{Origin:'https://portal.example.test','Content-Type':'application/json','X-CSRF-Token':String(user?.csrf??'')},body:JSON.stringify(data)}),{...context,identity:{userId:who,email:`${who}@example.test`}});
  return {status:response.status,data:await response.json()};
 }
 return {sql,db,context,activity,call};
}

test('manual provider query requires explicit confirmation before reading the order',async()=>{
 const f=fixture(),result=await f.call({provider:'vpay',orderId:'order-vpay',reason:'Owner reconciliation'});
 assert.equal(result.status,400);assert.match(result.data.error,/confirmation/i);
 assert.equal(f.sql.prepare("SELECT COUNT(*) count FROM audit WHERE event LIKE 'payment_manual_query_%'").get().count,0);
 assert.equal(f.activity.network,0);f.sql.close();
});

test('owner manual query is bound to an existing order, is audited, and fails closed without provider configuration',async()=>{
 const f=fixture(),result=await f.call({provider:'vpay',orderId:'order-vpay',confirm:true,reason:'Owner reconciliation'});
 assert.equal(result.status,503);assert.equal(result.data.error,'VPAY_NOT_CONFIGURED');
 const events=f.sql.prepare("SELECT event,target FROM audit WHERE event LIKE 'payment_manual_query_%'").all();
 assert.deepEqual(new Set(events.map(row=>row.event)),new Set(['payment_manual_query_requested','payment_manual_query_completed']));
 assert.ok(events.some(row=>row.event==='payment_manual_query_requested'&&/order-vpay/.test(String(row.target))));assert.ok(events.some(row=>row.event==='payment_manual_query_completed'&&/unknown/.test(String(row.target))));
 assert.equal(f.activity.network,0);assert.equal(f.sql.prepare("SELECT status FROM deposit_orders WHERE id='order-vpay'").get().status,'unknown');f.sql.close();
});

test('manual query cannot create or query an unknown order and remains owner-only',async()=>{
 const f=fixture();
 const unknown=await f.call({provider:'gspay',orderId:'missing',confirm:true,reason:'Owner reconciliation'});
 assert.equal(unknown.status,404);assert.equal(f.sql.prepare("SELECT COUNT(*) count FROM deposit_orders WHERE id='missing'").get().count,0);
 const member=await f.call({provider:'vpay',orderId:'order-vpay',confirm:true,reason:'Owner reconciliation'},'member');
 assert.equal(member.status,403);assert.equal(f.activity.network,0);f.sql.close();
});
