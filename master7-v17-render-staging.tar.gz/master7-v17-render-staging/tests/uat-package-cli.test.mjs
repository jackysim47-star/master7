import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import test from 'node:test';
import {createUatPackageTemplate} from '../lib/uat-package.ts';

test('pnpm-style separator validates one complete non-secret UAT manifest',t=>{
 const directory=mkdtempSync(join(tmpdir(),'master7-uat-package-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 const template=createUatPackageTemplate({kind:'game',providerProfile:'jili_myr_1to1',releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
 const manifest={...template,authorizedUat:true,officialContactVerified:true,whitelistConfirmed:true,evidence:Object.fromEntries(template.requiredEvidence.map(key=>[key,{reference:`synthetic/jili/${key}`,sha256:'c'.repeat(64)}]))};
 const path=join(directory,'manifest.json');writeFileSync(path,JSON.stringify(manifest));
 const result=spawnSync(process.execPath,['scripts/validate-uat-package.mjs','--',path],{cwd:new URL('..',import.meta.url),encoding:'utf8'});
 assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout);assert.equal(report.schemaValid,true);assert.equal(report.readyForRestrictedUat,true);assert.equal(report.accepted,false);assert.equal(report.productionReady,false);
});

test('CLI fails closed for incomplete or missing manifests',t=>{
 const directory=mkdtempSync(join(tmpdir(),'master7-uat-package-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 const path=join(directory,'manifest.json');writeFileSync(path,JSON.stringify({schemaVersion:1,kind:'payment',providerProfile:'vpay_myr',environment:'production',releaseVersion:'17.0.0-selfbuilt.174-uat-preview',evidence:{}}));
 const incomplete=spawnSync(process.execPath,['scripts/validate-uat-package.mjs',path],{cwd:new URL('..',import.meta.url),encoding:'utf8'});assert.equal(incomplete.status,1);assert.equal(JSON.parse(incomplete.stdout).readyForRestrictedUat,false);
 const missing=spawnSync(process.execPath,['scripts/validate-uat-package.mjs',join(directory,'missing.json')],{cwd:new URL('..',import.meta.url),encoding:'utf8'});assert.equal(missing.status,1);assert.equal(JSON.parse(missing.stdout).readyForRestrictedUat,false);
});
