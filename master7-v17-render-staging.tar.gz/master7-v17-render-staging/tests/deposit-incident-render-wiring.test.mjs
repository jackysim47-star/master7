import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
import ts from 'typescript';
import * as maps from '../lib/render-env-map.mjs';
import {authorizeDepositIncidentRead} from '../lib/deposit-incident-evidence.ts';

function load(url,require,processEnv){
 const exports={};
 const js=ts.transpileModule(readFileSync(url,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 vm.runInNewContext(js,{exports,require,process:{env:processEnv},URL,Response,Buffer,console});return exports;
}
for(const scenario of ['configured','absent','expired'])test('Render environment and HTTP dispatch preserve incident authorization: '+scenario,async()=>{
 const token='d'.repeat(64),hash=createHash('sha256').update(token).digest('hex'),now=Math.floor(Date.now()/1000);
 const processEnv=scenario==='absent'?{}:{PORTAL_DEPOSIT_FORENSICS_TOKEN_HASH:hash,PORTAL_DEPOSIT_FORENSICS_EXPIRES_AT:String(scenario==='expired'?now-1:now+60)};
 const runtime=load(new URL('../lib/render-env.ts',import.meta.url),name=>{
  if(name==='./render-d1')return {RenderD1Compat:class {}};
  if(name==='./render-env-map.mjs')return maps;
  throw Error('unexpected runtime dependency');
 },processEnv);
 const route=load(new URL('../app/api/[...path]/route.ts',import.meta.url),name=>{
  if(name==='cloudflare:workers')return runtime;
  if(name==='../../chatgpt-auth')return {getChatGPTUser:async()=>null};
  if(name==='../../../lib/backend')return {handle:async(req,context)=>Response.json({authorized:authorizeDepositIncidentRead(req.headers.get('authorization'),context.depositIncidentTokenHash,context.depositIncidentExpiresAt)})};
  throw Error('unexpected route dependency');
 },processEnv);
 const result=await route.GET(new Request('https://portal.test/api/internal/deposit-incidents',{headers:{authorization:'Bearer '+token}}));
 assert.equal((await result.json()).authorized,scenario==='configured');
});
