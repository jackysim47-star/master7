import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {createDecipheriv} from 'node:crypto';
import {handle} from '../lib/backend.ts';
import {jdbPlayerId} from '../lib/jdb-transfer-protocol.ts';
import {jdbProfileRuntime} from '../lib/jdb-profile-runtime.ts';
import {GAME_PROVIDER_ACCEPTANCE_CAPABILITIES,getGameProviderAcceptanceReadiness} from '../lib/game-provider-acceptance.ts';

function fixture(){
 const sqlite=new DatabaseSync(':memory:');for(const name of readdirSync(new URL('../drizzle',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 for(const [id,role] of [['alice','member'],['bob','member'],['owner','owner'],['staff','staff']])sqlite.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,1,?,0)').run(id,id,role,'csrf-'+id);
 sqlite.exec("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('synthetic-credit','alice','synthetic-credit','fixture','manual_bank',2000,'MYR','fixture','credited',0,0);INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('synthetic-member','synthetic-credit','alice','member',2000,'MYR',0),('synthetic-clearing','synthetic-credit','alice','provider_clearing',-2000,'MYR',0)");
 class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}async first(){return sqlite.prepare(this.sql).get(...this.args)??null;}async all(){return{results:sqlite.prepare(this.sql).all(...this.args)};}async run(){return sqlite.prepare(this.sql).run(...this.args);}}
 let queue=Promise.resolve();const db={prepare:sql=>new Statement(sql),batch(statements){const result=queue.then(async()=>{sqlite.exec('BEGIN IMMEDIATE');try{const out=[];for(const s of statements)out.push(await s.run());sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}});queue=result.catch(()=>{});return result;}};
 const connection={profile:'jdb_myr',baseUrl:'https://provider.example.test',dc:'synthetic',parent:'agent01',aesKey:'key1234567Sample',aesIv:'iv12345678Sample',padding:'space',launchOrigins:['https://games.example.test'],reportUtcOffsetMinutes:480},slot={mode:'qa',environment:'production',recoveryEnabled:true,sessionClosureVerified:true,qaMemberIds:['alice'],approvedApiOrigins:[connection.baseUrl],connection},document={profiles:{jdb_myr:slot}},factory={balance:0,playing:false,pid:100,timeoutDeposit:false,query:new Map(),calls:[]};
 const transport=async (url,init)=>{
  assert.equal(url,'https://provider.example.test/apiRequest.do');const envelope=JSON.parse(init.body),cipher=createDecipheriv('aes-128-cbc',Buffer.from(connection.aesKey),Buffer.from(connection.aesIv));cipher.setAutoPadding(false);const p=JSON.parse(Buffer.concat([cipher.update(Buffer.from(envelope.x,'base64url')),cipher.final()]).toString('utf8').trim());factory.calls.push(p);assert.equal(envelope.dc,'synthetic');
  const ok=body=>Response.json({status:'0000',...body});
  if(p.action===49)return ok({data:[{gType:0,list:[{mType:100,name:'Synthetic game',maintenance:false}]}]});
  if(p.action===12)return ok({});
  if(p.action===15)return ok({data:[{uid:p.uid,parent:'agent01',currency:'RM',lvl:0,locked:0,closed:0,balance:(factory.balance/100).toFixed(2)}]});
  if(p.action===52)return factory.playing?ok({data:{gType:0,mType:100}}):Response.json({status:'7505'});
  if(p.action===17){factory.playing=false;return ok({});}
  if(p.action===19){const pid=++factory.pid;factory.balance+=Math.round(p.amount*100);factory.query.set(p.serialNo,{uid:p.uid,action:p.amount>0?'deposit':'withdraw',amount:p.amount,pid});if(p.amount>0&&factory.timeoutDeposit)throw Error('Synthetic response lost');return ok({serialNo:p.serialNo,amount:p.amount,pid});}
  if(p.action===11){factory.playing=true;return ok({path:'https://games.example.test/synthetic-single-use-url'});}
  if(p.action===55){const q=factory.query.get(p.serialNo);return q?ok({data:[q]}):Response.json({status:'7500'});}
  throw Error('Unexpected synthetic action '+p.action);
 };
 const gameGatewayFetch=async url=>{
  assert.equal(url,'https://master7-integration-gateway.onrender.com/providers/jdb/games');
  return Response.json({provider:'jdb',games:[{gameCode:'0:100',name:'Synthetic game',category:'SLOT',maintenance:false}],complete:true,upstreamStatus:200});
 };
 const config={db,ownerEmail:'',newDepositsEnabled:'false',newPayoutsEnabled:'false',newGameLaunchesEnabled:'true',providerTransferFetch:transport,gameGatewayUrl:'https://master7-integration-gateway.onrender.com',gameGatewayFetch};
 const request=async (who,path,method='GET',data,extra={})=>{
  const response=await handle(new Request('https://www.master7.best'+path,{method,headers:{Origin:'https://www.master7.best','Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,'X-Forwarded-For':'192.0.2.8'},...(data?{body:JSON.stringify(data)}:{})}),{...config,identity:who?{userId:who,email:who+'@example.test'}:null,jdbTransferProfilesJson:JSON.stringify(document),...extra});
  return {status:response.status,body:await response.json()};
 };
 const launch=()=>request('alice','/api/game-launch','POST',{profileId:'jdb_myr',providerId:'jdb',gameCode:'0:100',idempotencyKey:crypto.randomUUID(),language:'zh'});
 const acceptJdb=async()=>{for(const capability of GAME_PROVIDER_ACCEPTANCE_CAPABILITIES){const result=await request('owner','/api/admin/game-acceptance','POST',{profileId:'jdb_myr',capability,environment:'production',result:'passed',evidenceSha256:'a'.repeat(64),evidenceReference:`synthetic-${capability}`,observedAt:Math.floor(Date.now()/1000),expectedEventId:null});assert.equal(result.status,201,JSON.stringify(result));}};
 return{sqlite,db,document,connection,slot,factory,config,request,launch,acceptJdb,close:()=>sqlite.close()};
}

test('universal API connects the approved QA member through JDB crypto, held wallet, settlement and shared staff records',async()=>{
 const h=fixture();try{
  const start=await h.launch();assert.equal(start.status,200,JSON.stringify(start));assert.equal(start.body.profileId,'jdb_myr');assert.ok(start.body.walletSessionId);assert.equal(start.body.launchUrl,'https://games.example.test/synthetic-single-use-url');assert.equal(h.factory.calls.filter(p=>p.action===19&&p.amount>0).length,1);assert.equal(h.factory.balance,2000);
  const wallet=await h.request('alice','/api/game-wallet?profileId=jdb_myr');assert.equal(wallet.status,200);assert.equal(wallet.body.wallet.availableMinor,'0');assert.equal(wallet.body.session.id,start.body.walletSessionId);assert.equal(wallet.body.session.profileId,'jdb_myr');assert.equal(wallet.body.supportsRecovery,true);
  h.factory.balance=1575;h.config.newGameLaunchesEnabled='false';
  const end=await h.request('alice','/api/game-wallet/settle','POST',{profileId:'jdb_myr',sessionId:start.body.walletSessionId});assert.equal(end.status,200,JSON.stringify(end));assert.equal(end.body.session.resultMinor,'-425');assert.equal(h.factory.balance,0);assert.ok(h.factory.calls.some(p=>p.action===17));assert.equal(h.factory.calls.filter(p=>p.action===19&&p.amount<0).length,1);
  const final=await h.request('alice','/api/game-wallet?profileId=jdb_myr');assert.equal(final.body.wallet.availableMinor,'1575');const replay=await h.request('alice','/api/game-wallet/recover','POST',{profileId:'jdb_myr',sessionId:start.body.walletSessionId});assert.equal(replay.status,200);assert.equal(h.factory.calls.filter(p=>p.action===19&&p.amount<0).length,1);
  for(const who of ['owner','staff']){const records=await h.request(who,'/api/admin/game-wallet');assert.equal(records.status,200,JSON.stringify(records));const record=records.body.profileItems.find(x=>x.id===start.body.walletSessionId);assert.equal(record.amountOutMinor,'2000');assert.equal(record.amountReturnedMinor,'1575');assert.equal(record.resultMinor,'-425');assert.equal(record.reservedMinor,null);assert.equal(record.lastTransfer.providerReference,'102');assert.equal(record.lastTransfer.currency,'MYR');assert.ok(!JSON.stringify(records.body).includes(h.connection.aesKey));}
  const exported=await h.request('owner','/api/admin/export');assert.equal(exported.status,200);assert.equal(exported.body.game_wallet_sessions[0].profile_id,'jdb_myr');assert.equal(exported.body.provider_wallet_operations[0].withdrawal_provider_reference,'102');assert.ok(!('request_fingerprint' in exported.body.provider_wallet_operations[0]));assert.ok(!JSON.stringify(exported.body).includes(h.connection.aesKey));
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.deepEqual(h.sqlite.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{h.close();}
});
test('production configuration never uses QA membership to bypass production acceptance',async()=>{
 const h=fixture();try{h.slot.mode='production';const result=await h.launch();assert.equal(result.status,503);assert.equal(result.body.code,'GAME_ACCEPTANCE_REQUIRED');assert.equal(h.factory.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);}finally{h.close();}
});
test('production JDB uses its own five acceptance capabilities without claiming all games are ready',async()=>{
 const h=fixture();try{
  h.slot.mode='production';h.slot.qaMemberIds=[];await h.acceptJdb();
  const readiness=await getGameProviderAcceptanceReadiness(h.db),jdb=readiness.profiles.find(profile=>profile.profileId==='jdb_myr');
  assert.equal(jdb.evidenceAccepted,true);assert.equal(readiness.allAcceptanceEvidencePassed,false);assert.equal(readiness.acceptedProfileCount,1);
  const catalogue=await h.request('alice','/api/games?provider=jdb&profileId=jdb_myr');assert.equal(catalogue.status,200,JSON.stringify(catalogue));assert.equal(catalogue.body.selectedProfile.launchReady,true);assert.equal(catalogue.body.selectedProfile.launchVerified,true);assert.equal(catalogue.body.selectedProfile.walletVerified,true);assert.equal(catalogue.body.selectedProfile.settlementVerified,true);assert.equal(catalogue.body.games[0].playable,true);assert.equal(catalogue.body.launchProvider,'jdb');assert.equal(catalogue.body.liveReady,true);
  const launched=await h.launch();assert.equal(launched.status,200,JSON.stringify(launched));assert.equal(launched.body.profileId,'jdb_myr');assert.equal(h.factory.calls.filter(call=>call.action===19&&call.amount>0).length,1);
 }finally{h.close();}
});
test('production acceptance cannot fund a game absent from the fresh JDB catalogue',async()=>{
 const h=fixture();try{
  h.slot.mode='production';h.slot.qaMemberIds=[];await h.acceptJdb();
  const result=await h.request('alice','/api/game-launch','POST',{profileId:'jdb_myr',providerId:'jdb',gameCode:'0:999',idempotencyKey:crypto.randomUUID(),language:'en'});
  assert.equal(result.status,409);assert.equal(result.body.code,'GAME_CATALOGUE_UNAVAILABLE');assert.equal(h.factory.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('one accepted provider becomes runtime-ready without requiring every other brand or probing from health',async()=>{
 const h=fixture();try{
  h.slot.mode='production';h.slot.qaMemberIds=[];await h.acceptJdb();
  const before=await h.request(null,'/health');assert.equal(before.body.providerAcceptance.liveProfileCount,0);
  const catalogue=await h.request('alice','/api/games?provider=jdb&profileId=jdb_myr');assert.equal(catalogue.body.games[0].playable,true);
  const calls=h.factory.calls.length,health=await h.request(null,'/health');
  assert.equal(health.body.providerAcceptance.liveProfileCount,1);assert.equal(health.body.liveGames,false);assert.equal(h.factory.calls.length,calls);
  const wallet=await h.request('alice','/api/game-wallet?profileId=jdb_myr');assert.equal(wallet.body.liveReady,true);assert.equal(wallet.body.launchVerified,true);assert.equal(wallet.body.settlementVerified,true);
  h.config.newGameLaunchesEnabled='false';const paused=await h.request(null,'/health');assert.equal(paused.body.providerAcceptance.liveProfileCount,0);assert.equal(h.factory.calls.length,calls);
 }finally{h.close();}
});

test('changing runtime credentials invalidates the observed readiness without an external request',async()=>{
 const h=fixture();try{
  h.slot.mode='production';h.slot.qaMemberIds=[];await h.acceptJdb();await h.request('alice','/api/games?provider=jdb&profileId=jdb_myr');
  const calls=h.factory.calls.length;h.connection.aesKey='newKey12345678901';
  const health=await h.request(null,'/health');assert.equal(health.body.providerAcceptance.liveProfileCount,0);assert.equal(h.factory.calls.length,calls);
 }finally{h.close();}
});

test('the general runtime secret supports the existing account contract and invalid JSON cannot fall back silently',async()=>{
 const h=fixture();try{
  const missing=await h.request('alice','/api/game-launch','POST',{profileId:'jdb_myr',providerId:'jdb',gameCode:'0:100',idempotencyKey:'bad-general-config'},{gameTransferProfilesJson:'{invalid'});
  assert.equal(missing.status,503);assert.equal(h.factory.calls.length,0);
  const valid=await h.request('alice','/api/game-launch','POST',{profileId:'jdb_myr',providerId:'jdb',gameCode:'0:100',idempotencyKey:'valid-general-config'},{jdbTransferProfilesJson:'',gameTransferProfilesJson:JSON.stringify(h.document)});
  assert.equal(valid.status,200,JSON.stringify(valid));assert.equal(valid.body.profileId,'jdb_myr');assert.equal(h.factory.calls.filter(p=>p.action===19&&p.amount>0).length,1);
 }finally{h.close();}
});

test('runtime seeding never overwrites a conflicting account ratio to make a launch pass',async()=>{
 const h=fixture();try{
  h.sqlite.exec("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES('jdb_myr','jdb','Conflicting account','jdb','transfer','cash','MYR',100,1,'production','uat',0,0)");
  const result=await h.launch();assert.equal(result.status,409);assert.equal(result.body.code,'GAME_PROFILE_RECONCILIATION_REQUIRED');
  assert.equal(h.sqlite.prepare('SELECT unit_numerator FROM game_provider_profiles WHERE id=?').get('jdb_myr').unit_numerator,100);
  assert.equal(h.factory.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});
test('unapproved API hosts, missing closure evidence and other members cannot submit money',async()=>{
 for(const change of [h=>h.slot.approvedApiOrigins=[],h=>h.slot.sessionClosureVerified=false,h=>h.slot.qaMemberIds=['bob']]){const h=fixture();try{change(h);const result=await h.launch();assert.equal(result.status,503);assert.equal(h.factory.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);}finally{h.close();}}
});
test('new-game maintenance blocks money before calls while a timed-out deposit remains recoverable',async()=>{
 const h=fixture();try{h.factory.timeoutDeposit=true;const start=await h.launch();assert.equal(start.status,503);const s=h.sqlite.prepare('SELECT * FROM game_wallet_sessions').get();assert.equal(s.status,'deposit_unknown');h.config.newGameLaunchesEnabled='false';const blocked=await h.launch();assert.equal(blocked.status,503);assert.equal(blocked.body.code,'GAMES_MAINTENANCE');const result=await h.request('alice','/api/game-wallet/recover','POST',{profileId:'jdb_myr',sessionId:s.id});assert.equal(result.status,200,JSON.stringify(result));assert.equal(result.body.status,'active');assert.equal(h.factory.calls.filter(p=>p.action===19&&p.amount>0).length,1);const returned=await h.request('alice','/api/game-wallet/settle','POST',{profileId:'jdb_myr',sessionId:s.id});assert.equal(returned.status,200,JSON.stringify(returned));assert.equal(returned.body.session.resultMinor,'0');}finally{h.close();}
});
test('member/profile isolation and missing credentials retain visible recovery records',async()=>{
 const h=fixture();try{const start=await h.launch(),id=start.body.walletSessionId;const bob=await h.request('bob','/api/game-wallet/recover','POST',{profileId:'jdb_myr',sessionId:id});assert.equal(bob.status,404);const read=await h.request('alice','/api/game-wallet?profileId=jdb_myr','GET',null,{jdbTransferProfilesJson:''});assert.equal(read.status,200);assert.equal(read.body.session.id,id);assert.equal(read.body.wallet.availableMinor,'0');assert.equal(read.body.supportsRecovery,false);const settled=await h.request('alice','/api/game-wallet/settle','POST',{profileId:'jdb_myr',sessionId:id},{jdbTransferProfilesJson:''});assert.equal(settled.status,503);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);}finally{h.close();}
});
test('runtime snapshots require a registered profile and accepted account origin, with per-profile players',()=>{
 const h=fixture();try{const raw=JSON.stringify(h.document);assert.ok(jdbProfileRuntime(raw,'jdb_myr','alice'));assert.equal(jdbProfileRuntime(raw,'jdb_myr','bob').launchAuthorized,false);assert.equal(jdbProfileRuntime(raw,'spribe_myr','alice'),null);assert.equal(jdbProfileRuntime(raw,'unregistered','alice'),null);h.connection.baseUrl+='/';assert.ok(jdbProfileRuntime(JSON.stringify(h.document),'jdb_myr','alice'));h.connection.baseUrl='https://provider.example.test/api';assert.equal(jdbProfileRuntime(JSON.stringify(h.document),'jdb_myr','alice'),null);h.connection.baseUrl='https://provider.example.test';h.slot.approvedApiOrigins=['https://other.example.test'];assert.equal(jdbProfileRuntime(JSON.stringify(h.document),'jdb_myr','alice'),null);assert.notEqual(jdbPlayerId('jdb_myr','alice'),jdbPlayerId('spribe_myr','alice'));}finally{h.close();}
});
