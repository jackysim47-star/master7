import { test } from 'node:test';
import assert from 'node:assert/strict';
import { manualBankPost } from '../lib/manual-bank.ts';

class Statement {
  constructor(sql,args=[]){this.sql=sql;this.args=args;}
  bind(...args){return new Statement(this.sql,args);}
  async first(){
    if(this.sql.includes("SELECT * FROM deposit_orders"))return {id:'order-claim-lost',user_id:'member-claim-lost',provider:'manual_bank',status:'pending',amount_minor:2000,currency:'MYR'};
    return null;
  }
}

for(const action of ['approve','reject'])test(`manual-bank ${action} reports a lost concurrent review claim`,async()=>{
  let batch;
  const db={
    prepare:sql=>new Statement(sql),
    async batch(statements){batch=statements;return statements.map(()=>({meta:{changes:0}}));}
  };
  const response=await manualBankPost('/api/admin/manual-bank/review',{id:'order-claim-lost',action},{db,user:{id:'staff-two',username:'staff2@example.test',role:'staff',approved:1}});
  assert.equal(response.status,409);
  assert.deepEqual(await response.json(),{error:'Deposit already reviewed or changed'});
  assert.match(batch[0].sql,/INSERT INTO member_wallet_guards/);
  assert.match(batch[1].sql,/UPDATE member_wallet_guards/);
  assert.match(batch[3].sql,/reviewed_by IS NULL/);
});
