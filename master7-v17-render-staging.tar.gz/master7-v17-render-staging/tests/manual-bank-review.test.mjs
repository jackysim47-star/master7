import { test } from 'node:test';
import assert from 'node:assert/strict';
import { manualBankPost } from '../lib/manual-bank.ts';

class Statement {
  constructor(sql,args=[]){this.sql=sql;this.args=args;}
  bind(...args){return new Statement(this.sql,args);}
  async first(){
    if(this.sql.includes("SELECT d.*,m.bank_account_id"))return {id:'order-claim-lost',user_id:'member-claim-lost',provider:'manual_bank',status:'pending',amount_minor:2000,currency:'MYR',bank_account_id:'bank',account_number:'1234567890'};
    return null;
  }
}

for(const action of ['approve','reject'])test(`manual-bank ${action} reports a lost concurrent review claim`,async()=>{
  let batch;
  const db={
    prepare:sql=>new Statement(sql),
    async batch(statements){batch=statements;return statements.map(()=>({meta:{changes:0}}));}
  };
  const response=await manualBankPost('/api/admin/manual-bank/review',{id:'order-claim-lost',action,bankReference:'BANK-REF-0001',bankAccountId:'bank',bankAmount:'20.00',currency:'MYR',bankConfirmed:true,bankOccurredAt:1700000000,proofData:'data:image/png;base64,'+Buffer.from([137,80,78,71,13,10,26,10,...new Array(20).fill(0)]).toString('base64')},{db,user:{id:'staff-two',username:'staff2@example.test',role:'staff',approved:1}});
  assert.equal(response.status,409);
  assert.deepEqual(await response.json(),{error:'Deposit already reviewed or changed'});
  assert.match(batch[0].sql,/INSERT INTO member_wallet_guards/);
  assert.match(batch[1].sql,/UPDATE member_wallet_guards/);
  assert.match(batch[3].sql,/reviewed_by IS NULL/);
});
