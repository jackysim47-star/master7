import assert from 'node:assert/strict';
import test from 'node:test';
import {
  EPICWIN_PROFILE_IDS,
  getEpicwinContractRequirements,
  inspectEpicwinContractManifest,
} from '../lib/epicwin-contract-readiness.ts';

const profileValues={
  epicwin_normal_myr:{account:'normal',balanceClass:'cash'},
  epicwin_free_myr:{account:'free',balanceClass:'free_credit'},
};

function setPath(target,path,value){
 const parts=path.split('.');let current=target;
 for(const part of parts.slice(0,-1))current=current[part]??={};
 current[parts.at(-1)]=value;
}

function completeManifest(profileId){
 const manifest={},profile=profileValues[profileId];
 for(const requirement of getEpicwinContractRequirements(profileId)){
  let value=requirement.expected?.[0]??'documented-value';
  if(requirement.kind==='string_list')value=['documented-field'];
  if(requirement.kind==='nonnegative_integer')value=1;
  if(requirement.kind==='sha256')value='a'.repeat(64);
  if(requirement.kind==='ratio')value='1:1';
  if(requirement.field==='profile.profile_id')value=profileId;
  if(requirement.field==='profile.account_variant')value=profile.account;
  if(requirement.field==='profile.provider_currency'||requirement.field==='profile.settlement_currency')value='MYR';
  if(requirement.field==='profile.balance_class')value=profile.balanceClass;
  setPath(manifest,requirement.field,value);
 }
 return manifest;
}

test('both EPICWIN profiles expose independent exact runtime contract gaps and remain fail closed',()=>{
 assert.deepEqual(EPICWIN_PROFILE_IDS,['epicwin_normal_myr','epicwin_free_myr']);
 for(const profileId of EPICWIN_PROFILE_IDS){
  const diagnostic=inspectEpicwinContractManifest(profileId);
  assert.equal(diagnostic.knownProfile,true);
  assert.equal(diagnostic.manifestComplete,false);
  assert.deepEqual(diagnostic.missingVendorFields,getEpicwinContractRequirements(profileId).map(item=>item.field));
  assert.equal(diagnostic.documentationOnly,true);
  assert.equal(diagnostic.adapterImplemented,false);
  assert.equal(diagnostic.catalogueAllowed,false);
  assert.equal(diagnostic.launchAllowed,false);
  assert.equal(diagnostic.walletAllowed,false);
  assert.equal(diagnostic.settlementAllowed,false);
  assert.equal(diagnostic.recoveryAllowed,false);
  assert.equal(diagnostic.playAllowed,false);
 }
 assert.equal(inspectEpicwinContractManifest('epicwin_normal_myr').missingVendorFields.includes('profile.free_credit_settlement_rule'),false);
 assert.ok(inspectEpicwinContractManifest('epicwin_free_myr').missingVendorFields.includes('profile.free_credit_settlement_rule'));
});

test('a WAF response, catalogue credential or game row cannot satisfy EPICWIN runtime requirements',()=>{
 const diagnostic=inspectEpicwinContractManifest('epicwin_normal_myr',{
  httpStatus:403,userAgent:'configured',apiToken:'must-never-be-reflected',games:[{gameCode:'fixture'}],
 });
 assert.equal(diagnostic.manifestComplete,false);
 assert.equal(diagnostic.missingVendorFields.length,getEpicwinContractRequirements('epicwin_normal_myr').length);
 assert.equal(JSON.stringify(diagnostic).includes('must-never-be-reflected'),false);
 assert.equal(diagnostic.playAllowed,false);
});

test('syntactically complete EPICWIN documents remain documentation-only until an adapter and UAT exist',()=>{
 for(const profileId of EPICWIN_PROFILE_IDS){
  const diagnostic=inspectEpicwinContractManifest(profileId,completeManifest(profileId));
  assert.equal(diagnostic.manifestComplete,true,profileId);
  assert.deepEqual(diagnostic.missingVendorFields,[]);
  assert.deepEqual(diagnostic.invalidVendorFields,[]);
  assert.equal(diagnostic.adapterImplemented,false);
  assert.equal(diagnostic.playAllowed,false);
 }
});

test('normal profile evidence cannot be inherited by the free-credit profile',()=>{
 const diagnostic=inspectEpicwinContractManifest('epicwin_free_myr',completeManifest('epicwin_normal_myr'));
 assert.equal(diagnostic.manifestComplete,false);
 assert.ok(diagnostic.invalidVendorFields.some(item=>item.field==='profile.profile_id'&&item.reason==='unexpected_value'));
 assert.ok(diagnostic.invalidVendorFields.some(item=>item.field==='profile.account_variant'&&item.reason==='unexpected_value'));
 assert.ok(diagnostic.invalidVendorFields.some(item=>item.field==='profile.balance_class'&&item.reason==='unexpected_value'));
 assert.ok(diagnostic.missingVendorFields.includes('profile.free_credit_source'));
});

test('unknown profiles never inherit EPICWIN contract scope or capabilities',()=>{
 const diagnostic=inspectEpicwinContractManifest('epicwin_unknown',completeManifest('epicwin_normal_myr'));
 assert.equal(diagnostic.knownProfile,false);
 assert.equal(diagnostic.manifestComplete,false);
 assert.deepEqual(diagnostic.missingVendorFields,[]);
 assert.equal(diagnostic.playAllowed,false);
});
