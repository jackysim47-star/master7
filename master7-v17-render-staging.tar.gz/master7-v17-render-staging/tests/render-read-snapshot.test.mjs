import test from 'node:test';
import assert from 'node:assert/strict';
import {constants,createDecipheriv,createHash,createPublicKey,generateKeyPairSync,privateDecrypt} from 'node:crypto';
import {mkdtempSync,readFileSync,readdirSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {DatabaseSync} from 'node:sqlite';
import {gunzipSync} from 'node:zlib';
import {BACKUP_PAGE_SIZE,createEncryptedPortalBackup} from '../lib/encrypted-backup.ts';
import {withPostgresReadSnapshot} from '../lib/render-read-snapshot.ts';

const begin='BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY';

function keys(){const key=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});return {...key,publicKeySha256:createHash('sha256').update(createPublicKey(key.publicKey).export({type:'spki',format:'der'})).digest('hex')};}

function decrypt(envelope,key){
 const contentKey=privateDecrypt({key,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64'));
 const cipher=createDecipheriv('aes-256-gcm',contentKey,Buffer.from(envelope.iv,'base64'));cipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));
 return JSON.parse(gunzipSync(Buffer.concat([cipher.update(Buffer.from(envelope.ciphertext,'base64')),cipher.final()])).toString('utf8'));
}

function mockPool({failBegin=false,failRead=false,failRollback=false,failRelease=false,row}={}){
 const events=[],client={
  async query(sql,values=[]){
   events.push({sql,values});
   if(sql===begin&&failBegin)throw new Error('synthetic begin failure');
   if(sql==='ROLLBACK'&&failRollback)throw new Error('synthetic rollback failure');
   if(sql.startsWith('SELECT')&&failRead)throw new Error('synthetic read failure');
   return {rows:sql.startsWith('SELECT * FROM settings')&&row?[row]:[],rowCount:0};
  },
  release(destroy){events.push({release:destroy});if(failRelease)throw new Error('synthetic release failure');},
 };
 return {events,pool:{connect:async()=>{events.push({connect:true});return client;},query:async()=>{throw new Error('The shared pool must not execute snapshot queries');}}};
}

const source=pool=>({prepare(){throw new Error('Snapshot must not fall back to ordinary reads');},withReadSnapshot:read=>withPostgresReadSnapshot(pool,read)});

test('read snapshot uses one acquired client and expires its statements before releasing',async()=>{
 const {pool,events}=mockPool();let escaped;
 const result=await withPostgresReadSnapshot(pool,async db=>{
  assert.equal(db.batch,undefined);
  escaped=db.prepare('SELECT * FROM users ORDER BY id LIMIT ? OFFSET ?').bind(1000,0);
  assert.equal(escaped.run,undefined);
  await escaped.all();
  await db.prepare('SELECT * FROM settings ORDER BY id LIMIT ? OFFSET ?').bind(1000,0).all();
  return {complete:true};
 });
 assert.deepEqual(result,{complete:true});
 assert.deepEqual(events,[{connect:true},{sql:begin,values:[]},{sql:'SELECT * FROM users ORDER BY id LIMIT $1 OFFSET $2',values:[1000,0]},{sql:'SELECT * FROM settings ORDER BY id LIMIT $1 OFFSET $2',values:[1000,0]},{sql:'ROLLBACK',values:[]},{release:false}]);
 await assert.rejects(()=>escaped.all(),/snapshot is closed/);
 assert.equal(events.length,6,'An escaped statement must not reuse a released connection');
});

test('read and begin failures roll back, discard the client, and never fall back',async()=>{
 for(const failure of ['failBegin','failRead']){
  const {pool,events}=mockPool({[failure]:true});let accessedCrypto=false;
  const cryptoConfig={get publicKey(){accessedCrypto=true;throw new Error('Encryption must not run');}};
  await assert.rejects(()=>createEncryptedPortalBackup(source(pool),'synthetic-release',cryptoConfig),new RegExp(failure==='failBegin'?'synthetic begin failure':'synthetic read failure'));
  assert.deepEqual(events.slice(-2),[{sql:'ROLLBACK',values:[]},{release:true}]);
  assert.equal(accessedCrypto,false);
 }
});

test('rollback and release failures prevent any successful backup envelope',async()=>{
 for(const failure of ['failRollback','failRelease']){
  const {pool,events}=mockPool({[failure]:true});let accessedCrypto=false;
  const cryptoConfig={get publicKey(){accessedCrypto=true;throw new Error('Encryption must not run');}};
  await assert.rejects(()=>createEncryptedPortalBackup(source(pool),'synthetic-release',cryptoConfig),new RegExp(failure==='failRollback'?'synthetic rollback failure':'synthetic release failure'));
  assert.deepEqual(events.slice(-2),[{sql:'ROLLBACK',values:[]},{release:failure==='failRollback'}]);
  assert.equal(accessedCrypto,false);
 }
});

test('multiple failures preserve the read and cleanup errors and still attempt release',async()=>{
 const {pool,events}=mockPool({failRead:true,failRollback:true,failRelease:true});
 await assert.rejects(()=>withPostgresReadSnapshot(pool,db=>db.prepare('SELECT * FROM users ORDER BY id LIMIT ? OFFSET ?').bind(1000,0).all()),error=>{
  assert.ok(error instanceof AggregateError);
  assert.deepEqual(error.errors.map(item=>item.message),['synthetic read failure','synthetic rollback failure','synthetic release failure']);
  return true;
 });
 assert.deepEqual(events.at(-1),{release:true});
});

test('serialization and encryption start only after snapshot rollback and release',async()=>{
 let events;
 const row={toJSON(){assert.deepEqual(events.at(-1),{release:false});return {id:'synthetic-setting',value:'local only'};}};
 const fake=mockPool({row});events=fake.events;
 const cryptoConfig={get publicKey(){assert.deepEqual(events.at(-1),{release:false});return 'deliberately invalid synthetic public key';}};
 await assert.rejects(()=>createEncryptedPortalBackup(source(fake.pool),'synthetic-release',cryptoConfig));
 assert.deepEqual(events.slice(-2),[{sql:'ROLLBACK',values:[]},{release:false}]);
});

function concurrentFixture(t){
 const directory=mkdtempSync(join(tmpdir(),'master7-snapshot-')),path=join(directory,'synthetic.sqlite');
 const writer=new DatabaseSync(path);writer.exec('PRAGMA journal_mode=WAL');
 const migrations=new URL('../drizzle/',import.meta.url);
 for(const name of readdirSync(migrations).filter(name=>/^\d{4}_.+\.sql$/.test(name)).sort())writer.exec(readFileSync(new URL(name,migrations),'utf8'));
 const count=BACKUP_PAGE_SIZE*2+5;
 writer.exec('BEGIN');
 const insert=writer.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,'member',1,'synthetic',1)");
 for(let i=0;i<count;i++)insert.run(`snapshot-user-${String(i).padStart(5,'0')}`,`synthetic_before_${i}`);
 writer.exec("INSERT INTO settings(id,value) VALUES('snapshot_generation','before'); COMMIT");
 const reader=new DatabaseSync(path);reader.exec('PRAGMA query_only=ON');
 let closed=false;
 t.after(()=>{if(!closed)reader.close();writer.close();rmSync(directory,{recursive:true,force:true});});
 return {writer,reader,count,close(){reader.close();closed=true;}};
}

test('all pages and tables keep one real SQLite snapshot while another connection commits',async t=>{
 const fixture=concurrentFixture(t),events=[];let changed=false;
 const client={
  async query(sql,values=[]){
   events.push(sql);
   if(sql===begin){fixture.reader.exec('BEGIN');return {rows:[]};}
   if(sql==='ROLLBACK'){fixture.reader.exec(sql);return {rows:[]};}
   const rows=fixture.reader.prepare(sql.replace(/\$\d+/g,'?')).all(...values);
   if(!changed&&sql.startsWith('SELECT * FROM users')){
    changed=true;
    fixture.writer.exec(`BEGIN;
     DELETE FROM users WHERE id='snapshot-user-00000';
     UPDATE users SET username='synthetic_after_update' WHERE id='snapshot-user-01000';
     INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('snapshot-user-new','synthetic_after_insert','member',1,'synthetic',2);
     UPDATE settings SET value='after' WHERE id='snapshot_generation';
     COMMIT`);
   }
   return {rows};
  },
  release(destroy){assert.equal(destroy,false);events.push('release');fixture.close();},
 };
 const pool={connect:async()=>client,query:async()=>{throw new Error('Shared-pool read attempted');}},key=keys();
 const {envelope,metadata}=await createEncryptedPortalBackup(source(pool),'synthetic-concurrent-release',key),payload=decrypt(envelope,key.privateKey);
 assert.equal(changed,true);
 assert.equal(envelope.readConsistency,'transaction_snapshot');
 assert.equal(metadata.readConsistency,'transaction_snapshot');
 assert.equal(payload.readConsistency,'transaction_snapshot');
 assert.equal(payload.tables.users.length,fixture.count);
 assert.deepEqual(payload.tables.users.map(row=>row.id),Array.from({length:fixture.count},(_,i)=>`snapshot-user-${String(i).padStart(5,'0')}`));
 assert.equal(payload.tables.users[1000].username,'synthetic_before_1000');
 assert.equal(payload.tables.settings.find(row=>row.id==='snapshot_generation').value,'before');
 assert.equal(fixture.writer.prepare("SELECT value FROM settings WHERE id='snapshot_generation'").get().value,'after');
 assert.equal(fixture.writer.prepare("SELECT username FROM users WHERE id='snapshot-user-01000'").get().username,'synthetic_after_update');
 assert.deepEqual(events.slice(-2),['ROLLBACK','release']);
 assert.equal(events.filter(sql=>sql===begin).length,1);
});

test('the scoped database rejects writes and transaction escape statements before executing them',async t=>{
 const fixture=concurrentFixture(t),events=[];
 const client={
  async query(sql,values=[]){
   events.push(sql);
   if(sql===begin){fixture.reader.exec('BEGIN');return {rows:[]};}
   if(sql==='ROLLBACK'){fixture.reader.exec(sql);return {rows:[]};}
   return {rows:fixture.reader.prepare(sql.replace(/\$\d+/g,'?')).all(...values)};
  },
  release(destroy){assert.equal(destroy,true);events.push('release');fixture.close();},
 };
 await assert.rejects(()=>withPostgresReadSnapshot({connect:async()=>client},async db=>{
  for(const sql of ["UPDATE settings SET value=? WHERE id='snapshot_generation' RETURNING value",'COMMIT','SELECT * FROM settings ORDER BY id LIMIT ? OFFSET ?; COMMIT']){
   assert.throws(()=>db.prepare(sql),/only accepts a single backup page SELECT/);
  }
  throw new Error('synthetic rejected-write test complete');
 }),/synthetic rejected-write test complete/);
 assert.equal(fixture.writer.prepare("SELECT value FROM settings WHERE id='snapshot_generation'").get().value,'before');
 assert.deepEqual(events.slice(-2),['ROLLBACK','release']);
 assert.deepEqual(events,[begin,'ROLLBACK','release']);
});
