import test from 'node:test';
import assert from 'node:assert/strict';
import {createDecipheriv} from 'node:crypto';
import {createJdbGameProviderAdapter} from '../lib/jdb-provider-adapter.ts';
import {jdbPlayerId,jdbSerialNo} from '../lib/jdb-transfer-protocol.ts';
import {GAME_PROVIDER_ADAPTER_METHODS} from '../lib/game-provider-adapter.ts';
import {getGameProviderProfile,resolveGameProviderAdapter} from '../lib/game-provider-registry.ts';

const now=Date.UTC(2026,10,8,12,0,0),userId='member-one';
const baseConfig={profile:'jdb_myr',baseUrl:'https://provider.example.test',dc:'fixture',parent:'agent01',aesKey:'key1234567Sample',aesIv:'iv12345678Sample',padding:'space',launchOrigins:['https://games.example.test'],reportUtcOffsetMinutes:480};
const user=(profile='jdb_myr')=>jdbPlayerId(profile,userId);
const context=(profile='jdb_myr')=>({profile:getGameProviderProfile(profile)});
const input=(profile='jdb_myr')=>({userId,providerPlayerId:user(profile),platformTransactionId:'transfer-one',amountMinor:'1234',currency:'MYR'});
const row=(profile='jdb_myr',changes={})=>({uid:user(profile),parent:'agent01',currency:'RM',lvl:0,locked:0,closed:0,balance:'0.00',...changes});
const wager=(changes={})=>({historyId:'bet-one',playerId:user(),gType:0,mtype:100,gameDate:'08-11-2026 19:50:00',lastModifyTime:'08-11-2026 19:51:00',bet:'-1.00',win:'2.00',total:'1.00',currency:'RM',...changes});
const window={from:now-10*60_000,to:now-9*60_000};
const ok=value=>Response.json({status:'0000',...value});

function fixture(handler,flags={},changes={}){
 const cfg={...baseConfig,...changes,launchOrigins:[...(changes.launchOrigins??baseConfig.launchOrigins)]},calls=[];
 const fetchImpl=async(url,init)=>{
  const envelope=JSON.parse(init.body),cipher=createDecipheriv('aes-128-cbc',Buffer.from(baseConfig.aesKey),Buffer.from(baseConfig.aesIv));cipher.setAutoPadding(false);
  const payload=JSON.parse(Buffer.concat([cipher.update(Buffer.from(envelope.x,'base64url')),cipher.final()]).toString('utf8').replace(/[\0 ]+$/,''));
  calls.push({url,init,envelope,payload});
  return handler(payload,calls.length);
 };
 const options={fetchImpl,now:()=>now,allowedReturnOrigins:['https://www.master7.best'],...flags};
 return {adapter:createJdbGameProviderAdapter(cfg,options),calls,cfg,options};
}

test('adapter construction does not enable launch or claim production verification',()=>{
 const f=fixture(()=>ok({data:[]}));assert.equal(Object.isFrozen(f.adapter),true);assert.equal(f.adapter.key,'jdb');
 for(const method of GAME_PROVIDER_ADAPTER_METHODS)assert.equal(typeof f.adapter[method],'function');
 assert.equal(getGameProviderProfile('jdb_myr').implemented,true);assert.equal(getGameProviderProfile('spribe_myr').implemented,false);
 assert.equal(resolveGameProviderAdapter('jdb_myr',{jdb:f.adapter}).executable,true);assert.equal(f.calls.length,0);assert.equal(getGameProviderProfile('jdb_myr').enabled,false);assert.equal(getGameProviderProfile('jdb_myr').launchVerified,false);
});
test('catalogue is read-only and retains IDs and unknown maintenance without using context transport overrides',async()=>{
 const f=fixture(()=>ok({data:[{gType:0,list:[{mType:100,name:'Game',maintenance:false},{mType:101,name:'Unconfirmed'}]}]}));
 let overrides=0;const result=await f.adapter.listGames({...context(),fetchImpl:async()=>{overrides++;throw new Error('must not use');}});
 assert.deepEqual(result,[{providerGameId:'0:100',name:'Game',maintenance:false,category:'unknown'},{providerGameId:'0:101',name:'Unconfirmed',maintenance:true,category:'unknown'}]);
 assert.equal(overrides,0);assert.equal(f.calls[0].payload.action,49);assert.equal(f.calls[0].init.redirect,'error');
});
test('foreign profiles, currencies, scales and ledger namespaces fail before any provider request',async()=>{
 const f=fixture(()=>ok({})),original=context().profile;
 for(const patch of [{profileId:'spribe_myr'},{providerId:'spribe'},{currency:'USDT'},{unitScale:100},{walletMode:'seamless'},{adapterKey:'other'},{playerNamespace:'spribe_myr'},{ledgerNamespace:'spribe_myr'}])await assert.rejects(f.adapter.listGames({profile:{...original,...patch}}),/JDB_PROFILE_MISMATCH/);
 assert.equal(f.calls.length,0);
});
test('new transfer and launch submissions default closed without provider calls',async()=>{
 const f=fixture(()=>ok({}));
 await assert.rejects(f.adapter.depositToGame(context(),input()),/SUBMISSION_DISABLED/);await assert.rejects(f.adapter.withdrawFromGame(context(),input()),/SUBMISSION_DISABLED/);
 await assert.rejects(f.adapter.launchGame(context(),{...input(),providerGameId:'0:100',language:'en',returnUrl:'https://www.master7.best/'}),/LAUNCH_DISABLED/);assert.equal(f.calls.length,0);
});
test('player verification remains available with creation disabled and never sends member names',async()=>{
 const f=fixture(()=>ok({data:[row()]}));
 assert.deepEqual(await f.adapter.createOrVerifyPlayer(context(),{userId,username:'private name'}),{providerPlayerId:user(),created:false});
 assert.deepEqual(f.calls.map(x=>x.payload.action),[15]);assert.ok(!JSON.stringify(f.calls).includes('private name'));
});
test('player creation, existing accounts and timeout each require independent identity and currency verification',async()=>{
 for(const state of ['created','exists','timeout']){
  const f=fixture(payload=>{if(payload.action===15)return ok({data:[row()]});if(state==='timeout')throw new Error('private provider message');return state==='exists'?Response.json({status:'7602'}):ok({});},{playerCreationEnabled:true});
  const result=await f.adapter.createOrVerifyPlayer(context(),{userId,username:'Member'});assert.equal(result.created,state==='created');assert.deepEqual(f.calls.map(x=>x.payload.action),[12,15]);assert.equal(f.calls[0].payload.credit_allocated,0);
 }
 const bad=fixture(p=>p.action===12?ok({}):ok({data:[row('jdb_myr',{parent:'another'})]}),{playerCreationEnabled:true});await assert.rejects(bad.adapter.createOrVerifyPlayer(context(),{userId,username:'Member'}),/player_identity_mismatch/);
});
test('JDB and SPRIBE factory instances cannot exchange profiles or players',async()=>{
 const jdb=fixture(()=>ok({data:[row()]})),spribe=fixture(()=>ok({data:[row('spribe_myr')]}),{},{profile:'spribe_myr'});
 assert.notEqual(user(),user('spribe_myr'));assert.equal(context('spribe_myr').profile.walletMode,'transfer');
 await assert.rejects(jdb.adapter.queryBalance(context('spribe_myr'),input('spribe_myr')),/PROFILE_MISMATCH/);
 await assert.rejects(spribe.adapter.queryBalance(context('spribe_myr'),input()),/PLAYER_MISMATCH/);assert.equal(jdb.calls.length,0);assert.equal(spribe.calls.length,0);
 assert.equal((await spribe.adapter.queryBalance(context('spribe_myr'),input('spribe_myr'))).currency,'MYR');
});
test('a deposit verifies the player currency before sending one stable serial and never implies a wallet posting',async()=>{
 const serial=jdbSerialNo('jdb_myr','transfer-one','deposit'),f=fixture(p=>p.action===15?ok({data:[row()]}):ok({serialNo:serial,amount:12.34,pid:123}),{depositEnabled:true});
 assert.deepEqual(await f.adapter.depositToGame(context(),input()),{state:'confirmed',providerTransactionId:'123',requiresLedgerReconciliation:true});
 assert.deepEqual(f.calls.map(x=>x.payload.action),[15,19]);assert.equal(f.calls[1].payload.serialNo,serial);assert.equal(f.calls[1].payload.amount,12.34);
});
test('withdrawal can settle an existing locked player while new deposits, creation and launch are paused',async()=>{
 const serial=jdbSerialNo('jdb_myr','transfer-one','withdraw'),f=fixture(p=>p.action===15?ok({data:[row('jdb_myr',{locked:1,balance:12.34})]}):ok({serialNo:serial,amount:-12.34,pid:124}),{withdrawalEnabled:true});
 assert.equal((await f.adapter.withdrawFromGame(context(),input())).state,'confirmed');assert.equal(f.calls[1].payload.amount,-12.34);assert.equal(f.calls[1].payload.serialNo,serial);
 await assert.rejects(f.adapter.depositToGame(context(),input()),/SUBMISSION_DISABLED/);assert.equal(f.calls.length,2);
});
test('unknown, duplicate and in-progress transfer results are not retried or converted to successful credit',async()=>{
 for(const status of ['timeout','6005','6012']){
  const f=fixture(p=>{if(p.action===15)return ok({data:[row()]});if(status==='timeout')throw new Error('secret upstream');return Response.json({status,err_text:'secret upstream'});},{depositEnabled:true});
  const result=await f.adapter.depositToGame(context(),input());assert.equal(result.state,'unknown');assert.equal(result.requiresLedgerReconciliation,true);assert.deepEqual(f.calls.map(x=>x.payload.action),[15,19]);assert.ok(!JSON.stringify(result).includes('secret upstream'));
 }
});
test('invalid transfer inputs and cross-member player bindings are rejected before requests',async()=>{
 const f=fixture(()=>ok({}),{depositEnabled:true});
 for(const patch of [{providerPlayerId:user('spribe_myr')},{userId:'other'},{currency:'MY1'},{amountMinor:'0'},{amountMinor:'1.00'},{amountMinor:'100000000000'},{platformTransactionId:'invalid\norder'}])await assert.rejects(f.adapter.depositToGame(context(),{...input(),...patch}));assert.equal(f.calls.length,0);
});
test('sub-cent balances are retained for review and prevent new money submissions',async()=>{
 const f=fixture(()=>ok({data:[row('jdb_myr',{balance:'12.345'})]}),{depositEnabled:true,withdrawalEnabled:true});
 assert.deepEqual(await f.adapter.queryBalance(context(),input()),{amountMinor:'1234',currency:'MYR',residual:true,providerAmount:'12.345'});
 assert.equal((await f.adapter.depositToGame(context(),input())).state,'unknown');assert.equal((await f.adapter.withdrawFromGame(context(),input())).state,'unknown');assert.ok(f.calls.every(x=>x.payload.action===15));
});
test('foreign-currency or parent mismatches never reach the transfer or recovery operation',async()=>{
 for(const patch of [{currency:'RMC'},{parent:'other'}]){
  const f=fixture(()=>ok({data:[row('jdb_myr',patch)]}),{depositEnabled:true});assert.equal((await f.adapter.depositToGame(context(),input())).state,'unknown');assert.equal((await f.adapter.queryTransfer(context(),{...input(),direction:'deposit'})).state,'unknown');assert.ok(f.calls.every(x=>x.payload.action===15));
 }
});
test('query-only recovery reuses the stable serial and checks provider reference without enabling transfers',async()=>{
 const f=fixture(p=>p.action===15?ok({data:[row()]}):ok({data:[{uid:user(),action:'deposit',amount:12.34,pid:123}]}));
 const result=await f.adapter.queryTransfer(context(),{...input(),direction:'deposit',providerTransactionId:'123'});assert.equal(result.state,'confirmed');assert.equal(result.requiresLedgerReconciliation,true);
 assert.deepEqual(f.calls.map(x=>x.payload.action),[15,55]);assert.equal(f.calls[1].payload.serialNo,jdbSerialNo('jdb_myr','transfer-one','deposit'));
 assert.equal((await f.adapter.queryTransfer(context(),{...input(),direction:'deposit',providerTransactionId:'999'})).errorCode,'JDB_TRANSFER_REFERENCE_MISMATCH');
});
test('recovery rejects ambiguous directions and non-string references before querying',async()=>{
 const f=fixture(()=>ok({}));for(const patch of [{direction:'refund'},{direction:'deposit',providerTransactionId:123},{direction:'deposit',providerTransactionId:'bad'}])await assert.rejects(f.adapter.queryTransfer(context(),{...input(),...patch}),/INPUT_INVALID/);assert.equal(f.calls.length,0);
});
test('launch requires a verified active player and exact approved return origin',async()=>{
 const f=fixture(p=>p.action===15?ok({data:[row()]}):ok({path:'https://games.example.test/play?ticket=private'}),{launchEnabled:true});
 const launch={...input(),providerGameId:'0:100',language:'zh',ip:'127.0.0.1',returnUrl:'https://www.master7.best/'};
 for(const returnUrl of ['http://www.master7.best/','https://www.master7.best.attacker.test/','https://owner:secret@www.master7.best/','https://www.master7.site/'])await assert.rejects(f.adapter.launchGame(context(),{...launch,returnUrl}),/RETURN_URL_INVALID/);assert.equal(f.calls.length,0);
 assert.equal((await f.adapter.launchGame(context(),launch)).launchUrl,'https://games.example.test/play?ticket=private');assert.deepEqual(f.calls.map(x=>x.payload.action),[15,11]);assert.equal(f.calls[1].payload.lang,'cn');
 const locked=fixture(()=>ok({data:[row('jdb_myr',{locked:1})]}),{launchEnabled:true});await assert.rejects(locked.adapter.launchGame(context(),launch),/PLAYER_UNAVAILABLE/);assert.equal(locked.calls.length,1);
});
test('report projection preserves provider IDs, raw decimals, absent rounds and explicit time units',async()=>{
 const f=fixture(()=>ok({data:[wager({tax:'0.000001',jackpotContribute:'-0.002'})]}));const page=await f.adapter.fetchWagers(context(),window);
 assert.equal(page.complete,false);assert.equal(page.nextCursor,undefined);assert.equal(page.items.length,1);
 const r=page.items[0];assert.equal(r.providerRoundId,null);assert.equal(r.providerBetId,'bet-one');assert.equal(r.providerPlayerId,user());assert.equal(r.providerGameId,'0:100');assert.equal(r.betMinor,'100');assert.equal(r.winMinor,'200');assert.equal(r.settledAt,now-9*60_000);assert.equal(r.sourceDetails.bet,'-1.00');assert.equal(r.sourceDetails.tax,'0.000001');assert.equal(r.sourceDetails.jackpotContribute,'-0.002');assert.equal(r.sourceDetails.timeBasis,'lastModifyTime');
});
test('arcade gambling stakes are preserved and included separately from the base stake',async()=>{
 const f=fixture(()=>ok({data:[wager({gType:9,bet:'0',gambleBet:'-2.00',hasGamble:1,win:'3.00',roundSeqNo:'round-exact'})]}));const r=(await f.adapter.fetchWagers(context(),window)).items[0];assert.equal(r.betMinor,'200');assert.equal(r.providerRoundId,'round-exact');assert.equal(r.sourceDetails.gambleBet,'-2.00');
 const missing=fixture(()=>ok({data:[wager({gType:9,bet:'0',hasGamble:1})]}));await assert.rejects(missing.adapter.fetchWagers(context(),window),/GAMBLE_DATA_MISSING/);
});
test('sub-cent bets, bad signs, duplicate bets and invalid dates stop projection instead of rounding or advancing',async()=>{
 for(const [data,error] of [[[wager({bet:'-1.001'})],/PRECISION_REVIEW/],[[wager({win:'-1.00'})],/DIRECTION_INVALID/],[[wager(),wager()],/DUPLICATE_BET/],[[wager({lastModifyTime:'31-02-2026 19:51:00'})],/DATE_INVALID/]]){
  const f=fixture(()=>ok({data}));await assert.rejects(f.adapter.fetchWagers(context(),window),error);assert.equal(f.calls.length,1);
 }
});
test('report history selects Action 64 for old windows and does not invent a continuation cursor',async()=>{
 const f=fixture(()=>ok({data:[]}));await f.adapter.fetchWagers(context(),{from:now-3*60*60_000,to:now-3*60*60_000+60_000});assert.equal(f.calls[0].payload.action,64);
 await assert.rejects(f.adapter.fetchWagers(context(),{...window,cursor:'unsupported'}),/CURSOR_UNSUPPORTED/);assert.equal(f.calls.length,1);
 const unconfirmed=fixture(()=>ok({data:[]}),{},{reportUtcOffsetMinutes:undefined});await assert.rejects(unconfirmed.adapter.fetchWagers(context(),window),/TIMEZONE_UNCONFIRMED/);assert.equal(unconfirmed.calls.length,0);
});
test('report rows bind to the documented time basis and cannot cross an unrelated query window',async()=>{
 const recent=fixture(()=>ok({data:[wager({lastModifyTime:'08-11-2026 18:00:00'})]}));await assert.rejects(recent.adapter.fetchWagers(context(),window),/WINDOW_MISMATCH/);
 const older={from:now-3*60*60_000,to:now-3*60*60_000+60_000};
 const old=fixture(()=>ok({data:[wager({gameDate:'08-11-2026 17:00:00',lastModifyTime:'08-11-2026 19:51:00'})]}));
 const result=await old.adapter.fetchWagers(context(),older);assert.equal(result.items[0].sourceDetails.timeBasis,'gameDate');assert.equal(result.items[0].settledAt,now-9*60_000);
 const outside=fixture(()=>ok({data:[wager()]}));await assert.rejects(outside.adapter.fetchWagers(context(),older),/WINDOW_MISMATCH/);
});
test('undocumented transfer callbacks are rejected without reads, writes or an invented success acknowledgement',async()=>{
 const f=fixture(()=>ok({}));const result=await f.adapter.handleCallback(context(),new Request('https://www.master7.best/callback',{method:'POST',body:'untrusted'}));assert.deepEqual(result,{accepted:false,duplicate:false,responseBody:'UNSUPPORTED_TRANSFER_CALLBACK',responseStatus:403});assert.equal(f.calls.length,0);
});
test('credentials, allowed origins and switches are snapshotted rather than taken from mutable request context',async()=>{
 const f=fixture(()=>ok({data:[]}));f.cfg.parent='other';f.cfg.aesKey='differentKey1234';f.options.depositEnabled=true;f.options.allowedReturnOrigins.push('https://attacker.example');
 await f.adapter.listGames(context());assert.equal(f.calls[0].payload.parent,'agent01');await assert.rejects(f.adapter.depositToGame(context(),input()),/SUBMISSION_DISABLED/);assert.equal(f.calls.length,1);
});

test('game closure requires Action 52 not-playing proof, not a successful kick acknowledgement',async()=>{
 let queries=0;const f=fixture(payload=>payload.action===15?ok({data:[row()]}):payload.action===17?ok({}):(++queries<3?ok({data:{gType:0,mType:100}}):Response.json({status:'7505'})),{sessionClosureEnabled:true,sessionClosureVerified:true});
 const first=await f.adapter.closeGame(context(),{userId,providerPlayerId:user(),requestClosure:true});assert.equal(first.state,'playing');assert.deepEqual(f.calls.map(x=>x.payload.action),[15,52,17,52]);
 const done=await f.adapter.closeGame(context(),{userId,providerPlayerId:user(),requestClosure:true});assert.deepEqual(done,{state:'closed',evidenceCode:'JDB_ACTION52_7505'});assert.deepEqual(f.calls.slice(4).map(x=>x.payload.action),[15,52]);
});
test('a kick timeout is resolved only by an independent not-playing query, without a second kick',async()=>{
 let query=0;const f=fixture(payload=>{if(payload.action===15)return ok({data:[row()]});if(payload.action===17)throw Error('synthetic timeout');return ++query===1?ok({data:{gType:0,mType:100}}):Response.json({status:'7505'});},{sessionClosureEnabled:true,sessionClosureVerified:true});
 assert.equal((await f.adapter.closeGame(context(),{userId,providerPlayerId:user(),requestClosure:true})).state,'closed');assert.equal(f.calls.filter(x=>x.payload.action===17).length,1);
});
test('disabled closure supports read-only offline evidence but cannot request a kick',async()=>{
 const offline=fixture(payload=>payload.action===15?ok({data:[row()]}):Response.json({status:'7505'}));assert.equal((await offline.adapter.closeGame(context(),{userId,providerPlayerId:user(),requestClosure:false})).state,'closed');
 const active=fixture(payload=>payload.action===15?ok({data:[row()]}):ok({data:{gType:0,mType:100}}),{sessionClosureVerified:true});await assert.rejects(active.adapter.closeGame(context(),{userId,providerPlayerId:user(),requestClosure:true}),/JDB_SESSION_CLOSURE_DISABLED/);assert.equal(active.calls.some(x=>x.payload.action===17),false);
});
test('closure rejects a foreign profile or member before traffic and malformed status never proves closure',async()=>{
 const f=fixture(payload=>payload.action===15?ok({data:[row()]}):ok({data:{}}),{sessionClosureEnabled:true,sessionClosureVerified:true});await assert.rejects(f.adapter.closeGame(context('spribe_myr'),{userId,providerPlayerId:user(),requestClosure:true}),/JDB_PROFILE_MISMATCH/);await assert.rejects(f.adapter.closeGame(context(),{userId:'other-member',providerPlayerId:user(),requestClosure:true}),/JDB_PLAYER_MISMATCH/);assert.equal(f.calls.length,0);assert.equal((await f.adapter.closeGame(context(),{userId,providerPlayerId:user(),requestClosure:true})).state,'unknown');
});

test('offline state cannot authorize settlement without an accepted session invalidation contract',async()=>{
 const f=fixture(()=>Response.json({status:'7505'}),{sessionClosureEnabled:true});
 await assert.rejects(f.adapter.closeGame(context(),{userId,providerPlayerId:user(),requestClosure:true}),/JDB_SESSION_CLOSURE_UNVERIFIED/);assert.equal(f.calls.length,0);
});
