import test from 'node:test';
import assert from 'node:assert/strict';
import {handle,RELEASE} from '../lib/backend.ts';

test('lightweight liveness checks the database without contacting providers',async()=>{
 let queries=0,providerCalls=0;
 const db={prepare(sql){assert.equal(sql,'SELECT id FROM users LIMIT 1');return {all:async()=>{queries++;return {results:[],success:true,meta:{changes:0}};}};}};
 const response=await handle(new Request('https://portal.example.test/health/live'),{
  db,identity:null,ownerEmail:'owner@example.test',
  vpayFetch:async()=>{providerCalls++;throw new Error('provider must not be called');},
  gspayFetch:async()=>{providerCalls++;throw new Error('provider must not be called');},
  oneMpayFetch:async()=>{providerCalls++;throw new Error('provider must not be called');},
  gameGatewayFetch:async()=>{providerCalls++;throw new Error('provider must not be called');},
 });
 assert.equal(response.status,200);
 assert.deepEqual(await response.json(),{status:'ok',release:RELEASE,database:'ready',scope:'portal-liveness'});
 assert.equal(response.headers.get('cache-control'),'no-store');
 assert.equal(queries,1);assert.equal(providerCalls,0);
});
