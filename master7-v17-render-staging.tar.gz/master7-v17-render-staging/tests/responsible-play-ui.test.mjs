import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

test('Responsible Play UI is dedicated, neutral and explicit about services that remain available',()=>{
 const script=readFileSync(new URL('../public/assets/responsible-play.js',import.meta.url),'utf8'),style=readFileSync(new URL('../public/assets/responsible-play.css',import.meta.url),'utf8');
 assert.match(script,/\/api\/responsible-play/);assert.match(script,/action:'set_limits'/);assert.match(script,/action:'cooling_off'/);assert.match(script,/action:'self_exclude'/);assert.match(script,/window\.confirm\(/);assert.match(script,/cannot be cancelled or shortened/);assert.match(script,/Play settings do not add a withdrawal block/);assert.match(script,/actual submission follows payout-channel status/);assert.match(script,/Anonymous aggregate counts only/);assert.doesNotMatch(script,/problem gambler|addict|punish|confiscat/i);assert.match(style,/\.responsible-play-center\.active\{display:grid\}/);assert.doesNotMatch(style,/\.responsible-play-center\{display:grid/);assert.match(style,/@media\(max-width:520px\)/);
});

test('Responsible Play has one member-only page and one owner-only aggregate panel',()=>{
 const portal=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8'),app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
 assert.equal((portal.match(/id="responsible-play"/g)||[]).length,1);assert.equal((portal.match(/data-section="responsible-play"/g)||[]).length,2);
 assert.match(portal,/responsible-play\.css/);assert.match(portal,/responsible-play\.js/);assert.match(portal,/id="responsiblePlayLimitForm"/);assert.match(portal,/id="responsiblePlayCoolingState"/);assert.match(portal,/id="responsiblePlayExclusionState"/);
 assert.match(portal,/href="#responsiblePlayAdminPanel" data-owner-only/);assert.match(portal,/id="responsiblePlayAdminPanel"[^>]*data-owner-only/);
 assert.match(app,/section==="responsible-play"\)window\.Master7ResponsiblePlay\?\.load/);assert.match(app,/responsiblePlayAdminPanel:\(\)=>window\.Master7ResponsiblePlay\?\.loadAdmin/);assert.match(app,/Master7ResponsiblePlay\?\.sessionChanged/);
 assert.match(app,/querySelectorAll\('\[data-section="responsible-play"\]'\)\.forEach\(el=>el\.hidden=u\?\.role!=="member"\)/);assert.match(app,/"responsiblePlayAdminPanel"/);
 for(const statement of ['不额外限制提款','提款通道状态为准','账号保持可用','客服保持可用','余额不会被冻结','不能取消或缩短'])assert.match(portal,new RegExp(statement));
 assert.doesNotMatch(portal,/problem gambler|addict|punish|confiscat/i);
});
