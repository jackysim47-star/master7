import assert from 'node:assert/strict';
import test from 'node:test';
import {
  EXPECTED_RELEASE,
  STAGING_ORIGIN,
  evaluateAutoSetup,
  formatAutoSetupReport,
} from '../scripts/master7-v173-auto-setup.mjs';

const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '');

function safeEnv(overrides={}){
 return {
  MASTER7_EXPECTED_RELEASE:EXPECTED_RELEASE,
  PUBLIC_ORIGIN:STAGING_ORIGIN,
  PORTAL_ALLOWED_ORIGINS:STAGING_ORIGIN,
  PORTAL_MEGA_TRANSFERS_ENABLED:'false',
  PORTAL_MEGA_LIVE_GAMES_ENABLED:'false',
  PORTAL_MEGA_SETTLEMENT_VERIFIED:'false',
  GSPAY_ORDERS_ENABLED:'false',
  GSPAY_USDT_ORDERS_ENABLED:'false',
  ONE_MPAY_ORDERS_ENABLED:'false',
  VPAY_RECOVERY_ENABLED:'false',
  PORTAL_NEW_DEPOSITS_ENABLED:'false',
  PORTAL_NEW_GAME_LAUNCHES_ENABLED:'false',
  PORTAL_NEW_PAYOUTS_ENABLED:'false',
  ...overrides,
 };
}

test('auto setup accepts the closed staging baseline and never approves production',()=>{
 const result=evaluateAutoSetup({root,env:safeEnv()});
 assert.equal(result.status,'STAGING_READY');
 assert.equal(result.productionStatus,'NO-GO');
 assert.ok(result.checks.some(item=>item.id==='official_entries'&&item.status==='NOT_VERIFIED'));
 assert.ok(result.checks.filter(item=>item.scope==='safe_staging').every(item=>item.status==='PASS'));
});

test('auto setup blocks any open transaction or game switch',()=>{
 const result=evaluateAutoSetup({root,env:safeEnv({PORTAL_NEW_DEPOSITS_ENABLED:'true'})});
 assert.equal(result.status,'BLOCKED');
 assert.equal(result.checks.find(item=>item.id==='safe_switches').status,'BLOCKED');
 assert.equal(result.productionStatus,'NO-GO');
});

test('auto setup blocks a non-staging public origin',()=>{
 const result=evaluateAutoSetup({root,env:safeEnv({PUBLIC_ORIGIN:'https://www.master7.best'})});
 assert.equal(result.status,'BLOCKED');
 assert.equal(result.checks.find(item=>item.id==='staging_origin').status,'BLOCKED');
});

test('auto setup blocks release drift and reports no environment values',()=>{
 const result=evaluateAutoSetup({root,env:safeEnv({MASTER7_EXPECTED_RELEASE:'17.0.0-old'})});
 assert.equal(result.status,'BLOCKED');
 const report=formatAutoSetupReport(result);
 assert.match(report,/NO-GO/);
 assert.doesNotMatch(report,/password|secret|apiKey|token|merchantId/i);
 assert.doesNotMatch(report,/17\.0\.0-old/);
});
