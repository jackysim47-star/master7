import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {readDirectCatalogue,rectangleCatalogueHeaders,directCatalogueConfigured,CatalogueReadError} from '../lib/direct-game-catalogues.ts';
import {getGameCatalogue} from '../lib/game-catalogue.ts';
import {startCatalogueSync} from '../scripts/catalogue-sync-job.mjs';

const rectangle={rectangleApiBase:'https://apig.rg-lgna.com',rectangleOperatorCode:'FIXTURE_MASTER7',rectangleApiKey:'fixture-rectangle-key'};
const godee={godeeApiBase:'https://api.godeezone1.com',godeeOperatorId:'FIXTURE_OPERATOR',godeeApiKey:'fixture-godee-api-key'};
test('Rectangle signs an empty GET body with UTC date, bare hostname and lowercase hexadecimal HMAC',()=>{
 const h=rectangleCatalogueHeaders('apig.rg-lgna.com',rectangle.rectangleApiKey,1793836800);
 assert.equal(h['X-Date'],'20261105');assert.equal(h['X-Content-SHA256'],'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
 assert.equal(h.Authorization.split('Signature=')[1],'813e1696fd379ef355597aa28374fb5ea39f2da385ff201df832ff25873aac2b');
 assert.match(h.Authorization,/^RG-HMAC-SHA256 SignedHeaders=host;x-content-sha256;x-date,Signature=[a-f0-9]{64}$/);
});
test('Rectangle reads only the assigned production host and the documented catalogue endpoint',async()=>{
 let calls=0;const c={...rectangle,gameCatalogueFetch:async(url,init)=>{calls++;const u=new URL(url);assert.equal(u.origin,rectangle.rectangleApiBase);assert.equal(u.pathname,'/api/v1/available-games');assert.equal(u.searchParams.get('oc'),rectangle.rectangleOperatorCode);assert.equal(init.method,'GET');assert.equal(init.redirect,'error');assert.equal(Object.hasOwn(init,'body'),false);assert.ok(init.headers.Authorization.startsWith('RG-HMAC-SHA256 '));return Response.json({data:[{code:'fixture-game',name:'Fixture game',status:'ACTIVE',type:'SLOT',url:'https://game.example.test/fixture-game',privateKey:'must-not-leak'}]});}};
 const d=await readDirectCatalogue(c,'rectangle',1793836800);assert.equal(calls,1);assert.deepEqual(d,{games:[{gameCode:'fixture-game',name:'Fixture game',category:'SLOT',maintenance:false}],complete:true});
});
test('Godee token stays server-side and provider pagination keeps the same code in different providers separate',async()=>{
 const seen=[];const c={...godee,gameCatalogueFetch:async(url,init)=>{
  const u=new URL(url);seen.push(u.pathname+u.search);assert.equal(u.origin,godee.godeeApiBase);assert.equal(init.method,'GET');assert.equal(init.redirect,'error');
  if(u.pathname==='/token'){assert.equal(init.headers['X-Operator'],godee.godeeOperatorId);assert.equal(init.headers['X-Key'],godee.godeeApiKey);return Response.json({status:'success',data:{token:'fixture-access-token'}});}
  assert.equal(init.headers['X-Token'],'fixture-access-token');assert.equal(Object.hasOwn(init.headers,'X-Key'),false);
  const page=Number(u.searchParams.get('page'));
  if(u.pathname==='/game-providers')return Response.json({status:'success',data:{gameProviders:[{id:String(page+3),name:'Provider '+page}],meta:{hasNext:page===1}}});
  assert.equal(u.pathname,'/games');const id=Number(u.searchParams.get('provider'));return Response.json({status:'success',data:{games:[{providerId:id,code:'same-code',name:'Game '+id,category:'slot',actived:true,disabled:0}],meta:{hasNext:false}}});
 }};
 const data=await readDirectCatalogue(c,'godeezone',1793836800);assert.equal(seen.length,5);assert.deepEqual(data.games.map(g=>g.gameCode),['4:same-code','5:same-code']);assert.deepEqual(data.games.map(g=>[g.originalProviderId,g.originalGameCode]),[['4','same-code'],['5','same-code']]);assert.equal(data.complete,true);assert.ok(!JSON.stringify(data).includes('fixture-access-token'));
});
test('invalid production configuration never sends credentials to another host',async()=>{
 let calls=0;const c={...rectangle,rectangleApiBase:'https://attacker.example.test',gameCatalogueFetch:async()=>{calls++;throw Error();}};
 assert.equal(directCatalogueConfigured(c,'rectangle'),false);await assert.rejects(()=>readDirectCatalogue(c,'rectangle',1793836800),CatalogueReadError);assert.equal(calls,0);
});
test('supplier rejection exposes only a safe status and never its body or merchant credentials',async()=>{
 const c={...godee,gameCatalogueFetch:async()=>Response.json({message:'provider secret',key:godee.godeeApiKey},{status:403})};
 await assert.rejects(()=>readDirectCatalogue(c,'godeezone',1793836800),e=>e instanceof CatalogueReadError&&e.upstreamStatus===403&&!e.message.includes('provider secret')&&!e.message.includes(godee.godeeApiKey));
});
test('a game returned under the wrong provider is rejected',async()=>{
 const c={...godee,gameCatalogueFetch:async url=>{const p=new URL(url).pathname;if(p==='/token')return Response.json({status:'success',data:{token:'fixture-access-token'}});if(p==='/game-providers')return Response.json({status:'success',data:{gameProviders:[{id:4,name:'One'}],meta:{hasNext:false}}});return Response.json({status:'success',data:{games:[{providerId:5,code:'wrong-game'}],meta:{hasNext:false}}});}};
 await assert.rejects(()=>readDirectCatalogue(c,'godeezone',1793836800),CatalogueReadError);
});
test('Godee original game and provider identifiers survive catalogue synchronization',async t=>{
 const sql=new DatabaseSync(':memory:');t.after(()=>sql.close());for(const name of ['0000_broken_bloodscream.sql','0019_game_catalogue_sync.sql'])sql.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 class S{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new S(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const c={...godee,db:{prepare:text=>new S(text)},gameSyncNow:()=>1000,gameCatalogueFetch:async url=>{const path=new URL(url).pathname;if(path==='/token')return Response.json({status:'success',data:{token:'fixture-access-token'}});if(path==='/game-providers')return Response.json({status:'success',data:{gameProviders:[{id:4,name:'Provider A'},{id:5,name:'Provider B'}],meta:{hasNext:false}}});const id=Number(new URL(url).searchParams.get('provider'));return Response.json({status:'success',data:{games:[{providerId:id,code:'same-code',name:'Game',actived:true,disabled:0}],meta:{hasNext:false}}});}};
 const result=await getGameCatalogue(c,{providerId:'godeezone'});assert.deepEqual(result.games.map(g=>[g.gameCode,g.originalProviderId,g.originalGameCode]),[['4:same-code','4','same-code'],['5:same-code','5','same-code']]);
 const cached=JSON.parse(sql.prepare("SELECT games_json FROM game_catalogue_cache WHERE provider_id='godeezone'").get().games_json);assert.deepEqual(cached.map(g=>g.originalGameCode),['same-code','same-code']);
});
test('Godee uses an independent private catalogue and never overwrites the existing ATG cache',async t=>{
 const sql=new DatabaseSync(':memory:');t.after(()=>sql.close());for(const name of ['0000_broken_bloodscream.sql','0019_game_catalogue_sync.sql'])sql.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 class S{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new S(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const old=JSON.stringify([{provider:'atg',gameCode:'legacy-atg'}]);sql.prepare("INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,lease_until,complete) VALUES('atg','available',?,100,100,0,1)").run(old);
 let calls=0;const c={...godee,db:{prepare:text=>new S(text)},gameSyncNow:()=>1000,gameCatalogueFetch:async url=>{calls++;const p=new URL(url).pathname;if(p==='/token')return Response.json({status:'success',data:{token:'fixture-access-token'}});if(p==='/game-providers')return Response.json({status:'success',data:{gameProviders:[{id:4,name:'Provider A'}],meta:{hasNext:false}}});return Response.json({status:'success',data:{games:[{providerId:4,code:'game-1',name:'Fixture',actived:true,disabled:0}],meta:{hasNext:false}}});}};
 assert.equal(directCatalogueConfigured(c,'atg'),false);await assert.rejects(()=>readDirectCatalogue(c,'atg',1000),CatalogueReadError);assert.equal(calls,0);
 const data=await getGameCatalogue(c,{providerId:'godeezone'});assert.equal(data.games[0].provider,'godeezone');assert.equal(data.games[0].playable,false);
 assert.equal(sql.prepare("SELECT games_json FROM game_catalogue_cache WHERE provider_id='atg'").get().games_json,old);
 assert.equal(sql.prepare("SELECT COUNT(*) n FROM providers WHERE id='godeezone'").get().n,0);
});
test('a newly configured direct provider persists its games and preserves owner visibility choices',async t=>{
 const sql=new DatabaseSync(':memory:');t.after(()=>sql.close());for(const name of ['0000_broken_bloodscream.sql','0019_game_catalogue_sync.sql'])sql.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 class S{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new S(this.sql,args);}async first(){return sql.prepare(this.sql).get(...this.args)??null;}async all(){return {results:sql.prepare(this.sql).all(...this.args)};}async run(){return sql.prepare(this.sql).run(...this.args);}}
 let time=1000;const c={...rectangle,db:{prepare:sql=>new S(sql)},gameSyncNow:()=>time,gameCatalogueFetch:async()=>Response.json({data:[{code:'fixture-game',name:'Fixture game',status:'ACTIVE',type:'SLOT'}]})};
 let data=await getGameCatalogue(c);assert.equal(data.games.length,1);assert.equal(data.providers[0].catalogueSynced,true);assert.equal(data.games[0].playable,false);assert.equal(sql.prepare("SELECT visible FROM providers WHERE id='rectangle'").get().visible,1);
 sql.prepare("UPDATE providers SET visible=0 WHERE id='rectangle'").run();time+=301;data=await getGameCatalogue(c);assert.equal(data.games.length,1);assert.equal(sql.prepare("SELECT visible FROM providers WHERE id='rectangle'").get().visible,0);
});
test('background synchronization uses a fixed authenticated loopback GET and prevents overlapping runs',async()=>{
 let calls=0,release;const gate=new Promise(resolve=>release=resolve),token='fixture-catalogue-sync-token-1234567890';
 const job=startCatalogueSync({token,port:'10000'},async(url,init)=>{calls++;assert.equal(url,'http://127.0.0.1:10000/api/internal/catalogue-sync');assert.equal(init.method,'GET');assert.equal(init.headers.Authorization,'Bearer '+token);assert.equal(init.redirect,'error');await gate;return Response.json({});});
 try{const first=job.run();await job.run();assert.equal(calls,1);release();await first;}finally{job.stop();}await job.run();assert.equal(calls,1);
});
test('an unset sync token or invalid loopback port cannot start a background request',async()=>{
 let calls=0;for(const options of [{token:'short',port:'10000'},{token:'x'.repeat(40),port:'10000/attacker'},{token:'x'.repeat(40),port:'70000'}]){const job=startCatalogueSync(options,async()=>{calls++;throw Error();});await job.run();job.stop();}assert.equal(calls,0);
});
