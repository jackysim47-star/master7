import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {approveWithdrawal,cancelWithdrawal,clearStaleReservation,listAdminWithdrawals,submitWithdrawal,withdrawalWalletState} from '../lib/withdrawals.ts';

class Statement {
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}
function setup(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());
 const dir=new URL('../drizzle/',import.meta.url);
 for(const file of readdirSync(dir).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,dir),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(items){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const item of items)results.push(await item.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.exec(`INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member','member',1,'csrf',0),('owner','owner','owner',1,'csrf',0);
 INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('credit','member','credit-request','fp','manual_bank',10000,'MYR','bank','credited',0,0);
 INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('member-credit','credit','member','member',10000,'MYR',0),('clearing-credit','credit','member','provider_clearing',-10000,'MYR',0);
 INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('member','passed','passed',1,'synthetic',0,0);`);
 const member={id:'member',username:'member',role:'member',approved:1},owner={id:'owner',username:'owner',role:'owner',approved:1};
 return {sqlite,db,member,owner};
}
function gate(){let signal,release;return {ready:new Promise(r=>{signal=r;}),wait:new Promise(r=>{release=r;}),signal:()=>signal(),release:()=>release()};}
const input={providerId:'vpay',bankCode:'maybank',accountHolder:'Test Member',accountNumber:'1234567890',amount:'20.00',requestKey:'test_withdrawal_0001'};
const key='local-fixture-key-'+ 'x'.repeat(40);

async function requestAndApprove({db,member,owner,adapter}){
 const payouts={vpay:adapter};
 const requested=await submitWithdrawal(input,{db,user:member,dataKey:key,payouts});
 assert.equal(requested.status,201);const requestBody=await requested.json();assert.equal(requestBody.status,'pending');
 const list=await listAdminWithdrawals({db,user:owner,dataKey:key,payouts});assert.equal(list.status,200);
 const row=(await list.json()).items.find(item=>item.id===requestBody.withdrawal.id);assert.equal(row.approvalEligible,true);
 return approveWithdrawal({id:row.id,approvalFingerprint:row.approvalFingerprint,ownerNote:'Synthetic approval'}, {db,user:owner,dataKey:key,payouts});
}

for(const cancelFirst of [true,false])test(`payout claim and owner cancellation serialize: ${cancelFirst?'cancellation wins':'provider claim wins'}`,async t=>{
 const {sqlite,db,member,owner}=setup(t),g=gate();let externalCalls=0;
 const adapter={enabled:true,reason:'fixture',submit:async({payoutId})=>{
  if(cancelFirst){g.signal();await g.wait;}
  const claimed=await db.prepare("UPDATE provider_payouts SET status='submitting',create_outcome='in_flight' WHERE id=? AND status='prepared' RETURNING id").bind(payoutId).first();
  if(!claimed)return {status:'processing'};
  if(!cancelFirst){g.signal();await g.wait;}
  externalCalls++;await db.prepare("UPDATE withdrawal_requests SET status='processing' WHERE id=(SELECT withdrawal_id FROM provider_payouts WHERE id=?) AND status='approved'").bind(payoutId).run();
  return {status:'processing'};
 }};
 const request=requestAndApprove({db,member,owner,adapter});await g.ready;
 const row=sqlite.prepare('SELECT id FROM withdrawal_requests').get();
 const cancel=await cancelWithdrawal({id:row.id,status:'cancelled',ownerNote:'Owner cancellation'},{db,user:owner});
 assert.equal(cancel.status,cancelFirst?200:409);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,cancelFirst?0:1);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='withdrawal_cancelled'").get().n,cancelFirst?1:0);
 g.release();const response=await request;const body=await response.json();
 assert.equal(externalCalls,cancelFirst?0:1);assert.equal(body.status,cancelFirst?'failed':'processing');
 assert.equal(sqlite.prepare('SELECT status FROM withdrawal_requests').get().status,cancelFirst?'cancelled':'processing');
 assert.equal(sqlite.prepare('SELECT status FROM provider_payouts').get().status,cancelFirst?'failed':'submitting');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,cancelFirst?0:1);
});

function seedWithdrawal(sqlite,{status='pending',payoutStatus='prepared',outcome='not_submitted',reference=null,errorCode=null,payoutAmount=2000,reservation=true,reservationAmount=2000,withPayout=true}={}){
 sqlite.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('historic-withdrawal','member','historical-key','vpay','VPay','maybank','Maybank','holder','account','7890',2000,'MYR',?,'',0,0)").run(status);
 if(withPayout)sqlite.prepare("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,provider_reference,last_error_code,created_at,updated_at) VALUES('P7historical','historic-withdrawal','vpay','historical-key','fp',?,'MYR',?,?,?,?,0,0)").run(payoutAmount,payoutStatus,outcome,reference,errorCode);
 if(reservation)sqlite.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','withdrawal','historic-withdrawal',?,0)").run(reservationAmount);
}

for(const change of ['payout_review','balance_removed'])test(`withdrawal rechecks ${change} within the guarded reservation transaction`,async t=>{
 const {sqlite,db,member}=setup(t),originalBatch=db.batch.bind(db);let injected=false,calls=0;
 db.batch=async statements=>{
  // Simulate a state change after the initial balance lookup and immediately
  // before the transaction acquires the member guard.
  if(!injected&&statements.some(item=>item.sql.includes('INSERT INTO wallet_reservations'))){
   injected=true;
   if(change==='payout_review')seedWithdrawal(sqlite,{status:'rejected',payoutStatus:'review',outcome:'unknown',reservation:false});
   else sqlite.prepare("DELETE FROM wallet_ledger WHERE id='member-credit'").run();
  }
  return originalBatch(statements);
 };
 const adapter={enabled:true,reason:'fixture',submit:async()=>{calls++;return {status:'processing'};}};
 const result=await submitWithdrawal(input,{db,user:member,dataKey:key,payouts:{vpay:adapter}});
 assert.equal(injected,true);assert.equal(result.status,409);assert.equal(calls,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM withdrawal_requests WHERE request_key=?").get(input.requestKey).n,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE kind='withdrawal'").get().n,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='withdrawal_requested'").get().n,0);
});
for(const [description,options] of [
 ['rejected withdrawal with in-flight payout',{status:'rejected',payoutStatus:'submitting',outcome:'in_flight'}],
 ['open payout with missing reservation',{reservation:false}],
 ['payout amount mismatch',{payoutAmount:1999}],
 ['reservation amount mismatch',{reservationAmount:1999}],
 ['paid with missing provider reference',{status:'paid',payoutStatus:'succeeded',outcome:'accepted'}],
 ['paid with an unresolved provider error',{status:'paid',payoutStatus:'succeeded',outcome:'accepted',reference:'P7historical',errorCode:'review_pending'}],
 ['paid with unknown submission outcome',{status:'paid',payoutStatus:'succeeded',outcome:'unknown',reference:'P7historical'}],
 ['legacy rejected with no evidence',{status:'rejected',withPayout:false}],
])test(`historical ${description} is blocked for reconciliation`,async t=>{
 const {sqlite,db}=setup(t);seedWithdrawal(sqlite,options);
 await clearStaleReservation(db,'member');
 const wallet=await withdrawalWalletState(db,'member');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,options.reservation===false?0:1);
});

test('verified paid payout permits cleanup of its exact old reservation',async t=>{
 const {sqlite,db}=setup(t);seedWithdrawal(sqlite,{status:'paid',payoutStatus:'succeeded',outcome:'accepted',reference:'P7historical'});
 await clearStaleReservation(db,'member');const wallet=await withdrawalWalletState(db,'member');
 assert.equal(wallet.balanceMinor,'8000');assert.equal(wallet.availableMinor,'8000');assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
});

test('legacy pending without payout is blocked for manual reconciliation',async t=>{
 const {sqlite,db,owner}=setup(t);seedWithdrawal(sqlite,{withPayout:false});
 const response=await cancelWithdrawal({id:'historic-withdrawal',status:'cancelled',ownerNote:'Legacy pending'},{db,user:owner});assert.equal(response.status,409);
 const wallet=await withdrawalWalletState(db,'member');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
});

for(const confirmed of [false,true])test(`withdrawal submission and replay expose ${confirmed?'verified paid':'review for inconsistent paid'}`,async t=>{
 const {db,member,owner}=setup(t);let calls=0;
 const adapter={enabled:true,reason:'fixture',submit:async({payoutId,withdrawalId})=>{
  calls++;await db.prepare("UPDATE provider_payouts SET status=?,create_outcome='accepted',provider_reference=? WHERE id=?").bind(confirmed?'succeeded':'review',payoutId,payoutId).run();
  await db.prepare("UPDATE withdrawal_requests SET status='paid' WHERE id=?").bind(withdrawalId).run();
  if(confirmed)await db.prepare("DELETE FROM wallet_reservations WHERE reference_id=?").bind(withdrawalId).run();
  return {status:'succeeded',providerReference:payoutId};
 }};
 const context={db,user:member,dataKey:key,payouts:{vpay:adapter}},response=await requestAndApprove({db,member,owner,adapter}),body=await response.json();
 assert.equal(response.status,202);assert.equal(body.status,confirmed?'paid':'review');assert.equal(body.withdrawal.status,confirmed?'paid':'review');
 const replay=await submitWithdrawal(input,context),repeat=await replay.json();assert.equal(replay.status,200);assert.equal(repeat.status,confirmed?'paid':'review');assert.equal(repeat.withdrawal.status,confirmed?'paid':'review');assert.equal(calls,1);
});

for(const withdrawalStatus of ['rejected','cancelled'])test(`terminal ${withdrawalStatus} with review payout reports review on submit and replay`,async t=>{
 const {db,member,owner}=setup(t);let calls=0;
 const adapter={enabled:true,reason:'fixture',submit:async({payoutId,withdrawalId})=>{
  calls++;await db.prepare("UPDATE provider_payouts SET status='review',create_outcome='unknown' WHERE id=?").bind(payoutId).run();
  await db.prepare('UPDATE withdrawal_requests SET status=? WHERE id=?').bind(withdrawalStatus,withdrawalId).run();
  return {status:'failed'};
 }};
 const context={db,user:member,dataKey:key,payouts:{vpay:adapter}},first=await requestAndApprove({db,member,owner,adapter}),body=await first.json();
 assert.equal(body.status,'review');assert.equal(body.withdrawal.status,'review');
 const replay=await submitWithdrawal(input,context),repeat=await replay.json();assert.equal(repeat.status,'review');assert.equal(repeat.withdrawal.status,'review');assert.equal(calls,1);
});

test('paid with a remaining reservation reports review on submit and replay',async t=>{
 const {db,member,owner}=setup(t);const adapter={enabled:true,reason:'fixture',submit:async({payoutId,withdrawalId})=>{
  await db.prepare("UPDATE provider_payouts SET status='succeeded',create_outcome='accepted',provider_reference=? WHERE id=?").bind(payoutId,payoutId).run();
  await db.prepare("UPDATE withdrawal_requests SET status='paid' WHERE id=?").bind(withdrawalId).run();return {status:'succeeded'};
 }};
 const context={db,user:member,dataKey:key,payouts:{vpay:adapter}},first=await requestAndApprove({db,member,owner,adapter}),body=await first.json();assert.equal(body.status,'review');assert.equal(body.withdrawal.status,'review');
 const replay=await submitWithdrawal(input,context),repeat=await replay.json();assert.equal(repeat.status,'review');assert.equal(repeat.withdrawal.status,'review');
});

for(const kind of ['missing','wrong_amount','wrong_member'])test(`owner cannot cancel payout when reservation is ${kind}`,async t=>{
 const {sqlite,db,owner}=setup(t);seedWithdrawal(sqlite,{reservation:kind!=='missing',reservationAmount:kind==='wrong_amount'?1999:2000});
 if(kind==='wrong_member'){
  sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('other','other','member',1,'csrf',0)").run();
  sqlite.prepare("UPDATE wallet_reservations SET user_id='other' WHERE reference_id='historic-withdrawal'").run();
 }
 const response=await cancelWithdrawal({id:'historic-withdrawal',status:'cancelled',ownerNote:'Reconcile'},{db,user:owner});
 assert.equal(response.status,409);assert.equal(sqlite.prepare('SELECT status FROM provider_payouts').get().status,'prepared');assert.equal(sqlite.prepare('SELECT status FROM withdrawal_requests').get().status,'pending');
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,kind==='missing'?0:1);
});
