import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const start=source.indexOf('function benefitRulesSummary(');
const end=source.indexOf('function renderBenefitCalculationPreview(',start);
assert.ok(start>=0&&end>start,'benefit calculation helpers must exist');
const context={Math,Number};
vm.createContext(context);vm.runInContext(source.slice(start,end),context);

test('benefit preview treats zero fixed turnover as multiplier and clears ineligible turnover',()=>{
 const rules={rewardAmountMYR:10,minDepositMYR:20,turnoverRequiredMYR:0,turnoverMultiplier:5,turnoverBase:'deposit_plus_bonus'};
 assert.match(context.benefitRulesSummary(rules),/Required turnover 5×/);
 assert.deepEqual({...context.calculateBenefitPreview(rules,20)},{eligible:true,reward:10,turnover:150,min:20});
 assert.deepEqual({...context.calculateBenefitPreview(rules,19)},{eligible:false,reward:0,turnover:0,min:20});
 assert.match(source,/L1 预览（不可领取）/);
 assert.doesNotMatch(source,/referralMetric\(summary,"累计佣金"/);
 assert.match(source,/Preview only · cannot be claimed · no wallet credit · turnover is not enforced/);
 assert.match(source,/request\.disabled=true/);
 assert.doesNotMatch(source,/function submitBonusClaimRequest/);
 assert.doesNotMatch(source,/Bonus request ·/);
});
