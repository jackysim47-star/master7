import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const start=source.indexOf('function benefitRulesSummary(');
const end=source.indexOf('function renderBenefitCalculationPreview(',start);
assert.ok(start>=0&&end>start,'benefit calculation helpers must exist');
const context={Math,Number};
vm.createContext(context);vm.runInContext(source.slice(start,end),context);

test('benefit preview treats zero fixed turnover as multiplier and clears ineligible turnover',()=>{
 const rules={rewardAmountMYR:10,minDepositMYR:20,turnoverRequiredMYR:0,turnoverMultiplier:5,turnoverBase:'deposit_plus_bonus'};
 assert.match(context.benefitRulesSummary(rules),/Required turnover 5×/);
 assert.deepEqual({...context.calculateBenefitPreview(rules,20)},{eligible:true,reward:10,turnover:150,min:20});
 assert.deepEqual({...context.calculateBenefitPreview(rules,19)},{eligible:false,reward:0,turnover:0,min:20});
 assert.match(source,/Latest commission preview/);
 assert.doesNotMatch(source,/referralMetric\(summary,"累计佣金"/);
 assert.match(source,/Preview only · cannot be claimed · no wallet credit · turnover is not enforced/);
 assert.match(source,/async function requestProviderBonus/);
 assert.match(source,/api\("\/api\/benefit-claims","POST"/);
 assert.doesNotMatch(source,/api\("\/api\/admin\/voucher-manual","POST"/);
 assert.match(source,/Benefit eligibility requests · 人工审核记录/);
 assert.match(source,/不会自动增加钱包、执行 Turnover 或公司汇款/);
 assert.match(source,/Approve eligibility/);
 assert.match(source,/decision:"approve"/);
 assert.match(source,/decision:"reject"/);
});
