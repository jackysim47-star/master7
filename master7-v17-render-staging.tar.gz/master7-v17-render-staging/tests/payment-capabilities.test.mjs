import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {paymentCapability} from '../lib/payment-capabilities.ts';
import {providerPayoutCapabilities,payoutTransitionAllowed,payoutSubmissionControls} from '../lib/payout-state.ts';
import {handle} from '../lib/backend.ts';

function database(t){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sqlite.prepare(this.text).get(...this.args)??null;}async all(){return {results:sqlite.prepare(this.text).all(...this.args)};}async run(){return sqlite.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text)};t.after(()=>sqlite.close());return {sqlite,db};
}

test('capability flags never infer verification or settlement from configuration',()=>{
 assert.deepEqual(paymentCapability({implemented:true,configured:true,enabled:true}),{implemented:true,configured:true,enabled:true,verified:false,settlementVerified:false,blockers:[]});
 for(const capability of Object.values(providerPayoutCapabilities)){assert.equal(capability.enabled,false);assert.equal(capability.submissionEnabled,false);assert.equal(capability.verified,false);assert.ok(capability.blockers.includes('submission_disabled'));}
});

test('payout database control remains fail-closed and reserved for the direct GSPAY adapter',async t=>{
 const {sqlite,db}=database(t),controls=await payoutSubmissionControls(db);assert.deepEqual(controls,[{providerId:'1mpay',submissionEnabled:false},{providerId:'gspay',submissionEnabled:false},{providerId:'vpay',submissionEnabled:false}]);
 assert.throws(()=>sqlite.prepare("UPDATE provider_payout_controls SET submission_enabled=1 WHERE provider_id='vpay'").run(),/CHECK constraint failed/);
 sqlite.prepare("UPDATE provider_payout_controls SET submission_enabled=1 WHERE provider_id='gspay'").run();assert.equal(sqlite.prepare("SELECT submission_enabled FROM provider_payout_controls WHERE provider_id='gspay'").get().submission_enabled,1);
 assert.equal(payoutTransitionAllowed('prepared','submitting'),true);assert.equal(payoutTransitionAllowed('prepared','succeeded'),false);assert.equal(payoutTransitionAllowed('review','succeeded'),false);
});

test('internal recovery endpoint requires its private token and keeps all recovery off by default',async t=>{
 const {db}=database(t),token='payment-recovery-fixture-token-'.padEnd(40,'x'),url='https://portal.example.test/api/internal/payment-recovery';
 let response=await handle(new Request(url,{method:'POST',headers:{authorization:'Bearer wrong'}}),{db,identity:null,ownerEmail:'',paymentRecoveryToken:token});assert.equal(response.status,401);
 response=await handle(new Request(url,{method:'POST',headers:{authorization:'Bearer '+token}}),{db,identity:null,ownerEmail:'',paymentRecoveryToken:token});assert.equal(response.status,200);const body=await response.json();assert.equal(body.providers.vpay.enabled,false);assert.equal(body.providers.gspay.enabled,false);assert.equal(body.newOrdersChanged,false);assert.equal(body.payoutsSubmitted,false);
});
