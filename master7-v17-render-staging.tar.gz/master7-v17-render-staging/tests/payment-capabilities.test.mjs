import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {paymentCapability} from '../lib/payment-capabilities.ts';
import {providerPayoutCapabilities,payoutTransitionAllowed,payoutSubmissionControls} from '../lib/payout-state.ts';
import {handle} from '../lib/backend.ts';

function database(t){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sqlite.prepare(this.text).get(...this.args)??null;}async all(){return {results:sqlite.prepare(this.text).all(...this.args)};}async run(){return sqlite.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text)};t.after(()=>sqlite.close());return {sqlite,db};
}

test('capability flags never infer verification or settlement from configuration',()=>{
 assert.deepEqual(paymentCapability({implemented:true,configured:true,enabled:true}),{implemented:true,configured:true,enabled:true,verified:false,settlementVerified:false,blockers:[]});
 for(const capability of Object.values(providerPayoutCapabilities)){assert.equal(capability.enabled,false);assert.equal(capability.submissionEnabled,false);assert.equal(capability.verified,false);assert.ok(capability.blockers.includes('submission_disabled'));}
});

test('payout database control remains fail-closed and reserved for the direct GSPAY adapter',async t=>{
 const {sqlite,db}=database(t),controls=await payoutSubmissionControls(db);assert.deepEqual(controls,[{providerId:'1mpay',submissionEnabled:false},{providerId:'gspay',submissionEnabled:false},{providerId:'vpay',submissionEnabled:false}]);
 assert.throws(()=>sqlite.prepare("UPDATE provider_payout_controls SET submission_enabled=1 WHERE provider_id='vpay'").run(),/CHECK constraint failed/);
 sqlite.prepare("UPDATE provider_payout_controls SET submission_enabled=1 WHERE provider_id='gspay'").run();assert.equal(sqlite.prepare("SELECT submission_enabled FROM provider_payout_controls WHERE provider_id='gspay'").get().submission_enabled,1);
 assert.equal(payoutTransitionAllowed('prepared','submitting'),true);assert.equal(payoutTransitionAllowed('prepared','succeeded'),false);assert.equal(payoutTransitionAllowed('review','succeeded'),false);
});

test('internal recovery endpoint requires its private token and keeps all recovery off by default',async t=>{
 const {db}=database(t),token='payment-recovery-fixture-token-'.padEnd(40,'x'),url='https://portal.example.test/api/internal/payment-recovery';
 let response=await handle(new Request(url,{method:'POST',headers:{authorization:'Bearer wrong'}}),{db,identity:null,ownerEmail:'',paymentRecoveryToken:token});assert.equal(response.status,401);
 response=await handle(new Request(url,{method:'POST',headers:{authorization:'Bearer '+token}}),{db,identity:null,ownerEmail:'',paymentRecoveryToken:token});assert.equal(response.status,200);const body=await response.json();assert.equal(body.providers.vpay.enabled,false);assert.equal(body.providers.gspay.enabled,false);assert.equal(body.newOrdersChanged,false);assert.equal(body.payoutsSubmitted,false);
});

test('1MPay-only recovery is token-protected and rejects ambiguous scope',async t=>{
 const {db}=database(t),token='payment-recovery-fixture-token-'.padEnd(40,'x'),base='https://portal.example.test/api/internal/payment-recovery',context={db,identity:null,ownerEmail:'',paymentRecoveryToken:token};
 let response=await handle(new Request(base+'?provider=1mpay',{method:'POST',headers:{authorization:'Bearer wrong'}}),context);assert.equal(response.status,401);
 for(const query of ['?provider=vpay','?provider=1mpay&provider=gspay']){response=await handle(new Request(base+query,{method:'POST',headers:{authorization:'Bearer '+token}}),context);assert.equal(response.status,400);}
 response=await handle(new Request(base+'?provider=1mpay',{method:'POST',headers:{authorization:'Bearer '+token}}),context);assert.equal(response.status,200);const body=await response.json();assert.equal(body.scope,'1mpay');assert.deepEqual(Object.keys(body.providers),['1mpay']);assert.deepEqual(body.payouts,{});assert.equal(body.providers['1mpay'].enabled,false);
});

test('VPay public status and health share the actual payout capability without changing controls',async t=>{
 const gateway='https://master7-integration-gateway.onrender.com',returnUrl='https://master7-v17-staging.onrender.com/payment/return';
 const cases=[
  {name:'configured and enabled',configured:true,enabled:true},
  {name:'missing payout token',patch:{vpayPayoutToken:undefined},configured:false,enabled:false},
  {name:'missing withdrawal data key',patch:{withdrawalDataKey:undefined},configured:false,enabled:false},
  {name:'reused payout and callback token',patch:{vpayPayoutToken:'c'.repeat(40)},configured:false,enabled:false},
  {name:'payout switch disabled',patch:{vpayPayoutEnabled:'false'},configured:true,enabled:false},
  {name:'payout switch absent',patch:{vpayPayoutEnabled:undefined},configured:true,enabled:false},
  {name:'channel suspended',channel:'suspended',configured:true,enabled:false},
  {name:'deprecated deposit switch cannot change payout capability',patch:{vpayOrdersEnabled:'false'},configured:true,enabled:true},
  {name:'global payout maintenance blocks submissions',patch:{newPayoutsEnabled:'false'},configured:true,enabled:false},
  {name:'absent global payout switch fails closed',patch:{newPayoutsEnabled:undefined},configured:true,enabled:false},
  {name:'deposit maintenance does not prevent payouts',patch:{newDepositsEnabled:'false'},configured:true,enabled:true},
  {name:'deposit gateway unavailable',gatewayUnavailable:true,configured:true,enabled:true},
 ];
 for(const scenario of cases)await t.test(scenario.name,async sub=>{
  const {sqlite,db}=database(sub);sub.mock.method(globalThis,'fetch',async()=>{throw Error('Unexpected network request');});
  sqlite.prepare("UPDATE payment_channel_controls SET status=? WHERE provider_id='vpay'").run(scenario.channel??'active');
  const controls=sqlite.prepare('SELECT * FROM payment_channel_controls ORDER BY provider_id').all(),payoutControls=sqlite.prepare('SELECT * FROM provider_payout_controls ORDER BY provider_id').all();
  let configReads=0;
  const context={db,identity:null,ownerEmail:'',newDepositsEnabled:'true',newPayoutsEnabled:'true',vpayGatewayUrl:gateway,vpayMode:'production',vpayTraderId:'3647',vpayOrdersEnabled:'true',vpayOrderToken:'o'.repeat(40),vpayQueryToken:'q'.repeat(40),vpayCallbackToken:'c'.repeat(40),vpayPayoutToken:'p'.repeat(40),vpayPayoutEnabled:'true',withdrawalDataKey:'w'.repeat(40),vpayReturnUrl:returnUrl,...scenario.patch,vpayFetch:async(input,init)=>{
   assert.equal(String(input),gateway+'/platform/vpay/config');assert.equal(init.method,'GET');assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+'q'.repeat(40));configReads++;
   if(scenario.gatewayUnavailable)throw Error('Synthetic unavailable gateway');
   return Response.json({provider:'vpay',mode:'production',paymentReady:true,traderId:'3647',notifyUrl:gateway+'/callbacks/vpay/payment',returnUrl,tradeCodes:['2']});
  }};
  const bodies=[];
  for(const path of ['/health','/api/payments/vpay/status']){const response=await handle(new Request('https://portal.example.test'+path),context);assert.equal(response.status,200);bodies.push(await response.json());}
  const [health,status]=bodies,payout=status.capabilities.payout;
  assert.deepEqual(payout,health.providerCapabilities.vpay.payout);
  assert.equal(payout.configured,scenario.configured);assert.equal(payout.enabled,scenario.enabled);assert.equal(payout.submissionEnabled,scenario.enabled);
  assert.equal(health.providerPayoutsEnabled.vpay,scenario.enabled);assert.equal(health.payoutsEnabled,scenario.enabled);
  assert.equal(payout.verified,false);assert.equal(payout.settlementVerified,false);assert.equal(status.settlementVerified,false);assert.equal(health.settlementVerified,false);assert.equal(health.productionReady,false);
  assert.equal(configReads,2);
  assert.deepEqual(sqlite.prepare('SELECT * FROM payment_channel_controls ORDER BY provider_id').all(),controls);
  assert.deepEqual(sqlite.prepare('SELECT * FROM provider_payout_controls ORDER BY provider_id').all(),payoutControls);
  for(const table of ['deposit_orders','withdrawal_requests','provider_payouts','wallet_ledger'])assert.equal(sqlite.prepare(`SELECT COUNT(*) n FROM ${table}`).get().n,0);
  for(const secret of [context.vpayOrderToken,context.vpayQueryToken,context.vpayCallbackToken,context.vpayPayoutToken,context.withdrawalDataKey].filter(Boolean))assert.ok(!JSON.stringify(bodies).includes(secret));
 });
});
