import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createContext,runInContext} from 'node:vm';

const full=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const split=full.indexOf('(async function start(){');
const definitions=full.slice(0,split),startup=full.slice(split);

function fixture(pathname='/'){
 const elements=new Map(),calls=[];
 const get=id=>{
  if(!elements.has(id))elements.set(id,{value:'',textContent:'',hidden:false,open:false,handlers:{},dataset:{},classList:{toggle(){}},
   addEventListener(name,fn){this.handlers[name]=fn;},showModal(){this.open=true;},reset(){for(const e of elements.values())e.value='';}});
  return elements.get(id);
 };
 const channels=['vpay','1mpay'].map(code=>({
  dataset:{paymentChannel:code},hidden:false,label:'',status:{textContent:''},
  querySelector(selector){assert.equal(selector,'.payment-state');return this.status;},
  setAttribute(name,value){assert.equal(name,'aria-label');this.label=value;},
  addEventListener(){}
 }));
 const context=createContext({document:{getElementById:get,querySelectorAll(selector){return selector==='[data-payment-channel]'?channels:[];}},
  window:{scrollTo(){}},location:{pathname},history:{replaceState(){}},calls});
 runInContext(definitions,context);
 return {get,channels,calls,run:code=>runInContext(code,context)};
}

for(const path of ['/','/admin','/signin','/register']){
test('startup loads public data only after sign-in pages are left: '+path,async()=>{
  const f=fixture(path);
  // Keep the real initial payment-state renderer and real auth UI; isolate other
  // unrelated UI work. Unlike an empty-selector stub, this DOM includes the
  // two active gateway controls present on every portal page. Retired GSPAY
  // channels and the separate manual-bank flow are not public gateway tiles.
  f.run('bind=bindPasswordAuth=bindPaymentPreview=bindBonusBrandPreview=renderAdmin=renderSession=()=>{};applyLang=()=>renderPaymentPreview();refreshSession=async()=>calls.push("session");loadPublic=async()=>calls.push("public");refreshTickets=async()=>calls.push("tickets");');
  await f.run(startup);
  assert.deepEqual(f.calls,['/signin','/register'].includes(path)?['session']:['session','public']);
  assert.ok(f.channels.every(c=>/Maintenance/i.test(c.status.textContent)));
  if(path==='/register'){
   assert.equal(f.get('memberPhone').required,true);
   assert.equal(f.get('memberOtp').required,true);
  }
 });
}

test('unloaded channel labels render safely in all three languages',()=>{
 for(const lang of ['en','zh','ms']){
  const f=fixture();f.run('state.lang='+JSON.stringify(lang)+';renderPaymentPreview()');
  assert.ok(f.channels.every(c=>c.status.textContent.length>0 && c.label.length>0));
 }
});



test('member sign-in uses ID and password; Malaysian phone OTP is only required at registration',()=>{
 const member=fixture('/signin');
 member.run('state.authMode="login";renderAuthMode()');
 assert.equal(member.get('usernameField').hidden,false);
 assert.equal(member.get('passwordField').hidden,false);
 assert.equal(member.get('authPassword').required,true);
 assert.equal(member.get('phoneField').hidden,true);
 assert.equal(member.get('memberPhone').required,false);
 assert.equal(member.get('otpFields').hidden,true);
 assert.equal(member.get('memberOtp').required,false);
 assert.equal(member.get('confirmPasswordField').hidden,true);
 const registration=fixture('/register');
 registration.run('state.authMode="register";renderAuthMode()');
 assert.equal(registration.get('passwordField').hidden,false);
 assert.equal(registration.get('confirmPasswordField').hidden,false);
 assert.equal(registration.get('confirmPassword').required,true);
 const owner=fixture('/admin');
 owner.run('state.authMode="login";renderAuthMode()');
 assert.equal(owner.get('passwordField').hidden,false);
 assert.equal(owner.get('phoneField').hidden,true);
 assert.equal(owner.get('otpFields').hidden,true);
});
