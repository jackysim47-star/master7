import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createContext,runInContext} from 'node:vm';

const full=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const split=full.indexOf('(async function start(){');
const startupEnd=full.indexOf('\n\nif(typeof navigator',split);
const definitions=full.slice(0,split),startup=full.slice(split,startupEnd);

function fixture(pathname='/'){
 const elements=new Map(),calls=[];
 const get=id=>{
  if(!elements.has(id))elements.set(id,{value:'',textContent:'',hidden:false,open:false,handlers:{},dataset:{},attributes:{},classList:{toggle(){}},
   addEventListener(name,fn){this.handlers[name]=fn;},setAttribute(name,value){this.attributes[name]=String(value);this[name]=String(value);},getAttribute(name){return this.attributes[name]??null;},showModal(){this.open=true;},reset(){for(const e of elements.values())e.value='';}});
  return elements.get(id);
 };
 const channels=['vpay','1mpay'].map(code=>({
  dataset:{paymentChannel:code},hidden:false,label:'',status:{textContent:''},
  querySelector(selector){assert.equal(selector,'.payment-state');return this.status;},
  setAttribute(name,value){
   assert.ok(['aria-disabled','title','aria-label'].includes(name));
   if(name==='aria-label')this.label=value;
   else this[name]=String(value);
  },
  addEventListener(){}
 }));
 const context=createContext({document:{getElementById:get,querySelectorAll(selector){return selector==='[data-payment-channel]'?channels:[];}},
  window:{scrollTo(){}},location:{pathname},history:{replaceState(){}},calls});
 runInContext(definitions,context);
 return {get,channels,calls,run:code=>runInContext(code,context)};
}

for(const path of ['/','/admin','/admin/','/admin/commission','/signin','/signin/','/register','/register/']){
test('startup loads public data only after sign-in pages are left: '+path,async()=>{
  const f=fixture(path);
  // Keep the real initial payment-state renderer and real auth UI; isolate other
  // unrelated UI work. Unlike an empty-selector stub, this DOM includes the
  // two active gateway controls present on every portal page. Retired GSPAY
  // channels and the separate manual-bank flow are not public gateway tiles.
  f.run('bind=bindPasswordAuth=bindPaymentPreview=bindBonusBrandPreview=renderAdmin=renderSession=()=>{};applyLang=()=>renderPaymentPreview();refreshSession=async()=>calls.push("session");loadPublic=async()=>calls.push("public");refreshTickets=async()=>calls.push("tickets");');
  await f.run(startup);
  const signedOutEntry=['/signin','/signin/','/register','/register/','/admin','/admin/','/admin/commission'].includes(path);
  assert.deepEqual(f.calls,signedOutEntry?['session']:['session','public']);
  if(path.startsWith('/admin'))assert.equal(f.get('authDialog').open,true);
  assert.ok(f.channels.every(c=>/Unavailable/i.test(c.status.textContent)));
  if(path==='/register'||path==='/register/'){
   assert.equal(f.get('memberPhone').required,true);
   assert.equal(f.get('memberOtp').required,true);
  }
 });
}

test('unloaded channel labels render safely in all three languages',()=>{
 for(const lang of ['en','zh','ms']){
  const f=fixture();f.run('state.lang='+JSON.stringify(lang)+';renderPaymentPreview()');
  assert.ok(f.channels.every(c=>c.status.textContent.length>0 && c.label.length>0));
 }
});

test('legacy active controls never advertise unavailable API orders as available',()=>{
 const f=fixture();
 f.run('state.lang="en";state.paymentChannels={vpay:"active","1mpay":"active"};state.paymentStatus={orderReady:false};state.oneMpayStatus={orderReady:false};renderPaymentPreview()');
 assert.ok(f.channels.every(c=>c.status.textContent==='Unavailable'));
 f.run('state.paymentStatus={orderReady:true};state.oneMpayStatus={orderReady:true};renderPaymentPreview()');
 assert.ok(f.channels.every(c=>c.status.textContent==='Available'));
});



test('member sign-in uses ID, password and OTP; the phone number is entered only during registration',()=>{
 const member=fixture('/signin');
 member.run('state.authMode="login";renderAuthMode()');
 assert.equal(member.get('usernameField').hidden,false);
 assert.equal(member.get('passwordField').hidden,false);
 assert.equal(member.get('authPassword').required,true);
 assert.equal(member.get('phoneField').hidden,true);
 assert.equal(member.get('memberPhone').required,false);
 assert.equal(member.get('otpFields').hidden,false);
 assert.equal(member.get('memberOtp').required,true);
 assert.equal(member.get('confirmPasswordField').hidden,true);
 const registration=fixture('/register');
 registration.run('state.authMode="register";renderAuthMode()');
 assert.equal(registration.get('passwordField').hidden,false);
 assert.equal(registration.get('confirmPasswordField').hidden,false);
 assert.equal(registration.get('confirmPassword').required,true);
 const owner=fixture('/admin');
 owner.run('state.authMode="login";renderAuthMode()');
 assert.equal(owner.get('passwordField').hidden,false);
 assert.equal(owner.get('phoneField').hidden,true);
 assert.equal(owner.get('otpFields').hidden,true);
});
