import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createContext,runInContext} from 'node:vm';

const full=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const split=full.indexOf('(async function start(){');
const definitions=full.slice(0,split),startup=full.slice(split);

function fixture(pathname='/'){
 const elements=new Map(),calls=[];
 const get=id=>{
  if(!elements.has(id))elements.set(id,{value:'',textContent:'',hidden:false,open:false,handlers:{},dataset:{},classList:{toggle(){}},
   addEventListener(name,fn){this.handlers[name]=fn;},showModal(){this.open=true;},reset(){for(const e of elements.values())e.value='';}});
  return elements.get(id);
 };
 const channels=['vpay','gspay','1mpay','gspay-plus'].map(code=>({
  dataset:{paymentChannel:code},hidden:false,label:'',status:{textContent:''},
  querySelector(selector){assert.equal(selector,'.payment-state');return this.status;},
  setAttribute(name,value){assert.equal(name,'aria-label');this.label=value;},
  addEventListener(){}
 }));
 const context=createContext({document:{getElementById:get,querySelectorAll(selector){return selector==='[data-payment-channel]'?channels:[];}},
  window:{scrollTo(){}},location:{pathname},history:{replaceState(){}},calls});
 runInContext(definitions,context);
 return {get,channels,calls,run:code=>runInContext(code,context)};
}

for(const path of ['/','/admin','/signin','/register']){
 test('startup reaches session and public loading before channel data arrives: '+path,async()=>{
  const f=fixture(path);
  // Keep the real initial payment-state renderer and real auth UI; isolate other
  // unrelated UI work. Unlike an empty-selector stub, this DOM includes the
  // four controls present on every portal page.
  f.run('bind=bindPasswordAuth=bindPaymentPreview=bindBonusBrandPreview=renderAdmin=renderSession=()=>{};applyLang=()=>renderPaymentPreview();refreshSession=async()=>calls.push("session");loadPublic=async()=>calls.push("public");refreshTickets=async()=>calls.push("tickets");');
  await f.run(startup);
  assert.deepEqual(f.calls,['session','public']);
  assert.ok(f.channels.every(c=>/Maintenance/i.test(c.status.textContent)));
  if(path==='/register'){
   assert.equal(f.get('memberPhone').required,true);
   assert.equal(f.get('memberOtp').required,true);
  }
 });
}

test('unloaded channel labels render safely in all three languages',()=>{
 for(const lang of ['en','zh','ms']){
  const f=fixture();f.run('state.lang='+JSON.stringify(lang)+';renderPaymentPreview()');
  assert.ok(f.channels.every(c=>c.status.textContent.length>0 && c.label.length>0));
 }
});

