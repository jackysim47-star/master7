import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {buildPersonalizedLobby,defaultEngagementProgram,getAdminEngagement,getPublicEngagement,saveEngagementProgram,validateEngagementProgram} from '../lib/engagement.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}
function fixture(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec("CREATE TABLE settings(id TEXT PRIMARY KEY,value TEXT NOT NULL);CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL);");
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(statements){sqlite.exec('BEGIN');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 return {sqlite,db};
}
const clone=value=>structuredClone(value);

test('engagement defaults are truthful, disabled, and contain no invented competition or money data',async()=>{
 const {db}=fixture(),admin=await getAdminEngagement(db),publicView=await getPublicEngagement(db);
 assert.equal(admin.configured,false);assert.equal(admin.storage,'engagement_program_v1');assert.equal(admin.program.enabled,false);assert.equal(admin.providers.length,37);assert.deepEqual(admin.providers[0],{id:'megah5',name:'MegaH5'});
 assert.deepEqual([admin.program.tournament.enabled,admin.program.depositSpin.enabled,admin.program.jackpot.enabled,admin.program.luckyDraw.enabled,admin.program.personalizedLobby.enabled,admin.program.notificationCenter.enabled],[false,false,false,false,false,false]);
 assert.equal(admin.readiness.tournament.scoreSource,'not_connected');assert.equal(admin.readiness.tournament.wagerSource,'not_connected');assert.deepEqual(admin.readiness.tournament.leaderboard,[]);assert.equal(admin.readiness.tournament.awardsEnabled,false);
 assert.equal(admin.readiness.depositSpin.qualificationSource,'credited_deposit_orders');assert.equal(admin.readiness.depositSpin.spinLedger,'not_connected');assert.equal(admin.readiness.depositSpin.randomDrawSource,'not_connected');assert.equal(admin.readiness.depositSpin.awardsEnabled,false);assert.equal(admin.readiness.depositSpin.walletCredit,false);
 for(const draw of [admin.readiness.jackpot,admin.readiness.luckyDraw]){assert.equal(draw.poolAmount,null);assert.equal(draw.drawEnabled,false);assert.equal(draw.randomDrawSource,'not_connected');assert.equal(draw.auditSource,'not_connected');assert.equal(draw.walletCredit,false);}
 assert.equal(admin.automaticRewards,false);assert.equal(admin.walletCredit,false);assert.equal(admin.moneyMovement,false);assert.equal(publicView.updatedAt,undefined);assert.equal(publicView.updatedBy,undefined);assert.equal(publicView.storage,undefined);
});

test('engagement validation is exact and accepts only supported cadences, categories, providers, and periods',()=>{
 const valid=defaultEngagementProgram();valid.tournament={...valid.tournament,enabled:true,cadence:'monthly',category:'fish',startsAt:'2026-11-01T00:00:00.000Z',endsAt:'2026-12-01T00:00:00.000Z'};valid.personalizedLobby={enabled:true,ownerCuratedProviders:['jili','bg'],maxItems:8};
 assert.deepEqual(validateEngagementProgram(valid),valid);
 const cases=[];
 const extra=clone(valid);extra.automaticRewards=true;cases.push(extra);
 const cadence=clone(valid);cadence.tournament.cadence='daily';cases.push(cadence);
 const category=clone(valid);category.tournament.category='cock';cases.push(category);
 const partialPeriod=clone(valid);partialPeriod.jackpot.startsAt='2026-11-01T00:00:00.000Z';cases.push(partialPeriod);
 const reversed=clone(valid);reversed.tournament.endsAt='2026-10-01T00:00:00.000Z';cases.push(reversed);
 const unknownProvider=clone(valid);unknownProvider.personalizedLobby.ownerCuratedProviders=['unknown'];cases.push(unknownProvider);
 const duplicateProvider=clone(valid);duplicateProvider.personalizedLobby.ownerCuratedProviders=['jili','jili'];cases.push(duplicateProvider);
 const invalidSpin=clone(valid);invalidSpin.depositSpin.spinsPerDeposit=0;cases.push(invalidSpin);
 for(const item of cases)assert.throws(()=>validateEngagementProgram(item));
});

test('owner save writes only settings and audit while executable capabilities remain disabled',async()=>{
 const {sqlite,db}=fixture(),program=defaultEngagementProgram();program.enabled=true;program.tournament.enabled=true;program.depositSpin={enabled:true,title:'Deposit Lucky Wheel',minDepositMYR:50,spinsPerDeposit:1,dailySpinCap:3,turnoverMultiplier:20,prizeNote:'Owner-approved display note.'};program.jackpot.enabled=true;program.luckyDraw.enabled=true;program.personalizedLobby={enabled:true,ownerCuratedProviders:['jili','bg'],maxItems:4};program.notificationCenter={enabled:true,tickets:true,financial:true,systemStatus:true,sound:true};
 const saved=await saveEngagementProgram(db,'owner-1',{program},1777777777);assert.equal(saved.status,'ok');assert.equal(saved.configured,true);assert.equal(saved.updatedBy,'owner-1');assert.equal(saved.readiness.tournament.published,true);assert.deepEqual(saved.readiness.tournament.leaderboard,[]);assert.equal(saved.readiness.tournament.awardsEnabled,false);assert.equal(saved.readiness.depositSpin.published,true);assert.equal(saved.readiness.depositSpin.spinLedger,'not_connected');assert.equal(saved.readiness.depositSpin.awardsEnabled,false);assert.equal(saved.readiness.jackpot.drawEnabled,false);assert.equal(saved.readiness.luckyDraw.drawEnabled,false);assert.equal(saved.automaticRewards,false);assert.equal(saved.walletCredit,false);assert.equal(saved.moneyMovement,false);
 const stored=JSON.parse(sqlite.prepare("SELECT value FROM settings WHERE id='engagement_program_v1'").get().value);assert.deepEqual({...stored,updatedAt:undefined,updatedBy:undefined},{...program,updatedAt:undefined,updatedBy:undefined});assert.equal(stored.updatedAt,1777777777);assert.equal(stored.updatedBy,'owner-1');
 const audit=sqlite.prepare("SELECT user_id,event,target,created_at FROM audit WHERE event='engagement_program_updated'").get();assert.equal(audit.user_id,'owner-1');assert.equal(audit.created_at,1777777777);assert.deepEqual(JSON.parse(audit.target),{version:1,enabled:true,modules:{tournament:true,depositSpin:true,jackpot:true,luckyDraw:true,personalizedLobby:true,notificationCenter:true},automaticRewards:false,walletCredit:false});
 const publicView=await getPublicEngagement(db);assert.deepEqual(publicView.program,program);assert.equal(publicView.readiness.notificationCenter.model,'existing_records_only');assert.equal(publicView.readiness.notificationCenter.copiesRecords,false);
});

test('disabled event drafts stay private and every public notification state follows the master display switch',async()=>{
 const {db}=fixture(),program=defaultEngagementProgram();program.enabled=false;
 program.tournament={...program.tournament,enabled:true,title:'PRIVATE TOURNAMENT DRAFT',eligibilityNote:'PRIVATE ELIGIBILITY',prizeNote:'PRIVATE PRIZE'};
 program.depositSpin={...program.depositSpin,enabled:true,title:'PRIVATE SPIN DRAFT',prizeNote:'PRIVATE SPIN PRIZE'};
 program.jackpot={...program.jackpot,enabled:true,title:'PRIVATE JACKPOT DRAFT',entryNote:'PRIVATE ENTRY',prizeNote:'PRIVATE JACKPOT PRIZE'};
 program.personalizedLobby={enabled:true,ownerCuratedProviders:['jili','bg'],maxItems:3};
 program.notificationCenter={enabled:true,tickets:true,financial:true,systemStatus:true,sound:true};
 await saveEngagementProgram(db,'owner-private',{program},1777777777);
 const admin=await getAdminEngagement(db),publicView=await getPublicEngagement(db),serialized=JSON.stringify(publicView);
 assert.equal(admin.program.tournament.title,'PRIVATE TOURNAMENT DRAFT');
 for(const privateText of ['PRIVATE TOURNAMENT DRAFT','PRIVATE ELIGIBILITY','PRIVATE PRIZE','PRIVATE SPIN DRAFT','PRIVATE SPIN PRIZE','PRIVATE JACKPOT DRAFT','PRIVATE ENTRY','PRIVATE JACKPOT PRIZE'])assert.equal(serialized.includes(privateText),false,privateText);
 assert.equal(publicView.program.enabled,false);assert.deepEqual(publicView.program.tournament,defaultEngagementProgram().tournament);assert.deepEqual(publicView.program.personalizedLobby,defaultEngagementProgram().personalizedLobby);
 assert.equal(publicView.readiness.notificationCenter.published,false);assert.equal(publicView.readiness.notificationCenter.sound,false);assert.ok(publicView.readiness.notificationCenter.sources.every(source=>source.enabled===false));

 const oneModuleOff=structuredClone(program);oneModuleOff.enabled=true;oneModuleOff.tournament.enabled=false;oneModuleOff.tournament.title='PRIVATE DISABLED MODULE';await saveEngagementProgram(db,'owner-private',{program:oneModuleOff},1777777778);
 assert.equal(JSON.stringify(await getPublicEngagement(db)).includes('PRIVATE DISABLED MODULE'),false);
});

test('personalized lobby uses only local favorite, local recent, and owner-curated providers',()=>{
 const program=defaultEngagementProgram();assert.deepEqual(buildPersonalizedLobby(program,{favorites:['jili']}),[]);program.enabled=true;program.personalizedLobby={enabled:true,ownerCuratedProviders:['bg','megah5'],maxItems:4};
 const items=buildPersonalizedLobby(program,{favorites:['jili','bg','fake'],recent:['bg','pgsoft','jili']});assert.deepEqual(items,[{id:'jili',name:'JILI',sources:['local_favorite','local_recent']},{id:'bg',name:'BG',sources:['local_favorite','local_recent','owner_curated']},{id:'pgsoft',name:'PGSOFT',sources:['local_recent']},{id:'megah5',name:'MegaH5',sources:['owner_curated']}]);
 assert.equal(JSON.stringify(items).includes('wager'),false);assert.equal(JSON.stringify(items).includes('amount'),false);
});

test('invalid stored engagement settings fail closed instead of falling back to fake data',async()=>{
 const {sqlite,db}=fixture();sqlite.prepare('INSERT INTO settings(id,value) VALUES(?,?)').run('engagement_program_v1',JSON.stringify({...defaultEngagementProgram(),updatedAt:1,updatedBy:'owner',jackpot:{...defaultEngagementProgram().jackpot,drawEnabled:true}}));
 await assert.rejects(()=>getAdminEngagement(db),error=>error?.status===503);
});

test('stored pre-wheel settings gain the disabled deposit spin default without losing other modules',async()=>{
 const {sqlite,db}=fixture(),legacy={...defaultEngagementProgram(),updatedAt:2,updatedBy:'owner'};delete legacy.depositSpin;sqlite.prepare('INSERT INTO settings(id,value) VALUES(?,?)').run('engagement_program_v1',JSON.stringify(legacy));const loaded=await getAdminEngagement(db);assert.deepEqual(loaded.program.depositSpin,defaultEngagementProgram().depositSpin);assert.equal(loaded.program.tournament.title,legacy.tournament.title);
});
