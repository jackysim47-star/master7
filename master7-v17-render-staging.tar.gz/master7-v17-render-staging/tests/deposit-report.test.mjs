import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handleVPay} from '../lib/vpay.ts';
import {readDepositReport} from '../lib/deposit-report.ts';

const start=Date.parse('2026-11-07T16:00:00Z')/1000,end=start+86400;

function fixture(t){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 for(const id of ['alice','bob','charlie'])sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,'member',1,'fixture',0)").run(id,id);
 const activity={reads:0,writes:0,network:0};
 class Statement{
  constructor(sql,args=[]){this.sql=sql;this.args=args;}
  bind(...args){return new Statement(this.sql,args);}
  async first(){activity.reads++;return sqlite.prepare(this.sql).get(...this.args)??null;}
  async all(){activity.reads++;return {results:sqlite.prepare(this.sql).all(...this.args)};}
  async run(){activity.writes++;throw Error('report attempted a write');}
 }
 const db={prepare(sql){assert.match(sql,/^SELECT\b/,'report must only prepare SELECT statements');return new Statement(sql);},async batch(){activity.writes++;throw Error('report attempted a batch');}};
 const context={db,user:{id:'owner',username:'owner',role:'owner',approved:1,csrf:'fixture'},fetchImpl:async()=>{activity.network++;throw Error('report must not contact a provider');}};
 const insert=sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,'fixture',?,?,'MYR','fixture',?,?,?)");
 function add(id,{user='alice',provider='vpay',amount=1000,status='credited',created=start,updated=start}={}){insert.run(id,user,id,provider,amount,status,created,updated);}
 async function call(query='',user=context.user){const response=await handleVPay(new Request('https://portal.example.test/api/admin/deposits'+query),{...context,user});return {status:response.status,data:await response.json()};}
 function freeze(){sqlite.exec('PRAGMA query_only=ON');return sqlite.prepare('SELECT total_changes() changes').get().changes;}
 t.after(()=>sqlite.close());return {sqlite,db,context,activity,add,call,freeze};
}

test('MYT daily totals use bounded settlement time, include old orders credited today, and exclude every unsettled state',async t=>{
 const f=fixture(t);
 f.add('before',{amount:9901,updated:start-1});
 f.add('at-start',{amount:1000,created:start-86400,updated:start});
 f.add('old-now-credited',{provider:'manual_bank',amount:2500,created:start-3*86400,updated:start+1});
 f.add('at-last-second',{user:'bob',provider:'gspay',amount:750,updated:end-1});
 f.add('at-end',{user:'bob',provider:'1mpay',amount:9000,updated:end});
 for(const [index,status] of ['pending','creating','created','unknown'].entries())f.add('unsettled-'+status,{user:index%2?'alice':'bob',amount:3000+index*1000,status,updated:start+index+5});
 f.add('failed',{amount:777,status:'failed',updated:start+9});
 f.add('review',{user:'bob',amount:888,status:'review',updated:start+10});
 const before=f.freeze(),report=await readDepositReport(f.db,new URLSearchParams(),start+600);
 assert.equal(report.date,'2026-11-08');assert.equal(report.timezone,'Asia/Kuching');assert.equal(report.start,start);assert.equal(report.end,end);
 assert.equal(report.timestampBasis,'updated_at');assert.equal(report.statusMeaning,'current_status');
 assert.deepEqual(report.summary.credited,{orders:3,members:2,amountMinor:'4250'});
 assert.deepEqual(report.summary.pending,{orders:4,members:2,amountMinor:'18000'});
 assert.deepEqual(report.summary.failed,{orders:1,members:1,amountMinor:'777'});
 assert.deepEqual(report.summary.review,{orders:1,members:1,amountMinor:'888'});
 assert.deepEqual(report.providers.find(row=>row.provider==='manual_bank').credited,{orders:1,members:1,amountMinor:'2500'});
 assert.equal(report.pagination.total,9);assert.equal(report.items.length,9);
 assert.ok(report.items.some(row=>row.id==='at-start'));assert.ok(report.items.some(row=>row.id==='old-now-credited'));assert.ok(report.items.some(row=>row.id==='at-last-second'));
 assert.ok(!report.items.some(row=>['before','at-end'].includes(row.id)));
 assert.equal(f.sqlite.prepare('SELECT total_changes() changes').get().changes,before);assert.equal(f.activity.writes,0);assert.equal(f.activity.network,0);
});

test('a selected MYT date has the same bounded totals and empty days return explicit zero pagination',async t=>{
 const f=fixture(t);f.add('yesterday',{amount:1234,updated:start-1});f.add('today',{amount:5678,updated:start});f.freeze();
 const yesterday=await f.call('?date=2026-11-07&pageSize=1');assert.equal(yesterday.status,200);assert.equal(yesterday.data.summary.credited.amountMinor,'1234');assert.equal(yesterday.data.items[0].id,'yesterday');
 const empty=await f.call('?date=2026-11-06&page=8');assert.equal(empty.status,200);assert.equal(empty.data.summary.credited.amountMinor,'0');assert.deepEqual(empty.data.providers,[]);assert.deepEqual(empty.data.items,[]);
 assert.deepEqual(empty.data.pagination,{total:0,page:1,pageSize:100,totalPages:1,hasMore:false,hasPrevious:false});
});

test('all history beyond 500 records is accessible and every page retains the full totals and provider breakdown',async t=>{
 const f=fixture(t),providers=['vpay','1mpay','gspay','manual_bank'];let amount=0n,credited=0;
 for(let index=0;index<603;index++){const status=index%4===0?'pending':'credited',minor=1000+index;if(status==='credited'){amount+=BigInt(minor);credited++;}f.add('report-'+String(index).padStart(4,'0'),{user:['alice','bob','charlie'][index%3],provider:providers[index%4],amount:minor,status,updated:start+(index%3)*86400});}
 const before=f.freeze(),ids=new Set();let summary,breakdown;
 for(let page=1;page<=3;page++){
  const response=await f.call('?scope=all&pageSize=250&page='+page),data=response.data;assert.equal(response.status,200);assert.equal(data.readOnly,true);assert.equal(data.scope,'all');assert.equal(data.start,null);assert.equal(data.end,null);
  assert.deepEqual(data.summary.credited,{orders:credited,members:3,amountMinor:amount.toString()});assert.equal(data.pagination.total,603);assert.equal(data.pagination.page,page);assert.equal(data.pagination.pageSize,250);assert.equal(data.pagination.totalPages,3);assert.equal(data.pagination.hasMore,page<3);assert.equal(data.pagination.hasPrevious,page>1);assert.equal(data.items.length,page<3?250:103);
  if(summary){assert.deepEqual(data.summary,summary);assert.deepEqual(data.providers,breakdown);}else{summary=data.summary;breakdown=data.providers;}
  for(const item of data.items){assert.ok(!ids.has(item.id),'pages must not duplicate rows with identical timestamps');ids.add(item.id);assert.equal(typeof item.amount_minor,'string');}
 }
 assert.equal(ids.size,603);assert.ok(ids.has('report-0000'));assert.ok(ids.has('report-0602'));assert.ok(breakdown.some(row=>row.provider==='manual_bank'));
 const clamped=await f.call('?scope=all&pageSize=250&page=99');assert.equal(clamped.data.pagination.page,3);assert.equal(clamped.data.items.length,103);
 assert.equal(f.sqlite.prepare('SELECT total_changes() changes').get().changes,before);assert.equal(f.activity.writes,0);assert.equal(f.activity.network,0);
});

test('only an owner can read deposit reports; unauthorized callers cannot trigger any database or provider work',async t=>{
 const f=fixture(t);f.freeze();
 for(const [user,status] of [[null,401],[{role:'member',id:'alice'},403],[{role:'staff',id:'staff'},403]]){
  const response=await f.call('',user);assert.equal(response.status,status);assert.deepEqual(Object.keys(response.data),['error']);
 }
 assert.equal(f.activity.reads,0);assert.equal(f.activity.writes,0);assert.equal(f.activity.network,0);
 assert.equal((await f.call()).status,200);assert.equal(f.activity.writes,0);assert.equal(f.activity.network,0);
});

test('invalid report dates, scopes and unbounded pagination fail before reading data',async t=>{
 const f=fixture(t);f.freeze();
 for(const query of ['?date=2026-02-30','?date=2026-2-3','?scope=month','?page=0','?page=-1','?page=1.5','?page=9007199254740992','?pageSize=0','?pageSize=251','?pageSize=abc'])assert.equal((await f.call(query)).status,400,query);
 assert.equal(f.activity.reads,0);assert.equal(f.activity.writes,0);assert.equal(f.activity.network,0);
});
