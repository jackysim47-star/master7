import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {authorizeDepositIncidentRead,readDepositIncidentSnapshot} from '../lib/deposit-incident-evidence.ts';
import {handle,RELEASE} from '../lib/backend.ts';

const token='d'.repeat(64),hash=createHash('sha256').update(token).digest('hex'),stamp=1794200000;
const order=(id,more={})=>({id,user_id:'member-one',provider:'vpay',amount_minor:'2000',currency:'MYR',status:'unknown',provider_trade_no:null,checkout_url:null,created_at:stamp,updated_at:stamp,...more});
function fixture({orders=[order('old-order')],ledger=[],audits=[],manual=[],totals=[],failAt,rollbackFails=false,releaseFails=false}={}){
 const calls=[],released=[];
 const client={async query(sql,values=[]){calls.push({sql,values});if(sql===failAt||sql==='ROLLBACK'&&rollbackFails)throw Error('synthetic read failed');
  if(sql.startsWith('SELECT current_database'))return {rows:[{database_name:'isolated_fixture',observed_at:String(stamp+10)}]};
  if(sql.includes('GROUP BY'))return {rows:totals};if(sql.includes('FROM deposit_orders ORDER'))return {rows:orders};if(sql.includes('FROM wallet_ledger'))return {rows:ledger};if(sql.includes('FROM audit'))return {rows:audits};if(sql.includes('FROM manual_deposit_requests'))return {rows:manual};return {rows:[]};},release(destroy){released.push(destroy);if(releaseFails)throw Error('synthetic release failed');}};
 return {calls,released,pool:{async connect(){return client;}}};
}
const event=(detail,more={})=>({id:'diagnostic-id',user_id:'member-one',event:'payment_order_diagnostic',target:JSON.stringify(detail),created_at:stamp+1,...more});
const leg=(account,amount,more={})=>({id:'ledger-'+account,order_id:'old-order',user_id:'member-one',account_code:account,amount_minor:String(amount),currency:'MYR',created_at:stamp+1,...more});

test('incident authorization requires a separate exact bearer and a bounded unexpired lifetime',()=>{
 assert.equal(authorizeDepositIncidentRead('Bearer '+token,hash,stamp+60,stamp),true);
 for(const [auth,h,e] of [[null,hash,stamp+60],['Bearer '+token+'x',hash,stamp+60],['Bearer '+'e'.repeat(64),hash,stamp+60],['Bearer '+token,undefined,stamp+60],['Bearer '+token,hash,stamp],['Bearer '+token,hash,stamp+3601],['Bearer '+token,hash,String(stamp+60)],['Bearer '+token,'x'.repeat(64),stamp+60]])assert.equal(authorizeDepositIncidentRead(auth,h,e,stamp),false);
});
test('missing, expired or wrong authorization performs zero database reads and zero provider requests',async()=>{
 let reads=0;const db={prepare(){throw Error('no database read');},readDepositIncidents(){reads++;throw Error('no incident read');}};
 for(const headers of [{},{authorization:'Bearer '+'e'.repeat(64)}]){const r=await handle(new Request('https://portal.test/api/internal/deposit-incidents',{headers}),{db,identity:null,ownerEmail:'owner@test',depositIncidentTokenHash:hash,depositIncidentExpiresAt:Math.floor(Date.now()/1000)+60});assert.equal(r.status,401);assert.equal(r.headers.get('cache-control'),'no-store');}
 assert.equal(reads,0);
});
test('authorized endpoint is GET-only, rejects all query scope and never reads authentication tables',async()=>{
 let reads=0;const context={db:{prepare(){throw Error('no session read');},async readDepositIncidents(){reads++;return {readOnly:true,items:[]};}},identity:null,ownerEmail:'owner@test',depositIncidentTokenHash:hash,depositIncidentExpiresAt:Math.floor(Date.now()/1000)+60};
 for(const [method,suffix,status] of [['POST','',405],['GET','?sql=DROP',400],['GET','?orderId=other',400],['GET','',200]]){const r=await handle(new Request('https://portal.test/api/internal/deposit-incidents'+suffix,{method,headers:{authorization:'Bearer '+token}}),context);assert.equal(r.status,status);if(status===200)assert.deepEqual(await r.json(),{release:RELEASE,sourceRelease:RELEASE,evidence:{readOnly:true,items:[]}});}
 assert.equal(reads,1);
});
test('unsupported storage fails closed instead of reading through an unprotected database path',async()=>{
 const r=await handle(new Request('https://portal.test/api/internal/deposit-incidents',{headers:{authorization:'Bearer '+token}}),{db:{prepare(){throw Error('no query');}},identity:null,ownerEmail:'owner@test',depositIncidentTokenHash:hash,depositIncidentExpiresAt:Math.floor(Date.now()/1000)+60});assert.equal(r.status,503);
});
test('fixed read-only snapshot identifies explicit provider order rejection and excludes signing material',async()=>{
 const f=fixture({audits:[event({provider:'vpay',orderId:'old-order',kind:'GATEWAY_HTTP',httpStatus:502,upstreamStatus:200,providerCode:-1,secretKey:'DO-NOT-EXPORT',checkoutToken:'DO-NOT-EXPORT',gatewayError:'RAW-ERROR-DO-NOT-EXPORT'})]});
 const r=await readDepositIncidentSnapshot(f.pool),item=r.items[0];assert.equal(item.finding,'B_provider_order_rejected');assert.equal(item.ledger.verifiedCredit,false);assert.equal(item.callbackEvidence,'no_dedicated_callback_evidence');assert.equal(item.providerPaymentVerified,false);assert.equal(item.frontendBalanceVerified,false);assert.equal(r.readConsistency,'transaction_snapshot');assert.doesNotMatch(JSON.stringify(r),/DO-NOT-EXPORT|member-one/);assert.equal(f.calls[0].sql,'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');assert.equal(f.calls.at(-1).sql,'ROLLBACK');assert.deepEqual(f.released,[false]);assert.ok(f.calls.every(c=>/^(BEGIN|SET LOCAL|SELECT|ROLLBACK)/.test(c.sql)));
});
test('the latest uncertain diagnostic cannot be overridden by an older business rejection',async()=>{
 const f=fixture({audits:[event({provider:'vpay',orderId:'old-order',kind:'TIMEOUT'},{id:'new',created_at:stamp+2}),event({provider:'vpay',orderId:'old-order',kind:'ORDER_RESPONSE',providerCode:-1})]});const r=await readDepositIncidentSnapshot(f.pool);assert.equal(r.items[0].finding,'after_order_payment_and_callback_not_verified');
});
test('checkout and provider references are evidence of creation, never proof of payment',async()=>{
 const f=fixture({orders:[order('old-order',{provider_trade_no:'trade-123',checkout_url:'https://cashier.test/pay?secret=DO-NOT-EXPORT'})],audits:[event({provider:'vpay',orderId:'old-order',kind:'ORDER_RESPONSE',providerCode:-1})]});const r=await readDepositIncidentSnapshot(f.pool);assert.equal(r.items[0].finding,'after_order_payment_and_callback_not_verified');assert.equal(r.items[0].checkoutHost,'cashier.test');assert.equal(r.items[0].providerTransactionId,'trade-123');assert.doesNotMatch(JSON.stringify(r),/DO-NOT-EXPORT/);
});
test('a balanced credit proves stored wallet posting and leaves callback and frontend unverified',async()=>{
 const f=fixture({orders:[order('old-order',{status:'credited'})],ledger:[leg('member',2000),leg('provider_clearing',-2000)],audits:[event(null,{event:'deposit_credited',target:'old-order'})]});const item=(await readDepositIncidentSnapshot(f.pool)).items[0];assert.equal(item.finding,'wallet_credit_recorded_frontend_not_verified');assert.equal(item.ledger.verifiedCredit,true);assert.equal(item.callbackEvidence,'no_dedicated_callback_evidence');assert.equal(item.frontendBalanceVerified,false);
});
for(const [name,legs] of [['partial',[leg('member',2000)]],['wrong amount',[leg('member',2000),leg('provider_clearing',-1)]],['wrong member',[leg('member',2000,{user_id:'other'}),leg('provider_clearing',-2000)]],['wrong currency',[leg('member',2000,{currency:'USDT'}),leg('provider_clearing',-2000)]]])test('ledger mismatch is explicit: '+name,async()=>{const item=(await readDepositIncidentSnapshot(fixture({orders:[order('old-order',{status:'credited'})],ledger:legs}).pool)).items[0];assert.equal(item.finding,'wallet_ledger_mismatch');assert.equal(item.ledger.verifiedCredit,false);});
test('credited status with zero ledger legs is not called a completed wallet credit',async()=>{const item=(await readDepositIncidentSnapshot(fixture({orders:[order('old-order',{status:'credited'})]}).pool)).items[0];assert.equal(item.finding,'credited_status_without_balanced_ledger');});
test('balanced ledger under a noncredited order requires review',async()=>{const item=(await readDepositIncidentSnapshot(fixture({ledger:[leg('member',2000),leg('provider_clearing',-2000)]}).pool)).items[0];assert.equal(item.finding,'wallet_ledger_present_order_status_conflict');assert.equal(item.ledger.verifiedCredit,false);});
test('a callback review is observed without claiming a verified paid callback',async()=>{const item=(await readDepositIncidentSnapshot(fixture({audits:[event(null,{event:'deposit_callback_review',target:'old-order'})]}).pool)).items[0];assert.equal(item.finding,'callback_review_wallet_credit_not_verified');assert.equal(item.callbackEvidence,'callback_review_event_present');assert.equal(item.providerPaymentVerified,false);});
test('malformed, wrong-provider and wrong-member diagnostics cannot prove a rejection',async()=>{for(const a of [event(null,{target:'malformed{'}),event({provider:'1mpay',orderId:'old-order',kind:'ORDER_RESPONSE',providerCode:-1}),event({provider:'vpay',orderId:'old-order',kind:'ORDER_RESPONSE',providerCode:-1},{user_id:'other'})]){const item=(await readDepositIncidentSnapshot(fixture({audits:[a]}).pool)).items[0];assert.equal(item.finding,'after_order_payment_and_callback_not_verified');}});
test('manual review exports no receipt, bank account or reviewer identity',async()=>{const r=await readDepositIncidentSnapshot(fixture({orders:[order('old-order',{provider:'manual_bank'})],manual:[{deposit_order_id:'old-order',review_recorded:true,receipt_data:'DO-NOT-EXPORT',reviewed_by:'DO-NOT-EXPORT',created_at:stamp,updated_at:stamp}],audits:[event(null,{event:'manual_bank_deposit_approved',target:'old-order',user_id:'owner'})]}).pool);assert.equal(r.items[0].manualReview.reviewRecorded,true);assert.equal(r.items[0].auditEvents.length,1);assert.doesNotMatch(JSON.stringify(r),/DO-NOT-EXPORT/);});
test('empty current database has explicit zero items rather than invented historical orders',async()=>{const f=fixture({orders:[]});const r=await readDepositIncidentSnapshot(f.pool);assert.deepEqual(r.items,[]);assert.deepEqual(r.summary,[]);assert.ok(f.calls.every(c=>!c.sql.includes('FROM wallet_ledger')&&!c.sql.includes('FROM audit')&&!c.sql.includes('FROM manual_deposit_requests')));});
test('bounded candidate reads report truncation and never claim complete coverage',async()=>{const orders=Array.from({length:1001},(_,i)=>order('order-'+i));const r=await readDepositIncidentSnapshot(fixture({orders}).pool);assert.equal(r.items.length,1000);assert.equal(r.coverage.ordersTruncated,true);});
test('database read failure rolls back and discards the client without a repair',async()=>{const f=fixture({failAt:"SET LOCAL statement_timeout = '5s'"});await assert.rejects(readDepositIncidentSnapshot(f.pool),/synthetic read failed/);assert.equal(f.calls.at(-1).sql,'ROLLBACK');assert.deepEqual(f.released,[true]);});
test('rollback failure discards the client and cannot return partial evidence',async()=>{const f=fixture({rollbackFails:true});await assert.rejects(readDepositIncidentSnapshot(f.pool),/synthetic read failed/);assert.deepEqual(f.released,[true]);});
test('read and cleanup failures are retained together',async()=>{const f=fixture({failAt:"SET LOCAL statement_timeout = '5s'",rollbackFails:true,releaseFails:true});await assert.rejects(readDepositIncidentSnapshot(f.pool),e=>e instanceof AggregateError&&e.errors.length===3);assert.deepEqual(f.released,[true]);});
test('audit candidate truncation is disclosed even if no candidate matches this order',async()=>{const audits=Array.from({length:10001},(_,i)=>event(null,{id:'event-'+i,target:'different-order'}));const r=await readDepositIncidentSnapshot(fixture({audits}).pool);assert.equal(r.coverage.auditCandidatesTruncated,true);assert.equal(r.items[0].callbackEvidence,'no_dedicated_callback_evidence');});
