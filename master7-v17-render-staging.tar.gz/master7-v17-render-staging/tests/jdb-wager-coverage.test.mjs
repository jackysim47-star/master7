import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {claimJdbWagerWindow,getJdbWagerCoverage,JdbWagerCoverageError,stageJdbWagerPage} from '../lib/jdb-wager-coverage.ts';

const BASE=Date.parse('2026-11-10T06:00:00Z'),owner={id:'owner',role:'owner'},staff={id:'staff',role:'staff'};

function d1(sqlite){
 const statement=(sql,values=[])=>({
  bind(...next){return statement(sql,next);},
  async all(){const rows=sqlite.prepare(sql).all(...values).map(row=>({...row}));return {results:rows,success:true,meta:{changes:rows.length}};},
  async first(){const row=sqlite.prepare(sql).get(...values);return row?{...row}:null;},
  async run(){const result=sqlite.prepare(sql).run(...values);return {results:[],success:true,meta:{changes:Number(result.changes)}};},
 });
 return {prepare:sql=>statement(sql),async batch(items){sqlite.exec('BEGIN');try{const results=[];for(const item of items)results.push(await item.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
}

function fixture(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());sqlite.exec('PRAGMA foreign_keys=ON');
 for(const file of ['0000_broken_bloodscream.sql','0110_game_provider_adapter_core.sql','0113_game_provider_acceptance_evidence.sql'])sqlite.exec(readFileSync(new URL(`../drizzle/${file}`,import.meta.url),'utf8'));
 sqlite.exec("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES('jdb_myr','jdb','JDB · MYR','jdb','transfer','cash','MYR',1,1,'production','closed',0,0)");
 sqlite.exec(readFileSync(new URL('../drizzle/0121_jdb_wager_coverage_staging.sql',import.meta.url),'utf8'));
 return {sqlite,db:d1(sqlite)};
}

const window=(offset=0,timeBasis='lastModifyTime')=>({profileId:'jdb_myr',timeBasis,from:BASE+offset,to:BASE+offset+60_000});
const wager=(id='bet-1',overrides={})=>({providerRoundId:`round-${id}`,providerBetId:id,providerPlayerId:'private-player',providerGameId:'0:100',betMinor:'100',winMinor:'40',currency:'MYR',settledAt:BASE+30_000,sourceDetails:{bet:'-1.00',win:'0.40',timeBasis:'lastModifyTime'},...overrides});
const page=(items)=>({items,complete:false});
const count=(sqlite,table)=>Number(sqlite.prepare(`SELECT COUNT(*) n FROM ${table}`).get().n);

test('claiming fails closed when the exact closed JDB parent profile is missing or altered',async t=>{
 const f=fixture(t);f.sqlite.prepare("DELETE FROM game_provider_profiles WHERE id='jdb_myr'").run();
 await assert.rejects(claimJdbWagerWindow(f.db,window(),{at:999,claimToken:'missing'}),error=>error instanceof JdbWagerCoverageError&&error.code==='JDB_WAGER_PROFILE_NOT_CLOSED');
 f.sqlite.exec("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES('jdb_myr','jdb','JDB · MYR','jdb','transfer','cash','MYR',1,1,'production','uat',0,0)");
 await assert.rejects(claimJdbWagerWindow(f.db,window(),{at:999,claimToken:'open'}),error=>error instanceof JdbWagerCoverageError&&error.code==='JDB_WAGER_PROFILE_NOT_CLOSED');
});

test('claims use an expiring generation fence and reject concurrent or stale workers',async t=>{
 const f=fixture(t),attempts=await Promise.allSettled(['first','parallel'].map(claimToken=>claimJdbWagerWindow(f.db,window(),{at:1000,leaseSeconds:5,claimToken}))),won=attempts.filter(result=>result.status==='fulfilled'),lost=attempts.filter(result=>result.status==='rejected');
 assert.equal(won.length,1);assert.equal(lost.length,1);assert.ok(lost[0].reason instanceof JdbWagerCoverageError);assert.equal(lost[0].reason.code,'JDB_WAGER_WINDOW_BUSY');
 const first=won[0].value;assert.equal(first.fence,1);
 const second=await claimJdbWagerWindow(f.db,window(),{at:1006,leaseSeconds:5,claimToken:'second'});
 assert.equal(second.fence,2);
 await assert.rejects(stageJdbWagerPage(f.db,first,page([wager()]),{at:1006}),error=>error instanceof JdbWagerCoverageError&&error.code==='JDB_WAGER_CLAIM_STALE');
 assert.equal(count(f.sqlite,'jdb_wager_receipts'),0);
 const stored=await stageJdbWagerPage(f.db,second,page([wager()]),{at:1006});
 assert.equal(stored.originalCount,1);assert.equal(stored.coverageComplete,false);
});

test('an exact page is idempotent across crash-style response loss and a new lease generation',async t=>{
 const f=fixture(t),input=page([wager('a'),wager('b'),wager('a')]),first=await claimJdbWagerWindow(f.db,window(),{at:2000,claimToken:'first'}),receipt=await stageJdbWagerPage(f.db,first,input,{at:2000});
 assert.equal(receipt.inputCount,3);assert.equal(receipt.uniqueInputCount,2);assert.equal(receipt.originalCount,2);assert.equal(receipt.duplicateCount,1);
 assert.equal(count(f.sqlite,'jdb_wager_receipts'),1);assert.equal(count(f.sqlite,'jdb_wager_event_versions'),2);
 const second=await claimJdbWagerWindow(f.db,window(),{at:2001,claimToken:'second'});
 await stageJdbWagerPage(f.db,first,input,{at:2001});
 assert.equal(f.sqlite.prepare("SELECT claim_token FROM game_recovery_leases WHERE resource_type='wager_sync'").get().claim_token,'second','a stale exact replay cannot release the newer fence');
 const replayed=await stageJdbWagerPage(f.db,second,page([wager('a'),wager('a'),wager('b')]),{at:2001});
 assert.equal(replayed.receiptId,receipt.receiptId);assert.equal(count(f.sqlite,'jdb_wager_receipts'),1);assert.equal(count(f.sqlite,'jdb_wager_event_versions'),2);assert.equal(count(f.sqlite,'jdb_wager_observations'),2);
 assert.equal(f.sqlite.prepare("SELECT claim_token FROM game_recovery_leases WHERE resource_type='wager_sync'").get().claim_token,'');
});

test('overlapping windows expose duplicates without writing accounting records',async t=>{
 const f=fixture(t),before=Object.fromEntries(['game_rounds','game_transactions','game_wallet_postings','game_provider_acceptance_events'].map(table=>[table,count(f.sqlite,table)]));
 const one=await claimJdbWagerWindow(f.db,{...window(),to:BASE+120_000},{at:3000,claimToken:'one'});await stageJdbWagerPage(f.db,one,page([wager()]),{at:3000});
 const two=await claimJdbWagerWindow(f.db,{...window(60_000),to:BASE+180_000},{at:3001,claimToken:'two'});const duplicate=await stageJdbWagerPage(f.db,two,page([wager()]),{at:3001});
 assert.equal(duplicate.duplicateCount,1);assert.equal(duplicate.originalCount,0);
 for(const [table,value] of Object.entries(before))assert.equal(count(f.sqlite,table),value,table);
 assert.equal(f.sqlite.prepare("SELECT status FROM game_provider_profiles WHERE id='jdb_myr'").get().status,'closed');
 const report=await getJdbWagerCoverage(f.db,staff);
 assert.equal(report.totals.duplicates,1);assert.equal(report.overlaps.length,1);assert.equal(report.accountingConnected,false);assert.equal(report.turnoverConnected,false);assert.equal(report.rewardConnected,false);assert.equal(report.playable,false);assert.equal(report.launchReady,false);assert.equal(report.productionReady,false);
});

test('later same-window records, changed results and zero corrections stay review-only',async t=>{
 const f=fixture(t),first=await claimJdbWagerWindow(f.db,window(),{at:4000,claimToken:'a'});await stageJdbWagerPage(f.db,first,page([wager('a')]),{at:4000});
 const later=await claimJdbWagerWindow(f.db,window(),{at:4001,claimToken:'b'}),late=await stageJdbWagerPage(f.db,later,page([wager('a'),wager('b')]),{at:4001});
 assert.equal(late.duplicateCount,1);assert.equal(late.lateCount,1);
 const revisionClaim=await claimJdbWagerWindow(f.db,window(),{at:4002,claimToken:'c'}),revision=await stageJdbWagerPage(f.db,revisionClaim,page([wager('a',{winMinor:'60'})]),{at:4002});
 assert.equal(revision.revisionCount,1);
 const reversalClaim=await claimJdbWagerWindow(f.db,window(),{at:4003,claimToken:'d'}),reversal=await stageJdbWagerPage(f.db,reversalClaim,page([wager('a',{betMinor:'0',winMinor:'0'})]),{at:4003});
 assert.equal(reversal.reversalCandidateCount,1);assert.equal(reversal.sourceFinalityVerified,false);assert.equal(reversal.sessionClosureVerified,false);assert.equal(reversal.merchantAuthorizationVerified,false);
 assert.deepEqual(f.sqlite.prepare('SELECT DISTINCT classification FROM jdb_wager_event_versions ORDER BY classification').all().map(row=>row.classification),['late','original','reversal_candidate','revision']);
});

test('a zero correction beside its nonzero version is a reversal candidate regardless of page ordering',async t=>{
 const f=fixture(t),claim=await claimJdbWagerWindow(f.db,window(),{at:4500,claimToken:'same-page'}),receipt=await stageJdbWagerPage(f.db,claim,page([wager('same',{betMinor:'0',winMinor:'0'}),wager('same')]),{at:4500});
 assert.equal(receipt.originalCount,1);assert.equal(receipt.reversalCandidateCount,1);
 assert.deepEqual(f.sqlite.prepare('SELECT bet_minor,win_minor,classification FROM jdb_wager_event_versions ORDER BY bet_minor').all().map(row=>({...row})),[{bet_minor:0,win_minor:0,classification:'reversal_candidate'},{bet_minor:100,win_minor:40,classification:'original'}]);
});

test('the same provider bet ID for different players remains two exact identities',async t=>{
 const f=fixture(t),claim=await claimJdbWagerWindow(f.db,window(),{at:4600,claimToken:'cross-player'}),receipt=await stageJdbWagerPage(f.db,claim,page([wager('shared'),wager('shared',{providerPlayerId:'another-private-player'})]),{at:4600});
 assert.equal(receipt.originalCount,2);assert.equal(receipt.revisionCount,0);assert.equal(receipt.duplicateCount,0);assert.equal(count(f.sqlite,'jdb_wager_identities'),2);
});

test('coverage diagnostics merge contiguous windows, expose gaps, and disclose every blocker',async t=>{
 const f=fixture(t);
 for(const [offset,token] of [[0,'a'],[60_000,'b'],[180_000,'c']]){const claim=await claimJdbWagerWindow(f.db,window(offset),{at:5000+offset/60_000,claimToken:token});await stageJdbWagerPage(f.db,claim,page([]),{at:5000+offset/60_000});}
 const report=await getJdbWagerCoverage(f.db,owner,{timeBasis:'lastModifyTime',from:BASE,to:BASE+240_000});
 assert.deepEqual(report.observedRanges,[{timeBasis:'lastModifyTime',from:BASE,to:BASE+120_000},{timeBasis:'lastModifyTime',from:BASE+180_000,to:BASE+240_000}]);
 assert.deepEqual(report.gaps,[{timeBasis:'lastModifyTime',from:BASE+120_000,to:BASE+180_000}]);
 assert.equal(report.complete,false);assert.equal(report.providerCoverageComplete,false);assert.equal(report.sourceFinalityVerified,false);assert.equal(report.closureVerified,false);assert.equal(report.merchantAuthorizationVerified,false);assert.ok(report.blockers.includes('provider_report_finality_unverified'));
 assert.equal(Object.values(report).some(value=>JSON.stringify(value).includes('private-player')),false);
});

test('a batch fault rolls back receipt, identity, version, observation, cursor and release for safe retry',async t=>{
 const f=fixture(t),claim=await claimJdbWagerWindow(f.db,window(),{at:6000,claimToken:'retry'});
 f.sqlite.exec(`CREATE TRIGGER fail_jdb_observation BEFORE INSERT ON jdb_wager_observations BEGIN SELECT RAISE(ABORT,'fixture crash'); END`);
 await assert.rejects(stageJdbWagerPage(f.db,claim,page([wager()]),{at:6000}),/fixture crash/);
 for(const table of ['jdb_wager_receipts','jdb_wager_identities','jdb_wager_event_versions','jdb_wager_observations','game_wager_sync_cursors'])assert.equal(count(f.sqlite,table),0,table);
 assert.equal(f.sqlite.prepare("SELECT claim_token FROM game_recovery_leases WHERE resource_type='wager_sync'").get().claim_token,'retry');
 f.sqlite.exec('DROP TRIGGER fail_jdb_observation');
 const retried=await stageJdbWagerPage(f.db,claim,page([wager()]),{at:6000});assert.equal(retried.originalCount,1);assert.equal(count(f.sqlite,'jdb_wager_receipts'),1);
});

test('direct staging cannot manufacture finality or broad/complete report coverage',async t=>{
 const f=fixture(t);
 await assert.rejects(claimJdbWagerWindow(f.db,{...window(),to:BASE+16*60_000},{at:7000}),error=>error instanceof JdbWagerCoverageError&&error.code==='JDB_WAGER_WINDOW_INVALID');
 const claim=await claimJdbWagerWindow(f.db,window(),{at:7000,claimToken:'incomplete'});
 await assert.rejects(stageJdbWagerPage(f.db,claim,{items:Array(501).fill(wager()),complete:false},{at:7000}),error=>error instanceof JdbWagerCoverageError&&error.code==='JDB_WAGER_STAGE_INVALID');
 await assert.rejects(stageJdbWagerPage(f.db,claim,{items:[],complete:true},{at:7000}),error=>error instanceof JdbWagerCoverageError&&error.code==='JDB_WAGER_STAGE_INVALID');
 assert.equal(count(f.sqlite,'jdb_wager_receipts'),0);
});

test('coverage diagnostics are owner/staff only',async t=>{
 const f=fixture(t);await assert.rejects(getJdbWagerCoverage(f.db,{id:'member',role:'member'}),error=>error instanceof JdbWagerCoverageError&&error.status===403);
});
