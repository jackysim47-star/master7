import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {RELEASE as release} from '../lib/release.ts';
import {RELEASE as backendRelease,SOURCE_RELEASE} from '../lib/backend.ts';

const read=path=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');

test('release, browser assets and service-worker cache share one version',()=>{
 const portal=read('app/portal.html'),worker=read('public/service-worker.js');assert.ok(release);assert.equal(backendRelease,release);assert.equal(SOURCE_RELEASE,release);
 const assets=[...portal.matchAll(/<(?:script|link)\b[^>]+(?:src|href)="(\/assets\/[^"?]+)\?v=([^"]+)"/g)];assert.ok(assets.length>=20);for(const [,path,version] of assets){assert.match(path,/^\/assets\//);assert.equal(version,release,path);}
 assert.ok(assets.some(([,path])=>path==='/assets/app.js'));assert.equal(worker.match(/const CACHE='master7-shell-([^']+)'/)?.[1],release);
});
