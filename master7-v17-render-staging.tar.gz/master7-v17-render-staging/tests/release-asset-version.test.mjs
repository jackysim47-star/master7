import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read=path=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');

test('release, browser assets and service-worker cache share one version',()=>{
 const backend=read('lib/backend.ts'),portal=read('app/portal.html'),worker=read('public/service-worker.js'),release=backend.match(/export const RELEASE = '([^']+)'/)?.[1];assert.ok(release);
 const urls=[...portal.matchAll(/<(?:script|link)\b[^>]+(?:src|href)="([^"]+)"/g)]
  .map(([,value])=>new URL(value.replaceAll('&amp;','&'),'https://master7-v17-staging.onrender.com'))
  .filter(url=>url.pathname.startsWith('/assets/')&&url.searchParams.get('v')?.startsWith('17.0.0-selfbuilt.'));
 assert.ok(urls.length>=20);
 for(const url of urls){
  const version=url.searchParams.get('v');
  if(['/assets/app.js','/assets/member-shell.css'].includes(url.pathname))assert.ok(version===release||version.startsWith(release+'-'),url.pathname);
  else assert.equal(version,release,url.pathname);
 }
 const app=urls.find(url=>url.pathname==='/assets/app.js');
 assert.equal(app?.searchParams.get('rev'),'withdrawal-provider-selection');
 assert.equal(worker.match(/const CACHE='master7-shell-([^']+)'/)?.[1],release);
});
