import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

for(const provider of ['vpay','gspay','1mpay']){
 test(`${provider}: Cloudflare D1 independently preserves one verified MYR deposit journal`,{timeout:90_000},()=>{
  const source=fileURLToPath(new URL('../',import.meta.url));
  const child=spawnSync(process.execPath,['scripts/verify-cloudflare-manual-bank.mjs','--payment-provider',provider],{
   cwd:source,
   env:{...process.env,MASTER7_VERIFICATION_SOURCE:source},
   encoding:'utf8',
   timeout:85_000,
   maxBuffer:2*1024*1024,
  });
  assert.ifError(child.error);
  assert.equal(child.status,0,child.stderr+child.stdout);
  const evidence=JSON.parse(child.stdout);
  assert.equal(evidence.result,'passed');
  assert.equal(evidence.runtime,'Cloudflare workerd + disposable D1');
  assert.equal(evidence.paymentProvider,provider);
  assert.equal(evidence.paymentCallsAreSynthetic,true);
  assert.equal(evidence.paymentJourneyCompleted,true);
  assert.deepEqual(evidence.syntheticAmountMinor,{bankIn:'5000',providerDeposit:'2000',bankOut:'2000',endingBalance:'5000'});
  assert.ok(evidence.checks.includes(`${provider}: independent create/callback/query-recovery/wallet/ledger/idempotency path`));
  assert.ok(evidence.checks.includes(`${provider}: internal double-entry reconciliation matched; external provider statement remains unavailable and no balance mutation occurred`));
  assert.ok(evidence.paymentObservation.createCalls>=1);
  assert.ok(evidence.paymentObservation.queryCalls>=1);
  assert.equal(evidence.paymentObservation.forcedQueryFailures,1);
  assert.equal(evidence.paymentObservation.externalCalls,0);
  assert.ok(evidence.limitations.includes('synthetic payment-provider transport only'));
  assert.ok(evidence.limitations.includes('not payment-provider UAT acceptance'));
 });
}
