import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const read=name=>readFile(new URL(`../${name}`,import.meta.url),'utf8');

test('one Events Center and one owner Manager are wired into the portal',async()=>{
 const [portal,app,engagement]=await Promise.all([read('app/portal.html'),read('public/assets/app.js'),read('public/assets/engagement.js')]);
 assert.equal((portal.match(/id="events"/g)||[]).length,1);assert.equal((portal.match(/id="engagementManager"/g)||[]).length,1);assert.equal((portal.match(/data-section="events"/g)||[]).length,2);
 assert.match(portal,/engagement\.css/);assert.match(portal,/engagement\.js/);assert.match(portal,/href="#engagementManager" data-owner-only/);assert.match(portal,/id="engagementManager"[^>]*data-owner-only/);
 assert.match(app,/section==="events"\)window\.Master7Engagement\?\.loadPublic/);assert.match(app,/engagementManager:\(\)=>window\.Master7Engagement\?\.loadAdmin/);assert.match(app,/"engagementManager"/);assert.match(app,/Master7Engagement\?\.sessionChanged/);assert.match(app,/recordRecentProvider\(profileId,profileName\)/);assert.match(engagement,/Master7Engagement=\{[^}]*soundEnabled/);assert.doesNotMatch(app,/Master7Engagement\?\.soundEnabled/);
});

test('engagement presentation only exposes the implemented lobby and notification features',async()=>{
 const [source,style]=await Promise.all([read('public/assets/engagement.js'),read('public/assets/engagement.css')]);
 for(const text of ['Personalized Lobby','Notification Center','LOBBY & MESSAGES'])assert.ok(source.includes(text));
 assert.doesNotMatch(source,/renderTournament|renderDepositSpin|renderDraw|eventEditor|depositSpinEditor|eventPayload|depositSpinPayload/);
 assert.match(source,/existing records and status sources only/i);assert.match(source,/sensitive wagering inference off/i);assert.doesNotMatch(source,/\.innerHTML\s*=/);assert.doesNotMatch(source,/api\([^\n]*draw/i);assert.doesNotMatch(source,/api\([^\n]*(award|credit)/i);
 assert.match(style,/\.engagement-grid/);assert.match(style,/@media\(max-width:620px\)/);assert.match(style,/@media\(prefers-reduced-motion:reduce\)/);
});

test('recent providers are device-local, explicit, deduplicated and limited to twelve',async()=>{
 const source=await read('public/assets/engagement.js'),store=new Map(),listeners={};
 const localStorage={getItem:key=>store.get(key)??null,setItem:(key,value)=>store.set(key,value)};
 const document={readyState:'loading',getElementById(){return null;},querySelectorAll(){return [];},addEventListener(name,handler){listeners[name]=handler;}};
 const window={};vm.runInNewContext(source,{window,document,localStorage,console,Date,setTimeout,clearTimeout});
 const ids=['megah5','jili','918kissh5','gameplay','lionking','suncity','pgsoft','gfg','sagaming','ps9','dragoonsoft','jdb','bg'];for(const id of ids)window.Master7Engagement.recordRecentProvider(id,id.toUpperCase());window.Master7Engagement.recordRecentProvider('bg','BG AGAIN');window.Master7Engagement.recordRecentProvider('unknown','UNKNOWN');
 const recent=JSON.parse(store.get('master7-recent-providers'));assert.equal(recent.length,12);assert.equal(recent[0].id,'bg');assert.equal(recent[0].name,'BG AGAIN');assert.equal(recent.filter(item=>item.id==='bg').length,1);assert.equal(recent.some(item=>item.id==='unknown'),false);assert.ok(recent.every(item=>Object.keys(item).sort().join(',')==='id,name,viewedAt'));
 assert.equal(typeof listeners.DOMContentLoaded,'function');
});

test('personalized provider order uses the existing favorite key, local recent views and owner curation only',async()=>{
 const source=await read('public/assets/engagement.js'),store=new Map([['master7-favorite-providers',JSON.stringify(['jili','bg'])],['master7-recent-providers',JSON.stringify([{id:'bg',name:'BG',viewedAt:2},{id:'pgsoft',name:'PGSOFT',viewedAt:1}])]]),document={readyState:'complete',getElementById(){return null;},querySelectorAll(){return [];},addEventListener(){}};
 const window={};vm.runInNewContext(source,{window,document,localStorage:{getItem:key=>store.get(key)??null,setItem:(key,value)=>store.set(key,value)},console,Date});
 const program={enabled:true,personalizedLobby:{enabled:true,ownerCuratedProviders:['megah5','bg'],maxItems:4}},items=window.Master7Engagement._test.personalizedProviders(program);
 assert.deepEqual([...items].map(item=>item.id),['jili','bg','pgsoft','megah5']);assert.deepEqual([...items[1].sources],['favorite','recent','curated']);assert.equal(JSON.stringify(items).includes('wager'),false);assert.equal(JSON.stringify(items).includes('amount'),false);
});

test('notification presentation follows the master display switch before module readiness',async()=>{
 const source=await read('public/assets/engagement.js'),document={readyState:'complete',getElementById(){return null;},querySelectorAll(){return [];},addEventListener(){}},window={};
 vm.runInNewContext(source,{window,document,localStorage:{getItem(){return null;},setItem(){}},console,Date});
 const state=window.Master7Engagement._test.notificationDisplayState;
 const readiness={notificationCenter:{published:true,sound:true,sources:[{id:'tickets',enabled:true},{id:'financial',enabled:true}]}};
 const off=state({program:{enabled:false},readiness});assert.equal(off.centerEnabled,false);assert.equal(off.soundEnabled,false);assert.ok(off.sources.every(source=>source.displayEnabled===false));
 const on=state({program:{enabled:true},readiness});assert.equal(on.centerEnabled,true);assert.equal(on.soundEnabled,true);assert.ok(on.sources.every(source=>source.displayEnabled===true));
 const unpublished=state({program:{enabled:true},readiness:{notificationCenter:{...readiness.notificationCenter,published:false}}});assert.equal(unpublished.centerEnabled,false);assert.equal(unpublished.soundEnabled,false);
});
