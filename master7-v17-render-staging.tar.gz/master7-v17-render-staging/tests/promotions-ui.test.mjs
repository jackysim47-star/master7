import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

test('Promotions uses published benefit data without adding reward or wallet writes',async()=>{
 const [html,script,css]=await Promise.all([
  readFile(new URL('../app/portal.html',import.meta.url),'utf8'),
  readFile(new URL('../public/assets/rewards.js',import.meta.url),'utf8'),
  readFile(new URL('../public/assets/rewards.css',import.meta.url),'utf8'),
 ]);
 for(const id of ['id="promotionsPublishedTitle"','id="promotionCategoryFilters"','id="promotionsPublishedList"'])assert.match(html,new RegExp(id));
 for(const category of ['all','new-member','deposit','games','other'])assert.match(html,new RegExp(`data-promotion-category="${category}"`));
 assert.match(script,/api\("\/api\/benefits"\)/);
 assert.match(script,/function renderPromotions\(/);
 assert.match(script,/No automatic wallet credit or reward claim/);
 assert.doesNotMatch(script,/api\("\/api\/benefit-claims"\s*,\s*"POST"/);
 assert.doesNotMatch(script,/api\("\/api\/admin\/benefits"\s*,\s*"POST"/);
 assert.doesNotMatch(script,/wallet[^\n]*(credit|deposit)[^\n]*(POST|api\()/i);
 assert.match(css,/\.promotion-card-list/);
 assert.match(css,/\.promotion-category\.active/);
 assert.match(css,/@media\(max-width:760px\)[^{]*\{[^}]*\.promotions-heading/s);
});
