import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const root = new URL('../', import.meta.url);

test('customer portal and localized account copy use MASTER7 branding', async () => {
  const [html, app, auth, payments] = await Promise.all([
    readFile(new URL('app/portal.html', root), 'utf8'),
    readFile(new URL('public/assets/app.js', root), 'utf8'),
    readFile(new URL('lib/password-auth.ts', root), 'utf8'),
    readFile(new URL('lib/vpay.ts', root), 'utf8'),
  ]);

  assert.match(html, /<title>MASTER7 · Premium Game Lobby<\/title>/);
  assert.match(html, /aria-label="MASTER7 home"/);
  assert.match(app, /MASTER7 ID/);
  assert.match(app, /ID MASTER7/);
  assert.match(auth, /Your MASTER7 verification code/);
  assert.match(auth, /MASTER7 ID/);
  assert.match(payments, /title: 'MASTER7 deposit'/);
  for (const [name, content] of Object.entries({ html, app, auth, payments })) {
    assert.doesNotMatch(content, /SEVEN(?=\s|[·/])/i, `${name} still contains old company copy`);
  }
});
