import {test} from 'node:test';
import assert from 'node:assert/strict';
import {configuredGameCatalogueSourceIds,gameSources} from '../lib/game-catalogue.ts';

const gateway={gameGatewayUrl:'https://master7-integration-gateway.onrender.com'};
const rectangle={rectangleApiBase:'https://apig.rg-lgna.com',rectangleOperatorCode:'FIXTURE_MASTER7',rectangleApiKey:'fixture-rectangle-key'};
const godee={godeeApiBase:'https://api.godeezone1.com',godeeOperatorId:'FIXTURE_OPERATOR',godeeApiKey:'fixture-godee-api-key'};

function guarded(config={}){
 const activity={network:0,database:0};
 return {
  activity,
  context:{
   ...config,
   db:{prepare(){activity.database++;throw Error('configuration inventory must not access the database');}},
   gameGatewayFetch:async()=>{activity.network++;throw Error('configuration inventory must not access the network');},
   gameCatalogueFetch:async()=>{activity.network++;throw Error('configuration inventory must not access the network');},
  },
 };
}

function inventory(config,expected){
 const {activity,context}=guarded(config),result=configuredGameCatalogueSourceIds(context);
 assert.deepEqual(result,expected);
 assert.equal(activity.network,0);
 assert.equal(activity.database,0);
 assert.equal(Object.isFrozen(result),true);
 return result;
}

test('configured catalogue inventory is empty when no trusted source is configured',()=>{
 inventory({},[]);
 inventory({gameGatewayUrl:'https://attacker.example.test',rectangleApiBase:'https://attacker.example.test',rectangleOperatorCode:rectangle.rectangleOperatorCode,rectangleApiKey:rectangle.rectangleApiKey},[]);
});

test('configured catalogue inventory includes all seven gateway sources only for the pinned gateway',()=>{
 inventory(gateway,gameSources.map(source=>source.id));
});

test('configured catalogue inventory includes Rectangle only when its exact production configuration is valid',()=>{
 inventory(rectangle,['rectangle']);
});

test('configured catalogue inventory includes Godee Zone only when its exact production configuration is valid',()=>{
 inventory(godee,['godeezone']);
});

test('configured catalogue inventory returns all configured sources without exposing configuration values',()=>{
 const result=inventory({...gateway,...rectangle,...godee},[...gameSources.map(source=>source.id),'rectangle','godeezone']);
 const serialized=JSON.stringify(result);
 for(const sensitive of [gateway.gameGatewayUrl,rectangle.rectangleApiBase,rectangle.rectangleOperatorCode,rectangle.rectangleApiKey,godee.godeeApiBase,godee.godeeOperatorId,godee.godeeApiKey])assert.doesNotMatch(serialized,new RegExp(sensitive.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
});
