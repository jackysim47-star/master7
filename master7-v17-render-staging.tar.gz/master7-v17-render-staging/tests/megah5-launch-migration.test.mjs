import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';

const migration='0112_megah5_launch_operations.sql';
function fixture(t){
 const db=new DatabaseSync(':memory:');t.after(()=>db.close());db.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync('drizzle').filter(file=>/^\d{4}_.+\.sql$/.test(file)&&file<migration).sort())db.exec(readFileSync(`drizzle/${file}`,'utf8'));
 db.exec(`INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf',1),('bob','bob','member',1,'csrf',1);
  INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('legacy','alice','megah5','player','55021','active',100,'deposit',1,1);`);
 return db;
}
test('launch operation migration is additive, repeatable, and preserves a historical wallet session',t=>{
 const db=fixture(t),before={...db.prepare("SELECT * FROM game_wallet_sessions WHERE id='legacy'").get()},sql=readFileSync(`drizzle/${migration}`,'utf8');
 db.exec(sql);db.exec(sql);
 assert.deepEqual({...db.prepare("SELECT * FROM game_wallet_sessions WHERE id='legacy'").get()},before);
 const columns=db.prepare('PRAGMA table_info(megah5_launch_operations)').all().map(row=>row.name);
 assert.deepEqual(columns,['id','wallet_session_id','user_id','game_code','state','created_at','updated_at','last_error']);
 assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
});
test('launch operation is unique to the wallet and bound to its owner and game',t=>{
 const db=fixture(t);db.exec(readFileSync(`drizzle/${migration}`,'utf8'));
 const create=db.prepare('INSERT INTO megah5_launch_operations(id,wallet_session_id,user_id,game_code,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
 assert.throws(()=>create.run('wrong-user','legacy','bob','55021','launching',1,1),/FOREIGN KEY/);
 assert.throws(()=>create.run('wrong-game','legacy','alice','99999','launching',1,1),/FOREIGN KEY/);
 assert.throws(()=>create.run('wrong-state','legacy','alice','55021','unknown_state',1,1),/CHECK/);
 create.run('original','legacy','alice','55021','launching',1,1);
 assert.throws(()=>create.run('duplicate','legacy','alice','55021','launching',1,1),/UNIQUE/);
 assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
});
