import assert from 'node:assert/strict';
import test from 'node:test';
import {getIntegrationContractIntake} from '../lib/integration-contracts.ts';

test('integration contract intake is documentation-only and fail-closed',()=>{
 const intake=getIntegrationContractIntake();
 assert.equal(intake.documentationOnly,true);
 assert.deepEqual(intake.gameProviders.map(item=>item.providerId),['lebet']);
 assert.equal(intake.gameProviders[0].status,'contract_missing');
 assert.deepEqual(intake.paymentProviders.map(item=>item.providerId),['vpay_myr','gspay_myr','gspay_usdt','onempay_myr']);
 assert.equal(intake.paymentProviders.find(item=>item.providerId==='gspay_usdt').status,'contract_missing');
 for(const item of intake.gameProviders){
  assert.equal(item.implemented,false,item.providerId);
  assert.equal(item.enabled,false,item.providerId);
  assert.equal(item.liveReady,false,item.providerId);
  assert.ok(item.requiredEvidence.length>0,item.providerId);
 }
 for(const item of intake.paymentProviders){
  assert.equal(item.enabled,false,item.providerId);
  assert.equal(item.liveReady,false,item.providerId);
  assert.ok(item.requiredEvidence.length>0,item.providerId);
 }
});

test('contract intake never reflects credentials or grants runtime capability',()=>{
 const intake=getIntegrationContractIntake();
 const serialized=JSON.stringify(intake);
 for(const value of ['password','secret','apiKey','token','merchantId'])assert.doesNotMatch(serialized,new RegExp(value,'i'));
 assert.equal(intake.gameProviders[0].launchReady,false);
 assert.equal(intake.gameProviders[0].walletReady,false);
 assert.equal(intake.gameProviders[0].recoveryReady,false);
 assert.ok(intake.paymentProviders.every(item=>item.orderReady===false&&item.callbackReady===false&&item.settlementVerified===false));
});
