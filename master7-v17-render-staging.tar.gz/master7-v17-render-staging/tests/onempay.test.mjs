import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {handle} from '../lib/backend.ts';
import {oneMpayOrderToken,oneMpayCallbackToken} from '../lib/onempay.ts';

// Only synthetic API replies are used. These checks never contact a provider.
const origin='https://portal.example.test',apiBase='https://api.1mpay.net';
const merchant='TESTMERCHANT',secret='fixture-secret-12345678';
const sha=value=>createHash('sha256').update(value).digest('base64');
function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 for(const [id,role] of [['alice','member'],['bob','member'],['owner','owner']])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,1,?,0)').run(id,id,role,'csrf-'+id);
 sql.prepare("UPDATE payment_channel_controls SET status='active' WHERE provider_id='1mpay'").run();
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sql.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.text).all(...this.args)};}
  async run(){return sql.prepare(this.text).run(...this.args);}
 }
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=statements.map(s=>sql.prepare(s.text).run(...s.args));sql.exec('COMMIT');return result;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const state={createCalls:0,queryCalls:0,status:'Successful',orders:new Map(),queryPatch:x=>x,checkout:apiBase+'/fundtransfer/pay/fixture',createError:false};
 const config={db,identity:null,ownerEmail:'owner@example.test',oneMpayApiBase:apiBase,oneMpayMerchant:merchant,oneMpaySecretKey:secret,oneMpayOrdersEnabled:'true',oneMpayCallbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',oneMpayReturnUrl:'https://master7-v17-staging.onrender.com/payment/return',oneMpayDiagnosticToken:'fixture-diagnostic-'.padEnd(45,'x'),oneMpayFetch:async(url,init)=>{
  const u=new URL(url);assert.equal(u.origin,apiBase);assert.equal(init.redirect,'error');
  if(u.pathname==='/fundtransfer/json'){
   state.createCalls++;assert.equal(init.method,'POST');assert.equal(init.headers['Content-Type'],'application/x-www-form-urlencoded');
   const data=Object.fromEntries(new URLSearchParams(init.body));state.lastCreate=data;
   assert.equal(data.merchant,merchant);assert.equal(data.amount,'20.00');assert.equal(data.currency,'MYR');
   assert.equal(data.token,sha(merchant+data.amount+data.refid+data.customer+secret+'MYR'));
   assert.deepEqual(Object.keys(data).sort(),['amount','currency','customer','failed_return_url','merchant','post_url','refid','return_url','token'].sort());
   state.orders.set(data.refid,{...data,trxno:'TRX-'+data.refid});
   if(state.createError)throw Error('Synthetic network failure');
   return Response.json({code:0,message:'Redirect URL',redirect_url:state.checkout,data:{trxno:'TRX-'+data.refid}});
  }
  assert.equal(init.method,'GET');assert.ok(u.pathname.startsWith('/transquery/'));state.queryCalls++;
  const [, ,encodedTrx,encodedToken]=u.pathname.split('/'),trxno=decodeURIComponent(encodedTrx),order=[...state.orders.values()].find(x=>x.trxno===trxno);assert.ok(order);
  const token=sha(merchant+order.amount+order.refid+order.customer+secret+trxno);
  assert.equal(Buffer.from(decodeURIComponent(encodedToken),'base64').toString(),token);
  return Response.json(state.queryPatch({merchant,amount:order.amount,refid:order.refid,customer:order.customer,token,trxno,status:state.status,status_message:state.status}));
 }};
 async function call(path,{who='alice',method='GET',data,headers={},extra={}}={}){
  const r=await handle(new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,...headers},...(data===undefined?{}:{body:JSON.stringify(data)})}),{...config,identity:who?{userId:who,email:who+'@example.test'}:null,...extra});
  return {status:r.status,data:r.headers.get('content-type')?.includes('application/json')?await r.json():await r.text()};
 }
 async function create(requestKey='synthetic-order-key-0001',extra={}){return call('/api/payments/1mpay/orders',{method:'POST',data:{amount:'20.00',requestKey},...extra});}
 async function callback(id,patch={},form=false){
  const order=state.orders.get(id);assert.ok(order);
  const data={merchant,amount:order.amount,refid:id,customer:order.customer,trxno:order.trxno,status:'Successful',token:sha(merchant+order.amount+id+order.customer+secret+order.trxno),...patch};
  if(!form)return call('/api/payment-callbacks/1mpay/payment',{who:null,method:'POST',data,headers:{Origin:'https://provider.example.test'}});
  const r=await handle(new Request(origin+'/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data)}),config);
  return {status:r.status,data:await r.text()};
 }
 const count=()=>sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n;
 t.after(()=>sql.close());return {sql,db,state,config,call,create,callback,count};
}

test('1MPay uses the official SHA256 raw digest and base64 test vectors',()=>{
 assert.equal(oneMpayOrderToken(merchant,'20.00','INV1000001','CUST001',secret),'DUn9m9RcVNjX2qbH2rc1EAFyoUVrVnOZorv6XqkbHDM=');
 assert.equal(oneMpayCallbackToken(merchant,'20.00','INV1000001','CUST001',secret,'TRX123'),'nKatfoiE1nYxRLRqdFzJziAZuSUKtnaqcz59VuA8jVc=');
});
test('production checkout persists an idempotent MYR order without crediting the wallet',async t=>{
 const f=fixture(t),a=await f.create(),b=await f.create();assert.equal(a.status,201);assert.equal(b.data.id,a.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.count(),0);
 const conflict=await f.call('/api/payments/1mpay/orders',{method:'POST',data:{amount:'21.00',requestKey:'synthetic-order-key-0001'}});assert.equal(conflict.status,409);assert.equal(f.state.createCalls,1);
 const wallet=await f.call('/api/wallet');assert.equal(wallet.data.balanceMinor,'0');
 const status=await f.call('/api/payments/1mpay/status',{who:null});assert.equal(status.data.mode,'production');assert.equal(status.data.enabled,true);assert.equal(status.data.queryReady,true);assert.equal(status.data.settlementVerified,false);assert.equal(status.data.capabilities.deposit.enabled,true);assert.equal(status.data.capabilities.payout.submissionEnabled,false);assert.equal(status.data.capabilities.balance.implemented,false);assert.ok(!JSON.stringify(status).includes(secret));
 const health=await f.call('/health',{who:null});assert.equal(health.data.realPayments,true);assert.equal(health.data.transactionsEnabled,true);assert.equal(health.data.settlementVerified,false);assert.equal(health.data.productionReady,false);
 const channels=await f.call('/api/payment-channels',{who:null});assert.equal(channels.data.providerOrdersEnabled['1mpay'],true);assert.equal(channels.data.providerOrdersEnabled.gspay,false);assert.equal(channels.data.providerCapabilities['1mpay'].payout.submissionEnabled,false);
});
test('1MPay accepts strictly parsed JSON when the server labels its JSON body as text',async t=>{
 const f=fixture(t),original=f.config.oneMpayFetch;f.config.oneMpayFetch=async(...args)=>{const r=await original(...args);return new Response(await r.text(),{status:r.status,headers:{'Content-Type':'text/html; charset=utf-8'}});};
 const r=await f.create();assert.equal(r.status,201);assert.ok(r.data.payUrl);assert.equal(f.count(),0);
});
test('unconfirmed payment diagnostics contain safe status facts and no provider body or secret',async t=>{
 const f=fixture(t);f.config.oneMpayFetch=async()=>Response.json({error:'private text',secret},{status:403});
 const r=await f.create();assert.equal(r.status,202);assert.equal(f.count(),0);
 const row=f.sql.prepare("SELECT target FROM audit WHERE event='payment_order_diagnostic'").get();assert.ok(row);const facts=JSON.parse(row.target);assert.equal(facts.provider,'1mpay');assert.equal(facts.httpStatus,403);assert.equal(facts.kind,'PROVIDER_HTTP');assert.ok(!row.target.includes(secret));assert.ok(!row.target.includes('private text'));
});
test('member ownership, CSRF, approval and channel switches stop unauthorized orders',async t=>{
 const f=fixture(t);assert.equal((await f.create(undefined,{who:null})).status,401);assert.equal((await f.create(undefined,{who:'owner'})).status,403);assert.equal((await f.create(undefined,{headers:{'X-CSRF-Token':'bad'}})).status,403);
 assert.equal((await f.create(undefined,{headers:{Origin:'https://attacker.example.test'}})).status,403);
 f.sql.prepare("UPDATE users SET approved=0 WHERE id='alice'").run();assert.equal((await f.create()).status,403);f.sql.prepare("UPDATE users SET approved=1 WHERE id='alice'").run();
 f.config.oneMpayOrdersEnabled='false';assert.equal((await f.create()).status,503);f.config.oneMpayOrdersEnabled='true';f.sql.prepare("UPDATE payment_channel_controls SET status='closed' WHERE provider_id='1mpay'").run();assert.equal((await f.create()).status,503);assert.equal(f.state.createCalls,0);
});
test('configuration keeps query and callback reconciliation ready while new orders are closed',async t=>{
 const f=fixture(t);f.config.oneMpayOrdersEnabled='false';f.sql.prepare("UPDATE payment_channel_controls SET status='closed' WHERE provider_id='1mpay'").run();
 const status=await f.call('/api/payments/1mpay/status',{who:null});assert.equal(status.data.programReady,true);assert.equal(status.data.enabled,false);assert.equal(status.data.orderReady,false);assert.equal(status.data.queryReady,true);assert.equal(status.data.callbacksReady,true);assert.equal(f.state.createCalls,0);assert.equal(f.state.queryCalls,0);
});
test('unsigned callback status never establishes success; independent query does',async t=>{
 const f=fixture(t),a=await f.create();f.state.status='Fail';assert.equal((await f.callback(a.data.id,{status:'Successful'},true)).status,200);assert.equal(f.count(),0);assert.equal(f.state.queryCalls,1);
 f.state.status='Successful';assert.equal((await f.callback(a.data.id,{status:'Fail'})).status,200);assert.equal(f.count(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
});
test('late success remains payable after an initial failure and duplicate callbacks credit once',async t=>{
 const f=fixture(t),a=await f.create();f.state.status='Fail';await f.callback(a.data.id);assert.equal(f.count(),0);f.state.status='Successful';
 for(let n=0;n<5;n++){const response=await f.callback(a.data.id);assert.equal(response.status,200);assert.equal(response.data,'ok');}
 assert.equal(f.count(),2);assert.equal(f.sql.prepare('SELECT SUM(amount_minor) n FROM wallet_ledger').get().n,0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(a.data.id).status,'credited');
});
test('bad callback signatures, amount, member or provider transaction do not credit',async t=>{
 const f=fixture(t),a=await f.create();
 for(const patch of [{token:'invalid'},{amount:'21.00'},{customer:'different'},{trxno:'different'}])assert.equal((await f.callback(a.data.id,patch)).status,401);
 assert.equal(f.count(),0);assert.equal(f.state.queryCalls,0);
});
test('trusted query must match merchant, amount, order, customer, transaction and signature',async t=>{
 const f=fixture(t),a=await f.create();
 for(const [key,value]of [['merchant','other'],['amount','21.00'],['refid','other'],['customer','other'],['trxno','other'],['token','bad'],['currency','USD']]){
  f.state.queryPatch=x=>({...x,[key]:value});assert.equal((await f.callback(a.data.id)).status,503);assert.equal(f.count(),0);
 }
});
test('member query can reconcile only their own order and completes an outstanding closed channel',async t=>{
 const f=fixture(t),a=await f.create();f.sql.prepare("UPDATE payment_channel_controls SET status='closed' WHERE provider_id='1mpay'").run();
 assert.equal((await f.call('/api/payments/1mpay/orders/query',{who:'bob',method:'POST',data:{orderId:a.data.id}})).status,404);assert.equal(f.count(),0);
 const r=await f.call('/api/payments/1mpay/orders/query',{method:'POST',data:{orderId:a.data.id}});assert.equal(r.data.status,'credited');assert.equal(f.count(),2);
});
test('failed atomic ledger batch rolls back both entries and can safely retry',async t=>{
 const f=fixture(t),a=await f.create();f.sql.exec("CREATE TRIGGER fixture_fail_clearing BEFORE INSERT ON wallet_ledger WHEN NEW.account_code='provider_clearing' BEGIN SELECT RAISE(ABORT,'fixture failure'); END;");
 assert.equal((await f.callback(a.data.id)).status,503);assert.equal(f.count(),0);assert.notEqual(f.sql.prepare('SELECT status FROM deposit_orders').get().status,'credited');
 f.sql.exec('DROP TRIGGER fixture_fail_clearing');assert.equal((await f.callback(a.data.id)).status,200);assert.equal(f.count(),2);
});
test('an inconsistent existing ledger is held for review before any new financial entry',async t=>{
 const f=fixture(t),a=await f.create();f.sql.prepare("INSERT INTO wallet_ledger VALUES('bad',?,'alice','member',1,'MYR',0)").run(a.data.id);
 assert.equal((await f.callback(a.data.id)).status,503);assert.equal(f.count(),1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders').get().status,'review');
});
test('ambiguous provider timeout records one order and does not resubmit it on retry',async t=>{
 const f=fixture(t);f.state.createError=true;const a=await f.create(),b=await f.create();assert.equal(a.status,202);assert.equal(a.data.id,b.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.count(),0);
});
test('untrusted checkout destinations and invalid monetary precision are rejected',async t=>{
 const f=fixture(t);
 for(const amount of ['0','-1','20.001','2e1','100000.01'])assert.equal((await f.call('/api/payments/1mpay/orders',{method:'POST',data:{amount,requestKey:'synthetic-invalid-amount'}})).status,400);
 f.state.checkout='https://attacker.example.test/pay';const a=await f.create();assert.equal(a.status,202);assert.equal(a.data.payUrl,null);assert.equal(f.count(),0);
});
test('callback duplicate form fields and oversized bodies are rejected without a query',async t=>{
 const f=fixture(t),a=await f.create();
 for(const body of ['refid='+a.data.id+'&refid=other','x='+ 'a'.repeat(8200)]){
  const r=await handle(new Request(origin+'/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body}),f.config);assert.equal(r.status,400);
 }
 assert.equal(f.state.queryCalls,0);assert.equal(f.count(),0);
});
test('outbound IP diagnostics requires a distinct private bearer and exposes no credentials',async t=>{
 const f=fixture(t);assert.equal((await f.call('/api/payments/1mpay/diagnostics',{who:null})).status,401);
 f.config.oneMpayFetch=async url=>{assert.equal(url,'https://api64.ipify.org?format=json');return Response.json({ip:'203.0.113.10'});};
 const r=await f.call('/api/payments/1mpay/diagnostics',{who:null,headers:{Authorization:'Bearer '+f.config.oneMpayDiagnosticToken}});assert.equal(r.status,200);assert.equal(r.data.source,'payment-application');assert.equal(r.data.fixedIpVerified,false);assert.ok(!JSON.stringify(r.data).includes(secret));
});
test('provider migration preserves historical VPay orders, ledger values, uniqueness and foreign keys',()=>{
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of ['0000_broken_bloodscream.sql','0007_vpay_uat_wallet.sql'])sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('a','a','member',1,'csrf',0); INSERT INTO deposit_orders VALUES('old','a','key','fingerprint','vpay',2000,'MYR','1','credited','TRADE',NULL,NULL,0,0); INSERT INTO wallet_ledger VALUES('m','old','a','member',2000,'MYR',0),('c','old','a','provider_clearing',-2000,'MYR',0)");
 const oldOrders=sql.prepare('SELECT * FROM deposit_orders').all(),oldLedger=sql.prepare('SELECT * FROM wallet_ledger ORDER BY id').all();
 sql.exec(readFileSync(new URL('../drizzle/0017_payment_providers.sql',import.meta.url),'utf8'));
 assert.deepEqual(sql.prepare('SELECT * FROM deposit_orders').all(),oldOrders);assert.deepEqual(sql.prepare('SELECT * FROM wallet_ledger ORDER BY id').all(),oldLedger);assert.deepEqual(sql.prepare('PRAGMA foreign_key_check').all(),[]);assert.equal(sql.prepare('PRAGMA foreign_keys').get().foreign_keys,1);
 assert.throws(()=>sql.exec("INSERT INTO wallet_ledger VALUES('duplicate','old','a','member',2000,'MYR',0)"),/UNIQUE/);assert.throws(()=>sql.exec("DELETE FROM deposit_orders WHERE id='old'"),/FOREIGN KEY/);sql.close();
});
