import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {handle} from '../lib/backend.ts';
import {createOneMpayOrder,oneMpayOrderToken,oneMpayCallbackToken} from '../lib/onempay.ts';

// Only synthetic API replies are used. These checks never contact a provider.
const origin='https://portal.example.test',apiBase='https://api.1mpay.net';
const merchant='TESTMERCHANT',secret='fixture-secret-12345678';
const sha=value=>createHash('sha256').update(value).digest('base64');
function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 for(const [id,role] of [['alice','member'],['bob','member'],['owner','owner']])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,1,?,0)').run(id,id,role,'csrf-'+id);
 sql.prepare("UPDATE payment_channel_controls SET status='active' WHERE provider_id='1mpay'").run();
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sql.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.text).all(...this.args)};}
  async run(){return sql.prepare(this.text).run(...this.args);}
 }
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=statements.map(s=>sql.prepare(s.text).run(...s.args));sql.exec('COMMIT');return result;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const state={createCalls:0,queryCalls:0,status:'Successful',orders:new Map(),queryPatch:x=>x,checkout:apiBase+'/fundtransfer/pay/fixture',createError:false,createResult:null};
 const config={db,identity:null,ownerEmail:'owner@example.test',newDepositsEnabled:'true',oneMpayApiBase:apiBase,oneMpayMerchant:merchant,oneMpaySecretKey:secret,oneMpayOrdersEnabled:'true',oneMpayCallbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',oneMpayReturnUrl:'https://master7-v17-staging.onrender.com/payment/return',oneMpayDiagnosticToken:'fixture-diagnostic-'.padEnd(45,'x'),oneMpayFetch:async(url,init)=>{
  const u=new URL(url);assert.equal(u.origin,apiBase);assert.equal(init.redirect,'error');
  if(u.pathname==='/fundtransfer/json'){
   state.createCalls++;assert.equal(init.method,'POST');assert.equal(init.headers['Content-Type'],'application/x-www-form-urlencoded');
   const data=Object.fromEntries(new URLSearchParams(init.body));state.lastCreate=data;
   assert.equal(data.merchant,merchant);assert.equal(data.amount,'20.00');assert.equal(data.currency,'MYR');
   assert.equal(data.token,sha(merchant+data.amount+data.refid+data.customer+secret+'MYR'));
   assert.deepEqual(Object.keys(data).sort(),['amount','currency','customer','failed_return_url','merchant','post_url','refid','return_url','token'].sort());
   state.orders.set(data.refid,{...data,trxno:'TRX-'+data.refid});
   if(state.createError)throw Error('Synthetic network failure');
   if(state.createResult)return Response.json(state.createResult);
   return Response.json({code:0,message:'Redirect URL',redirect_url:state.checkout,data:{trxno:'TRX-'+data.refid}});
  }
  assert.equal(init.method,'GET');assert.ok(u.pathname.startsWith('/transquery/'));state.queryCalls++;
  const [, ,encodedTrx,encodedToken]=u.pathname.split('/'),trxno=decodeURIComponent(encodedTrx),order=[...state.orders.values()].find(x=>x.trxno===trxno);assert.ok(order);
  const token=sha(merchant+order.amount+order.refid+order.customer+secret+trxno);
  assert.equal(Buffer.from(decodeURIComponent(encodedToken),'base64').toString(),token);
  return Response.json(state.queryPatch({merchant,amount:order.amount,refid:order.refid,customer:order.customer,token,trxno,status:state.status,status_message:state.status}));
 }};
 async function call(path,{who='alice',method='GET',data,headers={},extra={}}={}){
  const r=await handle(new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,...headers},...(data===undefined?{}:{body:JSON.stringify(data)})}),{...config,identity:who?{userId:who,email:who+'@example.test'}:null,...extra});
  return {status:r.status,data:r.headers.get('content-type')?.includes('application/json')?await r.json():await r.text()};
 }
 async function create(requestKey='synthetic-order-key-0001',extra={}){return call('/api/payments/1mpay/orders',{method:'POST',data:{amount:'20.00',requestKey},...extra});}
 async function callback(id,patch={},form=false){
  const order=state.orders.get(id);assert.ok(order);
  const data={merchant,amount:order.amount,refid:id,customer:order.customer,trxno:order.trxno,status:'Successful',token:sha(merchant+order.amount+id+order.customer+secret+order.trxno),...patch};
  if(!form)return call('/api/payment-callbacks/1mpay/payment',{who:null,method:'POST',data,headers:{Origin:'https://provider.example.test'}});
  const r=await handle(new Request(origin+'/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data)}),config);
  return {status:r.status,data:await r.text()};
 }
 const count=()=>sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n;
 t.after(()=>sql.close());return {sql,db,state,config,call,create,callback,count};
}

test('1MPay uses the official SHA256 raw digest and base64 test vectors',()=>{
 assert.equal(oneMpayOrderToken(merchant,'20.00','INV1000001','CUST001',secret),'DUn9m9RcVNjX2qbH2rc1EAFyoUVrVnOZorv6XqkbHDM=');
 assert.equal(oneMpayCallbackToken(merchant,'20.00','INV1000001','CUST001',secret,'TRX123'),'nKatfoiE1nYxRLRqdFzJziAZuSUKtnaqcz59VuA8jVc=');
});
test('production checkout persists an idempotent MYR order without crediting the wallet',async t=>{
 const f=fixture(t),a=await f.create(),b=await f.create();assert.equal(a.status,201);assert.equal(b.data.id,a.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.count(),0);
 const conflict=await f.call('/api/payments/1mpay/orders',{method:'POST',data:{amount:'21.00',requestKey:'synthetic-order-key-0001'}});assert.equal(conflict.status,409);assert.equal(f.state.createCalls,1);
 const wallet=await f.call('/api/wallet');assert.equal(wallet.data.balanceMinor,'0');
 const status=await f.call('/api/payments/1mpay/status',{who:null});assert.equal(status.data.mode,'production');assert.equal(status.data.enabled,true);assert.equal(status.data.queryReady,true);assert.equal(status.data.payoutReady,false);assert.equal(status.data.balanceReady,false);assert.equal(status.data.settlementVerified,false);assert.equal(status.data.capabilities.deposit.enabled,true);assert.equal(status.data.capabilities.payout.submissionEnabled,false);assert.equal(status.data.capabilities.balance.implemented,false);assert.ok(!JSON.stringify(status).includes(secret));
 const health=await f.call('/health',{who:null});assert.equal(health.data.realPayments,true);assert.equal(health.data.transactionsEnabled,true);assert.equal(health.data.settlementVerified,false);assert.equal(health.data.productionReady,false);
 const channels=await f.call('/api/payment-channels',{who:null});assert.equal(channels.data.providerOrdersEnabled['1mpay'],true);assert.equal(channels.data.providerOrdersEnabled.gspay,false);assert.equal(channels.data.providerCapabilities['1mpay'].payout.submissionEnabled,false);
});
test('1MPay accepts strictly parsed JSON when the server labels its JSON body as text',async t=>{
 const f=fixture(t),original=f.config.oneMpayFetch;f.config.oneMpayFetch=async(...args)=>{const r=await original(...args);return new Response(await r.text(),{status:r.status,headers:{'Content-Type':'text/html; charset=utf-8'}});};
 const r=await f.create();assert.equal(r.status,201);assert.ok(r.data.payUrl);assert.equal(f.count(),0);
});
test('unconfirmed payment diagnostics contain safe status facts and no provider body or secret',async t=>{
 const f=fixture(t);f.config.oneMpayFetch=async()=>Response.json({error:'private text',secret},{status:403});
 const r=await f.create();assert.equal(r.status,202);assert.equal(f.count(),0);
 const row=f.sql.prepare("SELECT target FROM audit WHERE event='payment_order_diagnostic'").get();assert.ok(row);const facts=JSON.parse(row.target);assert.equal(facts.provider,'1mpay');assert.equal(facts.httpStatus,403);assert.equal(facts.kind,'PROVIDER_HTTP');assert.ok(!row.target.includes(secret));assert.ok(!row.target.includes('private text'));
});
test('member ownership, CSRF, approval and complete configuration stop unauthorized orders',async t=>{
 const f=fixture(t);assert.equal((await f.create(undefined,{who:null})).status,401);assert.equal((await f.create(undefined,{who:'owner'})).status,403);assert.equal((await f.create(undefined,{headers:{'X-CSRF-Token':'bad'}})).status,403);
 assert.equal((await f.create(undefined,{headers:{Origin:'https://attacker.example.test'}})).status,403);
 f.sql.prepare("UPDATE users SET approved=0 WHERE id='alice'").run();assert.equal((await f.create()).status,403);f.sql.prepare("UPDATE users SET approved=1 WHERE id='alice'").run();
 f.config.oneMpayMerchant=undefined;assert.equal((await f.create()).status,503);assert.equal(f.state.createCalls,0);
});
test('the 1MPay profile switch blocks only new orders and leaves existing transaction services ready',async t=>{
 const f=fixture(t);f.config.oneMpayOrdersEnabled='false';f.sql.prepare("UPDATE payment_channel_controls SET status='closed' WHERE provider_id='1mpay'").run();
 const status=await f.call('/api/payments/1mpay/status',{who:null});assert.equal(status.data.programReady,true);assert.equal(status.data.enabled,false);assert.equal(status.data.orderReady,false);assert.equal(status.data.queryReady,true);assert.equal(status.data.callbacksReady,true);assert.equal(status.data.reason,'profile_orders_disabled');assert.equal(status.data.availabilityMode,'automatic');assert.equal(status.data.readOnly,true);assert.equal(status.data.channelStatus,'unavailable');
 const rejected=await f.create();assert.equal(rejected.status,503);assert.equal(rejected.data.code,'PROVIDER_ORDERS_DISABLED');assert.equal(f.state.createCalls,0);assert.equal(f.state.queryCalls,0);
});
test('unsigned callback status never establishes success; independent query does',async t=>{
 const f=fixture(t),a=await f.create();f.state.status='Fail';const pending=await f.callback(a.data.id,{status:'Successful'},true);assert.equal(pending.status,503);assert.equal(pending.data,'PENDING');assert.equal(f.count(),0);assert.equal(f.state.queryCalls,1);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_callback_verified' AND target=?").get(a.data.id).n,1);
 f.sql.prepare("INSERT INTO settings(id,value) VALUES('deposit_control:1mpay','paused')").run();
 f.state.status='Successful';assert.equal((await f.callback(a.data.id,{status:'Fail'})).status,200);assert.equal(f.count(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_callback_verified' AND target=?").get(a.data.id).n,1);
});
test('callback receipt persistence fails closed before query or wallet settlement',async t=>{
 const f=fixture(t),a=await f.create();
 f.sql.exec("CREATE TRIGGER reject_callback_receipt BEFORE INSERT ON audit WHEN NEW.event='1mpay_callback_verified' BEGIN SELECT RAISE(ABORT,'synthetic receipt failure'); END");
 const response=await f.callback(a.data.id);assert.equal(response.status,503);assert.equal(response.data,'PENDING');
 assert.equal(f.state.queryCalls,0);assert.equal(f.count(),0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_callback_verified'").get().n,0);
});
test('1MPay successful deposit updates only the paying member wallet and records',async t=>{
 const f=fixture(t),order=await f.create();
 assert.equal((await f.callback(order.data.id)).status,200);
 const alice=await f.call('/api/wallet',{who:'alice'}),bob=await f.call('/api/wallet',{who:'bob'});
 assert.equal(alice.data.balanceMinor,'2000');assert.equal(bob.data.balanceMinor,'0');
 const aliceRecords=await f.call('/api/payment-records',{who:'alice'}),bobRecords=await f.call('/api/payment-records',{who:'bob'});
 assert.ok(aliceRecords.data.items.some(item=>item.id===order.data.id));assert.ok(bobRecords.data.items.every(item=>item.id!==order.data.id));
});
test('late success remains payable after an initial failure and duplicate callbacks credit once',async t=>{
 const f=fixture(t),a=await f.create();f.state.status='Fail';await f.callback(a.data.id);assert.equal(f.count(),0);f.state.status='Successful';
 for(let n=0;n<5;n++){const response=await f.callback(a.data.id);assert.equal(response.status,200);assert.equal(response.data,'ok');}
 assert.equal(f.count(),2);assert.equal(f.sql.prepare('SELECT SUM(amount_minor) n FROM wallet_ledger').get().n,0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(a.data.id).status,'credited');
});
test('an independently unconfirmed query after credit keeps ledger and freezes for review',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id;assert.equal((await f.callback(id)).status,200);
 f.state.status='Pending';const pending=await f.callback(id);assert.equal(pending.status,503);assert.equal(pending.data,'PENDING');assert.equal(f.count(),2);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'review');
 const wallet=await f.call('/api/wallet');assert.equal(wallet.data.availableMinor,'0');assert.equal(wallet.data.reconciliationRequired,true);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_query_conflict_review' AND target=?").get(id).n,1);
 f.state.status='Successful';assert.equal((await f.callback(id)).status,503);assert.equal(f.count(),2);assert.equal(f.state.queryCalls,2);
});
test('independent success after a locally failed order preserves its ledger and requires review',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id;f.sql.prepare("UPDATE deposit_orders SET status='failed' WHERE id=?").run(id);
 const result=await f.callback(id);assert.equal(result.status,503);assert.equal(f.count(),0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'review');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_late_success_review' AND target=?").get(id).n,1);
});
test('a review reached while the independent query is in flight cannot be acknowledged as credited',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id;assert.equal((await f.callback(id)).status,200);
 f.state.queryPatch=value=>{f.sql.prepare("UPDATE deposit_orders SET status='review' WHERE id=?").run(id);return value;};
 const response=await f.callback(id);assert.equal(response.status,503);assert.equal(response.data,'PENDING');assert.equal(f.count(),2);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'review');assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_ledger_review' AND target=?").get(id).n,0);
});
test('a changed order amount while the independent query is in flight cannot be credited',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id;f.state.queryPatch=value=>{f.sql.prepare('UPDATE deposit_orders SET amount_minor=2100 WHERE id=?').run(id);return value;};
 const response=await f.callback(id);assert.equal(response.status,503);assert.equal(f.count(),0);assert.notEqual(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'credited');
});
test('credited create replay and member status require a reference and matching balanced ledger',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id;assert.equal((await f.callback(id)).status,200);
 const credited=await f.create();assert.equal(credited.status,200);assert.equal(credited.data.status,'credited');
 f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL WHERE id=?').run(id);
 const missing=await f.create(),query=await f.call('/api/payments/1mpay/orders/query',{method:'POST',data:{orderId:id}});
 assert.equal(missing.status,409);assert.equal(missing.data.status,'review');assert.equal(query.status,409);assert.equal(query.data.status,'review');
 f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=? WHERE id=?').run('TRX-'+id,id);
 f.sql.prepare("DELETE FROM wallet_ledger WHERE order_id=? AND account_code='provider_clearing'").run(id);
 assert.equal((await f.create()).data.status,'review');assert.equal((await f.call('/api/payments/1mpay/orders/query',{method:'POST',data:{orderId:id}})).data.status,'review');
});
test('credited create replay rejects a consistently altered order and ledger amount',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id;assert.equal((await f.callback(id)).status,200);
 f.sql.prepare('UPDATE deposit_orders SET amount_minor=2100 WHERE id=?').run(id);
 f.sql.prepare("UPDATE wallet_ledger SET amount_minor=CASE account_code WHEN 'member' THEN 2100 ELSE -2100 END WHERE order_id=?").run(id);
 const response=await createOneMpayOrder({amount:'20.00',requestKey:'synthetic-order-key-0001'},{db:f.db,user:{id:'alice',username:'alice',role:'member',approved:1},apiBase,merchant,secretKey:secret,enabled:'true',newDepositsEnabled:'true',callbackUrl:f.config.oneMpayCallbackUrl,returnUrl:f.config.oneMpayReturnUrl,fetchImpl:f.config.oneMpayFetch});
 assert.equal(response.status,409);assert.equal((await response.json()).status,'review');
});
test('created order replay requires its bound transaction and MYR amount before returning checkout',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id;assert.equal(a.status,201);
 f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL WHERE id=?').run(id);
 const missing=await f.create();assert.equal(missing.status,202);assert.equal(missing.data.status,'awaiting_confirmation');assert.equal(missing.data.payUrl,null);
 f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=?,amount_minor=2100 WHERE id=?').run('TRX-'+id,id);
 const mismatch=await f.create();assert.equal(mismatch.status,409);assert.equal(mismatch.data.code,'IDEMPOTENCY_CONFLICT');assert.equal(mismatch.data.payUrl,undefined);
});
test('a delayed create response cannot expose a checkout URL that differs from the stored order',async t=>{
 const f=fixture(t);let release,started;const waiting=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;}),fetch=f.config.oneMpayFetch;
 f.config.oneMpayFetch=async(url,init)=>{const response=await fetch(url,init);if(new URL(url).pathname==='/fundtransfer/json'){started();await waiting;}return response;};
 const creating=f.create();await ready;const id=f.state.lastCreate.refid;
 f.sql.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url=? WHERE id=?").run('TRX-'+id,apiBase+'/fundtransfer/pay/other',id);release();
 const response=await creating;assert.equal(response.status,202);assert.equal(response.data.status,'awaiting_confirmation');assert.equal(response.data.payUrl,null);assert.equal(f.count(),0);
});
test('a callback that settles during a delayed create response is reported only after ledger verification',async t=>{
 const f=fixture(t);let release,started;const waiting=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;}),fetch=f.config.oneMpayFetch;
 f.config.oneMpayFetch=async(url,init)=>{const response=await fetch(url,init);if(new URL(url).pathname==='/fundtransfer/json'){started();await waiting;}return response;};
 const creating=f.create();await ready;const id=f.state.lastCreate.refid;assert.equal((await f.callback(id)).status,200);release();
 const response=await creating;assert.equal(response.status,200);assert.equal(response.data.status,'credited');assert.equal(f.count(),2);
});
test('a late create rejection cannot report failed after a callback has credited the order',async t=>{
 const f=fixture(t);f.state.createResult={code:-1,message:'synthetic rejection',data:{}};
 let release,started;const waiting=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;}),fetch=f.config.oneMpayFetch;
 f.config.oneMpayFetch=async(url,init)=>{const response=await fetch(url,init);if(new URL(url).pathname==='/fundtransfer/json'){started();await waiting;}return response;};
 const creating=f.create();await ready;const id=f.state.lastCreate.refid;assert.equal((await f.callback(id)).status,200);release();
 const response=await creating;assert.equal(response.status,200);assert.equal(response.data.status,'credited');assert.equal(f.count(),2);
});
test('a late create rejection cannot acknowledge a credited order whose request binding changed',async t=>{
 for(const changed of ['amount','fingerprint']){
  const f=fixture(t);f.state.createResult={code:-1,message:'synthetic rejection',data:{}};
  let release,started;const waiting=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;}),fetch=f.config.oneMpayFetch;
  f.config.oneMpayFetch=async(url,init)=>{const response=await fetch(url,init);if(new URL(url).pathname==='/fundtransfer/json'){started();await waiting;}return response;};
  const creating=f.create();await ready;const id=f.state.lastCreate.refid;assert.equal((await f.callback(id)).status,200);
  if(changed==='amount'){
   f.sql.prepare('UPDATE deposit_orders SET amount_minor=2100 WHERE id=?').run(id);
   f.sql.prepare("UPDATE wallet_ledger SET amount_minor=CASE account_code WHEN 'member' THEN 2100 ELSE -2100 END WHERE order_id=?").run(id);
  }else f.sql.prepare("UPDATE deposit_orders SET fingerprint='altered' WHERE id=?").run(id);
  release();const response=await creating;assert.equal(response.status,409);assert.equal(response.data.status,'review');
 }
});
test('a late create rejection cannot discard a callback reference awaiting query',async t=>{
 const f=fixture(t);f.state.createResult={code:-1,message:'synthetic rejection',data:{}};
 let release,started;const waiting=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;}),fetch=f.config.oneMpayFetch;
 f.config.oneMpayFetch=async(url,init)=>{if(new URL(url).pathname.startsWith('/transquery/'))throw Error('Synthetic query timeout');const response=await fetch(url,init);if(new URL(url).pathname==='/fundtransfer/json'){started();await waiting;}return response;};
 const creating=f.create();await ready;const id=f.state.lastCreate.refid;assert.equal((await f.callback(id)).status,503);release();
 const response=await creating;assert.equal(response.status,202);assert.equal(response.data.status,'awaiting_confirmation');const row=f.sql.prepare('SELECT status,provider_trade_no FROM deposit_orders WHERE id=?').get(id);assert.equal(row.status,'creating');assert.equal(row.provider_trade_no,'TRX-'+id);assert.equal(f.count(),0);
});
test('bad callback signatures, amount, member or provider transaction do not credit',async t=>{
 const f=fixture(t),a=await f.create();
 for(const patch of [{token:'invalid'},{amount:'21.00'},{customer:'different'},{trxno:'different'}])assert.equal((await f.callback(a.data.id,patch)).status,401);
 assert.equal(f.count(),0);assert.equal(f.state.queryCalls,0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_callback_verified'").get().n,0);
});
test('an authenticated callback saves a missing reference before a failed query so recovery can credit once',async t=>{
 const f=fixture(t),created=await f.create(),id=created.data.id;f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL WHERE id=?').run(id);
 assert.equal((await f.callback(id,{token:'invalid'})).status,401);assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(id).provider_trade_no,null);
 const original=f.state.orders.get(id),otherAmountToken=oneMpayCallbackToken(merchant,'21.00',id,original.customer,secret,original.trxno);
 assert.equal((await f.callback(id,{amount:'21.00',token:otherAmountToken})).status,409);assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(id).provider_trade_no,null);
 const fetch=f.config.oneMpayFetch;f.config.oneMpayFetch=async(url,init)=>{if(new URL(url).pathname.startsWith('/transquery/'))throw Error('Synthetic query timeout');return fetch(url,init);};
 assert.equal((await f.callback(id)).status,503);assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(id).provider_trade_no,'TRX-'+id);assert.equal(f.count(),0);
 f.config.oneMpayFetch=fetch;f.config.oneMpayRecoveryEnabled='true';f.sql.prepare('UPDATE deposit_orders SET updated_at=? WHERE id=?').run(Math.floor(Date.now()/1000)-120,id);
 const token='recovery-fixture-token-'.padEnd(40,'r');for(let n=0;n<2;n++)assert.equal((await f.call('/api/internal/payment-recovery',{who:null,method:'POST',headers:{Authorization:'Bearer '+token},extra:{paymentRecoveryToken:token}})).status,200);
 assert.equal(f.count(),2);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'credited');assert.equal(f.state.createCalls,1);assert.equal(f.state.queryCalls,1);
});

test('competing signed callbacks cannot bind two references to one order',async t=>{
 const f=fixture(t),created=await f.create(),id=created.data.id,order=f.state.orders.get(id);f.sql.prepare('UPDATE deposit_orders SET provider_trade_no=NULL WHERE id=?').run(id);
 let release,started;const waiting=new Promise(resolve=>{release=resolve;}),queried=new Promise(resolve=>{started=resolve;}),fetch=f.config.oneMpayFetch;
 f.config.oneMpayFetch=async(url,init)=>{if(new URL(url).pathname.startsWith('/transquery/')){started();await waiting;}return fetch(url,init);};
 const first=f.callback(id);await queried;const alternate='TRX-ALTERNATE',token=oneMpayCallbackToken(merchant,order.amount,id,order.customer,secret,alternate);
 const second=await f.callback(id,{trxno:alternate,token});assert.equal(second.status,409);release();assert.equal((await first).status,200);
 assert.equal(f.sql.prepare('SELECT provider_trade_no FROM deposit_orders WHERE id=?').get(id).provider_trade_no,order.trxno);assert.equal(f.count(),2);assert.equal(f.state.queryCalls,1);
});

test('a review-held 1MPay order never emits a false credited audit',async t=>{
 const f=fixture(t),created=await f.create(),id=created.data.id;f.sql.prepare("UPDATE deposit_orders SET status='review' WHERE id=?").run(id);
 const response=await f.callback(id);assert.equal(response.status,503);assert.equal(response.data,'REVIEW_REQUIRED');assert.equal(f.state.queryCalls,0);assert.equal(f.count(),0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_deposit_credited' AND target=?").get(id).n,0);
});
test('trusted query must match merchant, amount, order, customer, transaction and signature',async t=>{
 const f=fixture(t),a=await f.create();
 for(const [key,value]of [['merchant','other'],['amount','21.00'],['refid','other'],['customer','other'],['trxno','other'],['token','bad'],['currency','USD']]){
  f.state.queryPatch=x=>({...x,[key]:value});assert.equal((await f.callback(a.data.id)).status,503);assert.equal(f.count(),0);
 }
});
test('member query can reconcile only their own order and completes an outstanding closed channel',async t=>{
 const f=fixture(t),a=await f.create();f.sql.prepare("UPDATE payment_channel_controls SET status='closed' WHERE provider_id='1mpay'").run();f.config.newDepositsEnabled='false';
 assert.equal((await f.call('/api/payments/1mpay/orders/query',{who:'bob',method:'POST',data:{orderId:a.data.id}})).status,404);assert.equal(f.count(),0);
 const r=await f.call('/api/payments/1mpay/orders/query',{method:'POST',data:{orderId:a.data.id}});assert.equal(r.data.status,'credited');assert.equal(f.count(),2);
});
test('failed atomic ledger batch rolls back both entries and can safely retry',async t=>{
 const f=fixture(t),a=await f.create();f.sql.exec("CREATE TRIGGER fixture_fail_clearing BEFORE INSERT ON wallet_ledger WHEN NEW.account_code='provider_clearing' BEGIN SELECT RAISE(ABORT,'fixture failure'); END;");
 assert.equal((await f.callback(a.data.id)).status,503);assert.equal(f.count(),0);assert.notEqual(f.sql.prepare('SELECT status FROM deposit_orders').get().status,'credited');
 f.sql.exec('DROP TRIGGER fixture_fail_clearing');assert.equal((await f.callback(a.data.id)).status,200);assert.equal(f.count(),2);
});
test('an inconsistent existing ledger is held for review before any new financial entry',async t=>{
 const f=fixture(t),a=await f.create();f.sql.prepare("INSERT INTO wallet_ledger VALUES('bad',?,'alice','member',1,'MYR',0)").run(a.data.id);
 assert.equal((await f.callback(a.data.id)).status,503);assert.equal(f.count(),1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders').get().status,'review');
});
test('ambiguous provider timeout records one order and does not resubmit it on retry',async t=>{
 const f=fixture(t);f.state.createError=true;const a=await f.create(),b=await f.create();assert.equal(a.status,202);assert.equal(a.data.id,b.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.count(),0);
});
test('a historical unknown order is changed only when its own safe audit proves provider rejection',async t=>{
 const f=fixture(t);f.state.createError=true;const unknown=await f.create();assert.equal(unknown.status,202);
 const unrelated='M7historicalunknown01';f.sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,?,'1mpay',?,'MYR','bank','unknown',0,0)").run(unrelated,'alice','historical-unrelated-key','historical-unrelated-fingerprint','2000');
 f.sql.prepare("UPDATE audit SET target=? WHERE event='payment_order_diagnostic' AND target LIKE ?").run(JSON.stringify({provider:'1mpay',orderId:unknown.data.id,kind:'ORDER_RESPONSE',providerCode:-1}),`%${unknown.data.id}%`);
 const records=await f.call('/api/payment-records');assert.equal(records.status,200);assert.equal(records.data.items.find(x=>x.id===unknown.data.id).status,'failed');assert.equal(records.data.items.find(x=>x.id===unrelated).status,'unknown');
 const replay=await f.create();assert.equal(replay.status,422);assert.equal(replay.data.error,'PROVIDER_REJECTED');assert.equal(f.state.createCalls,1);
});
test('explicit provider business rejection becomes failed and permits only a new explicit attempt',async t=>{
 const f=fixture(t);f.state.createResult={code:-1,message:'private provider rejection',data:{}};
 const a=await f.create(),replay=await f.create();
 assert.equal(a.status,422);assert.deepEqual(a.data,{error:'PROVIDER_REJECTED',id:a.data.id,status:'failed',payUrl:null});
 assert.equal(replay.status,422);assert.equal(replay.data.id,a.data.id);assert.equal(f.state.createCalls,1);assert.equal(f.count(),0);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(a.data.id).status,'failed');
 const diagnostic=JSON.parse(f.sql.prepare("SELECT target FROM audit WHERE event='payment_order_diagnostic' AND target LIKE ?").get(`%${a.data.id}%`).target);
 assert.equal(diagnostic.providerCode,-1);assert.ok(!JSON.stringify(diagnostic).includes('private provider rejection'));
 f.state.createResult=null;const next=await f.create('synthetic-order-key-0002');assert.equal(next.status,201);assert.notEqual(next.data.id,a.data.id);assert.equal(f.state.createCalls,2);
});
test('ambiguous response with provider reference retains it for reconciliation without resubmission',async t=>{
 const f=fixture(t);f.state.createResult={code:0,message:'created without checkout',data:{trxno:'AMBIGUOUS-TRX-1'}};
 const a=await f.create(),replay=await f.create();assert.equal(a.status,202);assert.equal(replay.status,202);assert.equal(f.state.createCalls,1);
 const row=f.sql.prepare('SELECT status,provider_trade_no FROM deposit_orders WHERE id=?').get(a.data.id);assert.deepEqual({...row},{status:'unknown',provider_trade_no:'AMBIGUOUS-TRX-1'});
});
test('untrusted checkout destinations and invalid monetary precision are rejected',async t=>{
 const f=fixture(t);
 for(const amount of ['0','-1','20.001','2e1','100000.01'])assert.equal((await f.call('/api/payments/1mpay/orders',{method:'POST',data:{amount,requestKey:'synthetic-invalid-amount'}})).status,400);
 f.state.checkout='https://attacker.example.test/pay';const a=await f.create();assert.equal(a.status,202);assert.equal(a.data.payUrl,null);assert.equal(f.count(),0);
});
test('callback duplicate form fields and oversized bodies are rejected without a query',async t=>{
 const f=fixture(t),a=await f.create();
 for(const body of ['refid='+a.data.id+'&refid=other','x='+ 'a'.repeat(8200)]){
  const r=await handle(new Request(origin+'/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body}),f.config);assert.equal(r.status,400);
 }
 assert.equal(f.state.queryCalls,0);assert.equal(f.count(),0);
});
test('outbound IP diagnostics requires a distinct private bearer and exposes no credentials',async t=>{
 const f=fixture(t);assert.equal((await f.call('/api/payments/1mpay/diagnostics',{who:null})).status,401);
 f.config.oneMpayFetch=async url=>{assert.equal(url,'https://api64.ipify.org?format=json');return Response.json({ip:'203.0.113.10'});};
 const r=await f.call('/api/payments/1mpay/diagnostics',{who:null,headers:{Authorization:'Bearer '+f.config.oneMpayDiagnosticToken}});assert.equal(r.status,200);assert.equal(r.data.source,'payment-application');assert.equal(r.data.fixedIpVerified,false);assert.ok(!JSON.stringify(r.data).includes(secret));
});
test('provider migration preserves historical VPay orders, ledger values, uniqueness and foreign keys',()=>{
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of ['0000_broken_bloodscream.sql','0007_vpay_uat_wallet.sql'])sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('a','a','member',1,'csrf',0); INSERT INTO deposit_orders VALUES('old','a','key','fingerprint','vpay',2000,'MYR','1','credited','TRADE',NULL,NULL,0,0); INSERT INTO wallet_ledger VALUES('m','old','a','member',2000,'MYR',0),('c','old','a','provider_clearing',-2000,'MYR',0)");
 const oldOrders=sql.prepare('SELECT * FROM deposit_orders').all(),oldLedger=sql.prepare('SELECT * FROM wallet_ledger ORDER BY id').all();
 sql.exec(readFileSync(new URL('../drizzle/0017_payment_providers.sql',import.meta.url),'utf8'));
 assert.deepEqual(sql.prepare('SELECT * FROM deposit_orders').all(),oldOrders);assert.deepEqual(sql.prepare('SELECT * FROM wallet_ledger ORDER BY id').all(),oldLedger);assert.deepEqual(sql.prepare('PRAGMA foreign_key_check').all(),[]);assert.equal(sql.prepare('PRAGMA foreign_keys').get().foreign_keys,1);
 assert.throws(()=>sql.exec("INSERT INTO wallet_ledger VALUES('duplicate','old','a','member',2000,'MYR',0)"),/UNIQUE/);assert.throws(()=>sql.exec("DELETE FROM deposit_orders WHERE id='old'"),/FOREIGN KEY/);sql.close();
});

test('a verified existing 1MPay deposit can settle once after manual review is revoked',async t=>{
 const f=fixture(t);f.config.manualComplianceEnforced='true';
 assert.equal((await f.call('/api/compliance',{method:'POST',data:{}})).status,200);
 for(const [reviewType,expectedVersion] of [['identity',1],['aml',2]]){
  const result=await f.call('/api/admin/compliance',{who:'owner',method:'POST',data:{memberId:'alice',reviewType,decision:'passed',expectedVersion,confirmed:true}});assert.equal(result.status,200);
 }
 const created=await f.create();assert.equal(created.status,201);
 const revoked=await f.call('/api/admin/compliance',{who:'owner',method:'POST',data:{memberId:'alice',reviewType:'aml',decision:'failed',expectedVersion:3,confirmed:true}});assert.equal(revoked.status,200);
 const blocked=await f.create('synthetic-order-key-0002');assert.equal(blocked.data.code,'COMPLIANCE_REVIEW_REQUIRED');assert.equal(f.state.createCalls,1);
 assert.equal((await f.callback(created.data.id)).status,200);assert.equal((await f.callback(created.data.id)).status,200);
 assert.equal(f.count(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
});

test('closing new deposits leaves a preexisting 1MPay callback and wallet credit recoverable once',async t=>{
 const f=fixture(t),created=await f.create();assert.equal(created.status,201);f.config.newDepositsEnabled='false';
 const status=await f.call('/api/payments/1mpay/status',{who:null});assert.equal(status.data.orderReady,false);assert.equal(status.data.queryReady,true);assert.equal(status.data.callbacksReady,true);
 const denied=await f.create('synthetic-order-key-0002');assert.equal(denied.data.code,'DEPOSITS_MAINTENANCE');assert.equal(f.state.createCalls,1);
 assert.equal((await f.callback(created.data.id)).status,200);assert.equal((await f.callback(created.data.id)).status,200);assert.equal(f.count(),2);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'2000');
});

test('1MPay locks and preserves a partial ledger created during provider query',async t=>{
 for(const existingAmount of [1,2000]){
  const f=fixture(t),a=await f.create(`partial-ledger-key-${existingAmount}-abcd`),id=a.data.id;
  // Give the member independent valid funds so the review freeze is observable.
  const good=`good-${existingAmount}`;
  f.sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,'alice',?,'fixture','manual_bank',5000,'MYR','bank','credited',0,0)").run(good,`good-key-${existingAmount}`);
  f.sql.prepare("INSERT INTO wallet_ledger VALUES(?,?,'alice','member',5000,'MYR',0),(?,?,'alice','provider_clearing',-5000,'MYR',0)").run(`m-${existingAmount}`,good,`c-${existingAmount}`,good);
  const upstream=f.config.oneMpayFetch;
  f.config.oneMpayFetch=async(url,init)=>{const response=await upstream(url,init);if(new URL(url).pathname.startsWith('/transquery/'))f.sql.prepare("INSERT INTO wallet_ledger VALUES(?,?,'alice','member',?,'MYR',0)").run(`partial-${existingAmount}`,id,existingAmount);return response;};
  const result=await f.callback(id);assert.equal(result.status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'review');
  assert.deepEqual(f.sql.prepare('SELECT account_code,amount_minor FROM wallet_ledger WHERE order_id=?').all(id).map(x=>({...x})),[{account_code:'member',amount_minor:existingAmount}]);
  assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_deposit_credited' AND target=?").get(id).n,0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_ledger_review' AND target=?").get(id).n,1);
  const wallet=await f.call('/api/wallet');assert.equal(wallet.data.balanceMinor,'5000');assert.equal(wallet.data.availableMinor,'0');assert.equal(wallet.data.reconciliationRequired,true);
 }
});

test('a concurrently credited 1MPay order with missing ledger legs enters review',async t=>{
 const f=fixture(t),a=await f.create(),id=a.data.id,upstream=f.config.oneMpayFetch;
 f.config.oneMpayFetch=async(url,init)=>{const response=await upstream(url,init);if(new URL(url).pathname.startsWith('/transquery/'))f.sql.prepare("UPDATE deposit_orders SET status='credited' WHERE id=?").run(id);return response;};
 assert.equal((await f.callback(id)).status,503);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').get(id).n,0);
});
