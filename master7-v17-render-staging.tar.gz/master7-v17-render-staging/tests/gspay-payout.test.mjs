import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {gspayPayoutResultSignature,gspayPayoutSignature,submitGSPayPayout} from '../lib/gspay.ts';
import {encryptWithdrawalValue} from '../lib/withdrawal-secrets.ts';

// All provider traffic in this suite is synthetic. No test contacts GSPAY.
const origin='https://portal.example.test',apiBase='https://api.thegspay.com',authKey='a'.repeat(32),secretKey='b'.repeat(32),dataKey='withdrawal-data-key-'+ 'w'.repeat(40),returnUrl='https://www.master7.best/payment/return';
const bankCodes=['maybank','cimb','public_bank','rhb','hong_leong','ambank','bank_islam','bank_rakyat','bsn','alliance','affin','ocbc','uob','hsbc','standard_chartered','agrobank','bank_muamalat','mbsb'];
const bankTargets=Object.fromEntries(bankCodes.map((code,index)=>[code,`BANK_${index+1}`]));

function fixture(t,{ready=true}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf-alice',0),('owner','owner','owner',1,'csrf-owner',0)").run();
 sql.prepare("UPDATE payment_channel_controls SET status='active' WHERE provider_id='gspay'").run();sql.prepare("UPDATE provider_payout_controls SET submission_enabled=1 WHERE provider_id='gspay'").run();
 sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('funding-order','alice','funding-request','f','vpay',10000,'MYR','1','credited',0,0)").run();
 sql.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('fund-member','funding-order','alice','member',10000,'MYR',0),('fund-clear','funding-order','alice','provider_clearing',-10000,'MYR',0)").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const results=[];for(const statement of statements)results.push(sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return results;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={postCalls:0,queryCalls:0,completed:true,success:true,throwPost:false,payoutId:'60001234',orders:new Map()};
 const config={db,identity:null,ownerEmail:'',allowedOrigins:[origin],withdrawalDataKey:dataKey,gspayApiBase:apiBase,gspayAuthKey:authKey,gspaySecretKey:secretKey,gspayOrdersEnabled:'false',gspayReturnUrl:returnUrl,gspayPayoutEnabled:'true',gspayPayoutIpWhitelistConfirmed:ready?'true':'false',gspayPayoutBankTargetsJson:JSON.stringify(bankTargets),gspayFetch:async(input,init={})=>{
  const url=new URL(String(input)),postPath=`/v2/integrations/operators/${authKey}/payout`,statusPath=`/v2/integrations/operators/${authKey}/payout/status`;
  if(url.pathname===postPath){state.postCalls++;assert.equal(init.method,'POST');const body=JSON.parse(init.body);assert.deepEqual(Object.keys(body).sort(),['account_name','account_number','amount','bank_target','player_username','signature','transaction_id','trx_description']);assert.equal(body.account_name,'Alice Example');assert.equal(body.account_number,'123456789012');assert.equal(body.amount,20);assert.equal(body.bank_target,bankTargets.maybank);assert.equal(body.signature,gspayPayoutSignature(body.transaction_id,body.player_username,'20.00',body.account_number,secretKey));assert.ok(!init.body.includes(secretKey));state.orders.set(body.transaction_id,body);if(state.throwPost)throw Error('synthetic timeout');return Response.json({code:200,data:JSON.stringify([{payout_id:state.payoutId}]),message:'ok'});}
  assert.equal(url.pathname,statusPath);assert.equal(init.method,'GET');assert.equal(url.searchParams.get('auth_key'),authKey);const transaction=url.searchParams.get('transaction_id'),order=state.orders.get(transaction);assert.ok(order);state.queryCalls++;const result={payout_id:state.payoutId,transaction_id:transaction,account_name:order.account_name,account_number:order.account_number,amount:'20.00',completed:state.completed,payout_success:state.success,remark:state.success?'paid':'pending',signature:gspayPayoutResultSignature(state.payoutId,order.account_number,'20.00',transaction,secretKey)};return Response.json({code:200,data:JSON.stringify([result]),message:'ok'});
 }};
 async function call(path,{who='alice',method='GET',data,extra={},headers={}}={}){const response=await handle(new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,...headers},...(data===undefined?{}:{body:JSON.stringify(data)})}),{...config,identity:who?{userId:who,email:who+'@example.test'}:null,...extra});return {status:response.status,data:response.headers.get('content-type')?.includes('application/json')?await response.json():await response.text()};}
 const payload=(overrides={})=>({providerId:'gspay',bankCode:'maybank',accountHolder:'Alice Example',accountNumber:'1234-5678-9012',amount:'20.00',requestKey:'gspay-payout-request-0001',...overrides});
 async function callback(patch={}){const payout=sql.prepare("SELECT id FROM provider_payouts WHERE provider_id='gspay'").get(),order=state.orders.get(payout.id),values={auth_key:authKey,payout_id:state.payoutId,transaction_id:payout.id,account_name:order.account_name,account_number:order.account_number,amount:'20.00',completed:true,payout_success:true,remark:'paid',...patch};if(values.signature===undefined)values.signature=gspayPayoutResultSignature(String(values.payout_id),String(values.account_number),Number(values.amount).toFixed(2),String(values.transaction_id),secretKey);const response=await handle(new Request(origin+'/api/payment/gspay/payout/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values)}),{...config,identity:null});return {status:response.status,data:await response.text()};}
 t.after(()=>sql.close());return {sql,db,state,config,call,payload,callback};
}

test('GSPAY payout stays closed until its independent prerequisites and control are ready',async t=>{
 const f=fixture(t,{ready:false}),before=f.state.postCalls,channels=await f.call('/api/withdrawal-banks',{who:null});assert.equal(channels.data.enabled,false);assert.equal(channels.data.providers.find(item=>item.id==='gspay').enabled,false);
 const result=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(result.status,503);assert.equal(f.state.postCalls,before);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,0);
});

test('signed GSPAY payout submission, independent status query and wallet debit are idempotent',async t=>{
 const f=fixture(t),status=await f.call('/api/payments/gspay/status',{who:null});assert.equal(status.data.capabilities.payout.implemented,true);assert.equal(status.data.capabilities.payout.submissionEnabled,true);
 const first=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(first.status,201);assert.equal(first.data.status,'paid');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);
 assert.deepEqual({...f.sql.prepare('SELECT status FROM withdrawal_requests').get()},{status:'paid'});assert.deepEqual({...f.sql.prepare('SELECT status,create_outcome,provider_reference FROM provider_payouts').get()},{status:'succeeded',create_outcome:'accepted',provider_reference:f.state.payoutId});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 const wallet=await f.call('/api/wallet');assert.equal(wallet.data.balanceMinor,'8000');assert.equal(wallet.data.availableMinor,'8000');
 const replay=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(replay.status,200);assert.equal(replay.data.status,'paid');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);
 const conflict=await f.call('/api/withdrawals',{method:'POST',data:f.payload({amount:'21.00'})});assert.equal(conflict.status,409);assert.equal(f.state.postCalls,1);
});

test('payout callback cannot mark paid until a separate signed status query confirms success',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;const created=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(created.status,202);assert.equal(created.data.status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
 let wallet=await f.call('/api/wallet');assert.equal(wallet.data.availableMinor,'8000');f.state.completed=true;f.state.success=true;const before=f.state.queryCalls,callback=await f.callback();assert.equal(callback.status,200);assert.equal(callback.data,'ok');assert.equal(f.state.queryCalls,before+1);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);wallet=await f.call('/api/wallet');assert.equal(wallet.data.balanceMinor,'8000');
});

test('forged payout callback cannot query, pay or release the held balance',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.call('/api/withdrawals',{method:'POST',data:f.payload()});const before=f.state.queryCalls,result=await f.callback({signature:'0'.repeat(32)});assert.equal(result.status,401);assert.equal(f.state.queryCalls,before);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
});

test('independently confirmed provider failure rejects the request and releases the reservation',async t=>{
 const f=fixture(t);f.state.completed=true;f.state.success=false;const result=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(result.status,202);assert.equal(result.data.status,'failed');assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'rejected');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'failed');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await f.call('/api/wallet')).data.availableMinor,'10000');
});

test('ambiguous submission is never resent and protected recovery only queries its status',async t=>{
 const f=fixture(t);f.state.throwPost=true;const created=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(created.status,202);assert.equal(created.data.status,'processing');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,0);
 const replay=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(replay.status,200);assert.equal(f.state.postCalls,1);f.state.throwPost=false;f.state.completed=true;f.state.success=true;const token='recovery-token-'.padEnd(40,'r'),recovered=await f.call('/api/internal/payment-recovery',{who:null,method:'POST',headers:{authorization:'Bearer '+token},extra:{paymentRecoveryToken:token}});assert.equal(recovered.status,200);assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');
});

test('concurrent payout submission has one atomic provider caller',async t=>{
 const f=fixture(t),withdrawalId='race-withdrawal',payoutId='P7racepayout00000000000000000001',requestKey='race-request-key-000001';
 f.sql.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'MYR','pending','',0,0)").run(withdrawalId,'alice',requestKey,'gspay','GSPAY','maybank','Maybank',encryptWithdrawalValue('Alice Example',dataKey),encryptWithdrawalValue('123456789012',dataKey),'9012',2000);
 f.sql.prepare("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,created_at,updated_at) VALUES(?,?, 'gspay',?, 'race-fingerprint',2000,'MYR','prepared','not_submitted',0,0)").run(payoutId,withdrawalId,requestKey);
 const originalFetch=f.config.gspayFetch;let release;const gate=new Promise(resolve=>{release=resolve;});
 const context={db:f.db,user:{id:'alice',username:'alice',role:'member',approved:1},apiBase,authKey,secretKey,returnUrl,payoutEnabled:'true',payoutIpWhitelistConfirmed:'true',payoutBankTargetsJson:JSON.stringify(bankTargets),withdrawalDataKey:dataKey,fetchImpl:async(input,init)=>{const response=await originalFetch(input,init);if(new URL(String(input)).pathname.endsWith('/payout'))await gate;return response;}};
 const input={payoutId,withdrawalId,userId:'alice',accountHolder:'Alice Example',accountNumber:'123456789012',bankCode:'maybank',amountMinor:'2000'},first=submitGSPayPayout(input,context);
 while(f.state.postCalls<1)await new Promise(resolve=>setImmediate(resolve));
 const concurrent=await submitGSPayPayout(input,context);assert.equal(concurrent.status,'processing');assert.equal(f.state.postCalls,1);
 release();const completed=await first;assert.equal(completed.status,'succeeded');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);
});
