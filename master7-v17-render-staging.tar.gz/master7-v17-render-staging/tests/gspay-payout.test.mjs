import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {gspayPayoutResultSignature,gspayPayoutSignature,submitGSPayPayout} from '../lib/gspay.ts';
import {encryptWithdrawalValue} from '../lib/withdrawal-secrets.ts';

// All provider traffic in this suite is synthetic. No test contacts GSPAY.
const origin='https://portal.example.test',apiBase='https://api.thegspay.com',authKey='a'.repeat(32),secretKey='b'.repeat(32),dataKey='withdrawal-data-key-'+ 'w'.repeat(40),returnUrl='https://master7-v17-staging.onrender.com/payment/return';
const bankCodes=['maybank','cimb','public_bank','rhb','hong_leong','ambank','bank_islam','bank_rakyat','bsn','alliance','affin','ocbc','uob','hsbc','standard_chartered','agrobank','bank_muamalat','mbsb'];
const bankTargets=Object.fromEntries(bankCodes.map((code,index)=>[code,`BANK_${index+1}`]));

function fixture(t,{ready=true}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf-alice',0),('owner','owner','owner',1,'csrf-owner',0)").run();
 sql.prepare("UPDATE payment_channel_controls SET status='active' WHERE provider_id='gspay'").run();sql.prepare("UPDATE provider_payout_controls SET submission_enabled=1 WHERE provider_id='gspay'").run();
 sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('funding-order','alice','funding-request','f','vpay',10000,'MYR','1','credited',0,0)").run();
 sql.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('fund-member','funding-order','alice','member',10000,'MYR',0),('fund-clear','funding-order','alice','provider_clearing',-10000,'MYR',0)").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const results=[];for(const statement of statements)results.push(sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return results;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 sql.exec("INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('alice','passed','passed',1,'c',0,0)");
 const state={postCalls:0,queryCalls:0,completed:true,success:true,throwPost:false,payoutId:'60001234',orders:new Map()};
 const config={db,identity:null,ownerEmail:'',allowedOrigins:[origin],newPayoutsEnabled:'true',withdrawalDataKey:dataKey,gspayApiBase:apiBase,gspayAuthKey:authKey,gspaySecretKey:secretKey,gspayOrdersEnabled:'false',gspayReturnUrl:returnUrl,gspayPayoutEnabled:'true',gspayPayoutIpWhitelistConfirmed:ready?'true':'false',gspayPayoutBankTargetsJson:JSON.stringify(bankTargets),gspayFetch:async(input,init={})=>{
  const url=new URL(String(input)),postPath=`/v2/integrations/operators/${authKey}/payout`,statusPath=`/v2/integrations/operators/${authKey}/payout/status`;
  if(url.pathname===postPath){state.postCalls++;assert.equal(init.method,'POST');const body=JSON.parse(init.body);assert.deepEqual(Object.keys(body).sort(),['account_name','account_number','amount','bank_target','player_username','signature','transaction_id','trx_description']);assert.equal(body.account_name,'Alice Example');assert.equal(body.account_number,'123456789012');assert.equal(body.amount,20);assert.equal(body.bank_target,bankTargets.maybank);assert.equal(body.signature,gspayPayoutSignature(body.transaction_id,body.player_username,'20.00',body.account_number,secretKey));assert.ok(!init.body.includes(secretKey));state.orders.set(body.transaction_id,body);if(state.throwPost)throw Error('synthetic timeout');return Response.json({code:200,data:JSON.stringify([{payout_id:state.payoutId}]),message:'ok'});}
  assert.equal(url.pathname,statusPath);assert.equal(init.method,'GET');assert.equal(url.searchParams.get('auth_key'),authKey);const transaction=url.searchParams.get('transaction_id'),order=state.orders.get(transaction);assert.ok(order);state.queryCalls++;const result={payout_id:state.payoutId,transaction_id:transaction,account_name:order.account_name,account_number:order.account_number,amount:'20.00',completed:state.completed,payout_success:state.success,...(state.currency===undefined?{}:{currency:state.currency}),remark:state.success?'paid':'pending',signature:gspayPayoutResultSignature(state.payoutId,order.account_number,'20.00',transaction,secretKey)};return Response.json({code:200,data:JSON.stringify([result]),message:'ok'});
 }};
 async function call(path,{who='alice',method='GET',data,extra={},headers={}}={}){const response=await handle(new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,...headers},...(data===undefined?{}:{body:JSON.stringify(data)})}),{...config,identity:who?{userId:who,email:who+'@example.test'}:null,...extra});return {status:response.status,data:response.headers.get('content-type')?.includes('application/json')?await response.json():await response.text()};}
 async function createAndApprove(options){
  const created=await call('/api/withdrawals',options);
  if(created.status!==201)return created;
  assert.equal(created.data.status,'pending');
  const list=await call('/api/admin/withdrawals',{who:'owner'});assert.equal(list.status,200);
  const reviewed=list.data.items.find(item=>item.id===created.data.withdrawal.id);assert.equal(reviewed.approvalEligible,true);
  const approved=await call('/api/admin/withdrawals/approve',{who:'owner',method:'POST',data:{id:reviewed.id,approvalFingerprint:reviewed.approvalFingerprint,ownerNote:'Synthetic test approval'}});
  assert.equal(approved.status,202);return approved;
 }
 const payload=(overrides={})=>({providerId:'gspay',bankCode:'maybank',accountHolder:'Alice Example',accountNumber:'1234-5678-9012',amount:'20.00',requestKey:'gspay-payout-request-0001',...overrides});
 async function callback(patch={}){const payout=sql.prepare("SELECT id FROM provider_payouts WHERE provider_id='gspay'").get(),order=state.orders.get(payout.id),values={auth_key:authKey,payout_id:state.payoutId,transaction_id:payout.id,account_name:order.account_name,account_number:order.account_number,amount:'20.00',completed:true,payout_success:true,remark:'paid',...patch};if(values.signature===undefined)values.signature=gspayPayoutResultSignature(String(values.payout_id),String(values.account_number),Number(values.amount).toFixed(2),String(values.transaction_id),secretKey);const response=await handle(new Request(origin+'/api/payment/gspay/payout/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values)}),{...config,identity:null});return {status:response.status,data:await response.text()};}
 t.after(()=>sql.close());return {sql,db,state,config,call,createAndApprove,payload,callback};
}

test('GSPAY payout stays closed until its independent prerequisites and control are ready',async t=>{
 const f=fixture(t,{ready:false}),before=f.state.postCalls,channels=await f.call('/api/withdrawal-banks',{who:null});assert.equal(channels.data.enabled,false);assert.equal(channels.data.providers.find(item=>item.id==='gspay').enabled,false);
 const result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.status,503);assert.equal(f.state.postCalls,before);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,0);
});

test('signed GSPAY payout submission, independent status query and wallet debit are idempotent',async t=>{
 const f=fixture(t),status=await f.call('/api/payments/gspay/status',{who:null});assert.equal(status.data.capabilities.payout.implemented,true);assert.equal(status.data.capabilities.payout.submissionEnabled,true);
 const first=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(first.status,202);assert.equal(first.data.status,'paid');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);
 assert.deepEqual({...f.sql.prepare('SELECT status FROM withdrawal_requests').get()},{status:'paid'});assert.deepEqual({...f.sql.prepare('SELECT status,create_outcome,provider_reference FROM provider_payouts').get()},{status:'succeeded',create_outcome:'accepted',provider_reference:f.state.payoutId});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 const wallet=await f.call('/api/wallet');assert.equal(wallet.data.balanceMinor,'8000');assert.equal(wallet.data.availableMinor,'8000');
 const replay=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(replay.status,200);assert.equal(replay.data.status,'paid');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);
 const conflict=await f.call('/api/withdrawals',{method:'POST',data:f.payload({amount:'21.00'})});assert.equal(conflict.status,409);assert.equal(f.state.postCalls,1);
});

test('payout callback cannot mark paid until a separate signed status query confirms success',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;const created=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(created.status,202);assert.equal(created.data.status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
 let wallet=await f.call('/api/wallet');assert.equal(wallet.data.availableMinor,'8000');f.state.completed=true;f.state.success=true;const before=f.state.queryCalls,callback=await f.callback();assert.equal(callback.status,200);assert.equal(callback.data,'ok');assert.equal(f.state.queryCalls,before+1);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);wallet=await f.call('/api/wallet');assert.equal(wallet.data.balanceMinor,'8000');
});

test('forged payout callback cannot query, pay or release the held balance',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});const before=f.state.queryCalls,result=await f.callback({signature:'0'.repeat(32)});assert.equal(result.status,401);assert.equal(f.state.queryCalls,before);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
});

test('provider failure requires review and leaves the withdrawal amount held',async t=>{
 const f=fixture(t);f.state.completed=true;f.state.success=false;const result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.status,202);assert.equal(result.data.status,'review');assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await f.call('/api/wallet')).data.availableMinor,'0');
});

test('incomplete payout status cannot be interpreted as failure or release funds',async t=>{
 for(const [completed,success] of [[undefined,false],[true,undefined],[null,false],[false,true],['true',false]]){
  const f=fixture(t);f.state.completed=completed;f.state.success=success;const result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.status,202);assert.equal(result.data.status,'processing');assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await f.call('/api/wallet')).data.availableMinor,'8000');
 }
});

test('provider payout currency mismatch enters review and retains funds',async t=>{
 const f=fixture(t);f.state.currency='USD';const result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.status,202);assert.equal(result.data.status,'review');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
});

test('success without a matching reservation stays in review instead of marking paid',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});f.sql.prepare('DELETE FROM wallet_reservations').run();
 f.state.completed=true;f.state.success=true;assert.equal((await f.callback()).status,409);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');
});

test('old succeeded payout with a processing withdrawal cannot borrow a new success update',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});f.sql.prepare("UPDATE provider_payouts SET status='succeeded'").run();
 f.state.completed=true;f.state.success=true;assert.equal((await f.callback()).status,409);assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'succeeded');assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await f.call('/api/wallet')).data.availableMinor,'0');
});

test('old paid payout with no provider reference cannot claim confirmed success',async t=>{
 const f=fixture(t);await f.createAndApprove({method:'POST',data:f.payload()});f.sql.prepare("UPDATE provider_payouts SET provider_reference=NULL").run();
 assert.equal((await f.callback()).status,409);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT provider_reference FROM provider_payouts').get().provider_reference,null);
});

test('changed payout details during provider status query cannot settle the altered record',async t=>{
 for(const change of ['bank','account','holder','fingerprint','amount']){
  const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});
  const fetch=f.config.gspayFetch;let release,started;const gate=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;});
  f.config.gspayFetch=async(...args)=>{const response=await fetch(...args);started();await gate;return response;};f.state.completed=true;f.state.success=true;const pending=f.callback();await ready;
  if(change==='bank')f.sql.prepare("UPDATE withdrawal_requests SET bank_code='cimb'").run();
  if(change==='account')f.sql.prepare('UPDATE withdrawal_requests SET account_number_encrypted=?').run(encryptWithdrawalValue('987654321098',dataKey));
  if(change==='holder')f.sql.prepare('UPDATE withdrawal_requests SET account_holder_encrypted=?').run(encryptWithdrawalValue('Alice Changed',dataKey));
  if(change==='fingerprint')f.sql.prepare("UPDATE provider_payouts SET fingerprint='altered'").run();
  if(change==='amount'){f.sql.prepare('UPDATE withdrawal_requests SET amount_minor=2100').run();f.sql.prepare('UPDATE provider_payouts SET amount_minor=2100').run();f.sql.prepare('UPDATE wallet_reservations SET amount_minor=2100').run();}
  release();const result=await pending;assert.equal(result.status,409,change);assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review',change);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing',change);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1,change);assert.equal((await f.call('/api/wallet')).data.availableMinor,'0',change);
 }
});

test('terminal payout with altered fingerprint is not reported as verified',async t=>{
 const f=fixture(t);await f.createAndApprove({method:'POST',data:f.payload()});f.sql.prepare("UPDATE provider_payouts SET fingerprint='altered'").run();
 assert.equal((await f.callback()).status,409);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal((await f.call('/api/wallet')).data.availableMinor,'0');
});

test('historic paid payout without accepted outcome is not reported successful',async t=>{
 const f=fixture(t);await f.createAndApprove({method:'POST',data:f.payload()});f.sql.prepare("UPDATE provider_payouts SET create_outcome='unknown'").run();
 assert.equal((await f.callback()).status,409);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');
});

test('historic submitted failure requires review; only owner cancellation before submission reports failed',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});
 f.sql.prepare("UPDATE withdrawal_requests SET status='rejected'").run();f.sql.prepare("UPDATE provider_payouts SET status='failed',create_outcome='rejected',last_error_code='provider_failed'").run();f.sql.prepare('DELETE FROM wallet_reservations').run();
 assert.equal((await f.callback()).status,409);
 f.sql.prepare("UPDATE withdrawal_requests SET status='cancelled'").run();f.sql.prepare("UPDATE provider_payouts SET create_outcome='not_submitted',provider_reference=NULL,last_error_code='owner_cancel_test'").run();
 const row=f.sql.prepare('SELECT id,withdrawal_id FROM provider_payouts').get();
 const context={db:f.db,user:{id:'alice',username:'alice',role:'member',approved:1},apiBase,authKey,secretKey,returnUrl,payoutEnabled:'true',newPayoutsEnabled:'true',payoutIpWhitelistConfirmed:'true',payoutBankTargetsJson:JSON.stringify(bankTargets),withdrawalDataKey:dataKey,fetchImpl:f.config.gspayFetch};
 const result=await submitGSPayPayout({payoutId:row.id,withdrawalId:row.withdrawal_id,userId:'alice',accountHolder:'Alice Example',accountNumber:'123456789012',bankCode:'maybank',amountMinor:'2000'},context);assert.equal(result.status,'failed');
});

test('failure observed before a delayed success retains the payout for review',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});
 const fetch=f.config.gspayFetch;let release,started;const gate=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;});let delay=true;
 f.config.gspayFetch=async(...args)=>{const response=await fetch(...args);if(delay){delay=false;started();await gate;}return response;};
 f.state.completed=true;f.state.success=true;const pendingSuccess=f.callback();await ready;f.state.success=false;const failure=await f.callback();assert.equal(failure.status,409);release();const late=await pendingSuccess;assert.equal(late.status,409);
 assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await f.call('/api/wallet')).data.availableMinor,'0');
});

test('a delayed GSPAY failure cannot mark a payout using the former member guard after its owner changes',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});
 const fetch=f.config.gspayFetch;let release,started;const gate=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;});
 f.config.gspayFetch=async(...args)=>{const response=await fetch(...args);started();await gate;return response;};
 f.state.completed=true;f.state.success=false;const pending=f.callback();await ready;
 f.sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('bob','bob','member',1,'csrf-bob',0)").run();
 f.sql.prepare("UPDATE withdrawal_requests SET user_id='bob'").run();release();
 assert.equal((await pending).status,409);
 assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'processing');
 assert.equal(f.sql.prepare('SELECT user_id FROM wallet_reservations').get().user_id,'alice');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_payout_review'").get().n,0);
});

test('late failed status cannot undo a paid withdrawal and is recorded for review',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;await f.createAndApprove({method:'POST',data:f.payload()});
 const fetch=f.config.gspayFetch;let release,started;const gate=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;});let delay=true;
 f.config.gspayFetch=async(...args)=>{const response=await fetch(...args);if(delay){delay=false;started();await gate;}return response;};
 f.state.completed=true;f.state.success=false;const pendingFailure=f.callback();await ready;f.state.success=true;const success=await f.callback();assert.equal(success.status,200);release();const late=await pendingFailure;assert.equal(late.status,409);
 assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');assert.equal((await f.call('/api/wallet')).data.availableMinor,'0');assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='gspay_payout_review'").get().n,1);
});

test('ambiguous submission is never resent and protected recovery only queries its status',async t=>{
 const f=fixture(t);f.state.throwPost=true;const created=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(created.status,202);assert.equal(created.data.status,'processing');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,0);
 const replay=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(replay.status,200);assert.equal(f.state.postCalls,1);f.state.throwPost=false;f.state.completed=true;f.state.success=true;const token='recovery-token-'.padEnd(40,'r'),recovered=await f.call('/api/internal/payment-recovery',{who:null,method:'POST',headers:{authorization:'Bearer '+token},extra:{paymentRecoveryToken:token}});assert.equal(recovered.status,200);assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');
});

test('concurrent owner approval has one atomic provider caller',async t=>{
 const f=fixture(t),created=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(created.status,201);assert.equal(created.data.status,'pending');
 const list=await f.call('/api/admin/withdrawals',{who:'owner'}),reviewed=list.data.items.find(item=>item.id===created.data.withdrawal.id);assert.equal(reviewed.approvalEligible,true);
 const originalFetch=f.config.gspayFetch;let release;const gate=new Promise(resolve=>{release=resolve;});
 f.config.gspayFetch=async(input,init)=>{const response=await originalFetch(input,init);if(new URL(String(input)).pathname.endsWith('/payout'))await gate;return response;};
 const approval={id:reviewed.id,approvalFingerprint:reviewed.approvalFingerprint,ownerNote:'Concurrent approval fixture'},first=f.call('/api/admin/withdrawals/approve',{who:'owner',method:'POST',data:approval});
 while(f.state.postCalls<1)await new Promise(resolve=>setImmediate(resolve));
 const concurrent=await f.call('/api/admin/withdrawals/approve',{who:'owner',method:'POST',data:approval});assert.equal(concurrent.status,409);assert.equal(f.state.postCalls,1);
 release();const completed=await first;assert.equal(completed.status,202);assert.equal(completed.data.status,'paid');assert.equal(f.state.postCalls,1);assert.equal(f.state.queryCalls,1);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'succeeded');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
});

test('global payout maintenance prevents new submissions while a pending GSPAY payout can finish',async t=>{
 const f=fixture(t);f.state.completed=false;f.state.success=false;const created=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(created.status,202);assert.equal(f.state.postCalls,1);
 f.config.newPayoutsEnabled='false';const banks=await f.call('/api/withdrawal-banks');assert.equal(banks.data.providers.find(x=>x.id==='gspay').enabled,false);
 const blocked=await f.call('/api/withdrawals',{method:'POST',data:f.payload({requestKey:'synthetic-payout-request-0002'})});assert.equal(blocked.status,503);assert.equal(f.state.postCalls,1);
 f.state.completed=true;f.state.success=true;assert.equal((await f.callback()).status,200);assert.equal((await f.callback()).status,200);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});
