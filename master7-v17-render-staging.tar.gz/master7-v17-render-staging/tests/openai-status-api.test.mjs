import assert from 'node:assert/strict';
import test from 'node:test';
import {handle} from '../lib/backend.ts';

function contextFor(userId,extra={}){
 const users={
  owner:{id:'owner',username:'owner',role:'owner',approved:1,csrf:'owner-csrf',created_at:0},
  staff:{id:'staff',username:'staff',role:'staff',approved:1,csrf:'staff-csrf',created_at:0},
  member:{id:'member',username:'member',role:'member',approved:1,csrf:'member-csrf',created_at:0},
 };
 const db={prepare(sql){let args=[];return {bind(...values){args=values;return this;},async first(){
  if(sql.includes('FROM password_sessions'))return userId==='staff'?{...users.staff,login_id:'staff',session_csrf:'staff-csrf',credential_version:1}:null;
  return sql.includes('FROM users WHERE id=?')?users[args[0]]??null:null;
 }};}};
 return {db,identity:{userId,email:`${userId}@example.test`},ownerEmail:'owner@example.test',...extra};
}

test('owner and staff can read unified AI status without receiving secrets',async()=>{
 for(const role of ['owner','staff']){
  const request=new Request('https://portal.example.test/api/admin/ai-status',role==='staff'?{headers:{cookie:`__Host-master7_session=${'a'.repeat(43)}`}}:undefined);
  const response=await handle(request,contextFor(role,{supportAiEnabled:'true',supportAiApiBaseUrl:'https://api.example.test/v1',supportAiApiKey:'private-openai-key-that-is-long-enough-123',supportAiModel:'gpt-test-v1'}));
  assert.equal(response.status,200);
  const data=await response.json();
  assert.equal(data.provider,'openai');
  assert.equal(data.ready,true);
  assert.equal(data.readOnly,true);
  assert.equal(data.gamePaymentWalletAutomation,false);
  assert.equal(data.providerTransactionsRemainSeparate,true);
  assert.deepEqual(data.tasks,['support_reply','operations_summary','handover_summary','translation']);
  assert.doesNotMatch(JSON.stringify(data),/private-openai-key|password|secret|apiKey|token/i);
 }
});

test('member cannot read unified AI configuration and non-GET is rejected',async()=>{
 const denied=await handle(new Request('https://portal.example.test/api/admin/ai-status'),contextFor('member'));
 assert.equal(denied.status,403);
 const method=await handle(new Request('https://portal.example.test/api/admin/ai-status',{method:'POST'}),contextFor('owner'));
 assert.equal(method.status,405);
});
