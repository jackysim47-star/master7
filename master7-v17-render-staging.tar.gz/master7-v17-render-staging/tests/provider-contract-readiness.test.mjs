import assert from 'node:assert/strict';
import test from 'node:test';
import {
  GENERIC_PROVIDER_REQUIRED_CONTRACT_FIELDS,
  inspectProviderContractManifest,
} from '../lib/provider-contract-readiness.ts';

function setPath(target,path,value){
 const parts=path.split('.');let current=target;
 for(const part of parts.slice(0,-1))current=current[part]??={};
 current[parts.at(-1)]=value;
}

function completeManifest(profileId,providerId){
 const manifest={};
 for(const requirement of GENERIC_PROVIDER_REQUIRED_CONTRACT_FIELDS){
  let value=requirement.expected?.[0]??'documented-value';
  if(requirement.kind==='string_list')value=['documented-field'];
  if(requirement.kind==='nonnegative_integer')value=1;
  if(requirement.kind==='sha256')value='b'.repeat(64);
  if(requirement.kind==='ratio')value='1:1';
  if(requirement.field==='profile.profile_id')value=profileId;
  if(requirement.field==='profile.provider_id')value=providerId;
  if(requirement.field==='profile.provider_currency'||requirement.field==='profile.settlement_currency')value='MYR';
  setPath(manifest,requirement.field,value);
 }
 return manifest;
}

test('a contract-missing supplier exposes exact launch, wallet, settlement and recovery requirements',()=>{
 const diagnostic=inspectProviderContractManifest('pgsoft_myr','pgsoft');
 assert.equal(diagnostic.manifestComplete,false);
 assert.deepEqual(diagnostic.missingContractFields,GENERIC_PROVIDER_REQUIRED_CONTRACT_FIELDS.map(item=>item.field));
 for(const path of ['authentication.signature_algorithm','player.create.endpoint','launch.endpoint','wallet.mode','wallet.transaction_query.endpoint','reports.round_id_field','session.unfinished_rounds.endpoint','settlement.reversal_rule','recovery.timeout_rule'])assert.ok(diagnostic.missingContractFields.includes(path),path);
 for(const field of ['adapterImplemented','catalogueAllowed','launchAllowed','walletAllowed','settlementAllowed','recoveryAllowed','playAllowed'])assert.equal(diagnostic[field],false,field);
});

test('credentials or a brand image never satisfy a provider API contract and secrets are not reflected',()=>{
 const diagnostic=inspectProviderContractManifest('allbet_myr','allbet',{merchantId:'merchant',apiKey:'must-not-leak',password:'must-not-leak',artwork:'/asset.webp'});
 assert.equal(diagnostic.credentialsPresent,true);
 assert.equal(diagnostic.manifestComplete,false);
 assert.equal(JSON.stringify(diagnostic).includes('must-not-leak'),false);
 assert.equal(diagnostic.playAllowed,false);
});

test('complete documentation remains non-executable and is bound to exactly one provider profile',()=>{
 const manifest=completeManifest('pgsoft_myr','pgsoft');
 const complete=inspectProviderContractManifest('pgsoft_myr','pgsoft',manifest);
 assert.equal(complete.manifestComplete,true);
 assert.deepEqual(complete.missingContractFields,[]);
 assert.deepEqual(complete.invalidContractFields,[]);
 assert.equal(complete.documentationOnly,true);
 assert.equal(complete.adapterImplemented,false);
 assert.equal(complete.playAllowed,false);
 const wrongProfile=inspectProviderContractManifest('allbet_myr','allbet',manifest);
 assert.equal(wrongProfile.manifestComplete,false);
 assert.ok(wrongProfile.invalidContractFields.some(item=>item.field==='profile.profile_id'&&item.reason==='unexpected_value'));
 assert.ok(wrongProfile.invalidContractFields.some(item=>item.field==='profile.provider_id'&&item.reason==='unexpected_value'));
});

test('invalid profile and provider identifiers fail closed before manifest inspection',()=>{
 for(const [profileId,providerId] of [['','pgsoft'],['../pgsoft','pgsoft'],['pgsoft_myr',''],['pgsoft_myr','PG SOFT']]){
  const diagnostic=inspectProviderContractManifest(profileId,providerId,completeManifest('pgsoft_myr','pgsoft'));
  assert.equal(diagnostic.knownScope,false);
  assert.equal(diagnostic.manifestComplete,false);
  assert.equal(diagnostic.playAllowed,false);
 }
});
