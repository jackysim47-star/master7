import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';

test('forward wallet migration preserves old money rows and composite launch foreign keys',()=>{
 const db=new DatabaseSync(':memory:');try{
  const files=readdirSync(new URL('../drizzle',import.meta.url)).filter(n=>n.endsWith('.sql')).sort();for(const name of files.filter(n=>n<'0116_'))db.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
  db.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'fixture',0),('bob','bob','member',1,'fixture',0);INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,expected_return_minor,deposit_reference,withdraw_reference,last_error,created_at,updated_at,settled_at) VALUES('old-settled','alice','megah5','player-a','game-a','settled',100,125,125,'old-da','old-wa','',1,2,2),('old-active','bob','megah5','player-b','game-b','active',200,NULL,NULL,'old-db',NULL,'original-note',3,4,NULL);INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('old-result','old-settled','alice','game_result',25,'MYR',2);INSERT INTO megah5_launch_operations(id,wallet_session_id,user_id,game_code,state,created_at,updated_at,last_error) VALUES('old-launch','old-active','bob','game-b','unknown',3,4,'original-unknown');INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('bob','game','old-active',200,3)");
  const old=db.prepare('SELECT * FROM game_wallet_sessions ORDER BY id').all().map(row=>({...row})),ledger=db.prepare('SELECT * FROM game_wallet_ledger').all(),launch=db.prepare('SELECT * FROM megah5_launch_operations').all(),holds=db.prepare('SELECT * FROM wallet_reservations').all();
  db.exec(readFileSync(new URL('../drizzle/0116_provider_wallet_operations.sql',import.meta.url),'utf8'));
  const current=db.prepare('SELECT * FROM game_wallet_sessions ORDER BY id').all().map(row=>{assert.equal(row.profile_id,null);const {profile_id,...previous}=row;void profile_id;return previous;});assert.deepEqual(current,old);assert.deepEqual(db.prepare('SELECT * FROM game_wallet_ledger').all(),ledger);assert.deepEqual(db.prepare('SELECT * FROM megah5_launch_operations').all(),launch);assert.deepEqual(db.prepare('SELECT * FROM wallet_reservations').all(),holds);assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
  assert.throws(()=>db.exec("INSERT INTO megah5_launch_operations(id,wallet_session_id,user_id,game_code,state,created_at,updated_at,last_error) VALUES('invalid-link','old-settled','bob','game-a','issued',3,4,'')"),/FOREIGN KEY/i);
 }finally{db.close();}
});
