import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');

// Keep the behavioural fixtures beside each connector, but expose one stable
// acceptance entry point for Maintenance Test Group A. Every selected test
// uses a real migrated SQLite database and synthetic provider replies only.
test('Maintenance Group A: deposits close without interrupting existing callback or recovery work',()=>{
 const pattern='new-deposit maintenance defaults closed|closing new deposits leaves a preexisting|VPay recovery is default-off|GSPAY recovery is off by default|member query is owner-bound|member query can reconcile only their own order';
 const files=[
  'tests/payment-auto-availability.test.mjs',
  'tests/vpay-portal.test.mjs',
  'tests/gspay-portal.test.mjs',
  'tests/gspay-recovery.test.mjs',
  'tests/onempay.test.mjs',
 ];
 const childEnv={...process.env,NODE_NO_WARNINGS:'1'};
 delete childEnv.NODE_TEST_CONTEXT;
 const result=spawnSync(process.execPath,['--test','--test-reporter=spec',`--test-name-pattern=${pattern}`,...files],{
  cwd:root,
  encoding:'utf8',
  timeout:30_000,
  env:childEnv,
 });
 const diagnostic=[result.stdout,result.stderr].filter(Boolean).join('\n');
 assert.equal(result.error,undefined,diagnostic);
 assert.equal(result.status,0,diagnostic);
 for(const expected of [
  'new-deposit maintenance defaults closed and status matches enforcement for all four channels',
  'closing new deposits leaves a preexisting VPay callback and wallet credit recoverable once',
  'closing new deposits leaves a preexisting GSPAY callback and wallet credit recoverable once',
  'closing new deposits leaves a preexisting 1MPay callback and wallet credit recoverable once',
  'VPay recovery is default-off and independently credits exactly one balanced ledger when enabled',
  'GSPAY recovery is off by default and independently credits exactly one balanced ledger when enabled',
  'member query is owner-bound, uses exact GET parameters, and can reconcile after channel closure',
  'member query can reconcile only their own order and completes an outstanding closed channel',
 ])assert.match(diagnostic,new RegExp(expected.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
 assert.match(diagnostic,/tests 8/);
 assert.match(diagnostic,/pass 8/);
 assert.match(diagnostic,/fail 0/);
});
