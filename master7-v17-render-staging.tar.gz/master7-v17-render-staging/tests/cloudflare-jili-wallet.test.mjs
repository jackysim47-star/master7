import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

// Separate processes, auth sessions, disposable databases and evidence per profile.
// These are local compatibility regressions, never official supplier acceptance.
for (const profile of ['jili_myr_1to1', 'jili_my1_1to100']) {
  test(`${profile}: Cloudflare D1 supports the independent registered-member bank/game/recovery/withdrawal journey`, { timeout: 90_000 }, () => {
    const source = fileURLToPath(new URL('../', import.meta.url));
    const child = spawnSync(process.execPath, ['scripts/verify-cloudflare-manual-bank.mjs', '--game-profile', profile], {
      cwd: source, env: { ...process.env, MASTER7_VERIFICATION_SOURCE: source },
      encoding: 'utf8', timeout: 85_000, maxBuffer: 2 * 1024 * 1024,
    });
    assert.ifError(child.error);
    assert.equal(child.status, 0, child.stderr + child.stdout);
    const evidence = JSON.parse(child.stdout);
    assert.equal(evidence.result, 'passed');
    assert.equal(evidence.gameProfile, profile);
    assert.equal(evidence.runtime, 'Cloudflare workerd + disposable D1');
    assert.equal(evidence.supplierCallsAreSynthetic, true);
    assert.deepEqual(evidence.syntheticAmountMinor, {
      bankIn: '5000', bankOut: '2000', endingBalance: '3375',
      gameOut: '5000', gameReturned: '5375', gameNet: '375',
    });
    assert.ok(evidence.checks.includes(profile + ': concurrent recovery preserves one sweep and one result posting'));
    assert.equal(evidence.auditEvents.find(x => x.event === 'manual_bank_payout_paid').n, 1);
    assert.ok(evidence.limitations.includes('synthetic JILI transport and closure evidence only; no bet or official finality verification'));
    assert.ok(evidence.limitations.includes('not UAT acceptance'));
  });
}
