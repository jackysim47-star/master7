import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const appSource=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const backendSource=readFileSync(new URL('../lib/backend.ts',import.meta.url),'utf8');
const renderSchemaSource=readFileSync(new URL('../db/render-schema.sql',import.meta.url),'utf8');

test('marketing contact import decodes split UTF-8 and uploads bounded batches without file.text()',async()=>{
 const chunkBytes=1024*1024,first=Buffer.alloc(chunkBytes,0x20);for(let index=1023;index<first.length;index+=1024)first[index]=0x0a;
 const phone=Buffer.from('+60123456789,');const chinese=Buffer.from('陈');const start=chunkBytes-1-phone.length;first[start-1]=0x0a;phone.copy(first,start);first[chunkBytes-1]=chinese[0];
 const bytes=Buffer.concat([first,chinese.subarray(1),Buffer.from('\r\n+60198765432,Ali\r\n+60198765432,Duplicate\r\n')]),blob=new Blob([bytes]),file={name:'contacts.csv',size:blob.size,slice:(start,end)=>blob.slice(start,end)};
 const controls={marketingContactFile:{files:[file]},marketingImportButton:{disabled:false},marketingImportStatus:{textContent:''},marketingImportProgress:{hidden:true,value:0},marketingConsent:{checked:true},marketingConsentSource:{value:'signed registration form'},marketingConsentProof:{value:'archive batch 2026-11-06'}},requests=[],stored=new Map();
 const context={TextDecoder,Map,Number,Math,Error,Promise,setTimeout:callback=>{callback();return 1;},state:{user:{id:'owner'}},localStorage:{getItem:key=>stored.get(key)??null,setItem:(key,value)=>stored.set(key,value),removeItem:key=>stored.delete(key)},$:id=>controls[id],api:async(url,method,payload)=>{requests.push({url,method,payload:JSON.parse(JSON.stringify(payload))});return {imported:payload.contacts.length,invalid:0,duplicates:0};},loadMarketingCenter:async()=>{},console};
 const startIndex=appSource.indexOf('function marketingCells('),endIndex=appSource.indexOf('function updateMarketingDuration()',startIndex);assert.ok(startIndex>=0&&endIndex>startIndex);vm.runInNewContext(`${appSource.slice(startIndex,endIndex)}\nthis.runImport=importMarketingContacts;`,context);
 await context.runImport({preventDefault(){}});
 assert.equal(requests.length,1);assert.equal(requests[0].url,'/api/admin/marketing');assert.equal(requests[0].payload.contacts.length,2);assert.deepEqual(requests[0].payload.contacts.map(item=>[item.phone,item.name,item.consent,item.consentSource,item.consentProof]),[['+60123456789','陈','opted_in','signed registration form','archive batch 2026-11-06'],['+60198765432','Ali','opted_in','signed registration form','archive batch 2026-11-06']]);assert.match(controls.marketingImportStatus.textContent,/新增 2/);assert.match(controls.marketingImportStatus.textContent,/重复 1/);assert.equal(controls.marketingImportProgress.value,100);assert.equal(controls.marketingImportButton.disabled,false);assert.equal(stored.size,0);
 const manyBlob=new Blob([Array.from({length:1001},(_,index)=>`+6011${String(index).padStart(7,'0')},Contact ${index}`).join('\n')]);controls.marketingContactFile.files=[{name:'many.csv',size:manyBlob.size,slice:(start,end)=>manyBlob.slice(start,end)}];requests.length=0;await context.runImport({preventDefault(){}});assert.deepEqual(requests.map(item=>item.payload.contacts.length),[1000,1]);
 const quotedBlob=new Blob(['+60128887777,"Family, Trading; Sdn. Bhd."\n+60129998888;"Ali; Bin, Abu"']);controls.marketingContactFile.files=[{name:'quoted.csv',size:quotedBlob.size,slice:(start,end)=>quotedBlob.slice(start,end)}];requests.length=0;await context.runImport({preventDefault(){}});assert.deepEqual(requests[0].payload.contacts.map(item=>[item.phone,item.name]),[['+60128887777','Family, Trading; Sdn. Bhd.'],['+60129998888','Ali; Bin, Abu']]);
 controls.marketingConsentSource.value='';requests.length=0;await context.runImport({preventDefault(){}});assert.equal(requests.length,0);assert.match(controls.marketingImportStatus.textContent,/必须填写同意来源和证明/);controls.marketingConsentSource.value='signed registration form';
 assert.doesNotMatch(appSource,/marketingRows\(await file\.text\(\)/);assert.match(appSource,/file\.slice\(offset,end\)\.arrayBuffer\(\)/);assert.match(appSource,/batchSize=1000/);assert.match(appSource,/error\.status!==429/);assert.match(appSource,/m7-marketing-import:/);assert.match(appSource,/saveCheckpoint/);assert.match(appSource,/5000\*2\*\*attempt/);
});

test('marketing CSV export is paged and streamed with a stable created_at and id cursor',()=>{
 assert.match(backendSource,/new ReadableStream<Uint8Array>/);assert.match(backendSource,/created_at>\? OR \(created_at=\? AND id>\?\)/);assert.match(backendSource,/ORDER BY created_at,id LIMIT 2000/);assert.doesNotMatch(backendSource,/SELECT phone,name FROM marketing_contacts[^\n]+LIMIT 1000000/);assert.doesNotMatch(backendSource,/contacts\.map\(\(x:any\)/);assert.match(renderSchemaSource,/marketing_contacts_export/);assert.match(backendSource,/Marketing contacts are limited to 1,000,000/);assert.doesNotMatch(backendSource,/const before=await db\.prepare\('SELECT COUNT\(\*\) count FROM marketing_contacts'/);
});
