import test from 'node:test';
import assert from 'node:assert/strict';
import {builtInSupportReply,generateSupportReply,SUPPORT_ASSISTANT_NAME,supportAiProviderStatus} from '../lib/support-ai.ts';

const configured={enabled:'true',apiBaseUrl:'https://ai.example.test/v1',apiKey:'test-key-that-is-long-enough-123456',model:'support-model-v1'};

test('Stephanie fallback identifies itself as AI and escalates financial and security work',()=>{
 const deposit=builtInSupportReply('充值没有到','付款后还没收到');
 assert.equal(deposit.category,'deposit');
 assert.equal(deposit.requiresHumanHandoff,true);
 assert.equal(deposit.engine,'built_in_rules_v2');
 assert.match(deposit.message,new RegExp(SUPPORT_ASSISTANT_NAME));
 assert.match(deposit.message,/AI 客服/);
 assert.match(deposit.message,/密码或 OTP/);
 const malay=builtInSupportReply('Bantuan permainan','Saya tidak boleh masuk permainan');
 assert.equal(malay.category,'game');
 assert.match(malay.message,/Kami telah menerima/);
});

test('money, complaints and account security never leave the portal for external generation',async()=>{
 let calls=0;
 for(const [subject,message] of [['Deposit','My payment is pending'],['Security','OTP login problem'],['Complaint','This looks like fraud']]){
  const reply=await generateSupportReply({...configured,fetchImpl:async()=>{calls++;return Response.json({choices:[{message:{content:'must not be used'}}]});}},subject,message);
  assert.equal(reply.engine,'built_in_rules_v2');
  assert.equal(reply.requiresHumanHandoff,true);
 }
 assert.equal(calls,0);
});

test('safe general questions can use a bounded OpenAI-compatible provider without exposing secrets',async()=>{
 let request;
 const reply=await generateSupportReply({...configured,fetchImpl:async(url,init)=>{request={url:String(url),init,body:JSON.parse(String(init.body))};return Response.json({choices:[{message:{content:'Please share the page name and the message shown. A staff member can follow up if records are needed.'}}]});}},'General help','Where can I find the menu? Reference 123456789012');
 assert.equal(reply.engine,'openai_compatible');
 assert.equal(reply.requiresHumanHandoff,false);
 assert.equal(request.url,'https://ai.example.test/v1/chat/completions');
 assert.equal(request.init.redirect,'error');
 assert.equal(request.init.headers.authorization,`Bearer ${configured.apiKey}`);
 const sent=request.body.messages.at(-1).content;
 assert.doesNotMatch(sent,/123456789012/);
 assert.match(sent,/\[REDACTED_NUMBER\]/);
 assert.match(reply.message,/Stephanie · MASTER7 AI 客服/);
});

test('invalid provider configuration and provider failures use the safe rules fallback',async()=>{
 assert.equal(supportAiProviderStatus({...configured,apiBaseUrl:'http://127.0.0.1:8080/v1'}).externalProviderConfigured,false);
 assert.equal(supportAiProviderStatus(configured).externalProviderReady,true);
 const reply=await generateSupportReply({...configured,fetchImpl:async()=>new Response('bad gateway',{status:502})},'General question','Please help with the menu');
 assert.equal(reply.engine,'built_in_rules_v2');
 assert.equal(reply.providerAttempted,true);
 assert.match(reply.message,/Stephanie/);
});
