import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/assets/member-shell.css',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');

function once(value,label){assert.equal((html.match(new RegExp(`id="${value}"`,'g'))||[]).length,1,`${label} must remain unique`);}

test('member wallet is the first authenticated lobby feature and preserves money DOM contracts',()=>{
 const lobby=html.indexOf('<section id="lobby"');
 const wallet=html.indexOf('id="memberWallet"');
 const hero=html.indexOf('lobby-overview');
 const providers=html.indexOf('id="apiSupplierLobby"');
 assert.ok(lobby>=0&&wallet>lobby&&hero>wallet&&providers>hero);
 for(const [id,label] of [['memberWallet','wallet'],['walletBalance','balance'],['refreshWallet','wallet refresh'],['walletDepositAction','deposit'],['walletWithdrawAction','withdraw'],['walletRecordsAction','records'],['refreshPaymentRecords','records refresh'],['memberPaymentRecords','records list'],['paymentLobby','cashier'],['paymentButtons','payment choices']])once(id,label);
 assert.match(html,/wallet-primary-actions wallet-quick-grid[\s\S]*walletDepositAction[\s\S]*walletWithdrawAction[\s\S]*walletRecordsAction[\s\S]*data-section="rewards"/);
 assert.match(css,/\.wallet-quick-grid\{grid-template-columns:repeat\(4/);
 assert.match(css,/@media\(max-width:760px\)[\s\S]*\.wallet-quick-grid\{grid-template-columns:repeat\(2/);
});

test('member lobby presents an English MASTER7 company profile without changing flow contracts',()=>{
 const lobby=html.indexOf('<section id="lobby"');
 const wallet=html.indexOf('id="memberWallet"',lobby);
 const profile=html.indexOf('class="company-profile-hero"',lobby);
 const hero=html.indexOf('lobby-overview',lobby);
 assert.ok(lobby>=0&&wallet>lobby&&profile>wallet&&hero>profile);
 once('companyProfileTitle','company profile title');
 assert.match(html,/MASTER7 · One Connected Experience/);
 assert.match(html,/Play with confidence\. One premium experience\./);
 assert.match(html,/SECURE SIGN-IN[\s\S]*CLEAR WALLET[\s\S]*TRACEABLE RECORDS[\s\S]*DEDICATED SUPPORT/);
 assert.match(html,/\/assets\/master7-company-hero\.png/);
 assert.match(css,/\.company-profile-hero\{[\s\S]*grid-template-columns/);
 assert.match(css,/@media\(max-width:760px\)[\s\S]*\.company-profile-hero\{grid-template-columns:minmax\(0,1fr\)/);
 assert.doesNotMatch(html.slice(profile,hero),/guaranteed win|licensed|certified|all providers live/i);
});

test('mobile shell has five focused destinations without the overflowing top navigation',()=>{
 const dock=html.match(/<nav class="mobile-dock"[\s\S]*?<\/nav>/)?.[0]||'';
 assert.equal((dock.match(/mobile-dock-button/g)||[]).length,5);
 for(const label of ['Home','Games','Wallet','Promotions','Support'])assert.match(dock,new RegExp(`>${label}<`));
 assert.match(dock,/data-section="rewards"[\s\S]*Promotions/);
 assert.match(dock,/data-section="support"[\s\S]*🎧[\s\S]*Support/);
 assert.doesNotMatch(dock,/mobileAccountButton|>Account</);
 assert.match(css,/@media\(max-width:760px\)[\s\S]*\.topbar \.topnav\{display:none!important\}/);
 assert.match(css,/\.mobile-dock\{[\s\S]*grid-template-columns:repeat\(5/);
 assert.match(css,/#logoutButton\{[\s\S]*width:40px/);
});

test('provider presentation is aligned and preserves truthful integration state',()=>{
 assert.match(css,/\.api-supplier-art\{[\s\S]*aspect-ratio:4\/3[\s\S]*object-fit:cover!important/);
 assert.match(css,/@media\(max-width:760px\)[\s\S]*\.api-supplier-grid\{grid-template-columns:repeat\(2/);
 assert.match(app,/"\/assets\/master7-luxury-lobby\.webp"/);
 const publicRender=app.slice(app.indexOf('function renderApiSupplierButtons'),app.indexOf('function renderApiSupplierAdminButtons'));
 assert.match(publicRender,/profileCapabilityText/);
 const catalog=app.slice(app.indexOf('function renderCatalog()'),app.indexOf('function renderAdGrid'));
 assert.match(catalog,/Play coming soon/);
 assert.doesNotMatch(catalog,/API PENDING|API CONNECTED/);
});

test('lobby prioritizes wallet and sponsored providers before the full directory',()=>{
 const lobby=html.indexOf('<section id="lobby"');
 const hero=html.indexOf('lobby-overview',lobby);
 const secondary=html.indexOf('lobby-secondary-content',lobby);
 const providers=html.indexOf('id="apiSupplierLobby"',lobby);
 assert.ok(lobby>=0&&hero>lobby&&secondary>hero&&providers>secondary);
 const summary=html.match(/<div class="lobby-live-summary"[\s\S]*?<\/div>/)?.[0]||'';
 assert.doesNotMatch(summary,/24\/7|PLAYABLE/);
 assert.match(summary,/FEATURED/);
 assert.doesNotMatch(summary,/CONNECTED/);
 assert.match(html,/id="bonusBrandLobby"[\s\S]*JILI[\s\S]*MEGA H5[\s\S]*918KISS/);
 assert.doesNotMatch(html.slice(lobby,html.indexOf('<section id="deposit"')),/android-download-panel|Android APK|iPhone 安装/);
 assert.doesNotMatch(html,/downloads\/MASTER7-Android|ANDROID APK/,'retired APK is not promoted to members');
 assert.match(html,/auth-quick-actions auth-quick-actions-single[\s\S]*auth-company-details/);
});
