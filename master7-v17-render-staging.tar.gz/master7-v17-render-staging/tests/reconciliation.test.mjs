import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,readFileSync,rmSync,readdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
import {reconcileStatements} from '../lib/reconciliation.ts';

const record=(patch={})=>({id:'row',domain:'payment',provider:'vpay',account:'merchant',reference:'order',transactionId:'transaction-'+(patch.reference??'order'),memberId:'fixture-member',amountMinor:'5000',currency:'MYR',status:'succeeded',direction:'credit',balanceClass:'cash',occurredAt:'2026-11-15T01:00:00Z',evidenceReference:'fixture:row',...patch,...(patch.ledger?{ledger:{memberEntries:1,clearingEntries:1,memberId:'fixture-member',...patch.ledger}}:{})});
function input(a=[record({id:'internal',ledger:{memberMinor:'5000',clearingMinor:'-5000'}})],b=[record({id:'external'})]){
 return {schemaVersion:'master7-reconciliation-v1',mappingVersion:'canonical-fixture-v1',ruleVersion:'v1',sourceCommit:'753ca2f4282f9270140fdac41a0fdbe128844c64',internalSnapshotId:'isolated-fixture',period:{startUtc:'2026-11-15T00:00:00Z',endUtcExclusive:'2026-11-16T00:00:00Z'},internalRecords:a,externalRecords:b,coverage:[{domain:'payment',provider:'vpay',account:'merchant',balanceClass:'cash',complete:true,evidenceReference:'fixture:complete'}]};
}
function freeze(x){if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;}
const classification=x=>reconcileStatements(x).discrepancies.map(d=>d.classification);

test('canonical payment comparison verifies both ledger legs and never mutates input or approves funds',()=>{
 const source=freeze(input()),before=JSON.stringify(source),report=reconcileStatements(source);
 assert.equal(report.result,'matched_inputs');assert.equal(report.counts.matched,1);assert.equal(report.ownerReview,'pending');assert.deepEqual(report.financialActions,[]);assert.equal(JSON.stringify(source),before);
 assert.deepEqual(classification(input([record({ledger:{memberMinor:'5000',clearingMinor:'-4999'}})])),['ledger_mismatch']);
 assert.deepEqual(classification(input([record()])),['unverifiable']);
});
test('equal totals cannot conceal per-order mismatches or duplicate match keys',()=>{
 const a=[record({id:'a',reference:'one',amountMinor:'3000',ledger:{memberMinor:'3000',clearingMinor:'-3000'}}),record({id:'b',reference:'two',amountMinor:'7000',ledger:{memberMinor:'7000',clearingMinor:'-7000'}})];
 const b=[record({id:'x',reference:'one',amountMinor:'7000'}),record({id:'y',reference:'two',amountMinor:'3000'})];
 assert.deepEqual(classification(input(a,b)),['amount_mismatch','amount_mismatch']);
 assert.deepEqual(classification(input(a,[b[0],{...b[0],id:'z'}])),['duplicate','missing_external']);
});
test('balanced ledger aggregates cannot hide duplicated legs, a foreign member or missing provider transaction identity',()=>{
 for(const patch of [{memberEntries:2},{clearingEntries:2},{memberId:'foreign'}]){
  const x=input([record({ledger:{memberMinor:'5000',clearingMinor:'-5000',...patch}})]);
  assert.ok(classification(x).includes('ledger_mismatch'));
 }
 const missing=input();delete missing.externalRecords[0].transactionId;assert.ok(classification(missing).includes('unverifiable'));
 const pending=input();pending.internalRecords[0].status='pending';pending.externalRecords[0].status='pending';assert.ok(classification(pending).includes('ledger_mismatch'));
});
test('currency, status, transaction and member mismatches stay separate from matching amounts',()=>{
 for(const [patch,kind] of [[{currency:'USD'},'currency_mismatch'],[{status:'failed'},'status_mismatch'],[{memberId:'other'},'binding_mismatch']]){
  assert.ok(classification(input(undefined,[record(patch)])).includes(kind));
 }
 assert.ok(classification(input([record({transactionId:'one',ledger:{memberMinor:'5000',clearingMinor:'-5000'}})],[record({transactionId:'two'})])).includes('binding_mismatch'));
});
test('missing coverage and absent counterpart never count as a complete reconciliation',()=>{
 const x=input();x.coverage=[];assert.equal(reconcileStatements(x).result,'incomplete');
 assert.deepEqual(classification(input([],[])),[]);
 const empty=input([],[]);empty.coverage=[];assert.notEqual(reconcileStatements(empty).result,'matched_inputs');
 assert.ok(classification(input(undefined,[])).includes('missing_external'));
 const dated=input();dated.externalRecords[0].occurredAt='2026-11-16T00:00:00Z';assert.ok(classification(dated).includes('outstanding'));
});
test('bank matching binds account, direction and currency, never just equal amount',()=>{
 const bank=record({domain:'bank',provider:'bank',account:'company-account',reference:'BANKREF',direction:'debit',transactionId:'bank-001'});
 const x=input([{...bank,id:'proof'}],[{...bank,id:'statement'}]);x.coverage=[{domain:'bank',provider:'bank',account:'company-account',balanceClass:'cash',complete:true,evidenceReference:'fixture:bank-full'}];
 assert.equal(reconcileStatements(x).counts.matched,1);
 x.externalRecords[0].direction='credit';assert.ok(classification(x).includes('binding_mismatch'));
 x.externalRecords[0].account='other-account';assert.equal(reconcileStatements(x).counts.matched,0);
});
test('reports hide account values and reject credential-bearing evidence links',()=>{
 const x=input();x.internalRecords[0].account='1234567890123456';x.externalRecords[0].account='1234567890123456';x.coverage[0].account='1234567890123456';
 const report=reconcileStatements(x);assert.equal(report.counts.matched,1);assert.equal(JSON.stringify(report).includes('1234567890123456'),false);
 x.externalRecords[0].evidenceReference='https://provider.test/report?token=do-not-include';
 assert.throws(()=>reconcileStatements(x),/RECONCILIATION_INPUT_INVALID/);
});
test('game results require exact profile, player, unit ratio and final net-result evidence',()=>{
 const game=record({domain:'game_provider',provider:'jili',account:'merchant',profileId:'jili_myr_1to1',playerId:'player',reference:'session-result',transactionId:'transfer',direction:'result',amountMinor:'-1000',unitNumerator:'1',unitDenominator:'1',result:{outMinor:'5000',returnedMinor:'4000',closureEvidenceReference:'fixture:closure'}});
 const x=input([structuredClone({...game,id:'session'})],[structuredClone({...game,id:'supplier'})]);x.coverage=[{domain:'game_provider',provider:'jili',account:'merchant',profileId:game.profileId,balanceClass:'cash',complete:true,evidenceReference:'fixture:game-full'}];
 assert.equal(reconcileStatements(x).counts.matched,1);
 x.externalRecords[0].result.returnedMinor='5000';assert.ok(classification(x).includes('ledger_mismatch'));
 x.externalRecords[0]={...game,id:'supplier',playerId:'foreign'};assert.ok(classification(x).includes('binding_mismatch'));
 x.externalRecords[0]={...game,id:'supplier',unitNumerator:'100'};assert.ok(classification(x).includes('binding_mismatch'));
 x.externalRecords[0]={...game,id:'supplier',result:{outMinor:'6000',returnedMinor:'5000',closureEvidenceReference:'fixture:closure'}};assert.ok(classification(x).includes('binding_mismatch'));
 x.externalRecords[0]={...game,id:'supplier',balanceClass:'free_credit'};assert.equal(reconcileStatements(x).counts.matched,0);
});
test('duplicate external transaction IDs across different references cannot be matched twice',()=>{
 const a=[record({id:'a',reference:'a',transactionId:'dup',ledger:{memberMinor:'5000',clearingMinor:'-5000'}}),record({id:'b',reference:'b',transactionId:'dup',ledger:{memberMinor:'5000',clearingMinor:'-5000'}})];
 const b=a.map(r=>{const copy={...r,id:'external-'+r.id};delete copy.ledger;return copy;});
 const report=reconcileStatements(input(a,b));assert.equal(report.counts.matched,0);assert.ok(report.discrepancies.some(d=>d.classification==='duplicate'));
});
test('invalid input fails closed on precision, dates, scope, units and coverage',()=>{
 for(const patch of [{amountMinor:'50.001'},{amountMinor:'01'},{amountMinor:'5000\n'},{amountMinor:'5000\u2028'},{currency:'MYR\n'},{currency:'MYR\u2028'},{amountMinor:'-1'},{amountMinor:'9223372036854775808'},{occurredAt:'2026-11-15'},{occurredAt:'2026-02-30T01:00:00Z'},{balanceClass:'free_credit'}]){
  assert.throws(()=>reconcileStatements(input(undefined,[record(patch)])),/RECONCILIATION_INPUT_INVALID/);
 }
 const dup=input();dup.coverage.push({...dup.coverage[0]});assert.throws(()=>reconcileStatements(dup),/duplicate coverage/);
 const extra=input();extra.approved=true;assert.throws(()=>reconcileStatements(extra),/RECONCILIATION_INPUT_INVALID/);
});
test('repeated and permuted inputs retain a deterministic run identity and business output',()=>{
 const x=input(),a=reconcileStatements(x),b=reconcileStatements(structuredClone(x));assert.deepEqual(a,b);
 x.internalRecords.push({...x.internalRecords[0],id:'second',reference:'second'});x.externalRecords.push({...x.externalRecords[0],id:'second-external',reference:'second'});
 const c=reconcileStatements(x);x.internalRecords.reverse();x.externalRecords.reverse();assert.deepEqual(reconcileStatements(x),c);
});
test('CLI writes immutable discrepancy artifacts and refuses to replace an existing run',t=>{
 const dir=mkdtempSync(join(tmpdir(),'master7-reconciliation-'));t.after(()=>rmSync(dir,{recursive:true,force:true}));
 const source=join(dir,'input.json'),output=join(dir,'report'),snapshot=JSON.stringify(input());writeFileSync(source,snapshot);
 const command=()=>spawnSync(process.execPath,[resolve('scripts/reconcile-statements.mjs'),'--input',source,'--output',output],{encoding:'utf8'});
 const made=command();assert.equal(made.status,0,made.stderr);assert.equal(readFileSync(source,'utf8'),snapshot);
 assert.deepEqual(readdirSync(output).sort(),['SHA256SUMS.txt','discrepancies.csv','input_manifest.json','owner_review.json','reconciliation_report.json']);
 assert.equal(JSON.parse(readFileSync(join(output,'owner_review.json'),'utf8')).verifiedBy,null);
 const report=readFileSync(join(output,'reconciliation_report.json'),'utf8');assert.equal(command().status,1);assert.equal(readFileSync(join(output,'reconciliation_report.json'),'utf8'),report);
});
