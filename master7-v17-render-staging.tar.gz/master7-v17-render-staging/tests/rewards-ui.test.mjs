import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

test('Rewards Hub has independent member and owner surfaces with explicit non-cash controls',async()=>{
 const [html,script,css]=await Promise.all([readFile(new URL('../app/portal.html',import.meta.url),'utf8'),readFile(new URL('../public/assets/rewards.js',import.meta.url),'utf8'),readFile(new URL('../public/assets/rewards.css',import.meta.url),'utf8')]);
 for(const id of ['id="rewards"','id="rewardsManager"','id="rewardsCheckIn"','id="rewardsLedger"'])assert.match(html,new RegExp(id));
 assert.match(html,/无现金价值/);assert.match(html,/积分使用独立账本，不能提款或转入真钱钱包/);assert.match(html,/claim 与 redemption 均固定关闭/);
 assert.match(script,/\/api\/rewards\/check-in/);assert.match(script,/\/api\/admin\/rewards/);assert.match(script,/hidePreviewSections/);assert.doesNotMatch(script,/renderMissions|renderReferrals|renderCoupons|addMilestoneRow|addCouponRow/);assert.doesNotMatch(script,/wallet[^\n]*(credit|deposit)[^\n]*(POST|api\()/i);
 assert.match(css,/\.rewards-hero/);assert.match(css,/@media\(max-width:760px\)/);
});
