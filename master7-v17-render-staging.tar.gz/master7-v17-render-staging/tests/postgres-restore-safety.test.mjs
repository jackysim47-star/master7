import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {assertIsolatedRestoreTarget} from '../lib/restore-safety.mjs';

test('PostgreSQL restore rehearsal only accepts an explicitly isolated database',()=>{
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://user:pass@db.example/master7'),/isolated/);
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://user:pass@db.example/master7_staging'),/isolated/);
 assert.throws(()=>assertIsolatedRestoreTarget('mysql://user:pass@db.example/master7_restore'),/PostgreSQL/);
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://user:pass@db.example/master7_restore',['postgres://user:pass@db.example/master7_restore']),/application database/);
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://restore_user:new@db.example/master7_restore?sslmode=require',['postgres://app:old@db.example/master7_restore']),/application database/);
 assert.deepEqual(assertIsolatedRestoreTarget('postgres://user:pass@db.example:5433/master7_restore_2026'),{database:'master7_restore_2026',host:'db.example',port:'5433'});
});

test('restore rehearsal always rolls back and never contains a commit statement',()=>{
 const source=readFileSync(new URL('../scripts/postgres-restore-dry-run.mjs',import.meta.url),'utf8');
 assert.match(source,/client\.query\('ROLLBACK'\)/);
 assert.doesNotMatch(source,/client\.query\(['"]COMMIT/);
 assert.match(source,/persistentWrites:false/);
 assert.match(source,/--confirm-isolated/);
});
