import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {assertIsolatedRestoreTarget} from '../lib/restore-safety.mjs';
import {ACCEPTANCE_PROTECTED_TABLES,BACKUP_EXCLUDED_TABLES,BACKUP_TABLES} from '../lib/encrypted-backup.ts';
import {initializeRehearsalSchema,withRollbackOnlyTransaction} from '../scripts/restore-postgres-schema.mjs';
import {criticalDatabaseGuardRows} from './critical-database-guard-fixture.mjs';

test('PostgreSQL restore rehearsal only accepts an explicitly isolated database',()=>{
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://user:pass@db.example/master7'),/isolated/);
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://user:pass@db.example/master7_staging'),/isolated/);
 assert.throws(()=>assertIsolatedRestoreTarget('mysql://user:pass@db.example/master7_restore'),/PostgreSQL/);
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://user:pass@db.example/master7_restore',['postgres://user:pass@db.example/master7_restore']),/application database/);
 assert.throws(()=>assertIsolatedRestoreTarget('postgres://restore_user:new@db.example/master7_restore?sslmode=require',['postgres://app:old@db.example/master7_restore']),/application database/);
 assert.deepEqual(assertIsolatedRestoreTarget('postgres://user:pass@db.example:5433/master7_restore_2026'),{database:'master7_restore_2026',host:'db.example',port:'5433'});
});

test('restore rehearsal always rolls back and never contains a commit statement',()=>{
 const source=readFileSync(new URL('../scripts/postgres-restore-dry-run.mjs',import.meta.url),'utf8');
 assert.match(source,/const receipt=await withRollbackOnlyTransaction\(client/);
 assert.doesNotMatch(source,/client\.query\(['"]COMMIT/);
 assert.match(source,/persistentWrites:false/);
 assert.match(source,/--confirm-isolated/);
});

test('PostgreSQL restore keeps acceptance triggers active and clears only a fresh empty protected ledger',()=>{
 const source=readFileSync(new URL('../scripts/postgres-restore-dry-run.mjs',import.meta.url),'utf8');
 assert.equal(ACCEPTANCE_PROTECTED_TABLES.length,4);
 assert.match(source,/for\(const table of ACCEPTANCE_PROTECTED_TABLES\).*COUNT\(\*\)::bigint count FROM \"\$\{table\}\"/);
 assert.match(source,/name!==['"]users['"]&&!ACCEPTANCE_PROTECTED_TABLES\.includes\(name\)/);
 assert.match(source,/TRUNCATE \$\{quoted\} CASCADE/);
 assert.match(source,/DELETE FROM users/);
 assert.doesNotMatch(source,/DISABLE TRIGGER|session_replication_role/i);
 assert.match(source,/orderBackupRestoreRows\(table,payload\.tables\[table\]\)/);
});

test('PostgreSQL outer transaction always rolls back and closes on success or restore failure',async()=>{
 for(const fail of [false,true]){
  const events=[],client={connect:async()=>events.push('connect'),query:async sql=>events.push(sql),end:async()=>events.push('end')};
  const restore=()=>withRollbackOnlyTransaction(client,async()=>{events.push('restore');if(fail)throw new Error('synthetic restore failure');return {verified:true};});
  if(fail)await assert.rejects(restore,/synthetic restore failure/);
  else assert.deepEqual(await restore(),{verified:true});
  assert.deepEqual(events,['connect','BEGIN','restore','ROLLBACK','end']);
 }
});

test('PostgreSQL rollback failure prevents a successful receipt and still closes the connection',async()=>{
 const events=[],client={connect:async()=>events.push('connect'),query:async sql=>{events.push(sql);if(sql==='ROLLBACK')throw new Error('synthetic rollback failure');},end:async()=>events.push('end')};
 await assert.rejects(()=>withRollbackOnlyTransaction(client,async()=>({verified:true})),/synthetic rollback failure/);
 assert.deepEqual(events,['connect','BEGIN','ROLLBACK','end']);
});

class RehearsalClient {
 constructor(failOn){this.events=[];this.failOn=failOn;this.applied=new Set();this.released=false;}
 async query(sql,params=[]){
  this.events.push({sql,params});
  assert.doesNotMatch(sql,/^\s*(?:BEGIN|COMMIT|END|ABORT)\b/i,'The schema initializer must never control the outer transaction');
  if(this.failOn?.test(sql))throw new Error('synthetic migration failure');
  if(sql.startsWith('SELECT version FROM portal_schema_migrations'))return {rows:this.applied.has(params[0])?[{version:params[0]}]:[]};
  if(sql.includes('FROM pg_catalog.pg_trigger'))return {rows:criticalDatabaseGuardRows('restore_fixture')};
  if(sql.startsWith('INSERT INTO portal_schema_migrations'))this.applied.add(params[0]);
  return {rows:[]};
 }
 release(){this.released=true;}
}

test('PostgreSQL rehearsal bootstraps the complete runtime schema inside one savepoint',async()=>{
 const client=new RehearsalClient(),schema=readFileSync(new URL('../db/render-schema.sql',import.meta.url),'utf8');
 await initializeRehearsalSchema(client,schema,[],'restore_fixture');
 const sql=client.events.map(event=>event.sql).join('\n');
 const tables=[...new Set([...sql.matchAll(/CREATE TABLE IF NOT EXISTS ([a-z][a-z0-9_]*)\b/g)].map(match=>match[1]))].sort();
 assert.ok(tables.includes('megah5_launch_operations'),'numeric characters are part of the complete SQL table name');
 assert.deepEqual(tables,[...BACKUP_TABLES,...BACKUP_EXCLUDED_TABLES].sort(),'Every release table must be created and classified');
 for(const column of ['review_status','reviewed_by','reviewed_at','review_note'])assert.match(sql,new RegExp(`ALTER TABLE benefit_claims ADD COLUMN IF NOT EXISTS ${column}\\b`));
 assert.match(sql,/ALTER TABLE marketing_campaigns ADD COLUMN IF NOT EXISTS template_params_json/);
 assert.match(sql,/ALTER TABLE marketing_deliveries ADD COLUMN IF NOT EXISTS delivered_at/);
 assert.equal(client.events[0].sql,'SAVEPOINT master7_restore_bootstrap');
 assert.equal(client.events.at(-1).sql,'RELEASE SAVEPOINT master7_restore_bootstrap');
 assert.equal(client.released,false,'The outer transaction owns the client');
 assert.equal(client.events.some(event=>event.params[0]?.includes?.('open-explicit')),false,'Bootstrap must not activate payment providers');
});

test('PostgreSQL rehearsal rolls a late migration failure back to its savepoint',async()=>{
 const client=new RehearsalClient(/ALTER TABLE benefit_claims ADD COLUMN IF NOT EXISTS review_note/);
 await assert.rejects(()=>initializeRehearsalSchema(client,'SELECT 1;',[],'restore_fixture'),/synthetic migration failure/);
 assert.deepEqual(client.events.slice(-2).map(event=>event.sql),['ROLLBACK TO SAVEPOINT master7_restore_bootstrap','RELEASE SAVEPOINT master7_restore_bootstrap']);
 assert.equal(client.released,false);
});

test('PostgreSQL rehearsal rejects transaction control hidden in SQL batches or comments',async()=>{
 for(const schema of ['SELECT 1; COMMIT;','-- schema header\nCOMMIT AND CHAIN;','SELECT 1; /* outer /* inner */ comment */ END;','SELECT 1; PREPARE TRANSACTION \'fixture\';','SELECT 1; ROLLBACK;']){
  const client=new RehearsalClient();
  await assert.rejects(()=>initializeRehearsalSchema(client,schema,[],'restore_fixture'),/Unsupported restore bootstrap transaction statement/);
  assert.equal(client.events.some(event=>event.sql===schema),false,'Unsafe SQL must not reach the database');
  assert.deepEqual(client.events.slice(-2).map(event=>event.sql),['ROLLBACK TO SAVEPOINT master7_restore_bootstrap','RELEASE SAVEPOINT master7_restore_bootstrap']);
 }
});

test('PostgreSQL rehearsal permits transaction words inside strings and function bodies',async()=>{
 const schema=`SELECT 'COMMIT; ''ROLLBACK''', E'escaped\\\'quote; COMMIT';
 CREATE FUNCTION fixture_fn() RETURNS void LANGUAGE plpgsql AS $body$ BEGIN RETURN; END; $body$;`;
 const client=new RehearsalClient();
 await initializeRehearsalSchema(client,schema,[],'restore_fixture');
 assert.ok(client.events.some(event=>event.sql===schema));
 assert.equal(client.events.at(-1).sql,'RELEASE SAVEPOINT master7_restore_bootstrap');
});
