import assert from 'node:assert/strict';
import test from 'node:test';
import {GAME_PROVIDER_ADAPTER_METHODS, GameProviderUnavailableError} from '../lib/game-provider-adapter.ts';
import {
  GAME_PROVIDER_BRANDS,
  GAME_PROVIDER_PROFILES,
  getGameProviderProfile,
  getGameProviderProfiles,
  resolveGameProviderAdapter,
} from '../lib/game-provider-registry.ts';

test('registry retains 37 lobby brands and gives every brand a lobby profile', () => {
  assert.equal(GAME_PROVIDER_BRANDS.length, 37);
  assert.equal(new Set(GAME_PROVIDER_BRANDS.map(item => item.providerId)).size, 37);
  for (const brand of GAME_PROVIDER_BRANDS) {
    assert.ok(getGameProviderProfiles(brand.providerId).some(item => item.listedInLobby), brand.providerId);
  }
});

test('every profile has isolated player and ledger namespaces and remains unverified', () => {
  assert.ok(GAME_PROVIDER_PROFILES.length > GAME_PROVIDER_BRANDS.length);
  assert.equal(new Set(GAME_PROVIDER_PROFILES.map(item => item.profileId)).size, GAME_PROVIDER_PROFILES.length);
  assert.equal(new Set(GAME_PROVIDER_PROFILES.map(item => item.playerNamespace)).size, GAME_PROVIDER_PROFILES.length);
  assert.equal(new Set(GAME_PROVIDER_PROFILES.map(item => item.ledgerNamespace)).size, GAME_PROVIDER_PROFILES.length);
  for (const item of GAME_PROVIDER_PROFILES) {
    assert.equal(item.currency, 'MYR');
    assert.match(item.envPrefix, /^GAME_[A-Z0-9_]+$/);
    assert.equal(item.enabled, false);
    assert.equal(item.launchVerified, false);
    assert.equal(item.walletVerified, false);
    assert.equal(item.settlementVerified, false);
  }
});

test('known multi-account suppliers keep exact independent profiles and scales', () => {
  assert.deepEqual(getGameProviderProfiles('jili').map(item => item.profileId), ['jili_myr_1to1', 'jili_my1_1to100']);
  assert.deepEqual(getGameProviderProfiles('918kissh5').map(item => item.profileId), ['918kiss_normal_myr', '918kiss_normal_my1_1to100', '918kiss_free_myr']);
  assert.deepEqual(getGameProviderProfiles('epicwin').map(item => item.profileId), ['epicwin_normal_myr', 'epicwin_free_myr']);
  assert.equal(getGameProviderProfile('jili_my1_1to100').unitScale, 100);
  assert.equal(getGameProviderProfile('918kiss_normal_my1_1to100').unitScale, 100);
});

test('SPRIBE is independent from JDB while remaining outside the current 37 lobby brands', () => {
  const spribe = getGameProviderProfile('spribe_myr');
  const jdb = getGameProviderProfile('jdb_myr');
  assert.equal(jdb.walletMode, 'transfer');
  assert.equal(jdb.enabled, false);
  assert.equal(spribe.providerId, 'spribe');
  assert.equal(spribe.adapterKey, 'jdb');
  assert.notEqual(spribe.playerNamespace, jdb.playerNamespace);
  assert.notEqual(spribe.ledgerNamespace, jdb.ledgerNamespace);
  assert.equal(spribe.listedInLobby, false);
  assert.equal(GAME_PROVIDER_BRANDS.some(item => item.providerId === 'spribe'), false);
});

test('only the implemented MegaH5 profile can resolve an injected executable adapter', async () => {
  const fakeMega = Object.fromEntries([
    ['key', 'megah5'],
    ['executable', true],
    ...GAME_PROVIDER_ADAPTER_METHODS.map(method => [method, async () => ({method})]),
  ]);
  assert.equal(resolveGameProviderAdapter('megah5_myr', {megah5: fakeMega}), fakeMega);
  for (const item of GAME_PROVIDER_PROFILES.filter(profile => profile.profileId !== 'megah5_myr')) {
    assert.equal(resolveGameProviderAdapter(item.profileId, {[item.adapterKey]: fakeMega}).executable, false, item.profileId);
  }
  await assert.rejects(resolveGameProviderAdapter('megah5_myr').launchGame(), error =>
    error instanceof GameProviderUnavailableError && error.reason === 'adapter_unimplemented' && error.operation === 'launchGame');
});

test('all unavailable adapter operations fail closed with a precise reason', async () => {
  for (const [profileId, expectedReason] of [
    ['jili_myr_1to1', 'adapter_unimplemented'],
    ['fuma_myr', 'contract_missing'],
    ['unknown_profile', 'contract_missing'],
  ]) {
    const adapter = resolveGameProviderAdapter(profileId);
    for (const method of GAME_PROVIDER_ADAPTER_METHODS) {
      await assert.rejects(adapter[method](), error =>
        error instanceof GameProviderUnavailableError && error.profileId === profileId && error.reason === expectedReason && error.operation === method);
    }
  }
});
