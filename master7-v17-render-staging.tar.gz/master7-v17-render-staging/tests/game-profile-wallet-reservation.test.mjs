import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {clearStaleReservation,submitWithdrawal,withdrawalWalletState} from '../lib/withdrawals.ts';
import {MegaWalletError,prepareMegaWallet} from '../lib/megah5-wallet.ts';
import {megaCapabilityFixture} from './fixtures/megah5-capability.mjs';

class Statement {
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}

function setup(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());
 const migrations=new URL('../drizzle/',import.meta.url);
 for(const file of readdirSync(migrations).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,migrations),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(items){sqlite.exec('BEGIN IMMEDIATE');try{const result=[];for(const item of items)result.push(await item.run());sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.exec(`
  INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member','member',1,'csrf',0),('other','other','member',1,'csrf',0);
  INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at)
   VALUES('credit','member','credit-request','credit-fingerprint','manual_bank',10000,'MYR','fixture','credited',0,0);
  INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at)
   VALUES('credit-member','credit','member','member',10000,'MYR',0),('credit-clearing','credit','member','provider_clearing',-10000,'MYR',0);
  INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at)
   VALUES('jdb_myr','jdb','JDB','jdb','transfer','cash','MYR',1,1,'uat','uat',0,0);
  INSERT INTO game_provider_players(profile_id,user_id,provider_player_id,status,created_at,updated_at)
   VALUES('jdb_myr','member','player1','verified',0,0),('jdb_myr','other','player2','verified',0,0);
  INSERT INTO game_provider_sessions(id,profile_id,user_id,provider_player_id,game_code,provider_game_id,request_key,request_fingerprint,wallet_mode,currency,status,created_at,updated_at)
   VALUES('session1','jdb_myr','member','player1','0:1','0:1','launch1','fingerprint1','transfer','MYR','unknown',0,0),
         ('session2','jdb_myr','other','player2','0:1','0:1','launch2','fingerprint2','transfer','MYR','active',0,0);
  INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','game','session1',4000,0);
 `);
 return {sqlite,db};
}

test('generic profile reservations stay held and visible to the member wallet',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.exec("INSERT INTO game_wallet_transfers(id,session_id,profile_id,user_id,direction,request_key,request_fingerprint,provider_reference,amount_minor,currency,status,attempts,created_at,updated_at,completed_at) VALUES('funded-transfer','session1','jdb_myr','member','deposit','funded-request','funded-fingerprint','funded-reference',4000,'MYR','succeeded',1,0,1,1)");
 assert.deepEqual(await withdrawalWalletState(db,'member'),{balanceMinor:'10000',availableMinor:'6000',heldMinor:'4000',withdrawalHeldMinor:'0',gameHeldMinor:'4000'});
 for(const status of ['prepared','launching','active','settling','unknown','review']){
  sqlite.prepare('UPDATE game_provider_sessions SET status=? WHERE id=?').run(status,'session1');
  await clearStaleReservation(db,'member');
  assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='session1'").get().n,1,status);
  assert.equal((await withdrawalWalletState(db,'member')).availableMinor,status==='review'?'0':'6000',status);
 }
});

test('cleanup preserves even a closed generic session until explicit settlement releases it',async t=>{
 const {sqlite,db}=setup(t);
 for(const status of ['settled','failed']){
  sqlite.prepare('UPDATE game_provider_sessions SET status=? WHERE id=?').run(status,'session1');
  await clearStaleReservation(db,'member');
  assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE user_id='member'").get().n,1);
  assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'0');
  assert.equal((await withdrawalWalletState(db,'member')).reconciliationRequired,true);
 }
 sqlite.prepare("DELETE FROM wallet_reservations WHERE reference_id='session1'").run();
 assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'10000');
});

test('a reservation referencing another member or a missing session remains held for review',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.prepare("DELETE FROM wallet_reservations WHERE reference_id='session1'").run();
 sqlite.prepare("UPDATE game_provider_sessions SET status='settled' WHERE id='session1'").run();
 sqlite.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','game','session2',4000,0)").run();
 await clearStaleReservation(db,'member');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE user_id='member'").get().n,1);
 assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'0');
 assert.equal((await withdrawalWalletState(db,'member')).reconciliationRequired,true);
 sqlite.prepare("UPDATE wallet_reservations SET reference_id='missing-session' WHERE user_id='member'").run();
 await clearStaleReservation(db,'member');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE user_id='member'").get().n,1);
 assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'6000');
});

test('a legacy settled reservation requires a recorded result before cleanup',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.prepare("DELETE FROM wallet_reservations WHERE reference_id='session1'").run();
 sqlite.prepare("UPDATE game_provider_sessions SET status='settled' WHERE id='session1'").run();
 sqlite.prepare("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('legacy','member','megah5','player','55021','settled',4000,'legacy-ref',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','game','legacy',4000,0)").run();
 await clearStaleReservation(db,'member');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='legacy'").get().n,1);
 assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'0');
 sqlite.prepare("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('result','legacy','member','game_result',0,'MYR',1)").run();
 await clearStaleReservation(db,'member');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='legacy'").get().n,1);
 assert.equal((await withdrawalWalletState(db,'member')).reconciliationRequired,true);
 sqlite.prepare("UPDATE game_wallet_sessions SET amount_returned_minor=4000 WHERE id='legacy'").run();
 await clearStaleReservation(db,'member');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='legacy'").get().n,0);
 assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'10000');
});

test('a reference collision between legacy and generic sessions errs on the side of holding funds',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.prepare("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('session1','member','megah5','player','55021','active',4000,'legacy-collision',0,0)").run();
 assert.equal((await withdrawalWalletState(db,'member')).gameHeldMinor,'8000');
 await clearStaleReservation(db,'member');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='session1'").get().n,1);
});

test('a historically settled session with an inconsistent result stays frozen until reconciled',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.prepare("DELETE FROM wallet_reservations WHERE reference_id='session1'").run();
 sqlite.prepare("UPDATE game_provider_sessions SET status='settled' WHERE id='session1'").run();
 sqlite.prepare("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,deposit_reference,created_at,updated_at) VALUES('legacy-bad','member','megah5','player','55021','settled',4000,4000,'legacy-bad-ref',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','game','legacy-bad',4000,0)").run();
 sqlite.prepare("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('bad-result','legacy-bad','member','game_result',9999,'MYR',1)").run();
 await clearStaleReservation(db,'member');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='legacy-bad'").get().n,1);
 const wallet=await withdrawalWalletState(db,'member');assert.equal(wallet.balanceMinor,'10000');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
});

test('an open transfer session without its reservation makes the available balance unavailable',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.prepare("DELETE FROM wallet_reservations WHERE reference_id='session1'").run();
 const wallet=await withdrawalWalletState(db,'member');
 assert.equal(wallet.balanceMinor,'10000');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 let submissions=0;
 const context={db,user:{id:'member',username:'member',role:'member',approved:1},dataKey:'fixture-secret-'.padEnd(40,'z'),payouts:{vpay:{enabled:true,reason:'fixture',submit:async()=>{submissions++;return {status:'processing'};}}}};
 const response=await submitWithdrawal({providerId:'vpay',bankCode:'maybank',accountHolder:'Fixture Member',accountNumber:'1234567890',amount:'10.00',requestKey:'fixture-withdraw-request-0002'},context);
 assert.equal(response.status,409);assert.equal(submissions,0);
});

test('an existing generic reservation prevents a second MegaH5 wallet transfer',async t=>{
 const {sqlite,db}=setup(t);let balances=0,deposits=0;
 const fetchImpl=async url=>{
  const path=new URL(url).pathname;
  if(path==='/readiness')return Response.json(megaCapabilityFixture());
  if(path.endsWith('/balance')){balances++;return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:'0.00',Currency:'MYR'}});}
  if(path.endsWith('/deposit')){deposits++;return Response.json({provider:'megah5',result:{Status:200}});}
  throw new Error('unexpected fixture call');
 };
 const context={db,user:{id:'member',username:'member',role:'member',approved:1},gatewayUrl:'https://master7-integration-gateway.onrender.com',gameToken:'g'.repeat(48),walletToken:'w'.repeat(48),launchOriginsJson:'["https://launch.example.test"]',newGameLaunchesEnabled:'true',fetchImpl};
 await assert.rejects(prepareMegaWallet(context,'55021'),error=>error instanceof MegaWalletError&&error.status===409);
 assert.equal(balances,0);assert.equal(deposits,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='session1'").get().n,1);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM game_wallet_sessions").get().n,0);
 assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'6000');
});

test('a generic game reservation blocks withdrawal submission without calling a payout provider',async t=>{
 const {sqlite,db}=setup(t);let submissions=0;
 const context={db,user:{id:'member',username:'member',role:'member',approved:1},dataKey:'fixture-secret-'.padEnd(40,'z'),payouts:{vpay:{enabled:true,reason:'fixture',submit:async()=>{submissions++;return {status:'processing'};}}}};
 const response=await submitWithdrawal({providerId:'vpay',bankCode:'maybank',accountHolder:'Fixture Member',accountNumber:'1234567890',amount:'10.00',requestKey:'fixture-withdraw-request-0001'},context);
 assert.equal(response.status,409);assert.match((await response.json()).error,/Settle the game wallet/);
 assert.equal(submissions,0);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE reference_id='session1'").get().n,1);
});
