import {test} from 'node:test';
import assert from 'node:assert/strict';
import {renderPaymentActivationOptions} from '../lib/render-payment-activation.mjs';

const token=character=>character.repeat(32);
const bankCodes=['maybank','cimb','public_bank','rhb','hong_leong','ambank','bank_islam','bank_rakyat','bsn','alliance','affin','ocbc','uob','hsbc','standard_chartered','agrobank','bank_muamalat','mbsb'];
const bankTargets=JSON.stringify(Object.fromEntries(bankCodes.map((code,index)=>[code,`BANK_${index+1}`])));
const valid={
 VPAY_ORDERS_ENABLED:'true',VPAY_GATEWAY_URL:'https://master7-integration-gateway.onrender.com',
 VPAY_ORDER_TOKEN:token('a'),VPAY_QUERY_TOKEN:token('b'),VPAY_CALLBACK_TOKEN:token('c'),
 VPAY_MODE:'production',VPAY_TRADER_ID:'3647',VPAY_RETURN_URL:'https://master7-v17-staging.onrender.com/payment/return',
 ONE_MPAY_ORDERS_ENABLED:'true',ONE_MPAY_API_BASE_URL:'https://api.1mpay.net',ONE_MPAY_MERCHANT:'merchant_1',
 ONE_MPAY_SECRET_KEY:'d'.repeat(16),ONE_MPAY_CALLBACK_URL:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',ONE_MPAY_RETURN_URL:'https://master7-v17-staging.onrender.com/payment/return',
 GSPAY_ORDERS_ENABLED:'true',GSPAY_API_BASE_URL:'https://api.thegspay.com',GSPAY_AUTH_KEY:'e'.repeat(32),GSPAY_SECRET_KEY:'f'.repeat(32),GSPAY_RETURN_URL:'https://master7.best/payment/return',
};

test('only explicit enabled flags plus complete pinned production configuration activate deposits',()=>{
 assert.deepEqual(renderPaymentActivationOptions(valid),{vpayEnabled:true,oneMpayEnabled:true,gspayEnabled:true,gspayPayoutEnabled:false});
 for(const key of ['VPAY_ORDERS_ENABLED','ONE_MPAY_ORDERS_ENABLED','GSPAY_ORDERS_ENABLED']){
  const env={...valid,[key]:'false'},result=renderPaymentActivationOptions(env);
  assert.equal(result[key.startsWith('VPAY')?'vpayEnabled':key.startsWith('ONE')?'oneMpayEnabled':'gspayEnabled'],false);
 }
});

test('wrong hosts, reused VPay secrets and malformed provider credentials stay closed',()=>{
 assert.equal(renderPaymentActivationOptions({...valid,VPAY_GATEWAY_URL:'https://example.test'}).vpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,VPAY_MODE:'uat'}).vpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,VPAY_QUERY_TOKEN:valid.VPAY_ORDER_TOKEN}).vpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,ONE_MPAY_CALLBACK_URL:'https://master7.best/api/payment-callbacks/1mpay/payment'}).oneMpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,GSPAY_AUTH_KEY:'not-a-key'}).gspayEnabled,false);
 assert.deepEqual(renderPaymentActivationOptions({}),{vpayEnabled:false,oneMpayEnabled:false,gspayEnabled:false,gspayPayoutEnabled:false});
});

test('GSPAY payout activation requires its independent switch, IP acceptance, withdrawal key and complete bank targets',()=>{
 const ready={...valid,GSPAY_PAYOUT_ENABLED:'true',GSPAY_PAYOUT_IP_WHITELIST_CONFIRMED:'true',WITHDRAWAL_DATA_KEY:'w'.repeat(32),GSPAY_BANK_TARGETS_JSON:bankTargets};
 assert.equal(renderPaymentActivationOptions(ready).gspayPayoutEnabled,true);
 for(const key of ['GSPAY_PAYOUT_ENABLED','GSPAY_PAYOUT_IP_WHITELIST_CONFIRMED','WITHDRAWAL_DATA_KEY','GSPAY_BANK_TARGETS_JSON'])assert.equal(renderPaymentActivationOptions({...ready,[key]:''}).gspayPayoutEnabled,false);
});
