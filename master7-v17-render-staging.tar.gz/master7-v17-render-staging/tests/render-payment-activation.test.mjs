import {test} from 'node:test';
import assert from 'node:assert/strict';
import {renderPaymentActivationOptions} from '../lib/render-payment-activation.mjs';

const token=character=>character.repeat(32);
const bankCodes=['maybank','cimb','public_bank','rhb','hong_leong','ambank','bank_islam','bank_rakyat','bsn','alliance','affin','ocbc','uob','hsbc','standard_chartered','agrobank','bank_muamalat','mbsb'];
const bankTargets=JSON.stringify(Object.fromEntries(bankCodes.map((code,index)=>[code,`BANK_${index+1}`])));
const valid={
 VPAY_ORDERS_ENABLED:'true',VPAY_GATEWAY_URL:'https://master7-integration-gateway.onrender.com',
 VPAY_ORDER_TOKEN:token('a'),VPAY_QUERY_TOKEN:token('b'),VPAY_CALLBACK_TOKEN:token('c'),
 VPAY_MODE:'production',VPAY_TRADER_ID:'3647',VPAY_RETURN_URL:'https://master7-v17-staging.onrender.com/payment/return',
 ONE_MPAY_ORDERS_ENABLED:'true',ONE_MPAY_API_BASE_URL:'https://api.1mpay.net',ONE_MPAY_MERCHANT:'merchant_1',
 ONE_MPAY_SECRET_KEY:'d'.repeat(16),ONE_MPAY_CALLBACK_URL:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',ONE_MPAY_RETURN_URL:'https://master7-v17-staging.onrender.com/payment/return',
 GSPAY_ORDERS_ENABLED:'true',GSPAY_API_BASE_URL:'https://master7-integration-gateway.onrender.com',GSPAY_AUTH_KEY:'e'.repeat(32),GSPAY_SECRET_KEY:'f'.repeat(32),GSPAY_CALLBACK_TOKEN:'9'.repeat(32),GSPAY_RETURN_URL:'https://master7-v17-staging.onrender.com/payment/return',
};

test('only explicit enabled flags plus complete pinned production configuration activate deposits',()=>{
 assert.deepEqual(renderPaymentActivationOptions(valid),{vpayEnabled:true,vpayPayoutEnabled:false,oneMpayEnabled:true,gspayEnabled:true,gspayPayoutEnabled:false});
 for(const key of ['VPAY_ORDERS_ENABLED','ONE_MPAY_ORDERS_ENABLED','GSPAY_ORDERS_ENABLED']){
  const env={...valid,[key]:'false'},result=renderPaymentActivationOptions(env);
  assert.equal(result[key.startsWith('VPAY')?'vpayEnabled':key.startsWith('ONE')?'oneMpayEnabled':'gspayEnabled'],false);
 }
});

test('GSPAY uses the direct Render return route instead of a forwarding domain',()=>{
 const returnUrl=new URL(valid.GSPAY_RETURN_URL);
 assert.equal(returnUrl.origin,'https://master7-v17-staging.onrender.com');
 assert.equal(returnUrl.pathname,'/payment/return');
 assert.equal(renderPaymentActivationOptions(valid).gspayEnabled,true);
});

for(const origin of ['https://master7.best','https://www.master7.best'])test(`all payment activations bind to ${origin} when it is the configured public origin`,()=>{
 const env={...valid,PUBLIC_ORIGIN:origin,
  VPAY_RETURN_URL:`${origin}/payment/return`,
  ONE_MPAY_CALLBACK_URL:`${origin}/api/payment-callbacks/1mpay/payment`,
  ONE_MPAY_RETURN_URL:`${origin}/payment/return`,
  GSPAY_RETURN_URL:`${origin}/payment/return`,
 };
 const result=renderPaymentActivationOptions(env);
 assert.equal(result.vpayEnabled,true);assert.equal(result.oneMpayEnabled,true);assert.equal(result.gspayEnabled,true);
 assert.equal(renderPaymentActivationOptions({...env,ONE_MPAY_CALLBACK_URL:`https://master7.best/api/payment-callbacks/1mpay/payment`}).oneMpayEnabled,origin==='https://master7.best');
 assert.equal(renderPaymentActivationOptions({...env,GSPAY_RETURN_URL:valid.GSPAY_RETURN_URL}).gspayEnabled,false);
});

test('wrong hosts, reused VPay secrets and malformed provider credentials stay closed',()=>{
 assert.equal(renderPaymentActivationOptions({...valid,VPAY_GATEWAY_URL:'https://example.test'}).vpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,VPAY_MODE:'uat'}).vpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,VPAY_QUERY_TOKEN:valid.VPAY_ORDER_TOKEN}).vpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,ONE_MPAY_CALLBACK_URL:'https://master7.best/api/payment-callbacks/1mpay/payment'}).oneMpayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,GSPAY_AUTH_KEY:'not-a-key'}).gspayEnabled,false);
 assert.equal(renderPaymentActivationOptions({...valid,GSPAY_CALLBACK_TOKEN:valid.GSPAY_AUTH_KEY}).gspayEnabled,false);
 const legacyForwardingUrl=['https://www.master7','.best/payment/return'].join('');
 assert.equal(renderPaymentActivationOptions({...valid,GSPAY_RETURN_URL:legacyForwardingUrl}).gspayEnabled,false);
 assert.deepEqual(renderPaymentActivationOptions({}),{vpayEnabled:false,vpayPayoutEnabled:false,oneMpayEnabled:false,gspayEnabled:false,gspayPayoutEnabled:false});
});

test('VPay payout activation uses an isolated token and withdrawal encryption key',()=>{
 const ready={...valid,VPAY_PAYOUT_ENABLED:'true',VPAY_PAYOUT_TOKEN:token('p'),WITHDRAWAL_DATA_KEY:token('w')};
 assert.equal(renderPaymentActivationOptions(ready).vpayPayoutEnabled,true);
 for(const key of ['VPAY_PAYOUT_ENABLED','VPAY_PAYOUT_TOKEN','WITHDRAWAL_DATA_KEY'])assert.equal(renderPaymentActivationOptions({...ready,[key]:''}).vpayPayoutEnabled,false);
 assert.equal(renderPaymentActivationOptions({...ready,VPAY_PAYOUT_TOKEN:ready.VPAY_CALLBACK_TOKEN}).vpayPayoutEnabled,false);
});

test('GSPAY payout activation requires its independent switch, IP acceptance, withdrawal key and complete bank targets',()=>{
 const ready={...valid,GSPAY_API_BASE_URL:'https://api.thegspay.com',GSPAY_PAYOUT_ENABLED:'true',GSPAY_PAYOUT_IP_WHITELIST_CONFIRMED:'true',WITHDRAWAL_DATA_KEY:'w'.repeat(32),GSPAY_BANK_TARGETS_JSON:bankTargets};
 assert.equal(renderPaymentActivationOptions(ready).gspayPayoutEnabled,true);
 for(const key of ['GSPAY_PAYOUT_ENABLED','GSPAY_PAYOUT_IP_WHITELIST_CONFIRMED','WITHDRAWAL_DATA_KEY','GSPAY_BANK_TARGETS_JSON'])assert.equal(renderPaymentActivationOptions({...ready,[key]:''}).gspayPayoutEnabled,false);
});
