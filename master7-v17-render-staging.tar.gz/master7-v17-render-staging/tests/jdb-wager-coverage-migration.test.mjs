import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';

const sha='a'.repeat(64),otherSha='b'.repeat(64);
function fixture(t){
 const db=new DatabaseSync(':memory:');t.after(()=>db.close());db.exec('PRAGMA foreign_keys=ON');
 db.exec(readFileSync(new URL('../drizzle/0110_game_provider_adapter_core.sql',import.meta.url),'utf8'));
 db.exec("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES('jdb_myr','jdb','JDB · MYR','jdb','transfer','cash','MYR',1,1,'production','closed',0,0)");
 db.exec(readFileSync(new URL('../drizzle/0121_jdb_wager_coverage_staging.sql',import.meta.url),'utf8'));
 assert.deepEqual({...db.prepare("SELECT provider_id,adapter_key,wallet_mode,currency,environment,status FROM game_provider_profiles WHERE id='jdb_myr'").get()},{provider_id:'jdb',adapter_key:'jdb',wallet_mode:'transfer',currency:'MYR',environment:'production',status:'closed'});
 return db;
}

test('JDB staging migration does not create or mutate a provider profile',t=>{
 const db=new DatabaseSync(':memory:');t.after(()=>db.close());db.exec('PRAGMA foreign_keys=ON');
 db.exec(readFileSync(new URL('../drizzle/0110_game_provider_adapter_core.sql',import.meta.url),'utf8'));
 db.exec(readFileSync(new URL('../drizzle/0121_jdb_wager_coverage_staging.sql',import.meta.url),'utf8'));
 assert.equal(db.prepare("SELECT COUNT(*) n FROM game_provider_profiles WHERE id='jdb_myr'").get().n,0);
 assert.throws(()=>db.prepare(`INSERT INTO jdb_wager_sync_windows(window_id,profile_id,time_basis,window_start_ms,window_end_ms,created_at,updated_at)
  VALUES('missing-parent','jdb_myr','lastModifyTime',1000,2000,1,1)`).run(),/FOREIGN KEY constraint failed/);
});
function window(db){db.prepare(`INSERT INTO jdb_wager_sync_windows(window_id,profile_id,time_basis,window_start_ms,window_end_ms,state,current_fence,created_at,updated_at)
 VALUES('window-1','jdb_myr','lastModifyTime',1000,2000,'syncing',1,1,1)`).run();}
function receipt(db,overrides={}){
 const row={id:'receipt-1',window_id:'window-1',profile_id:'jdb_myr',fence:1,claim:sha,page:otherSha,page_complete:0,source:0,closure:0,authorization:0,coverage:0};Object.assign(row,overrides);
 return db.prepare(`INSERT INTO jdb_wager_receipts(id,window_id,profile_id,fence,claim_token_sha256,page_sha256,page_complete,source_finality_verified,session_closure_verified,merchant_authorization_verified,coverage_complete,observed_at)
 VALUES(?,?,?,?,?,?,?,?,?,?,?,1)`).run(row.id,row.window_id,row.profile_id,row.fence,row.claim,row.page,row.page_complete,row.source,row.closure,row.authorization,row.coverage);
}

test('JDB staging identifiers and source details are hash-only while every completion authority is false',t=>{
 const db=fixture(t);window(db);receipt(db);
 const columns=db.prepare("PRAGMA table_info('jdb_wager_event_versions')").all().map(row=>row.name);
 assert.ok(columns.includes('provider_player_sha256'));assert.ok(columns.includes('source_details_sha256'));
 assert.ok(!columns.includes('provider_player_id'));assert.ok(!columns.includes('source_details_json'));assert.ok(!columns.includes('payload_json'));
 for(const [column,value] of [['page_complete',1],['source',1],['closure',1],['authorization',1],['coverage',1]]){
  db.prepare('DELETE FROM jdb_wager_receipts').run();
  assert.throws(()=>receipt(db,{id:`bad-${column}`,[column]:value}),/CHECK constraint failed/);
 }
});

test('JDB staging schema rejects oversized windows and deduplicates a page across fences',t=>{
 const db=fixture(t);
 assert.throws(()=>db.prepare(`INSERT INTO jdb_wager_sync_windows(window_id,profile_id,time_basis,window_start_ms,window_end_ms,created_at,updated_at)
  VALUES('too-wide','jdb_myr','gameDate',0,300001,1,1)`).run(),/CHECK constraint failed/);
 window(db);receipt(db);
 assert.throws(()=>receipt(db,{id:'receipt-2',fence:2}),/UNIQUE constraint failed/);
 assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
});
