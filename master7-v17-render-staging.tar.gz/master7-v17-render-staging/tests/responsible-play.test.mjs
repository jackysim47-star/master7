import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {
  ResponsiblePlayError,
  assertResponsiblePlayGameLaunch,
  finalizeResponsiblePlayDeposit,
  getResponsiblePlay,
  mytPeriodWindows,
  reserveResponsiblePlayDeposit,
  responsiblePlayAdminStats,
  responsiblePlayPolicy,
  strictMinor,
  suppressResponsiblePlayMarketing,
  updateResponsiblePlay,
} from '../lib/responsible-play.ts';

class Statement{
  constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
  bind(...args){return new Statement(this.sqlite,this.sql,args);}
  async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
  async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
  async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function fixture(){
  const sqlite=new DatabaseSync(':memory:');
  sqlite.exec(`
   PRAGMA foreign_keys=ON;
   CREATE TABLE users(id TEXT PRIMARY KEY,phone TEXT,username TEXT,role TEXT,approved INTEGER,csrf TEXT,created_at INTEGER);
   CREATE TABLE deposit_orders(
    id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),request_key TEXT NOT NULL,provider TEXT NOT NULL,
    amount_minor INTEGER NOT NULL,status TEXT NOT NULL,updated_at INTEGER NOT NULL,UNIQUE(user_id,request_key)
   );
   CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL);
   CREATE TABLE marketing_contacts(id TEXT PRIMARY KEY,phone TEXT NOT NULL UNIQUE);
   CREATE TABLE marketing_deliveries(
    campaign_id TEXT NOT NULL,contact_id TEXT NOT NULL,status TEXT NOT NULL,claim_token TEXT,locked_until INTEGER NOT NULL DEFAULT 0,
    provider_error_code TEXT,failed_at INTEGER,updated_at INTEGER NOT NULL,PRIMARY KEY(campaign_id,contact_id)
   );
   INSERT INTO users VALUES
    ('member','+60111111111','member','member',1,'member-csrf',0),
    ('member2','+60112222222','member2','member',1,'member2-csrf',0),
    ('owner',NULL,'owner','owner',1,'owner-csrf',0);
  `);
  sqlite.exec(readFileSync(new URL('../drizzle/0102_responsible_play.sql',import.meta.url),'utf8'));
  let batchQueue=Promise.resolve();
  const db={
   prepare:sql=>new Statement(sqlite,sql),
   async batch(statements){const execute=async()=>{sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}};const task=batchQueue.then(execute,execute);batchQueue=task.catch(()=>{});return task;}
  };
  return {sqlite,db};
}

const at=Math.floor(Date.now()/1000);
const limitPayload=(daily,weekly,monthly)=>({action:'set_limits',dailyLimitMinor:daily,weeklyLimitMinor:weekly,monthlyLimitMinor:monthly});

test('Responsible Play defaults preserve existing member behavior and use MYT periods',async()=>{
 const {sqlite,db}=fixture();
 const state=await getResponsiblePlay(db,'member',at);
 assert.equal(state.configured,false);assert.equal(state.restricted,false);
 assert.deepEqual(state.limits,{dailyMinor:null,weeklyMinor:null,monthlyMinor:null});
 assert.deepEqual(state.availability,{newDeposits:true,gameLaunch:true,withdrawalRestriction:'not_added_by_play_settings',withdrawalChannelReadiness:'separate',login:true,records:true,support:true,balanceFrozen:false,balanceForfeited:false});
 assert.deepEqual(mytPeriodWindows(Math.floor(Date.parse('2026-11-01T16:00:00Z')/1000)),{
  daily:{start:Math.floor(Date.parse('2026-11-01T16:00:00Z')/1000),end:Math.floor(Date.parse('2026-11-02T16:00:00Z')/1000)},
  weekly:{start:Math.floor(Date.parse('2026-11-01T16:00:00Z')/1000),end:Math.floor(Date.parse('2026-11-08T16:00:00Z')/1000)},
  monthly:{start:Math.floor(Date.parse('2026-10-31T16:00:00Z')/1000),end:Math.floor(Date.parse('2026-11-30T16:00:00Z')/1000)},
 });
 assert.deepEqual(await reserveResponsiblePlayDeposit(db,'member',{provider:'vpay',requestKey:'default-request-key',amountMinor:'999999'},at),{reserved:false,idempotent:false});
 assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM responsible_play_deposit_reservations').get().count,0);
 assert.equal(await assertResponsiblePlayGameLaunch(db,'member',at),true);
 assert.equal(responsiblePlayPolicy.withdrawalsNotBlockedByPlaySettings,true);assert.equal(responsiblePlayPolicy.withdrawalChannelReadiness,'separate');assert.equal(responsiblePlayPolicy.balanceFrozen,false);
 sqlite.close();
});

test('minor-unit validation is strict and limits count credited plus every unresolved reservation',async()=>{
 const {sqlite,db}=fixture(),period=mytPeriodWindows(at);
 assert.equal(strictMinor('1000'),'1000');assert.equal(strictMinor(null),null);
 for(const invalid of [1000,'0','01','10.00','1e3','-1','',undefined])assert.throws(()=>strictMinor(invalid),ResponsiblePlayError);
 await updateResponsiblePlay(db,'member',limitPayload('10000','20000','30000'),at);
 const insert=sqlite.prepare('INSERT INTO deposit_orders VALUES(?,?,?,?,?,?,?)');
 insert.run('credited','member','credited-key','vpay',4000,'credited',period.daily.start+100);
 // Unresolved orders reserve allowance even when created in an earlier period.
 insert.run('pending','member','pending-key','1mpay',1000,'pending',period.monthly.start-1);
 insert.run('unknown','member','unknown-key','gspay',1000,'unknown',period.monthly.start-1);
 insert.run('failed','member','failed-key','vpay',9000,'failed',period.daily.start+200);
 const state=await getResponsiblePlay(db,'member',at);
 assert.deepEqual(state.usage,{outstandingMinor:'2000',dailyMinor:'6000',weeklyMinor:'6000',monthlyMinor:'6000'});
 assert.deepEqual(state.remaining,{dailyMinor:'4000',weeklyMinor:'14000',monthlyMinor:'24000'});
 const first=await reserveResponsiblePlayDeposit(db,'member',{provider:'manual_bank',requestKey:'limit-reservation-one',amountMinor:'4000'},at);
 assert.equal(first.reserved,true);
 await assert.rejects(()=>reserveResponsiblePlayDeposit(db,'member',{provider:'vpay',requestKey:'limit-reservation-two',amountMinor:'1'},at),error=>error instanceof ResponsiblePlayError&&error.code==='DAILY_DEPOSIT_LIMIT');
 assert.equal(sqlite.prepare("SELECT COUNT(*) count FROM audit WHERE event='responsible_play_deposit_blocked'").get().count,1);
 sqlite.prepare("INSERT INTO deposit_orders VALUES('manual','member','limit-reservation-one','manual_bank',4000,'pending',?)").run(at);
 assert.deepEqual(await finalizeResponsiblePlayDeposit(db,'member','manual_bank','limit-reservation-one',at+1),{consumed:true,orderId:'manual'});
 assert.equal(sqlite.prepare("SELECT status FROM responsible_play_deposit_reservations WHERE request_key='limit-reservation-one'").get().status,'consumed');
 sqlite.close();
});

test('atomic reservations prevent concurrent deposit-limit bypass',async()=>{
 const {sqlite,db}=fixture();await updateResponsiblePlay(db,'member2',limitPayload('10000','10000','10000'),at);
 const settled=await Promise.allSettled([
  reserveResponsiblePlayDeposit(db,'member2',{provider:'vpay',requestKey:'concurrent-request-a',amountMinor:'6000'},at),
  reserveResponsiblePlayDeposit(db,'member2',{provider:'gspay',requestKey:'concurrent-request-b',amountMinor:'6000'},at),
 ]);
 assert.equal(settled.filter(item=>item.status==='fulfilled').length,1);
 const rejected=settled.find(item=>item.status==='rejected');assert.ok(rejected);assert.equal(rejected.reason.code,'DAILY_DEPOSIT_LIMIT');
 assert.equal(sqlite.prepare("SELECT SUM(amount_minor) total FROM responsible_play_deposit_reservations WHERE user_id='member2' AND status='reserved'").get().total,6000);
 sqlite.close();
});

test('a live idempotency reservation cannot start a duplicate provider call, while a released reservation can retry safely',async()=>{
 const {sqlite,db}=fixture();await updateResponsiblePlay(db,'member',limitPayload('10000','10000','10000'),at);
 const input={provider:'vpay',requestKey:'same-request-reservation',amountMinor:'1000'};
 assert.deepEqual(await reserveResponsiblePlayDeposit(db,'member',input,at),{reserved:true,idempotent:false});
 assert.deepEqual(await reserveResponsiblePlayDeposit(db,'member',input,at),{reserved:true,idempotent:true});
 assert.deepEqual(await finalizeResponsiblePlayDeposit(db,'member','vpay',input.requestKey,at+1),{consumed:false,orderId:null});
 assert.equal(sqlite.prepare('SELECT status FROM responsible_play_deposit_reservations WHERE user_id=? AND request_key=?').get('member',input.requestKey).status,'released');
 assert.deepEqual(await reserveResponsiblePlayDeposit(db,'member',input,at+2),{reserved:true,idempotent:false});
 sqlite.close();
});

test('less restrictive limits wait 24 hours while safer limits apply immediately',async()=>{
 const {sqlite,db}=fixture();
 let state=await updateResponsiblePlay(db,'member',limitPayload('10000','20000','30000'),at);
 assert.equal(state.limits.dailyMinor,'10000');assert.equal(state.pendingLimits,null);
 state=await updateResponsiblePlay(db,'member',limitPayload('20000','30000','40000'),at+1);
 assert.equal(state.limits.dailyMinor,'10000');assert.equal(state.pendingLimits.dailyMinor,'20000');assert.equal(state.pendingLimits.effectiveAt,at+1+86400);
 assert.equal((await getResponsiblePlay(db,'member',at+86400)).limits.dailyMinor,'10000');
 state=await getResponsiblePlay(db,'member',at+86402);assert.equal(state.limits.dailyMinor,'20000');assert.equal(state.pendingLimits,null);
 state=await updateResponsiblePlay(db,'member',limitPayload('5000','10000','15000'),at+86403);assert.equal(state.limits.dailyMinor,'5000');assert.equal(state.pendingLimits,null);
 assert.equal(sqlite.prepare("SELECT COUNT(*) count FROM audit WHERE event='responsible_play_limits_applied'").get().count,1);
 sqlite.close();
});

test('a mixed limit change applies safer fields now and delays only the less restrictive target',async()=>{
 const {sqlite,db}=fixture();await updateResponsiblePlay(db,'member',limitPayload('10000','20000','30000'),at);
 const state=await updateResponsiblePlay(db,'member',limitPayload('5000','25000','30000'),at+1);
 assert.deepEqual(state.limits,{dailyMinor:'5000',weeklyMinor:'20000',monthlyMinor:'30000'});
 assert.deepEqual(state.pendingLimits,{dailyMinor:'5000',weeklyMinor:'25000',monthlyMinor:'30000',effectiveAt:at+1+86400});
 const mature=await getResponsiblePlay(db,'member',at+86402);assert.deepEqual(mature.limits,{dailyMinor:'5000',weeklyMinor:'25000',monthlyMinor:'30000'});
 sqlite.close();
});

test('active cooling-off and self-exclusion are immutable and only pause deposits, games and marketing',async()=>{
 const {sqlite,db}=fixture();
 let state=await updateResponsiblePlay(db,'member',{action:'cooling_off',durationHours:24},at);
 assert.equal(state.restrictions.coolingOff.active,true);assert.equal(state.availability.withdrawalRestriction,'not_added_by_play_settings');assert.equal(state.availability.withdrawalChannelReadiness,'separate');assert.equal(state.availability.support,true);assert.equal(state.availability.balanceFrozen,false);
 await assert.rejects(()=>updateResponsiblePlay(db,'member',{action:'cooling_off',until:at+7200},at+1),error=>error.code==='ACTIVE_WINDOW_IMMUTABLE');
 assert.throws(()=>sqlite.prepare('UPDATE responsible_play_profiles SET cooling_off_until=NULL WHERE user_id=?').run('member'),/RESPONSIBLE_PLAY_ACTIVE_WINDOW_IMMUTABLE/);
 await assert.rejects(()=>reserveResponsiblePlayDeposit(db,'member',{provider:'vpay',requestKey:'cooling-deposit-key',amountMinor:'1000'},at+2),error=>error.code==='COOLING_OFF_ACTIVE');
 await assert.rejects(()=>assertResponsiblePlayGameLaunch(db,'member',at+2),error=>error.code==='COOLING_OFF_ACTIVE');
 state=await updateResponsiblePlay(db,'member',{action:'self_exclude',durationDays:30},at+3);assert.equal(state.restrictions.selfExclusion.active,true);
 sqlite.exec("INSERT INTO marketing_contacts VALUES('contact','+60111111111'); INSERT INTO marketing_deliveries(campaign_id,contact_id,status,updated_at) VALUES('campaign','contact','queued',0)");
 assert.equal(await suppressResponsiblePlayMarketing(db,at+4),1);
 const delivery=sqlite.prepare("SELECT status,provider_error_code FROM marketing_deliveries WHERE contact_id='contact'").get();assert.equal(delivery.status,'failed');assert.equal(delivery.provider_error_code,'responsible_play_suppressed');
 assert.equal(sqlite.prepare("SELECT COUNT(*) count FROM audit WHERE event='responsible_play_cooling_off_started'").get().count,1);
 assert.equal(sqlite.prepare("SELECT COUNT(*) count FROM audit WHERE event='responsible_play_self_exclusion_started'").get().count,1);
 sqlite.close();
});

test('owner statistics are anonymous, aggregate only and cannot change a member profile',async()=>{
 const {sqlite,db}=fixture();await updateResponsiblePlay(db,'member',limitPayload('1000','2000','3000'),at);await updateResponsiblePlay(db,'member2',{action:'self_exclude',durationDays:90},at);
 const report=await responsiblePlayAdminStats(db,at+1);
 assert.equal(report.anonymous,true);assert.equal(report.memberDetailsExposed,false);assert.equal(report.ownerOverride,false);
 assert.deepEqual(report.counts,{profiles:2,membersWithLimits:1,activeCoolingOff:0,activeSelfExclusion:1,blockedDepositsLast30Days:0,blockedGameLaunchesLast30Days:0});
 assert.doesNotMatch(JSON.stringify(report),/member2|\+6011/);
 sqlite.close();
});
