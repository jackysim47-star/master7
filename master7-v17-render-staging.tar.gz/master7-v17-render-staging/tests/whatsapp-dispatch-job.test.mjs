import test from "node:test";
import assert from "node:assert/strict";
import { startWhatsAppDispatch } from "../scripts/whatsapp-dispatch-job.mjs";

test("WhatsApp dispatch worker is inert until sending is explicitly enabled with a strong token", async () => {
  let calls = 0;
  const fetchImpl = async () => {
    calls++;
    return Response.json({ ok: true });
  };
  for (const options of [
    { enabled: false, token: "x".repeat(40), port: 3000 },
    { enabled: true, token: "short", port: 3000 },
    { enabled: true, token: "x".repeat(40), port: "3000/attacker" },
    { enabled: true, token: "x".repeat(40), port: 70000 },
  ]) {
    const worker = startWhatsAppDispatch(options, fetchImpl);
    await worker.run();
    worker.stop();
  }
  assert.equal(calls, 0);
});

test("WhatsApp dispatch worker calls only its protected loopback endpoint", async () => {
  const calls = [];
  const token = "whatsapp-worker-token-".padEnd(48, "w");
  const worker = startWhatsAppDispatch(
    { enabled: true, token, port: 4321, intervalMs: 1000, startupDelayMs: 60000 },
    async (url, init) => {
      calls.push({ url, init });
      return Response.json({ ok: true });
    },
  );
  await worker.run();
  worker.stop();
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, "http://127.0.0.1:4321/api/internal/whatsapp-dispatch");
  assert.equal(calls[0].init.method, "POST");
  assert.equal(calls[0].init.headers.Authorization, `Bearer ${token}`);
  assert.equal(calls[0].init.redirect, "error");
});

test("WhatsApp dispatch worker prevents overlapping calls and stops permanently", async () => {
  let calls = 0;
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  const worker = startWhatsAppDispatch(
    { enabled: true, token: "w".repeat(40), port: 3000, startupDelayMs: 60000 },
    async () => {
      calls++;
      await gate;
      return Response.json({ ok: true });
    },
  );
  const first = worker.run();
  await worker.run();
  assert.equal(calls, 1);
  release();
  await first;
  worker.stop();
  await worker.run();
  assert.equal(calls, 1);
});
