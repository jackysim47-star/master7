import {
 CRITICAL_DATABASE_GUARDS,
 CRITICAL_DATABASE_GUARD_FUNCTIONS,
 CRITICAL_DATABASE_GUARD_TRIGGER_BEHAVIOR,
} from '../lib/render-migrations.mjs';

export function criticalDatabaseGuardRows(schema='public'){
 return CRITICAL_DATABASE_GUARDS.map(({tableName:table_name,triggerName:trigger_name,functionName,triggerType:trigger_type,updateColumns:update_columns})=>{
  const fn=CRITICAL_DATABASE_GUARD_FUNCTIONS.find(item=>item.name===functionName);
  if(!fn)throw new Error(`Missing fixture contract for ${functionName}`);
  const behavior=CRITICAL_DATABASE_GUARD_TRIGGER_BEHAVIOR;
  return {
   table_schema:schema,table_name,trigger_name,enabled:'O',trigger_type,update_columns:[...update_columns],
   trigger_when_is_null:behavior.whenIsNull,trigger_argument_count:behavior.argumentCount,trigger_arguments_empty:behavior.argumentsEmpty,
   old_transition_table:behavior.oldTransitionTable,new_transition_table:behavior.newTransitionTable,
   constraint_oid:behavior.constraintOid,constraint_relation_oid:behavior.constraintRelationOid,
   trigger_deferrable:behavior.deferrable,trigger_initially_deferred:behavior.initiallyDeferred,parent_trigger_oid:behavior.parentTriggerOid,
   function_schema:schema,function_name:fn.name,function_identity_arguments:fn.identityArguments,function_language:fn.language,
   function_return_type:fn.returnType,function_kind:fn.kind,function_volatility:fn.volatility,function_parallel_safety:fn.parallelSafety,
   function_security_definer:fn.securityDefiner,function_leakproof:fn.leakproof,function_strict:fn.strict,function_returns_set:fn.returnsSet,
   function_config:[...fn.config],function_source:`\r\n${fn.source}\r\n`,
  };
 });
}
