import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/assets/style.css',import.meta.url),'utf8');
const route=readFileSync(new URL('../app/api/[...path]/route.ts',import.meta.url),'utf8');
const renderEnv=readFileSync(new URL('../lib/render-env.ts',import.meta.url),'utf8');

test('Stephanie is presented as a multilingual AI assistant with human escalation',()=>{
 assert.match(html,/STEPHANIE · MASTER7 AI SUPPORT/);
 assert.match(html,/class="stephanie-avatar"/);
 assert.match(html,/English, Chinese and Bahasa Melayu/);
 assert.match(html,/Payment, withdrawal, account security and complaint cases remain available for staff review/);
 assert.match(css,/\.stephanie-intro/);
 assert.match(css,/\.stephanie-avatar/);
 assert.match(app,/"External AI",external\?"Connected":"Not connected"/);
 assert.match(app,/"Safe rules fallback",data\.rulesFallbackReady\?"Ready":"Unavailable"/);
 assert.match(app,/外部 AI 尚未连接；Stephanie 目前使用中英马三语安全规则回复/);
});

test('external AI credentials are server-only and the UI exposes readiness booleans only',()=>{
 for(const key of ['OPENAI_ENABLED','OPENAI_API_BASE_URL','OPENAI_API_KEY','OPENAI_MODEL','SUPPORT_AI_ENABLED','SUPPORT_AI_API_BASE_URL','SUPPORT_AI_API_KEY','SUPPORT_AI_MODEL']){
  assert.match(route,new RegExp(key));
  assert.match(renderEnv,new RegExp(key));
 }
 assert.doesNotMatch(html,/SUPPORT_AI_API_KEY|SUPPORT_AI_MODEL/);
 assert.doesNotMatch(app,/SUPPORT_AI_API_KEY|SUPPORT_AI_MODEL/);
});
