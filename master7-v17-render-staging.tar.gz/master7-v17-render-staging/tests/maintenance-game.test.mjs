import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {MegaWalletError,prepareMegaWallet} from '../lib/megah5-wallet.ts';
import {withdrawalWalletState} from '../lib/withdrawals.ts';
import {megaCapabilityFixture} from './fixtures/megah5-capability.mjs';

// This suite verifies the maintenance boundary through the real router and
// MegaH5 wallet implementation. Every upstream response is an in-process
// fixture, so these tests can never contact a supplier or move real funds.
const gateway='https://master7-integration-gateway.onrender.com';
const gameToken='g'.repeat(48),walletToken='w'.repeat(48);
const game={provider:'megah5',providerName:'MegaH5',gameCode:'55021',name:'Ocean Quest',category:'2',maintenance:false,playable:false};

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function harness(){
 const sqlite=new DatabaseSync(':memory:'),migrations=new URL('../drizzle/',import.meta.url);
 for(const file of readdirSync(migrations).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,migrations),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member@example.test','member',1,'fixture-csrf',0)").run();
 sqlite.prepare("INSERT INTO providers(id,name,category,symbol,visible) VALUES('megah5','MegaH5','supplier','M7',1) ON CONFLICT(id) DO UPDATE SET visible=1").run();
 sqlite.prepare("INSERT INTO api_supplier_artwork(provider_id,image_data,status,updated_by,updated_at) VALUES('megah5','','active','member',0) ON CONFLICT(provider_id) DO UPDATE SET status='active'").run();
 sqlite.prepare("INSERT INTO game_visibility(provider_id,game_code,visible,status,image_data,category_override,updated_by,updated_at) VALUES('megah5','55021',1,'active','','','member',0)").run();
 const stamp=Math.floor(Date.now()/1000);
 sqlite.prepare("INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,upstream_status,lease_until,complete) VALUES('megah5','available',?,?,?,200,0,1)").run(JSON.stringify([game]),stamp,stamp);
 sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fixture-credit','member','fixture-credit-key','fixture','manual_bank',2000,'MYR','fixture','credited',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('fixture-member','fixture-credit','member','member',2000,'MYR',0),('fixture-clearing','fixture-credit','member','provider_clearing',-2000,'MYR',0)").run();

 const provider={balance:'0.00',deposit:'success',withdraw:'success',statusAmount:'20.00'};
 const calls=[];
 const fetchImpl=async(url,init={})=>{
  const path=new URL(url).pathname;
  calls.push({path,body:init.body?JSON.parse(init.body):null});
  if(path==='/readiness')return Response.json(megaCapabilityFixture());
  if(path==='/platform/megah5/session')return Response.json({provider:'megah5',upstreamStatus:200,result:{Status:200,Url:'https://launch.example.test/session'}});
  if(path==='/platform/megah5/balance')return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:provider.balance,Currency:'MYR'}});
  if(path==='/platform/megah5/deposit'){
   if(provider.deposit==='throw')throw new Error('fixture deposit transport failure');
   return Response.json({provider:'megah5',operation:path.endsWith('/deposit')?'deposit':'withdraw',referenceId:JSON.parse(init.body).referenceId,result:{Status:200,Description:'Success'}});
  }
  if(path==='/platform/megah5/withdraw'){
   if(provider.withdraw==='throw')throw new Error('fixture withdrawal transport failure');
   return Response.json({provider:'megah5',operation:path.endsWith('/deposit')?'deposit':'withdraw',referenceId:JSON.parse(init.body).referenceId,result:{Status:200,Description:'Success'}});
  }
  if(path==='/platform/megah5/transfer-status')return Response.json({provider:'megah5',operation:'transfer_status',result:{Status:200,Description:'Success',Trans:{Amount:provider.statusAmount,Currency:'MYR'}}});
  throw new Error(`Unexpected fixture gateway call: ${path}`);
 };
 const context={db,identity:{userId:'member',email:'member@example.test'},ownerEmail:'owner@example.test',newGameLaunchesEnabled:'false',gameGatewayUrl:gateway,gameGatewayToken:gameToken,gameGatewayWalletToken:walletToken,megaTransfersEnabled:'true',megaLiveGamesEnabled:'true',megaSettlementVerified:'true',gameGatewayFetch:fetchImpl};
 async function request(path,{method='GET',data}={}){
  const response=await handle(new Request('https://portal.example.test'+path,{method,headers:{'content-type':'application/json',origin:'https://portal.example.test','x-csrf-token':'fixture-csrf','x-forwarded-for':'203.0.113.8'},...(data===undefined?{}:{body:JSON.stringify(data)})}),context);
  return {status:response.status,data:await response.json()};
 }
 const launch=()=>request('/api/game-launch',{method:'POST',data:{providerId:'megah5',gameCode:'55021'}});
 const directContext=()=>({db,user:{id:'member',username:'member@example.test',role:'member',approved:1},gatewayUrl:gateway,gameToken,walletToken,newGameLaunchesEnabled:context.newGameLaunchesEnabled,fetchImpl});
 return {sqlite,db,provider,calls,context,request,launch,directContext,close:()=>sqlite.close()};
}

function count(sqlite,table,where=''){return sqlite.prepare(`SELECT COUNT(*) n FROM ${table}${where}`).get().n;}
function pathCount(h,path){return h.calls.filter(call=>call.path===path).length;}

test('game maintenance blocks both the universal launch route and direct MegaH5 session preparation without creating data',async()=>{
 const h=harness();try{
  const denied=await h.launch();
  assert.equal(denied.status,503);assert.equal(denied.data.code,'GAMES_MAINTENANCE');
  await assert.rejects(()=>prepareMegaWallet(h.directContext(),'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  assert.equal(h.calls.length,0);
  assert.equal(count(h.sqlite,'game_wallet_sessions'),0);
  assert.equal(count(h.sqlite,'wallet_reservations'),0);
  assert.equal(count(h.sqlite,'game_wallet_ledger'),0);
 }finally{h.close();}
});

test('an existing game settles exactly once while new game launches are in maintenance',async()=>{
 const h=harness();try{
  h.context.newGameLaunchesEnabled='true';
  const opened=await prepareMegaWallet(h.directContext(),'55021');assert.equal(opened.walletVerified,true);assert.equal(count(h.sqlite,'game_wallet_sessions'),1);
  h.context.newGameLaunchesEnabled='false';h.provider.balance='15.50';
  const blocked=await h.launch();assert.equal(blocked.status,503);assert.equal(blocked.data.code,'GAMES_MAINTENANCE');
  const settled=await h.request('/api/game-wallet/settle',{method:'POST',data:{}});
  assert.equal(settled.status,200);assert.equal(settled.data.status,'settled');assert.equal(settled.data.session.resultMinor,'-450');
  const duplicate=await h.request('/api/game-wallet/settle',{method:'POST',data:{}});assert.equal(duplicate.status,200);assert.equal(duplicate.data.status,'none');
  assert.equal(pathCount(h,'/platform/megah5/session'),0);assert.equal(pathCount(h,'/platform/megah5/withdraw'),1);
  assert.equal(count(h.sqlite,'game_wallet_sessions'),1);assert.equal(count(h.sqlite,'game_wallet_ledger'),1);assert.equal(count(h.sqlite,'wallet_reservations'),0);
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'1550',availableMinor:'1550',heldMinor:'0',withdrawalHeldMinor:'0',gameHeldMinor:'0'});
 }finally{h.close();}
});

test('deposit-status wallet recovery remains available and idempotent during game maintenance',async()=>{
 const h=harness();try{
  h.context.newGameLaunchesEnabled='true';h.provider.deposit='throw';
  await assert.rejects(()=>prepareMegaWallet(h.directContext(),'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'deposit_unknown');
  h.context.newGameLaunchesEnabled='false';
  const recovered=await h.request('/api/game-wallet/recover',{method:'POST',data:{}});assert.equal(recovered.status,200);assert.equal(recovered.data.status,'active');
  const repeated=await h.request('/api/game-wallet/recover',{method:'POST',data:{}});assert.equal(repeated.status,200);assert.equal(repeated.data.status,'active');
  assert.equal((await h.launch()).data.code,'GAMES_MAINTENANCE');
  assert.equal(pathCount(h,'/platform/megah5/deposit'),1);assert.equal(pathCount(h,'/platform/megah5/transfer-status'),1);assert.equal(pathCount(h,'/platform/megah5/session'),0);
  assert.equal(count(h.sqlite,'game_wallet_sessions'),1);assert.equal(count(h.sqlite,'game_wallet_ledger'),0);assert.equal(count(h.sqlite,'wallet_reservations'),1);
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'2000',availableMinor:'0',heldMinor:'2000',withdrawalHeldMinor:'0',gameHeldMinor:'2000'});
 }finally{h.close();}
});

test('an uncertain settlement recovers once without another withdrawal during game maintenance',async()=>{
 const h=harness();try{
  h.context.newGameLaunchesEnabled='true';assert.equal((await prepareMegaWallet(h.directContext(),'55021')).walletVerified,true);
  h.context.newGameLaunchesEnabled='false';h.provider.balance='15.50';h.provider.withdraw='throw';h.provider.statusAmount='15.50';
  const interrupted=await h.request('/api/game-wallet/settle',{method:'POST',data:{}});assert.equal(interrupted.status,503);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'withdraw_unknown');
  const recovered=await h.request('/api/game-wallet/recover',{method:'POST',data:{}});assert.equal(recovered.status,200);assert.equal(recovered.data.status,'settled');assert.equal(recovered.data.session.resultMinor,'-450');
  const repeated=await h.request('/api/game-wallet/recover',{method:'POST',data:{}});assert.equal(repeated.status,200);assert.equal(repeated.data.status,'none');
  assert.equal(pathCount(h,'/platform/megah5/withdraw'),1);assert.equal(pathCount(h,'/platform/megah5/transfer-status'),1);
  assert.equal(count(h.sqlite,'game_wallet_sessions'),1);assert.equal(count(h.sqlite,'game_wallet_ledger'),1);assert.equal(count(h.sqlite,'wallet_reservations'),0);
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'1550',availableMinor:'1550',heldMinor:'0',withdrawalHeldMinor:'0',gameHeldMinor:'0'});
 }finally{h.close();}
});
