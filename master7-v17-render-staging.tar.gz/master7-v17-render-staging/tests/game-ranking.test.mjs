import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {GAME_PROVIDER_IDS,GAME_PROVIDER_CATEGORY_IDS,defaultGameRanking,getGameRanking,rankPlatforms,saveGameRanking,validateGameRanking} from '../lib/game-ranking.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}
function fixture(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec("CREATE TABLE settings(id TEXT PRIMARY KEY,value TEXT NOT NULL);CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL);");
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(list){sqlite.exec('BEGIN');try{const results=[];for(const item of list)results.push(await item.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};return {sqlite,db};
}

test('default game ranking covers each of the 37 platform cards without inventing games',async()=>{
 const {db}=fixture(),result=await getGameRanking(db);assert.equal(result.configured,false);assert.equal(result.source,'owner_curated');assert.equal(result.automaticRanking,false);assert.equal(result.internalGamesRanked,false);assert.equal(result.platformCount,37);assert.deepEqual(result.ranking.categories.HOT,[...GAME_PROVIDER_IDS]);assert.equal(new Set(result.ranking.categories.HOT).size,37);assert.deepEqual(result.categoryCounts,{HOT:37,SLOT:14,LIVE:7,FISH:5,COCK:0,SPORT:1});
 const ranked=rankPlatforms(GAME_PROVIDER_IDS.map(id=>({id,playable:false})),result.ranking);assert.equal(ranked.length,37);assert.equal(ranked[0].position,1);assert.ok(ranked.every(item=>item.playable===false&&item.rankingSource==='owner_curated'));
});

test('game ranking validation allows ordering only and rejects missing, duplicate, invented, or reclassified platforms',()=>{
 const valid=defaultGameRanking();valid.categories.HOT=[...valid.categories.HOT].reverse();valid.categories.LIVE=[...valid.categories.LIVE].reverse();assert.equal(validateGameRanking(valid).categories.HOT[0],'clotplay');
 for(const broken of [
  {...defaultGameRanking(),categories:{...defaultGameRanking().categories,HOT:defaultGameRanking().categories.HOT.slice(1)}},
  {...defaultGameRanking(),categories:{...defaultGameRanking().categories,SLOT:[...GAME_PROVIDER_CATEGORY_IDS.SLOT.slice(0,-1),GAME_PROVIDER_CATEGORY_IDS.SLOT[0]]}},
  {...defaultGameRanking(),categories:{...defaultGameRanking().categories,LIVE:[...GAME_PROVIDER_CATEGORY_IDS.LIVE.slice(0,-1),'unknown']}},
  {...defaultGameRanking(),categories:{...defaultGameRanking().categories,SPORT:['jili']}},
 ])assert.throws(()=>validateGameRanking(broken));
});

test('owner curated ranking persists with an audit receipt and reloads exactly',async()=>{
 const {sqlite,db}=fixture(),ranking=defaultGameRanking();ranking.categories.HOT=[ranking.categories.HOT[1],ranking.categories.HOT[0],...ranking.categories.HOT.slice(2)];ranking.categories.FISH=[...ranking.categories.FISH].reverse();
 const saved=await saveGameRanking(db,'owner',ranking,1234);assert.equal(saved.status,'ok');assert.equal(saved.configured,true);assert.equal(saved.ranking.categories.HOT[0],'jili');assert.equal(saved.updatedAt,1234);const loaded=await getGameRanking(db);assert.deepEqual(loaded.ranking,ranking);assert.equal(loaded.updatedBy,'owner');const audit=sqlite.prepare("SELECT user_id,event,target,created_at FROM audit WHERE event='game_provider_ranking_updated'").get();assert.equal(audit.user_id,'owner');assert.equal(audit.created_at,1234);assert.deepEqual(JSON.parse(audit.target),{version:1,mode:'owner_curated',categories:{HOT:37,SLOT:14,LIVE:7,FISH:5,COCK:0,SPORT:1}});
});

test('stored 34-platform ranking expands safely to the three new independent entries',async()=>{
 const {sqlite,db}=fixture(),legacy=defaultGameRanking();
 legacy.categories.HOT=legacy.categories.HOT.slice(0,34).reverse();legacy.categories.SLOT=legacy.categories.SLOT.slice(0,12).reverse();
 sqlite.prepare('INSERT INTO settings(id,value) VALUES(?,?)').run('game_provider_ranking_v1',JSON.stringify({...legacy,updatedAt:123,updatedBy:'owner'}));
 const loaded=await getGameRanking(db);assert.equal(loaded.configured,true);assert.equal(loaded.platformCount,37);assert.deepEqual(loaded.ranking.categories.HOT.slice(0,34),legacy.categories.HOT);assert.deepEqual(loaded.ranking.categories.HOT.slice(34),['epicwin','venus','clotplay']);assert.deepEqual(loaded.ranking.categories.SLOT.slice(-2),['epicwin','clotplay']);
});
