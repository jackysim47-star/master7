import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';

// All gateway responses are synthetic. This suite never contacts VPay or moves real funds.
const origin='https://portal.example.test';
const gateway='https://master7-integration-gateway.onrender.com';
const payoutToken='maintenance-payout-token-'.padEnd(40,'p');
const callbackToken='maintenance-callback-token-'.padEnd(40,'c');
const dataKey='maintenance-withdrawal-key-'.padEnd(40,'w');

function fixture(t){
 const sql=new DatabaseSync(':memory:');
 sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf-alice',0),('owner','owner','owner',1,'csrf-owner',0);INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,last_authorization_id,created_at,updated_at) VALUES('alice','passed','passed',1,'review-1',NULL,0,0);UPDATE payment_channel_controls SET status='active' WHERE provider_id='vpay';INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fund','alice','funding-request','f','vpay',10000,'MYR','2','credited',0,0);INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('member','fund','alice','member',10000,'MYR',0),('clearing','fund','alice','provider_clearing',-10000,'MYR',0)");
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const results=statements.map(statement=>sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return results;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={submits:0,queries:0,payoutState:'1'};
 const config={db,identity:{userId:'alice',email:'alice@example.test'},ownerEmail:'',allowedOrigins:[origin],newPayoutsEnabled:'true',withdrawalDataKey:dataKey,vpayGatewayUrl:gateway,vpayPayoutToken:payoutToken,vpayCallbackToken:callbackToken,vpayPayoutEnabled:'true',vpayTraderId:'3647',vpayFetch:async(input,init)=>{
  const url=new URL(String(input)),body=JSON.parse(init.body);
  assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+payoutToken);
  if(url.pathname==='/platform/vpay/withdrawal'){
   state.submits++;
   return Response.json({provider:'vpay',upstreamStatus:200,result:{code:0,data:{money_id:'provider_123',out_money_id:body.refId}}});
  }
  assert.equal(url.pathname,'/platform/vpay/withdrawal-query');
  state.queries++;
  return Response.json({provider:'vpay',upstreamStatus:200,result:{code:0,data:{out_money_id:body.outMoneyId,state:state.payoutState,amount:'20.00',service_fee:'0.50'}}});
 }};
 async function call(path,{who='alice',method='GET',data,headers={},extra={}}={}){
  const identity=who?{userId:who,email:who+'@example.test'}:null;
  const response=await handle(new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+(who??'alice'),...headers},...(data===undefined?{}:{body:JSON.stringify(data)})}),{...config,identity,...extra});
  return {status:response.status,data:response.headers.get('content-type')?.includes('json')?await response.json():await response.text()};
 }
 const payload=(requestKey='maintenance-payout-request-0001')=>({providerId:'vpay',bankCode:'maybank',accountHolder:'Alice Example',accountNumber:'1234-5678-9012',amount:'20.00',requestKey});
 async function createPending(){state.payoutState='1';const result=await call('/api/withdrawals',{method:'POST',data:payload()});assert.equal(result.status,201);assert.equal(result.data.status,'pending');assert.equal(state.submits,0);return result;}
 async function approvePending(){const list=await call('/api/admin/withdrawals',{who:'owner'}),item=list.data.items[0];assert.equal(list.status,200);assert.equal(item.approvalEligible,true);assert.match(item.approvalFingerprint,/^[a-f0-9]{64}$/);const result=await call('/api/admin/withdrawals/approve',{who:'owner',method:'POST',data:{id:item.id,ownerNote:'Maintenance acceptance fixture',approvalFingerprint:item.approvalFingerprint}});assert.equal(result.status,202);assert.equal(result.data.withdrawal.status,'processing');assert.equal(state.submits,1);return result;}
 async function createInFlight(){await createPending();await approvePending();assert.equal(sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(sql.prepare('SELECT status FROM provider_payouts').get().status,'processing');}
 async function callback(){const payout=sql.prepare("SELECT id FROM provider_payouts WHERE provider_id='vpay'").get();return call('/api/payment-callbacks/vpay/withdrawal',{method:'POST',headers:{Authorization:'Bearer '+callbackToken},data:{trader_id:'3647',money_id:'provider_123',out_money_id:payout.id,state:state.payoutState,amount:'20.00',notify_time:'2026-11-08 12:00:00'},extra:{identity:null}});}
 t.after(()=>sql.close());
 return {sql,state,config,call,payload,createPending,approvePending,createInFlight,callback};
}

test('payout maintenance rejects a new request before provider submission or database creation',async t=>{
 const f=fixture(t);f.config.newPayoutsEnabled='false';
 const before={withdrawals:f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,payouts:f.sql.prepare('SELECT COUNT(*) n FROM provider_payouts').get().n};
 const result=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});
 assert.equal(result.status,503);assert.match(result.data.error,/temporarily paused|not connected/i);
 assert.equal(f.state.submits,0);assert.equal(f.state.queries,0);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,before.withdrawals);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM provider_payouts').get().n,before.payouts);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
});

test('payout maintenance prevents owner approval from turning a reviewed request into a provider submission',async t=>{
 const f=fixture(t);await f.createPending();f.config.newPayoutsEnabled='false';
 const list=await f.call('/api/admin/withdrawals',{who:'owner'}),item=list.data.items[0];assert.equal(list.status,200);assert.equal(item.approvalEligible,true);
 const result=await f.call('/api/admin/withdrawals/approve',{who:'owner',method:'POST',data:{id:item.id,ownerNote:'Must remain held',approvalFingerprint:item.approvalFingerprint}});
 assert.equal(result.status,503);assert.match(result.data.error,/provider unavailable/i);assert.equal(f.state.submits,0);assert.equal(f.state.queries,0);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'pending');assert.deepEqual({...f.sql.prepare('SELECT status,create_outcome FROM provider_payouts').get()},{status:'prepared',create_outcome:'not_submitted'});
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await f.call('/api/wallet')).data.availableMinor,'8000');
});

test('maintenance leaves an existing payout record queryable and its verified callback idempotent',async t=>{
 const f=fixture(t);await f.createInFlight();const payoutId=f.sql.prepare('SELECT id FROM provider_payouts').get().id;
 f.config.newPayoutsEnabled='false';
 const listed=await f.call('/api/withdrawals');assert.equal(listed.status,200);assert.equal(listed.data.items.length,1);assert.equal(listed.data.items[0].status,'processing');
 const status=await f.call('/api/payment-callbacks/vpay/withdrawal',{extra:{identity:null}});assert.equal(status.status,200);assert.equal(status.data.active,true);
 const blocked=await f.call('/api/withdrawals',{method:'POST',data:f.payload('maintenance-payout-request-0002')});assert.equal(blocked.status,503);assert.equal(f.state.submits,1);
 f.state.payoutState='3';const first=await f.callback(),second=await f.callback();assert.equal(first.status,200);assert.equal(second.status,200);
 assert.deepEqual({...f.sql.prepare('SELECT id,status FROM provider_payouts').get()},{id:payoutId,status:'succeeded'});
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_payout_paid'").get().n,1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});

test('maintenance recovery queries an existing payout once without resubmitting or duplicating settlement',async t=>{
 const f=fixture(t);await f.createInFlight();f.config.newPayoutsEnabled='false';f.state.payoutState='3';
 const token='maintenance-recovery-token-'.padEnd(40,'r'),beforeQueries=f.state.queries;
 const first=await f.call('/api/internal/payment-recovery',{method:'POST',headers:{authorization:'Bearer '+token},extra:{identity:null,paymentRecoveryToken:token}});
 assert.equal(first.status,200);assert.equal(first.data.payouts.vpay.enabled,true);assert.equal(first.data.payouts.vpay.queried,1);assert.equal(first.data.payouts.vpay.succeeded,1);
 assert.equal(first.data.newOrdersChanged,false);assert.equal(first.data.payoutsSubmitted,false);assert.equal(f.state.submits,1);assert.equal(f.state.queries,beforeQueries+1);
 const second=await f.call('/api/internal/payment-recovery',{method:'POST',headers:{authorization:'Bearer '+token},extra:{identity:null,paymentRecoveryToken:token}});
 assert.equal(second.status,200);assert.equal(second.data.payouts.vpay.queried,0);assert.equal(f.state.submits,1);assert.equal(f.state.queries,beforeQueries+1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM provider_payouts').get().n,1);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'succeeded');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_payout_paid'").get().n,1);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});
