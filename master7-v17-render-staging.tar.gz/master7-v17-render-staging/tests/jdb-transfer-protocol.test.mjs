import assert from 'node:assert/strict';
import test from 'node:test';
import {createDecipheriv} from 'node:crypto';
import {createJdbProtocolClient, encryptJdbPayload, jdbPlayerId, jdbSerialNo} from '../lib/jdb-transfer-protocol.ts';

const config = Object.freeze({profile:'jdb_myr',baseUrl:'https://provider.example.test',dc:'fixture',parent:'agent01',aesKey:'key1234567Sample',aesIv:'iv12345678Sample',padding:'zero',launchOrigins:['https://games.example.test'],reportUtcOffsetMinutes:480});
const now = Date.UTC(2026,10,8,12,0,0);
const user = jdbPlayerId('jdb_myr','member-1');
const transfer = Object.freeze({playerId:user,serialNo:jdbSerialNo('jdb_myr','order-123','deposit'),direction:'deposit',amountMinor:'12345'});

function decrypt(value, cfg = config){
 const decipher = createDecipheriv('aes-128-cbc',Buffer.from(cfg.aesKey),Buffer.from(cfg.aesIv));
 decipher.setAutoPadding(false);
 return JSON.parse(Buffer.concat([decipher.update(Buffer.from(value,'base64url')),decipher.final()]).toString('utf8').replace(/[\0 ]+$/,''));
}
function fixture(handler, cfg = config){
 const calls=[];
 const transport=async(url,init)=>{
  const envelope=JSON.parse(init.body), payload=decrypt(envelope.x,config);
  calls.push({url,init,envelope,payload});
  return handler(payload,calls.length);
 };
 return {client:createJdbProtocolClient(cfg,transport,()=>now),calls};
}
const ok = value => Response.json({status:'0000',...value});
const row = changes => ({uid:user,parent:'agent01',currency:'RM',lvl:0,locked:0,closed:0,balance:12.345,...changes});

test('official zero-padding vector and documented space padding remain distinct and explicit',()=>{
 assert.equal(encryptJdbPayload('SampleData',config.aesKey,config.aesIv,'zero'),'GhKRVa6BHoOJAhjVYMKuFw');
 assert.equal(encryptJdbPayload('SampleData',config.aesKey,config.aesIv,'space'),'xa--LwmZQjlxNJdFOm_-Xg');
 assert.throws(()=>encryptJdbPayload('SampleData',config.aesKey,config.aesIv,undefined),/invalid_configuration/);
});

test('profile identities and transaction serials are deterministic, independent and JDB compatible',()=>{
 assert.match(user,/^[a-z0-9_-]{1,50}$/);
 assert.notEqual(user,jdbPlayerId('spribe_myr','member-1'));
 assert.equal(user,jdbPlayerId('jdb_myr','member-1'));
 assert.match(transfer.serialNo,/^[A-Za-z0-9]{1,50}$/);
 assert.notEqual(transfer.serialNo,jdbSerialNo('spribe_myr','order-123','deposit'));
 assert.notEqual(transfer.serialNo,jdbSerialNo('jdb_myr','order-123','withdraw'));
 assert.equal(transfer.serialNo,jdbSerialNo('jdb_myr','order-123','deposit'));
});

test('configuration validates HTTPS, AES and explicit padding before any network call',()=>{
 let calls=0;const transport=async()=>{calls++;return ok({});};
 for(const invalid of [{...config,baseUrl:'http://provider.example.test'}, {...config,baseUrl:'https://user:pass@provider.example.test'}, {...config,baseUrl:'https://provider.example.test/path'}, {...config,aesKey:'short'}, {...config,aesKey:undefined}, {...config,padding:undefined}, {...config,envelopeParent:'bad value'}])
  assert.throws(()=>createJdbProtocolClient(invalid,transport,()=>now),/invalid_configuration/);
 assert.equal(calls,0);
});

test('catalogue sends the documented encrypted Action 49 and missing maintenance fails closed',async()=>{
 const f=fixture(()=>ok({data:[{gType:0,list:[{mType:100,name:'Slot',maintenance:false},{mtype:'101',name:'Unknown'}]}]}));
 assert.deepEqual(await f.client.listGames(),[{providerGameId:'0:100',name:'Slot',maintenance:false},{providerGameId:'0:101',name:'Unknown',maintenance:true}]);
 assert.equal(f.calls.length,1);
 assert.equal(f.calls[0].url,'https://provider.example.test/apiRequest.do');
 assert.equal(f.calls[0].init.method,'POST');assert.equal(f.calls[0].init.redirect,'error');
 assert.deepEqual(f.calls[0].payload,{action:49,ts:now,parent:'agent01',lang:'en'});
 assert.equal(f.calls[0].envelope.dc,'fixture');
 assert.ok(!f.calls[0].init.body.includes(config.aesKey));
});

test('catalogue rejects duplicates, malformed data and oversized provider replies',async()=>{
 const variants=[{data:[{gType:0,list:[{mType:1,name:'A',maintenance:false},{mType:1,name:'B',maintenance:false}]}]}, {data:[{gType:0,list:[{mType:1,name:'A',maintenance:'false'}]}]}];
 for(const variant of variants)await assert.rejects(fixture(()=>ok(variant)).client.listGames(),/invalid_provider_response/);
 const f=fixture(()=>new Response('x'.repeat(2*1024*1024+1),{headers:{'content-type':'application/json'}}));
 await assert.rejects(f.client.listGames(),/invalid_provider_response/);
});

test('create-player response never treats an existing or timed-out player as verified',async()=>{
 for(const [handler,state] of [[()=>ok({}),'created'],[()=>Response.json({status:'7602',err_text:'private'}),'exists_unverified'],[()=>{throw new Error('private');},'unknown']]){
  const f=fixture(handler);assert.deepEqual(await f.client.createPlayer(user),{state});assert.equal(f.calls.length,1);
  assert.equal(f.calls[0].payload.action,12);assert.equal(f.calls[0].payload.uid,user);assert.equal(f.calls[0].payload.credit_allocated,0);
 }
});

test('player lookup requires matching parent, identity, level and RM currency and exposes sub-cent residual',async()=>{
 const f=fixture(()=>ok({data:[row()]}));
 assert.deepEqual(await f.client.verifyPlayer(user),{playerId:user,currency:'MYR',amountMinor:'1234',residual:true,providerAmount:'12.345',active:true});
 for(const changes of [{uid:'another'},{parent:'other'},{currency:'RMC'},{currency:'MYR'},{lvl:1},{locked:'0'},{closed:null}])
  await assert.rejects(fixture(()=>ok({data:[row(changes)]})).client.verifyPlayer(user),/player_identity_mismatch/);
 const locked=await fixture(()=>ok({data:[row({locked:1,balance:0})]})).client.verifyPlayer(user);assert.equal(locked.active,false);
});

test('launch requires an approved HTTPS origin and a valid game, and does not leak provider errors',async()=>{
 const f=fixture(()=>ok({path:'https://games.example.test/play?ticket=fixture'}));
 assert.deepEqual(await f.client.launch(user,'7:7001','zh','https://portal.example.test/lobby'),{launchUrl:'https://games.example.test/play?ticket=fixture'});
 assert.deepEqual(f.calls[0].payload,{action:11,ts:now,uid:user,lang:'cn',gType:'7',mType:'7001',windowMode:'2',lobbyURL:'https://portal.example.test/lobby'});
 await assert.rejects(f.client.launch(user,'bad','en','https://portal.example.test/lobby'),/invalid_launch/);
 assert.equal(f.calls.length,1);
 for(const path of ['http://games.example.test/play','https://other.example.test/play','https://user:pass@games.example.test/'])
  await assert.rejects(fixture(()=>ok({path})).client.launch(user,'0:1','en','https://portal.example.test/lobby'),/invalid_provider_response/);
});

test('a transfer sends the stable serial once, validates its receipt and does not post a wallet credit',async()=>{
 const f=fixture(()=>ok({serialNo:transfer.serialNo,amount:123.45,pid:1234,err_text:'private'}));
 const result=await f.client.transfer(transfer);
 assert.deepEqual(result,{state:'matched',providerTransactionId:'1234',requiresLedgerReconciliation:true});
 assert.equal(f.calls.length,1);assert.equal(f.calls[0].payload.action,19);assert.equal(f.calls[0].payload.amount,123.45);assert.equal(f.calls[0].payload.uid,user);assert.equal(f.calls[0].payload.serialNo,transfer.serialNo);
 assert.ok(!JSON.stringify(result).includes('private'));
 const withdrawal={...transfer,direction:'withdraw',serialNo:'withdraw1'};
 const w=fixture(()=>ok({serialNo:'withdraw1',amount:-123.45,pid:1235}));
 assert.equal((await w.client.transfer(withdrawal)).state,'matched');assert.equal(w.calls[0].payload.amount,-123.45);
});

test('timeout, duplicate, in-progress and malformed receipts remain unknown without retries',async()=>{
 for(const handler of [()=>{throw new Error('sensitive upstream');},()=>Response.json({status:'6005'}),()=>Response.json({status:'6012'}),()=>ok({serialNo:'different',amount:123.45,pid:1}),()=>ok({serialNo:transfer.serialNo,amount:123.451,pid:1}),()=>ok({serialNo:transfer.serialNo,amount:-123.45,pid:1}),()=>ok({serialNo:transfer.serialNo,amount:123.45,pid:9007199254740992}),()=>new Response('private',{status:502})]){
  const f=fixture(handler),result=await f.client.transfer(transfer);assert.equal(result.state,'unknown');assert.equal(f.calls.length,1);assert.ok(!JSON.stringify(result).includes('sensitive'));
 }
 for(const code of ['6009','6010','6901'])assert.deepEqual(await fixture(()=>Response.json({status:code})).client.transfer(transfer),{state:'rejected',providerCode:code,requiresLedgerReconciliation:true});
});

test('transfer recovery requires one row matching the player, direction and exact amount',async()=>{
 const match={uid:user,action:'deposit',amount:123.45,pid:4201};
 const f=fixture(()=>ok({data:[match]}));
 assert.deepEqual(await f.client.queryTransfer(transfer),{state:'matched',providerTransactionId:'4201',requiresLedgerReconciliation:true});
 assert.deepEqual(f.calls[0].payload,{action:55,ts:now,parent:'agent01',serialNo:transfer.serialNo});
 for(const data of [[],[match,match],[{...match,uid:'other'}],[{...match,action:'withdraw'}],[{...match,amount:1}],[{...match,amount:123.451}],[{...match,pid:null}]])
  assert.equal((await fixture(()=>ok({data})).client.queryTransfer(transfer)).state,'unknown');
 for(const status of ['6012','9015'])assert.equal((await fixture(()=>Response.json({status})).client.queryTransfer(transfer)).state,'unknown');
});

test('invalid transfer inputs are rejected before transmission',async()=>{
 const f=fixture(()=>{throw new Error('must not call');});
 for(const input of [{...transfer,amountMinor:'0'},{...transfer,amountMinor:'1.01'},{...transfer,amountMinor:'100000000000'},{...transfer,serialNo:'bad-id'},{...transfer,playerId:'OTHER!'}])
  await assert.rejects(f.client.transfer(input));
 assert.equal(f.calls.length,0);
});

test('report actions enforce vendor windows and preserve provider IDs and decimal values',async()=>{
 const record={historyId:'history-1',playerId:user,gType:0,mtype:14093,roundSeqNo:'round-a',gameDate:'08-11-2026 19:50:00',lastModifyTime:'08-11-2026 19:51:00',bet:'-1.235',win:'2.100',total:'0.865',currency:'RM'};
 const f=fixture(()=>ok({data:[record]}));
 const recent=await f.client.fetchWagers('recent',now-10*60_000,now-9*60_000);
 assert.equal(recent.complete,false);assert.equal(recent.timeBasis,'lastModifyTime');assert.equal(recent.records[0].historyId,'history-1');assert.equal(recent.records[0].bet,'-1.235');assert.equal(recent.records[0].providerGameId,'0:14093');
 assert.deepEqual(f.calls[0].payload,{action:29,ts:now,parent:'agent01',starttime:'08-11-2026 19:50:00',endtime:'08-11-2026 19:51:00'});
 const older=await f.client.fetchWagers('old',now-90*60_000,now-89*60_000);assert.equal(older.timeBasis,'gameDate');assert.equal(f.calls[1].payload.action,64);
 await assert.rejects(f.client.fetchWagers('recent',now-2*60_000,now-60_000),/invalid_report_window/);
 await assert.rejects(f.client.fetchWagers('old',now-50*60_000,now-49*60_000),/invalid_report_window/);
 await assert.rejects(f.client.fetchWagers('old',now-90*60_000,now-84*60_000),/invalid_report_window/);
 assert.equal(f.calls.length,2);
});

test('unconfirmed report timezone and foreign or malformed report rows fail closed',async()=>{
 const f=fixture(()=>ok({data:[]}),{...config,reportUtcOffsetMinutes:undefined});
 await assert.rejects(f.client.fetchWagers('recent',now-10*60_000,now-9*60_000),/invalid_report_window/);assert.equal(f.calls.length,0);
 const foreign={historyId:'1',playerId:user,gType:0,mtype:1,gameDate:'08-11-2026 19:50:00',lastModifyTime:'08-11-2026 19:50:00',bet:1,win:0,total:-1,currency:'RMC'};
 await assert.rejects(fixture(()=>ok({data:[foreign]})).client.fetchWagers('recent',now-10*60_000,now-9*60_000),/invalid_provider_response/);
});

test('configuration is snapshotted so another profile cannot replace credentials after construction',async()=>{
 const mutable={...config,launchOrigins:[...config.launchOrigins]},f=fixture(()=>ok({data:[]}),mutable);
 mutable.parent='another';mutable.aesKey='differentKey1234';mutable.launchOrigins.push('https://other.example.test');
 await f.client.listGames();assert.equal(f.calls[0].payload.parent,'agent01');
});
