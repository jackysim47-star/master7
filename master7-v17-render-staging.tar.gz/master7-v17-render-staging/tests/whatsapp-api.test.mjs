import test from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {handle} from '../lib/backend.ts';

const migrations=['0000_broken_bloodscream.sql','0001_orange_owl.sql','0002_lobby_ads.sql','0003_game_visibility.sql','0004_sponsored_brands.sql','0005_custom_game_cards.sql','0006_malaysia_member_phone.sql','0007_vpay_uat_wallet.sql','0008_member_sms_otp.sql','0009_game_payment_statuses.sql','0010_game_visibility_artwork.sql','0011_provider_artwork.sql','0012_close_defaults_and_brand_directory.sql','0013_api_supplier_artwork.sql','0014_withdrawal_requests.sql','0019_game_catalogue_sync.sql','0020_manual_bank_deposits.sql','0021_api_supplier_status.sql','0022_referrals.sql','0023_marketing_campaigns.sql','0024_megah5_transfer_wallet.sql','0025_game_access_zones.sql','0027_marketing_contact_scale.sql','0090_security_wallet_reservations.sql','0091_operations_automation.sql','0092_support_marketing_notifications.sql','0093_reward_state_machines.sql','0094_payment_recovery_and_payout_state.sql','0100_whatsapp_campaign_delivery.sql'];

class Statement{
 constructor(database,sql,args=[]){this.database=database;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.database,this.sql,args);}
 async first(){return this.database.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.database.prepare(this.sql).all(...this.args)};}
 async run(){return this.database.prepare(this.sql).run(...this.args);}
 execute(){const statement=this.database.prepare(this.sql);if(/\bRETURNING\b/i.test(this.sql)){const results=statement.all(...this.args);return {results,success:true,meta:{changes:results.length}};}const result=statement.run(...this.args);return {results:[],success:true,meta:{changes:Number(result.changes)}};}
}

function fixture(){
 const directory=mkdtempSync(join(tmpdir(),'master7-whatsapp-api-')),sqlite=new DatabaseSync(join(directory,'test.sqlite'));
 for(const migration of migrations)sqlite.exec(readFileSync(new URL(`../drizzle/${migration}`,import.meta.url),'utf8'));
 sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner@example.test','owner',1,'owner-csrf',1)").run();
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(statements){sqlite.exec('BEGIN');try{const result=statements.map(statement=>statement.execute());sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 return {directory,sqlite,db,close(){sqlite.close();rmSync(directory,{recursive:true,force:true});}};
}

const provider={
 whatsappEnabled:'true',
 whatsappGraphApiVersion:'v27.0',
 whatsappPhoneNumberId:'123456789012345',
 whatsappWabaId:'987654321098765',
 whatsappAccessToken:'EAA'+'.'.repeat(64),
 whatsappAppSecret:'a'.repeat(32),
 whatsappWebhookVerifyToken:'verify-token-'+('x'.repeat(32)),
 whatsappBusinessNumber:'+601166336686',
 whatsappTemplateName:'master7_launch_invitation',
 whatsappTemplateLanguage:'zh_CN',
 whatsappRecipientLimit:'1000000',
 whatsappWorkerToken:'w'.repeat(40),
 whatsappWorkerBatchSize:'10'
};

function context(db,extra={}){return {db,identity:null,ownerEmail:'owner@example.test',allowedOrigins:['https://portal.example.test'],...extra};}
async function responseJson(response){return {status:response.status,data:await response.json()};}
async function admin(db,path,method='GET',data,extra={}){
 const request=new Request(`https://portal.example.test${path}`,{method,headers:{'content-type':'application/json',origin:'https://portal.example.test','x-csrf-token':'owner-csrf'},...(data===undefined?{}:{body:JSON.stringify(data)})});
 return responseJson(await handle(request,{...context(db,extra),identity:{userId:'owner',email:'owner@example.test'}}));
}

test('WhatsApp API exposes only verified public and authenticated server surfaces',async t=>{
 const f=fixture();
 try{
  await t.test('webhook challenge and signed raw-body callback work without a portal session',async()=>{
   const challenge=await handle(new Request(`https://portal.example.test/api/marketing/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=${encodeURIComponent(provider.whatsappWebhookVerifyToken)}&hub.challenge=meta-challenge-123`),context(f.db,provider));
   assert.equal(challenge.status,200);assert.equal(challenge.headers.get('content-type'),'text/plain; charset=utf-8');assert.equal(await challenge.text(),'meta-challenge-123');
   const rejected=await handle(new Request('https://portal.example.test/api/marketing/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=wrong&hub.challenge=nope'),context(f.db,provider));assert.equal(rejected.status,403);
   const body=Buffer.from(JSON.stringify({object:'whatsapp_business_account',entry:[]})),signature='sha256='+createHmac('sha256',provider.whatsappAppSecret).update(body).digest('hex');
   const invalid=await handle(new Request('https://portal.example.test/api/marketing/whatsapp/webhook',{method:'POST',headers:{'content-type':'application/json','x-hub-signature-256':'sha256='+'0'.repeat(64)},body}),context(f.db,provider));assert.equal(invalid.status,401);
   const accepted=await responseJson(await handle(new Request('https://portal.example.test/api/marketing/whatsapp/webhook',{method:'POST',headers:{'content-type':'application/json','x-hub-signature-256':signature},body}),context(f.db,provider)));assert.equal(accepted.status,200);assert.deepEqual(accepted.data,{status:'ok',statuses:0,optOuts:0,duplicates:0});
  });

  await t.test('internal dispatcher requires its independent bearer token',async()=>{
   const request=authorization=>new Request('https://portal.example.test/api/internal/whatsapp-dispatch',{method:'POST',headers:{authorization}});
   assert.equal((await handle(request('Bearer wrong'),context(f.db,provider))).status,401);
   const accepted=await responseJson(await handle(request(`Bearer ${provider.whatsappWorkerToken}`),context(f.db,provider)));assert.equal(accepted.status,200);assert.deepEqual(accepted.data,{status:'ok',claimed:0,sent:0,retried:0,unknown:0,failed:0,optedOut:0});
  });

  await t.test('a business phone number alone remains blocked and admin status never returns secrets',async()=>{
   const value=await admin(f.db,'/api/admin/marketing','GET',undefined,{whatsappBusinessNumber:'+601166336686'});assert.equal(value.status,200);assert.equal(value.data.providerReady,false);assert.equal(value.data.launchEnabled,false);assert.equal(value.data.maximumContacts,1_000_000);assert.equal(value.data.whatsapp.businessNumber,'+601166336686');assert.ok(value.data.whatsapp.blockers.includes('configuration_incomplete'));
   const serialized=JSON.stringify(value.data);for(const secret of [provider.whatsappAccessToken,provider.whatsappAppSecret,provider.whatsappWebhookVerifyToken,provider.whatsappWorkerToken])assert.ok(!serialized.includes(secret));
  });

  await t.test('an opted-in import without explicit consent source and proof is rejected',async()=>{
   const result=await admin(f.db,'/api/admin/marketing','POST',{action:'import',source:'phone-only.csv',contacts:[{phone:'+60119998888',consent:true}]});assert.equal(result.status,400);assert.match(result.data.error,/Consent source and proof/);assert.equal(f.sqlite.prepare("SELECT COUNT(*) count FROM marketing_contacts WHERE phone='+60119998888'").get().count,0);
  });

  await t.test('configured approved-template campaign queues verified consent only',async()=>{
   f.sqlite.prepare("INSERT INTO marketing_contacts(id,phone,name,consent_status,source,consented_at,consent_source,consent_proof,unsubscribe_token,created_at,updated_at) VALUES('verified','+60111111111','','opted_in','registration',1,'signed_form','proof-001','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',1,1)").run();
   f.sqlite.prepare("INSERT INTO marketing_contacts(id,phone,name,consent_status,source,consented_at,consent_source,consent_proof,unsubscribe_token,created_at,updated_at) VALUES('unknown','+60112222222','','unknown','csv',NULL,'','','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',1,1)").run();
   const saved=await admin(f.db,'/api/admin/marketing','POST',{action:'save',name:'Launch invitation',channel:'whatsapp',message:'Welcome to MASTER7',benefitText:'Launch benefit',retentionGoal:18000,sendRatePerMinute:30},provider);assert.equal(saved.status,201);assert.equal(saved.data.campaignStatus,'ready');assert.equal(saved.data.providerReady,true);
   const campaign=f.sqlite.prepare("SELECT id,template_name,template_language,status FROM marketing_campaigns WHERE name='Launch invitation'").get();assert.equal(campaign.template_name,provider.whatsappTemplateName);assert.equal(campaign.template_language,provider.whatsappTemplateLanguage);assert.equal(campaign.status,'ready');
   const launched=await admin(f.db,'/api/admin/marketing','POST',{action:'launch',id:campaign.id},provider);assert.equal(launched.status,200);assert.equal(launched.data.status,'sending');assert.equal(launched.data.audience,1);assert.equal(launched.data.recipientLimit,1_000_000);
   assert.deepEqual(f.sqlite.prepare('SELECT contact_id,status FROM marketing_deliveries WHERE campaign_id=?').all(campaign.id).map(row=>({...row})),[{contact_id:'verified',status:'queued'}]);
   const status=await admin(f.db,'/api/admin/marketing','GET',undefined,provider);assert.equal(status.data.providerReady,true);assert.equal(status.data.campaigns.find(item=>item.id===campaign.id).queued_count,1);const serialized=JSON.stringify(status.data);for(const secret of [provider.whatsappAccessToken,provider.whatsappAppSecret,provider.whatsappWebhookVerifyToken,provider.whatsappWorkerToken])assert.ok(!serialized.includes(secret));
  });
 }finally{f.close();}
});
