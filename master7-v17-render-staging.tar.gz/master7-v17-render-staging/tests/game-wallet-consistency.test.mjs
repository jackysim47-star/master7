import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {genericGameWalletConsistency,genericGameWalletConsistencyForUsers} from '../lib/game-wallet-consistency.ts';
import {walletGuardStatements,walletGuardedReservation,walletGuardedRiskCheck} from '../lib/wallet-guard.ts';
import {withdrawalWalletState,clearStaleReservation,hasProtectedGameReservation} from '../lib/withdrawals.ts';
import {adminProfileGameWallets} from '../lib/game-wallet-records.ts';
import {handleVPay} from '../lib/vpay.ts';
import {seedWalletMembers,seedGenericSession,seedGenericPosting} from './fixtures/game-wallet-consistency.mjs';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}
async function fixture(t){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');t.after(()=>sqlite.close());
 const dir=new URL('../drizzle/',import.meta.url);for(const file of readdirSync(dir).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,dir),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(items){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const item of items)results.push(await item.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 await seedWalletMembers(db);return {sqlite,db};
}
async function assertBlocked(db,user='alice'){
 const wallet=await withdrawalWalletState(db,user);assert.equal(wallet.balanceMinor,'10000');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 const result=await db.batch([...walletGuardStatements(db,user),walletGuardedRiskCheck(db,user),walletGuardedReservation(db,{userId:user,kind:'withdrawal',referenceId:'new-withdraw-'+user,amountMinor:'100',createdAt:1})]);
 assert.equal(Number(result[2].changes),0);assert.equal(Number(result[3].changes),0);assert.equal(await hasProtectedGameReservation(db,user),true);
}

test('consistent pending game remains held and blocks a second commitment without manufacturing a ledger problem',async t=>{
 const {db}=await fixture(t);await seedGenericSession(db);
 assert.deepEqual(await genericGameWalletConsistency(db,'alice'),{sessionMismatch:false,transferMismatch:false,unprojectedPosting:false,reconciliationRequired:false});
 const wallet=await withdrawalWalletState(db,'alice');assert.equal(wallet.availableMinor,'6000');assert.equal(wallet.gameHeldMinor,'4000');assert.equal(wallet.reconciliationRequired,undefined);
 const r=await db.batch([...walletGuardStatements(db,'alice'),walletGuardedRiskCheck(db,'alice'),walletGuardedReservation(db,{userId:'alice',kind:'withdrawal',referenceId:'new',amountMinor:'100',createdAt:1})]);assert.equal(Number(r[2].changes),1);assert.equal(Number(r[3].changes),0);
});

for(const status of ['failed','settled'])for(const transferStatus of ['unknown','submitting','succeeded'])test(`${status} session cannot release ${transferStatus} supplier funds`,async t=>{
 const {db}=await fixture(t);await seedGenericSession(db,{status,transferStatus,reserved:null,closedAt:3});await assertBlocked(db);
 assert.equal((await withdrawalWalletState(db,'bob')).availableMinor,'10000');
});

test('a session marked closed while its reservation remains requires reconciliation',async t=>{
 const {db}=await fixture(t);await seedGenericSession(db,{status:'failed',transferStatus:'failed'});await assertBlocked(db);
});
test('the held amount must match all pending or confirmed deposit principal',async t=>{
 const {db}=await fixture(t);await seedGenericSession(db,{reserved:'1'});await assertBlocked(db);assert.equal((await withdrawalWalletState(db,'alice')).gameHeldMinor,'1');
});
test('a wrong reservation owner blocks both affected members and leaves unrelated balances available',async t=>{
 const {db}=await fixture(t);await seedGenericSession(db,{reservationUser:'bob'});await assertBlocked(db,'alice');await assertBlocked(db,'bob');
 assert.equal((await withdrawalWalletState(db,'charlie')).availableMinor,'10000');
});
test('player identity, player review and profile currency mismatches are not treated as a valid held session',async t=>{
 for(const change of ['player','review','currency'])await t.test(change,async sub=>{
  const {db,sqlite}=await fixture(sub);await seedGenericSession(db,change==='player'?{playerId:'different-player'}:{});
  if(change==='review')sqlite.exec("UPDATE game_provider_players SET status='review' WHERE profile_id='jdb_myr' AND user_id='alice'");
  if(change==='currency')sqlite.exec("UPDATE game_provider_profiles SET currency='MY1' WHERE id='jdb_myr'");
  await assertBlocked(db);
 });
});
for(const [status,attempts,completedAt] of [['prepared',1,null],['unknown',0,null],['submitting',0,null],['succeeded',1,null],['failed',1,null]])test(`transfer status ${status}, attempts ${attempts}, completed ${completedAt} cannot look reconciled`,async t=>{
 const {db}=await fixture(t);await seedGenericSession(db,{transferStatus:status,attempts,completedAt});await assertBlocked(db);
});
test('active sessions require a funded deposit and withdrawal attempts require a prior succeeded deposit',async t=>{
 const {db}=await fixture(t);await seedGenericSession(db,{status:'active',noTransfer:true});await assertBlocked(db);
 const second=await fixture(t);await seedGenericSession(second.db,{direction:'withdrawal'});await assertBlocked(second.db);
});
test('a properly rejected transfer or an unfunded historical closed session does not freeze clean money',async t=>{
 const {db}=await fixture(t);await seedGenericSession(db,{status:'failed',transferStatus:'failed',reserved:null,closedAt:3});
 let wallet=await withdrawalWalletState(db,'alice');assert.equal(wallet.availableMinor,'10000');assert.equal(wallet.reconciliationRequired,undefined);
 await seedGenericSession(db,{id:'empty-history',status:'settled',noTransfer:true,reserved:null,user:'bob',closedAt:2});wallet=await withdrawalWalletState(db,'bob');assert.equal(wallet.availableMinor,'10000');assert.equal(wallet.reconciliationRequired,undefined);
});
test('orphaned historical transfer rows fail closed even when a foreign-key check was bypassed during import',async t=>{
 const {db,sqlite}=await fixture(t);await seedGenericSession(db,{status:'failed',reserved:null});sqlite.exec('PRAGMA foreign_keys=OFF');sqlite.exec("DELETE FROM game_provider_sessions WHERE id='session-one'");sqlite.exec('PRAGMA foreign_keys=ON');await assertBlocked(db);
});
for(const legs of ['none','partial','balanced'])test(`generic ${legs} postings cannot be silently ignored by the current cash projection`,async t=>{
 const {db}=await fixture(t);const session=await seedGenericSession(db,{status:'settled',reserved:null,noTransfer:true,closedAt:2});await seedGenericPosting(db,session,{legs});await assertBlocked(db);assert.equal((await genericGameWalletConsistency(db,'alice')).unprojectedPosting,true);
});
test('a rejected unposted generic event is not an applied cash movement',async t=>{
 const {db}=await fixture(t);const session=await seedGenericSession(db,{status:'settled',reserved:null,noTransfer:true,closedAt:2});await seedGenericPosting(db,session,{status:'rejected',legs:'none'});assert.equal((await withdrawalWalletState(db,'alice')).availableMinor,'10000');
});
test('automatic stale-hold cleanup cannot discard a reservation while another generic movement is unresolved',async t=>{
 const {db,sqlite}=await fixture(t);await seedGenericSession(db,{status:'failed',reserved:null});
 sqlite.exec("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('old-failed','alice','megah5','legacy-player','1','deposit_failed',2000,'old-deposit',0,0); INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('alice','game','old-failed',2000,0)");
 await clearStaleReservation(db,'alice');assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE user_id='alice'").get().n,1);await assertBlocked(db);
});
test('clean legacy failed holds still clear under the existing policy',async t=>{
 const {db,sqlite}=await fixture(t);sqlite.exec("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('old-failed','alice','megah5','legacy-player','1','deposit_failed',2000,'old-deposit',0,0); INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('alice','game','old-failed',2000,0)");
 await clearStaleReservation(db,'alice');assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await withdrawalWalletState(db,'alice')).availableMinor,'10000');
});
test('admin inspection exposes review flags without repairing money or mixing profiles',async t=>{
 const {db,sqlite}=await fixture(t);await seedGenericSession(db,{status:'failed',reserved:null});const before=sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n;
 const report=await adminProfileGameWallets(db);assert.equal(report.readOnly,true);assert.equal(report.profileItems[0].consistency.reconciliationRequired,true);assert.equal(report.profileItems[0].profileId,'jdb_myr');assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,before);
 const batch=await genericGameWalletConsistencyForUsers(db,['alice','alice','bob']);assert.equal(batch.size,2);assert.equal(batch.get('bob').reconciliationRequired,false);
});
test('missing or malformed database assessments fail closed rather than returning clean flags',async()=>{
 for(const row of [null,{}, {session_mismatch:0,transfer_mismatch:'not-a-flag',unprojected_posting:0}])await assert.rejects(genericGameWalletConsistency({prepare:()=>({bind:()=>({first:async()=>row})})},'alice'),/unavailable/);
 await assert.rejects(genericGameWalletConsistencyForUsers({},Array.from({length:501},(_,i)=>'user-'+i)),/too large/);
});
test('existing authenticated deposit callbacks still credit once while unrelated game funds require review',async t=>{
 const {db,sqlite}=await fixture(t);await seedGenericSession(db,{status:'failed',reserved:null});
 await db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES('existing-order','alice','existing-request','fixture','vpay',2000,'MYR','bank','pending','provider-trade',0,0)").run();
 const callbackToken='c'.repeat(48),c={db,user:null,gatewayUrl:'https://master7-integration-gateway.onrender.com',orderToken:'o'.repeat(48),queryToken:'q'.repeat(48),callbackToken,mode:'uat',vpayTraderId:'fixture-trader',portalOrigins:['https://www.master7.best'],returnUrl:'https://www.master7.best/payment/return',enabled:'false',newDepositsEnabled:'false',fetchImpl:async url=>{
  assert.equal(new URL(String(url)).pathname,'/platform/vpay/order-query');return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:'existing-order',trade_no:'provider-trade',amount:'20.00',currency:'MYR',state:'3',trader_id:'fixture-trader'}}});
 }};
 for(let i=0;i<2;i++){
  const r=await handleVPay(new Request('https://www.master7.best/api/payment-callbacks/vpay/payment',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+callbackToken},body:JSON.stringify({out_trade_no:'existing-order',trade_no:'provider-trade',amount:'20.00',state:'3',trader_id:'fixture-trader'})}),c);
  assert.equal(r.status,200);assert.equal(await r.text(),'SUCCESS');
 }
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_ledger WHERE order_id='existing-order'").get().n,2);
 const wallet=await withdrawalWalletState(db,'alice');assert.equal(wallet.balanceMinor,'12000');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
});
