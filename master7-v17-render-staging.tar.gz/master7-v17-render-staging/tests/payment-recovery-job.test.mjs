import test from 'node:test';
import assert from 'node:assert/strict';
import {startPaymentRecovery} from '../scripts/payment-recovery-job.mjs';

test('payment recovery worker is inert unless explicitly enabled',async()=>{
 let calls=0;const worker=startPaymentRecovery({token:'x'.repeat(40),port:3000,vpayEnabled:false,gspayEnabled:false},async()=>{calls++;return new Response('{}');});
 await worker.run();worker.stop();assert.equal(calls,0);
});

test('payment recovery worker calls only the protected loopback endpoint',async()=>{
 const calls=[],token='r'.repeat(40),worker=startPaymentRecovery({token,port:4321,vpayEnabled:true,gspayEnabled:false,intervalMs:60000},async(url,init)=>{calls.push({url,init});return new Response('{}',{status:200});});
 await worker.run();worker.stop();assert.equal(calls.length,1);assert.equal(calls[0].url,'http://127.0.0.1:4321/api/internal/payment-recovery');assert.equal(calls[0].init.method,'POST');assert.equal(calls[0].init.headers.Authorization,`Bearer ${token}`);assert.equal(calls[0].init.redirect,'error');
});
