import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const from=source.indexOf('const withdrawalAdminControlState='),to=source.indexOf('function adminGameWalletNotice(',from);
assert.ok(from>=0&&to>from);
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.attributes={};this.textContent='';this.disabled=false;this.hidden=false;}
 append(...items){this.children.push(...items);}
 replaceChildren(...items){this.children=items;}
 setAttribute(key,value){this.attributes[key]=String(value);}
}
const node=(tag,css='',text='')=>Object.assign(new Element(tag),{className:css,textContent:text});
const descendants=el=>[el,...el.children.flatMap(descendants)];
function fixture(role='owner',lang='en'){
 const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,new Element());return nodes.get(id);};
 const eligible={id:'request-12345',username:'Member',providerName:'VPay',amountMinor:'1000',currency:'MYR',bankName:'Fixture Bank',accountHolder:'Fixture',accountNumber:'12345678',accountLast4:'5678',createdAt:1,status:'pending',approvalEligible:true,approvalFingerprint:'a'.repeat(64)};
 const state={lang,user:{id:role+'-id',role}},data={items:[eligible]},calls=[],confirmations=[],scenario={response:{status:'processing',withdrawal:{id:eligible.id,status:'processing'}},error:null,gate:null,reads:0,confirmResult:true};
 const context={state,$:get,node,clear:el=>el.replaceChildren(),moneyMinor:value=>'MYR '+value,window:{confirm:message=>{confirmations.push(message);return scenario.confirmResult;}},api:async(path,method='GET',body)=>{
  calls.push({path,method,body});
  if(method==='GET'){scenario.reads++;return data;}
  if(scenario.gate)await scenario.gate;
  if(scenario.error)throw scenario.error;
  return scenario.response;
 }};
 vm.runInNewContext(source.slice(from,to),context);
 return {context,state,data,eligible,calls,confirmations,scenario,get};
}

test('only owner sees approve for server-eligible pending records with a valid reviewed fingerprint',async()=>{
 const f=fixture();f.data.items.push({...f.eligible,id:'request-23456',approvalEligible:false},{...f.eligible,id:'request-34567',status:'processing'},{...f.eligible,id:'request-45678',approvalFingerprint:'bad'},{...f.eligible,id:'request-56789',approvalEligible:'true'});
 await f.context.renderAdminWithdrawals();const all=descendants(f.get('adminWithdrawalRecords')),buttons=all.filter(item=>item.tagName==='button');assert.equal(buttons.length,1);assert.equal(buttons[0].attributes['aria-label'],'Approve & submit payout · request-12345');
 assert.ok(all.some(item=>item.textContent.includes('Fixture Bank')&&item.textContent.includes('Fixture')&&item.textContent.includes('•••• 5678')));assert.ok(all.some(item=>item.textContent.includes('MYR 1000')));assert.ok(!all.some(item=>item.textContent.includes('12345678')));assert.ok(f.get('adminWithdrawalNotice').textContent.includes('real payout immediately'));
 const staff=fixture('staff');await staff.context.renderAdminWithdrawals();assert.equal(staff.calls.length,1);assert.equal(staff.get('adminWithdrawalPanel').hidden,false);assert.equal(descendants(staff.get('adminWithdrawalRecords')).filter(item=>item.tagName==='button').length,0);
});

test('approval stays hidden when any reviewed member, bank, masked account, amount or currency is missing',async()=>{
 for(const patch of [{username:''},{providerName:''},{bankName:''},{accountHolder:''},{accountLast4:''},{amountMinor:'0'},{amountMinor:'not-money'},{currency:'USD'},{currency:undefined}]){
  const f=fixture();Object.assign(f.eligible,patch);await f.context.renderAdminWithdrawals();assert.equal(descendants(f.get('adminWithdrawalRecords')).filter(item=>item.tagName==='button').length,0,JSON.stringify(patch));
 }
});

test('owner approval uses only the redacted response and never needs a full account number',async()=>{
 const f=fixture();delete f.eligible.accountNumber;await f.context.renderAdminWithdrawals();const all=descendants(f.get('adminWithdrawalRecords')),button=all.find(item=>item.tagName==='button');
 assert.ok(button);assert.ok(all.some(item=>item.textContent.includes('•••• 5678')));await button.onclick();
 const writes=f.calls.filter(call=>call.method==='POST');assert.equal(writes.length,1);assert.deepEqual(Object.keys(writes[0].body).sort(),['approvalFingerprint','id','ownerNote']);assert.ok(!JSON.stringify(writes[0]).includes('12345678'));
});

test('confirmation shows reviewed member, provider, bank, recipient, masked account and amount; cancel sends no request',async()=>{
 const f=fixture();f.scenario.confirmResult=false;await f.context.renderAdminWithdrawals();const button=descendants(f.get('adminWithdrawalRecords')).find(item=>item.tagName==='button');await button.onclick();
 assert.equal(f.confirmations.length,1);for(const value of ['Member','VPay','Fixture Bank','Fixture','•••• 5678','MYR 1000','real payout'])assert.ok(f.confirmations[0].includes(value),value);
 assert.ok(!f.confirmations[0].includes('12345678'));assert.equal(f.calls.filter(call=>call.method==='POST').length,0);assert.equal(button.disabled,false);
});

test('double click submits once, binds reviewed fingerprint, and does not treat review as paid',async()=>{
 const f=fixture();let release;f.scenario.gate=new Promise(resolve=>{release=resolve;});f.scenario.response={status:'review',withdrawal:{id:f.eligible.id,status:'processing'}};
 await f.context.renderAdminWithdrawals();let button=descendants(f.get('adminWithdrawalRecords')).find(item=>item.tagName==='button');const first=button.onclick();const second=button.onclick();assert.equal(button.disabled,true);release();await Promise.all([first,second]);
 const writes=f.calls.filter(call=>call.method==='POST');assert.equal(writes.length,1);assert.equal(writes[0].path,'/api/admin/withdrawals/approve');assert.equal(JSON.stringify(writes[0].body),JSON.stringify({id:f.eligible.id,ownerNote:'',approvalFingerprint:'a'.repeat(64)}));
 button=descendants(f.get('adminWithdrawalRecords')).find(item=>item.tagName==='button');assert.equal(button.disabled,true);assert.ok(descendants(f.get('adminWithdrawalRecords')).some(item=>item.textContent.includes('could not be confirmed')));
});

test('unknown response or request failure stays disabled across a refresh while still pending',async()=>{
 for(const condition of ['failure','wrong-id']){
  const f=fixture();if(condition==='failure')f.scenario.error=Error('synthetic timeout');else f.scenario.response={status:'processing',withdrawal:{id:'other-id',status:'processing'}};
  await f.context.renderAdminWithdrawals();let button=descendants(f.get('adminWithdrawalRecords')).find(item=>item.tagName==='button');await button.onclick();assert.equal(button.disabled,true);assert.ok(descendants(f.get('adminWithdrawalRecords')).some(item=>item.textContent.includes('could not be confirmed')));
  await f.context.renderAdminWithdrawals();button=descendants(f.get('adminWithdrawalRecords')).find(item=>item.tagName==='button');assert.equal(button.disabled,true);await button.onclick();assert.equal(f.calls.filter(call=>call.method==='POST').length,1);
 }
});

test('the real-payout warning and unknown-result guidance are available in all three languages',async()=>{
 for(const [lang,warning,unknown,confirmation] of [['en','real payout immediately','reconcile before trying again','real payout'],['zh','立即提交真实出款','先刷新记录并对账','真实出款'],['ms','pembayaran sebenar serta-merta','buat penyelarasan sebelum mencuba lagi','Pembayaran sebenar']]){
  const f=fixture('owner',lang);f.scenario.error=Error('synthetic timeout');await f.context.renderAdminWithdrawals();assert.ok(f.get('adminWithdrawalNotice').textContent.includes(warning));const button=descendants(f.get('adminWithdrawalRecords')).find(item=>item.tagName==='button');await button.onclick();assert.ok(descendants(f.get('adminWithdrawalRecords')).some(item=>item.textContent.includes(unknown)));
  assert.ok(f.confirmations[0].includes(confirmation));
 }
});
