import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {financeCenterReport} from '../lib/finance-center.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}

function fixture(){
 const sqlite=new DatabaseSync(':memory:');
 sqlite.exec(`
  CREATE TABLE deposit_orders(id TEXT PRIMARY KEY,user_id TEXT,provider TEXT,amount_minor INTEGER,currency TEXT,status TEXT,updated_at INTEGER);
  CREATE TABLE withdrawal_requests(id TEXT PRIMARY KEY,user_id TEXT,provider_id TEXT,amount_minor INTEGER,currency TEXT,status TEXT,updated_at INTEGER);
  CREATE TABLE wallet_ledger(id TEXT PRIMARY KEY,order_id TEXT,user_id TEXT,account_code TEXT,amount_minor INTEGER,currency TEXT,created_at INTEGER);
  CREATE TABLE company_bank_accounts(id TEXT PRIMARY KEY,enabled INTEGER,account_name TEXT,account_number TEXT);
  CREATE TABLE manual_deposit_requests(deposit_order_id TEXT PRIMARY KEY,bank_account_id TEXT,receipt_data TEXT);
  CREATE TABLE game_wallet_sessions(id TEXT PRIMARY KEY,user_id TEXT,status TEXT,amount_out_minor INTEGER,amount_returned_minor INTEGER);
  CREATE TABLE game_wallet_ledger(id TEXT PRIMARY KEY,session_id TEXT,user_id TEXT,account_code TEXT,amount_minor INTEGER,currency TEXT,created_at INTEGER);
  CREATE TABLE commission_periods(id TEXT PRIMARY KEY,basis TEXT,status TEXT,period_start INTEGER,period_end INTEGER);
  CREATE TABLE commission_entries(id TEXT PRIMARY KEY,period_id TEXT,commission_minor INTEGER);
 `);
 const db={prepare:sql=>new Statement(sqlite,sql)};
 return {sqlite,db};
}

function seed(sqlite){
 const deposit=sqlite.prepare('INSERT INTO deposit_orders VALUES(?,?,?,?,?,?,?)');
 deposit.run('d1','u1','vpay',1000,'MYR','credited',1100);
 deposit.run('d2','u2','manual_bank',2000,'MYR','credited',1200);
 deposit.run('d3','u3','manual_bank',3000,'MYR','pending',1300);
 deposit.run('d4','u4','1mpay',9000,'MYR','credited',900);
 const withdrawal=sqlite.prepare('INSERT INTO withdrawal_requests VALUES(?,?,?,?,?,?,?)');
 withdrawal.run('w1','u1','vpay',500,'MYR','paid',1400);
 withdrawal.run('w2','u2','gspay',700,'MYR','pending',1500);
 const ledger=sqlite.prepare('INSERT INTO wallet_ledger VALUES(?,?,?,?,?,?,?)');
 for(const [id,order,user,account,value] of [['l1','d1','u1','member',1000],['l2','d1','u1','provider_clearing',-1000],['l3','d2','u2','member',2000],['l4','d2','u2','provider_clearing',-2000]])ledger.run(id,order,user,account,value,'MYR',1600);
 sqlite.prepare("INSERT INTO company_bank_accounts VALUES('bank1',1,'PRIVATE NAME','99887766')").run();
 sqlite.prepare("INSERT INTO manual_deposit_requests VALUES('d2','bank1','private-receipt'),('d3','bank1','private-pending-receipt')").run();
 sqlite.prepare("INSERT INTO game_wallet_sessions VALUES('gs1','u1','settled',2000,1600)").run();
 sqlite.prepare("INSERT INTO game_wallet_ledger VALUES('g1','gs1','u1','game_result',-400,'MYR',1700)").run();
 sqlite.prepare("INSERT INTO commission_periods VALUES('c1','deposit','preview',1000,1900)").run();
 sqlite.prepare("INSERT INTO commission_entries VALUES('ce1','c1',150),('ce2','c1',50)").run();
}

test('finance center recognizes only settled cashflow and exposes unavailable sources as null',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'},{generatedAt:2001,settlementVerified:false});
 assert.equal(report.reportType,'finance_center_v1');
 assert.deepEqual({...report.categories.deposits,providers:report.categories.deposits.providers.map(item=>({...item}))},{source:'deposit_orders',status:'connected',recognized:true,amountMinor:'3000',orders:2,members:2,providers:[{provider:'manual_bank',orders:1,amountMinor:'2000'},{provider:'vpay',orders:1,amountMinor:'1000'}]});
 assert.equal(report.categories.withdrawals.amountMinor,'500');
 assert.equal(report.totals.netCashflowMinor,'2500');
 assert.equal(report.totals.netProfitMinor,null);
 assert.equal(report.categories.manualBank.amountMinor,'2000');
 assert.deepEqual(report.categories.manualBank.pending,{orders:1,members:1,amountMinor:'3000'});
 assert.equal(report.bank.bankConfigured,true);
 assert.equal(report.bank.enabledAccounts,1);
 assert.equal(report.bank.approval.panel,'manualBankAdminPanel');
 assert.equal(report.categories.referralDepositCommission.amountMinor,null);
 assert.equal(report.categories.referralDepositCommission.previewAmountMinor,'200');
 assert.equal(report.categories.referralDepositCommission.status,'preview_only');
 assert.equal(report.categories.referralTurnoverCommission.amountMinor,null);
 assert.equal(report.categories.companyProfitDividend.amountMinor,null);
 assert.equal(report.categories.gamePnl.amountMinor,null);
 assert.equal(report.categories.gamePnl.observedMemberResultMinor,'-400');
 assert.equal(report.categories.gamePnl.status,'unverified');
 for(const key of ['vipBonuses','cashback','providerSettlement','providerFees','refunds','operatingExpenses'])assert.equal(report.categories[key].amountMinor,null);
 assert.equal(report.reconciliation.memberWallet.status,'matched');
 assert.equal(report.reconciliation.paymentProvider.differenceMinor,null);
 assert.equal(report.reconciliation.bankStatement.differenceMinor,null);
 assert.equal(report.reconciliation.settlementVerified,false);
 assert.equal(report.readiness.netProfitReady,false);
 const serialized=JSON.stringify(report);
 assert.doesNotMatch(serialized,/PRIVATE NAME|99887766|private-receipt/);
 sqlite.close();
});

test('finance center detects an internal wallet posting mismatch without inventing an external difference',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);sqlite.prepare("DELETE FROM wallet_ledger WHERE id='l4'").run();
 const report=await financeCenterReport(db,{period:'month',start:1000,end:2000,label:'1970-01'},{generatedAt:2001,settlementVerified:false});
 assert.equal(report.reconciliation.memberWallet.status,'mismatch');
 assert.equal(report.reconciliation.memberWallet.doubleEntryDifferenceMinor,'2000');
 assert.equal(report.reconciliation.paymentProvider.differenceMinor,null);
 assert.equal(report.totals.netCashflowMinor,'2500');
 sqlite.close();
});

test('finance center excludes conflicting or unsettled game ledger rows',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);
 sqlite.prepare("INSERT INTO game_wallet_sessions VALUES('gs-conflict','u1','settled',2000,1500),('gs-open','u1','withdraw_pending',2000,NULL)").run();
 sqlite.prepare("INSERT INTO game_wallet_ledger VALUES('g-conflict','gs-conflict','u1','game_result',999,'MYR',1750),('g-open','gs-open','u1','game_result',700,'MYR',1800)").run();
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'},{generatedAt:2001,settlementVerified:true});
 assert.equal(report.categories.gamePnl.observedMemberResultMinor,'-400');
 assert.equal(report.categories.gamePnl.amountMinor,'400');
 assert.equal(report.categories.gamePnl.sessions,1);
 sqlite.close();
});

test('finance center rejects invalid or unbounded ranges',async()=>{
 const {sqlite,db}=fixture();
 await assert.rejects(()=>financeCenterReport(db,{period:'day',start:2000,end:1000,label:'bad'}),/Invalid finance report range/);
 await assert.rejects(()=>financeCenterReport(db,{period:'all',start:0,end:86400*4000,label:'too-wide'}),/Invalid finance report range/);
 sqlite.close();
});
