import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {financeCenterReport} from '../lib/finance-center.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}

function fixture(){
 const sqlite=new DatabaseSync(':memory:');
 sqlite.exec(`
  CREATE TABLE settings(id TEXT PRIMARY KEY,value TEXT);
  CREATE TABLE manual_bank_transactions(id TEXT PRIMARY KEY,direction TEXT,amount_minor INTEGER,recorded_at INTEGER,payout_id TEXT,bank_account_id TEXT,currency TEXT,proof_sha256 TEXT,proof_data TEXT,recorded_by TEXT);
  CREATE TABLE deposit_orders(id TEXT PRIMARY KEY,user_id TEXT,provider TEXT,amount_minor INTEGER,currency TEXT,status TEXT,updated_at INTEGER);
  CREATE TABLE withdrawal_requests(id TEXT PRIMARY KEY,user_id TEXT,provider_id TEXT,amount_minor INTEGER,currency TEXT,status TEXT,updated_at INTEGER,request_key TEXT DEFAULT '',manual_ledger_version INTEGER NOT NULL DEFAULT 0);
  CREATE TABLE provider_payouts(id TEXT PRIMARY KEY,withdrawal_id TEXT,provider_id TEXT,request_key TEXT,amount_minor INTEGER,currency TEXT,status TEXT,create_outcome TEXT,last_error_code TEXT,provider_reference TEXT,manual_bank_account_id TEXT,last_event_hash TEXT);
  CREATE TABLE manual_withdrawal_ledger(id TEXT PRIMARY KEY,withdrawal_id TEXT,payout_id TEXT,bank_transaction_id TEXT,user_id TEXT,account_code TEXT,amount_minor INTEGER,currency TEXT,created_at INTEGER,created_by TEXT);
  CREATE TABLE wallet_reservations(user_id TEXT,kind TEXT,reference_id TEXT,amount_minor INTEGER,created_at INTEGER);
  CREATE TABLE audit(id TEXT PRIMARY KEY,event TEXT,target TEXT,user_id TEXT,created_at INTEGER);
  CREATE TABLE wallet_ledger(id TEXT PRIMARY KEY,order_id TEXT,user_id TEXT,account_code TEXT,amount_minor INTEGER,currency TEXT,created_at INTEGER);
  CREATE TABLE company_bank_accounts(id TEXT PRIMARY KEY,enabled INTEGER,account_name TEXT,account_number TEXT);
  CREATE TABLE manual_deposit_requests(deposit_order_id TEXT PRIMARY KEY,bank_account_id TEXT,receipt_data TEXT);
  CREATE TABLE game_wallet_sessions(id TEXT PRIMARY KEY,user_id TEXT,status TEXT,amount_out_minor INTEGER,amount_returned_minor INTEGER);
  CREATE TABLE game_wallet_ledger(id TEXT PRIMARY KEY,session_id TEXT,user_id TEXT,account_code TEXT,amount_minor INTEGER,currency TEXT,created_at INTEGER);
  CREATE TABLE commission_periods(id TEXT PRIMARY KEY,basis TEXT,status TEXT,period_start INTEGER,period_end INTEGER);
  CREATE TABLE commission_entries(id TEXT PRIMARY KEY,period_id TEXT,commission_minor INTEGER);
 `);
 const db={prepare:sql=>new Statement(sqlite,sql)};
 return {sqlite,db};
}

function seed(sqlite){
 const deposit=sqlite.prepare('INSERT INTO deposit_orders VALUES(?,?,?,?,?,?,?)');
 deposit.run('d1','u1','vpay',1000,'MYR','credited',1100);
 deposit.run('d2','u2','manual_bank',2000,'MYR','credited',1200);
 deposit.run('d3','u3','manual_bank',3000,'MYR','pending',1300);
 deposit.run('d4','u4','1mpay',9000,'MYR','credited',900);
 const withdrawal=sqlite.prepare('INSERT INTO withdrawal_requests(id,user_id,provider_id,amount_minor,currency,status,updated_at) VALUES(?,?,?,?,?,?,?)');
 withdrawal.run('w1','u1','vpay',500,'MYR','paid',1400);
 withdrawal.run('w2','u2','gspay',700,'MYR','pending',1500);
 const ledger=sqlite.prepare('INSERT INTO wallet_ledger VALUES(?,?,?,?,?,?,?)');
 for(const [id,order,user,account,value] of [['l1','d1','u1','member',1000],['l2','d1','u1','provider_clearing',-1000],['l3','d2','u2','member',2000],['l4','d2','u2','provider_clearing',-2000]])ledger.run(id,order,user,account,value,'MYR',1600);
 sqlite.prepare("INSERT INTO company_bank_accounts VALUES('bank1',1,'PRIVATE NAME','99887766')").run();
 sqlite.prepare("INSERT INTO manual_deposit_requests VALUES('d2','bank1','private-receipt'),('d3','bank1','private-pending-receipt')").run();
 sqlite.prepare("INSERT INTO game_wallet_sessions VALUES('gs1','u1','settled',2000,1600)").run();
 sqlite.prepare("INSERT INTO game_wallet_ledger VALUES('g1','gs1','u1','game_result',-400,'MYR',1700)").run();
 sqlite.prepare("INSERT INTO commission_periods VALUES('c1','deposit','preview',1000,1900)").run();
 sqlite.prepare("INSERT INTO commission_entries VALUES('ce1','c1',150),('ce2','c1',50)").run();
}

test('finance center recognizes only settled cashflow and exposes unavailable sources as null',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'},{generatedAt:2001,settlementVerified:false});
 assert.equal(report.reportType,'finance_center_v1');
 assert.deepEqual({...report.categories.deposits,providers:report.categories.deposits.providers.map(item=>({...item}))},{source:'deposit_orders',status:'connected',recognized:true,amountMinor:'3000',orders:2,members:2,providers:[{provider:'manual_bank',orders:1,amountMinor:'2000'},{provider:'vpay',orders:1,amountMinor:'1000'}]});
 assert.equal(report.categories.withdrawals.amountMinor,'500');
 assert.equal(report.totals.netCashflowMinor,'2500');
 assert.equal(report.totals.netProfitMinor,null);
 assert.equal(report.categories.manualBank.amountMinor,'2000');
 assert.deepEqual(report.categories.manualBank.pending,{orders:1,members:1,amountMinor:'3000'});
 assert.equal(report.bank.bankConfigured,true);
 assert.equal(report.bank.enabledAccounts,1);
 assert.equal(report.bank.approval.panel,'manualBankAdminPanel');
 assert.equal(report.categories.referralDepositCommission.amountMinor,null);
 assert.equal(report.categories.referralDepositCommission.previewAmountMinor,'200');
 assert.equal(report.categories.referralDepositCommission.status,'preview_only');
 assert.equal(report.categories.referralTurnoverCommission.amountMinor,null);
 assert.equal(report.categories.companyProfitDividend.amountMinor,null);
 assert.equal(report.categories.gamePnl.amountMinor,null);
 assert.equal(report.categories.gamePnl.observedMemberResultMinor,'-400');
 assert.equal(report.categories.gamePnl.status,'unverified');
 for(const key of ['vipBonuses','cashback','providerSettlement','providerFees','refunds','operatingExpenses'])assert.equal(report.categories[key].amountMinor,null);
 assert.equal(report.reconciliation.memberWallet.status,'matched');
 assert.equal(report.reconciliation.manualWithdrawals.status,'not_observed');
 assert.equal(report.reconciliation.manualWithdrawals.matched,false);
 assert.equal(report.reconciliation.manualWithdrawals.excludedProviderPaidOrders,1);
 assert.equal(report.reconciliation.paymentProvider.differenceMinor,null);
 assert.equal(report.reconciliation.bankStatement.differenceMinor,null);
 assert.equal(report.reconciliation.settlementVerified,false);
 assert.equal(report.readiness.netProfitReady,false);
 const serialized=JSON.stringify(report);
 assert.doesNotMatch(serialized,/PRIVATE NAME|99887766|private-receipt/);
 sqlite.close();
});

function manualPaid(sqlite,{id,user,minor,version=1,at=1750}){
 const payout=`p-${id}`,proof=`proof-${id}`,request=`request-${id}`,hash='d'.repeat(64);
 sqlite.prepare('INSERT INTO withdrawal_requests(id,user_id,provider_id,amount_minor,currency,status,updated_at,request_key,manual_ledger_version) VALUES(?,?,?,?,?,?,?,?,?)').run(id,user,'manual_bank',minor,'MYR','paid',at,request,version);
 sqlite.prepare('INSERT INTO provider_payouts VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(payout,id,'manual_bank',request,minor,'MYR','succeeded','accepted','',proof,'bank1',hash);
 sqlite.prepare('INSERT INTO manual_bank_transactions VALUES(?,?,?,?,?,?,?,?,?,?)').run(proof,'withdrawal',minor,at,payout,'bank1','MYR',hash,'private-bank-proof','owner');
 sqlite.prepare('INSERT INTO audit VALUES(?,?,?,?,?)').run(`audit-${id}`,'manual_bank_payout_paid',proof,'owner',at);
 if(version===1){
  const insert=sqlite.prepare('INSERT INTO manual_withdrawal_ledger VALUES(?,?,?,?,?,?,?,?,?,?)');
  insert.run(`member-${id}`,id,payout,proof,user,'member',-minor,'MYR',at,'owner');
  insert.run(`clearing-${id}`,id,payout,proof,user,'bank_clearing',minor,'MYR',at,'owner');
 }
}

test('manual withdrawal reconciliation pairs actual paid orders without adding a second cashflow debit',async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);
 manualPaid(sqlite,{id:'wm1',user:'u1',minor:350});manualPaid(sqlite,{id:'wm2',user:'u2',minor:650});
 const changes=sqlite.prepare('SELECT total_changes() n').get().n;
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'}),manual=report.reconciliation.manualWithdrawals;
 assert.equal(manual.status,'matched');assert.equal(manual.matched,true);
 assert.equal(manual.scope,'manual_bank');assert.equal(manual.paidOrders,2);assert.equal(manual.journaledOrders,2);assert.equal(manual.legacyOrders,0);
 assert.equal(manual.paidAmountMinor,'1000');assert.equal(manual.journaledPaidMinor,'1000');assert.equal(manual.memberDebitMinor,'-1000');assert.equal(manual.bankClearingMinor,'1000');
 assert.equal(manual.withdrawalDifferenceMinor,'0');assert.equal(manual.doubleEntryDifferenceMinor,'0');assert.equal(manual.mismatchOrders,0);assert.equal(manual.invalidJournalEntries,0);
 assert.equal(manual.ledgerEntries,4);assert.equal(manual.excludedProviderPaidOrders,1);
 assert.equal(report.totals.recognizedWithdrawalsMinor,'1500');assert.equal(report.totals.netCashflowMinor,'1500');
 assert.equal(report.reconciliation.overall,'incomplete');assert.equal(report.reconciliation.bankStatement.status,'not_connected');
 assert.doesNotMatch(JSON.stringify(report),/private-bank-proof|PRIVATE NAME|99887766/);
 assert.equal(sqlite.prepare('SELECT total_changes() n').get().n,changes);
});

test('legacy manual paid rows retain cashflow but remain explicitly incomplete without automatic backfill',async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);
 manualPaid(sqlite,{id:'wm-old',user:'u1',minor:800,version:0});manualPaid(sqlite,{id:'wm-new',user:'u2',minor:200});
 const changes=sqlite.prepare('SELECT total_changes() n').get().n;
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'}),manual=report.reconciliation.manualWithdrawals;
 assert.equal(manual.status,'incomplete');assert.equal(manual.matched,false);assert.equal(manual.paidOrders,2);assert.equal(manual.legacyOrders,1);assert.equal(manual.legacyAmountMinor,'800');
 assert.equal(manual.journaledOrders,1);assert.equal(manual.journaledPaidMinor,'200');assert.equal(manual.memberDebitMinor,'-200');assert.equal(manual.bankClearingMinor,'200');
 assert.equal(manual.mismatchOrders,0);assert.equal(manual.invalidJournalEntries,0);assert.equal(manual.withdrawalDifferenceMinor,'0');assert.equal(manual.doubleEntryDifferenceMinor,'0');
 assert.equal(report.totals.recognizedWithdrawalsMinor,'1500');
 assert.equal(sqlite.prepare('SELECT total_changes() n').get().n,changes);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM manual_withdrawal_ledger WHERE withdrawal_id='wm-old'").get().n,0);
});

for(const scenario of [
 {name:'amounts swapped between paid withdrawals',mismatches:2,sql:"UPDATE manual_withdrawal_ledger SET amount_minor=CASE WHEN withdrawal_id='wm1' THEN CASE account_code WHEN 'member' THEN -650 ELSE 650 END ELSE CASE account_code WHEN 'member' THEN -350 ELSE 350 END END"},
 {name:'both journal legs assigned to a different member',mismatches:1,sql:"UPDATE manual_withdrawal_ledger SET user_id='u2' WHERE withdrawal_id='wm1'"},
 {name:'journal currency disagrees with the paid withdrawal',mismatches:1,sql:"UPDATE manual_withdrawal_ledger SET currency='USD' WHERE withdrawal_id='wm1'"},
 {name:'journal links to another payout proof',mismatches:1,sql:"UPDATE manual_withdrawal_ledger SET bank_transaction_id='proof-wm2' WHERE withdrawal_id='wm1'"},
 {name:'paid proof amount differs from the withdrawal',mismatches:1,sql:"UPDATE manual_bank_transactions SET amount_minor=999 WHERE id='proof-wm1'"},
 {name:'version zero row unexpectedly has a journal',mismatches:1,sql:"UPDATE withdrawal_requests SET manual_ledger_version=0 WHERE id='wm1'"},
])test(`manual withdrawal report rejects ${scenario.name}`,async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);
 manualPaid(sqlite,{id:'wm1',user:'u1',minor:350});manualPaid(sqlite,{id:'wm2',user:'u2',minor:650});sqlite.exec(scenario.sql);
 const changes=sqlite.prepare('SELECT total_changes() n').get().n;
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'}),manual=report.reconciliation.manualWithdrawals;
 assert.equal(manual.status,'mismatch');assert.equal(manual.matched,false);assert.equal(manual.mismatchOrders,scenario.mismatches);assert.ok(manual.invalidJournalEntries>0);
 assert.equal(manual.withdrawalDifferenceMinor,'0');assert.equal(manual.doubleEntryDifferenceMinor,'0','aggregate cancellation cannot substitute for per-order evidence');
 assert.equal(report.reconciliation.overall,'incomplete');assert.equal(sqlite.prepare('SELECT total_changes() n').get().n,changes);
});

test('manual withdrawal report detects a missing journal leg and ignores unrelated date ranges',async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);manualPaid(sqlite,{id:'wm1',user:'u1',minor:350});
 manualPaid(sqlite,{id:'wm-old-period',user:'u2',minor:650,version:0,at:900});sqlite.exec("DELETE FROM manual_withdrawal_ledger WHERE id='clearing-wm1'");
 const manual=(await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'})).reconciliation.manualWithdrawals;
 assert.equal(manual.status,'mismatch');assert.equal(manual.paidOrders,1);assert.equal(manual.legacyOrders,0);assert.equal(manual.mismatchOrders,1);
 assert.equal(manual.doubleEntryDifferenceMinor,'-350');assert.equal(manual.ledgerEntries,1);
});

for(const scenario of [
 {name:'unpaid withdrawal',sql:"UPDATE withdrawal_requests SET status='processing' WHERE id='wm1'"},
 {name:'foreign provider withdrawal',sql:"UPDATE withdrawal_requests SET provider_id='vpay' WHERE id='wm1'"},
 {name:'orphaned journal',sql:"DELETE FROM withdrawal_requests WHERE id='wm1'"},
])test(`manual withdrawal report flags a journal attached to an ${scenario.name}`,async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);manualPaid(sqlite,{id:'wm1',user:'u1',minor:350});sqlite.exec(scenario.sql);
 const manual=(await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'})).reconciliation.manualWithdrawals;
 assert.equal(manual.paidOrders,0);assert.equal(manual.status,'mismatch');assert.equal(manual.matched,false);assert.equal(manual.invalidJournalEntries,2);
});

test('a journal completion marker on an unpaid withdrawal is an exception even when its journal is absent',async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);manualPaid(sqlite,{id:'wm1',user:'u1',minor:350});
 sqlite.exec("DELETE FROM manual_withdrawal_ledger WHERE withdrawal_id='wm1'; UPDATE withdrawal_requests SET status='processing' WHERE id='wm1'");
 const manual=(await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'})).reconciliation.manualWithdrawals;
 assert.equal(manual.paidOrders,0);assert.equal(manual.invalidJournalEntries,0);assert.equal(manual.invalidWithdrawalStates,1);assert.equal(manual.status,'mismatch');assert.equal(manual.matched,false);
});

test('a paid withdrawal with a complete pair but an unreleased reservation is not reconciled',async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);manualPaid(sqlite,{id:'wm1',user:'u1',minor:350});
 sqlite.prepare('INSERT INTO wallet_reservations VALUES(?,?,?,?,?)').run('u1','withdrawal','wm1',350,1700);
 const manual=(await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'})).reconciliation.manualWithdrawals;
 assert.equal(manual.status,'mismatch');assert.equal(manual.matched,false);assert.equal(manual.mismatchOrders,1);assert.equal(manual.invalidJournalEntries,2);assert.equal(manual.invalidWithdrawalStates,1);
 assert.equal(manual.withdrawalDifferenceMinor,'0');assert.equal(manual.doubleEntryDifferenceMinor,'0');
});

test('a current withdrawal exception cannot hide behind an older journal creation timestamp',async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);
 manualPaid(sqlite,{id:'wm-old-journal',user:'u1',minor:350,at:900});manualPaid(sqlite,{id:'wm-current',user:'u2',minor:650});
 sqlite.exec("UPDATE withdrawal_requests SET status='processing',manual_ledger_version=0,updated_at=1800 WHERE id='wm-old-journal'");
 const manual=(await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'})).reconciliation.manualWithdrawals;
 assert.equal(manual.paidOrders,1);assert.equal(manual.mismatchOrders,0);assert.equal(manual.invalidWithdrawalStates,0);assert.equal(manual.invalidJournalEntries,2);
 assert.equal(manual.status,'mismatch');assert.equal(manual.matched,false);
});

test('finance center detects an internal wallet posting mismatch without inventing an external difference',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);sqlite.prepare("DELETE FROM wallet_ledger WHERE id='l4'").run();
 const report=await financeCenterReport(db,{period:'month',start:1000,end:2000,label:'1970-01'},{generatedAt:2001,settlementVerified:false});
 assert.equal(report.reconciliation.memberWallet.status,'mismatch');
 assert.equal(report.reconciliation.memberWallet.doubleEntryDifferenceMinor,'2000');
 assert.equal(report.reconciliation.paymentProvider.differenceMinor,null);
 assert.equal(report.totals.netCashflowMinor,'2500');
 sqlite.close();
});

for(const scenario of [
 {name:'swapped amounts between orders',mismatchOrders:2,sql:"UPDATE wallet_ledger SET amount_minor=CASE id WHEN 'l1' THEN 2000 WHEN 'l2' THEN -2000 WHEN 'l3' THEN 1000 ELSE -1000 END WHERE order_id IN ('d1','d2')"},
 {name:'both ledger legs assigned to another member',mismatchOrders:1,sql:"UPDATE wallet_ledger SET user_id='u2' WHERE order_id='d1'"},
 {name:'duplicate split ledger legs',mismatchOrders:1,sql:"UPDATE wallet_ledger SET amount_minor=CASE account_code WHEN 'member' THEN 500 ELSE -500 END WHERE order_id='d1'; INSERT INTO wallet_ledger VALUES('duplicate-member','d1','u1','member',500,'MYR',1600),('duplicate-clearing','d1','u1','provider_clearing',-500,'MYR',1600)"},
])test(`finance center rejects ${scenario.name} even when all aggregate totals match`,async t=>{
 const {sqlite,db}=fixture();t.after(()=>sqlite.close());seed(sqlite);sqlite.exec(scenario.sql);
 const changes=sqlite.prepare('SELECT total_changes() n').get().n;
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'});
 const wallet=report.reconciliation.memberWallet;
 assert.equal(wallet.creditedDepositMinor,'3000');
 assert.equal(wallet.memberCreditMinor,'3000');
 assert.equal(wallet.providerClearingMinor,'-3000');
 assert.equal(wallet.depositDifferenceMinor,'0');
 assert.equal(wallet.doubleEntryDifferenceMinor,'0');
 assert.equal(wallet.memberLedgerOrders,2);
 assert.equal(wallet.clearingLedgerOrders,2);
 assert.equal(wallet.matched,false);
 assert.equal(wallet.status,'mismatch');
 assert.equal(wallet.mismatchOrders,scenario.mismatchOrders);
 assert.equal(report.reconciliation.paymentProvider.differenceMinor,null);
 assert.equal(report.reconciliation.bankStatement.differenceMinor,null);
 assert.equal(sqlite.prepare('SELECT total_changes() n').get().n,changes,'a report must not repair or mutate wallet entries');
});

test('finance center excludes conflicting or unsettled game ledger rows',async()=>{
 const {sqlite,db}=fixture();seed(sqlite);
 sqlite.prepare("INSERT INTO game_wallet_sessions VALUES('gs-conflict','u1','settled',2000,1500),('gs-open','u1','withdraw_pending',2000,NULL)").run();
 sqlite.prepare("INSERT INTO game_wallet_ledger VALUES('g-conflict','gs-conflict','u1','game_result',999,'MYR',1750),('g-open','gs-open','u1','game_result',700,'MYR',1800)").run();
 const report=await financeCenterReport(db,{period:'day',start:1000,end:2000,label:'1970-01-01'},{generatedAt:2001,settlementVerified:true});
 assert.equal(report.categories.gamePnl.observedMemberResultMinor,'-400');
 assert.equal(report.categories.gamePnl.amountMinor,'400');
 assert.equal(report.categories.gamePnl.sessions,1);
 sqlite.close();
});

test('finance center rejects invalid or unbounded ranges',async()=>{
 const {sqlite,db}=fixture();
 await assert.rejects(()=>financeCenterReport(db,{period:'day',start:2000,end:1000,label:'bad'}),/Invalid finance report range/);
 await assert.rejects(()=>financeCenterReport(db,{period:'all',start:0,end:86400*4000,label:'too-wide'}),/Invalid finance report range/);
 sqlite.close();
});
