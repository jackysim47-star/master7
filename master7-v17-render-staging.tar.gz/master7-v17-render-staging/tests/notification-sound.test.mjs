import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');

function functionSource(name,next){
 const start=source.indexOf(`function ${name}`),end=source.indexOf(`\n${next}`,start);
 assert.ok(start>=0&&end>start,`${name} source is present`);
 return source.slice(start,end);
}

test('financial alerts follow the existing device sound toggle without an Events dependency',()=>{
 const body=functionSource('financialAlert','async function pollFinancialNotifications');
 assert.match(body,/state\.financialSoundEnabled!==false/);assert.match(body,/playFinancialTone\(\)/);assert.match(body,/armFinancialAudio\(\)/);
 assert.doesNotMatch(body,/Master7Engagement|soundEnabled/);
});

test('support alerts follow the existing device sound toggle without an Events dependency',()=>{
 const start=source.indexOf('async function pollTicketNotifications'),end=source.indexOf('\nasync function loadPublic',start),body=source.slice(start,end);
 assert.ok(start>=0&&end>start);assert.match(body,/state\.financialSoundEnabled!==false/);assert.match(body,/playTicketTone\(\)/);assert.match(body,/armFinancialAudio\(\)/);
 assert.doesNotMatch(body,/Master7Engagement|soundEnabled/);
});
