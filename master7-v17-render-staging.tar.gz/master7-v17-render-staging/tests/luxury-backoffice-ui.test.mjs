import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,statSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const style=readFileSync(new URL('../public/assets/style.css',import.meta.url),'utf8');
const backend=readFileSync(new URL('../lib/backend.ts',import.meta.url),'utf8');
const route=readFileSync(new URL('../app/route.ts',import.meta.url),'utf8');

test('backoffice menu puts daily work first and low-frequency tools last',()=>{
 const order=['#operationsAiPanel','#manualBankAdminPanel','#adminDepositPanel','#vipManager','#apiSupplierManager','#lobbyAdManager','#bonusHunterPanel','#auditPanel','#systemReadinessPanel'];
 let cursor=-1;for(const id of order){const next=html.indexOf(`href="${id}"`);assert.ok(next>cursor,`${id} should follow the previous menu item`);cursor=next;}
 assert.match(html,/MORE · 较少使用/);
 const menu=html.slice(html.indexOf('id="adminInternalSidebar"'),html.indexOf('</nav>',html.indexOf('id="adminInternalSidebar"')));
 assert.equal((menu.match(/href="#accountingPanel"/g)||[]).length,1);
 assert.equal((menu.match(/href="#pendingPanel"/g)||[]).length,1);
});

test('bank, VIP, support and contact settings each use an independent compact cover',()=>{
 for(const css of ['bank-admin-cover','vip-admin-cover','commission-admin-cover','support-admin-cover','contact-admin-cover'])assert.match(html,new RegExp(css));
 assert.match(html,/data-bank-admin-tab="accounts"/);
 assert.match(html,/data-bank-admin-tab="receipts"/);
 assert.match(html,/id="manualBankPendingBadge"/);
 assert.match(app,/dashboardHeading\.hidden=panelId!=="operationsPanel"/);
 assert.match(style,/\.admin-feature-cover\{display:block!important/);
 assert.match(style,/\.admin-internal-sidebar a\.active::after/);
 assert.match(style,/background:#5de9df/);
});

test('contact hub supports hotline, chat channels and an opt-in Meta Pixel',()=>{
 for(const id of ['hotlineContact','whatsappContact','wechatContact','lineContact','telegramContact','facebookLink','instagramLink','metaPixelId','metaPixelEnabled'])assert.match(html,new RegExp(`id="${id}"`));
 assert.match(app,/configureAdvertisingPixel\(data\)/);
 assert.match(app,/https:\/\/connect\.facebook\.net\/en_US\/fbevents\.js/);
 assert.match(app,/pixelEnabled:\$\("metaPixelEnabled"\)\.checked/);
 assert.match(backend,/contact_and_pixel_settings_updated/);
 assert.match(backend,/Meta Pixel ID 必须是数字/);
 assert.match(route,/script-src 'self' https:\/\/connect\.facebook\.net/);
 assert.match(route,/img-src 'self' data: https:\/\/www\.facebook\.com/);
});

test('AI platform manager links core white-label modules without duplicating the side menu',()=>{
 for(const label of ['会员 CRM','支付对账','厂家健康','KYC 与风险','优惠规则','代理联盟'])assert.match(html,new RegExp(label));
 assert.match(style,/\.ops-ai-capability-grid/);
 assert.match(app,/const adminFeatureGuides=Object\.freeze/);
 for(const id of ['operationsAiPanel','financeCenterPanel','manualBankAdminPanel','vipManager','apiSupplierManager','gameCatalogManager','marketingCenter','supportOperationsPanel'])assert.ok(app.includes(`${id}:[`),`${id} needs an inline guide`);
 assert.match(app,/功能说明书 · \$\{title\}/);
 assert.match(app,/游戏 ID、赔率、RTP、投注和结算由各厂家 API 提供/);
});

test('optimized original artwork is wired into customer, login and owner shells',()=>{
 for(const name of ['master7-casino-lobby-premium.webp','master7-casino-backoffice-premium.webp']){const file=new URL(`../public/assets/${name}`,import.meta.url),bytes=readFileSync(file);assert.equal(bytes.subarray(0,4).toString(),'RIFF');assert.equal(bytes.subarray(8,12).toString(),'WEBP');assert.ok(statSync(file).size<200_000,`${name} should stay mobile-friendly`);}
 assert.match(html,/rel="preload" as="image" href="\/assets\/master7-casino-lobby-premium\.webp"/);
 assert.match(style,/body\.auth-entry\{background:[^}]*master7-casino-lobby-premium\.webp/);
 assert.match(style,/#home \.hero\{[^}]*master7-casino-lobby-premium\.webp/);
 assert.match(style,/body\.admin-mode\{[^}]*master7-casino-backoffice-premium\.webp/);
});

test('three sponsor cards, live hosts, cartoons and VIP artwork use independent premium visuals',()=>{
 for(const name of ['master7-sponsored-mascots.webp','master7-live-hosts.webp','master7-cartoon-providers.webp','master7-vip-commission.webp']){const file=new URL(`../public/assets/${name}`,import.meta.url),bytes=readFileSync(file);assert.equal(bytes.subarray(0,4).toString(),'RIFF');assert.equal(bytes.subarray(8,12).toString(),'WEBP');assert.ok(statSync(file).size<350_000,`${name} should stay below the upload-size class`);}
 assert.equal((html.match(/data-sponsor-index=/g)||[]).length,3);
 assert.equal((html.match(/>FREE CREDIT</g)||[]).length,3);
 assert.match(app,/liveSupplierPortraits=Object\.freeze\(\{gameplay:0/);
 assert.match(app,/cartoonSupplierPortraits=Object\.freeze\(\{astar:0/);
 assert.match(style,/master7-vip-commission\.webp/);
});

test('lobby Voucher shows the exact RM88 promotion and records a company-manual request path',()=>{
 const art=new URL('../public/assets/master7-rm88-voucher.webp',import.meta.url),bytes=readFileSync(art);assert.equal(bytes.subarray(0,4).toString(),'RIFF');assert.equal(bytes.subarray(8,12).toString(),'WEBP');assert.ok(statSync(art).size<350_000);
 for(const text of ['新会员 RM88 FREE Voucher','最多玩 5 次','中奖一次即结束','TURNOVER 20× · RM1,760','MASTER7 公司汇款','JILI、MegaH5、918KISS'])assert.match(html,new RegExp(text));
 assert.match(html,/class="welcome-voucher-art"[^>]+src="\/assets\/master7-rm88-voucher\.webp"/);
 assert.match(style,/\.welcome-voucher-art\{/);
 assert.match(app,/requestProviderBonus\(offer,code,request\)/);
 assert.match(app,/selectedProviderId:providerId/);
 assert.match(app,/awaiting review|等待后台审核/i);
 assert.match(app,/MASTER7 公司手工处理/);
 assert.match(app,/api\/admin\/voucher-manual/);
 assert.match(backend,/sponsoredProviderIds/);
 assert.match(backend,/lifetimeClaimLimit/);
 assert.match(backend,/walletCredited:false/);
});

test('customer bank photos, an independent agent menu and four free share channels are present',()=>{
 for(const id of ['manualBankPhoto','companyBankImage','companyBankImagePreview','organicPromoLanguage','organicPromoLink','organicPromoText'])assert.match(html,new RegExp(`id="${id}"`));
 assert.equal((html.match(/data-organic-share=/g)||[]).length,4);
 assert.match(html,/data-section="agent"/);
 assert.match(html,/id="agent" class="section agent-center"/);
 assert.match(app,/shareOrganicPromotion\(channel\)/);
 assert.match(app,/imageData:await imageDataForUpload|payload\.imageData=await imageDataForUpload/);
});
