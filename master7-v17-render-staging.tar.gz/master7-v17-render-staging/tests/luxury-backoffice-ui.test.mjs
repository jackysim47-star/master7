import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readFileSync,readdirSync,statSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const style=readFileSync(new URL('../public/assets/style.css',import.meta.url),'utf8');
const suiteStyle=readFileSync(new URL('../public/assets/suite-theme.css',import.meta.url),'utf8');
const backend=readFileSync(new URL('../lib/backend.ts',import.meta.url),'utf8');
const route=readFileSync(new URL('../app/route.ts',import.meta.url),'utf8');

test('backoffice menu puts daily work first and low-frequency tools last',()=>{
 const order=['#operationsAiPanel','#manualBankAdminPanel','#adminDepositPanel','#vipManager','#apiSupplierManager','#lobbyAdManager','#bonusHunterPanel','#auditPanel','#systemReadinessPanel'];
 let cursor=-1;for(const id of order){const next=html.indexOf(`href="${id}"`);assert.ok(next>cursor,`${id} should follow the previous menu item`);cursor=next;}
 assert.match(html,/MORE · 较少使用/);
 const menu=html.slice(html.indexOf('id="adminInternalSidebar"'),html.indexOf('</nav>',html.indexOf('id="adminInternalSidebar"')));
 assert.equal((menu.match(/href="#accountingPanel"/g)||[]).length,1);
 assert.equal((menu.match(/href="#pendingPanel"/g)||[]).length,1);
});

test('bank, VIP, support and contact settings each use an independent compact cover',()=>{
 for(const css of ['bank-admin-cover','vip-admin-cover','commission-admin-cover','support-admin-cover','contact-admin-cover'])assert.match(html,new RegExp(css));
 assert.match(html,/data-bank-admin-tab="accounts"/);
 assert.match(html,/data-bank-admin-tab="receipts"/);
 assert.match(html,/id="manualBankPendingBadge"/);
 assert.match(app,/dashboardHeading\.hidden=panelId!=="operationsPanel"/);
 assert.match(style,/\.admin-feature-cover\{display:block!important/);
 assert.match(style,/\.admin-internal-sidebar a\.active::after/);
 assert.match(style,/background:#5de9df/);
 assert.match(html,/\/assets\/suite-theme\.css\?v=17\.0\.0-selfbuilt\.123-official-entry-verification/);
 assert.ok(html.lastIndexOf('/assets/suite-theme.css')>html.lastIndexOf('/assets/owner-manual.css'),'suite theme must load after all feature styles');
 assert.match(suiteStyle,/--m7-gold:/);
 assert.match(suiteStyle,/body\.admin-mode \.admin-internal-sidebar a\{/);
 assert.match(suiteStyle,/font-size:12px/);
 assert.match(suiteStyle,/color:#e7e1d7/);
});

test('contact hub supports hotline, chat channels and an opt-in Meta Pixel',()=>{
 for(const id of ['hotlineContact','whatsappContact','wechatContact','lineContact','telegramContact','facebookLink','instagramLink','metaPixelId','metaPixelEnabled'])assert.match(html,new RegExp(`id="${id}"`));
 assert.match(app,/configureAdvertisingPixel\(data\)/);
 assert.match(app,/https:\/\/connect\.facebook\.net\/en_US\/fbevents\.js/);
 assert.match(app,/pixelEnabled:\$\("metaPixelEnabled"\)\.checked/);
 assert.match(backend,/contact_and_pixel_settings_updated/);
 assert.match(backend,/Meta Pixel ID 必须是数字/);
 assert.match(route,/script-src 'self' https:\/\/connect\.facebook\.net/);
 assert.match(route,/img-src 'self' data: https:\/\/www\.facebook\.com/);
});

test('AI platform manager links core white-label modules without duplicating the side menu',()=>{
 for(const label of ['会员 CRM','支付对账','厂家健康','KYC 与风险','优惠规则','代理联盟'])assert.match(html,new RegExp(label));
 assert.match(style,/\.ops-ai-capability-grid/);
 assert.doesNotMatch(app,/const adminFeatureGuides/);
 const manual=readFileSync(new URL('../public/assets/owner-manual.js',import.meta.url),'utf8');
 for(const id of ['operationsAiPanel','financeCenterPanel','manualBankAdminPanel','vipManager','apiSupplierManager','gameCatalogManager','marketingCenter','supportOperationsPanel'])assert.ok(manual.includes(`id:"${id}"`),`${id} needs its owner manual entry`);
 assert.match(app,/功能说明书 · \$\{title\}/);
 assert.match(app,/const customerFeatureGuides=Object\.freeze/);
});

test('optimized original artwork is wired into customer, login and owner shells',()=>{
 for(const name of ['master7-casino-lobby-premium.webp','master7-casino-backoffice-premium.webp']){const file=new URL(`../public/assets/${name}`,import.meta.url),bytes=readFileSync(file);assert.equal(bytes.subarray(0,4).toString(),'RIFF');assert.equal(bytes.subarray(8,12).toString(),'WEBP');assert.ok(statSync(file).size<200_000,`${name} should stay mobile-friendly`);}
 assert.match(html,/rel="preload" as="image" href="\/assets\/master7-casino-lobby-premium\.webp"/);
 assert.match(style,/body\.auth-entry\{background:[^}]*master7-casino-lobby-premium\.webp/);
 assert.match(style,/#home \.hero\{[^}]*master7-casino-lobby-premium\.webp/);
 assert.match(style,/body\.admin-mode\{[^}]*master7-casino-backoffice-premium\.webp/);
});

test('three sponsor cards, live hosts, cartoons and VIP artwork use independent premium visuals',()=>{
 for(const name of ['master7-sponsored-mascots.webp','master7-live-hosts.webp','master7-cartoon-providers.webp','master7-vip-commission.webp']){const file=new URL(`../public/assets/${name}`,import.meta.url),bytes=readFileSync(file);assert.equal(bytes.subarray(0,4).toString(),'RIFF');assert.equal(bytes.subarray(8,12).toString(),'WEBP');assert.ok(statSync(file).size<350_000,`${name} should stay below the upload-size class`);}
 assert.equal((html.match(/data-sponsor-index=/g)||[]).length,3);
 assert.equal((html.match(/>SPONSORED</g)||[]).length,3);
 assert.match(app,/liveSupplierPortraits=Object\.freeze\(\{gameplay:0/);
 assert.match(app,/cartoonSupplierPortraits=Object\.freeze\(\{astar:0/);
 assert.match(style,/master7-vip-commission\.webp/);
});

test('all 34 provider fallbacks are valid and visually independent',()=>{
 const root=new URL('../public/assets/providers/',import.meta.url),files=readdirSync(root).filter(name=>name.endsWith('.webp')).sort();
 assert.equal(files.length,34);
 const payloads=[];for(const name of files){const file=new URL(name,root),bytes=readFileSync(file);assert.equal(bytes.subarray(0,4).toString(),'RIFF',name);assert.equal(bytes.subarray(8,12).toString(),'WEBP',name);assert.ok(statSync(file).size<350_000,name);payloads.push(bytes.toString('base64'));}
 assert.equal(new Set(payloads).size,34,'every provider must have a distinct fallback image');
 assert.match(app,/liveSupplierPortraits=Object\.freeze\(\{gameplay:0/);
 assert.match(app,/cartoonSupplierPortraits=Object\.freeze\(\{astar:0/);
});

test('fixed promotional artwork and hard-coded amount are retired while configurable benefits remain',()=>{
 assert.equal(existsSync(new URL('../public/assets/master7-rm88-voucher.webp',import.meta.url)),false);
 assert.doesNotMatch(html,/master7-rm88-voucher|新会员 RM88 FREE Voucher|TURNOVER 20×/);
 assert.doesNotMatch(app,/api\/admin\/voucher-manual/);
 assert.match(app,/requestProviderBonus\(offer,code,request\)/);
 assert.match(app,/selectedProviderId:providerId/);
 assert.match(app,/awaiting review|等待后台审核/i);
 assert.match(app,/管理员可自行设置金额、资格、有效期与 Turnover/);
 assert.match(backend,/manualVoucherProcessing:false/);
 assert.match(backend,/walletCredited:false/);
});

test('customer and backoffice production domains are strictly separated',()=>{
 assert.match(route,/portalHostRedirect/);
});

test('customer bank photos and four free share channels are present while agent controls stay private',()=>{
 for(const id of ['manualBankPhoto','companyBankImage','companyBankImagePreview','organicPromoLanguage','organicPromoLink','organicPromoText'])assert.match(html,new RegExp(`id="${id}"`));
 assert.equal((html.match(/data-organic-share=/g)||[]).length,4);
 assert.doesNotMatch(html,/data-section="agent"/);
 assert.doesNotMatch(html,/id="agent" class="section agent-center"/);
 assert.match(html,/id="referralAdminPanel"[^>]*data-owner-only/);
 assert.match(app,/shareOrganicPromotion\(channel\)/);
 assert.match(app,/imageData:await imageDataForUpload|payload\.imageData=await imageDataForUpload/);
});
