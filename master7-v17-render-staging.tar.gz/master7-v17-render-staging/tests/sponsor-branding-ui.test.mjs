import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync, readFileSync, statSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/assets/member-shell.css',import.meta.url),'utf8');
const worker=readFileSync(new URL('../public/service-worker.js',import.meta.url),'utf8');
const manifest=JSON.parse(readFileSync(new URL('../public/manifest.webmanifest',import.meta.url),'utf8'));

const sponsors=[
 {code:'jili',label:'JILI',asset:'sponsor-jili-master7.webp'},
 {code:'megah5',label:'MEGA H5',asset:'sponsor-megah5-master7.webp'},
 {code:'918kissh5',label:'918KISS',asset:'sponsor-918kiss-master7.webp'}
];

function webpSize(file){
 const bytes=readFileSync(file);
 assert.equal(bytes.subarray(0,4).toString(),'RIFF');
 assert.equal(bytes.subarray(8,12).toString(),'WEBP');
 const signature=bytes.indexOf(Buffer.from([0x9d,0x01,0x2a]));
 assert.ok(signature>=0,'WebP frame header is missing');
 return [bytes.readUInt16LE(signature+3)&0x3fff,bytes.readUInt16LE(signature+5)&0x3fff];
}

function pngSize(file){
 const bytes=readFileSync(file);
 assert.deepEqual([...bytes.subarray(0,8)],[137,80,78,71,13,10,26,10]);
 return [bytes.readUInt32BE(16),bytes.readUInt32BE(20)];
}

test('three independent 16:9 sponsor artworks are present and wired to their provider cards',()=>{
 assert.equal((html.match(/class="bonus-brand-card /g)||[]).length,3);
 for(const sponsor of sponsors){
  const file=new URL(`../public/assets/${sponsor.asset}`,import.meta.url);
  assert.ok(statSync(file).size>100_000,`${sponsor.label} sponsor artwork is unexpectedly small`);
  assert.deepEqual(webpSize(file),[1599,900]);
  assert.match(html,new RegExp(`${sponsor.label.replace(' ','\\s')} × MASTER7`));
  assert.match(app,new RegExp(`(?:"${sponsor.code}"|${sponsor.code}):"/assets/${sponsor.asset.replaceAll('.','\\.')}"`));
  assert.match(worker,new RegExp(`/assets/${sponsor.asset.replaceAll('.','\\.')}`));
 }
 assert.equal((html.match(/data-bonus-i18n="cta">View games</g)||[]).length,3);
 assert.equal((html.match(/data-bonus-i18n="claim">Terms &amp; offers</g)||[]).length,3);
 assert.match(app,/termsTitle:"Terms & conditions"/);
 assert.match(app,/MASTER7-published offer terms/);
 assert.match(app,/\[data-bonus-brand\][\s\S]*openCatalogProvider/);
 assert.match(app,/jili:"jili_myr_1to1"/);
 assert.match(app,/featuredProviderProfile\(provider\.code\)[\s\S]*openCatalogProvider\(profile\.id,profile\.name,provider\.code\)/);
 assert.doesNotMatch(app,/openCatalogProvider\(providerId,provider\.label\)/);
 assert.match(app,/\[data-provider-bonus\][\s\S]*openProviderBonus/);
 const featured=html.slice(html.indexOf('id="bonusBrandLobby"'),html.indexOf('id="apiSupplierLobby"'));
 assert.doesNotMatch(`${featured}\n${app.slice(app.indexOf('const bonusBrandTranslations'),app.indexOf('function bonusText'))}`,/vendor[- ]approved|provider[- ]approved|official partner|licensed by|certified by|authori[sz]ed partner|guaranteed/i);
});

test('all 38 provider entries have individual art and retain the safe lobby fallback',()=>{
 const catalog=app.slice(app.indexOf('const apiSupplierEntries=Object.freeze(['),app.indexOf('const GAME_PLATFORM_COUNT'));
 const providerIds=[...catalog.matchAll(/\{id:"([^"]+)"/g)].map(match=>match[1]);
 assert.equal(providerIds.length,38);
 assert.equal(new Set(providerIds).size,38);
 const generic=new URL('../public/assets/master7-casino-lobby-premium.webp',import.meta.url);
 assert.ok(existsSync(generic)&&statSync(generic).size>50_000);
 assert.match(app,/image\.onerror=\(\)=>\{image\.onerror=null;image\.src="\/assets\/master7-casino-lobby-premium\.webp";\}/);
 for(const id of providerIds){
  const own=new URL(`../public/assets/providers/${id}.webp`,import.meta.url);
  assert.ok(existsSync(own)&&statSync(own).size>1_000,`${id} provider artwork is missing or empty`);
 }
});

test('member mobile layout shows one large horizontally scrollable, snapping sponsor banner',()=>{
 assert.ok(html.indexOf('/assets/style.css')<html.indexOf('/assets/member-shell.css'),'member overrides must load last');
 assert.match(css,/\.bonus-brand-grid\{[\s\S]*display:flex!important;[\s\S]*overflow-x:auto;[\s\S]*scroll-snap-type:inline mandatory;/);
 assert.match(css,/\.bonus-brand-card\{[\s\S]*flex:0 0 min\(82%,880px\)!important;[\s\S]*scroll-snap-align:center;/);
 assert.match(css,/@media\(max-width:650px\)\{[\s\S]*\.bonus-brand-card\{flex-basis:92%!important\}/);
 assert.match(css,/\.bonus-brand-card \.sponsor-art\{[\s\S]*aspect-ratio:16\/9;[\s\S]*object-fit:cover!important;/);
});

test('blue MASTER7 favicon and matching PWA icons are linked and cached',()=>{
 assert.deepEqual(pngSize(new URL('../public/assets/favicon-64.png',import.meta.url)),[64,64]);
 assert.match(html,/rel="icon" href="\/assets\/favicon-64\.png"[^>]*sizes="64x64"/);
 assert.match(worker,/\/assets\/favicon-64\.png/);
 assert.equal(manifest.theme_color,'#39bdf2');
 assert.equal(manifest.background_color,'#e9fbff');
 for(const size of [180,192,512]){
  assert.deepEqual(pngSize(new URL(`../public/assets/pwa-icon-${size}.png`,import.meta.url)),[size,size]);
  assert.match(worker,new RegExp(`/assets/pwa-icon-${size}\\.png`));
 }
});
