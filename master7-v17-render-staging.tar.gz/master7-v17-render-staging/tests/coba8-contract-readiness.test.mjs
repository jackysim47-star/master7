import assert from 'node:assert/strict';
import test from 'node:test';
import {COBA8_PROFILE_ID,COBA8_REQUIRED_CONTRACT_FIELDS,inspectCoba8ContractManifest} from '../lib/coba8-contract-readiness.ts';
import {getGameProviderProfile,resolveGameProviderAdapter} from '../lib/game-provider-registry.ts';
import {GAME_PROVIDER_ADAPTER_METHODS,GameProviderUnavailableError} from '../lib/game-provider-adapter.ts';

test('COBA8 is registered in the member lobby but remains contract-missing and unimplemented',async()=>{
 const profile=getGameProviderProfile(COBA8_PROFILE_ID);assert.ok(profile);assert.equal(profile.providerId,'coba8');assert.equal(profile.displayName,'COBA8 · MYR');
 assert.equal(profile.listedInLobby,true);assert.equal(profile.contractStatus,'missing');assert.equal(profile.adapterStatus,'contract_missing');assert.equal(profile.implemented,false);assert.equal(profile.enabled,false);
 const adapter=resolveGameProviderAdapter(COBA8_PROFILE_ID);assert.equal(adapter.executable,false);
 for(const operation of GAME_PROVIDER_ADAPTER_METHODS)await assert.rejects(adapter[operation](),error=>error instanceof GameProviderUnavailableError&&error.profileId===COBA8_PROFILE_ID&&error.reason==='contract_missing'&&error.operation===operation);
});

test('a login and API token alone disclose no value and cannot enable any COBA8 capability',()=>{
 const diagnostic=inspectCoba8ContractManifest({username:'synthetic-user',password:'synthetic-password',apiToken:'synthetic-token'});
 assert.equal(diagnostic.credentialsPresent,true);assert.equal(diagnostic.manifestComplete,false);assert.deepEqual(diagnostic.missingContractFields,[...COBA8_REQUIRED_CONTRACT_FIELDS]);
 assert.equal(JSON.stringify(diagnostic).includes('synthetic'),false);
 for(const field of ['adapterImplemented','catalogueAllowed','launchAllowed','walletAllowed','settlementAllowed','recoveryAllowed','playAllowed'])assert.equal(diagnostic[field],false,field);
});

test('even a syntactically complete documentation manifest cannot enable Play without an adapter and acceptance',()=>{
 const manifest={};
 for(const path of COBA8_REQUIRED_CONTRACT_FIELDS){const parts=path.split('.');let current=manifest;for(const part of parts.slice(0,-1))current=current[part]??={};current[parts.at(-1)]='documented';}
 const diagnostic=inspectCoba8ContractManifest(manifest);assert.equal(diagnostic.manifestComplete,true);assert.deepEqual(diagnostic.missingContractFields,[]);
 assert.equal(diagnostic.adapterImplemented,false);assert.equal(diagnostic.launchAllowed,false);assert.equal(diagnostic.walletAllowed,false);assert.equal(diagnostic.settlementAllowed,false);assert.equal(diagnostic.recoveryAllowed,false);assert.equal(diagnostic.playAllowed,false);
});
