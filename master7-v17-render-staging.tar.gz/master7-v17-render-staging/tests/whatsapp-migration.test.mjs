import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {join} from 'node:path';

const migration='0100_whatsapp_campaign_delivery.sql';

test('WhatsApp queue migration preserves deliveries and adds leased webhook-safe lifecycle',()=>{
 const db=new DatabaseSync(':memory:');
 db.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync('drizzle').filter(file=>file.endsWith('.sql')&&file!==migration).sort())db.exec(readFileSync(join('drizzle',file),'utf8'));
 db.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner','owner',1,'csrf',1)").run();
 db.prepare("INSERT INTO marketing_contacts(id,phone,name,consent_status,source,created_at,updated_at) VALUES('contact-1','+60111111111','Contact','opted_in','test',1,1)").run();
 db.prepare("INSERT INTO marketing_campaigns(id,name,channel,message,created_by,created_at,updated_at) VALUES('campaign-1','Campaign','whatsapp','Hello','owner',1,1)").run();
 db.prepare("INSERT INTO marketing_deliveries(campaign_id,contact_id,status,provider_message_id,attempts,updated_at) VALUES('campaign-1','contact-1','delivered','wamid.existing',2,2)").run();

 db.exec(readFileSync(join('drizzle',migration),'utf8'));

 const campaign={...db.prepare("SELECT provider,template_name,template_language,template_params_json,audience_count,started_at,completed_at FROM marketing_campaigns WHERE id='campaign-1'").get()};
 assert.deepEqual(campaign,{provider:'unconfigured',template_name:'',template_language:'',template_params_json:'{}',audience_count:0,started_at:null,completed_at:null});
 const preserved={...db.prepare("SELECT status,provider_message_id,attempts,locked_until,next_attempt_at FROM marketing_deliveries WHERE campaign_id='campaign-1' AND contact_id='contact-1'").get()};
 assert.deepEqual(preserved,{status:'delivered',provider_message_id:'wamid.existing',attempts:2,locked_until:0,next_attempt_at:0});
 for(const status of ['queued','submitting','unknown','sent','delivered','read','failed','opted_out']){
  db.prepare("UPDATE marketing_deliveries SET status=? WHERE campaign_id='campaign-1' AND contact_id='contact-1'").run(status);
 }
 assert.throws(()=>db.prepare("UPDATE marketing_deliveries SET status='invalid' WHERE campaign_id='campaign-1'").run(),/CHECK constraint failed/);
 db.prepare("INSERT INTO marketing_contacts(id,phone,name,consent_status,source,created_at,updated_at) VALUES('contact-2','+60112222222','Contact 2','opted_in','test',1,1)").run();
 assert.throws(()=>db.prepare("INSERT INTO marketing_deliveries(campaign_id,contact_id,status,provider_message_id,updated_at) VALUES('campaign-1','contact-2','sent','wamid.existing',3)").run(),/UNIQUE constraint failed/);
 db.prepare("INSERT INTO marketing_webhook_events(event_key,provider_message_id,event_type,status,payload_hash,received_at) VALUES('event-1','wamid.existing','status','delivered',?,4)").run('a'.repeat(64));
 assert.throws(()=>db.prepare("INSERT INTO marketing_webhook_events(event_key,event_type,payload_hash,received_at) VALUES('event-1','status',?,5)").run('b'.repeat(64)),/UNIQUE constraint failed/);
 assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
 db.close();
});
