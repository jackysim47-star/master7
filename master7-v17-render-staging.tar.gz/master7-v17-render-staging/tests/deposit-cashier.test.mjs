import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const definitions=source.slice(0,source.indexOf('(async function start(){'));
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.dataset={};this.attributes={};this.value='';this.hidden=true;this.disabled=false;this.open=false;this._text='';this.style={setProperty(){}};this.classList={toggle(){},add(){},remove(){}};}
 set textContent(value){this._text=String(value);this.children=[];}
 get textContent(){return this._text+this.children.map(item=>item.textContent||'').join('');}
 append(...items){this.children.push(...items);if(this.tagName==='select'&&!this.value&&items[0])this.value=items[0].value;}
 replaceChildren(...items){this._text='';this.children=[];this.append(...items);}
 get options(){return this.children;}
 addEventListener(name,handler){this[name]=handler;}
 setAttribute(name,value){this.attributes[name]=String(value);}
 removeAttribute(name){delete this.attributes[name];}
 querySelector(){return this.label||null;}
 showModal(){this.open=true;}
 close(){this.open=false;}
 scrollIntoView(){this.scrolled=true;}
}
function fixture({user={id:'fixture-member',role:'member',approved:true},read,post}={}){
 const nodes=new Map([...html.matchAll(/<(\w+)[^>]*\bid="([^"]+)"/g)].map(match=>[match[2],new Element(match[1])])),calls=[],navigations=[],notices=[],stored=new Map();let sequence=0;
 const buttons=['vpay','gspay','gspay-usdt','1mpay','manual-bank'].map(provider=>{const el=new Element('button');el.dataset.paymentChannel=provider;el.label=new Element('small');return el;});
 const context=vm.createContext({document:{getElementById:id=>nodes.get(id)||null,querySelectorAll:selector=>selector==='[data-payment-channel]'?buttons:[],createElement:tag=>new Element(tag),createTextNode:value=>Object.assign(new Element('#text'),{textContent:value})},window:{location:{assign:url=>navigations.push(url)},scrollTo(){}},location:{pathname:'/',href:'https://fixture.test/'},history:{replaceState(){}},URL,URLSearchParams,AbortController,setTimeout,clearTimeout,crypto:{randomUUID:()=>`synthetic-request-${String(++sequence).padStart(8,'0')}`},sessionStorage:{getItem:key=>stored.get(key)||null,setItem:(key,value)=>stored.set(key,value),removeItem:key=>stored.delete(key)}});
 vm.runInContext(definitions,context);
 const state=vm.runInContext('state',context);state.user=user;state.lang='en';if(user?.role==='member'&&user.approved){state.responsiblePlay={restricted:false,restrictions:{selfExclusion:{active:false},coolingOff:{active:false}},availability:{newDeposits:true,records:true,support:true}};state.responsiblePlayMemberId=user.id;state.responsiblePlayError=false;}
 context.api=async(path,method='GET',payload,timeout)=>{calls.push({path,method,payload:payload===undefined?undefined:JSON.parse(JSON.stringify(payload)),timeout});if(method==='POST')return post?post(path,payload):{id:'fixture-order',status:'awaiting_confirmation',payUrl:null};return read?read(path):{enabled:true,orderReady:true,queryReady:true,tradeCodes:['1']};};
 context.showAuth=()=>notices.push('auth');context.notification=message=>notices.push(message);
 context.selected=section=>{state.section=section;};context.loadMemberWallet=async()=>{};
 context.bindPaymentPreview();
 return {context,state,nodes,calls,navigations,notices,stored,buttons};
}
const entries={vpay:{form:'vpayOrderForm',amount:'vpayAmount',message:'vpayOrderMessage',submit:'submitVPayOrder',url:'https://payment.vpay.club/checkout/fixture'},gspay:{form:'gspayOrderForm',amount:'gspayAmount',message:'gspayOrderMessage',submit:'submitGSPayOrder',url:'https://secured.gspay.online/channel?id=123&key=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'},'1mpay':{form:'oneMpayOrderForm',amount:'oneMpayAmount',message:'oneMpayOrderMessage',submit:'submitOneMpayOrder',url:'https://api.1mpay.net/payment/fixture'}};
const event={preventDefault(){}};
function amount(f,provider){f.nodes.get(entries[provider].amount).value='25.50';if(provider==='vpay'){f.nodes.get('vpayPayerName').value='Fixture Payer';f.nodes.get('vpayTradeCode').value='1';}}

test('manual bank is primary and four independent provider profiles precede separate wallet records',()=>{
 const chooser=html.indexOf('id="paymentLobby"'),wallet=html.indexOf('id="memberWallet"'),cashier=html.indexOf('id="depositCashier"');assert.ok(wallet<chooser&&chooser<cashier);
 assert.ok(html.indexOf('class="cashier-bank-entry"')<html.indexOf('id="paymentButtons"'));
 const primary=html.slice(html.indexOf('id="paymentButtons"'),html.indexOf('class="payment-caveat"'));
 assert.deepEqual([...primary.matchAll(/data-payment-channel="([^"]+)"/g)].map(match=>match[1]),['vpay','gspay','gspay-usdt','1mpay']);
 assert.match(html,/class="button button-primary cashier-bank-option" data-payment-channel="manual-bank"/);
 for(const entry of Object.values(entries))assert.ok(html.indexOf(`id="${entry.form}"`)>cashier);
});

test('GSPAY USDT stays visibly isolated and cannot expose an order form before contract acceptance',async()=>{
 const f=fixture({read:path=>path==='/api/payments/gspay/usdt/status'?{profileId:'gspay_usdt',currency:'USDT',enabled:false,orderReady:false,queryReady:false,callbacksReady:false}:{enabled:true,orderReady:true,queryReady:true,tradeCodes:['1']}});
 await f.buttons.find(button=>button.dataset.paymentChannel==='gspay-usdt').click(event);
 assert.equal(f.state.depositProvider,'gspay-usdt');assert.equal(f.state.gspayUsdtStatus.orderReady,false);
 assert.equal(f.nodes.get('gspayUsdtOrderForm').hidden,true);assert.equal(f.nodes.get('depositCashierCurrency').textContent,'USDT · DEPOSIT');
 assert.match(f.nodes.get('depositCashierStatus').textContent,/unavailable right now/);
 assert.deepEqual(f.calls.map(call=>[call.path,call.method]),[['/api/payments/gspay/usdt/status','GET']]);
});

test('generic company-bank images never enable DuitNow QR while Bank Transfer keeps every enabled account',async()=>{
 const accounts=[
  {id:'bank-only',bank_name:'Bank only',account_name:'MASTER7',account_number:'11111111',image_data:''},
  {id:'bank-with-image',bank_name:'Bank with image',account_name:'MASTER7',account_number:'22222222',image_data:'data:image/png;base64,fixture'},
  {id:'untrusted-qr-claim',bank_name:'Untrusted QR claim',account_name:'MASTER7',account_number:'33333333',image_data:'data:image/png;base64,fixture',duitnowQrReady:true}
 ],f=fixture({read:path=>path==='/api/manual-bank/accounts'?{items:accounts}:{enabled:false,orderReady:false}});
 await f.context.openDepositCashier('duitnow-qr');
 assert.equal(f.nodes.get('manualBankDepositForm').hidden,true);
 assert.deepEqual(f.nodes.get('manualBankAccount').options.map(option=>option.value),[]);
 assert.match(f.nodes.get('depositCashierStatus').textContent,/DuitNow QR has not been configured/);
 await f.context.openDepositCashier('manual-bank');
 assert.deepEqual(f.nodes.get('manualBankAccount').options.map(option=>option.value),['bank-only','bank-with-image','untrusted-qr-claim']);
});

test('DuitNow QR stays closed when only bank-transfer details are configured',async()=>{
 const f=fixture({read:path=>path==='/api/manual-bank/accounts'?{items:[{id:'bank-only',bank_name:'Bank only',account_name:'MASTER7',account_number:'11111111',image_data:''}]}:{enabled:false,orderReady:false}});
 await f.context.openDepositCashier('duitnow-qr');
 assert.equal(f.nodes.get('manualBankDepositForm').hidden,true);
 assert.match(f.nodes.get('depositCashierStatus').textContent,/DuitNow QR has not been configured/);
 await f.context.openDepositCashier('manual-bank');
 assert.equal(f.nodes.get('manualBankDepositForm').hidden,false);
});

for(const [provider,entry]of Object.entries(entries)){
 test(`${provider}: click checks only that provider and opens its required form before any order`,async()=>{
  const f=fixture();await f.buttons.find(button=>button.dataset.paymentChannel===provider).click(event);
  assert.equal(f.state.depositProvider,provider);assert.equal(f.nodes.get('depositCashier').open,true);assert.equal(f.nodes.get(entry.form).hidden,false);
  assert.deepEqual(f.calls.map(call=>call.path),[`/api/payments/${provider}/status`]);assert.equal(f.nodes.get('memberWallet').scrolled,undefined);
  for(const [other,otherEntry]of Object.entries(entries))if(other!==provider)assert.equal(f.nodes.get(otherEntry.form).hidden,true);
 });
 test(`${provider}: original order payload and validated checkout use the same tab with a fallback link`,async()=>{
  const f=fixture({post:()=>({id:'fixture-order',status:'awaiting_payment',payUrl:entry.url})});await f.context.openDepositCashier(provider);amount(f,provider);await f.context[entry.submit](event);
  const orders=f.calls.filter(call=>call.method==='POST');assert.equal(orders.length,1);assert.equal(orders[0].path,`/api/payments/${provider}/orders`);assert.equal(orders[0].payload.amount,'25.50');assert.equal(orders[0].timeout,35000);
  if(provider==='vpay'){assert.equal(orders[0].payload.tradeCode,'1');assert.equal(orders[0].payload.payerName,'Fixture Payer');assert.deepEqual(Object.keys(orders[0].payload).sort(),['amount','payerName','requestKey','tradeCode']);}else assert.deepEqual(Object.keys(orders[0].payload).sort(),['amount','requestKey']);
  assert.deepEqual(f.navigations,[entry.url]);const links=f.nodes.get(entry.message).children.filter(item=>item.tagName==='a');assert.equal(links.length,1);assert.equal(links[0].href,entry.url);assert.equal(links[0].target,undefined);
  assert.equal(f.context.loadDepositAttempt(provider).orderId,'fixture-order');
 });
 test(`${provider}: double click does not create two POSTs and a 409 preserves the original request`,async()=>{
  let reject;const f=fixture({post:()=>new Promise((_,fail)=>{reject=fail;})});await f.context.openDepositCashier(provider);amount(f,provider);
  const first=f.context[entry.submit](event);await f.context[entry.submit](event);assert.equal(f.calls.filter(call=>call.method==='POST').length,1);const key=f.context.loadDepositAttempt(provider).requestKey;
  reject(Object.assign(new Error('Request already in progress'),{status:409,code:'DEPOSIT_REQUEST_IN_PROGRESS'}));await first;assert.equal(f.context.loadDepositAttempt(provider).requestKey,key);assert.match(f.nodes.get(entry.message).textContent,/request is already in progress/);assert.equal(f.calls.filter(call=>call.method==='POST').length,1);assert.deepEqual(f.navigations,[]);
 });
 test(`${provider}: rejected sessions never appear as a recorded payment and unknown network results retain idempotency`,async()=>{
  let fail=Object.assign(new Error('CSRF denied'),{status:403});const f=fixture({post:()=>Promise.reject(fail)});await f.context.openDepositCashier(provider);amount(f,provider);await f.context[entry.submit](event);
  assert.match(f.nodes.get(entry.message).textContent,/session could not authorize/);assert.doesNotMatch(f.nodes.get(entry.message).textContent,/request recorded|Payment confirmation is pending|CSRF/);
  const key=f.context.loadDepositAttempt(provider).requestKey;fail=Object.assign(new Error('synthetic timeout'),{connectionFailure:true});await f.context[entry.submit](event);
  assert.equal(f.context.loadDepositAttempt(provider).requestKey,key);assert.match(f.nodes.get(entry.message).textContent,/result could not be confirmed/);assert.deepEqual(f.calls.filter(call=>call.method==='POST').map(call=>call.payload.requestKey),[key,key]);assert.deepEqual(f.navigations,[]);
 });
 test(`${provider}: unsafe payment links cannot navigate and only final rejection releases an attempt`,async()=>{
  let result={id:'fixture-order',status:'awaiting_payment',payUrl:'https://untrusted.example/payment'};const f=fixture({post:()=>result});await f.context.openDepositCashier(provider);amount(f,provider);await f.context[entry.submit](event);
  assert.deepEqual(f.navigations,[]);assert.match(f.nodes.get(entry.message).textContent,/valid payment page/);assert.ok(f.context.loadDepositAttempt(provider));
  result=Promise.reject(Object.assign(new Error('PROVIDER_REJECTED'),{status:422}));await f.context[entry.submit](event);assert.equal(f.context.loadDepositAttempt(provider),null);assert.match(f.nodes.get(entry.message).textContent,/provider declined/);
 });
}

test('anonymous, staff and unapproved accounts receive a clear explanation without calling order APIs',async()=>{
 for(const user of [null,{id:'staff',role:'staff',approved:true},{id:'pending',role:'member',approved:false}]){
  const f=fixture({user});await f.context.openDepositCashier('vpay');assert.equal(f.calls.length,0);
  if(!user)assert.deepEqual(f.notices,['auth']);else if(user.role==='staff')assert.match(f.notices[0],/member accounts/);else{assert.equal(f.nodes.get('depositCashier').open,true);assert.match(f.nodes.get('depositCashierStatus').textContent,/awaiting approval/);assert.equal(f.nodes.get('vpayOrderForm').hidden,true);}
 }
});

test('active self-exclusion and cooling-off disable every deposit card before submit while records and support remain available',async()=>{
 assert.match(source,/api\("\/api\/responsible-play"\)/);
 for(const [kind,phrase] of [['selfExclusion',/self-exclusion/],['coolingOff',/cooling-off/]]){
  const f=fixture();f.state.paymentStatus={orderReady:true};f.state.gspayStatus={orderReady:true};f.state.gspayUsdtStatus={orderReady:true};f.state.oneMpayStatus={orderReady:true};f.state.responsiblePlay={restricted:true,restrictions:{selfExclusion:{active:kind==='selfExclusion'},coolingOff:{active:kind==='coolingOff'}},availability:{newDeposits:false,records:true,support:true}};
  f.context.renderPaymentPreview();for(const button of f.buttons){assert.equal(button.disabled,true);assert.equal(button.attributes['aria-disabled'],'true');assert.match(button.label.textContent,phrase);}
  await f.context.openDepositCashier('vpay');assert.equal(f.calls.length,0);assert.equal(f.nodes.get('vpayOrderForm').hidden,true);assert.equal(f.nodes.get('vpaySubmit').disabled,true);assert.equal(f.nodes.get('depositCashierRecords').disabled,false);assert.match(f.nodes.get('depositCashierStatus').textContent,phrase);
  amount(f,'vpay');await f.context.submitVPayOrder(event);assert.equal(f.calls.filter(call=>call.method==='POST').length,0);assert.match(f.nodes.get('vpayOrderMessage').textContent,phrase);
  assert.match(html,/data-section="support"/);assert.equal(f.state.responsiblePlay.availability.records,true);assert.equal(f.state.responsiblePlay.availability.support,true);
 }
});

test('unavailable selected providers never switch brands; missing channels and failed reads are explicit',async()=>{
 for(const response of [{enabled:true,orderReady:false,tradeCodes:['1']},{enabled:true,orderReady:true,tradeCodes:[]}]){
  const f=fixture({read:()=>response});f.state.oneMpayStatus={orderReady:true};await f.context.openDepositCashier('vpay');assert.equal(f.state.depositProvider,'vpay');assert.equal(f.nodes.get('vpayOrderForm').hidden,true);assert.match(f.nodes.get('depositCashierStatus').textContent,response.orderReady?/No payment channels/:/unavailable right now/);
 }
 const f=fixture({read:()=>Promise.reject(new Error('offline'))});await f.context.openDepositCashier('gspay');assert.match(f.nodes.get('depositCashierStatus').textContent,/could not be checked/);assert.equal(f.nodes.get('depositCashierRetry').hidden,false);assert.equal(f.state.gspayStatus,null);
});

test('a late status response cannot replace the brand selected more recently',async()=>{
 let finish;const f=fixture({read:path=>path.includes('/vpay/')?new Promise(resolve=>{finish=resolve;}):{orderReady:true,enabled:true}});const first=f.context.openDepositCashier('vpay');await f.context.openDepositCashier('gspay');finish({orderReady:true,tradeCodes:['1']});await first;
 assert.equal(f.state.depositProvider,'gspay');assert.equal(f.nodes.get('gspayOrderForm').hidden,false);assert.equal(f.nodes.get('vpayOrderForm').hidden,true);
});

for(const [provider,entry]of Object.entries(entries)){
 test(`${provider}: delayed member-A results never reach logged-out or member-B accounts`,async()=>{
  for(const nextUser of [null,{id:'member-b',role:'member',approved:true}])for(const fail of [false,true]){
   let resolve,reject;const f=fixture({post:()=>new Promise((yes,no)=>{resolve=yes;reject=no;})});await f.context.openDepositCashier(provider);amount(f,provider);const pending=f.context[entry.submit](event),oldKey=f.context.loadDepositAttempt(provider).requestKey;
   f.state.user=nextUser;f.context.renderDepositCashier();assert.equal(f.nodes.get('depositCashier').open,false);assert.equal(f.nodes.get(entry.message).textContent,'');
   if(fail)reject(Object.assign(new Error('PROVIDER_REJECTED'),{status:422}));else resolve({id:'member-a-order',status:'awaiting_payment',payUrl:entry.url});await pending;
   assert.deepEqual(f.navigations,[]);assert.equal(f.nodes.get(entry.message).textContent,'');assert.equal(f.context.loadDepositAttempt(provider),null);
   assert.equal(JSON.parse(f.stored.get(`m7-${provider}-order-fixture-member`)).requestKey,oldKey);assert.equal(f.stored.has(`m7-${provider}-order-member-b`),false);
  }
 });
 test(`${provider}: attempts are member-scoped and a legacy saved key migrates only for its owner`,()=>{
  const f=fixture(),a=f.context.depositAttemptFor(provider,'amount','10.00');f.state.user={id:'member-b',role:'member',approved:true};assert.equal(f.context.loadDepositAttempt(provider),null);
  const b=f.context.depositAttemptFor(provider,'amount','10.00');assert.notEqual(a.requestKey,b.requestKey);assert.equal(b.memberId,'member-b');assert.equal(b.storageKey,`m7-${provider}-order-member-b`);
  f.state.user={id:'fixture-member',role:'member',approved:true};assert.equal(f.context.loadDepositAttempt(provider).requestKey,a.requestKey);
  f.state.user={id:'legacy-member',role:'member',approved:true};f.stored.set(`m7-${provider}-order-legacy-member`,JSON.stringify({amount:'20.00',requestKey:'legacy-request'}));const legacy=f.context.loadDepositAttempt(provider);
  assert.equal(legacy.requestKey,'legacy-request');assert.equal(legacy.memberId,'legacy-member');assert.equal(legacy.storageKey,`m7-${provider}-order-legacy-member`);
 });
}

test('409 reasons retain safe codes, distinguish restrictions, and never release or retry the request',async()=>{
 for(const [code,phrase]of Object.entries({SELF_EXCLUSION_ACTIVE:'self-exclusion',COOLING_OFF_ACTIVE:'cooling-off',DAILY_DEPOSIT_LIMIT:'daily deposit limit',WEEKLY_DEPOSIT_LIMIT:'weekly deposit limit',MONTHLY_DEPOSIT_LIMIT:'monthly deposit limit',DEPOSIT_LIMIT:'deposit limit',DEPOSIT_REQUEST_IN_PROGRESS:'already in progress',IDEMPOTENCY_CONFLICT:'different details'})){
  const f=fixture({post:()=>Promise.reject(Object.assign(new Error(code),{status:409,code}))});await f.context.openDepositCashier('vpay');amount(f,'vpay');await f.context.submitVPayOrder(event);
  const message=f.nodes.get('vpayOrderMessage').textContent;assert.ok(message.includes(phrase));assert.ok(message.includes(code));assert.ok(f.context.loadDepositAttempt('vpay').requestKey);assert.equal(f.calls.filter(call=>call.method==='POST').length,1);
 }
});

test('the API helper preserves safe application codes for structured and legacy conflicts',async()=>{
 const start=source.indexOf('async function api('),end=source.indexOf('\nfunction ',start),apiSource=source.slice(start,end);
 for(const body of [{error:'This request is already in progress',code:'DEPOSIT_REQUEST_IN_PROGRESS'},{error:'IDEMPOTENCY_CONFLICT'}]){
  const context={state:{csrf:'fixture-csrf'},t:key=>key,AbortController,setTimeout,clearTimeout,fetch:async()=>({ok:false,status:409,headers:{get:()=> 'application/json'},json:async()=>body})};vm.runInNewContext(apiSource,context);
  await assert.rejects(context.api('/api/payments/vpay/orders','POST',{}),error=>error.status===409&&error.code===(body.code||body.error)&&error.message===body.error);
 }
});

test('identity changes clear manual-bank inputs without firing its request-key reset handler',async()=>{
 const f=fixture();await f.context.openDepositCashier('vpay');let resets=0;f.nodes.get('manualBankDepositForm').reset=()=>{resets++;};f.nodes.get('manualBankAmount').value='88.00';f.nodes.get('manualBankReceipt').value='synthetic-receipt';
 f.state.user={id:'member-b',role:'member',approved:true};f.context.renderDepositCashier();assert.equal(resets,0);assert.equal(f.nodes.get('manualBankAmount').value,'');assert.equal(f.nodes.get('manualBankReceipt').value,'');
});

test('each cashier explains a review requirement in the selected language without navigating or losing its request key',async()=>{
 for(const [provider,entry] of Object.entries(entries))for(const [language,expected] of [['en',/request identity and risk review/],['zh',/申请身份及风险审核/],['ms',/mohon semakan identiti dan risiko/]]){
  const failure=Object.assign(new Error('Complete identity and risk review before this action'),{status:403,code:'COMPLIANCE_REVIEW_REQUIRED'});
  const f=fixture({post:()=>Promise.reject(failure)});f.state.lang=language;await f.context.openDepositCashier(provider);amount(f,provider);await f.context[entry.submit](event);
  assert.match(f.nodes.get(entry.message).textContent,expected,`${provider} ${language}`);assert.ok(f.context.loadDepositAttempt(provider)?.requestKey);assert.deepEqual(f.navigations,[]);
 }
});
