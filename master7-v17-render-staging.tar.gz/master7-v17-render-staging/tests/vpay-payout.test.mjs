import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {vpayPayoutSupportsBank} from '../lib/vpay-payout.ts';

// All VPay replies are synthetic. This suite never sends a real payout.
const origin='https://portal.example.test',gateway='https://master7-integration-gateway.onrender.com',uatGateway='https://master7-payment-uat.onrender.com',stagingOrigin='https://master7-v17-staging.onrender.com',payoutToken='payout-token-'.padEnd(40,'p'),callbackToken='callback-token-'.padEnd(40,'c'),dataKey='withdrawal-key-'.padEnd(40,'w');

function fixture(t,{enabled=true,gatewayUrl=gateway,portalOrigin=origin,mode='production',returnUrl=portalOrigin+'/payment/return',allowedOrigins=[portalOrigin],newPayoutsEnabled='true',uatGate=gatewayUrl===uatGateway&&mode==='uat'}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf-alice',0),('owner','owner','owner',1,'csrf-owner',0);UPDATE payment_channel_controls SET status='active' WHERE provider_id='vpay';INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fund','alice','funding-request','f','vpay',10000,'MYR','2','credited',0,0);INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('member','fund','alice','member',10000,'MYR',0),('clearing','fund','alice','provider_clearing',-10000,'MYR',0)");
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const results=statements.map(statement=>sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return results;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 sql.exec("INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('alice','passed','passed',1,'c',0,0)");
 const uat={memberId:'alice',withdrawalId:'uat-withdrawal-00000001',payoutId:'P7uatpayout0000000000000000000001',amountMinor:'2000',expiresAt:String(Math.floor(Date.now()/1000)+600)};
 const state={submits:0,queries:0,payoutState:'3',amount:'20.00',gatewayOrigins:[]};
 const config={db,identity:{userId:'alice',email:'alice@example.test'},ownerEmail:'',allowedOrigins,newPayoutsEnabled,withdrawalDataKey:dataKey,vpayGatewayUrl:gatewayUrl,vpayPayoutToken:payoutToken,vpayCallbackToken:callbackToken,vpayPayoutEnabled:enabled?'true':'false',vpayTraderId:'3647',vpayMode:mode,vpayReturnUrl:returnUrl,...(uatGate?{vpayUatPayoutMemberId:uat.memberId,vpayUatWithdrawalId:uat.withdrawalId,vpayUatPayoutId:uat.payoutId,vpayUatPayoutAmountMinor:uat.amountMinor,vpayUatPayoutExpiresAt:uat.expiresAt}:{}),vpayFetch:async(input,init)=>{
  const url=new URL(String(input)),body=JSON.parse(init.body);state.gatewayOrigins.push(url.origin);assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+payoutToken);
  if(url.pathname==='/platform/vpay/withdrawal'){state.submits++;assert.deepEqual(body,{contract:'vpay-payout-v1',currency:'MYR',...(uatGate?{memberId:uat.memberId,withdrawalId:uat.withdrawalId}:{}),refId:body.refId,amount:'20.00',bankName:'MBB',accountName:'Alice Example',accountNumber:'123456789012'});if(state.createHook)await state.createHook();return Response.json({provider:'vpay',upstreamStatus:200,result:{code:0,data:{money_id:'provider_123',out_money_id:body.refId}}});}
  assert.equal(url.pathname,'/platform/vpay/withdrawal-query');state.queries++;const queryState=state.payoutState;if(state.queryHook)await state.queryHook(queryState);return Response.json({provider:'vpay',upstreamStatus:200,result:{code:0,data:{out_money_id:body.outMoneyId,state:queryState,amount:state.amount,service_fee:'0.50'}}});
 }};
 async function call(path,{who='alice',method='GET',data,headers={},extra={}}={}){const response=await handle(new Request(portalOrigin+path,{method,headers:{Origin:portalOrigin,'Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,...headers},...(data===undefined?{}:{body:JSON.stringify(data)})}),{...config,identity:who?{userId:who,email:who+'@example.test'}:null,...extra});return {status:response.status,data:response.headers.get('content-type')?.includes('json')?await response.json():await response.text()};}
 async function createAndApprove(options){
  const created=await call('/api/withdrawals',options);
  if(created.status!==201)return created;
  assert.equal(created.data.status,'pending');
  const list=await call('/api/admin/withdrawals',{who:'owner'});assert.equal(list.status,200);
  const reviewed=list.data.items.find(item=>item.id===created.data.withdrawal.id);assert.equal(reviewed.approvalEligible,true);
  assert.equal(reviewed.accountHolder,'Alice Example');assert.equal(reviewed.accountNumber,undefined);assert.equal(reviewed.accountLast4,'9012');
  const encrypted=sql.prepare('SELECT account_holder_encrypted,account_number_encrypted FROM withdrawal_requests WHERE id=?').get(reviewed.id),serialized=JSON.stringify(list.data);
  assert.ok(!serialized.includes('123456789012'));assert.ok(!serialized.includes(encrypted.account_holder_encrypted));assert.ok(!serialized.includes(encrypted.account_number_encrypted));
  const approval={id:reviewed.id,approvalFingerprint:reviewed.approvalFingerprint,ownerNote:'Synthetic test approval'};assert.deepEqual(Object.keys(approval).sort(),['approvalFingerprint','id','ownerNote']);
  const approved=await call('/api/admin/withdrawals/approve',{who:'owner',method:'POST',data:approval});
  assert.equal(approved.status,202);return approved;
 }
 const payload=(patch={})=>({providerId:'vpay',bankCode:'maybank',accountHolder:'Alice Example',accountNumber:'1234-5678-9012',amount:'20.00',requestKey:'vpay-payout-request-0001',...patch});
 async function callback(patch={}){const payout=sql.prepare("SELECT id FROM provider_payouts WHERE provider_id='vpay'").get();return call('/api/payment-callbacks/vpay/withdrawal',{method:'POST',headers:{Authorization:'Bearer '+callbackToken},data:{trader_id:'3647',money_id:'provider_123',out_money_id:payout.id,state:state.payoutState,amount:state.amount,notify_time:'2026-11-07 12:00:00',...patch},extra:{identity:null}});}
 t.after(()=>sql.close());return {sql,state,config,uat,call,createAndApprove,payload,callback};
}

test('VPay payout is closed until its separate switch is enabled',async t=>{const f=fixture(t,{enabled:false}),result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.status,503);assert.equal(f.state.submits,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,0);});

test('VPay stores its provider money ID separately and repeated callbacks preserve one debit',async t=>{
 const f=fixture(t);await f.createAndApprove({method:'POST',data:f.payload()});
 const payout=f.sql.prepare('SELECT id,provider_reference,provider_money_id FROM provider_payouts').get();
 assert.equal(payout.provider_money_id,'provider_123');assert.equal(payout.provider_reference,payout.id);
 for(let i=0;i<2;i++)assert.deepEqual(await f.callback(),{status:200,data:'SUCCESS'});
 const list=await f.call('/api/admin/withdrawals',{who:'owner'});assert.equal(list.data.items[0].providerMoneyId,'provider_123');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests WHERE status=\'paid\'').get().n,1);
 assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});

test('VPay rejects unsupported banks before reserving or submitting funds',async t=>{
 const f=fixture(t),result=await f.call('/api/withdrawals',{method:'POST',data:f.payload({bankCode:'mbsb'})});
 assert.equal(result.status,400);assert.equal(f.state.submits,0);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
});

test('VPay callback with another provider money ID requires review and preserves held funds',async t=>{
 const f=fixture(t);f.state.payoutState='1';await f.createAndApprove({method:'POST',data:f.payload()});
 const before=f.state.queries;f.state.payoutState='3';assert.equal((await f.callback({money_id:'provider_other'})).status,409);
 assert.equal(f.state.queries,before);assert.equal(f.sql.prepare('SELECT provider_money_id FROM provider_payouts').get().provider_money_id,'provider_123');
 assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
 assert.equal((await f.call('/api/wallet')).data.balanceMinor,'10000');
});

test('VPay binds a provider money ID from a callback when the create response was lost',async t=>{
 const f=fixture(t);f.state.payoutState='1';await f.createAndApprove({method:'POST',data:f.payload()});
 f.sql.prepare("UPDATE provider_payouts SET provider_money_id=NULL,create_outcome='unknown'").run();
 for(const money_id of [undefined,'','bad/id'])assert.equal((await f.callback({money_id})).status,400);
 f.state.payoutState='3';assert.equal((await f.callback()).status,200);
 assert.equal(f.sql.prepare('SELECT provider_money_id FROM provider_payouts').get().provider_money_id,'provider_123');
});

test('VPay does not reuse one provider money ID for two payouts',async t=>{
 const f=fixture(t);await f.createAndApprove({method:'POST',data:f.payload()});
 const second=await f.createAndApprove({method:'POST',data:f.payload({requestKey:'vpay-payout-request-0002'})});
 assert.equal(second.data.status,'review');assert.equal(f.state.queries,1);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM provider_payouts WHERE provider_money_id='provider_123'").get().n,1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
});

for(const conflicting of [false,true])test(`VPay callback arriving before the create response ${conflicting?'rejects a conflicting':'preserves the same'} provider money ID`,async t=>{
 const f=fixture(t);f.state.createHook=async()=>{assert.equal((await f.callback({money_id:conflicting?'provider_other':'provider_123'})).status,200);};
 const result=await f.createAndApprove({method:'POST',data:f.payload()});
 assert.equal(result.data.status,conflicting?'review':'paid');
 assert.equal(f.sql.prepare('SELECT provider_money_id FROM provider_payouts').get().provider_money_id,conflicting?'provider_other':'provider_123');
 assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});

test('isolated Staging VPay payout uses only the exact UAT Gateway',async t=>{
 const f=fixture(t,{gatewayUrl:uatGateway,portalOrigin:stagingOrigin,mode:'uat'}),result=await f.createAndApprove({method:'POST',data:f.payload()});
 assert.equal(result.status,202);assert.equal(result.data.status,'paid');assert.deepEqual([...new Set(f.state.gatewayOrigins)],[uatGateway]);
});

test('isolated UAT opens one fixed payout while global payouts stay paused and rejects every other scope',async t=>{
 const f=fixture(t,{gatewayUrl:uatGateway,portalOrigin:stagingOrigin,mode:'uat',newPayoutsEnabled:'false'});
 assert.equal((await f.call('/api/withdrawal-banks')).data.providers.find(item=>item.id==='vpay').enabled,true);
 f.sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('bob','bob','member',1,'csrf-bob',0)").run();
 const denied=await f.call('/api/withdrawals',{who:'bob',method:'POST',data:f.payload({requestKey:'vpay-payout-bob-000001'})});assert.equal(denied.status,403);assert.equal(denied.data.code,'VPAY_UAT_PAYOUT_MEMBER_DENIED');
 const wrongAmount=await f.call('/api/withdrawals',{method:'POST',data:f.payload({amount:'21.00'})});assert.equal(wrongAmount.status,400);assert.equal(wrongAmount.data.code,'VPAY_UAT_PAYOUT_SCOPE_MISMATCH');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,0);assert.equal(f.state.submits,0);
 const first=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(first.status,202);assert.equal(first.data.status,'paid');
 const stored=f.sql.prepare('SELECT w.id,p.id payout_id FROM withdrawal_requests w JOIN provider_payouts p ON p.withdrawal_id=w.id').get();assert.equal(stored.id,f.uat.withdrawalId);assert.equal(stored.payout_id,f.uat.payoutId);
 const replay=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(replay.status,200);assert.equal(replay.data.status,'paid');
 const rebound=await f.call('/api/withdrawals',{method:'POST',data:f.payload({requestKey:'vpay-payout-request-0002'})});assert.equal(rebound.status,409);assert.equal(rebound.data.code,'VPAY_UAT_PAYOUT_ALREADY_BOUND');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM provider_payouts').get().n,1);assert.equal(f.state.submits,1);assert.equal(f.state.queries,1);
});

for(const scenario of [
 {name:'production mode',options:{gatewayUrl:uatGateway,portalOrigin:stagingOrigin,mode:'production'}},
 {name:'production portal',options:{gatewayUrl:uatGateway,portalOrigin:'https://www.master7.best',mode:'uat',returnUrl:stagingOrigin+'/payment/return'}},
 {name:'mixed portal origins',options:{gatewayUrl:uatGateway,portalOrigin:stagingOrigin,mode:'uat',allowedOrigins:[stagingOrigin,'https://www.master7.best']}},
])test(`isolated VPay payout rejects UAT Gateway with ${scenario.name} before network`,async t=>{
 const f=fixture(t,scenario.options),banks=await f.call('/api/withdrawal-banks');
 assert.equal(banks.status,200);assert.equal(banks.data.providers.find(item=>item.id==='vpay').enabled,false);assert.deepEqual(f.state.gatewayOrigins,[]);
});

test('owner list keeps corrupt or ineligible recipient data redacted without failing the list',async t=>{
 const f=fixture(t),created=await f.call('/api/withdrawals',{method:'POST',data:f.payload()});assert.equal(created.status,201);
 f.sql.prepare("UPDATE withdrawal_requests SET account_number_encrypted='corrupt',status='processing' WHERE id=?").run(created.data.withdrawal.id);
 const list=await f.call('/api/admin/withdrawals',{who:'owner'});assert.equal(list.status,200);
 const item=list.data.items.find(value=>value.id===created.data.withdrawal.id);assert.equal(item.approvalEligible,false);assert.equal(item.accountHolder,undefined);assert.equal(item.accountNumber,undefined);assert.equal(item.accountLast4,'9012');assert.equal(item.approvalFingerprint,undefined);
 const serialized=JSON.stringify(list.data);assert.ok(!serialized.includes('123456789012'));assert.ok(!serialized.includes('corrupt'));
});

test('VPay payout submits, independently queries and debits the wallet exactly once',async t=>{const f=fixture(t),first=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(first.status,202);assert.equal(first.data.status,'paid');assert.equal(f.state.submits,1);assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'succeeded');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');const replay=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(replay.status,200);assert.equal(f.state.submits,1);assert.equal(f.state.queries,1);});

test('pending VPay callback must query before it can mark a withdrawal paid',async t=>{const f=fixture(t);f.state.payoutState='1';const created=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(created.status,202);assert.equal(created.data.status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);f.state.payoutState='3';const before=f.state.queries,result=await f.callback();assert.deepEqual(result,{status:200,data:'SUCCESS'});assert.equal(f.state.queries,before+1);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');});

test('VPay rejection requires review and retains the held amount',async t=>{const f=fixture(t);f.state.payoutState='2';const result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.status,202);assert.equal(result.data.status,'review');assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await f.call('/api/wallet')).data.availableMinor,'0');const next=f.payload({requestKey:'vpay-payout-request-0002',bankCode:'mbsb'}),unsupported=await f.call('/api/withdrawals',{method:'POST',data:next});assert.equal(unsupported.status,400);assert.equal(f.state.submits,1);});

function gate(){let release,signal;return {ready:new Promise(r=>{signal=r;}),wait:new Promise(r=>{release=r;}),signal:()=>signal(),release:()=>release()};}

test('a delayed VPay failure cannot mark a payout using the former member guard after its owner changes',async t=>{
 const f=fixture(t);f.state.payoutState='1';await f.createAndApprove({method:'POST',data:f.payload()});
 const delayed=gate();f.state.queryHook=async state=>{if(state==='2'){delayed.signal();await delayed.wait;}};
 f.state.payoutState='2';const pending=f.callback();await delayed.ready;
 f.sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('bob','bob','member',1,'csrf-bob',0)").run();
 f.sql.prepare("UPDATE withdrawal_requests SET user_id='bob'").run();delayed.release();
 assert.equal((await pending).status,503);
 assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'processing');
 assert.equal(f.sql.prepare('SELECT user_id FROM wallet_reservations').get().user_id,'alice');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_payout_review'").get().n,0);
});

test('VPay late failure after a successful query keeps the debit and flags review',async t=>{
 const f=fixture(t);f.state.payoutState='1';await f.createAndApprove({method:'POST',data:f.payload()});const delayed=gate();f.state.queryHook=async state=>{if(state==='2'){delayed.signal();await delayed.wait;}};
 f.state.payoutState='2';const failed=f.callback();await delayed.ready;f.state.payoutState='3';assert.equal((await f.callback()).status,200);delayed.release();assert.equal((await failed).status,503);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});

test('VPay late success after failure review cannot release or debit the held funds',async t=>{
 const f=fixture(t);f.state.payoutState='1';await f.createAndApprove({method:'POST',data:f.payload()});const delayed=gate();f.state.queryHook=async state=>{if(state==='3'){delayed.signal();await delayed.wait;}};
 f.state.payoutState='3';const succeeded=f.callback();await delayed.ready;f.state.payoutState='2';assert.equal((await f.callback()).status,503);delayed.release();assert.equal((await succeeded).status,503);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal((await f.call('/api/wallet')).data.availableMinor,'0');
});

test('VPay reversal after payout requires review without crediting the wallet',async t=>{
 const f=fixture(t);await f.createAndApprove({method:'POST',data:f.payload()});f.state.payoutState='6';assert.equal((await f.callback()).status,503);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});

test('VPay success with missing reservation remains in review and never reports paid',async t=>{
 const f=fixture(t);f.state.payoutState='1';await f.createAndApprove({method:'POST',data:f.payload()});f.sql.prepare('DELETE FROM wallet_reservations').run();f.state.payoutState='3';assert.equal((await f.callback()).status,503);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal((await f.call('/api/wallet')).data.balanceMinor,'10000');
});

for(const scenario of [
 {name:'amount',mutate:sql=>sql.prepare("UPDATE withdrawal_requests SET amount_minor=2100").run()},
 {name:'member',mutate:sql=>{sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('bob','bob','member',1,'csrf-bob',0)").run();sql.prepare("UPDATE withdrawal_requests SET user_id='bob'").run();}},
 {name:'withdrawal currency',mutate:sql=>{sql.exec('PRAGMA ignore_check_constraints=ON');sql.prepare("UPDATE withdrawal_requests SET currency='USD'").run();}},
 {name:'payout currency',mutate:sql=>{sql.exec('PRAGMA ignore_check_constraints=ON');sql.prepare("UPDATE provider_payouts SET currency='USD'").run();}},
 {name:'create outcome',mutate:sql=>sql.prepare("UPDATE provider_payouts SET create_outcome='unknown'").run()},
 {name:'error code',mutate:sql=>sql.prepare("UPDATE provider_payouts SET last_error_code='historical_conflict'").run()},
 {name:'provider reference',mutate:sql=>sql.prepare("UPDATE provider_payouts SET provider_reference='other-reference'").run()},
 {name:'missing provider reference',mutate:sql=>sql.prepare("UPDATE provider_payouts SET provider_reference=NULL").run()},
])test(`VPay historical paid result with mismatched ${scenario.name} is not reported as success`,async t=>{
 const f=fixture(t);await f.createAndApprove({method:'POST',data:f.payload()});scenario.mutate(f.sql);assert.equal((await f.callback()).status,503);
 assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal(f.sql.prepare('SELECT status FROM provider_payouts').get().status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
});

test('VPay callback authentication and amount binding fail closed',async t=>{const f=fixture(t);f.state.payoutState='1';await f.createAndApprove({method:'POST',data:f.payload()});let result=await f.call('/api/payment-callbacks/vpay/withdrawal',{method:'POST',headers:{Authorization:'Bearer wrong'},data:{trader_id:'3647',out_money_id:f.sql.prepare('SELECT id FROM provider_payouts').get().id,state:'3',amount:'20.00'},extra:{identity:null}});assert.equal(result.status,401);result=await f.callback({amount:'21.00'});assert.equal(result.status,409);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);});

test('global payout maintenance prevents new submissions while a pending VPay payout can finish',async t=>{
 const f=fixture(t);f.state.payoutState='1';const created=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(created.status,202);assert.equal(f.state.submits,1);
 f.config.newPayoutsEnabled='false';const banks=await f.call('/api/withdrawal-banks');assert.equal(banks.data.providers.find(x=>x.id==='vpay').enabled,false);
 const blocked=await f.call('/api/withdrawals',{method:'POST',data:f.payload({requestKey:'vpay-payout-request-0002'})});assert.equal(blocked.status,503);assert.equal(f.state.submits,1);
 f.state.payoutState='3';assert.equal((await f.callback()).status,200);assert.equal((await f.callback()).status,200);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'paid');assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');
});

// Current official docs accept integer or up to two decimal digits for replies.
test('documented Bank Rakyat mapping is available',()=>{assert.equal(vpayPayoutSupportsBank('bank_rakyat'),true);});
for(const amount of ['20','20.0',20])test(`VPay accepts an exact documented amount representation: ${amount}`,async t=>{const f=fixture(t);f.state.amount=amount;const result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.data.status,'paid');assert.equal((await f.call('/api/wallet')).data.balanceMinor,'8000');assert.deepEqual(await f.callback(),{status:200,data:'SUCCESS'});});
for(const amount of ['20.001',20.001,'2e1','020.00'])test(`VPay rejects a non-exact amount without debiting: ${amount}`,async t=>{const f=fixture(t);f.state.amount=amount;const result=await f.createAndApprove({method:'POST',data:f.payload()});assert.equal(result.data.status,'review');assert.equal((await f.call('/api/wallet')).data.balanceMinor,'10000');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);});
