import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

test('META deadlines, body cancellation and size limits work in Cloudflare workerd', { timeout: 30_000 }, async () => {
  const require = createRequire(import.meta.url);
  const runtimeRequire = createRequire(require.resolve('wrangler/package.json'));
  const { Miniflare } = runtimeRequire('miniflare');
  const { build } = runtimeRequire('esbuild');
  const directory = mkdtempSync(join(tmpdir(), 'master7-meta-timeout-'));
  const entry = join(directory, 'worker.ts'), output = join(directory, 'worker.mjs');
  const adapterPath = fileURLToPath(new URL('../lib/metagaming-provider-adapter.ts', import.meta.url));
  const registryPath = fileURLToPath(new URL('../lib/game-provider-registry.ts', import.meta.url));
  let mf;
  try {
    writeFileSync(entry, `
import {createMetaGamingProviderAdapter,metaGamingPlayerId} from ${JSON.stringify(adapterPath)};
import {getGameProviderProfile} from ${JSON.stringify(registryPath)};
export default {async fetch(req){
 const scenario=new URL(req.url).searchParams.get('scenario');let calls=0,cancelled=false,signal;
 const transport=async(url,init)=>{
  calls++;signal=init.signal;
  if(scenario==='body'||scenario==='oversized')return new Response(new ReadableStream({
   start(controller){if(scenario==='oversized'){controller.enqueue(new Uint8Array(1024*1024));controller.enqueue(new Uint8Array(1024*1024+1));}else controller.enqueue(new TextEncoder().encode('{'));},
   cancel(){cancelled=true;}
  }));
  return new Promise(()=>{});
 };
 const profile='metagaming_normal_myr',adapter=createMetaGamingProviderAdapter({profile,account:'normal',baseUrl:'https://gateway.example.test',currency:'MYR',playerToken:'p'.repeat(48),walletToken:'w'.repeat(48),recoveryToken:'r'.repeat(48),reportToken:'l'.repeat(48),launchOrigins:['https://games.example.test']},{fetchImpl:transport,allowedReturnOrigins:['https://www.master7.best'],merchantContractVerified:true,sessionClosureVerified:true,balanceEnabled:true,depositEnabled:true,timeoutMs:scenario==='oversized'?500:25});
 const ctx={profile:getGameProviderProfile(profile)},input={userId:'synthetic-member',providerPlayerId:metaGamingPlayerId(profile,'synthetic-member'),platformTransactionId:'synthetic-original-transfer',amountMinor:'2000',currency:'MYR'};
 try{if(scenario==='deposit')await adapter.depositToGame(ctx,input);else await adapter.queryBalance(ctx,input);return Response.json({error:'Unexpected success',calls});}
 catch(e){return Response.json({code:e.code,calls,cancelled,aborted:signal?.aborted??false});}
}};
`);
    await build({ entryPoints: [entry], outfile: output, bundle: true, format: 'esm', platform: 'neutral', target: 'es2022', external: ['node:*'] });
    mf = new Miniflare({ rootPath: directory, modulesRoot: directory, modules: true, scriptPath: output, compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'] });
    for (const scenario of ['headers', 'body', 'deposit', 'oversized']) {
      const response = await mf.dispatchFetch('https://isolated.example.test/?scenario=' + scenario);
      const result = await response.json();
      assert.equal(result.code, scenario === 'oversized' ? 'META_GATEWAY_RESPONSE_INVALID' : 'META_GATEWAY_TIMEOUT', scenario + ': ' + JSON.stringify(result));
      assert.equal(result.calls, 1);
      if (scenario !== 'oversized') assert.equal(result.aborted, true);
      if (scenario === 'body' || scenario === 'oversized') assert.equal(result.cancelled, true);
    }
  } finally {
    if (mf) await mf.dispose();
    rmSync(directory, { recursive: true, force: true });
  }
});
