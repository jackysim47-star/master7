import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const script=readFileSync(new URL('../public/assets/production-acceptance-console.js',import.meta.url),'utf8');

test('game acceptance console can record UAT separately from production',()=>{
 assert.match(html,/id="gameAcceptanceEnvironment"/);
 assert.match(html,/value="uat">UAT \/ 测试/);
 assert.match(html,/value="production">Production \/ 生产/);
 assert.match(script,/game-acceptance\?environment=uat&limit=0/);
 assert.match(script,/environment,result:\$\('gameAcceptanceResult'\)\.value/);
 assert.match(script,/只记录 UAT 测试证据，不会开启生产游戏/);
});

test('payment acceptance console can record UAT separately from production',()=>{
 assert.match(html,/id="productionAcceptanceEnvironment"/);
 assert.match(html,/id="productionAcceptanceEnvironmentNotice"/);
 assert.match(script,/production-acceptance\?environment=uat&limit=100/);
 assert.match(script,/environment:acceptanceEnvironment\(\)/);
 assert.match(script,/只记录 UAT 支付测试证据，不会开启充值或提款/);
});
