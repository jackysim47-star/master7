import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {applyWhatsAppWebhook,authorizeWhatsAppWorker,dispatchWhatsAppCampaigns,launchWhatsAppCampaign,WhatsAppCampaignError,whatsappCampaignStatus} from '../lib/whatsapp-campaign.ts';

class Statement{
 constructor(database,sql,args=[]){this.database=database;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.database,this.sql,args);}
 async first(){return this.database.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.database.prepare(this.sql).all(...this.args),success:true,meta:{changes:0}};}
 async run(){const value=this.database.prepare(this.sql).run(...this.args);return {results:[],success:true,meta:{changes:Number(value.changes)}};}
 execute(){const statement=this.database.prepare(this.sql);if(/^\s*(?:SELECT|WITH)\b/i.test(this.sql)&&!/\b(?:INSERT|UPDATE|DELETE)\b/i.test(this.sql))return {results:statement.all(...this.args),success:true,meta:{changes:0}};if(/\bRETURNING\b/i.test(this.sql)){const rows=statement.all(...this.args);return {results:rows,success:true,meta:{changes:Number(rows.length)}};}const result=statement.run(...this.args);return {results:[],success:true,meta:{changes:Number(result.changes)}};}
}

function fixture(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(`
  PRAGMA foreign_keys=ON;
  CREATE TABLE marketing_contacts(id TEXT PRIMARY KEY,phone TEXT UNIQUE NOT NULL,name TEXT NOT NULL DEFAULT '',consent_status TEXT NOT NULL,source TEXT NOT NULL DEFAULT 'csv',consented_at INTEGER,consent_source TEXT NOT NULL DEFAULT '',consent_proof TEXT NOT NULL DEFAULT '',unsubscribe_token TEXT UNIQUE,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
  CREATE TABLE marketing_campaigns(id TEXT PRIMARY KEY,name TEXT NOT NULL,channel TEXT NOT NULL,message TEXT NOT NULL,image_data TEXT NOT NULL DEFAULT '',benefit_text TEXT NOT NULL DEFAULT '',referral_code TEXT,retention_goal INTEGER NOT NULL DEFAULT 18000,send_rate_per_minute INTEGER NOT NULL DEFAULT 30,scheduled_at INTEGER,status TEXT NOT NULL,created_by TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,provider TEXT NOT NULL DEFAULT 'unconfigured',template_name TEXT NOT NULL DEFAULT '',template_language TEXT NOT NULL DEFAULT '',template_params_json TEXT NOT NULL DEFAULT '{}',audience_count INTEGER NOT NULL DEFAULT 0,started_at INTEGER,completed_at INTEGER);
  CREATE TABLE marketing_deliveries(campaign_id TEXT NOT NULL,contact_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'queued',provider_message_id TEXT UNIQUE,attempts INTEGER NOT NULL DEFAULT 0,claim_token TEXT,locked_until INTEGER NOT NULL DEFAULT 0,next_attempt_at INTEGER NOT NULL DEFAULT 0,provider_error_code TEXT,submitted_at INTEGER,sent_at INTEGER,delivered_at INTEGER,read_at INTEGER,failed_at INTEGER,updated_at INTEGER NOT NULL,PRIMARY KEY(campaign_id,contact_id));
  CREATE TABLE marketing_webhook_events(event_key TEXT PRIMARY KEY,provider_message_id TEXT,event_type TEXT NOT NULL,status TEXT NOT NULL DEFAULT '',payload_hash TEXT NOT NULL,received_at INTEGER NOT NULL);
  CREATE TABLE rate_limits(id TEXT PRIMARY KEY,count INTEGER NOT NULL,expires_at INTEGER NOT NULL);
  CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL);
  CREATE TABLE users(id TEXT PRIMARY KEY,phone TEXT UNIQUE);
  CREATE TABLE responsible_play_profiles(user_id TEXT PRIMARY KEY,cooling_off_until INTEGER,self_excluded_until INTEGER);
 `);
 const db={prepare(sql){return new Statement(sqlite,sql);},async batch(statements){sqlite.exec('BEGIN');try{const results=statements.map(statement=>statement.execute());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 const provider={enabled:'true',graphApiVersion:'v25.0',phoneNumberId:'123456789012345',wabaId:'987654321098765',accessToken:'EAA'+'.'.repeat(50),appSecret:'a'.repeat(32),webhookVerifyToken:'verify-token-'+'x'.repeat(32),businessNumber:'+601166336686',templateName:'master7_launch_invitation',templateLanguage:'zh_CN'};
 return {sqlite,db,provider,context:{db,provider,recipientLimit:'1000000',workerToken:'w'.repeat(40),workerBatchSize:'10'}};
}

function contact(sqlite,id,phone,status='opted_in',source='signed_form',proof='proof-001'){
 sqlite.prepare('INSERT INTO marketing_contacts(id,phone,name,consent_status,consented_at,consent_source,consent_proof,unsubscribe_token,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,1,1)').run(id,phone,id,status,status==='opted_in'?1:null,source,proof,`${id}-unsubscribe-token`);
}
function campaign(sqlite,id,status='ready'){
 sqlite.prepare("INSERT INTO marketing_campaigns(id,name,channel,message,benefit_text,referral_code,send_rate_per_minute,status,created_by,created_at,updated_at) VALUES(?,?,'whatsapp','Launch greeting','VIP benefit','REF001',60,?,'owner',1,1)").run(id,id,status);
}
function restrict(sqlite,id,phone,until=Math.floor(Date.now()/1000)+86400){
 sqlite.prepare('INSERT INTO users(id,phone) VALUES(?,?)').run(id,phone);
 sqlite.prepare('INSERT INTO responsible_play_profiles(user_id,cooling_off_until,self_excluded_until) VALUES(?,?,NULL)').run(id,until);
}
function signed(provider,payload){const body=Buffer.from(JSON.stringify(payload));return {body,signature:'sha256='+createHmac('sha256',provider.appSecret).update(body).digest('hex')};}

test('campaign readiness requires verified Meta configuration and a verified recipient limit',()=>{
 const {context}=fixture();assert.equal(whatsappCampaignStatus(context).ready,true);assert.equal(whatsappCampaignStatus({...context,recipientLimit:''}).ready,false);assert.ok(whatsappCampaignStatus({...context,recipientLimit:''}).blockers.includes('recipient_limit_unverified'));
 assert.equal(authorizeWhatsAppWorker(`Bearer ${context.workerToken}`,context),true);assert.equal(authorizeWhatsAppWorker('Bearer short',context),false);
});

test('launch queues verified consent only, enforces the recipient tier and is idempotent',async()=>{
 const {sqlite,context}=fixture();campaign(sqlite,'launch-one');contact(sqlite,'verified','+60111111111');contact(sqlite,'unknown','+60112222222','unknown','','');contact(sqlite,'blank-proof','+60113333333','opted_in','  ','  ');contact(sqlite,'opted-out','+60114444444','opted_out','unsubscribe','STOP');
 const launched=await launchWhatsAppCampaign(context,'launch-one','owner');assert.deepEqual({...launched},{status:'sending',campaignId:'launch-one',audience:1,recipientLimit:1_000_000,idempotent:false});
 assert.deepEqual(sqlite.prepare("SELECT contact_id,status FROM marketing_deliveries WHERE campaign_id='launch-one'").all().map(row=>({...row})),[{contact_id:'verified',status:'queued'}]);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='whatsapp_campaign_launched'").get().n,1);
 assert.deepEqual(await launchWhatsAppCampaign(context,'launch-one','owner'),{status:'sending',campaignId:'launch-one',idempotent:true});assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='whatsapp_campaign_launched'").get().n,1);
 campaign(sqlite,'over-limit');contact(sqlite,'verified-two','+60115555555');
 await assert.rejects(()=>launchWhatsAppCampaign({...context,recipientLimit:'1'},'over-limit','owner'),error=>error instanceof WhatsAppCampaignError&&error.status===409&&/recipient limit is 1/.test(error.message));
 assert.equal(sqlite.prepare("SELECT status FROM marketing_campaigns WHERE id='over-limit'").get().status,'ready');assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM marketing_deliveries WHERE campaign_id='over-limit'").get().n,0);
});

test('Responsible Play removes active members at launch and suppresses an already queued delivery before send',async()=>{
 const launch=fixture();campaign(launch.sqlite,'restricted-launch');contact(launch.sqlite,'allowed','+60111110001');contact(launch.sqlite,'restricted','+60111110002');restrict(launch.sqlite,'member-restricted','+60111110002');
 const started=await launchWhatsAppCampaign(launch.context,'restricted-launch','owner');assert.equal(started.audience,1);
 assert.deepEqual(launch.sqlite.prepare("SELECT contact_id FROM marketing_deliveries WHERE campaign_id='restricted-launch'").all().map(row=>row.contact_id),['allowed']);

 const queued=fixture();campaign(queued.sqlite,'restricted-after-launch');contact(queued.sqlite,'queued-contact','+60111110003');await launchWhatsAppCampaign(queued.context,'restricted-after-launch','owner');restrict(queued.sqlite,'member-queued','+60111110003');let calls=0;queued.context.provider.fetchImpl=async()=>{calls++;return Response.json({messages:[{id:'should-not-send'}]});};
 const summary=await dispatchWhatsAppCampaigns(queued.context);assert.equal(summary.suppressed,1);assert.equal(summary.claimed,0);assert.equal(calls,0);
 const delivery=queued.sqlite.prepare("SELECT status,provider_error_code FROM marketing_deliveries WHERE campaign_id='restricted-after-launch'").get();assert.equal(delivery.status,'failed');assert.equal(delivery.provider_error_code,'responsible_play_suppressed');
 assert.equal(queued.sqlite.prepare("SELECT status FROM marketing_campaigns WHERE id='restricted-after-launch'").get().status,'completed');
});

test('worker uses the campaign template snapshot and never repeats a successful or transport-unknown submission',async()=>{
 const successful=fixture();campaign(successful.sqlite,'send-once');contact(successful.sqlite,'send-contact','+60116667777');let calls=0,observed;
 successful.context.provider.fetchImpl=async(_url,init)=>{calls++;observed=JSON.parse(init.body);return Response.json({messages:[{id:'wamid.send-once-001'}]});};
 await launchWhatsAppCampaign(successful.context,'send-once','owner');successful.context.provider.templateName='changed_after_launch';
 const first=await dispatchWhatsAppCampaigns(successful.context);assert.equal(first.sent,1);assert.equal(calls,1);assert.equal(observed.template.name,'master7_launch_invitation');assert.deepEqual(observed.template.components[0].parameters.map(item=>item.text),['Launch greeting','VIP benefit','https://www.master7.best/register?ref=REF001','https://www.master7.best/unsubscribe?token=send-contact-unsubscribe-token']);
 assert.equal(successful.sqlite.prepare("SELECT status FROM marketing_deliveries WHERE campaign_id='send-once'").get().status,'sent');assert.equal(successful.sqlite.prepare("SELECT status FROM marketing_campaigns WHERE id='send-once'").get().status,'completed');
 await dispatchWhatsAppCampaigns(successful.context);assert.equal(calls,1);

 const uncertain=fixture();campaign(uncertain.sqlite,'unknown-once');contact(uncertain.sqlite,'unknown-contact','+60118889999');let uncertainCalls=0;uncertain.context.provider.fetchImpl=async()=>{uncertainCalls++;throw new Error('timeout');};
 await launchWhatsAppCampaign(uncertain.context,'unknown-once','owner');const unknown=await dispatchWhatsAppCampaigns(uncertain.context);assert.equal(unknown.unknown,1);assert.equal(uncertainCalls,1);assert.equal(uncertain.sqlite.prepare("SELECT status FROM marketing_deliveries WHERE campaign_id='unknown-once'").get().status,'unknown');
 await dispatchWhatsAppCampaigns(uncertain.context);assert.equal(uncertainCalls,1);assert.equal(uncertain.sqlite.prepare("SELECT status FROM marketing_campaigns WHERE id='unknown-once'").get().status,'sending');
});

test('overlapping workers can claim a delivery only once',async()=>{
 const {sqlite,context}=fixture();campaign(sqlite,'concurrent-send');contact(sqlite,'concurrent-contact','+60117778888');let calls=0,release;const gate=new Promise(resolve=>{release=resolve;});
 context.provider.fetchImpl=async()=>{calls++;await gate;return Response.json({messages:[{id:'wamid.concurrent-001'}]});};
 await launchWhatsAppCampaign(context,'concurrent-send','owner');const first=dispatchWhatsAppCampaigns(context),second=dispatchWhatsAppCampaigns(context);await new Promise(resolve=>setImmediate(resolve));release();await Promise.all([first,second]);
 assert.equal(calls,1);assert.equal(sqlite.prepare("SELECT attempts FROM marketing_deliveries WHERE campaign_id='concurrent-send'").get().attempts,1);assert.equal(sqlite.prepare("SELECT status FROM marketing_deliveries WHERE campaign_id='concurrent-send'").get().status,'sent');
});

test('signed webhooks update monotonically, deduplicate retries and immediately suppress inbound STOP',async()=>{
 const {sqlite,context,provider}=fixture();campaign(sqlite,'webhook-main','sending');campaign(sqlite,'webhook-pending','sending');contact(sqlite,'webhook-contact','+60112223333');
 sqlite.prepare("INSERT INTO marketing_deliveries(campaign_id,contact_id,status,provider_message_id,sent_at,updated_at) VALUES('webhook-main','webhook-contact','sent','wamid.webhook-001',1,1)").run();
 sqlite.prepare("INSERT INTO marketing_deliveries(campaign_id,contact_id,status,claim_token,locked_until,updated_at) VALUES('webhook-pending','webhook-contact','submitting','claim',9999999999,1)").run();
 const delivered=signed(provider,{entry:[{changes:[{field:'messages',value:{statuses:[{id:'wamid.webhook-001',recipient_id:'60112223333',status:'delivered',timestamp:'1793970001'}]}}]}]});
 await assert.rejects(()=>applyWhatsAppWebhook(context,delivered.body,'sha256='+'0'.repeat(64)),error=>error instanceof WhatsAppCampaignError&&error.status===401);
 assert.equal((await applyWhatsAppWebhook(context,delivered.body,delivered.signature)).statuses,1);assert.equal(sqlite.prepare("SELECT status FROM marketing_deliveries WHERE campaign_id='webhook-main'").get().status,'delivered');
 assert.equal((await applyWhatsAppWebhook(context,delivered.body,delivered.signature)).duplicates,1);
 for(const status of ['sent','failed','read']){const event=signed(provider,{entry:[{changes:[{field:'messages',value:{statuses:[{id:'wamid.webhook-001',recipient_id:'60112223333',status,timestamp:'1793970002',errors:status==='failed'?[{code:131026}]:[]}]}}]}]});await applyWhatsAppWebhook(context,event.body,event.signature);}
 assert.equal(sqlite.prepare("SELECT status FROM marketing_deliveries WHERE campaign_id='webhook-main'").get().status,'read');
 const stop=signed(provider,{entry:[{changes:[{field:'messages',value:{messages:[{id:'wamid.inbound-stop',from:'60112223333',type:'text',text:{body:' STOP '}}]}}]}]});
 assert.equal((await applyWhatsAppWebhook(context,stop.body,stop.signature)).optOuts,1);assert.equal(sqlite.prepare("SELECT consent_status FROM marketing_contacts WHERE id='webhook-contact'").get().consent_status,'opted_out');assert.equal(sqlite.prepare("SELECT status FROM marketing_deliveries WHERE campaign_id='webhook-pending'").get().status,'opted_out');assert.equal(sqlite.prepare("SELECT status FROM marketing_deliveries WHERE campaign_id='webhook-main'").get().status,'read');
 assert.equal((await applyWhatsAppWebhook(context,stop.body,stop.signature)).duplicates,1);assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='marketing_contact_opted_out'").get().n,1);
});
