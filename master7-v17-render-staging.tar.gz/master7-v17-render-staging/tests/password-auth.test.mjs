import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {randomBytes,createHash} from 'node:crypto';
import {handle} from '../lib/backend.ts';

function fixture(){
 const sqlite=new DatabaseSync(':memory:');
 for(const name of readdirSync(new URL('../drizzle/',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}async first(){return sqlite.prepare(this.sql).get(...this.args)??null;}async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}async run(){return sqlite.prepare(this.sql).run(...this.args);}}
 const db={prepare:sql=>new Statement(sql),async batch(statements){sqlite.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
 const code=randomBytes(32).toString('base64url'),config={db,identity:null,ownerEmail:'owner@example.test',ownerLoginId:'master7_owner',ownerSetupHash:createHash('sha256').update(code).digest('hex'),ownerSetupExpires:Math.floor(Date.now()/1000)+3600};
 const sessions={};
 async function call(name,path,data,extra={}){
  const entry=sessions[name]??{};
  const req=new Request('https://portal.example.test'+path,{method:data===undefined?'GET':'POST',headers:{'content-type':'application/json',origin:'https://portal.example.test',cookie:entry.cookie??'','x-csrf-token':entry.csrf??'','cf-connecting-ip':'192.0.2.8',...extra},...(data===undefined?{}:{body:JSON.stringify(data)})});
  const response=await handle(req,config),setCookie=response.headers.get('set-cookie');
  if(name&&setCookie)sessions[name]={...entry,cookie:setCookie.split(';')[0]};
  const body=await response.json();if(name&&path==='/api/session')sessions[name]={...sessions[name],csrf:body.csrf};
  return {status:response.status,body,setCookie};
 }
 function enableSms(){const base=`https://anchor-${randomBytes(4).toString('hex')}.test`;config.anchorApiBaseUrl=base;config.anchorUsername='test-user';config.anchorPassword='test-password';config.anchorSenderId='SEVEN';config.otpHashSecret='test-only-secret-that-is-long-enough-123456';config.smsFetch=async(url,init)=>{const path=new URL(url).pathname;if(path==='/auth/getToken')return Response.json({accessToken:'test-access-token-value-123456789',expiry:3600000});const body=JSON.parse(init.body);const message=Buffer.from(body.msgEncoded,'base64').toString('utf8');config.lastOtp=/\b(\d{6})\b/.exec(message)?.[1];config.lastSms={url:String(url),authorization:new Headers(init.headers).get('Authorization'),body};return Response.json({statusCode:'001'},{status:201});};return base;}
 return {sqlite,config,code,call,sessions,enableSms};
}
const pass='Local test password / one 2026';
const nextPass='Local test password / two 2026';
test('trusted Render public origin allows activation behind an internal request URL',async()=>{
 const f=fixture();f.config.allowedOrigins=['https://master7-v17-staging.onrender.com'];
 try{
  const allowed=await f.call(null,'/api/auth/activate',{code:f.code,password:pass},{origin:'https://master7-v17-staging.onrender.com'});
  assert.equal(allowed.status,201);
  const g=fixture();g.config.allowedOrigins=['https://master7-v17-staging.onrender.com'];
  try{const denied=await g.call(null,'/api/auth/activate',{code:g.code,password:pass},{origin:'https://attacker.example.test'});assert.equal(denied.status,403);}
  finally{g.sqlite.close();}
 }finally{f.sqlite.close();}
});
test('owner password accepts a simple six-character value and rejects shorter values',async()=>{
 const accepted=fixture();try{
  assert.equal((await accepted.call(null,'/api/auth/activate',{code:accepted.code,password:'123456'})).status,201);
  assert.equal((await accepted.call('owner','/api/auth/login',{username:'master7_owner',password:'123456'})).status,200);
 }finally{accepted.sqlite.close();}
 const rejected=fixture();try{
  assert.equal((await rejected.call(null,'/api/auth/activate',{code:rejected.code,password:'12345'})).status,400);
 }finally{rejected.sqlite.close();}
});
async function resetFixture(){
 const f=fixture();await f.call(null,'/api/auth/activate',{code:f.code,password:pass});
 f.resetCode=randomBytes(32).toString('base64url');f.config.ownerResetHash=createHash('sha256').update(f.resetCode).digest('hex');
 f.config.ownerResetIssuedAt=Math.floor(Date.now()/1000);f.config.ownerResetExpires=f.config.ownerResetIssuedAt+3600;
 f.sqlite.prepare('UPDATE password_credentials SET changed_at=?').run(f.config.ownerResetIssuedAt-10);return f;
}
test('owner recovery preserves data and renamed identity, revokes sessions and requires a new login',async()=>{
 const f=await resetFixture();try{
  f.enableSms();const issued=await f.call(null,'/api/auth/otp/send',{username:'member_one',password:pass,phone:'010-801 8801'});await f.call(null,'/api/auth/register',{username:'member_one',password:pass,phone:'010-801 8801',challengeId:issued.body.challengeId,otp:f.config.lastOtp});
  f.sqlite.prepare("UPDATE password_credentials SET username='renamed_owner' WHERE username='master7_owner'").run();
  await f.call('owner','/api/auth/login',{username:'renamed_owner',password:pass});await f.call('owner','/api/session');
  await f.call('second','/api/auth/login',{username:'renamed_owner',password:pass});
  const users=f.sqlite.prepare('SELECT * FROM users ORDER BY id').all(),member=f.sqlite.prepare("SELECT * FROM password_credentials WHERE username='member_one'").get();
  const oldVersion=f.sqlite.prepare("SELECT version FROM password_credentials WHERE username='renamed_owner'").get().version;
  assert.equal((await f.call(null,'/api/auth/options')).body.ownerResetAvailable,true);
  const r=await f.call(null,'/api/auth/reset-owner',{code:f.resetCode,password:nextPass,userId:member.user_id,username:'member_one'});
  assert.equal(r.status,200);assert.equal(r.body.username,'renamed_owner');assert.equal(r.body.signInAgain,true);assert.match(r.setCookie,/Max-Age=0/);
  assert.deepEqual(f.sqlite.prepare('SELECT * FROM users ORDER BY id').all(),users);
  assert.deepEqual(f.sqlite.prepare("SELECT * FROM password_credentials WHERE username='member_one'").get(),member);
  assert.equal(f.sqlite.prepare("SELECT version FROM password_credentials WHERE username='renamed_owner'").get().version,oldVersion+1);
  assert.equal((await f.call('owner','/api/session')).body.user,null);assert.equal((await f.call('second','/api/session')).body.user,null);
  assert.equal((await f.call(null,'/api/auth/login',{username:'renamed_owner',password:pass})).status,401);
  assert.equal((await f.call('owner','/api/auth/login',{username:'renamed_owner',password:nextPass})).status,200);await f.call('owner','/api/session');
  assert.equal((await f.call('owner','/api/admin/summary')).status,200);
  const exported=JSON.stringify((await f.call('owner','/api/admin/export')).body);
  for(const secret of [f.resetCode,f.config.ownerResetHash,'owner_password_setup','owner_password_reset:'])assert.equal(exported.includes(secret),false);
  assert.equal((await f.call(null,'/api/auth/options')).body.ownerResetAvailable,false);
  assert.equal((await f.call(null,'/api/auth/reset-owner',{code:f.resetCode,password:pass})).status,409);
  assert.equal(f.sqlite.prepare("SELECT count(*) n FROM audit WHERE event='owner_password_reset'").get().n,1);
 }finally{f.sqlite.close();}
});
test('invalid, expired, weak, cross-origin and stale recovery requests never change credentials',async t=>{
 for(const variant of ['invalid','expired','weak','cross-origin','changed','missing-owner'])await t.test(variant,async()=>{
  const f=await resetFixture();try{
   let code=f.resetCode,password=nextPass,headers={},status=403;
   if(variant==='invalid')code='x'.repeat(43);
   if(variant==='expired')f.config.ownerResetExpires=1;
   if(variant==='weak'){password='short';status=400;}
   if(variant==='cross-origin')headers.origin='https://evil.test';
   if(variant==='changed'){f.sqlite.prepare('UPDATE password_credentials SET changed_at=?').run(f.config.ownerResetIssuedAt);status=409;}
   if(variant==='missing-owner'){f.sqlite.prepare("DELETE FROM settings WHERE id='owner_password_setup'").run();status=409;}
   const before=f.sqlite.prepare('SELECT * FROM password_credentials').all();
   assert.equal((await f.call(null,'/api/auth/reset-owner',{code,password},headers)).status,status);
   assert.deepEqual(f.sqlite.prepare('SELECT * FROM password_credentials').all(),before);
   assert.equal(f.sqlite.prepare("SELECT count(*) n FROM settings WHERE id LIKE 'owner_password_reset:%'").get().n,0);
  }finally{f.sqlite.close();}
 });
});
test('recovery rolls back all changes if a later database write fails',async()=>{
 const f=await resetFixture();try{
  await f.call('owner','/api/auth/login',{username:'master7_owner',password:pass});
  const before=f.sqlite.prepare('SELECT * FROM password_credentials').all(),sessions=f.sqlite.prepare('SELECT * FROM password_sessions').all();
  f.sqlite.exec("CREATE TRIGGER fail_reset BEFORE INSERT ON audit WHEN NEW.event='owner_password_reset' BEGIN SELECT RAISE(ABORT,'test write failure'); END;");
  assert.equal((await f.call(null,'/api/auth/reset-owner',{code:f.resetCode,password:nextPass})).status,503);
  assert.deepEqual(f.sqlite.prepare('SELECT * FROM password_credentials').all(),before);assert.deepEqual(f.sqlite.prepare('SELECT * FROM password_sessions').all(),sessions);
  assert.equal(f.sqlite.prepare("SELECT count(*) n FROM settings WHERE id LIKE 'owner_password_reset:%'").get().n,0);
  f.sqlite.exec('DROP TRIGGER fail_reset');assert.equal((await f.call(null,'/api/auth/reset-owner',{code:f.resetCode,password:nextPass})).status,200);
 }finally{f.sqlite.close();}
});
test('recovery rejects a concurrent credential change between read and transaction',async()=>{
 const f=await resetFixture();try{
  const batch=f.config.db.batch;
  f.config.db.batch=async statements=>{f.sqlite.prepare('UPDATE password_credentials SET version=version+1').run();return batch(statements);};
  const before=f.sqlite.prepare('SELECT password_hash FROM password_credentials').get().password_hash;
  assert.equal((await f.call(null,'/api/auth/reset-owner',{code:f.resetCode,password:nextPass})).status,503);
  assert.equal(f.sqlite.prepare('SELECT password_hash FROM password_credentials').get().password_hash,before);
  assert.equal(f.sqlite.prepare("SELECT count(*) n FROM settings WHERE id LIKE 'owner_password_reset:%'").get().n,0);
 }finally{f.sqlite.close();}
});
test('recovery guesses are rate limited',async()=>{
 const f=await resetFixture();try{for(let i=0;i<5;i++)assert.equal((await f.call(null,'/api/auth/reset-owner',{code:'x'.repeat(43),password:nextPass})).status,403);assert.equal((await f.call(null,'/api/auth/reset-owner',{code:f.resetCode,password:nextPass})).status,429);}finally{f.sqlite.close();}
});
test('password login and one-use owner handover',async t=>{
 const f=fixture(),{call,sqlite,code,sessions}=f;
 try{
 await t.test('invalid, expired, foreign-origin and weak-password activation cannot create an owner',async()=>{
  assert.equal((await call(null,'/api/auth/options')).body.ownerSetupComplete,false);
  assert.equal((await call(null,'/api/auth/activate',{code:'x'.repeat(43),password:pass})).status,403);
  assert.equal((await call(null,'/api/auth/activate',{code,password:pass},{origin:'https://evil.test'})).status,403);
  assert.equal((await call(null,'/api/auth/activate',{code,password:'short'})).status,400);
  f.config.ownerSetupExpires=1;assert.equal((await call(null,'/api/auth/activate',{code,password:pass})).status,403);f.config.ownerSetupExpires=Math.floor(Date.now()/1000)+3600;
  assert.equal(sqlite.prepare('SELECT count(*) n FROM users').get().n,0);
 });
 await t.test('activation is atomic and single use; only salted password hash is stored',async()=>{
  const r=await call(null,'/api/auth/activate',{code,password:pass});assert.equal(r.status,201);assert.equal(r.body.username,'master7_owner');assert.equal(r.setCookie,null);
  assert.equal((await call(null,'/api/auth/activate',{code,password:nextPass})).status,409);
  const stored=sqlite.prepare('SELECT * FROM password_credentials').get();assert.notEqual(stored.password_hash,pass);assert.equal(stored.password_hash.length,64);assert.equal(stored.salt.length,43);
  assert.equal((await call(null,'/api/auth/options')).body.ownerSetupAvailable,false);
  assert.equal((await call(null,'/api/auth/options')).body.ownerSetupComplete,true);
 });
 await t.test('login rejects wrong credentials and untrusted origins, sets secure cookie',async()=>{
  assert.equal((await call('bad','/api/auth/login',{username:'master7_owner',password:'bad password'})).status,401);
  assert.equal((await call('bad','/api/auth/login',{username:'missing_user',password:pass})).status,401);
  assert.equal((await call('owner','/api/auth/login',{username:'master7_owner',password:pass},{origin:'https://evil.test'})).status,403);
  const r=await call('owner','/api/auth/login',{username:'MASTER7_OWNER',password:pass});assert.equal(r.status,200);for(const flag of ['Secure','HttpOnly','SameSite=Strict','Path=/'])assert.ok(r.setCookie.includes(flag));
  const s=await call('owner','/api/session');assert.equal(s.body.user.role,'owner');assert.equal(s.body.authMethod,'password');assert.equal((await call('owner','/api/admin/summary')).status,200);
 });
 await t.test('members cannot claim owner ID, self-approve or view administration',async()=>{
  assert.equal((await call(null,'/api/auth/register',{username:'master7_owner',password:pass,phone:'010-801 8802',role:'owner'})).status,409);
  f.enableSms();const issued=await call(null,'/api/auth/otp/send',{username:'member_one',password:pass,phone:'010-801 8801'});assert.equal((await call(null,'/api/auth/register',{username:'member_one',password:pass,phone:'010-801 8801',role:'owner',approved:true,challengeId:issued.body.challengeId,otp:f.config.lastOtp})).status,201);
  await call('member','/api/auth/login',{username:'member_one',password:pass,phone:'010-801 8801'});const s=await call('member','/api/session');assert.equal(s.body.user.role,'member');assert.equal(s.body.user.approved,false);
  assert.equal((await call('member','/api/admin/summary')).status,403);assert.equal((await call('member','/api/tickets',{subject:'Login help',message:'Please help me'})).status,403);
  assert.equal((await call('owner','/api/admin/approve',{userId:s.body.user.id})).status,200);
  assert.equal((await call('member','/api/tickets',{subject:'Login help',message:'Please help me'})).status,201);
 });
 await t.test('password and ID change needs current password and CSRF; invalidates every old session',async()=>{
  await call('otherOwnerDevice','/api/auth/login',{username:'master7_owner',password:pass});await call('otherOwnerDevice','/api/session');
  const saved={...sessions.owner};
  assert.equal((await call('owner','/api/auth/change-password',{currentPassword:pass,newPassword:nextPass},{'x-csrf-token':'bad'})).status,403);
  assert.equal((await call('owner','/api/auth/change-password',{currentPassword:'incorrect',newPassword:nextPass})).status,401);
  assert.equal((await call('owner','/api/auth/change-password',{currentPassword:pass,newPassword:nextPass,newUsername:'member_one'})).status,409);
  assert.equal((await call('owner','/api/auth/change-password',{currentPassword:pass,newPassword:nextPass,newUsername:'renamed_owner'})).status,200);
  sessions.owner=saved;
  assert.equal((await call('owner','/api/session')).body.user,null);assert.equal((await call('otherOwnerDevice','/api/session')).body.user,null);
  assert.equal((await call(null,'/api/auth/login',{username:'master7_owner',password:pass})).status,401);
  assert.equal((await call(null,'/api/auth/login',{username:'renamed_owner',password:pass})).status,401);
  assert.equal((await call('owner','/api/auth/login',{username:'renamed_owner',password:nextPass})).status,200);assert.equal((await call('owner','/api/session')).body.user.role,'owner');
 });
 await t.test('exports contain neither password hashes, salts nor session/activation tokens',async()=>{
  const r=await call('owner','/api/admin/export');assert.equal(r.status,200);const text=JSON.stringify(r.body);for(const field of ['password_hash','salt','csrf','token_hash','credential_version',code,pass,nextPass])assert.equal(text.includes(field),false);
 });
 await t.test('logout rejects cross-site requests and revokes cookie server-side',async()=>{
  const saved={...sessions.owner};assert.equal((await call('owner','/api/auth/logout',{}, {origin:'https://evil.test'})).status,403);
  assert.equal((await call('owner','/api/auth/logout',{})).status,200);sessions.owner=saved;assert.equal((await call('owner','/api/admin/summary')).status,401);
 });
 }finally{sqlite.close();}
});
test('expired sessions and throttled logins fail closed',async t=>{
 // Keep the attempts inside one ten-minute rate bucket; wall-clock rollover
 // otherwise makes this assertion depend on when the suite was started.
 const timestamp=Date.now();t.mock.method(Date,'now',()=>timestamp);
 const f=fixture();try{
  await f.call(null,'/api/auth/activate',{code:f.code,password:pass});await f.call('owner','/api/auth/login',{username:'master7_owner',password:pass});
  f.sqlite.prepare('UPDATE password_sessions SET expires_at=1').run();assert.equal((await f.call('owner','/api/session')).body.user,null);
  let last;for(let i=0;i<11;i++)last=await f.call(null,'/api/auth/login',{username:'master7_owner',password:'not correct'});assert.equal(last.status,429);
 }finally{f.sqlite.close();}
});

test('member accounts require a unique Malaysian mobile and member login checks it while admin login does not',async()=>{
 const f=fixture();try{
  assert.equal((await f.call(null,'/api/auth/register',{username:'member_phone',password:'12345678'})).status,400);
  assert.equal((await f.call(null,'/api/auth/register',{username:'member_phone',password:'12345678',phone:'555'})).status,400);
  f.enableSms();const issued=await f.call(null,'/api/auth/otp/send',{username:'member_phone',password:'12345678',phone:'010-801 8800'});assert.equal(issued.status,200);assert.equal((await f.call(null,'/api/auth/register',{username:'member_phone',password:'12345678',phone:'010-801 8800',challengeId:issued.body.challengeId,otp:f.config.lastOtp})).status,201);
  assert.equal(f.sqlite.prepare("SELECT phone FROM users WHERE username='member_phone'").get().phone,'+60108018800');
  assert.equal((await f.call(null,'/api/auth/register',{username:'another_member',password:'12345678',phone:'+60108018800'})).status,409);
  assert.equal((await f.call('member','/api/auth/login',{username:'member_phone',password:'12345678'})).status,401);
  assert.equal((await f.call('member','/api/auth/login',{username:'member_phone',password:'12345678',phone:'010-801 8801'})).status,401);
  assert.equal((await f.call('member','/api/auth/login',{username:'member_phone',password:'12345678',phone:'+60108018800'})).status,200);
  await f.call(null,'/api/auth/activate',{code:f.code,password:'12345678'});
  assert.equal((await f.call('owner','/api/auth/login',{username:'master7_owner',password:'12345678'})).status,200);
 }finally{f.sqlite.close();}
});

test('member registration requires a one-use Anchor SMS challenge and never exposes its code',async()=>{
 const f=fixture();try{
  assert.equal((await f.call(null,'/api/auth/otp/send',{phone:'010-801 8800'})).status,503);
  assert.equal((await f.call(null,'/api/auth/register',{username:'sms_member',password:'12345678',phone:'010-801 8800'})).status,400);
  const base=f.enableSms(),issued=await f.call(null,'/api/auth/otp/send',{username:'sms_member',password:'12345678',phone:'010-801 8800'});
  assert.equal(issued.status,200);assert.equal(issued.body.status,'accepted');assert.equal(issued.body.expiresInSeconds,300);assert.equal(typeof issued.body.challengeId,'string');assert.equal(issued.body.challengeId.length,32);
  assert.equal(f.config.lastSms.url,base+'/mt/sendMtSms');assert.equal(f.config.lastSms.authorization,'Bearer test-access-token-value-123456789');assert.equal(f.config.lastSms.body.destAddr,'+60108018800');assert.equal(f.config.lastSms.body.senderId,'SEVEN');assert.equal(f.config.lastSms.body.dataCoding,8);
  const stored=f.sqlite.prepare('SELECT * FROM otp_challenges WHERE id=?').get(issued.body.challengeId);assert.ok(stored);assert.notEqual(stored.code_hash,f.config.lastOtp);assert.equal(JSON.stringify(issued.body).includes(f.config.lastOtp),false);
  assert.equal((await f.call(null,'/api/auth/register',{username:'sms_member',password:'12345678',phone:'010-801 8800',challengeId:issued.body.challengeId,otp:String((Number(f.config.lastOtp)+1)%1000000).padStart(6,'0')})).status,400);
  assert.equal(f.sqlite.prepare('SELECT attempts FROM otp_challenges WHERE id=?').get(issued.body.challengeId).attempts,1);
  assert.equal((await f.call(null,'/api/auth/register',{username:'sms_member',password:'12345678',phone:'010-801 8800',challengeId:issued.body.challengeId,otp:f.config.lastOtp})).status,201);
  assert.equal((await f.call(null,'/api/auth/register',{username:'replay_member',password:'12345678',phone:'010-801 8800',challengeId:issued.body.challengeId,otp:f.config.lastOtp})).status,409);
  assert.equal(f.sqlite.prepare('SELECT consumed_at FROM otp_challenges WHERE id=?').get(issued.body.challengeId).consumed_at>0,true);
  const second=await f.call(null,'/api/auth/otp/send',{username:'expired_member',password:'12345678',phone:'010-801 8801'});assert.equal(second.status,200);
  f.sqlite.prepare('UPDATE otp_challenges SET expires_at=1 WHERE id=?').run(second.body.challengeId);
  assert.equal((await f.call(null,'/api/auth/register',{username:'expired_member',password:'12345678',phone:'010-801 8801',challengeId:second.body.challengeId,otp:f.config.lastOtp})).status,400);
 }finally{f.sqlite.close();}
});

test('customer registration and sign-in require ID, password, Malaysian phone and one-use Anchor OTP',async()=>{
 const f=fixture();try{
  f.enableSms();
  const pass='member-pass-123';
  const registration=await f.call(null,'/api/auth/otp/send',{username:'otp_member',password:pass,phone:'010-801 8899',purpose:'register'});
  assert.equal(registration.status,200);
  assert.equal((await f.call(null,'/api/auth/register',{username:'otp_member',phone:'010-801 8899',challengeId:registration.body.challengeId,otp:f.config.lastOtp})).status,400);
  assert.equal((await f.call(null,'/api/auth/register',{username:'otp_member',password:pass,phone:'010-801 8899',challengeId:registration.body.challengeId,otp:f.config.lastOtp})).status,201);
  assert.ok(f.sqlite.prepare("SELECT username FROM password_credentials WHERE username='otp_member'").get());
  f.sqlite.prepare('DELETE FROM rate_limits').run();
  assert.equal((await f.call(null,'/api/auth/otp/send',{username:'otp_member',password:'wrong-password',phone:'+60108018899',purpose:'login'})).status,401);
  assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM otp_challenges').get().n,1);
  f.sqlite.prepare('DELETE FROM rate_limits').run();
  const login=await f.call(null,'/api/auth/otp/send',{username:'otp_member',password:pass,phone:'+60108018899',purpose:'login'});
  assert.equal(login.status,200);
  assert.equal((await f.call(null,'/api/auth/otp/login',{username:'otp_member',password:'wrong-password',phone:'+60108018899',challengeId:login.body.challengeId,otp:f.config.lastOtp})).status,401);
  const signedIn=await f.call('otpMember','/api/auth/otp/login',{username:'otp_member',password:pass,phone:'+60108018899',challengeId:login.body.challengeId,otp:f.config.lastOtp});
  assert.equal(signedIn.status,200);assert.match(signedIn.setCookie,/HttpOnly/);
  const session=await f.call('otpMember','/api/session');assert.equal(session.body.user.username,'otp_member');assert.equal(session.body.user.role,'member');
  assert.equal((await f.call(null,'/api/auth/otp/login',{username:'otp_member',password:pass,phone:'+60108018899',challengeId:login.body.challengeId,otp:f.config.lastOtp})).status,400);
 }finally{f.sqlite.close();}
});

test('Anchor provider failures fail closed without creating OTP challenges',async()=>{
 const f=fixture();try{
  f.enableSms();f.config.smsFetch=async()=>Response.json({error:'temporary'}, {status:503});
  assert.equal((await f.call(null,'/api/auth/otp/send',{username:'sms_member',password:'12345678',phone:'010-801 8800'})).status,503);
  assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM otp_challenges').get().n,0);
  assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM users').get().n,0);
 }finally{f.sqlite.close();}
});
