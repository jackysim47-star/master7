import assert from 'node:assert/strict';
import test from 'node:test';
import {handle} from '../lib/backend.ts';

function contextFor(userId){
 const users={
  owner:{id:'owner',username:'owner',role:'owner',approved:1,csrf:'owner-csrf',created_at:0},
  staff:{id:'staff',username:'staff',role:'staff',approved:1,csrf:'staff-csrf',created_at:0},
  member:{id:'member',username:'member',role:'member',approved:1,csrf:'member-csrf',created_at:0},
 };
 const db={prepare(sql){
  let args=[];
  return {bind(...values){args=values;return this;},async first(){
   if(sql.includes('FROM password_sessions'))return userId==='staff'?{...users.staff,login_id:'staff_login',session_csrf:'staff-csrf',credential_version:1}:null;
   return sql.includes('FROM users WHERE id=?')?users[args[0]]??null:null;
  }};
 }};
 return {db,identity:{userId,email:`${userId}@example.test`},ownerEmail:'owner@example.test',readOnly:true,newDepositsEnabled:'false',newGameLaunchesEnabled:'false',newPayoutsEnabled:'false'};
}

for(const role of ['owner','staff'])test(`${role} can read the single platform handover status`,async()=>{
 const request=new Request('https://portal.example.test/api/admin/handover-status',role==='staff'?{headers:{cookie:`__Host-master7_session=${'a'.repeat(43)}`}}:undefined);
 const response=await handle(request,contextFor(role));
 assert.equal(response.status,200);
 const data=await response.json();
 assert.deepEqual(data.entry.hosts,['https://www.master7.best','https://www.master7.site']);
 assert.equal(data.entry.mode,'same_application');
 assert.equal(data.production.status,'NO-GO');
});

test('member cannot read the staff handover status',async()=>{
 const response=await handle(new Request('https://portal.example.test/api/admin/handover-status'),contextFor('member'));
 assert.equal(response.status,403);
});
