import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {getGameProviderProfile} from '../lib/game-provider-registry.ts';
import {walletMinorToGameAmount} from '../lib/game-unit-conversion.ts';
import {GAME_PROVIDER_ACCEPTANCE_CAPABILITIES} from '../lib/game-provider-acceptance.ts';

function fixture(profileId='jili_myr_1to1'){
 const sql=new DatabaseSync(':memory:');for(const name of readdirSync(new URL('../drizzle',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 sql.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf-alice',0),('bob','bob','member',1,'csrf-bob',0),('owner','owner','owner',1,'csrf-owner',0);INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('synthetic-credit','alice','synthetic-credit','fixture','manual_bank',2000,'MYR','fixture','credited',0,0);INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('synthetic-member','synthetic-credit','alice','member',2000,'MYR',0),('synthetic-clearing','synthetic-credit','alice','provider_clearing',-2000,'MYR',0)");
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 let queue=Promise.resolve();const db={prepare:text=>new Statement(text),batch(statements){const result=queue.then(async()=>{sql.exec('BEGIN IMMEDIATE');try{const out=[];for(const s of statements)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}});queue=result.catch(()=>{});return result;}};
 const profile=getGameProviderProfile(profileId),account=profile.unitScale===100?'1to100':'1to1',connection={profile:profileId,baseUrl:'https://supplier.example.test/api1',agentId:'synthetic_'+account,agentKey:'syntheticAgentKey000000000000000',transferAmountUnit:'platform_currency',queryAmountUnit:'platform_currency',balanceAmountUnit:'game_points',reportAmountUnit:'game_points',launchOrigins:['https://games.example.test']},slot={mode:'qa',environment:'production',recoveryEnabled:true,qaMemberIds:['alice'],approvedApiEndpoints:[connection.baseUrl],connection,merchantContractVerified:true,merchantContractEvidenceSha256:'a'.repeat(64),sessionClosureVerified:true,allIssuedLaunchesInvalidated:true,lateResultsFinal:true};
 const state={cash:'0',online:false,created:false,calls:[],gatewayCalls:[],transfers:new Map(),throwDeposit:false,throwSweep:false,submitErrorCode:null,missingQuery:false,badGatewayAccount:false};
 const transport=async(url,init)=>{
  const method=new URL(url).pathname.split('/').at(-1),form=new URLSearchParams(init.body);state.calls.push({method,form});assert.equal(form.get('AgentId'),connection.agentId);const ok=data=>Response.json({ErrorCode:0,Data:data});
  if(method==='GetGameList')return ok([{GameId:1,name:{'en-US':'Synthetic JILI slot'},GameCategoryId:1}]);
  if(method==='CreateMember'){state.created=true;return ok(null);}
  if(method==='GetMemberInfo')return ok([{Account:form.get('Accounts'),Balance:walletMinorToGameAmount(state.cash,profile.unitScale),Status:state.created?state.online?1:2:3}]);
  if(method==='KickMember'){state.online=false;return ok(null);}
  if(method==='LoginWithoutRedirect'){state.online=true;return ok('https://games.example.test/single-use-jili');}
  if(method==='ExchangeTransferByAgentId'){
   if(state.submitErrorCode!==null)return Response.json({ErrorCode:state.submitErrorCode,Data:null});
   const direction=form.get('TransferType'),id=form.get('TransactionId'),amount=direction==='2'?form.get('Amount'):(Number(state.cash)/100).toFixed(2);if(direction==='1')assert.equal(form.get('Amount'),'0');
   state.transfers.set(id,{Account:form.get('Account'),TransactionId:id,Amount:amount,TransferType:Number(direction),Status:1});state.cash=direction==='2'?String(Math.round(Number(amount)*100)):'0';
   if(direction==='1'?state.throwSweep:state.throwDeposit)throw Error('Synthetic accepted transfer response lost');return ok({TransactionId:id,Status:1});
  }
  if(method==='CheckTransferByTransactionId')return state.missingQuery?Response.json({ErrorCode:101,Data:null}):ok(state.transfers.get(form.get('TransactionId'))??null);
  throw Error('Unexpected supplier method '+method);
 };
 const config={db,newGameLaunchesEnabled:'true',newDepositsEnabled:'false',newPayoutsEnabled:'false',providerTransferFetch:transport,gameGatewayUrl:'https://master7-integration-gateway.onrender.com',gameGatewayFetch:async url=>{state.gatewayCalls.push(url);const u=new URL(url),chosen=u.searchParams.get('account');assert.equal(u.pathname,'/providers/jili/games');return Response.json({provider:'jili',account:state.badGatewayAccount?'other':chosen,currency:'MYR',ratio:chosen==='1to100'?'1:100':'1:1',games:[{gameCode:'1',name:'Synthetic JILI slot',category:'SLOT',maintenance:false}],upstreamStatus:200,complete:true});}};
 const request=async(who,path,method='GET',body)=>{const response=await handle(new Request('https://www.master7.best'+path,{method,headers:{Origin:'https://www.master7.best','Content-Type':'application/json','X-CSRF-Token':'csrf-'+who,'X-Forwarded-For':'192.0.2.8'},...(body?{body:JSON.stringify(body)}:{})}),{...config,gameTransferProfilesJson:JSON.stringify({profiles:{[profileId]:slot}}),identity:who?{userId:who,email:who+'@example.test'}:null});return {status:response.status,body:await response.json()};};
 const launch=(who='alice',id=profileId)=>request(who,'/api/game-launch','POST',{profileId:id,providerId:'jili',gameCode:'1',idempotencyKey:crypto.randomUUID(),language:'en'});
 const accept=async()=>{for(const capability of GAME_PROVIDER_ACCEPTANCE_CAPABILITIES){const r=await request('owner','/api/admin/game-acceptance','POST',{profileId,capability,environment:'production',result:'passed',evidenceSha256:'b'.repeat(64),evidenceReference:'synthetic-jili-'+capability,observedAt:Math.floor(Date.now()/1000),expectedEventId:null});assert.equal(r.status,201,JSON.stringify(r));}};
 return {sql,db,profile,slot,connection,state,config,request,launch,accept,close:()=>sql.close()};
}

for(const profileId of ['jili_myr_1to1','jili_my1_1to100'])test(`${profileId}: universal API transfers, launches, returns and records MYR exactly once`,async()=>{
 const h=fixture(profileId);try{
  const start=await h.launch();assert.equal(start.status,200,JSON.stringify(start));assert.equal(start.body.profileId,profileId);assert.equal(start.body.launchUrl,'https://games.example.test/single-use-jili');assert.ok(h.state.gatewayCalls[0].endsWith(h.profile.unitScale===100?'account=1to100':'account=1to1'));
  const wallet=await h.request('alice',`/api/game-wallet?profileId=${profileId}`);assert.equal(wallet.body.wallet.availableMinor,'0');assert.equal(wallet.body.session.id,start.body.walletSessionId);assert.equal(wallet.body.supportsRecovery,true);
  h.state.cash='1575';h.config.newGameLaunchesEnabled='false';
  const end=await h.request('alice','/api/game-wallet/settle','POST',{profileId,sessionId:start.body.walletSessionId});assert.equal(end.status,200,JSON.stringify(end));assert.equal(end.body.session.resultMinor,'-425');
  await h.request('alice','/api/game-wallet/recover','POST',{profileId,sessionId:start.body.walletSessionId});
  const result=await h.request('alice',`/api/game-wallet?profileId=${profileId}`);assert.equal(result.body.wallet.availableMinor,'1575');assert.equal(h.state.calls.filter(x=>x.method==='ExchangeTransferByAgentId').length,2);
  const records=await h.request('owner','/api/admin/game-wallet'),row=records.body.profileItems.find(x=>x.id===start.body.walletSessionId);assert.equal(row.amountReturnedMinor,'1575');assert.equal(row.reservedMinor,null);assert.equal(row.lastTransfer.providerReference,h.state.calls.find(x=>x.method==='ExchangeTransferByAgentId'&&x.form.get('TransferType')==='1').form.get('TransactionId'));assert.ok(!JSON.stringify(records.body).includes(h.connection.agentKey));assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);assert.deepEqual(h.sql.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{h.close();}
});
test('an accepted but timed-out JILI sweep is recovered under maintenance without a second submission',async()=>{
 const h=fixture('jili_my1_1to100');try{const start=await h.launch();assert.equal(start.status,200,JSON.stringify(start));h.state.cash='1801';h.state.throwSweep=true;const body={profileId:h.profile.profileId,sessionId:start.body.walletSessionId},end=await h.request('alice','/api/game-wallet/settle','POST',body);assert.equal(end.status,503,JSON.stringify(end));assert.equal(h.sql.prepare('SELECT expected_return_minor FROM game_wallet_sessions').get().expected_return_minor,null);h.config.newGameLaunchesEnabled='false';h.slot.mode='closed';h.slot.qaMemberIds=[];h.state.missingQuery=true;const unresolved=await h.request('alice','/api/game-wallet/recover','POST',body);assert.equal(unresolved.body.status,'withdraw_unknown');h.state.missingQuery=false;const recovered=await h.request('alice','/api/game-wallet/recover','POST',body);assert.equal(recovered.body.status,'settled',JSON.stringify(recovered));assert.equal(h.state.calls.filter(x=>x.method==='ExchangeTransferByAgentId'&&x.form.get('TransferType')==='1').length,1);assert.equal((await h.request('alice',`/api/game-wallet?profileId=${h.profile.profileId}`)).body.wallet.availableMinor,'1801');}finally{h.close();}
});
test('JILI maintenance and ambiguous member submit results retain funds and recovery never resubmits',async()=>{
 for(const code of [10,101]){
  const h=fixture();try{
   h.state.submitErrorCode=code;const launch=await h.launch();assert.equal(launch.status,503,JSON.stringify(launch));assert.equal(launch.body.code,'GAME_DEPOSIT_UNKNOWN');
   const session=h.sql.prepare('SELECT id,status FROM game_wallet_sessions').get(),operation=h.sql.prepare('SELECT deposit_state,deposit_attempts FROM provider_wallet_operations').get();assert.equal(session.status,'deposit_unknown');assert.equal(operation.deposit_state,'unknown');assert.equal(operation.deposit_attempts,1);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
   h.state.missingQuery=true;const body={profileId:h.profile.profileId,sessionId:session.id};for(let i=0;i<2;i++){const recovered=await h.request('alice','/api/game-wallet/recover','POST',body);assert.equal(recovered.body.status,'deposit_unknown');}
   assert.equal(h.state.calls.filter(x=>x.method==='ExchangeTransferByAgentId').length,1);assert.equal(h.state.calls.filter(x=>x.method==='CheckTransferByTransactionId').length,2);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);
  }finally{h.close();}
 }
});
test('JILI credentials, accepted evidence and a QA allowlist cannot bypass an unverified merchant closure contract',async()=>{
 const h=fixture();try{h.slot.mode='production';await h.accept();h.slot.allIssuedLaunchesInvalidated=false;const r=await h.launch();assert.equal(r.status,503);assert.equal(h.state.calls.length,0);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal((await h.request(null,'/health')).body.anyGamePlayable,false);}finally{h.close();}
});
test('a JILI return-origin misconfiguration cannot advertise Play, reserve a wallet or submit funds',async()=>{
 const h=fixture();try{
  h.slot.allowedReturnOrigins=['https://operator.example.test'];
  const catalogue=await h.request('alice',`/api/games?provider=jili&profileId=${h.profile.profileId}`);assert.equal(catalogue.body.selectedProfile.launchReady,false);assert.equal(catalogue.body.playable,false);
  const wallet=await h.request('alice',`/api/game-wallet?profileId=${h.profile.profileId}`);assert.equal(wallet.body.supportsRecovery,true);
  const result=await h.launch();assert.equal(result.status,503,JSON.stringify(result));assert.equal(h.state.calls.length,0);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
 }finally{h.close();}
});
test('JILI production readiness is per profile and does not certify its other account or 37 brands',async()=>{
 const h=fixture();try{h.slot.mode='production';const before=await h.launch();assert.equal(before.status,503);assert.equal(h.state.calls.length,0);await h.accept();const catalogue=await h.request('alice',`/api/games?provider=jili&profileId=${h.profile.profileId}`);assert.equal(catalogue.body.selectedProfile.launchReady,true,JSON.stringify(catalogue));const health=await h.request(null,'/health');assert.equal(health.body.anyGamePlayable,true);assert.equal(health.body.providerAcceptance.liveProfileCount,1);assert.equal(health.body.liveGames,false);const other=await h.launch('alice','jili_my1_1to100');assert.equal(other.status,503);assert.equal(h.state.calls.filter(x=>x.method==='ExchangeTransferByAgentId').length,0);}finally{h.close();}
});
test('JILI summary readiness uses the exact profile cache instead of borrowing the other account',async()=>{
 const h=fixture('jili_my1_1to100');try{
  h.slot.mode='production';await h.accept();const checkedAt=Math.floor(Date.now()/1000),insert=h.sql.prepare('INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,lease_until,upstream_status,complete) VALUES(?,?,?,?,?,0,200,1)');
  insert.run('jili','available',JSON.stringify([{provider:'jili',gameCode:'1',maintenance:false}]),checkedAt,checkedAt);
  let summary=await h.request('alice','/api/games'),target=summary.body.profiles.find(profile=>profile.profileId===h.profile.profileId),other=summary.body.profiles.find(profile=>profile.profileId==='jili_myr_1to1');
  assert.equal(target.catalogueProfileBound,true);assert.equal(target.catalogueCacheStatus,'missing');assert.equal(target.launchReady,false);assert.equal(other.launchReady,false);assert.equal(summary.body.playable,false);assert.equal(h.state.calls.length,0);
  insert.run(h.profile.profileId,'available',JSON.stringify([{provider:'jili',profileId:h.profile.profileId,gameCode:'1',maintenance:false}]),checkedAt,checkedAt);
  summary=await h.request('alice','/api/games');target=summary.body.profiles.find(profile=>profile.profileId===h.profile.profileId);other=summary.body.profiles.find(profile=>profile.profileId==='jili_myr_1to1');
  assert.equal(target.catalogueCacheStatus,'available');assert.equal(target.cachedGameCount,1);assert.equal(target.launchReady,true);assert.equal(other.launchReady,false);assert.equal(summary.body.playable,true);assert.equal(h.state.calls.length,0);
 }finally{h.close();}
});
test('a JILI catalogue bound to a different account cannot reserve or deposit any member funds',async()=>{
 const h=fixture('jili_my1_1to100');try{h.state.badGatewayAccount=true;const result=await h.launch();assert.equal(result.status,409,JSON.stringify(result));assert.equal(h.state.calls.length,0);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);}finally{h.close();}
});
test('a changed JILI amount unit mapping cannot reinterpret a funded session during recovery',async()=>{
 const h=fixture('jili_my1_1to100');try{const start=await h.launch();assert.equal(start.status,200,JSON.stringify(start));const calls=h.state.calls.length;h.connection.queryAmountUnit='game_points';const end=await h.request('alice','/api/game-wallet/settle','POST',{profileId:h.profile.profileId,sessionId:start.body.walletSessionId});assert.equal(end.status,409);assert.equal(end.body.code,'GAME_TRANSFER_CONTRACT_REVIEW');assert.equal(h.state.calls.length,calls);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);assert.equal(h.sql.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);}finally{h.close();}
});
