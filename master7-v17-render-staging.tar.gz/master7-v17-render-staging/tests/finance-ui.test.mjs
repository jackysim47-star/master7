import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const portal=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8'),app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8'),finance=readFileSync(new URL('../public/assets/finance.js',import.meta.url),'utf8'),style=readFileSync(new URL('../public/assets/finance.css',import.meta.url),'utf8');

test('finance center is a dedicated owner and staff dashboard with truthful source states',()=>{
 assert.match(portal,/href="#financeCenterPanel"/);
 assert.match(portal,/id="financeCenterPanel"/);
 assert.match(portal,/id="financeCenterBank"/);
 assert.match(portal,/id="financeCenterReconciliation"/);
 assert.match(portal,/未连接的资料显示“等待连接”，不会用 RM0 冒充已经对账/);
 assert.match(portal,/\/assets\/finance\.css\?v=/);
 assert.match(portal,/\/assets\/finance\.js\?v=/);
 assert.match(app,/financeCenterPanel:\(\)=>window\.Master7Finance\?\.load\(\)/);
 assert.match(finance,/\/api\/admin\/finance-center\?/);
 assert.match(finance,/\['owner','staff'\]\.includes/);
 assert.match(finance,/item\.amountMinor===null\?'等待连接'/);
 for(const label of ['VIP 礼金','Cashback','Deposit Commission','Turnover Commission','Company Profit Dividend','游戏盈亏','厂家结算','营运支出'])assert.match(finance,new RegExp(label));
 assert.doesNotMatch(finance,/innerHTML|account_number|accountName|receipt_data|password|otp/i);
 assert.match(style,/finance-center-summary/);
 assert.match(style,/@media\(max-width:620px\)/);
});
