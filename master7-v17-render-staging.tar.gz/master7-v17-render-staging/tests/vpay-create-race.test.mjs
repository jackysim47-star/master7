import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {createVPayOrder,handleVPay} from '../lib/vpay.ts';

// All gateway responses are simulated and no provider is contacted.
const gateway='https://master7-integration-gateway.onrender.com',portal='https://master7-v17-staging.onrender.com',trader='fixture-trader';
const orderToken='o'.repeat(40),queryToken='q'.repeat(40),callbackToken='c'.repeat(40),callbackReference='callback-reference';
function fixture(t,providerState,createReference){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf',0)").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=statements.map(s=>sql.prepare(s.text).run(...s.args));sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 let releaseOrder,arrival;const waitForOrder=new Promise(resolve=>{releaseOrder=resolve;}),arrived=new Promise(resolve=>{arrival=resolve;}),state={orderId:'',orders:0,queries:0};
 const context={db,user:{id:'alice',username:'alice',role:'member',approved:1,csrf:'csrf'},gatewayUrl:gateway,orderToken,queryToken,callbackToken,enabled:'true',newDepositsEnabled:'true',mode:'production',vpayTraderId:trader,returnUrl:portal+'/payment/return',fetchImpl:async(input,init)=>{
  const path=new URL(String(input)).pathname;
  if(path==='/platform/vpay/config')return Response.json({provider:'vpay',mode:'production',paymentReady:true,traderId:trader,notifyUrl:gateway+'/callbacks/vpay/payment',returnUrl:context.returnUrl,tradeCodes:['2']});
  if(path==='/platform/vpay/order'){
   state.orders++;const payload=JSON.parse(init.body);state.orderId=payload.outTradeNo;arrival();await waitForOrder;
   if(createReference===null)return Response.json({provider:'vpay',result:{code:-1,data:{}}});
   return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:state.orderId,trade_no:createReference,trader_id:trader,amount:'20.00',currency:'MYR',pay_url:'https://payment.vpay.club/checkout/test'}}});
  }
  assert.equal(path,'/platform/vpay/order-query');state.queries++;const payload=JSON.parse(init.body);assert.equal(payload.tradeNo,callbackReference);
  return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:state.orderId,trade_no:callbackReference,trader_id:trader,amount:'20.00',currency:'MYR',state:providerState}}});
 }};
 async function callback(){const response=await handleVPay(new Request(portal+'/api/payment-callbacks/vpay/payment',{method:'POST',headers:{Authorization:'Bearer '+callbackToken,'Content-Type':'application/json'},body:JSON.stringify({out_trade_no:state.orderId,trade_no:callbackReference,amount:'20.00',state:'3',trader_id:trader})}),{...context,user:null});return {status:response.status,body:await response.text()};}
 t.after(()=>{releaseOrder();sql.close();});return {sql,state,context,arrived,releaseOrder,callback};
}

test('a late VPay create response cannot overwrite a callback-bound reference',async t=>{
 const f=fixture(t,'2','different-reference');
 const creating=createVPayOrder({amount:'20.00',tradeCode:'2',payerName:'fixture',requestKey:'request-key-123456'},f.context);await f.arrived;
 assert.deepEqual(await f.callback(),{status:502,body:'PENDING'});f.releaseOrder();
 const response=await creating;assert.equal(response.status,202);assert.equal((await response.json()).status,'awaiting_confirmation');
 const row=f.sql.prepare('SELECT status,provider_trade_no,checkout_url FROM deposit_orders WHERE id=?').get(f.state.orderId);
 assert.deepEqual({...row},{status:'creating',provider_trade_no:callbackReference,checkout_url:null});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);assert.equal(f.state.orders,1);assert.equal(f.state.queries,1);
});

test('a callback that credits during VPay order creation is reported as credited without a second ledger entry',async t=>{
 const f=fixture(t,'3',callbackReference);
 const creating=createVPayOrder({amount:'20.00',tradeCode:'2',payerName:'fixture',requestKey:'request-key-123456'},f.context);await f.arrived;
 assert.deepEqual(await f.callback(),{status:200,body:'SUCCESS'});f.releaseOrder();
 const response=await creating;assert.equal(response.status,200);assert.deepEqual(await response.json(),{id:f.state.orderId,status:'credited',payUrl:null});
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);assert.equal(f.sql.prepare('SELECT SUM(amount_minor) n FROM wallet_ledger').get().n,0);assert.equal(f.state.orders,1);assert.equal(f.state.queries,1);
});

test('a late create rejection does not mark a callback-bound VPay order failed',async t=>{
 const f=fixture(t,'2',null);
 const creating=createVPayOrder({amount:'20.00',tradeCode:'2',payerName:'fixture',requestKey:'request-key-123456'},f.context);await f.arrived;
 assert.deepEqual(await f.callback(),{status:502,body:'PENDING'});f.releaseOrder();const response=await creating;
 assert.equal(response.status,202);assert.equal((await response.json()).status,'awaiting_confirmation');
 const row=f.sql.prepare('SELECT status,provider_trade_no FROM deposit_orders WHERE id=?').get(f.state.orderId);assert.deepEqual({...row},{status:'creating',provider_trade_no:callbackReference});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('replayed VPay orders never show an unsafe checkout URL or an unverified credit',async t=>{
 const f=fixture(t,'2',callbackReference),request={amount:'20.00',tradeCode:'2',payerName:'fixture',requestKey:'request-key-123456'};
 const first=createVPayOrder(request,f.context);await f.arrived;f.releaseOrder();assert.equal((await first).status,201);
 f.sql.prepare("UPDATE deposit_orders SET checkout_url='https://attacker.invalid/pay' WHERE id=?").run(f.state.orderId);
 let response=await createVPayOrder(request,f.context);assert.equal(response.status,202);assert.equal((await response.json()).payUrl,null);
 f.sql.prepare("UPDATE deposit_orders SET status='credited' WHERE id=?").run(f.state.orderId);
 response=await createVPayOrder(request,f.context);assert.equal(response.status,409);assert.equal((await response.json()).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('late VPay create response cannot return a checkout URL different from the persisted order',async t=>{
 const f=fixture(t,'2',callbackReference),request={amount:'20.00',tradeCode:'2',payerName:'fixture',requestKey:'request-key-123456'};
 const first=createVPayOrder(request,f.context);await f.arrived;
 f.sql.prepare("UPDATE deposit_orders SET status='created',provider_trade_no=?,checkout_url='https://payment.vpay.club/checkout/other' WHERE id=?").run(callbackReference,f.state.orderId);
 f.releaseOrder();const response=await first;assert.equal(response.status,202);assert.equal((await response.json()).payUrl,null);
});

test('VPay replay refuses a credited ledger that matches a changed amount instead of the request',async t=>{
 const f=fixture(t,'3',callbackReference),request={amount:'20.00',tradeCode:'2',payerName:'fixture',requestKey:'request-key-123456'};
 const first=createVPayOrder(request,f.context);await f.arrived;assert.equal((await f.callback()).status,200);f.releaseOrder();assert.equal((await first).status,200);
 f.sql.prepare('UPDATE deposit_orders SET amount_minor=2100 WHERE id=?').run(f.state.orderId);
 f.sql.prepare("UPDATE wallet_ledger SET amount_minor=CASE account_code WHEN 'member' THEN 2100 ELSE -2100 END WHERE order_id=?").run(f.state.orderId);
 const response=await createVPayOrder(request,f.context);assert.equal(response.status,409);assert.equal((await response.json()).status,'review');
});
