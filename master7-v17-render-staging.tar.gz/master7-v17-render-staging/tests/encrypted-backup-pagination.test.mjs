import test from 'node:test';
import assert from 'node:assert/strict';
import {constants,createDecipheriv,generateKeyPairSync,privateDecrypt} from 'node:crypto';
import {readFileSync,readdirSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {gunzipSync} from 'node:zlib';
import {BACKUP_PAGE_SIZE,BACKUP_TABLES,createEncryptedPortalBackup} from '../lib/encrypted-backup.ts';

function releaseTables(){
 const db=new DatabaseSync(':memory:'),directory=new URL('../drizzle/',import.meta.url);
 try{
  for(const name of readdirSync(directory).filter(name=>/^\d{4}_.+\.sql$/.test(name)).sort())db.exec(readFileSync(new URL(name,directory),'utf8'));
  return Object.fromEntries(BACKUP_TABLES.map(table=>{
   const columns=db.prepare(`PRAGMA table_info(${table})`).all();
   return [table,{columns:columns.map(column=>column.name),keys:columns.filter(column=>column.pk).sort((a,b)=>a.pk-b.pk).map(column=>column.name)}];
  }));
 }finally{db.close();}
}

function syntheticKeyPair(){return generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});}

function decrypt(envelope,privateKey){
 const key=privateDecrypt({key:privateKey,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64'));
 const cipher=createDecipheriv('aes-256-gcm',key,Buffer.from(envelope.iv,'base64'));cipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));
 return JSON.parse(gunzipSync(Buffer.concat([cipher.update(Buffer.from(envelope.ciphertext,'base64')),cipher.final()])).toString('utf8'));
}

const selectPattern=/^SELECT \* FROM ([a-z0-9_]+) ORDER BY ([a-z0-9_, ]+) LIMIT \? OFFSET \?$/;

test('every backup table orders pages by a complete release unique key',async()=>{
 const schema=releaseTables(),queries=[];
 const db={prepare(sql){queries.push(sql);return {bind(){return {all:async()=>({results:[]})};}};}};
 await createEncryptedPortalBackup(db,'synthetic-pagination-release',syntheticKeyPair());
 assert.equal(queries.length,BACKUP_TABLES.length);
 for(const sql of queries){
  const match=sql.match(selectPattern);assert.ok(match,sql);
  const {columns,keys}=schema[match[1]];
  assert.ok(keys.length>0,`${match[1]} must have a stable key`);
  const ordered=match[2].split(',').map(value=>value.trim()).map(value=>/^\d+$/.test(value)?columns[Number(value)-1]:value);
  const acceptanceOrder={
   game_provider_acceptance_events:['profile_id','capability','environment','revision'],
   production_acceptance_events:['category','subject_id','capability','environment','revision'],
  }[match[1]];
  assert.deepEqual(ordered,acceptanceOrder??keys,`${match[1]} must use its complete stable key`);
 }
});

test('composite-key pages retain every row across changing legal tie orders',async t=>{
 const schema=releaseTables(),composites=Object.entries(schema).filter(([,table])=>table.keys.length>1),sqlite=new DatabaseSync(':memory:');
 t.after(()=>sqlite.close());
 const count=BACKUP_PAGE_SIZE*2+5,queries=[];
 sqlite.exec('BEGIN');
 for(const [table,{keys}] of composites){
  sqlite.exec(`CREATE TABLE ${table}(${keys.map(key=>`${key} TEXT NOT NULL`).join(',')},synthetic_marker INTEGER NOT NULL,PRIMARY KEY(${keys.join(',')}))`);
  sqlite.exec(`CREATE INDEX ${table}_forward ON ${table}(${keys.map(key=>`${key} ASC`).join(',')})`);
  sqlite.exec(`CREATE INDEX ${table}_reverse ON ${table}(${keys.map((key,index)=>`${key} ${index===0?'ASC':'DESC'}`).join(',')})`);
  const insert=sqlite.prepare(`INSERT INTO ${table} VALUES(${[...keys,'synthetic_marker'].map(()=>'?').join(',')})`);
  for(let i=0;i<count;i++)insert.run(...keys.map((_,index)=>index===keys.length-1?String(i).padStart(5,'0'):'same-prefix'),i);
 }
 sqlite.exec('COMMIT');
 const db={prepare(sql){
  const match=sql.match(selectPattern);assert.ok(match,sql);
  const table=match[1];
  return {bind(limit,offset){return {all:async()=>{
   assert.equal(limit,BACKUP_PAGE_SIZE);queries.push({table,offset});
   if(schema[table].keys.length===1)return {results:[]};
   // Both indexes legally satisfy a prefix-only order, with opposite tie
   // orders. A full primary-key ORDER BY must be invariant to that plan choice.
   const direction=(offset/BACKUP_PAGE_SIZE)%2?'reverse':'forward';
   const planned=sql.replace(`FROM ${table}`,`FROM ${table} INDEXED BY ${table}_${direction}`);
   return {results:sqlite.prepare(planned).all(limit,offset)};
  }};}};
 }};
 const key=syntheticKeyPair(),{envelope}=await createEncryptedPortalBackup(db,'synthetic-pagination-release',key),payload=decrypt(envelope,key.privateKey);
 assert.equal(payload.manifest.totalRecords,composites.length*count);
 for(const [table,{keys}] of composites){
  const rows=payload.tables[table],identities=rows.map(row=>keys.map(column=>row[column]).join(':'));
  assert.equal(rows.length,count,`${table} row count`);
  assert.equal(new Set(identities).size,count,`${table} must not repeat or omit keys at page boundaries`);
  assert.deepEqual(rows.map(row=>row.synthetic_marker),Array.from({length:count},(_,i)=>i),`${table} stable ordering`);
  assert.deepEqual(queries.filter(query=>query.table===table).map(query=>query.offset),[0,BACKUP_PAGE_SIZE,BACKUP_PAGE_SIZE*2]);
 }
});
