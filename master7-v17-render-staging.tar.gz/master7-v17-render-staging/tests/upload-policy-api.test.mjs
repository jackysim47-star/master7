import assert from 'node:assert/strict';
import test from 'node:test';
import {handle} from '../lib/backend.ts';

function contextFor(userId,extra={}){
 const users={
  owner:{id:'owner',username:'owner',role:'owner',approved:1,csrf:'owner-csrf',created_at:0},
  staff:{id:'staff',username:'staff',role:'staff',approved:1,csrf:'staff-csrf',created_at:0},
  member:{id:'member',username:'member',role:'member',approved:1,csrf:'member-csrf',created_at:0},
 };
 const db={prepare(sql){let args=[];return {bind(...values){args=values;return this;},async first(){
  if(sql.includes('FROM password_sessions'))return userId==='staff'?{...users.staff,login_id:'staff',session_csrf:'staff-csrf',credential_version:1}:null;
  return sql.includes('FROM users WHERE id=?')?users[args[0]]??null:null;
 }};}};
 return {db,identity:{userId,email:`${userId}@example.test`},ownerEmail:'owner@example.test',...extra};
}

test('owner and staff can read the staging upload policy without secrets',async()=>{
 for(const role of ['owner','staff']){
  const request=new Request('https://portal.example.test/api/admin/upload-policy',role==='staff'?{headers:{cookie:`__Host-master7_session=${'a'.repeat(43)}`}}:undefined);
  const response=await handle(request,contextFor(role,{uploadApprovalMode:'layered_safe',assetAutoApproval:'true',receiptAutoApproval:'true'}));
  assert.equal(response.status,200);
  const data=await response.json();
  assert.equal(data.readOnly,true);
  assert.equal(data.environment,'staging');
  assert.equal(data.mode,'layered_safe');
  assert.equal(data.receipt.autoApprove,false);
  assert.equal(data.receipt.walletCreditOnUpload,false);
  assert.equal(data.package.productionAutoDeploy,false);
  assert.doesNotMatch(JSON.stringify(data),/api[_-]?key|password|secret|token|credential/i);
 }
});

test('members are denied and writes are rejected',async()=>{
 const denied=await handle(new Request('https://portal.example.test/api/admin/upload-policy'),contextFor('member'));
 assert.equal(denied.status,403);
 const method=await handle(new Request('https://portal.example.test/api/admin/upload-policy',{method:'POST'}),contextFor('owner'));
 assert.equal(method.status,405);
});
