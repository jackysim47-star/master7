import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {defaultVipProgram, validateVipProgram} from '../lib/vip.ts';

const dataKey=value=>value.replace(/^data-/,'').replace(/-([a-z])/g,(_,letter)=>letter.toUpperCase());
class Element {
 constructor(tag='div'){
  this.tagName=tag.toUpperCase();this.children=[];this.dataset={};this.attributes={};this.listeners={};this.hidden=false;this.className='';this._text='';this._value='';
  this.style={setProperty(){}};
  this.classList={toggle:(name,active)=>{const classes=new Set(this.className.split(/\s+/).filter(Boolean));if(active)classes.add(name);else classes.delete(name);this.className=[...classes].join(' ');},contains:name=>this.className.split(/\s+/).includes(name)};
 }
 set textContent(value){this._text=String(value??'');this.children=[];}
 get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
 set value(value){this._value=String(value??'');}
 get value(){return this._value;}
 append(...children){for(const child of children){child.parentElement=this;this.children.push(child);}}
 replaceChildren(...children){this.children=[];this._text='';this.append(...children);}
 setAttribute(key,value){this.attributes[key]=String(value);}
 addEventListener(name,callback){(this.listeners[name]??=[]).push(callback);}
 querySelectorAll(selector){const result=[];for(const child of this.children){if(matches(child,selector))result.push(child);result.push(...child.querySelectorAll(selector));}return result;}
 querySelector(selector){return this.querySelectorAll(selector)[0]??null;}
 async dispatch(name){for(const callback of this.listeners[name]??[])await callback({preventDefault(){},currentTarget:this});}
 get lastElementChild(){return this.children.at(-1);}
}
function matches(node,selector){
 const data=selector.match(/^\[(data-[\w-]+)(?:="([^"]*)")?\]$/);
 if(data){const key=dataKey(data[1]);return Object.hasOwn(node.dataset,key)&&(data[2]===undefined||node.dataset[key]===data[2]);}
 return /^[a-z]+$/.test(selector)&&node.tagName===selector.toUpperCase();
}
function environment(file,{api,role='owner',periodAttribute,periods=[]}={}){
 const nodes=new Map(),readyCallbacks=[];
 const get=id=>{if(!nodes.has(id))nodes.set(id,new Element());return nodes.get(id);};
 const buttons=periods.map(period=>{const button=new Element('button');button.dataset[periodAttribute]=period;return button;});
 const document={readyState:'loading',getElementById:get,createElement:tag=>new Element(tag),addEventListener(name,callback){if(name==='DOMContentLoaded')readyCallbacks.push(callback);},querySelectorAll:selector=>buttons.filter(button=>matches(button,selector))};
 const context=vm.createContext({window:{},document,state:{user:role?{role}:null},api,URLSearchParams,Intl,BigInt,Date,notification(){},fetch(){throw new Error('Unexpected real network request');}});
 vm.runInContext(readFileSync(new URL('../public/assets/'+file,import.meta.url),'utf8'),context,{filename:file});
 return {get,nodes,buttons,window:context.window,async ready(){for(const callback of readyCallbacks)callback();await Promise.resolve();}};
}
function deferredApi(){const requests=[];return {requests,api:(url,method='GET',payload)=>new Promise((resolve,reject)=>requests.push({url,method,payload,resolve,reject}))};}
const financeData=amount=>({totals:{recognizedDepositsMinor:amount,recognizedWithdrawalsMinor:'0',netCashflowMinor:amount,netProfitMinor:null},categories:{},reconciliation:{},bank:{}});
const operationsData=label=>({summary:{statement:label},generatedAt:1,metrics:{},recommendations:[]});
const reportCases=[
 {name:'Finance Center',file:'finance.js',exportName:'Master7Finance',periodAttribute:'financePeriod',status:'financeCenterStatus',summary:'financeCenterSummary',payload:value=>financeData(value==='LATEST_DAY'?'20000':'90000'),assertLatest:e=>assert.match(e.get('financeCenterSummary').textContent,/200\.00/),contentNodes:['financeCenterSummary','financeCenterSources','financeCenterReconciliation','financeCenterBank']},
 {name:'Operations Intelligence',file:'operations-intelligence.js',exportName:'Master7OperationsIntelligence',periodAttribute:'opsPeriod',status:'operationsAiStatus',summary:'operationsAiSummary',payload:operationsData,assertLatest:e=>assert.match(e.get('operationsAiStatus').textContent,/LATEST_DAY/),contentNodes:['operationsAiSummary','operationsAiMetrics','operationsAiRecommendations']}
];
for(const report of reportCases){
 test(`${report.name}: slow previous-period success cannot replace the latest period`,async()=>{
  const d=deferredApi(),e=environment(report.file,{api:d.api,periodAttribute:report.periodAttribute,periods:['day','month']}),load=e.window[report.exportName].load;
  const older=load('month'),latest=load('day');
  assert.match(d.requests[0].url,/period=month/);assert.match(d.requests[1].url,/period=day/);
  d.requests[1].resolve(report.payload('LATEST_DAY'));await latest;
  d.requests[0].resolve(report.payload('OLD_MONTH'));await older;
  report.assertLatest(e);
  assert.equal(e.buttons.find(button=>button.classList.contains('active')).dataset[report.periodAttribute],'day');
  assert.ok(d.requests.every(request=>request.method==='GET'));
 });
 test(`${report.name}: slow previous-period failure cannot hide a newer successful report`,async()=>{
  const d=deferredApi(),e=environment(report.file,{api:d.api,periodAttribute:report.periodAttribute,periods:['day','month']}),load=e.window[report.exportName].load;
  const older=load('month'),latest=load('day');d.requests[1].resolve(report.payload('LATEST_DAY'));await latest;
  const acceptedStatus=e.get(report.status).textContent;d.requests[0].reject(new Error('STALE_MONTH_FAILURE'));await older;
  assert.equal(e.get(report.status).textContent,acceptedStatus);report.assertLatest(e);
 });
 test(`${report.name}: a failed current-period refresh does not leave previous financial figures`,async()=>{
  const d=deferredApi(),e=environment(report.file,{api:d.api,periodAttribute:report.periodAttribute,periods:['day','month']}),load=e.window[report.exportName].load;
  const first=load('month');d.requests[0].resolve(report.payload('OLD_MONTH'));await first;assert.ok(e.get(report.summary).children.length>0);
  const next=load('day');for(const id of report.contentNodes)assert.equal(e.get(id).children.length,0);
  d.requests[1].reject(new Error('CURRENT_DAY_FAILURE'));await next;
  assert.equal(e.get(report.status).textContent,'CURRENT_DAY_FAILURE');for(const id of report.contentNodes)assert.equal(e.get(id).children.length,0);
 });
}

test('Finance Center keeps a selected month and its amount together when an older day request arrives late',async()=>{
 const d=deferredApi(),e=environment('finance.js',{api:d.api,periodAttribute:'financePeriod',periods:['day','month']}),load=e.window.Master7Finance.load;
 const older=load('day'),latest=load('month','2026-10');assert.match(d.requests[1].url,/period=month&month=2026-10/);
 d.requests[1].resolve(financeData('23000'));await latest;d.requests[0].resolve(financeData('99000'));await older;
 assert.match(e.get('financeCenterSummary').textContent,/230\.00/);assert.ok(e.buttons.every(button=>!button.classList.contains('active')));
});

test('VIP read failure remains an error and clears stale values instead of fabricating an off program',async()=>{
 const e=environment('vip.js',{api:async()=>{throw new Error('SYNTHETIC_UNAVAILABLE');}});
 for(const id of ['vipTierGrid','vipBenefitMatrix','vipCommissionDetails'])e.get(id).textContent='PREVIOUS_MEMBER_DATA';e.get('vipMemberPanel').hidden=false;
 await e.window.Master7Vip.loadPublic();
 assert.match(e.get('vipProgramNotice').textContent,/SYNTHETIC_UNAVAILABLE/);assert.doesNotMatch(e.get('vipProgramNotice').textContent,/由管理员准备中/);
 assert.match(e.get('vipProgramBadges').textContent,/UNAVAILABLE/);assert.equal(e.get('vipMemberPanel').hidden,true);
 for(const id of ['vipTierGrid','vipBenefitMatrix','vipCommissionDetails'])assert.doesNotMatch(e.get(id).textContent,/PREVIOUS_MEMBER_DATA|0\.00|Bronze/);
 assert.equal(e.get('vipDepositCommissionRates').textContent,'L1 — · L2 — · L3 —');assert.equal(e.get('vipCommissionLedgerStatus').textContent,'STATUS UNCONFIRMED');
});

test('VIP explicitly disabled configuration is distinct from a failed read',async()=>{
 const e=environment('vip.js',{api:async()=>({program:defaultVipProgram()})});await e.window.Master7Vip.loadPublic();
 assert.match(e.get('vipProgramBadges').textContent,/VIP DISPLAY OFF/);assert.match(e.get('vipProgramNotice').textContent,/由管理员准备中/);assert.doesNotMatch(e.get('vipProgramNotice').textContent,/暂时无法读取/);
});

test('VIP ignores a stale failure after a newer valid read',async()=>{
 const d=deferredApi(),e=environment('vip.js',{api:d.api}),load=e.window.Master7Vip.loadPublic,older=load(),latest=load();
 d.requests[1].resolve({program:defaultVipProgram()});await latest;const notice=e.get('vipProgramNotice').textContent;
 d.requests[0].reject(new Error('OLDER_READ_FAILURE'));await older;assert.equal(e.get('vipProgramNotice').textContent,notice);
});

test('VIP fixed levels and colours cannot be edited while names and cashback still save',async()=>{
 const calls=[];let program=defaultVipProgram();const e=environment('vip.js',{api:async(url,method='GET',payload)=>{
  calls.push({url,method,payload});if(url==='/api/admin/referrals')return {};
  if(url==='/api/admin/vip'&&method==='POST'){program=validateVipProgram(payload);return {program};}
  if(url==='/api/vip'||url==='/api/admin/vip')return {program};throw new Error('Unexpected endpoint '+url);
 }});
 await e.ready();await e.window.Master7Vip.loadAdmin();const editor=e.get('vipTierEditor');
 assert.equal(editor.querySelectorAll('[data-vip-fixed-field="level"]').length,8);assert.equal(editor.querySelectorAll('[data-vip-fixed-field="color"]').length,8);
 assert.equal(editor.querySelectorAll('[data-vip-field="level"]').length,0);assert.equal(editor.querySelectorAll('[data-vip-field="color"]').length,0);
 const first=editor.querySelectorAll('[data-vip-tier-index="0"]');const name=first.find(input=>input.dataset.vipField==='name'),cashback=first.find(input=>input.dataset.vipField==='cashbackPercent.slot');
 assert.equal(name.tagName,'INPUT');assert.equal(name.disabled,undefined);name.value='Bronze updated';cashback.value='1.25';first.find(input=>input.dataset.vipField==='claimLimit').value='1';first.find(input=>input.dataset.vipField==='validityDays').value='30';
 await e.get('vipManagerForm').dispatch('submit');const saved=calls.find(call=>call.url==='/api/admin/vip'&&call.method==='POST');assert.ok(saved);
 assert.equal(saved.payload.tiers[0].name,'Bronze updated');assert.equal(saved.payload.tiers[0].cashbackPercent.slot,1.25);
 assert.deepEqual(Array.from(saved.payload.tiers,tier=>tier.level),[1,2,3,4,5,6,7,8]);assert.equal(saved.payload.tiers[0].color,'#B87333');
 assert.match(e.get('vipManagerStatus').textContent,/已保存/);
});
