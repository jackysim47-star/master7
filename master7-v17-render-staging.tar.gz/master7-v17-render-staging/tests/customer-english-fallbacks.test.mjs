import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read=file=>readFileSync(new URL(`../${file}`,import.meta.url),'utf8');
const han=/[\u3400-\u9fff]/;

test('English customer fallback text contains no Chinese outside deliberate language labels',()=>{
 const portal=read('app/portal.html');
 const adminStart=portal.indexOf('<section id="admin"');
 const adminEnd=portal.indexOf('  </main>',adminStart);
 assert.ok(adminStart>0&&adminEnd>adminStart);
 const customer=portal.slice(0,adminStart)+portal.slice(adminEnd);
 const visibleText=[...customer.matchAll(/>([^<>]+)</g)].map(match=>match[1].replace(/\s+/g,' ').trim()).filter(Boolean);
 const allowed=new Set(['中文','EN · 中文 · BM']);
 const leaks=visibleText.filter(value=>han.test(value)&&!allowed.has(value));
 assert.deepEqual(leaks,[]);
 const admin=portal.slice(adminStart,adminEnd);
 assert.doesNotMatch(admin,/data-member-zh=/,'customer fallback localization must not modify backoffice markup');
});

test('customer modules localize every public Chinese source string for English',()=>{
 const modules=[
  ['VIP',read('public/assets/vip.js'),' const vipMatrixSections='],
  ['Rewards',read('public/assets/rewards.js'),' function input('],
  ['Events',read('public/assets/engagement.js'),' function inputField(']
 ];
 for(const [name,source,adminMarker] of modules){
  const publicSource=source.slice(0,source.indexOf(adminMarker));
  const unguarded=publicSource.split('\n').filter(line=>han.test(line)&&!/(?:memberCopy|copy)\(|locale\(\)==="en"/.test(line));
  assert.deepEqual(unguarded,[],`${name} public renderer must guard Chinese copy by locale`);
  assert.match(source,/languageChanged/);
 }
 const app=read('public/assets/app.js');
 for(const removed of ['Copied · 已复制','显示最新 200 条回复 / Showing the latest 200 replies','加载更多 / Load more','收到新的客服消息 / New support message'])assert.doesNotMatch(app,new RegExp(removed.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
 assert.match(app,/marketingUnsubscribeTitle:"Stop promotional messages"/);
});
