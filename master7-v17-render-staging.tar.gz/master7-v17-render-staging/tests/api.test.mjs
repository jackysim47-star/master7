import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync,mkdtempSync,rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { handle } from '../lib/backend.ts';

// Execute the real migration and backend queries against SQLite, not query mocks.
const dir=mkdtempSync(join(tmpdir(),'master7-api-'));
const file=join(dir,'test.sqlite');
let sqlite=new DatabaseSync(file);sqlite.exec(readFileSync(new URL('../drizzle/0000_broken_bloodscream.sql',import.meta.url),'utf8'));sqlite.exec(readFileSync(new URL('../drizzle/0001_orange_owl.sql',import.meta.url),'utf8'));
class Statement{
 constructor(sql,args=[]){this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sql,args);}
 async first(){return sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return sqlite.prepare(this.sql).run(...this.args);}
}
const db={prepare:sql=>new Statement(sql),async batch(list){sqlite.exec('BEGIN');try{const r=[];for(const s of list)r.push(await s.run());sqlite.exec('COMMIT');return r;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
const sessions={};
async function call(who,path,method='GET',data,headers={},extra={}){
 const identity=who?{userId:who,email:who==='owner'?'owner@example.test':who+'@example.test'}:null;
 const req=new Request('https://portal.example.test'+path,{method,headers:{'content-type':'application/json','origin':'https://portal.example.test','x-csrf-token':sessions[who]?.csrf??'',...headers},...(data===undefined?{}:{body:JSON.stringify(data)})});
 const r=await handle(req,{db,identity,ownerEmail:'owner@example.test',...extra});return {status:r.status,data:await r.json()};
}
test('V17 hosted portal: identity, authorization, persistence and operations',async t=>{
 try{
 await t.test('public provider catalog is read-only, normalized, and never launchable',async()=>{
  const calls=[];const gameGatewayFetch=async(url,options)=>{calls.push({url:String(url),method:options.method,redirect:options.redirect});const path=new URL(url).pathname;if(path.endsWith('/megah5/games'))return new Response(JSON.stringify({provider:'megah5',result:{Game:[{GameCode:'55021',GameName:'Ocean Quest',GameType:'2',ImageUrl:'https://gth.megah5.com/thumbs/web/55021.png',apiKey:'must-not-leak'}]}}),{headers:{'content-type':'application/json'}});if(path.endsWith('/jili/games'))return new Response(JSON.stringify({games:[{gameCode:'1',name:'Royal Fishing',nameZh:'钱龙捕鱼',category:'5',jackpot:true,secret:'must-not-leak'}]}),{headers:{'content-type':'application/json'}});return new Response(JSON.stringify({games:[{gameCode:'265022',name:'Supreme Zeus',category:'1',imageUrl:'https://gth.kissh5.com/thumbs/web/265022.png'}]}),{headers:{'content-type':'application/json'}});};
  const r=await call(null,'/api/games','GET',undefined,{}, {gameGatewayUrl:'https://master7-integration-gateway.onrender.com',gameGatewayFetch});
  assert.equal(r.status,200);assert.equal(r.data.playable,false);assert.equal(r.data.games.length,3);assert.equal(r.data.games.find(g=>g.provider==='jili').nameZh,'钱龙捕鱼');assert.equal(r.data.games.find(g=>g.provider==='megah5').imageUrl,'https://gth.megah5.com/thumbs/web/55021.png');assert.equal(r.data.games.find(g=>g.provider==='918kissh5').imageUrl,'https://gth.kissh5.com/thumbs/web/265022.png');assert.ok(!JSON.stringify(r.data).includes('must-not-leak'));assert.equal(calls.length,3);assert.ok(calls.every(x=>x.method==='GET'&&x.redirect==='error'));
 });
 await t.test('game catalog rejects untrusted gateway origins and hides upstream failures',async()=>{let calls=0;const gameGatewayFetch=async()=>{calls++;return new Response(JSON.stringify({error:'private detail'}),{status:502,headers:{'content-type':'application/json'}});};const denied=await call(null,'/api/games','GET',undefined,{}, {gameGatewayUrl:'https://attacker.test',gameGatewayFetch});assert.equal(denied.data.games.length,0);assert.equal(calls,0);const blocked=await call(null,'/api/games','GET',undefined,{}, {gameGatewayUrl:'https://master7-integration-gateway.onrender.com',gameGatewayFetch});assert.equal(blocked.status,200);assert.ok(blocked.data.providers.every(p=>p.status==='blocked'));assert.ok(!JSON.stringify(blocked.data).includes('private detail'));});
 await t.test('anonymous access exposes no admin or ticket data',async()=>{assert.equal((await call(null,'/health')).status,200);assert.equal((await call(null,'/api/session')).data.user,null);assert.equal((await call(null,'/api/admin/summary')).status,401);assert.equal((await call(null,'/api/tickets')).status,401);});
 await t.test('only configured owner is auto-approved; members wait',async()=>{for(const who of ['owner','alice','bob','employee'])sessions[who]=(await call(who,'/api/session')).data;assert.equal(sessions.owner.user.role,'owner');assert.equal(sessions.alice.user.role,'member');assert.equal(sessions.alice.user.approved,false);assert.equal((await call('alice','/api/tickets','POST',{subject:'Help me',message:'Need assistance'})).status,403);});
 await t.test('CSRF, foreign origins and privilege escalation rejected',async()=>{assert.equal((await call('owner','/api/admin/approve','POST',{userId:'alice'},{'x-csrf-token':'bad'})).status,403);assert.equal((await call('owner','/api/admin/approve','POST',{userId:'alice'},{origin:'https://evil.test'})).status,403);assert.equal((await call('owner','/api/admin/role','POST',{userId:'alice',role:'owner'})).status,400);assert.equal((await call('owner','/api/admin/role','POST',{userId:'owner',role:'member'})).status,403);});
 await t.test('owner approval and staff assignment persist',async()=>{assert.equal((await call('owner','/api/admin/approve','POST',{userId:'alice'})).status,200);assert.equal((await call('owner','/api/admin/approve','POST',{userId:'bob'})).status,200);assert.equal((await call('owner','/api/admin/role','POST',{userId:'employee',role:'staff'})).status,200);assert.equal((await call('employee','/api/admin/users')).status,403);assert.equal((await call('alice','/api/admin/summary')).status,403);assert.equal((await call('employee','/api/admin/approve','POST',{userId:'bob'})).status,403);});
 let ticket;
 await t.test('ticket creation is isolated between members and survives reopening storage',async()=>{const r=await call('alice','/api/tickets','POST',{subject:'Login help',message:'Please assist with my account.'});assert.equal(r.status,201);ticket=r.data.id;sqlite.close();sqlite=new DatabaseSync(file);assert.equal((await call('alice','/api/tickets')).data.items.length,1);assert.equal((await call('bob','/api/tickets')).data.items.length,0);assert.equal((await call('employee','/api/tickets')).data.items.length,1);});
 await t.test('reply ownership, staff replies and closing workflow',async()=>{assert.equal((await call('bob','/api/tickets/reply','POST',{ticketId:ticket,message:'No access'})).status,404);assert.equal((await call('employee','/api/tickets/reply','POST',{ticketId:ticket,message:'We can help.'})).status,200);assert.equal((await call('alice','/api/tickets')).data.items[0].replies[0].message,'We can help.');assert.equal((await call('employee','/api/admin/ticket-status','POST',{ticketId:ticket,status:'closed'})).status,200);assert.equal((await call('alice','/api/tickets/reply','POST',{ticketId:ticket,message:'More'})).status,409);});
 await t.test('announcements and validated social links appear publicly',async()=>{assert.equal((await call('employee','/api/admin/announcement','POST',{title:'Service notice',body:'Support is now available.'})).status,201);assert.equal((await call(null,'/api/announcements')).data.items[0].title,'Service notice');assert.equal((await call('owner','/api/admin/social-links','POST',{enabled:true,facebookUrl:'https://facebook.com.evil.test/',instagramUrl:''})).status,400);assert.equal((await call('owner','/api/admin/social-links','POST',{enabled:true,facebookUrl:'https://www.facebook.com/example',instagramUrl:''})).status,200);assert.equal((await call(null,'/api/social-links')).data.enabled,true);});
 await t.test('export redacts CSRF; payment status is honest',async()=>{const r=await call('owner','/api/admin/export');assert.equal(r.status,200);assert.ok(r.data.tickets.length);assert.ok(r.data.users.every(u=>!('csrf' in u)));assert.equal((await call('employee','/api/admin/export')).status,403);const h=await call(null,'/health');assert.equal(h.data.realPayments,false);assert.equal(h.data.liveGames,false);});
 await t.test('revoked staff role takes effect on next request',async()=>{assert.equal((await call('owner','/api/admin/role','POST',{userId:'employee',role:'member'})).status,200);assert.equal((await call('employee','/api/admin/summary')).status,403);assert.equal((await call('employee','/api/tickets')).data.items.length,0);});
 await t.test('bounded bodies and persistent write rate limit',async()=>{assert.equal((await call('alice','/api/tickets','POST',{subject:'Big body',message:'x'.repeat(25000)})).status,413);let limited=false;for(let i=0;i<35;i++){if((await call('bob','/api/not-found','POST',{})).status===429){limited=true;break;}}assert.ok(limited);});
 }finally{sqlite.close();rmSync(dir,{recursive:true,force:true});}
});
