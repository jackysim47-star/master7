import test from 'node:test';
import assert from 'node:assert/strict';
import {gspayUsdtCapabilitySnapshot,gspayUsdtPrerequisites,handleGSPayUsdtStatus} from '../lib/gspay-usdt.ts';

const complete=()=>({
 apiBase:'https://api.usdt-provider.example',authKey:'a'.repeat(32),secretKey:'b'.repeat(32),callbackToken:'c'.repeat(32),
 ordersEnabled:'true',returnUrl:'https://portal.example/payment/return',callbackUrl:'https://portal.example/api/payment/gspay/usdt/callback',
 recoveryEnabled:'true',balanceEnabled:'true',contractVerified:'true',assetNetwork:'TRC20',currencyScale:'6',checkoutOrigin:'https://checkout.usdt-provider.example',
});

test('GSPAY USDT profile is fail closed when all declaration fields are present',async()=>{
 const context=complete(),prerequisites=gspayUsdtPrerequisites(context),capabilities=gspayUsdtCapabilitySnapshot(context);
 assert.deepEqual(prerequisites,{credentialsConfigured:true,endpointsDeclared:true,currencyRulesDeclared:true,contractVerified:true});
 assert.equal(capabilities.deposit.implemented,false);
 assert.equal(capabilities.deposit.configured,false);
 assert.equal(capabilities.deposit.enabled,false);
 assert.ok(capabilities.deposit.blockers.includes('deposit_adapter_not_implemented'));
 const response=handleGSPayUsdtStatus(new Request('https://portal.example/api/payments/gspay/usdt/status'),context);
 assert.ok(response);assert.equal(response.status,200);const body=await response.json();
 assert.equal(body.profileId,'gspay_usdt');assert.equal(body.currency,'USDT');assert.equal(body.enabled,false);assert.equal(body.orderReady,false);assert.equal(body.liveReady,false);
 assert.equal(body.contractVerified,true);assert.equal(body.credentialsConfigured,true);assert.equal(body.capabilities.payout.enabled,false);
 const serialized=JSON.stringify(body);for(const value of [context.authKey,context.secretKey,context.callbackToken,context.apiBase,context.callbackUrl,context.checkoutOrigin])assert.doesNotMatch(serialized,new RegExp(value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
});

test('GSPAY USDT missing configuration reports independent blockers and never enables orders',async()=>{
 const capabilities=gspayUsdtCapabilitySnapshot({ordersEnabled:'true'});
 for(const blocker of ['profile_credentials_incomplete','profile_endpoints_unverified','asset_network_or_scale_unverified','provider_contract_unverified','deposit_adapter_not_implemented'])assert.ok(capabilities.deposit.blockers.includes(blocker));
 const response=handleGSPayUsdtStatus(new Request('https://portal.example/api/payments/gspay/usdt/status'),{ordersEnabled:'true'});assert.ok(response);const body=await response.json();
 assert.equal(body.credentialsConfigured,false);assert.equal(body.contractVerified,false);assert.equal(body.orderReady,false);assert.equal(body.queryReady,false);assert.equal(body.callbacksReady,false);assert.equal(body.recoveryReady,false);
});

test('USDT handler recognizes only its status route and does not implement transaction routes',()=>{
 assert.equal(handleGSPayUsdtStatus(new Request('https://portal.example/api/payments/gspay/status'),complete()),null);
 assert.equal(handleGSPayUsdtStatus(new Request('https://portal.example/api/payments/gspay/usdt/orders',{method:'POST'}),complete()),null);
 assert.equal(handleGSPayUsdtStatus(new Request('https://portal.example/api/payments/gspay/usdt/status',{method:'POST'}),complete()),null);
});

test('USDT profile never reads or aliases MYR-shaped settings',()=>{
 const myrOnly={apiBase:undefined,authKey:undefined,secretKey:undefined,callbackToken:undefined,ordersEnabled:undefined,contractVerified:undefined};
 assert.deepEqual(gspayUsdtPrerequisites(myrOnly),{credentialsConfigured:false,endpointsDeclared:false,currencyRulesDeclared:false,contractVerified:false});
 assert.equal(gspayUsdtCapabilitySnapshot(myrOnly).deposit.enabled,false);
});
