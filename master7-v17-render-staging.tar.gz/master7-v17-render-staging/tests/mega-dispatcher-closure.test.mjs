import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import {handle} from '../lib/backend.ts';
import {megaPlayerId} from '../lib/megah5-wallet.ts';

function fixture(t){
 const sql=new DatabaseSync(':memory:');
 for(const f of readdirSync(new URL('../drizzle/',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member','member',1,'csrf',0)").run();
 sql.exec("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('credit','member','credit','fixture','manual_bank',100,'MYR','fixture','credited',0,0); INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('credit-member','credit','member','member',100,'MYR',0),('credit-clearing','credit','member','provider_clearing',-100,'MYR',0)");
 sql.prepare("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('session','member','megah5',?,'55021','active',100,'original-deposit',0,0)").run(megaPlayerId('member'));
 sql.exec("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','game','session',100,0); INSERT INTO megah5_launch_operations(id,wallet_session_id,user_id,game_code,state,created_at,updated_at,last_error) VALUES('launch','session','member','55021','issued',0,0,'')");
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(items){sql.exec('BEGIN');try{const out=items.map(x=>sql.prepare(x.text).run(...x.args));sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const env={DB:db,PUBLIC_ORIGIN:'https://portal.example.test',GAME_GATEWAY_URL:'https://master7-integration-gateway.onrender.com',GAME_GATEWAY_TOKEN:'g'.repeat(40),GAME_GATEWAY_WALLET_TOKEN:'w'.repeat(40),PORTAL_NEW_GAME_LAUNCHES_ENABLED:'false'};
 const exports={};
 const js=ts.transpileModule(readFileSync(new URL('../app/api/[...path]/route.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 vm.runInNewContext(js,{exports,require:name=>{
  if(name==='cloudflare:workers')return {env};
  if(name==='../../chatgpt-auth')return {getChatGPTUser:async()=>({userId:'member',email:'member@example.test'})};
  if(name==='../../../lib/backend')return {handle};
  throw Error('unexpected route dependency: '+name);
 },URL,Request,Response,Buffer,console});
 t.after(()=>sql.close());
 const request=()=>new Request('https://portal.example.test/api/game-wallet/settle',{method:'POST',headers:{Origin:'https://portal.example.test','Content-Type':'application/json','X-CSRF-Token':'csrf'},body:JSON.stringify({profileId:'megah5_myr',sessionId:'session',megaClosureContractVerified:true})});
 return {sql,exports,request,env};
}

test('actual dispatcher remains closed without a server closure dependency, regardless of request fields',async t=>{
 const f=fixture(t),response=await f.exports.POST(f.request());assert.equal(response.status,409);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);
});

test('actual dispatcher requires a verified function pair and snapshots its server dependencies',async t=>{
 const f=fixture(t);assert.equal(typeof f.exports.createDispatcher,'function');let calls=0;
 const dependencies={megaClosureContractVerified:false,megaSessionCloser:async()=>{calls++;return {state:'unknown'};}};
 const dispatch=f.exports.createDispatcher(dependencies);dependencies.megaClosureContractVerified=true;
 assert.equal((await dispatch(f.request())).status,409);assert.equal(calls,0);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
});

test('actual dispatcher forwards a server closer to settlement while new launches are paused',async t=>{
 const f=fixture(t);assert.equal(typeof f.exports.createDispatcher,'function');let calls=0,balanceReads=0;
 const dispatch=f.exports.createDispatcher({megaClosureContractVerified:true,megaSessionCloser:async input=>{calls++;return {state:'closed',receipt:{...input,providerClosureReference:'synthetic-final-closure',allIssuedLaunchesInvalidated:true,pendingRounds:0,lateResultsFinal:true}};},gameGatewayFetch:async url=>{
  assert.equal(new URL(url).pathname,'/platform/megah5/balance');balanceReads++;
  return Response.json({provider:'megah5',result:{Status:200,Currency:'MYR',CurrentBalance:'0.00'}});
 }});
 const response=await dispatch(f.request());assert.equal(response.status,200,await response.clone().text());
 assert.equal(calls,1);assert.ok(balanceReads>=1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 assert.deepEqual({...f.sql.prepare('SELECT amount_minor,currency FROM game_wallet_ledger').get()},{amount_minor:-100,currency:'MYR'});
 assert.equal((await dispatch(f.request())).status,200);
 assert.equal(calls,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);
});

test('unconfirmed dispatcher closure never calls the balance transport or releases funds',async t=>{
 const f=fixture(t);assert.equal(typeof f.exports.createDispatcher,'function');let calls=0;
 const dispatch=f.exports.createDispatcher({megaClosureContractVerified:true,megaSessionCloser:async()=>({state:'unknown'}),gameGatewayFetch:async()=>{calls++;throw Error('must not query balance before closure');}});
 assert.equal((await dispatch(f.request())).status,409);assert.equal(calls,0);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
});
