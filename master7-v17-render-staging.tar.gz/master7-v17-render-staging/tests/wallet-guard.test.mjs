import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {walletGuardStatements,walletGuardedReservation,walletGuardedRiskCheck,walletGuardedEmptyGameCheck} from '../lib/wallet-guard.ts';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

class Statement{
 constructor(db,sql,args=[]){this.db=db;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.db,this.sql,args);}
 async run(){return this.db.prepare(this.sql).run(...this.args);}
 async first(){return this.db.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.db.prepare(this.sql).all(...this.args)};}
}
function setup(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());
 const dir=new URL('../drizzle/',import.meta.url);
 for(const f of readdirSync(dir).filter(f=>f.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(f,dir),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(items){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const item of items)results.push(await item.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
 sqlite.exec(`INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member','member',1,'fixture',0);
 INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('credit','member','credit-request','fixture','manual_bank',10000,'MYR','bank','credited',0,0);
 INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('member-ledger','credit','member','member',10000,'MYR',0),('clearing-ledger','credit','member','provider_clearing',-10000,'MYR',0);`);
 return {sqlite,db};
}
const reserve=(db,amount='2000',kind='withdrawal')=>walletGuardedReservation(db,{userId:'member',kind,referenceId:'fixture-reservation',amountMinor:amount,createdAt:1});

test('guard creates a lazy per-user row and checks balance inside the batch',async t=>{
 const {sqlite,db}=setup(t);
 assert.equal((await withdrawalWalletState(db,'member')).availableMinor,'10000');
 let results=await db.batch([...walletGuardStatements(db,'member'),reserve(db,'10001')]);assert.equal(Number(results[2].changes),0);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 results=await db.batch([...walletGuardStatements(db,'member'),reserve(db)]);assert.equal(Number(results[2].changes),1);
 assert.deepEqual({...sqlite.prepare('SELECT user_id,kind,reference_id,amount_minor FROM wallet_reservations').get()},{user_id:'member',kind:'withdrawal',reference_id:'fixture-reservation',amount_minor:2000});
 assert.equal(sqlite.prepare("SELECT revision FROM member_wallet_guards WHERE user_id='member'").get().revision,2);
 results=await db.batch([...walletGuardStatements(db,'member'),reserve(db,'1000','game')]);assert.equal(Number(results[2].changes),0);
});

test('historical missing payout blocks risk check and any new reservation',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.exec("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('old','member','old-request','vpay','VPay','maybank','Maybank','fixture','fixture','1234',2000,'MYR','cancelled','',0,0)");
 const wallet=await withdrawalWalletState(db,'member');assert.equal(wallet.reconciliationRequired,true);assert.equal(wallet.availableMinor,'0');
 const results=await db.batch([...walletGuardStatements(db,'member'),walletGuardedRiskCheck(db,'member'),reserve(db)]);
 assert.equal(Number(results[2].changes),0);assert.equal(Number(results[3].changes),0);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
});

test('valid active game is risk-free but prevents a second reservation',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.exec("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('session','member','megah5','player','game','active',2000,'deposit',0,0); INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','game','session',2000,0)");
 const result=await db.batch([...walletGuardStatements(db,'member'),walletGuardedRiskCheck(db,'member'),reserve(db)]);assert.equal(Number(result[2].changes),1);assert.equal(Number(result[3].changes),0);
});

test('batch rollback leaves no guard row if later writes fail',async t=>{
 const {sqlite,db}=setup(t);
 await assert.rejects(()=>db.batch([...walletGuardStatements(db,'member'),db.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('absent','invalid','x',1,0)")]));
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM member_wallet_guards').get().n,0);
});


test('zero-balance game authorization rejects funds or another operation appearing under the guard',async t=>{
 const {sqlite,db}=setup(t);
 let result=await db.batch([...walletGuardStatements(db,'member'),walletGuardedEmptyGameCheck(db,'member')]);assert.equal(Number(result[2].changes),0);
 sqlite.exec("DELETE FROM wallet_ledger WHERE order_id='credit'");
 result=await db.batch([...walletGuardStatements(db,'member'),walletGuardedEmptyGameCheck(db,'member')]);assert.equal(Number(result[2].changes),1);
 sqlite.exec("INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at) VALUES('session','member','megah5','player','game','active',2000,'deposit',0,0); INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','game','session',2000,0)");
 result=await db.batch([...walletGuardStatements(db,'member'),walletGuardedEmptyGameCheck(db,'member')]);assert.equal(Number(result[2].changes),0);
});

const parityCases=[
 {name:'credited balance',sql:'',available:'10000',risk:false},
 {name:'settled game loss',sql:"INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,deposit_reference,created_at,updated_at) VALUES('settled-game','member','megah5','player','game','settled',2000,1500,'dep',0,0); INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('game-ledger','settled-game','member','game_result',-500,'MYR',0)",available:'9500',risk:false},
 {name:'mismatched game ledger',sql:"INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,deposit_reference,created_at,updated_at) VALUES('bad-game','member','megah5','player','game','settled',2000,1500,'dep',0,0); INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('bad-ledger','bad-game','member','game_result',500,'MYR',0)",available:'0',risk:true},
 {name:'reviewing payout',sql:"INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('pending','member','pending-request','vpay','VPay','maybank','Maybank','fixture','fixture','1234',2000,'MYR','processing','',0,0); INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,created_at,updated_at) VALUES('payout','pending','vpay','pending-request','fixture',2000,'MYR','review','accepted',0,0); INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','withdrawal','pending',2000,0)",available:'0',risk:true},
 {name:'legacy withdrawal without provider evidence',sql:"INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('legacy','member','legacy-request','vpay','VPay','maybank','Maybank','fixture','fixture','1234',2000,'MYR','cancelled','',0,0)",available:'0',risk:true},
 {name:'valid completed payout',sql:"INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('paid','member','paid-request','vpay','VPay','maybank','Maybank','fixture','fixture','1234',2000,'MYR','paid','',0,0); INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,provider_reference,created_at,updated_at) VALUES('payout-paid','paid','vpay','paid-request','fixture',2000,'MYR','succeeded','accepted','payout-paid',0,0)",available:'8000',risk:false},
];
for(const entry of parityCases)test(`locked spend qualification agrees with wallet: ${entry.name}`,async t=>{
 const {sqlite,db}=setup(t);if(entry.sql)sqlite.exec(entry.sql);
 const state=await withdrawalWalletState(db,'member');assert.equal(state.availableMinor,entry.available);assert.equal(Boolean(state.reconciliationRequired),entry.risk);
 const checked=await db.batch([...walletGuardStatements(db,'member'),walletGuardedRiskCheck(db,'member')]);assert.equal(Number(checked[2].changes),entry.risk?0:1);
 if(entry.risk){const results=await db.batch([...walletGuardStatements(db,'member'),reserve(db,'1')]);assert.equal(Number(results[2].changes),0);}
 else{
  let results=await db.batch([...walletGuardStatements(db,'member'),reserve(db,String(BigInt(entry.available)+1n))]);assert.equal(Number(results[2].changes),0);
  results=await db.batch([...walletGuardStatements(db,'member'),reserve(db,entry.available)]);assert.equal(Number(results[2].changes),1);
 }
});

test('game transfer must match the entire current locked wallet balance',async t=>{
 const {db}=setup(t);
 let result=await db.batch([...walletGuardStatements(db,'member'),reserve(db,'2000','game')]);assert.equal(Number(result[2].changes),0);
 result=await db.batch([...walletGuardStatements(db,'member'),reserve(db,'10000','game')]);assert.equal(Number(result[2].changes),1);
});


test('review of a previously credited deposit blocks spending other credited funds',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.exec(`INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('disputed','member','disputed-request','fixture','vpay',2000,'MYR','bank','review',0,0);
 INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('disputed-member','disputed','member','member',2000,'MYR',0),('disputed-clearing','disputed','member','provider_clearing',-2000,'MYR',0)`);
 const wallet=await withdrawalWalletState(db,'member');assert.equal(wallet.balanceMinor,'10000');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 const result=await db.batch([...walletGuardStatements(db,'member'),walletGuardedRiskCheck(db,'member'),reserve(db,'100')]);assert.equal(Number(result[2].changes),0);assert.equal(Number(result[3].changes),0);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
});

test('a reviewed deposit without any member credit does not freeze unrelated funds',async t=>{
 const {sqlite,db}=setup(t);
 sqlite.exec("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('unposted','member','unposted-request','fixture','vpay',2000,'MYR','bank','review',0,0)");
 const wallet=await withdrawalWalletState(db,'member');assert.equal(wallet.availableMinor,'10000');assert.equal(wallet.reconciliationRequired,undefined);
 const result=await db.batch([...walletGuardStatements(db,'member'),walletGuardedRiskCheck(db,'member'),reserve(db,'100')]);assert.equal(Number(result[2].changes),1);assert.equal(Number(result[3].changes),1);
});
