import test from 'node:test';
import assert from 'node:assert/strict';
import {readOneMpayDepositProviderEvidence,oneMpayCallbackToken,oneMpayCustomer} from '../lib/onempay.ts';
import {handle} from '../lib/backend.ts';
const row={id:'fixture-order',user_id:'fixture-member',provider_trade_no:'fixture-trade',amount_minor:'1000',currency:'MYR',status:'unknown'};
function fixture({rows=[row],alter={},failure=false,configured=true}={}){
 let queries=0;
 const context={db:{prepare(sql){assert.match(sql,/^SELECT .* FROM deposit_orders WHERE provider='1mpay'/);return {all:async()=>({results:rows})};},batch(){throw Error('writes forbidden');}},user:null,apiBase:'https://api.1mpay.net',merchant:'fixture_merchant',secretKey:configured?'synthetic-credential-only':undefined,portalOrigins:['https://www.master7.best'],callbackUrl:'https://www.master7.best/api/payment-callbacks/1mpay/payment',returnUrl:'https://www.master7.best/payment/return',fetchImpl:async(input,init)=>{
  queries++;assert.equal(init.method,'GET');assert.equal(init.body,undefined);assert.equal(init.redirect,'error');
  const url=new URL(input);assert.equal(url.origin,'https://api.1mpay.net');assert.equal(url.pathname.split('/')[1],'transquery');
  const token=oneMpayCallbackToken(context.merchant,'10.00',row.id,oneMpayCustomer(row.user_id),context.secretKey,row.provider_trade_no);
  assert.equal(decodeURIComponent(url.pathname.split('/')[3]),Buffer.from(token,'utf8').toString('base64'));
  if(failure)return new Response('DO-NOT-EXPORT',{status:403});
  return Response.json({merchant:context.merchant,amount:'10.00',refid:row.id,customer:oneMpayCustomer(row.user_id),trxno:row.provider_trade_no,currency:'MYR',token,status:'Successful',raw:'DO-NOT-EXPORT',...alter});
 }};return {context,queries:()=>queries};
}
test('read-only 1MPay incident query validates an existing signed transaction without posting money',async()=>{
 const f=fixture(),r=await readOneMpayDepositProviderEvidence(f.context);assert.equal(f.queries(),1);assert.equal(r.items[0].paymentVerified,true);assert.equal(r.items[0].providerStatus,'successful');assert.equal(r.walletCreditExecuted,false);assert.equal(r.repairsExecuted,false);assert.equal(r.readOnly,true);assert.doesNotMatch(JSON.stringify(r),/synthetic-credential-only|DO-NOT-EXPORT|fixture-member/);
});
for(const [field,value] of [['merchant','other'],['refid','other'],['customer','other'],['trxno','other'],['amount','10.01'],['token','other'],['currency','USDT']])test('read-only query rejects provider binding mismatch: '+field,async()=>{
 const r=await readOneMpayDepositProviderEvidence(fixture({alter:{[field]:value}}).context);assert.equal(r.items[0].paymentVerified,false);assert.equal(r.items[0].outcome,'provider_binding_mismatch');assert.equal(r.repairsExecuted,false);
});
test('a bound timeout is observed without claiming payment or terminal failure',async()=>{const r=await readOneMpayDepositProviderEvidence(fixture({alter:{status:'timeout'}}).context);assert.equal(r.items[0].outcome,'provider_query_bound');assert.equal(r.items[0].providerStatus,'timeout');assert.equal(r.items[0].paymentVerified,false);});
test('provider errors and unknown status messages stay redacted',async()=>{
 const r=await readOneMpayDepositProviderEvidence(fixture({failure:true}).context);assert.equal(r.items[0].httpStatus,403);assert.equal(r.items[0].paymentVerified,false);assert.doesNotMatch(JSON.stringify(r),/DO-NOT-EXPORT/);
 const q=await readOneMpayDepositProviderEvidence(fixture({alter:{status:'DO-NOT-EXPORT'}}).context);assert.equal(q.items[0].providerStatus,'unrecognized');assert.doesNotMatch(JSON.stringify(q),/DO-NOT-EXPORT/);
});
test('unconfigured or invalid stored transactions never invoke the provider',async()=>{
 for(const options of [{configured:false},{rows:[{...row,provider_trade_no:'../bad'}]},{rows:[{...row,currency:'USDT'}]},{rows:[]}]){const f=fixture(options);const r=await readOneMpayDepositProviderEvidence(f.context);assert.equal(f.queries(),0);assert.equal(r.repairsExecuted,false);}
});
test('private manufacturer query rejects unauthenticated callers before any database or network work',async()=>{
 const r=await handle(new Request('https://portal.test/api/internal/deposit-incidents/1mpay-query'),{db:{prepare(){throw Error('no query');}},identity:null,ownerEmail:'owner@test',oneMpayFetch:async()=>{throw Error('no network');}});assert.equal(r.status,401);assert.equal(r.headers.get('cache-control'),'no-store');
});
