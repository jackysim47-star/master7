import assert from 'node:assert/strict';
import test from 'node:test';
import { GET } from '../app/[...legacy]/route.ts';

test('old frontend links and accidental trailing backticks return to a working entry', async () => {
  const cases = [
    ['/%60', '/'],
    ['/admin/%60', '/admin'],
    ['/games', '/'],
    ['/player/games', '/'],
    ['/index.html?source=old', '/?source=old'],
  ];

  for (const [source, expected] of cases) {
    const response = await GET(new Request(`https://portal.example.test${source}`));
    assert.equal(response.status, 308, source);
    assert.equal(response.headers.get('location'), `https://portal.example.test${expected}`, source);
    assert.equal(response.headers.get('cache-control'), 'no-store', source);
  }

  const unknown = await GET(new Request('https://portal.example.test/not-a-real-page'));
  assert.equal(unknown.status, 404);
});

