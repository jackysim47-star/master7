import assert from 'node:assert/strict';
import test from 'node:test';
import {eliteHubzQuery,signEliteHubz,verifyEliteHubzSignature} from '../lib/elitehubz-signature.ts';

// Public documentation sample; this is not a merchant credential.
const key='ojbefkajslndalsjkdas',ts=1753842603174;
const body={ProviderCode:'string',PlayerCode:'string',GameRoundId:'string',TransactionId:'string',TransactionDate:'string',Currency:'string',Amount:'99.9999',GameCode:'string',Type:1,ReserveBetRoundingTolerance:'string',IsTest:false,PromotionEvent:[{Type:0,RefNo:'string',Name:'string',Metadata:'string'},{Type:0,RefNo:'string',Name:'string',Metadata:'string'}]};
const expected='Amount=99.9999&Currency=string&GameCode=string&GameRoundId=string&IsTest=false&PlayerCode=string&PromotionEvent%5b0%5d.Metadata=string&PromotionEvent%5b0%5d.Name=string&PromotionEvent%5b0%5d.RefNo=string&PromotionEvent%5b0%5d.Type=0&PromotionEvent%5b1%5d.Metadata=string&PromotionEvent%5b1%5d.Name=string&PromotionEvent%5b1%5d.RefNo=string&PromotionEvent%5b1%5d.Type=0&ProviderCode=string&ReserveBetRoundingTolerance=string&TransactionDate=string&TransactionId=string&Type=1';

test('official EliteHubz sample produces the exact canonical query and HMAC',()=>{
 assert.equal(eliteHubzQuery(body),expected);
 assert.equal(signEliteHubz(body,ts,key),'EZIQz1iMwCd9zG3twNdKFqqxe/VQt+D1D0jg0mnXm7k=');
});

test('empty fields are skipped, arrays are compacted and URL escapes are lowercase',()=>{
 assert.equal(eliteHubzQuery({Z:'a/b C',B:false,C:0,Skip:'',O:null,Items:['',null,{Name:'A&B'},'value']}),'B=false&C=0&Items%5b0%5d.Name=A%26B&Items%5b1%5d=value&Z=a%2fb%20C');
});

test('signature verification rejects changed content, timestamp, key, malformed encoding and stale messages',()=>{
 const signature=signEliteHubz(body,ts,key);
 assert.equal(verifyEliteHubzSignature(body,ts,signature,key,ts+1000,5000),true);
 assert.equal(verifyEliteHubzSignature({...body,Amount:'100'},ts,signature,key,ts,5000),false);
 assert.equal(verifyEliteHubzSignature(body,ts+1,signature,key,ts,5000),false);
 assert.equal(verifyEliteHubzSignature(body,ts,signature,'12345678901234567890',ts,5000),false);
 assert.equal(verifyEliteHubzSignature(body,ts,signature,key,ts+5001,5000),false);
 assert.equal(verifyEliteHubzSignature(body,ts,signature.slice(0,-1),key,ts,5000),false);
});

test('ambiguous or unbounded signing input fails closed',()=>{
 const cycle={};cycle.Self=cycle;
 for(const invalid of [cycle,{'A.B':1}, {A:NaN},{A:'a'.repeat(4097)},{A:[...Array(1001).keys()]}])assert.throws(()=>eliteHubzQuery(invalid),/invalid_elitehubz_signature_input/);
 assert.throws(()=>signEliteHubz(body,ts,'short'),/invalid_elitehubz_signature_input/);
});
