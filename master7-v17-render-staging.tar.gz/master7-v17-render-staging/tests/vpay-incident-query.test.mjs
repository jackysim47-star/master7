import test from 'node:test';
import assert from 'node:assert/strict';
import {setTimeout as delay} from 'node:timers/promises';
import {readVPayDepositProviderEvidence} from '../lib/vpay.ts';
import {handle} from '../lib/backend.ts';
const row={id:'fixture-order',user_id:'fixture-member',amount_minor:'2000',currency:'MYR',provider_trade_no:null,status:'unknown'};
function fixture({rows=[row],data={},envelope={},httpStatus=200,wait=false}={}){
 let queries=0,active=0,maxActive=0;const requests=[];
 const c={db:{prepare(sql){assert.match(sql,/^SELECT .* FROM deposit_orders WHERE provider='vpay'/);return {all:async()=>({results:rows})};},batch(){throw Error('writes forbidden');}},user:null,gatewayUrl:'https://master7-integration-gateway.onrender.com',queryToken:'q'.repeat(48),orderToken:'o'.repeat(48),callbackToken:'c'.repeat(48),vpayTraderId:'1234',newDepositsEnabled:'false',enabled:'false',fetchImpl:async(input,init)=>{
  queries++;active++;maxActive=Math.max(maxActive,active);try{
   assert.equal(String(input),'https://master7-integration-gateway.onrender.com/platform/vpay/order-query');assert.equal(init.method,'POST');assert.equal(init.redirect,'error');assert.equal(init.headers.Authorization,'Bearer '+c.queryToken);
   const body=JSON.parse(init.body);requests.push(body);assert.ok(Object.keys(body).every(k=>['outTradeNo','tradeNo'].includes(k)));if(wait)await delay(10);
   return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:body.outTradeNo,trade_no:'provider-'+body.outTradeNo,trader_id:'1234',amount:'20.00',currency:'MYR',state:3,secret:'DO-NOT-EXPORT',...data},...envelope}},{status:httpStatus});
  }finally{active--;}
 }};return {c,queries:()=>queries,maxActive:()=>maxActive,requests};
}
test('read-only VPay query can recover an observation by platform order ID without binding or crediting it',async()=>{
 const f=fixture(),r=await readVPayDepositProviderEvidence(f.c);assert.equal(r.items[0].paymentVerified,true);assert.equal(r.items[0].outcome,'provider_query_bound');assert.equal(r.items[0].providerState,'3');assert.equal(r.walletCreditExecuted,false);assert.equal(r.repairsExecuted,false);assert.equal(f.queries(),1);assert.deepEqual(f.requests,[{outTradeNo:'fixture-order'}]);assert.doesNotMatch(JSON.stringify(r),/DO-NOT-EXPORT|fixture-member|qqqqqq/);
});
for(const [field,value] of [['out_trade_no','other'],['trade_no',null],['trader_id','other'],['amount','20.01'],['currency','USDT']])test('VPay incident query rejects binding mismatch: '+field+' '+String(value),async()=>{
 const r=await readVPayDepositProviderEvidence(fixture({data:{[field]:value}}).c);assert.equal(r.items[0].paymentVerified,false);assert.equal(r.items[0].outcome,'provider_binding_mismatch');
});
test('an existing conflicting provider reference is never overwritten',async()=>{const f=fixture({rows:[{...row,provider_trade_no:'stored-other-trade'}]});const r=await readVPayDepositProviderEvidence(f.c);assert.deepEqual(f.requests,[{outTradeNo:'fixture-order',tradeNo:'stored-other-trade'}]);assert.equal(r.items[0].outcome,'provider_binding_mismatch');});
test('nonpaid and unknown provider states never become wallet credits',async()=>{for(const state of [1,2,4,5,'DO-NOT-EXPORT']){const r=await readVPayDepositProviderEvidence(fixture({data:{state}}).c);assert.equal(r.items[0].paymentVerified,false);assert.equal(r.walletCreditExecuted,false);assert.doesNotMatch(JSON.stringify(r),/DO-NOT-EXPORT/);}});
test('provider business and HTTP query failures stay unverified and redacted',async()=>{
 const a=await readVPayDepositProviderEvidence(fixture({envelope:{code:-1}}).c);assert.equal(a.items[0].outcome,'provider_query_rejected');assert.equal(a.items[0].providerCode,-1);
 const b=await readVPayDepositProviderEvidence(fixture({httpStatus:502,envelope:{code:-1}}).c);assert.equal(b.items[0].outcome,'provider_query_unavailable');assert.equal(b.items[0].httpStatus,502);assert.equal(b.items[0].paymentVerified,false);assert.doesNotMatch(JSON.stringify(b),/DO-NOT-EXPORT/);
});
test('foreign origins, missing query token or reused payment tokens cannot access the provider',async()=>{for(const change of [{gatewayUrl:'https://foreign.test'},{queryToken:undefined},{queryToken:'o'.repeat(48)},{queryToken:'c'.repeat(48)},{vpayTraderId:'invalid'}]){const f=fixture();Object.assign(f.c,change);const r=await readVPayDepositProviderEvidence(f.c);assert.equal(r.configured,false);assert.equal(f.queries(),0);}});
test('invalid stored bindings do not send requests',async()=>{for(const change of [{id:'../bad'},{currency:'USDT'},{amount_minor:'-100'},{provider_trade_no:'bad/reference'}]){const f=fixture({rows:[{...row,...change}]});const r=await readVPayDepositProviderEvidence(f.c);assert.equal(f.queries(),0);assert.equal(r.items[0].outcome,'invalid_stored_binding');}});
test('manufacturer reads are capped at ten with two concurrent workers and explicit truncation',async()=>{const f=fixture({rows:Array.from({length:11},(_,i)=>({...row,id:'order-'+i})),wait:true});const r=await readVPayDepositProviderEvidence(f.c);assert.equal(f.queries(),10);assert.equal(f.maxActive(),2);assert.equal(r.truncated,true);assert.equal(r.items.length,10);assert.deepEqual(r.items.map(i=>i.orderId),Array.from({length:10},(_,i)=>'order-'+i));});
test('private VPay observation endpoint rejects unauthenticated callers before reads or outbound requests',async()=>{const r=await handle(new Request('https://portal.test/api/internal/deposit-incidents/vpay-query'),{db:{prepare(){throw Error('no read');}},identity:null,ownerEmail:'owner@test',vpayFetch:async()=>{throw Error('no network');}});assert.equal(r.status,401);assert.equal(r.headers.get('cache-control'),'no-store');});

test('documented legacy query replies may omit merchant ID while explicit foreign merchants remain rejected',async()=>{const r=await readVPayDepositProviderEvidence(fixture({data:{trader_id:undefined}}).c);assert.equal(r.items[0].paymentVerified,true);});
