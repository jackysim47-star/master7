import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8'),start=source.indexOf('const adminDepositReportState='),end=source.indexOf('function renderFinancialAudioControl()',start);
assert.ok(start>=0&&end>start);
const ids=['adminDepositPanel','adminDepositRecords','adminDepositSummary','adminDepositProviders','adminDepositDate','adminDepositToday','adminDepositAll','adminDepositPageSize','adminDepositPrevious','adminDepositNext','adminDepositPageStatus','adminDepositTitle','adminDepositNotice'];
const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');for(const id of ids)assert.ok(html.includes(`id="${id}"`),id);

class Element{
 constructor(){this.children=[];this.text='';this.attributes={};this.disabled=false;this.value='';}
 append(...children){this.children.push(...children);}
 set textContent(value){this.text=String(value);this.children=[];}
 get textContent(){return [this.text,...this.children.map(child=>child.textContent)].join(' ');}
 setAttribute(name,value){this.attributes[name]=String(value);}
}
function response(query){
 const credited={orders:502,members:20,amountMinor:'50200'},empty={orders:0,members:0,amountMinor:'0'},page=Number(query.get('page')||1),pageSize=Number(query.get('pageSize')||100),scope=query.get('scope')||'day';
 return {scope,date:scope==='day'?query.get('date')||'2026-11-08':null,today:'2026-11-08',summary:{credited,pending:{orders:1,members:1,amountMinor:'2000'},failed:empty,review:empty,other:empty},providers:[{provider:'manual_bank',credited,pending:empty,failed:empty,review:empty}],pagination:{total:503,page,pageSize,totalPages:Math.ceil(503/pageSize),hasMore:page*pageSize<503,hasPrevious:page>1},items:[{id:'order-'+page,user_id:'alice',username:'Alice',provider:'manual_bank',amount_minor:'100',status:'credited',created_at:1794067200,updated_at:1794153600}]};
}
function fixture(){
 const elements=new Map(ids.map(id=>[id,new Element()])),requests=[],state={user:{role:'owner'}},control={reply:query=>response(query)};
 const context={state,URLSearchParams,Date,$:id=>elements.get(id),clear:element=>{element.textContent='';},node:(tag,css,text='')=>{const element=new Element();element.textContent=text;return element;},moneyMinor:value=>'MYR '+(Number(value)/100).toFixed(2),paymentProviderLabel:value=>String(value).toUpperCase(),api:async(path,method)=>{assert.equal(method,undefined,'report controls must issue only GET requests');const url=new URL(path,'https://portal.example.test');assert.equal(url.pathname,'/api/admin/deposits');requests.push(url.searchParams);return control.reply(url.searchParams);}};
 runInNewContext(source.slice(start,end)+'\nthis.render=renderAdminDeposits;',context);
 return {state,control,requests,render:context.render,el:id=>elements.get(id)};
}

test('owner report displays full API aggregates and date/all-history/page controls keep requests read-only',async()=>{
 const f=fixture();await f.render();
 assert.match(f.el('adminDepositTitle').textContent,/2026-11-08/);assert.match(f.el('adminDepositSummary').textContent,/502/);assert.match(f.el('adminDepositSummary').textContent,/20/);assert.match(f.el('adminDepositProviders').textContent,/公司银行转账/);assert.match(f.el('adminDepositNotice').textContent,/不受翻页影响/);
 assert.equal(f.el('adminDepositPrevious').disabled,true);assert.equal(f.el('adminDepositNext').disabled,false);
 await f.el('adminDepositNext').onclick();assert.equal(f.requests.at(-1).get('page'),'2');assert.equal(f.el('adminDepositPrevious').disabled,false);assert.match(f.el('adminDepositSummary').textContent,/502/);
 f.el('adminDepositDate').value='2026-11-01';await f.el('adminDepositDate').onchange();assert.equal(f.requests.at(-1).get('date'),'2026-11-01');assert.equal(f.requests.at(-1).get('page'),'1');
 await f.el('adminDepositAll').onclick();assert.equal(f.requests.at(-1).get('scope'),'all');assert.match(f.el('adminDepositTitle').textContent,/全部充值历史/);
 f.el('adminDepositPageSize').value='250';await f.el('adminDepositPageSize').onchange();assert.equal(f.requests.at(-1).get('pageSize'),'250');assert.equal(f.requests.at(-1).get('page'),'1');
 await f.el('adminDepositToday').onclick();assert.equal(f.requests.at(-1).get('scope'),'day');assert.equal(f.requests.at(-1).has('date'),false);
});

test('non-owners do not fetch reports and failed refreshes clear stale financial totals',async()=>{
 const f=fixture();f.state.user.role='staff';await f.render();assert.equal(f.requests.length,0);assert.equal(f.el('adminDepositPanel').hidden,true);
 f.state.user.role='owner';await f.render();assert.ok(f.el('adminDepositSummary').children.length);
 f.control.reply=()=>{throw Error('unavailable');};await f.render();assert.equal(f.el('adminDepositSummary').children.length,0);assert.equal(f.el('adminDepositProviders').children.length,0);assert.match(f.el('adminDepositRecords').textContent,/无法读取/);assert.equal(f.el('adminDepositNext').disabled,true);
});

test('a slow previous date response cannot replace the selected date report',async()=>{
 const f=fixture(),pending=[];f.control.reply=query=>new Promise(resolve=>pending.push({query,resolve}));
 const old=f.render();f.el('adminDepositDate').value='2026-11-01';const latest=f.el('adminDepositDate').onchange();
 pending[1].resolve(response(pending[1].query));await latest;pending[0].resolve(response(pending[0].query));await old;
 assert.match(f.el('adminDepositTitle').textContent,/2026-11-01/);assert.equal(f.el('adminDepositDate').value,'2026-11-01');
});
