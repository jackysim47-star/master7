import test from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import { readFileSync } from "node:fs";
import { startSchedulerLeadership } from "../scripts/scheduler-leader.mjs";

class FakeClient extends EventEmitter {
  constructor(acquired = true) {
    super();
    this.acquired = acquired;
    this.queries = [];
    this.connects = 0;
    this.ends = 0;
  }
  async connect() { this.connects++; }
  async query(sql, values) {
    this.queries.push({ sql, values });
    if (sql.includes("pg_try_advisory_lock")) return { rows: [{ acquired: this.acquired }] };
    if (sql === "SELECT 1") return { rows: [{ "?column?": 1 }] };
    return { rows: [{ pg_advisory_unlock: true }] };
  }
  async end() { this.ends++; }
}

const quiet = () => ({ log() {}, error() {} });

test("only the PostgreSQL advisory-lock owner starts background schedulers", async () => {
  const leaderClient = new FakeClient(true);
  const standbyClient = new FakeClient(false);
  let starts = 0;
  let stops = 0;
  const startWorkers = () => {
    starts++;
    return [{ stop() { stops++; } }, { stop() { stops++; } }];
  };
  const leader = startSchedulerLeadership({
    connectionString: "postgres://fixture/leader",
    clientFactory: () => leaderClient,
    startWorkers,
    retryMs: 60_000,
    heartbeatMs: 60_000,
    logger: quiet(),
  });
  const standby = startSchedulerLeadership({
    connectionString: "postgres://fixture/standby",
    clientFactory: () => standbyClient,
    startWorkers,
    retryMs: 60_000,
    heartbeatMs: 60_000,
    logger: quiet(),
  });
  assert.equal(await leader.ready, true);
  assert.equal(await standby.ready, false);
  assert.equal(starts, 1);
  assert.equal(leader.isLeader(), true);
  assert.equal(standby.isLeader(), false);
  assert.equal(standbyClient.ends, 1);
  await standby.stop();
  await leader.stop();
  assert.equal(stops, 2);
  assert.equal(leaderClient.ends, 1);
  assert.ok(leaderClient.queries.some(item => item.sql.includes("pg_advisory_unlock")));
});

test("connection loss stops every scheduler without leaking connection details", async () => {
  const client = new FakeClient(true);
  let stopped = 0;
  const messages = [];
  const leadership = startSchedulerLeadership({
    connectionString: "postgres://fixture/leader",
    clientFactory: () => client,
    startWorkers: () => [{ stop() { stopped++; } }],
    retryMs: 60_000,
    heartbeatMs: 60_000,
    logger: { log() {}, error(message) { messages.push(message); } },
  });
  assert.equal(await leadership.ready, true);
  client.emit("error", Object.assign(new Error("postgres://user:secret@private-db/internal"), { code: "ECONNRESET" }));
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(leadership.isLeader(), false);
  assert.equal(stopped, 1);
  assert.deepEqual(messages, ["MASTER7 scheduler leadership lost (ECONNRESET); retrying."]);
  assert.doesNotMatch(messages[0], /secret|private-db|postgres:\/\//);
  await leadership.stop();
});

test("missing database configuration keeps scheduler leadership inert", async () => {
  let starts = 0;
  const leadership = startSchedulerLeadership({ connectionString: "", startWorkers: () => { starts++; return []; } });
  assert.equal(leadership.enabled, false);
  assert.equal(await leadership.ready, false);
  assert.equal(starts, 0);
  await leadership.stop();
});

test("a failed client factory stays fail-closed and schedules no worker", async () => {
  let starts = 0;
  const messages = [];
  const leadership = startSchedulerLeadership({
    connectionString: "postgres://fixture/leader",
    clientFactory: () => { throw Object.assign(new Error("postgres://secret"), { code: "ECONNREFUSED" }); },
    startWorkers: () => { starts++; return []; },
    retryMs: 60_000,
    logger: { log() {}, error(message) { messages.push(message); } },
  });
  assert.equal(await leadership.ready, false);
  assert.equal(starts, 0);
  assert.deepEqual(messages, ["MASTER7 scheduler leadership unavailable (ECONNREFUSED); retrying."]);
  assert.doesNotMatch(messages[0], /secret|postgres:\/\//);
  await leadership.stop();
});

test("Render starts schedulers only through the advisory-lock leader", () => {
  const source = readFileSync(new URL("../scripts/start-render.mjs", import.meta.url), "utf8");
  assert.match(source, /startSchedulerLeadership\(\{/);
  assert.match(source, /startWorkers:\s*\(\)\s*=>\s*\[/);
  assert.match(source,/database guards \$\{result\.criticalDatabaseGuardCount\}\/9 ready/);
  assert.match(source,/guard functions \$\{result\.criticalDatabaseGuardFunctionCount\}\/5 attested/);
  assert.ok(source.indexOf('initializePortalDatabase')<source.indexOf('await import("../.output/server/index.mjs")'));
  for (const name of ["startCatalogueSync", "startAccountingCloseScheduler", "startPaymentRecovery", "startWhatsAppDispatch"]) {
    assert.equal((source.match(new RegExp(`${name}\\(\\)`, "g")) ?? []).length, 1, name);
  }
});

test("successful database guard startup logging cannot be classified as an alert", () => {
  const source = readFileSync(new URL("../scripts/start-render.mjs", import.meta.url), "utf8");
  const successLog = source.match(/console\.log\(`([^`]*database guards[^`]*)`\);/)?.[1] ?? "";
  assert.ok(successLog, "database guard startup success log is missing");
  assert.match(successLog, /database guards \$\{result\.criticalDatabaseGuardCount\}\/9 ready/);
  assert.match(successLog, /guard functions \$\{result\.criticalDatabaseGuardFunctionCount\}\/5 attested/);
  assert.doesNotMatch(successLog, /\b(?:critical|error|warning|warn|fatal|emergency|alert|panic|fail|failed|failure)\b/i);
});
