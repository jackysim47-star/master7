import assert from 'node:assert/strict';
import test from 'node:test';
import {generateOpenAiText,openAiGatewayStatus,redactSensitive} from '../lib/openai-gateway.ts';

const configured={enabled:'true',apiBaseUrl:'https://api.example.test/v1',apiKey:'test-openai-key-that-is-long-enough-123',model:'gpt-test-v1'};

test('unified gateway exposes only allow-listed non-transactional tasks',()=>{
 const status=openAiGatewayStatus(configured);
 assert.equal(status.provider,'openai');
 assert.equal(status.ready,true);
 assert.equal(status.serverOnly,true);
 assert.equal(status.toolCalling,false);
 assert.equal(status.transactionAutomation,false);
 assert.deepEqual(status.tasks,['support_reply','operations_summary','handover_summary','translation']);
 assert.doesNotMatch(JSON.stringify(status),/openai-key|secret|token/i);
});

test('gateway redacts sensitive input and never puts a tool or transaction action in the request',async()=>{
 let observed;
 const result=await generateOpenAiText({...configured,fetchImpl:async(url,init)=>{
  observed={url:String(url),init,body:JSON.parse(String(init.body))};
  return Response.json({choices:[{message:{content:'Safe read-only support answer.'}}]});
 }},{task:'support_reply',systemPrompt:'Answer safely.',userPrompt:'password: secret OTP: 12345678 api_key: private-value bank 123456789012'});
 assert.equal(result.text,'Safe read-only support answer.');
 assert.equal(result.providerAttempted,true);
 assert.equal(observed.url,'https://api.example.test/v1/chat/completions');
 assert.equal(observed.init.method,'POST');
 assert.equal(observed.init.redirect,'error');
 assert.equal(observed.body.tools,undefined);
 assert.equal(observed.body.messages.length,2);
 const serialized=JSON.stringify(observed.body);
 assert.doesNotMatch(serialized,/secret|private-value|12345678|123456789012/);
 assert.match(serialized,/REDACTED/);
 assert.equal(redactSensitive('password:abc token:xyz'), '[REDACTED_SECRET] [REDACTED_TOKEN]');
});

test('missing configuration uses no provider call and remains safe for staging',async()=>{
 let calls=0;
 const result=await generateOpenAiText({enabled:'false',apiBaseUrl:'https://api.example.test/v1',apiKey:'',model:'gpt-test',fetchImpl:async()=>{calls++;return Response.json({});}},{task:'operations_summary',systemPrompt:'Summarize safely.',userPrompt:'Read-only status'});
 assert.equal(result.text,null);
 assert.equal(result.providerAttempted,false);
 assert.equal(result.reason,'not_ready');
 assert.equal(calls,0);
});

test('provider errors and invalid responses are contained without leaking upstream data',async()=>{
 const failed=await generateOpenAiText({...configured,fetchImpl:async()=>new Response('private upstream secret',{status:502})},{task:'handover_summary',systemPrompt:'Summarize safely.',userPrompt:'status'});
 assert.equal(failed.text,null);
 assert.equal(failed.providerAttempted,true);
 assert.equal(failed.reason,'provider_error');
 const invalid=await generateOpenAiText({...configured,fetchImpl:async()=>new Response(JSON.stringify({choices:[{message:{content:'x'}}]}),{headers:{'content-type':'application/json'}})},{task:'translation',systemPrompt:'Translate safely.',userPrompt:'hello'});
 assert.equal(invalid.text,null);
 assert.equal(invalid.providerAttempted,true);
 assert.equal(invalid.reason,'invalid_response');
});
