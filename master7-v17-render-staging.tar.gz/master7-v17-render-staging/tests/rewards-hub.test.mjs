import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {
  RewardsHubError,
  checkInRewardsHub,
  defaultRewardsHubProgram,
  getAdminRewardsHub,
  getRewardsHub,
  mytDayStart,
  saveRewardsHubProgram,
  validateRewardsHubProgram,
} from '../lib/rewards-hub.ts';

class Statement{
  constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
  bind(...args){return new Statement(this.sqlite,this.sql,args);}
  async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
  async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
  async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function fixture(){
  const sqlite=new DatabaseSync(':memory:');
  sqlite.exec(`
    PRAGMA foreign_keys=ON;
    CREATE TABLE users(id TEXT PRIMARY KEY,approved INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE settings(id TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL);
    CREATE TABLE deposit_orders(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,amount_minor INTEGER NOT NULL,currency TEXT NOT NULL,status TEXT NOT NULL);
    CREATE TABLE referral_relationships(member_id TEXT PRIMARY KEY,referrer_id TEXT NOT NULL,created_at INTEGER NOT NULL);
    CREATE TABLE wallet_ledger(id TEXT PRIMARY KEY,amount_minor INTEGER NOT NULL);
    CREATE TABLE rewards_checkins(
      id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,myt_day INTEGER NOT NULL,
      cycle_day INTEGER NOT NULL CHECK(cycle_day BETWEEN 1 AND 7),streak INTEGER NOT NULL CHECK(streak>0),
      points INTEGER NOT NULL DEFAULT 0 CHECK(points>=0),created_at INTEGER NOT NULL,UNIQUE(user_id,myt_day)
    );
    CREATE TABLE rewards_points_ledger(
      id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,source_type TEXT NOT NULL,
      source_id TEXT NOT NULL,points INTEGER NOT NULL CHECK(points>0),status TEXT NOT NULL DEFAULT 'earned',
      cash_value_status TEXT NOT NULL DEFAULT 'none',wallet_credit_status TEXT NOT NULL DEFAULT 'disabled',
      redemption_status TEXT NOT NULL DEFAULT 'disabled',created_at INTEGER NOT NULL,UNIQUE(source_type,source_id)
    );
  `);
  sqlite.prepare("INSERT INTO users(id,approved) VALUES('owner',1),('member',1),('ref1',1),('ref2',0)").run();
  const db={
    prepare:sql=>new Statement(sqlite,sql),
    async batch(statements){sqlite.exec('BEGIN');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}
  };
  return {sqlite,db};
}

function activeProgram(){
  const program=defaultRewardsHubProgram();
  program.enabled=true;
  program.pointsEnabled=true;
  program.checkIn={enabled:true,dailyPoints:[1,2,3,4,5,6,7]};
  program.missions.registration={enabled:true,rewardPoints:0};
  program.missions.creditedDeposit={enabled:true,targetMYR:50,rewardPoints:0};
  program.referralMilestones=[{id:'first_referral',active:true,targetQualified:1,rewardPoints:0}];
  program.coupons=[
    {id:'members',title:'Member preview',description:'Eligibility preview only',active:true,expiresAt:null,eligibility:{type:'all',threshold:0}},
    {id:'deposit50',title:'Deposit preview',description:'No automatic redemption',active:true,expiresAt:null,eligibility:{type:'min_credited_deposit',threshold:50}},
  ];
  return program;
}

test('Rewards Hub defaults are closed and declare every money path unavailable',async()=>{
  const {sqlite,db}=fixture();
  const result=await getRewardsHub(db,'member',2_000_000_000);
  assert.equal(result.configured,false);
  assert.equal(result.program.enabled,false);
  assert.deepEqual(result.program.checkIn.dailyPoints,[0,0,0,0,0,0,0]);
  assert.equal(result.capabilities.cashValue,false);
  assert.equal(result.capabilities.walletCredit,false);
  assert.equal(result.capabilities.redemption,false);
  assert.equal(result.capabilities.sources.turnover,'not_connected');
  assert.equal(result.member.points.balance,0);
  assert.equal(result.member.checkIn.enabled,false);
  assert.equal(result.member.missions.find(item=>item.id==='gameplay').sourceStatus,'not_connected');
  sqlite.close();
});

test('Rewards Hub program schema is strict and cannot enable rewards behind disabled points',()=>{
  const extra={...defaultRewardsHubProgram(),unexpected:true};
  assert.throws(()=>validateRewardsHubProgram(extra),RewardsHubError);
  const missing=defaultRewardsHubProgram();delete missing.coupons;
  assert.throws(()=>validateRewardsHubProgram(missing),/Missing Rewards Hub program field/);
  const hidden=defaultRewardsHubProgram();hidden.checkIn.enabled=true;
  assert.throws(()=>validateRewardsHubProgram(hidden),/Enable Lucky Points/);
  const unconnected=defaultRewardsHubProgram();unconnected.pointsEnabled=true;unconnected.missions.turnover={enabled:true,targetMYR:100,rewardPoints:10};
  const accepted=validateRewardsHubProgram(unconnected);
  assert.equal(accepted.missions.turnover.enabled,true);
});

test('verified progress and coupon eligibility are previews and never create money or claim rights',async()=>{
  const {sqlite,db}=fixture();
  sqlite.prepare("INSERT INTO deposit_orders VALUES('d1','member',5000,'MYR','credited')").run();
  sqlite.prepare("INSERT INTO deposit_orders VALUES('d2','member',9999,'MYR','pending')").run();
  sqlite.prepare("INSERT INTO referral_relationships VALUES('ref1','member',1),('ref2','member',2)").run();
  sqlite.prepare("INSERT INTO deposit_orders VALUES('r1','ref1',100,'MYR','credited')").run();
  await saveRewardsHubProgram(db,'owner',{program:activeProgram()},2_000_000_000);
  const result=await getRewardsHub(db,'member',2_000_000_001);
  assert.equal(result.member.verifiedProgress.creditedDeposit.amountMinor,'5000');
  assert.equal(result.member.verifiedProgress.creditedDeposit.orders,1);
  assert.deepEqual(result.member.verifiedProgress.referrals,{source:'referral_relationships+deposit_orders:credited',directCount:2,qualifiedCount:1});
  assert.equal(result.member.missions.find(item=>item.id==='credited_deposit').completed,true);
  assert.equal(result.member.missions.find(item=>item.id==='credited_deposit').claimable,false);
  assert.equal(result.member.referralMilestones[0].completed,true);
  assert.equal(result.member.referralMilestones[0].claimable,false);
  assert.ok(result.member.couponWallet.items.every(item=>item.eligible&&item.claimable===false&&item.redemption===false));
  assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,0);
  const admin=await getAdminRewardsHub(db);
  assert.deepEqual(admin.activity,{checkIns:0,ledgerEntries:0,issuedNonCashPoints:0});
  assert.equal(sqlite.prepare("SELECT COUNT(*) count FROM audit WHERE event='rewards_hub_updated'").get().count,1);
  sqlite.close();
});

test('MYT daily check-in is idempotent, follows the seven-day cycle, and uses only the non-cash ledger',async()=>{
  const {sqlite,db}=fixture(),at=2_000_000_000;
  await saveRewardsHubProgram(db,'owner',{program:activeProgram()},at-1);
  const first=await checkInRewardsHub(db,'member',at);
  const duplicate=await checkInRewardsHub(db,'member',at+3600);
  assert.equal(first.idempotent,false);
  assert.equal(duplicate.idempotent,true);
  assert.equal(first.date,new Date((mytDayStart(at)+8*3600)*1000).toISOString().slice(0,10));
  assert.deepEqual([first.cycleDay,first.streak,first.points],[1,1,1]);
  assert.deepEqual([duplicate.cycleDay,duplicate.streak,duplicate.points],[1,1,1]);
  const second=await checkInRewardsHub(db,'member',at+86400);
  assert.deepEqual([second.cycleDay,second.streak,second.points],[2,2,2]);
  const reset=await checkInRewardsHub(db,'member',at+3*86400);
  assert.deepEqual([reset.cycleDay,reset.streak,reset.points],[1,1,1]);
  assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM rewards_checkins').get().count,3);
  assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM rewards_points_ledger').get().count,3);
  assert.equal(sqlite.prepare('SELECT SUM(points) points FROM rewards_points_ledger').get().points,4);
  assert.equal(sqlite.prepare("SELECT COUNT(*) count FROM audit WHERE event='rewards_checkin'").get().count,3);
  assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM wallet_ledger').get().count,0);
  const state=await getRewardsHub(db,'member',at+3*86400);
  assert.equal(state.member.points.balance,4);
  assert.ok(state.member.points.ledger.every(item=>item.source_type==='checkin'));
  assert.equal(state.member.points.walletCredit,false);
  sqlite.close();
});
