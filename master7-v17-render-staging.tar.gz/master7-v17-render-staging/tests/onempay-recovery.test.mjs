import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {oneMpayCallbackToken,oneMpayCustomer,recoverOneMpayDeposits} from '../lib/onempay.ts';
import {handle} from '../lib/backend.ts';
import {startPaymentRecovery} from '../scripts/payment-recovery-job.mjs';

// Synthetic provider replies only. Recovery must never create or resubmit an order.
const merchant='TESTMERCHANT',secret='fixture-secret-12345678',apiBase='https://api.1mpay.net';
function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf',0)").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){const results=sql.prepare(this.text).all(...this.args);if(this.text.includes("WHERE provider='1mpay' AND status IN")&&state.afterScan){const next=state.afterScan;state.afterScan=null;next();}return {results};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const values=statements.map(statement=>sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return values;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={queryCalls:0,createCalls:0,status:'Successful',patch:value=>value,orders:new Map(),release:null,afterScan:null};
 const context={db,user:null,apiBase,merchant,secretKey:secret,recoveryEnabled:'true',newDepositsEnabled:'false',callbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async(input,init)=>{
  const url=new URL(input);assert.equal(init.method,'GET');assert.match(url.pathname,/^\/transquery\//);state.queryCalls++;
  if(state.release)await state.release;
  const [, ,encodedTrx]=url.pathname.split('/'),trxno=decodeURIComponent(encodedTrx),order=state.orders.get(trxno);assert.ok(order);
  const token=oneMpayCallbackToken(merchant,order.amount,order.refid,order.customer,secret,trxno);
  return Response.json(state.patch({merchant,amount:order.amount,refid:order.refid,customer:order.customer,token,trxno,status:state.status,status_message:state.status,currency:'MYR'}));
 }};
 function insert({id='M7recovery000000001',trxno='TRX-RECOVERY-1',status='unknown',amountMinor=2000,updatedAt=0}={}){
  sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES(?,?,?,?,'1mpay',?,'MYR','bank',?,?,0,?)").run(id,'alice','request-'+id,'fingerprint-'+id,amountMinor,status,trxno,updatedAt);
  if(trxno)state.orders.set(trxno,{refid:id,amount:`${Math.trunc(amountMinor/100)}.${String(amountMinor%100).padStart(2,'0')}`,customer:oneMpayCustomer('alice')});
  return id;
 }
 t.after(()=>sql.close());return {sql,db,state,context,insert};
}

test('recovery credits an existing bound order exactly once while new deposits are paused',async t=>{
 const f=fixture(t),id=f.insert();
 const first=await recoverOneMpayDeposits(f.context,25,1000),second=await recoverOneMpayDeposits(f.context,25,1000);
 assert.equal(first.credited,1);assert.equal(first.queried,1);assert.equal(second.queried,0);assert.equal(f.state.queryCalls,1);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'credited');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').get(id).n,2);
 assert.equal(f.sql.prepare('SELECT SUM(amount_minor) n FROM wallet_ledger WHERE order_id=?').get(id).n,0);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_deposit_credited' AND target=?").get(id).n,1);
});

test('non-successful provider query remains pending and can later recover',async t=>{
 const f=fixture(t),id=f.insert();f.state.status='Failed';
 const pending=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(pending.pending,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'unknown');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 f.state.status='Successful';const credited=await recoverOneMpayDeposits(f.context,25,Math.floor(Date.now()/1000)+120);assert.equal(credited.credited,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,2);
});

test('non-success recovery preserves a usable created checkout and a failed decision',async t=>{
 const f=fixture(t),created=f.insert({id:'M7recoveryCreated01',trxno:'TRX-CREATED',status:'created'}),failed=f.insert({id:'M7recoveryFailed001',trxno:'TRX-FAILED',status:'failed'});
 f.sql.prepare("UPDATE deposit_orders SET checkout_url='https://api.1mpay.net/checkout/still-usable' WHERE id=?").run(created);f.state.status='Pending';
 const result=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(result.pending,2);assert.equal(result.queried,2);
 assert.deepEqual({...f.sql.prepare('SELECT status,checkout_url FROM deposit_orders WHERE id=?').get(created)},{status:'created',checkout_url:'https://api.1mpay.net/checkout/still-usable'});
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(failed).status,'failed');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('query binding mismatch moves only that order to review without credit',async t=>{
 const f=fixture(t),id=f.insert();f.state.patch=value=>({...value,amount:'21.00'});
 const result=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(result.review,1);assert.equal(result.errors,0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'review');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_recovery_review'").get().n,1);
});

test('a concurrent callback credit cannot receive a false recovery review audit',async t=>{
 const f=fixture(t),id=f.insert();f.state.patch=value=>{
  f.sql.exec(`INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES
   ('concurrent-member','${id}','alice','member',2000,'MYR',0),
   ('concurrent-clearing','${id}','alice','provider_clearing',-2000,'MYR',0)`);
  f.sql.prepare("UPDATE deposit_orders SET status='credited' WHERE id=?").run(id);
  return {...value,amount:'21.00'};
 };
 const result=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(result.review,0);assert.equal(result.skipped,1);assert.equal(result.errors,0);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'credited');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_recovery_review'").get().n,0);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').get(id).n,2);
});

test('a stale query mismatch cannot mark a newly rebound reference for review',async t=>{
 const f=fixture(t),id=f.insert();f.state.patch=value=>{f.sql.prepare("UPDATE deposit_orders SET provider_trade_no='TRX-NEW',updated_at=1001 WHERE id=?").run(id);return {...value,amount:'21.00'};};
 const result=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(result.review,0);assert.equal(result.skipped,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'unknown');assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_recovery_review'").get().n,0);
});

test('unknown order without trxno is held for review without any upstream call',async t=>{
 const f=fixture(t),id=f.insert({trxno:null,status:'unknown'});
 const result=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(result.review,1);assert.equal(result.queried,0);assert.equal(f.state.queryCalls,0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'review');
 const repeat=await recoverOneMpayDeposits(f.context,25,2000);assert.equal(repeat.scanned,0);assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_recovery_review'").get().n,1);
});

test('a reference received during a missing-reference scan is not overwritten by manual review',async t=>{
 const f=fixture(t),id=f.insert({trxno:null,status:'unknown'});f.state.afterScan=()=>{
  f.sql.prepare("UPDATE deposit_orders SET provider_trade_no='TRX-LATE',updated_at=1000 WHERE id=?").run(id);
  f.state.orders.set('TRX-LATE',{refid:id,amount:'20.00',customer:oneMpayCustomer('alice')});
 };
 const first=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(first.review,0);assert.equal(first.skipped,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'unknown');assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='1mpay_recovery_review'").get().n,0);
 const next=await recoverOneMpayDeposits(f.context,25,1100);assert.equal(next.credited,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').get(id).n,2);
});

test('a 1MPay-only scheduled worker queries a stored order and credits its ledger once',async t=>{
 const f=fixture(t),id=f.insert({updatedAt:Math.floor(Date.now()/1000)-120}),token='recovery-fixture-token-'.padEnd(40,'r');
 const prepare=f.db.prepare;let otherProviderReads=0;f.db.prepare=text=>{if(text.includes('provider_payouts')||text.includes('payment_recovery_leases'))otherProviderReads++;return prepare(text);};
 const config={db:f.db,identity:null,ownerEmail:'',newDepositsEnabled:'false',paymentRecoveryToken:token,oneMpayApiBase:f.context.apiBase,oneMpayMerchant:merchant,oneMpaySecretKey:secret,oneMpayCallbackUrl:f.context.callbackUrl,oneMpayReturnUrl:f.context.returnUrl,oneMpayRecoveryEnabled:'true',oneMpayFetch:f.context.fetchImpl,gspayApiBase:'https://api.thegspay.com',gspayAuthKey:'a'.repeat(32),gspaySecretKey:'b'.repeat(32),gspayReturnUrl:'https://master7-v17-staging.onrender.com/payment/return',gspayRecoveryEnabled:'true',withdrawalDataKey:'w'.repeat(40),vpayGatewayUrl:'https://master7-integration-gateway.onrender.com',vpayPayoutToken:'p'.repeat(40),vpayCallbackToken:'c'.repeat(40),vpayTraderId:'3647'};
 let loopbackCalls=0;const worker=startPaymentRecovery({token,port:4321,vpayEnabled:false,gspayEnabled:false,oneMpayEnabled:true},async(url,init)=>{loopbackCalls++;assert.equal(url,'http://127.0.0.1:4321/api/internal/payment-recovery?provider=1mpay');return handle(new Request(url,init),config);});
 await worker.run();await worker.run();worker.stop();assert.equal(loopbackCalls,2);assert.equal(otherProviderReads,0);assert.equal(f.state.queryCalls,1);assert.equal(f.state.createCalls,0);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(id).status,'credited');assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').get(id).n,2);
});

test('concurrent workers optimistically claim one order and make one provider query',async t=>{
 const f=fixture(t),id=f.insert();let release;f.state.release=new Promise(resolve=>{release=resolve;});
 const first=recoverOneMpayDeposits(f.context,25,1000);await new Promise(resolve=>setImmediate(resolve));const second=recoverOneMpayDeposits(f.context,25,1000);release();
 const [a,b]=await Promise.all([first,second]);assert.equal(a.queried+b.queried,1);assert.equal(f.state.queryCalls,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger WHERE order_id=?').get(id).n,2);
});

test('disabled or incomplete recovery performs no scan, query or write',async t=>{
 const f=fixture(t),id=f.insert(),before=f.sql.prepare('SELECT updated_at,status FROM deposit_orders WHERE id=?').get(id);f.context.recoveryEnabled='false';
 const result=await recoverOneMpayDeposits(f.context,25,1000);assert.equal(result.enabled,false);assert.equal(result.scanned,0);assert.equal(f.state.queryCalls,0);assert.deepEqual({...f.sql.prepare('SELECT updated_at,status FROM deposit_orders WHERE id=?').get(id)},{...before});
});
