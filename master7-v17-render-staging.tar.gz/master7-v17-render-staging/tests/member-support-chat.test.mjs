import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';

function fixture(t){
 const sql=new DatabaseSync(':memory:');for(const name of readdirSync(new URL('../drizzle/',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 for(const [id,role] of [['alice','member'],['bob','member'],['owner','owner'],['agent','staff']])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,1,?,0)').run(id,id,role,'csrf-'+id);
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=statements.map(s=>sql.prepare(s.text).run(...s.args));sql.exec('COMMIT');return result;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 async function call(who,path,method='GET',data,extra={}){const response=await handle(new Request('https://portal.example.test'+path,{method,headers:{Origin:'https://portal.example.test','Content-Type':'application/json','X-CSRF-Token':'csrf-'+who},...(data===undefined?{}:{body:JSON.stringify(data)})}),{db,identity:who?{userId:who,email:who+'@example.test'}:null,ownerEmail:'',...extra});return {status:response.status,data:await response.json()};}
 t.after(()=>sql.close());return {sql,call};
}

test('a short Chinese chat reaches the admin inbox and admin reply returns to the right member',async t=>{
 const f=fixture(t),created=await f.call('alice','/api/tickets','POST',{subject:'Customer chat',message:'你好'});assert.equal(created.status,201);
 const id=created.data.id,inbox=await f.call('owner','/api/tickets');assert.equal(inbox.status,200);assert.equal(inbox.data.items.find(x=>x.id===id).message,'你好');
 assert.equal((await f.call('bob','/api/tickets')).data.items.length,0);
 assert.equal((await f.call('bob','/api/tickets/reply','POST',{ticketId:id,message:'Wrong member'})).status,404);
 assert.equal((await f.call('agent','/api/tickets')).status,401,'retired staff accounts remain blocked');
 assert.equal((await f.call('owner','/api/tickets/reply','POST',{ticketId:id,message:'客服已收到，会在这里回复你。'})).status,200);
 const thread=(await f.call('alice','/api/tickets')).data.items[0];assert.match(thread.replies.at(-1).message,/客服已收到/);
 assert.equal((await f.call('alice','/api/tickets/notifications')).data.unread,1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('pending members can ask support while financial writes remain blocked',async t=>{
 const f=fixture(t);f.sql.prepare("UPDATE users SET approved=0 WHERE id='alice'").run();
 const chat=await f.call('alice','/api/tickets','POST',{subject:'Customer chat',message:'你好'});assert.equal(chat.status,201);
 assert.equal((await f.call('alice','/api/support/handoff','POST',{ticketId:chat.data.id})).status,200);
 assert.equal((await f.call('alice','/api/tickets/reply','POST',{ticketId:chat.data.id,message:'请协助审核'})).status,200);
 assert.equal((await f.call('alice','/api/payments/vpay/order','POST',{})).status,403);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('turning automation off during generation suppresses the delayed reply',async t=>{
 const f=fixture(t);let start,finish;const started=new Promise(resolve=>{start=resolve;}),provider=new Promise(resolve=>{finish=resolve;});
 const pending=f.call('alice','/api/tickets','POST',{subject:'Customer chat',message:'Which languages can support use?'},{supportAiEnabled:'true',supportAiApiBaseUrl:'https://ai.example.test/v1',supportAiApiKey:'test-key-that-is-long-enough-123456',supportAiModel:'test-model',supportAiFetch:async()=>{start();return provider;}});
 await started;await f.call('owner','/api/admin/support-settings','POST',{aiEnabled:false,humanHandoff:true});finish(Response.json({choices:[{message:{content:'Support can help in three languages.'}}]}));
 const response=await pending;assert.equal(response.status,201);assert.equal(response.data.automatedReply,false);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM replies').get().n,0);
});

test('AI teaches the actual verification entry on a customer follow-up',async t=>{
 const f=fixture(t),created=await f.call('alice','/api/tickets','POST',{subject:'Customer chat',message:'你好'});
 const response=await f.call('alice','/api/tickets/reply','POST',{ticketId:created.data.id,message:'身份审核在哪里？'});assert.equal(response.status,200);
 const replies=(await f.call('alice','/api/tickets')).data.items[0].replies;
 assert.equal(replies.at(-1).user_id,'system-support-assistant');assert.match(replies.at(-1).message,/菜单/);assert.match(replies.at(-1).message,/申请审核/);
});

test('owner AI switch and per-conversation human handoff both stop automated replies',async t=>{
 const f=fixture(t),status=await f.call(null,'/api/support/status');assert.equal(status.status,200);assert.equal(status.data.aiRepliesEnabled,true);assert.ok(!JSON.stringify(status.data).includes('apiKey'));
 const created=await f.call('alice','/api/tickets','POST',{subject:'Customer chat',message:'Hello'}),id=created.data.id;
 assert.equal((await f.call('bob','/api/support/handoff','POST',{ticketId:id})).status,404);
 assert.equal((await f.call('alice','/api/support/handoff','POST',{ticketId:id})).status,200);
 const count=f.sql.prepare("SELECT COUNT(*) n FROM replies WHERE user_id='system-support-assistant'").get().n;
 assert.equal((await f.call('alice','/api/tickets/reply','POST',{ticketId:id,message:'Please let an agent help.'})).status,200);
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM replies WHERE user_id='system-support-assistant'").get().n,count);
 assert.equal((await f.call('alice','/api/tickets')).data.items[0].humanHandoff,true);
 assert.equal((await f.call('alice','/api/admin/support-settings','POST',{aiEnabled:false,humanHandoff:true})).status,403);
 assert.equal((await f.call('owner','/api/admin/support-settings','POST',{aiEnabled:false,humanHandoff:true})).status,200);
 assert.equal((await f.call(null,'/api/support/status')).data.aiRepliesEnabled,false);
 const manual=await f.call('bob','/api/tickets','POST',{subject:'Customer chat',message:'Help'});assert.equal(manual.status,201);assert.equal(manual.data.automatedReply,false);
});
