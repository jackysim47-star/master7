import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {join} from 'node:path';

const migration='0110_game_provider_adapter_core.sql';
const coreTables=[
 'game_provider_profiles','game_provider_players','game_provider_sessions','game_wallet_transfers','game_rounds',
 'game_transactions','game_wallet_postings','game_callback_receipts','game_wager_sync_cursors','game_recovery_leases',
];

function database(t){
 const db=new DatabaseSync(':memory:');t.after(()=>db.close());db.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync('drizzle').filter(file=>file.endsWith('.sql')&&file<migration).sort())db.exec(readFileSync(join('drizzle',file),'utf8'));
 return db;
}

test('adapter core migration is additive, repeatable and preserves the legacy MegaH5 ledger',t=>{
 const db=database(t);
 db.exec(`
  INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member','member',1,'csrf',1);
  INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,expected_return_minor,deposit_reference,withdraw_reference,created_at,updated_at,settled_at)
   VALUES('legacy-session','member','megah5','legacy-player','1001','settled',1000,1200,1200,'legacy-deposit','legacy-withdrawal',1,2,2);
  INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at)
   VALUES('legacy-result','legacy-session','member','game_result',200,'MYR',2);
 `);
 const beforeSession={...db.prepare("SELECT * FROM game_wallet_sessions WHERE id='legacy-session'").get()};
 const beforeLedger={...db.prepare("SELECT * FROM game_wallet_ledger WHERE id='legacy-result'").get()};
 const sql=readFileSync(join('drizzle',migration),'utf8');db.exec(sql);db.exec(sql);
 assert.deepEqual({...db.prepare("SELECT * FROM game_wallet_sessions WHERE id='legacy-session'").get()},beforeSession);
 assert.deepEqual({...db.prepare("SELECT * FROM game_wallet_ledger WHERE id='legacy-result'").get()},beforeLedger);
 const tables=db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(row=>row.name);
 for(const table of coreTables)assert.ok(tables.includes(table),table);
 assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
});

test('adapter core isolates profiles and enforces immutable external identifiers',t=>{
 const db=database(t);db.exec(readFileSync(join('drizzle',migration),'utf8'));
 db.exec(`
  INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member','member',1,'csrf',1);
  INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at)
   VALUES('jili-myr-1','jili','JILI MYR 1:1','jili','transfer','cash','MYR',1,1,'uat','uat',1,1),
         ('jili-my1-100','jili','JILI MY1 1:100','jili','transfer','cash','MY1',100,1,'uat','uat',1,1);
  INSERT INTO game_provider_players(profile_id,user_id,provider_player_id,status,created_at,updated_at,verified_at)
   VALUES('jili-myr-1','member','member-myr','verified',1,1,1),('jili-my1-100','member','member-my1','verified',1,1,1);
  INSERT INTO game_provider_sessions(id,profile_id,user_id,provider_player_id,game_code,provider_game_id,request_key,request_fingerprint,wallet_mode,currency,status,created_at,updated_at)
   VALUES('session-myr','jili-myr-1','member','member-myr','slot-1','raw-slot-1','launch-1','fingerprint-1','transfer','MYR','active',1,1),
         ('session-my1','jili-my1-100','member','member-my1','slot-1','raw-slot-1','launch-1','fingerprint-2','transfer','MY1','active',1,1);
  INSERT INTO game_wallet_transfers(id,session_id,profile_id,user_id,direction,request_key,request_fingerprint,provider_reference,amount_minor,currency,status,attempts,created_at,updated_at,completed_at)
   VALUES('transfer-1','session-myr','jili-myr-1','member','deposit','deposit-1','transfer-fingerprint','provider-transfer-1',1000,'MYR','succeeded',1,1,1,1);
  INSERT INTO game_rounds(id,profile_id,user_id,session_id,provider_round_id,provider_game_id,currency,status,total_bet_minor,total_win_minor,opened_at,updated_at,closed_at)
   VALUES('round-myr','jili-myr-1','member','session-myr','provider-round-1','raw-slot-1','MYR','settled',100,250,1,2,2),
         ('round-my1','jili-my1-100','member','session-my1','provider-round-1','raw-slot-1','MY1','settled',10000,25000,1,2,2);
  INSERT INTO game_transactions(id,profile_id,user_id,round_id,provider_transaction_id,event_type,amount_minor,currency,request_fingerprint,status,received_at,applied_at)
   VALUES('transaction-myr','jili-myr-1','member','round-myr','provider-transaction-1','credit',250,'MYR','event-fingerprint-1','applied',2,2),
         ('transaction-my1','jili-my1-100','member','round-my1','provider-transaction-1','credit',25000,'MY1','event-fingerprint-2','applied',2,2);
  INSERT INTO game_wallet_postings(id,transaction_id,profile_id,user_id,account_code,amount_minor,currency,created_at)
   VALUES('posting-member','transaction-myr','jili-myr-1','member','member',250,'MYR',2),
         ('posting-clearing','transaction-myr','jili-myr-1','member','provider_game_clearing',-250,'MYR',2);
  INSERT INTO game_callback_receipts(profile_id,event_key,provider_event_id,callback_type,payload_hash,signature_status,processing_status,received_at,processed_at)
   VALUES('jili-myr-1','callback-1','provider-event-1','settlement','payload-hash','valid','processed',2,2);
  INSERT INTO game_wager_sync_cursors(profile_id,cursor_value,watermark_at,status,last_success_at,updated_at)
   VALUES('jili-myr-1','cursor-1',2,'idle',2,2);
  INSERT INTO game_recovery_leases(profile_id,resource_type,resource_id,claim_token,locked_until,last_checked_at,attempts)
   VALUES('jili-myr-1','transfer','transfer-1','claim',10,2,1);
 `);
 assert.equal(db.prepare("SELECT COUNT(*) count FROM game_transactions WHERE provider_transaction_id='provider-transaction-1'").get().count,2,'the same external id is isolated by profile');
 assert.equal(db.prepare("SELECT SUM(amount_minor) amount FROM game_wallet_postings WHERE transaction_id='transaction-myr'").get().amount,0);
 assert.throws(()=>db.prepare("INSERT INTO game_transactions(id,profile_id,user_id,round_id,provider_transaction_id,event_type,amount_minor,currency,request_fingerprint,status,received_at) VALUES('duplicate','jili-myr-1','member','round-myr','provider-transaction-1','credit',1,'MYR','different','received',3)").run(),/UNIQUE/);
 assert.throws(()=>db.prepare("INSERT INTO game_wallet_transfers(id,session_id,profile_id,user_id,direction,request_key,request_fingerprint,provider_reference,amount_minor,currency,status,created_at,updated_at) VALUES('mismatch','session-my1','jili-myr-1','member','deposit','bad','bad','bad',1,'MYR','prepared',3,3)").run(),/FOREIGN KEY/);
 assert.throws(()=>db.prepare("INSERT INTO game_callback_receipts(profile_id,event_key,provider_event_id,callback_type,payload_hash,signature_status,processing_status,received_at) VALUES('jili-myr-1','callback-2','provider-event-1','settlement','different','valid','received',3)").run(),/UNIQUE/);
 assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
});
