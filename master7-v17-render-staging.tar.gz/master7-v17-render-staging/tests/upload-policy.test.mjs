import assert from 'node:assert/strict';
import test from 'node:test';
import {ASSET_UPLOAD_SCOPES,UPLOAD_APPROVAL_MODE,uploadPolicyStatus} from '../lib/upload-policy.ts';

test('safe layered upload policy approves only validated non-financial assets',()=>{
 const status=uploadPolicyStatus();
 assert.equal(UPLOAD_APPROVAL_MODE,'layered_safe');
 assert.equal(status.mode,'layered_safe');
 assert.equal(status.environmentReady,true);
 assert.equal(status.assets.autoApproveAfterValidation,true);
 assert.deepEqual(status.assets.approvalScope,[...ASSET_UPLOAD_SCOPES]);
 assert.equal(status.receipt.autoApprove,false);
 assert.equal(status.receipt.humanApprovalRequired,true);
 assert.equal(status.receipt.aiMaySuggest,true);
 assert.equal(status.receipt.walletCreditOnUpload,false);
 assert.equal(status.package.target,'v173_staging');
 assert.equal(status.package.productionAutoDeploy,false);
 assert.equal(status.package.transactionSwitchesChanged,false);
 assert.doesNotMatch(JSON.stringify(status),/api[_-]?key|password|secret|token|credential/i);
});

test('receipt approval stays disabled even if a caller requests it',()=>{
 const status=uploadPolicyStatus({mode:'layered_safe',assetAutoApproval:'true',receiptAutoApproval:'true'});
 assert.equal(status.assets.autoApproveAfterValidation,true);
 assert.equal(status.receipt.autoApprove,false);
 assert.equal(status.receipt.walletCreditOnUpload,false);
});

test('invalid policy mode blocks asset auto-approval',()=>{
 const status=uploadPolicyStatus({mode:'unsafe',assetAutoApproval:'true'});
 assert.equal(status.modeValid,false);
 assert.equal(status.environmentReady,false);
 assert.equal(status.assets.autoApproveAfterValidation,false);
 assert.equal(status.receipt.autoApprove,false);
});
