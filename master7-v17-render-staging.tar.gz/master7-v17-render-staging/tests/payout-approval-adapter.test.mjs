import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {encryptWithdrawalValue} from '../lib/withdrawal-secrets.ts';
import {submitVPayPayout} from '../lib/vpay-payout.ts';
import {submitGSPayPayout} from '../lib/gspay.ts';
import {malaysiaBankCodes} from '../lib/malaysia-banks.ts';

const hash=v=>createHash('sha256').update(v).digest('hex'),dataKey='synthetic-withdrawal-key-'.padEnd(40,'x');
function fixture(t,provider){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');for(const f of readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));
 sql.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'x',0),('owner','owner','owner',1,'y',0); UPDATE payment_channel_controls SET status='active' WHERE provider_id='gspay'; UPDATE provider_payout_controls SET submission_enabled=1 WHERE provider_id='gspay'; INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('alice','passed','passed',1,'a',0,0)");
 sql.exec("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fund','alice','fund','f','vpay',10000,'MYR','2','credited',0,0); INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('credit','fund','alice','member',10000,'MYR',0),('clearing','fund','alice','provider_clearing',-10000,'MYR',0)");
 const holder=encryptWithdrawalValue('Alice Example',dataKey),number=encryptWithdrawalValue('123456789012',dataKey),fingerprint=hash(JSON.stringify({provider,userId:'alice',amount:'2000',bank:'maybank',account:hash('123456789012')}));
 sql.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,updated_by,created_at,updated_at) VALUES('withdrawal','alice','request-key',?,?,'maybank','Maybank',?,?,'9012',2000,'MYR','approved','owner',0,0)").run(provider,provider,holder,number);
 sql.prepare("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,created_at,updated_at) VALUES('payout-id','withdrawal',?,'request-key',?,2000,'MYR','prepared','not_submitted',0,0)").run(provider,fingerprint);
 sql.exec("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('alice','withdrawal','withdrawal',2000,0)");
 const snapshot=['withdrawal','payout-id','alice',provider,'request-key','2000','MYR','maybank',holder,number,fingerprint,'1'];
 const insert=sql.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,0)');
 insert.run('withdrawal_request_v1_withdrawal','alice','withdrawal_requested_v1','withdrawal');
 insert.run('withdrawal_approved_v1_withdrawal','owner','withdrawal_approved_v1','withdrawal');
 insert.run('withdrawal_approval_binding_v1_withdrawal_'+hash(JSON.stringify(snapshot)),'owner','withdrawal_approval_binding_v1','withdrawal');
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(stmts){sql.exec('BEGIN');try{const result=stmts.map(s=>sql.prepare(s.text).run(...s.args));sql.exec('COMMIT');return result;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const state={calls:0}; const fetchImpl=async()=>{state.calls++;throw Error('synthetic timeout');};
 const context=provider==='vpay'?{db,gatewayUrl:'https://master7-integration-gateway.onrender.com',payoutToken:'p'.repeat(40),callbackToken:'c'.repeat(40),vpayTraderId:'1',withdrawalDataKey:dataKey,fetchImpl}:{db,user:null,apiBase:'https://api.thegspay.com',authKey:'a'.repeat(32),secretKey:'b'.repeat(32),returnUrl:'https://master7-v17-staging.onrender.com/payment/return',payoutEnabled:'true',newPayoutsEnabled:'true',payoutIpWhitelistConfirmed:'true',payoutBankTargetsJson:JSON.stringify(Object.fromEntries(malaysiaBankCodes.map((c,i)=>[c,'bank'+i]))),withdrawalDataKey:dataKey,fetchImpl};
 const input={payoutId:'payout-id',withdrawalId:'withdrawal',userId:'alice',accountHolder:'Alice Example',accountNumber:'123456789012',bankCode:'maybank',amountMinor:'2000'};
 const submit=()=>provider==='vpay'?submitVPayPayout(input,context):submitGSPayPayout(input,context);
 t.after(()=>sql.close());return {sql,state,submit};
}
for(const provider of ['vpay','gspay']){
 test(`${provider}: only one synthetic send after approval; unknown outcome is never resent`,async t=>{const f=fixture(t,provider);await Promise.all([f.submit(),f.submit()]);assert.equal(f.state.calls,1);assert.equal(f.sql.prepare('SELECT status FROM withdrawal_requests').get().status,'processing');assert.equal(f.sql.prepare('SELECT create_outcome FROM provider_payouts').get().create_outcome,'unknown');});
 for(const [name,mutate] of [
  ['missing request',s=>s.exec("DELETE FROM audit WHERE event='withdrawal_requested_v1'")],
  ['wrong approval actor',s=>s.exec("UPDATE audit SET user_id='alice' WHERE event='withdrawal_approved_v1'")],
  ['insufficient wallet',s=>s.exec("DELETE FROM wallet_ledger")],
  ['missing approval',s=>s.exec("DELETE FROM audit WHERE event='withdrawal_approved_v1'")],
  ['missing approval binding',s=>s.exec("DELETE FROM audit WHERE event='withdrawal_approval_binding_v1'")],
  ['changed holder',s=>s.prepare('UPDATE withdrawal_requests SET account_holder_encrypted=?').run(encryptWithdrawalValue('Alice Other',dataKey))],
  ['missing reservation',s=>s.exec('DELETE FROM wallet_reservations')],
  ['changed compliance version',s=>s.exec('UPDATE manual_compliance_reviews SET version=2')],
  ['revoked AML',s=>s.exec("UPDATE manual_compliance_reviews SET aml_status='failed'")],
  ['pending',s=>s.exec("UPDATE withdrawal_requests SET status='pending'")],
  ['disabled member',s=>s.exec("UPDATE users SET approved=0 WHERE id='alice'")],
  ['disabled approver',s=>s.exec("UPDATE users SET approved=0 WHERE id='owner'")],
 ])test(`${provider}: ${name} blocks provider submission`,async t=>{const f=fixture(t,provider);mutate(f.sql);try{await f.submit();}catch{}assert.equal(f.state.calls,0);assert.ok(['prepared','review'].includes(f.sql.prepare('SELECT status FROM provider_payouts').get().status));assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,name==='missing reservation'?0:1);});
}
