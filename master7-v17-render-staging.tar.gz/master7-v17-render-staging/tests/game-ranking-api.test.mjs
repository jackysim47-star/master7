import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {handle} from '../lib/backend.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}
function fixture(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(`
  CREATE TABLE users(id TEXT PRIMARY KEY,username TEXT NOT NULL,role TEXT NOT NULL,approved INTEGER NOT NULL,csrf TEXT NOT NULL,created_at INTEGER NOT NULL);
  CREATE TABLE settings(id TEXT PRIMARY KEY,value TEXT NOT NULL);
  CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL);
  CREATE TABLE rate_limits(id TEXT PRIMARY KEY,count INTEGER NOT NULL,expires_at INTEGER NOT NULL);
  CREATE TABLE game_catalogue_cache(provider_id TEXT PRIMARY KEY,status TEXT NOT NULL,complete INTEGER NOT NULL);
  CREATE TABLE api_supplier_artwork(provider_id TEXT PRIMARY KEY,status TEXT NOT NULL,image_data TEXT NOT NULL DEFAULT '',updated_at INTEGER NOT NULL);
  CREATE TABLE providers(id TEXT PRIMARY KEY,visible INTEGER NOT NULL);
  INSERT INTO users VALUES('owner','owner@example.test','owner',1,'owner-csrf',1),('staff','staff@example.test','staff',1,'staff-csrf',2);
 `);const db={prepare:sql=>new Statement(sqlite,sql),async batch(list){sqlite.exec('BEGIN');try{const results=[];for(const item of list)results.push(await item.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 async function call(who,path,method='GET',data){const csrf=who==='owner'?'owner-csrf':who==='staff'?'staff-csrf':'',response=await handle(new Request(`https://portal.example.test${path}`,{method,headers:{'content-type':'application/json','origin':'https://portal.example.test','x-csrf-token':csrf},...(data===undefined?{}:{body:JSON.stringify(data)})}),{db,identity:who?{userId:who,email:`${who}@example.test`}:null,ownerEmail:'owner@example.test'});return {status:response.status,data:await response.json()};}
 return {sqlite,call};
}

test('game ranking routes are owner controlled and reorder only the 34 platform cards',async()=>{
 const {sqlite,call}=fixture(),publicDefault=await call(null,'/api/game-ranking');assert.equal(publicDefault.status,200);assert.equal(publicDefault.data.platformCount,34);assert.equal(publicDefault.data.automaticRanking,false);assert.equal(publicDefault.data.internalGamesRanked,false);assert.equal(publicDefault.data.ranking.categories.HOT[0],'megah5');assert.equal(Object.hasOwn(publicDefault.data,'updatedBy'),false);assert.equal(Object.hasOwn(publicDefault.data,'storage'),false);
 assert.equal((await call('staff','/api/admin/game-ranking')).status,403);const owner=await call('owner','/api/admin/game-ranking');assert.equal(owner.status,200);const ranking=structuredClone(owner.data.ranking);ranking.categories.HOT=[ranking.categories.HOT[1],ranking.categories.HOT[0],...ranking.categories.HOT.slice(2)];
 ranking.categories.LIVE=[...ranking.categories.LIVE].reverse();ranking.categories.SLOT=[ranking.categories.SLOT.at(-1),...ranking.categories.SLOT.slice(0,-1)];
 const duplicate=structuredClone(ranking);duplicate.categories.HOT[1]=duplicate.categories.HOT[0];assert.equal((await call('owner','/api/admin/game-ranking','POST',{ranking:duplicate})).status,400);
 const saved=await call('owner','/api/admin/game-ranking','POST',{ranking});assert.equal(saved.status,200);assert.equal(saved.data.ranking.categories.HOT[0],'jili');assert.equal(saved.data.ranking.categories.LIVE[0],'awc');assert.equal(saved.data.ranking.categories.SLOT[0],'evo888h5');assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='game_provider_ranking_updated'").get().n,1);
 const publicSaved=await call(null,'/api/game-ranking');assert.equal(publicSaved.data.ranking.categories.LIVE[0],'awc');assert.equal(Object.hasOwn(publicSaved.data,'updatedBy'),false);assert.equal(Object.hasOwn(publicSaved.data,'storage'),false);
 const games=await call(null,'/api/games');assert.equal(games.status,200);assert.equal(games.data.providers.length,34);assert.equal(games.data.providers[0].id,'jili');assert.equal(games.data.providers[0].position,1);assert.equal(games.data.providers[0].rankingSource,'owner_curated');assert.equal(games.data.games.length,0);assert.equal(games.data.playable,false);assert.equal(games.data.liveReady,false);assert.equal(games.data.ranking.automaticRanking,false);
});
