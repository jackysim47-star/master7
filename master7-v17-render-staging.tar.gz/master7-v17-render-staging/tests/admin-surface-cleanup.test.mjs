import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const read=path=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');
const app=read('public/assets/app.js'),portal=read('app/portal.html');
const definitions=app.slice(0,app.indexOf('(async function start(){'));

class Element {
 constructor(tag='div',attrs={}){this.tag=tag;this.attrs={...attrs};this.id=attrs.id;this.value=attrs.value||'';this.textContent='';this.hidden=Object.hasOwn(attrs,'hidden');this.disabled=false;this.checked=false;this.children=[];this.handlers={};this.dataset={};this.style={};this.className=attrs.class||'';for(const [key,value] of Object.entries(attrs))if(key.startsWith('data-'))this.dataset[key.slice(5).replace(/-([a-z])/g,(_,letter)=>letter.toUpperCase())]=value;const classes=new Set(this.className.split(/\s+/));this.classList={toggle:(key,force)=>{const on=force??!classes.has(key);if(on)classes.add(key);else classes.delete(key);return on;},contains:key=>classes.has(key),add:key=>classes.add(key),remove:key=>classes.delete(key)};}
 addEventListener(name,handler){this.handlers[name]=handler;}
 setAttribute(name,value){this.attrs[name]=String(value);}
 getAttribute(name){return this.attrs[name]??null;}
 removeAttribute(name){delete this.attrs[name];}
 append(...items){this.children.push(...items);}
 replaceChildren(...items){this.children=[...items];}
 querySelector(){return null;}
 get options(){return this.children;}
}
function fixture(){
 const nodes=[];for(const match of portal.matchAll(/<([a-zA-Z][\w-]*)\b([^<>]*)>/g)){
  const attrs=Object.fromEntries([...match[2].matchAll(/([^\s=]+)(?:="([^"]*)")?/g)].map(item=>[item[1],item[2]??'']));const node=new Element(match[1],attrs);node.offset=match.index;nodes.push(node);
 }
 const ids=new Map(nodes.filter(node=>node.id).map(node=>[node.id,node])),menuStart=portal.indexOf('id="adminInternalSidebar"'),menuEnd=portal.indexOf('</nav>',menuStart),calls=[];
 const matches=(node,selector)=>{
  if(selector===' .admin-internal-sidebar a'||selector==='.admin-internal-sidebar a')return node.tag==='a'&&node.offset>menuStart&&node.offset<menuEnd;
  if(selector.startsWith('.'))return node.className.split(/\s+/).includes(selector.slice(1));
  const attribute=selector.match(/^\[([^\]=]+)(?:="([^"]*)")?\]$/);return attribute?Object.hasOwn(node.attrs,attribute[1])&&(attribute[2]===undefined||node.attrs[attribute[1]]===attribute[2]):false;
 };
 const document={getElementById:id=>ids.get(id)??null,querySelectorAll:selector=>nodes.filter(node=>selector.split(',').some(item=>matches(node,item.trim()))),querySelector:selector=>nodes.find(node=>matches(node,selector))??null,createElement:tag=>new Element(tag),addEventListener(){},body:new Element('body')};
 const context=vm.createContext({document,window:{scrollTo(){}},location:{pathname:'/admin'},history:{replaceState(){}},localStorage:{getItem:()=>null,setItem(){}},calls,console});vm.runInContext(definitions,context);
 // Bind every real static ID; isolate unrelated initial render work and network.
 vm.runInContext('updateOrganicPromotion=renderFinancialAudioControl=updateMarketingDuration=renderBenefitCalculationPreview=renderPaymentPreview=renderTicketUnreadBadges=renderGameWallet=()=>{};refreshTickets=()=>calls.push("tickets");notification=()=>{};',context);
 return {nodes,ids,calls,context,run:code=>vm.runInContext(code,context)};
}

test('main binding succeeds against the remaining portal DOM without reserved or placeholder controls',()=>{
 const f=fixture();assert.doesNotThrow(()=>f.run('bind()'));
 assert.ok(f.ids.get('lobby').children.some(node=>node.tag==='details'&&node.className==='feature-inline-guide'),'customer quick guides still install');
 assert.equal(f.ids.get('operationsPanel').children.some(node=>node.className==='feature-inline-guide'),false,'backoffice quick guides are not installed a second time');
 for(const id of ['platformSuitePanel','platformGamesManager','platformGameForm','marketingLaunch'])assert.equal(f.ids.has(id),false);
 for(const script of [app,read('public/assets/owner-manual.js'),read('public/assets/style.css'),read('public/assets/suite-theme.css')])assert.doesNotMatch(script,/platformSuitePanel|platformGamesManager|platformGameForm|marketingLaunch/);
 for(const id of ['apiSupplierManager','gameCatalogManager','gameRankingPanel','paymentChannelManager','marketingCampaignForm','ownerManualPanel'])assert.ok(f.ids.has(id),`${id} remains available`);
 const backend=read('lib/backend.ts');assert.ok(backend.includes("p==='/api/admin/custom-games'"));assert.ok(backend.includes("p==='/api/custom-games'"));assert.ok(backend.includes('custom_game_cards'));
});

test('owner-only sidebar and backup actions follow the session role while staff retain the readiness view',()=>{
 const f=fixture();f.run('bind()');
 const links=['pendingPanel','securityPanel','auditPanel'].map(id=>f.nodes.find(node=>node.attrs.href===`#${id}`&&Object.hasOwn(node.attrs,'data-owner-only')));
 assert.ok(links.every(Boolean));const backup=f.ids.get('createEncryptedBackup'),exportLink=f.nodes.find(node=>node.attrs.href==='/api/admin/export'&&Object.hasOwn(node.attrs,'data-owner-only'));assert.ok(exportLink);assert.ok(Object.hasOwn(backup.attrs,'data-owner-only'));
 const readinessLink=f.nodes.find(node=>node.attrs.href==='#systemReadinessPanel');assert.equal(Object.hasOwn(readinessLink.attrs,'data-owner-only'),false);
 assert.match(read('public/assets/style.css'),/body\.admin-mode \.admin-internal-sidebar a\[hidden\]\{display:none!important\}/,'owner-only links must stay hidden despite the mobile sidebar display override');
 for(const role of ['staff','owner']){f.run(`state.user={id:"synthetic-${role}",username:"Fixture",role:"${role}",approved:true};state.section="admin";renderSession()`);for(const control of [...links,backup,exportLink])assert.equal(control.hidden,role!=='owner');}
});

test('the backoffice Live Chat shortcut opens actual support tickets for staff and owner',()=>{
 const f=fixture();f.run('bind()');const link=f.ids.get('adminSupportButton');assert.equal(link.attrs.href,'#support');assert.equal(link.attrs['data-admin-shortcut'],undefined);
 for(const role of ['staff','owner']){let prevented=false;f.run(`state.user={role:"${role}"};state.section="admin"`);link.onclick({preventDefault(){prevented=true;}});assert.equal(prevented,true);assert.equal(f.run('state.section'),'support');}
 assert.deepEqual(f.calls,['tickets','tickets']);
});

test('removing the marketing placeholder preserves real provider status and individual campaign launch',async()=>{
 const f=fixture();f.run('renderMarketingProvider({providerReady:true,templateName:"Approved template",recipientLimit:50})');assert.match(f.ids.get('marketingProviderStatus').textContent,/已就绪/);assert.ok(f.ids.get('marketingProviderDetails').children.length>=3);
 f.run('api=async(path,method,body)=>{calls.push({path,method,body});return {audience:12}};loadMarketingCenter=async()=>{}');
 await f.run('launchMarketingCampaign({id:"synthetic-campaign"},{disabled:false,textContent:""})');
 assert.deepEqual(JSON.parse(JSON.stringify(f.calls)),[{path:'/api/admin/marketing',method:'POST',body:{action:'launch',id:'synthetic-campaign'}}]);
});

test('game wallet records explain actual capability failures separately from settlement evidence',()=>{
 const f=fixture();const cases={connection_not_configured:'尚未配置',gateway_capability_unavailable:'无法读取',gateway_capability_invalid:'不符合',gateway_credentials_not_ready:'凭证',gateway_wallet_contract_unavailable:'查单'};
 for(const [reason,phrase] of Object.entries(cases)){const text=f.run(`adminGameWalletNotice({enabled:true,walletReady:false,capabilityReason:"${reason}",settlementVerified:false})`);assert.ok(text.includes(phrase));assert.match(text,/结算验收：待验证/);assert.doesNotMatch(text,/真实资金开关|已记录通过/);}
 const ready=f.run('adminGameWalletNotice({walletReady:true,capabilityReason:"ready",settlementVerified:false})');assert.match(ready,/接口当前可用/);assert.match(ready,/结算验收：待验证/);
 const verified=f.run('adminGameWalletNotice({walletReady:true,capabilityReason:"ready",settlementVerified:true})');assert.match(verified,/结算验收：已记录通过/);
});
