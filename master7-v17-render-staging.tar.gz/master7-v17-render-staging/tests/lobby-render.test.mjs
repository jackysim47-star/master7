import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');

class Element {
 constructor(tag='div'){this.tagName=tag;this.className='';this.textContent='';this.children=[];this.hidden=false;}
 append(...children){this.children.push(...children);}
 replaceChildren(...children){this.children=[...children];}
}
function renderGames(games,category='ALL',search=''){
 const ids={providers:new Element(),gamesStatus:new Element(),search:{value:search}};
 const context={state:{games,gameCategory:category},$:id=>ids[id],document:{createElement:tag=>new Element(tag)},clear:element=>element.replaceChildren(),node:(tag,css='',text='')=>{const el=new Element(tag);el.className=css;el.textContent=String(text);return el;},t:key=>({catalogSummary:'{count} supplier titles',catalogUnavailable:'No supplier games',itemSearchNoResults:'No match',maintenanceGame:'Maintenance',gameActivePreview:'Active · launch pending UAT'})[key]||key};
 const categoryStart=source.indexOf('function normalizedGameCategory(game){');
 const start=source.indexOf('function renderCatalog(){');
 const end=source.indexOf('\nfunction renderCarousel()',start);
 assert.ok(start>=0&&end>start);
 vm.runInNewContext(`${source.slice(categoryStart,start)}\n${source.slice(start,end)}\nrenderCatalog();`,context);
 return ids;
}

test('supplier games are individual, categorized, grouped by provider, and closed titles are hidden',()=>{
 const ids=renderGames([
  {provider:'jili',providerName:'JILI',gameCode:'S-1',name:'Slot One',category:'slot',status:'active',imageData:'data:image/png;base64,abc'},
  {provider:'jili',providerName:'JILI',gameCode:'B-1',name:'Live Baccarat',category:'live',status:'suspended'},
  {provider:'megah5',providerName:'MegaH5',gameCode:'C-1',name:'Closed title',category:'slot',status:'closed'}
 ]);
 const lobby=JSON.stringify(ids.providers);
 assert.match(lobby,/Slot One/);
 assert.match(lobby,/Live Baccarat/);
 assert.match(lobby,/SLOT/);
 assert.match(lobby,/LIVE/);
 assert.match(lobby,/JILI/);
 assert.match(lobby,/Maintenance/);
 assert.doesNotMatch(lobby,/Closed title/);
 assert.equal(ids.gamesStatus.textContent,'2 supplier titles');
});

test('category and text filters only show matching supplier titles',()=>{
 const games=[{provider:'jili',providerName:'JILI',name:'Slot One',category:'slot',status:'active'},{provider:'jili',providerName:'JILI',name:'Live Baccarat',category:'live',status:'active'}];
 assert.match(JSON.stringify(renderGames(games,'LIVE').providers),/Live Baccarat/);
 assert.doesNotMatch(JSON.stringify(renderGames(games,'LIVE').providers),/Slot One/);
 assert.match(JSON.stringify(renderGames(games,'ALL','JILI').providers),/Slot One/);
});

test('lobby and deposit are the first two pages; three sponsored brands have Claim Bonus actions',()=>{
 const lobby=html.indexOf('data-section="lobby"'),deposit=html.indexOf('data-section="deposit"'),support=html.indexOf('data-section="support"');
 assert.ok(lobby>=0&&lobby<deposit&&deposit<support);
 assert.equal((html.match(/data-provider-bonus=/g)||[]).length,3);
 assert.equal((html.match(/data-provider-art=/g)||[]).length,3);
 assert.equal((html.match(/data-bonus-i18n="claim"/g)||[]).length,3);
 assert.match(html,/id="benefitProvider"/);
 assert.match(html,/id="paymentLobby"/);
 assert.match(html,/id="gameCatalogSettings"/);
 assert.match(html,/800 × 600 px \(4:3\)/);
 assert.doesNotMatch(html,/customGameForm|platformMiniGames|mini-game-grid/i);
});

test('supplier API catalogue is loaded separately from admin visibility controls',()=>{
 assert.match(source,/api\("\/api\/games"\)/);
 assert.match(source,/api\("\/api\/admin\/games"\)/);
 assert.match(source,/api\("\/api\/brand-directory"\)/);
 assert.match(source,/api\/brand-directory-art\?id=/);
 assert.match(html,/id="providerDirectoryLobby"/);
 assert.match(html,/data-brand-category="SPORT"/);
 assert.match(source,/\["suspended","Maintenance"\],\["active","Active"\],\["closed","Close"\]/);
 assert.match(source,/imageDataForUpload\(file,800,600\)/);
});
