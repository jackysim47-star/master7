import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');

class Element {
 constructor(tag='div'){this.tagName=tag;this.className='';this.textContent='';this.children=[];this.hidden=false;this.src='';this.alt='';}
 append(...children){this.children.push(...children);}
 replaceChildren(...children){this.children=[...children];}
}
function renderGames(games,category='ALL',search='',gameAccessZone='ALL'){
 const ids={providers:new Element(),gamesStatus:new Element(),search:{value:search}};
 const context={state:{games,gameCategory:category,gameAccessZone},location:{href:'https://portal.example.test/'},URL,$:id=>ids[id],document:{createElement:tag=>new Element(tag)},clear:element=>element.replaceChildren(),node:(tag,css='',text='')=>{const el=new Element(tag);el.className=css;el.textContent=String(text);return el;},t:key=>({catalogSummary:'{count} supplier titles',catalogUnavailable:'No supplier games',itemSearchNoResults:'No match',maintenanceGame:'Maintenance',gameActivePreview:'Active · launch pending UAT'})[key]||key};
 const categoryStart=source.indexOf('function normalizedGameCategory(game){');
 const start=source.indexOf('function renderCatalog(){');
 const end=source.indexOf('\nfunction renderCarousel()',start);
 assert.ok(start>=0&&end>start);
 vm.runInNewContext(`${source.slice(categoryStart,start)}\n${source.slice(start,end)}\nrenderCatalog();`,context);
 return ids;
}

test('supplier games are individual, categorized, grouped by provider, and closed titles are hidden',()=>{
 const ids=renderGames([
  {provider:'jili',providerName:'JILI',gameCode:'S-1',name:'Slot One',category:'slot',status:'active',imageData:'data:image/png;base64,abc'},
  {provider:'jili',providerName:'JILI',gameCode:'B-1',name:'Live Baccarat',category:'live',status:'suspended'},
  {provider:'megah5',providerName:'MegaH5',gameCode:'C-1',name:'Closed title',category:'slot',status:'closed'}
 ]);
 const lobby=JSON.stringify(ids.providers);
 assert.match(lobby,/Slot One/);
 assert.match(lobby,/Live Baccarat/);
 assert.match(lobby,/SLOT/);
 assert.match(lobby,/LIVE/);
 assert.match(lobby,/JILI/);
 assert.match(lobby,/Maintenance/);
 assert.doesNotMatch(lobby,/Closed title/);
 assert.equal(ids.gamesStatus.textContent,'2 supplier titles');
});

test('category and text filters only show matching supplier titles',()=>{
 const games=[{provider:'jili',providerName:'JILI',name:'Slot One',category:'slot',status:'active'},{provider:'jili',providerName:'JILI',name:'Live Baccarat',category:'live',status:'active'}];
 assert.match(JSON.stringify(renderGames(games,'LIVE').providers),/Live Baccarat/);
 assert.doesNotMatch(JSON.stringify(renderGames(games,'LIVE').providers),/Slot One/);
 assert.match(JSON.stringify(renderGames(games,'ALL','JILI').providers),/Slot One/);
});

test('free and paid zones filter independently and every tile displays its zone',()=>{
 const games=[
  {provider:'jili',providerName:'JILI',name:'Free Demo',category:'slot',status:'active',accessZone:'free'},
  {provider:'jili',providerName:'JILI',name:'Paid Game',category:'slot',status:'active',accessZone:'paid'},
  {provider:'jili',providerName:'JILI',name:'Default Paid',category:'slot',status:'active'},
 ];
 const free=JSON.stringify(renderGames(games,'ALL','','FREE').providers),paid=JSON.stringify(renderGames(games,'ALL','','PAID').providers);
 assert.match(free,/Free Demo/);assert.doesNotMatch(free,/Paid Game|Default Paid/);assert.match(free,/game-zone-free/);
 assert.doesNotMatch(paid,/Free Demo/);assert.match(paid,/Paid Game/);assert.match(paid,/Default Paid/);assert.match(paid,/game-zone-paid/);
 assert.deepEqual([...html.matchAll(/data-game-zone="([A-Z]+)"/g)].map(match=>match[1]),['ALL','FREE','PAID']);
});

test('numeric supplier category codes are normalized into the customer filters',()=>{
 const games=[
  {provider:'jili',providerName:'JILI',name:'JILI Slot',category:'1',status:'active'},
  {provider:'jili',providerName:'JILI',name:'JILI Fishing',category:'5',status:'active'},
  {provider:'918kissh5',providerName:'918KISS H5',name:'Roulette',category:'3',status:'active'},
  {provider:'megah5',providerName:'MegaH5',name:'Battle World',category:'2',status:'active'},
  {provider:'venus',providerName:'VENUS',name:'Cockfight',category:'7',status:'active'}
 ];
 const slot=JSON.stringify(renderGames(games,'SLOT').providers),fish=JSON.stringify(renderGames(games,'FISH').providers),live=JSON.stringify(renderGames(games,'LIVE').providers),cock=JSON.stringify(renderGames(games,'COCK').providers),hot=JSON.stringify(renderGames(games,'HOT').providers);
 assert.match(slot,/JILI Slot/);assert.doesNotMatch(slot,/JILI Fishing/);
 assert.match(fish,/JILI Fishing/);assert.match(live,/Roulette/);assert.match(cock,/Cockfight/);
 assert.match(hot,/FAST GAME/);assert.match(hot,/Battle World/);
});

test('customer lobby uses seven requested automatic categories and renders only twelve games initially',()=>{
 const categories=[...html.matchAll(/data-sidebar-game-category="([A-Z]+)"/g)].map(match=>match[1]);
 assert.deepEqual(categories,['HOT','SLOT','LIVE','FISH','COCK','SPORT','FAV']);
 const games=Array.from({length:20},(_,index)=>({provider:'jili',providerName:'JILI',gameCode:`S-${index}`,name:`Slot ${index}`,category:'slot',status:'active'}));
 const lobby=JSON.stringify(renderGames(games,'HOT').providers);
 for(let index=0;index<12;index++)assert.match(lobby,new RegExp(`Slot ${index}(?:[^0-9]|$)`));
 assert.doesNotMatch(lobby,/Slot 12(?:[^0-9]|$)/);
 assert.match(lobby,/Load more \(8\)/);
});

test('catalog uses provider artwork fallback instead of blank covers',()=>{
 const ids=renderGames([{provider:'jili',providerName:'JILI',gameCode:'1',name:'Royal Fishing',category:'slot',status:'active',imageUrl:'/assets/providers/jili.webp'}]);
 const lobby=JSON.stringify(ids.providers);
 assert.match(lobby,/providers\/jili\.webp/);
 assert.match(lobby,/Royal Fishing · JILI/);
});

test('lobby and deposit are the first two pages; three sponsored brands have Claim Bonus actions',()=>{
 const lobby=html.indexOf('data-section="lobby"'),deposit=html.indexOf('data-section="deposit"'),support=html.indexOf('data-section="support"');
 assert.ok(lobby>=0&&lobby<deposit&&deposit<support);
 assert.equal((html.match(/data-provider-bonus=/g)||[]).length,3);
 assert.equal((html.match(/data-provider-art=/g)||[]).length,3);
 assert.equal((html.match(/data-bonus-i18n="claim"/g)||[]).length,3);
 assert.match(html,/id="benefitProvider"/);
 assert.match(html,/id="paymentLobby"/);
 assert.doesNotMatch(html,/id="gameCatalogSettings"/);
 assert.match(source,/Supplier photo · 800 × 600 px \(4:3\)/);
 assert.doesNotMatch(html,/customGameForm|platformMiniGames|mini-game-grid/i);
});

test('withdraw page collects one of three gateway companies while owner view remains read-only',()=>{
 assert.match(html,/data-section="withdraw"/);
 assert.match(html,/id="withdrawalForm"/);
 assert.match(html,/id="withdrawBank"/);
 assert.match(html,/id="withdrawAccountHolder"/);
 assert.match(html,/id="withdrawAccountNumber"/);
 assert.match(html,/id="withdrawAmount"/);
 for(const company of ['vpay','gspay','1mpay'])assert.match(html,new RegExp(`value="${company}"`));
 assert.match(html,/id="adminWithdrawalPanel"/);
 assert.match(source,/api\("\/api\/withdrawals","POST"/);
 assert.doesNotMatch(source,/api\("\/api\/admin\/withdrawals\/status","POST"/);
});

test('supplier API catalogue is loaded separately from admin visibility controls',()=>{
 assert.match(source,/api\("\/api\/games"\)/);
 assert.match(source,/api\("\/api\/admin\/games"\)/);
 assert.doesNotMatch(html,/id="providerDirectoryLobby"/);
 assert.doesNotMatch(html,/id="brandDirectoryManager"/);
 assert.match(html,/id="lobbyAdManager"/);
 assert.match(source,/\["suspended","Maintenance"\],\["active","Active"\],\["closed","Close"\]/);
 assert.match(source,/imageDataForUpload\(file,800,600\)/);
});

test('MegaH5 member flow opens a game window, settles on exit, and exposes read-only backoffice records',()=>{
 assert.match(html,/id="gameWalletPanel"/);assert.match(html,/id="gameWalletSettle"/);assert.match(html,/id="gameWalletRecover"/);
 assert.match(html,/id="gameWalletAdminPanel"/);assert.match(html,/id="gameWalletAdminRecords"/);
 assert.match(source,/api\("\/api\/game-launch","POST"/);assert.match(source,/api\("\/api\/game-wallet\/settle","POST"/);assert.match(source,/api\("\/api\/game-wallet\/recover","POST"/);
 assert.match(source,/window\.open\("about:blank"/);assert.match(source,/function settleClosedGameWindow/);assert.match(source,/action\.onclick=\(\)=>startGame\(game\)/);
 assert.match(source,/api\("\/api\/admin\/game-wallet"\)/);assert.match(source,/async function renderAdminGameWallet/);
});

test('template navigation opens existing pages and admin links point to real backoffice sections',()=>{
 assert.match(html,/<aside class="portal-sidebar"/);
 assert.match(html,/id="adminSidebarNav"[^>]*hidden/);
 assert.match(source,/\$\("adminSidebarNav"\)\.hidden=!canManage/);
 const targets=[...html.matchAll(/<a href="#([^"]+)"/g)].map(match=>match[1]);
 const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]));
 for(const target of targets)assert.ok(ids.has(target),`Backoffice link target #${target} does not exist`);
 const duplicateIds=[...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]).filter((id,index,all)=>all.indexOf(id)!==index);
 assert.deepEqual(duplicateIds,[]);
 assert.match(html,/class="admin-workspace"/);
 assert.match(html,/class="admin-internal-sidebar"/);
});

test('38 supplied API providers have independent customer and backoffice button hosts',()=>{
 const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
 const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
 const block=source.match(/const apiSupplierEntries=Object\.freeze\(\[([\s\S]*?)\]\);/);
 assert.ok(block);
 const ids=[...block[1].matchAll(/\{id:"([^"]+)",name:"([^"]+)"\}/g)];
 assert.equal(ids.length,38);
 assert.equal(new Set(ids.map(match=>match[1])).size,38);
 for(const match of ids){const path=['epicwin','venus','clotplay','godeezone'].includes(match[1])?'../public/assets/seven-emblem.png':`../public/assets/providers/${match[1]}.webp`;assert.equal(existsSync(new URL(path,import.meta.url)),true,`${match[2]} artwork fallback is missing`);}
 assert.match(html,/id="apiSupplierButtons"/);
 assert.match(html,/id="apiSupplierAdminButtons"/);
 assert.match(source,/function supplierArtwork\(entry,css\)/);
 assert.match(source,/\/api\/supplier-art-list/);
 assert.match(source,/\/api\/admin\/supplier-art/);
 assert.match(source,/Supplier photo · 800 × 600 px \(4:3\)/);
 assert.match(source,/supplier status controls/);
 assert.match(source,/supplier-manage-details/);
});

test('owner can publish multiple lobby ads while the main banner keeps rotating',()=>{
 assert.match(html,/MASTER7 company advertising/);
 assert.match(html,/MASTER7 PROMOTION/);
 assert.match(html,/id="lobbyAdCarousel"/);
 assert.match(html,/id="lobbyAdGrid"/);
 assert.match(source,/function renderAdGrid\(items\)/);
 assert.match(source,/\.slice\(0,6\)/);
 assert.match(source,/300000/);
});

test('backoffice live status is health-backed and financial alerts poll without repeating initial records',()=>{
 assert.match(html,/id="adminLivePill"/);assert.match(source,/async function checkPortalLive/);assert.match(source,/health\.status==="ok"&&health\.database==="ready"/);assert.match(source,/async function pollFinancialNotifications/);assert.match(source,/setInterval\(pollFinancialNotifications,15000\)/);assert.match(source,/function financialAlert/);
});

test('game checks separate current connection, cached catalog, launch and wallet states',()=>{
 assert.match(source,/\["name","connection","sync","launch","wallet"\]/);
 assert.match(source,/\["connectionVerified","catalogueSynced","launchVerified","walletVerified"\]/);
});

test('backoffice opens one compact section at a time and benefits show system turnover calculations',()=>{
 assert.match(source,/function selectAdminPanel/);
 assert.match(html,/Deposit records/);assert.match(html,/Company banks/);
 assert.match(html,/VIP \/ Benefits/);
 assert.match(html,/id="benefitCalculationPreview"/);
 assert.match(source,/\/api\/benefits\/calculate/);
 assert.match(source,/Required turnover RM/);
});
