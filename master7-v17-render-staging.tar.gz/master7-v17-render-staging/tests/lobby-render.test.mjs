import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const style=readFileSync(new URL('../public/assets/style.css',import.meta.url),'utf8');

class Element {
 constructor(tag='div'){this.tagName=tag;this.className='';this.textContent='';this.children=[];this.hidden=false;this.src='';this.alt='';}
 append(...children){this.children.push(...children);}
 replaceChildren(...children){this.children=[...children];}
 setAttribute(name,value){this[name]=String(value);}
 querySelector(){return null;}
 scrollIntoView(){}
}
function supplierConstants(){
 const start=source.indexOf('const apiSupplierEntries=Object.freeze(['),end=source.indexOf('const apiSupplierIdSet',start),context={};assert.ok(start>=0&&end>start);
 vm.runInNewContext(`${source.slice(start,end)}\nthis.entries=apiSupplierEntries;this.categories=apiSupplierCategoryIds;`,context);
 return JSON.parse(JSON.stringify({entries:context.entries,categories:context.categories}));
}
function renderPlatformStatus(providerId='jili',control='active',connected=true){
 const ids={providers:new Element(),gamesStatus:new Element(),clearProviderFilter:new Element(),lobbyGameCount:new Element(),lobbyProviderCount:new Element(),search:new Element('input')};
 const entries=supplierConstants().entries,games=connected?[{provider:providerId,providerName:'JILI',gameCode:'J-1',name:'One title',nameZh:'',category:'1',status:'active',accessZone:'paid',playable:false,imageUrl:`/assets/providers/${providerId}.webp`}]:[],state={lang:'en',gameCategory:'HOT',gameAccessZone:'ALL',gameLimit:12,selectedCatalogProvider:providerId,selectedCatalogProviderName:null,supplierControls:{[providerId]:control},games,gameLaunchBusy:false,favoriteGames:[],gameCatalogue:{selectedProvider:providerId,providers:connected?[{id:providerId,connectionVerified:true,catalogueSynced:true,platformLaunchReady:false}]:[],games}};
 const start=source.indexOf('function publicGameCard('),end=source.indexOf('\nfunction renderCarousel()',start),context={state,document:{createElement:tag=>new Element(tag)},apiSupplierEntries:entries,apiSupplierCategoryIds:supplierConstants().categories,$:id=>ids[id],clear:element=>element.replaceChildren(),supplierEntriesForCategory:()=>entries,apiSupplierState:entry=>({connected:entry.id===providerId&&connected,platformLaunchReady:false,control:entry.id===providerId?control:'active'}),supplierArtwork:entry=>{const el=new Element('img');el.src=`/assets/providers/${entry.id}.webp`;return el;},node:(tag,css='',text='')=>{const el=new Element(tag);el.className=css;el.textContent=String(text);return el;},renderApiSupplierButtons(){},normalizedGameCategory:()=>"SLOT",favoriteGameKeys:()=>new Set(),gameIdentity:game=>`${game.provider}:${game.gameCode}`,toggleFavoriteGame(){},startGame(){}};
 vm.runInNewContext(`${source.slice(start,end)}\nrenderCatalog();`,context);return ids;
}

test('the customer chooser contains exactly 34 independent platform entries and excludes extra sources',()=>{
 const {entries,categories}=supplierConstants(),ids=entries.map(entry=>entry.id);
 assert.equal(entries.length,34);assert.equal(new Set(ids).size,34);assert.deepEqual(ids.filter(id=>['epicwin','venus','clotplay','godeezone'].includes(id)),[]);
 assert.deepEqual(categories.HOT,ids);
 for(const [category,list] of Object.entries(categories)){assert.equal(new Set(list).size,list.length,`${category} duplicates a platform`);assert.ok(list.every(id=>ids.includes(id)),`${category} contains an unknown platform`);}
 for(const entry of entries)assert.equal(existsSync(new URL(`../public/assets/providers/${entry.id}.webp`,import.meta.url)),true,`${entry.name} artwork fallback is missing`);
});

test('category filters classify platform entries without duplicating or inventing internal games',()=>{
 const {categories}=supplierConstants();
 assert.deepEqual(categories.SLOT,['megah5','jili','918kissh5','suncity','dragoonsoft','jdb','astar','metagaming','spadegaming','pragmaticplay','joker','evo888h5']);
 assert.deepEqual(categories.LIVE,['gameplay','sagaming','bg','allbet','ct855','pragmaticplay','awc']);
 assert.deepEqual(categories.FISH,['jili','jdb','yl','spadegaming','joker']);
 assert.deepEqual(categories.COCK,[]);assert.deepEqual(categories.SPORT,['m8bet']);
 const top=[...html.matchAll(/data-game-category="([A-Z]+)"/g)].map(match=>match[1]),side=[...html.matchAll(/data-sidebar-game-category="([A-Z]+)"/g)].map(match=>match[1]);
 assert.deepEqual(top,['HOT','SLOT','LIVE','FISH','COCK','SPORT','FAV']);assert.deepEqual(side,top);
 assert.doesNotMatch(html,/data-game-zone=/);
});

test('customer rendering expands only the selected supplier into safe game cards',()=>{
 const start=source.indexOf('function publicGameCard('),end=source.indexOf('\nfunction renderCarousel()',start),renderSource=source.slice(start,end),openStart=source.indexOf('function openCatalogProvider('),openEnd=source.indexOf('\nfunction openProviderBonus',openStart),openSource=source.slice(openStart,openEnd);
 assert.match(renderSource,/game-card|gameCode|state\.games|startGame/);
 assert.match(openSource,/loadGameCatalogue\(providerId\)/);
 assert.match(html,/选择一家后，只展开该厂商已连接的游戏/);assert.doesNotMatch(html,/mini-game-grid|platformMiniGames/i);
});

test('clicking a connected platform shows its platform state and only its own titles',()=>{
 const connected=renderPlatformStatus('jili','active',true),view=JSON.stringify(connected.providers);
 assert.match(view,/JILI/);assert.match(view,/1 games connected; launch access is awaiting the provider/);assert.match(view,/providers\/jili\.webp/);assert.match(view,/One title|game-card/);assert.equal(connected.gamesStatus.textContent,'JILI · 1 GAMES · API CONNECTED');
 const maintenance=JSON.stringify(renderPlatformStatus('awc','suspended',true).providers);assert.match(maintenance,/This platform is under maintenance/);
});

test('platform favourites are separate from internal game favourites and drive the FAV category',()=>{
 assert.match(source,/master7-favorite-providers/);assert.match(source,/favoriteProviders:\[\]/);assert.match(source,/category==="FAV"/);assert.match(source,/toggleFavoriteProvider\(entry\.id\)/);
});

test('three featured supplier slots remain separate above the 34-platform chooser',()=>{
 const featured=html.indexOf('id="bonusBrandLobby"'),chooser=html.indexOf('id="apiSupplierLobby"');assert.ok(featured>=0&&featured<chooser);
 assert.equal((html.match(/data-provider-bonus=/g)||[]).length,3);assert.equal((html.match(/data-bonus-brand=/g)||[]).length,3);assert.equal((html.match(/data-provider-art=/g)||[]).length,3);
});

test('lobby and deposit are the first two pages; three sponsored brands have Claim Bonus actions',()=>{
 const lobby=html.indexOf('data-section="lobby"'),deposit=html.indexOf('data-section="deposit"'),support=html.indexOf('data-section="support"');
 assert.ok(lobby>=0&&lobby<deposit&&deposit<support);
 assert.equal((html.match(/data-provider-bonus=/g)||[]).length,3);
 assert.equal((html.match(/data-provider-art=/g)||[]).length,3);
 assert.equal((html.match(/data-bonus-i18n="claim"/g)||[]).length,3);
 assert.match(html,/id="benefitProvider"/);
 assert.match(html,/id="paymentLobby"/);
 assert.match(html,/id="gameCatalogManager"/);
 assert.match(html,/id="gameCatalogDetails"/);
 assert.match(html,/id="gameCatalogSettings"/);
 assert.match(source,/adminGamePageSize:24/);
 assert.match(source,/Platform photo · 800 × 600 px \(4:3\)/);
 assert.doesNotMatch(html,/customGameForm|platformMiniGames|mini-game-grid/i);
});

test('customer deposit and withdraw navigation is available only to signed-in members',()=>{
 assert.equal((html.match(/<button data-section="(?:deposit|withdraw)"[^>]*hidden/g)||[]).length,4);
 assert.match(source,/\(section==="deposit"\|\|section==="withdraw"\)&&state\.user\?\.role!=="member"/);
 assert.match(source,/querySelectorAll\('\[data-section="deposit"\],\[data-section="withdraw"\]'\)\.forEach\(el=>el\.hidden=u\?\.role!=="member"\)/);
 assert.match(source,/\(state\.section==="deposit"\|\|state\.section==="withdraw"\)&&u\?\.role!=="member"/);
 assert.match(html,/<a href="#adminDepositPanel" data-owner-only>/);
 assert.match(html,/<a href="#adminWithdrawalPanel" data-owner-only>/);
});

test('only members see the new support request form while staff retain ticket operations',()=>{
 assert.match(html,/id="ticketForm"/);
 assert.match(source,/\$\("ticketForm"\)\.hidden=!!u&&u\.role!=="member"/);
 assert.match(source,/if\(state\.user\.role!=="member"\).*closeTicket/);
 assert.match(source,/api\("\/api\/tickets\/reply","POST"/);
 assert.match(source,/playTicketTone/);
});

test('withdraw page renders only payout providers enabled by the server capability response',()=>{
 assert.match(html,/data-section="withdraw"/);
 assert.match(html,/id="withdrawalForm"/);
 assert.match(html,/id="withdrawBank"/);
 assert.match(html,/id="withdrawAccountHolder"/);
 assert.match(html,/id="withdrawAccountNumber"/);
 assert.match(html,/id="withdrawAmount"/);
 for(const company of ['vpay','gspay','1mpay'])assert.doesNotMatch(html,new RegExp(`<option value="${company}"`));
 assert.match(source,/availableProviders=\(config\.providers\|\|\[\]\)\.filter\(item=>item\.enabled===true\)/);
 assert.match(html,/id="adminWithdrawalPanel"/);
 assert.match(source,/api\("\/api\/withdrawals","POST"/);
 assert.doesNotMatch(source,/api\("\/api\/admin\/withdrawals\/status","POST"/);
});

test('GSPAY deposit is restored but remains gated by verified order readiness',()=>{
 const deposit=html.slice(html.indexOf('<section id="deposit"'),html.indexOf('<section id="withdraw"'));
 const withdraw=html.slice(html.indexOf('<section id="withdraw"'),html.indexOf('<section id="support"'));
 assert.match(deposit,/data-payment-channel="gspay"/);
 assert.match(deposit,/id="gspayOrderForm"/);
 assert.doesNotMatch(withdraw,/<option value="gspay(?:_plus)?">/);
 assert.match(source,/submitGSPayOrder/);
 assert.match(source,/\/api\/payments\/gspay\/status/);
 assert.match(source,/\/api\/payments\/gspay\/orders/);
 assert.match(source,/state\.gspayStatus\?\.orderReady===true/);
 assert.match(source,/trustedGSPayCheckout/);
 for(const channel of ['vpay','gspay','1mpay','manual-bank'])assert.match(deposit,new RegExp(`data-payment-channel="${channel}"`));
});

test('public platform summary is loaded separately from admin-only game visibility controls',()=>{
 assert.match(source,/`\/api\/games\?provider=\$\{encodeURIComponent\(providerId\)\}`:"\/api\/games"/);
 assert.match(source,/api\("\/api\/admin\/games"\)/);
 assert.doesNotMatch(html,/id="providerDirectoryLobby"/);
 assert.doesNotMatch(html,/id="brandDirectoryManager"/);
 assert.match(html,/id="lobbyAdManager"/);
 assert.match(source,/\["suspended","Maintenance"\],\["active","Active"\],\["closed","Close"\]/);
 assert.match(source,/imageDataForUpload\(file,800,600\)/);
});

test('a stale platform-summary response cannot replace the newest public summary',async()=>{
 const start=source.indexOf('async function loadGameCatalogue('),end=source.indexOf('\nfunction renderItem',start);assert.ok(start>=0&&end>start);
 const pending=[],state={selectedCatalogProvider:null,gameCatalogue:null,gameCatalogueRequestId:0,games:[]},context={state,renderCatalog(){},renderApiSupplierButtons(){},api:url=>new Promise(resolve=>pending.push({url,resolve}))};
 vm.runInNewContext(source.slice(start,end),context);
 const older=context.loadGameCatalogue(),newer=context.loadGameCatalogue();assert.deepEqual(pending.map(item=>item.url),['/api/games','/api/games']);
 pending[1].resolve({providers:[{id:'megah5'}],games:[],platformsOnly:true});await newer;
 pending[0].resolve({providers:[{id:'jili'}],games:[{provider:'jili',gameCode:'must-not-render'}],platformsOnly:true});await older;
 assert.equal(state.gameCatalogue.providers[0].id,'megah5');assert.equal(state.games.length,0);
 assert.match(source,/clearProviderFilter"\)\.onclick=\(\)=>\{state\.gameCatalogueRequestId\+\+/);
});

test('customer lobby exposes selected game cards while wallet settlement remains protected',()=>{
 assert.match(html,/id="gameWalletPanel"/);assert.match(html,/id="gameWalletSettle"/);assert.match(html,/id="gameWalletRecover"/);
 assert.match(html,/id="gameWalletAdminPanel"/);assert.match(html,/id="gameWalletAdminRecords"/);
 assert.match(source,/api\("\/api\/game-launch","POST"/);assert.match(source,/api\("\/api\/game-wallet\/settle","POST"/);assert.match(source,/api\("\/api\/game-wallet\/recover","POST"/);
 assert.match(source,/function settleClosedGameWindow/);assert.match(source,/panel\.hidden=!member\|\|!session/);
 const renderStart=source.indexOf('function publicGameCard('),renderEnd=source.indexOf('\nfunction renderAdGrid(',renderStart);assert.match(source.slice(renderStart,renderEnd),/startGame|gameCode|game-card/);assert.match(source,/action\.disabled=!game\.playable/);
 assert.match(source,/api\("\/api\/admin\/game-wallet"\)/);assert.match(source,/async function renderAdminGameWallet/);
});

test('template navigation opens existing pages and admin links point to real backoffice sections',()=>{
 assert.match(html,/<aside class="portal-sidebar"/);
 assert.match(html,/id="adminSidebarNav"[^>]*hidden/);
 assert.match(source,/\$\("adminSidebarNav"\)\.hidden=!canManage/);
 const targets=[...html.matchAll(/<a href="#([^"]+)"/g)].map(match=>match[1]);
 const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]));
 for(const target of targets)assert.ok(ids.has(target),`Backoffice link target #${target} does not exist`);
 const duplicateIds=[...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]).filter((id,index,all)=>all.indexOf(id)!==index);
 assert.deepEqual(duplicateIds,[]);
 assert.match(html,/class="admin-workspace"/);
 assert.match(html,/class="admin-internal-sidebar"/);
});

test('34 supplied API providers have independent customer and backoffice button hosts',()=>{
 const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
 const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
 const block=source.match(/const apiSupplierEntries=Object\.freeze\(\[([\s\S]*?)\]\);/);
 assert.ok(block);
 const ids=[...block[1].matchAll(/\{id:"([^"]+)",name:"([^"]+)"\}/g)];
 assert.equal(ids.length,34);
 assert.equal(new Set(ids.map(match=>match[1])).size,34);
 assert.deepEqual(ids.map(match=>match[1]).filter(id=>['epicwin','venus','clotplay','godeezone'].includes(id)),[]);
 for(const match of ids){const path=`../public/assets/providers/${match[1]}.webp`;assert.equal(existsSync(new URL(path,import.meta.url)),true,`${match[2]} artwork fallback is missing`);}
 assert.match(html,/id="apiSupplierButtons"/);
 assert.match(html,/id="apiSupplierAdminButtons"/);
 assert.match(source,/function supplierArtwork\(entry,css\)/);
 assert.match(source,/\/api\/supplier-art-list/);
 assert.match(source,/\/api\/admin\/supplier-art/);
 assert.match(source,/Platform photo · 800 × 600 px \(4:3\)/);
 assert.match(source,/supplier status controls/);
 assert.match(source,/supplier-manage-details/);
 assert.match(html,/id="apiSupplierToggle"/);
 assert.match(html,/id="apiSupplierCountLabel"/);
 assert.match(source,/34 independent game platforms/);
 assert.match(source,/const apiSupplierCategoryIds=Object\.freeze/);
 assert.match(source,/button\.onclick=\(\)=>openCatalogProvider\(entry\.id,entry\.name\)/);
});

test('owner can publish multiple lobby ads while the main banner keeps rotating',()=>{
 assert.match(html,/MASTER7 company advertising/);
 assert.match(html,/MASTER7 PROMOTION/);
 assert.match(html,/id="lobbyAdCarousel"/);
 assert.match(html,/id="lobbyAdGrid"/);
 assert.match(source,/function renderAdGrid\(items\)/);
 assert.match(source,/\.slice\(0,6\)/);
 assert.match(source,/300000/);
});

test('backoffice live status is health-backed and financial alerts poll without repeating initial records',()=>{
 assert.match(html,/id="adminLivePill"/);assert.match(source,/async function checkPortalLive/);assert.match(source,/health\.status==="ok"&&health\.database==="ready"/);assert.match(source,/async function pollFinancialNotifications/);assert.match(source,/setInterval\(pollFinancialNotifications,15000\)/);assert.match(source,/function financialAlert/);
 assert.match(html,/id="financialAudioToggle"/);assert.match(source,/function toggleFinancialAudio/);assert.match(source,/m7-financial-sound/);assert.match(style,/\.admin-sound-toggle\[aria-pressed="true"\]/);
});

test('game checks separate current connection, cached catalog, launch and wallet states',()=>{
 assert.match(source,/\["name","connection","sync","launch","wallet"\]/);
 assert.match(source,/\["connectionVerified","catalogueSynced","launchVerified","walletVerified"\]/);
});

test('payment checks and owner controls include the pending GSPAY deposit integration',()=>{
 assert.match(html,/id="paymentGatewayChecks"/);
 assert.match(source,/function renderPaymentGatewayChecks/);
 for(const label of ["Deposit configured","New order","Query","Callback","Payout","Balance","Wallet verified"])assert.match(source,new RegExp(`"${label}"`));
 assert.doesNotMatch(source,/\["Company","Connected"/);
 for(const provider of ["VPay","GSPAY","1MPAY"])assert.match(source,new RegExp(`name:"${provider}"`));
 assert.doesNotMatch(source,/Archived \/ Closed · read-only history|isArchivedGSPay/);
 assert.match(html,/bo\.thegspay\.com\/index/);
 assert.match(html,/Open GSPAY reconciliation BO/);
 assert.match(source,/path:"\/api\/payments\/gspay\/status"/);
 assert.match(source,/providerId:channel\.provider_id,status:value/);
 assert.match(source,/settlementVerified===true&&status\?\.liveReady===true/);
 assert.match(source,/payout\.submissionEnabled===true/);
});

test('backoffice opens one compact section at a time and benefits show system turnover calculations',()=>{
 assert.match(source,/function selectAdminPanel/);
 assert.match(source,/setAttribute\("aria-current","page"\)/);assert.match(source,/auditData\.items\.slice\(0,100\)/);assert.match(style,/#auditLog\{max-height:/);assert.match(style,/body\.admin-mode \.admin-internal-sidebar\{height:calc\(100vh - 112px\)/);
 assert.match(html,/充值审核/);assert.match(html,/公司银行与银行单/);
 assert.match(html,/VIP 配套/);
 assert.match(html,/福利规则/);
 assert.match(html,/id="benefitCalculationPreview"/);
 assert.match(source,/\/api\/benefits\/calculate/);
 assert.match(source,/Required turnover RM/);
 const benefitSelect=html.match(/<select id="benefitProvider">([\s\S]*?)<\/select>/);assert.ok(benefitSelect);
 const benefitProviderIds=[...benefitSelect[1].matchAll(/<option value="([^"]+)"/g)].map(match=>match[1]);
 assert.deepEqual(benefitProviderIds,['all',...supplierConstants().entries.map(entry=>entry.id)]);
 assert.match(source,/All 34 game platforms/);
});
