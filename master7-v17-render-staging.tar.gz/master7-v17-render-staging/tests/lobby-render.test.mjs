import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const style=readFileSync(new URL('../public/assets/style.css',import.meta.url),'utf8');

class Element {
 constructor(tag='div'){this.tagName=tag;this.className='';this.textContent='';this.children=[];this.hidden=false;this.src='';this.alt='';}
 append(...children){this.children.push(...children);}
 replaceChildren(...children){this.children=[...children];}
 setAttribute(name,value){this[name]=String(value);}
 querySelector(){return null;}
 scrollIntoView(){}
}
function supplierConstants(){
 const start=source.indexOf('const apiSupplierEntries=Object.freeze(['),end=source.indexOf('const apiSupplierIdSet',start),context={};assert.ok(start>=0&&end>start);
 vm.runInNewContext(`${source.slice(start,end)}\nthis.entries=apiSupplierEntries;this.categories=apiSupplierCategoryIds;`,context);
 return JSON.parse(JSON.stringify({entries:context.entries,categories:context.categories}));
}
function renderPlatformStatus(providerId='jili',control='active',connected=true,retainedCatalogue=false){
 const ids={providers:new Element(),gamesStatus:new Element(),clearProviderFilter:new Element(),lobbyGameCount:new Element(),lobbyProviderCount:new Element(),search:new Element('input')};
 const entries=supplierConstants().entries,games=connected||retainedCatalogue?[{provider:providerId,providerName:'JILI',gameCode:'J-1',name:'One title',nameZh:'',category:'1',status:retainedCatalogue?'suspended':'active',maintenance:retainedCatalogue,accessZone:'paid',playable:false,imageUrl:`/assets/providers/${providerId}.webp`}]:[],state={lang:'en',gameCategory:'HOT',gameAccessZone:'ALL',gameLimit:12,selectedCatalogProvider:providerId,selectedCatalogProviderName:null,supplierControls:{[providerId]:control},games,gameLaunchBusy:false,favoriteGames:[],gameCatalogue:{selectedProvider:providerId,providers:connected?[{id:providerId,connectionVerified:true,catalogueSynced:true,platformLaunchReady:false}]:retainedCatalogue?[{id:providerId,connectionVerified:false,catalogueSynced:false,platformLaunchReady:false}]:[],games}};
 const start=source.indexOf('function publicGameCard('),end=source.indexOf('\nfunction renderCarousel()',start),context={state,gameProfileProviderId:entry=>String(entry.providerId||entry.id),document:{createElement:tag=>new Element(tag)},apiSupplierEntries:entries,apiSupplierCategoryIds:supplierConstants().categories,GAME_PLATFORM_COUNT:entries.length,$:id=>ids[id],clear:element=>element.replaceChildren(),supplierEntriesForCategory:()=>entries,apiSupplierState:entry=>({connected:entry.id===providerId&&connected,platformLaunchReady:false,maintenance:entry.id===providerId&&control==='suspended'}),supplierArtwork:entry=>{const el=new Element('img');el.src=`/assets/providers/${entry.id}.webp`;return el;},node:(tag,css='',text='')=>{const el=new Element(tag);el.className=css;el.textContent=String(text);return el;},renderApiSupplierButtons(){},normalizedGameCategory:()=>"SLOT",favoriteGameKeys:()=>new Set(),gameIdentity:game=>`${game.provider}:${game.gameCode}`,toggleFavoriteGame(){},startGame(){}};
 vm.runInNewContext(`${source.slice(start,end)}\nrenderCatalog();`,context);return ids;
}

test('the customer chooser contains exactly 38 independent platform entries and keeps GodeeZone internal',()=>{
 const {entries,categories}=supplierConstants(),ids=entries.map(entry=>entry.id);
 assert.equal(entries.length,38);assert.equal(new Set(ids).size,38);assert.deepEqual(ids.filter(id=>['epicwin','venus','clotplay','godeezone'].includes(id)),['epicwin','venus','clotplay']);
 assert.deepEqual(categories.HOT,ids);
 for(const [category,list] of Object.entries(categories)){assert.equal(new Set(list).size,list.length,`${category} duplicates a platform`);assert.ok(list.every(id=>ids.includes(id)),`${category} contains an unknown platform`);}
 for(const entry of entries)assert.equal(existsSync(new URL(`../public/assets/providers/${entry.id}.webp`,import.meta.url)),true,`${entry.name} artwork fallback is missing`);assert.equal(existsSync(new URL('../public/assets/master7-casino-lobby-premium.webp',import.meta.url)),true);
});

test('category filters classify platform entries without duplicating or inventing internal games',()=>{
 const {categories}=supplierConstants();
 assert.deepEqual(categories.SLOT,['megah5','jili','918kissh5','suncity','dragoonsoft','jdb','astar','metagaming','spadegaming','pragmaticplay','joker','evo888h5','epicwin','clotplay']);
 assert.deepEqual(categories.LIVE,['gameplay','sagaming','bg','allbet','ct855','pragmaticplay','awc']);
 assert.deepEqual(categories.FISH,['jili','jdb','yl','spadegaming','joker']);
 assert.deepEqual(categories.COCK,[]);assert.deepEqual(categories.SPORT,['m8bet']);
 const top=[...html.matchAll(/data-game-category="([A-Z]+)"/g)].map(match=>match[1]),side=[...html.matchAll(/data-sidebar-game-category="([A-Z]+)"/g)].map(match=>match[1]);
 assert.deepEqual(top,['HOT','SLOT','LIVE','FISH','COCK','SPORT','FAV']);assert.deepEqual(side,top);
 assert.doesNotMatch(html,/data-game-zone=/);
 assert.doesNotMatch(html,/id="category"/);assert.doesNotMatch(source,/recommendedCatalog|\$\("category"\)/);
});

test('META GAMING documented GameType 1 is a slot while unknown codes remain uncategorized',()=>{
 const start=source.indexOf('function normalizedGameCategory('),end=source.indexOf('\nfunction gameIdentity(',start),context={};assert.ok(start>=0&&end>start);
 vm.runInNewContext(`${source.slice(start,end)}\nthis.category=normalizedGameCategory;`,context);
 assert.equal(context.category({provider:'metagaming',category:'1'}),'SLOT');
 assert.equal(context.category({provider:'metagaming',category:'2'}),'OTHERS');
 assert.equal(context.category({provider:'unknown',category:'1'}),'OTHERS');
});

test('customer rendering expands only the selected supplier into safe game cards',()=>{
 const start=source.indexOf('function publicGameCard('),end=source.indexOf('\nfunction renderCarousel()',start),renderSource=source.slice(start,end),openStart=source.indexOf('function openCatalogProvider('),openEnd=source.indexOf('\nfunction openProviderBonus',openStart),openSource=source.slice(openStart,openEnd);
 assert.match(renderSource,/game-card|gameCode|state\.games|startGame/);
 assert.match(openSource,/loadGameCatalogue\(profileId\)/);assert.match(openSource,/loadGameWallet\(profileId\)/);
 assert.match(html,/Choose a provider to browse its game catalogue/);assert.doesNotMatch(html,/mini-game-grid|platformMiniGames/i);
});

test('every returned game can fall back from catalogue artwork to provider artwork and the global cover',()=>{
 const {entries}=supplierConstants(),start=source.indexOf('function publicGameCard('),end=source.indexOf('\nfunction renderCatalog()',start);assert.ok(start>=0&&end>start);
 for(const entry of entries){
  const state={lang:'en',selectedCatalogProvider:entry.id,gameLaunchBusy:false},context={state,apiSupplierIdSet:new Set(entries.map(item=>item.id)),gameProfileEntry:()=>entry,document:{createElement:tag=>new Element(tag)},node:(tag,css='',text='')=>{const el=new Element(tag);el.className=css;el.textContent=String(text);return el;},normalizedGameCategory:()=>"SLOT",favoriteGameKeys:()=>new Set(),gameIdentity:game=>`${game.providerId}:${game.gameCode}`,toggleFavoriteGame(){},startGame(){}};
  vm.runInNewContext(`${source.slice(start,end)}\nthis.makeGameCard=publicGameCard;`,context);
  const card=context.makeGameCard({profileId:entry.id,providerId:entry.id,providerName:entry.name,gameCode:'COVER-TEST',name:'Cover test',status:'active',playable:false,imageUrl:'/missing/catalogue-cover.webp'}),image=card.children[0].children[0];
  assert.equal(image.src,'/missing/catalogue-cover.webp',entry.id);image.onerror();assert.equal(image.src,`/assets/providers/${entry.id}.webp`,entry.id);image.onerror();assert.equal(image.src,'/assets/master7-casino-lobby-premium.webp',entry.id);
 }
});

test('clicking a connected platform shows its platform state and only its own titles',()=>{
 const connected=renderPlatformStatus('jili','active',true),view=JSON.stringify(connected.providers);
 assert.match(view,/JILI/);assert.match(view,/1 games synchronized; launch or wallet integration is not ready/);assert.match(view,/providers\/jili\.webp/);assert.match(view,/One title|game-card/);assert.equal(connected.gamesStatus.textContent,'JILI · 1 games · Play coming soon');
 const maintenance=JSON.stringify(renderPlatformStatus('awc','suspended',true).providers);assert.match(maintenance,/The provider is under maintenance/);
 const stale=JSON.stringify(renderPlatformStatus('evo888h5','active',false,true).providers);assert.match(stale,/saved catalogue games; the provider connection is unavailable and the platform is under maintenance/);assert.doesNotMatch(stale,/games connected/);
 const synchronizedMaintenance=JSON.stringify(renderPlatformStatus('evo888h5','active',true,true).providers);assert.match(synchronizedMaintenance,/games synchronized; all are currently under maintenance/);assert.doesNotMatch(synchronizedMaintenance,/provider connection is unavailable|saved catalogue/);
});

test('platform favourites are separate from internal game favourites and drive the FAV category',()=>{
 assert.match(source,/master7-favorite-providers/);assert.match(source,/favoriteProviders:\[\]/);assert.match(source,/category==="FAV"/);assert.match(source,/toggleFavoriteProvider\(entry\.id\)/);
});

test('three featured supplier slots remain separate above the 38-platform chooser',()=>{
 const featured=html.indexOf('id="bonusBrandLobby"'),chooser=html.indexOf('id="apiSupplierLobby"');assert.ok(featured>=0&&featured<chooser);
 assert.equal((html.match(/data-provider-bonus=/g)||[]).length,3);assert.equal((html.match(/data-bonus-brand=/g)||[]).length,3);assert.equal((html.match(/data-provider-art=/g)||[]).length,3);
});

test('published customer benefits have a generic lobby container without a fixed RM88 offer',()=>{
 const benefits=html.slice(html.indexOf('id="customerBenefits"'),html.indexOf('id="bonusBrandLobby"'));
 assert.match(benefits,/id="customerBenefitsList"/);
 assert.match(benefits,/hidden/);
 assert.doesNotMatch(benefits,/RM\s*88|88\s*块/i);
 assert.match(source,/function renderBenefits\(\).*\$\("customerBenefits"\)/s);
 assert.match(source,/host\.hidden=!state\.benefits\.length/);
});

test('lobby and deposit are the first two pages; three sponsored brands have Claim Bonus actions',()=>{
 const lobby=html.indexOf('data-section="lobby"'),deposit=html.indexOf('data-section="deposit"'),support=html.indexOf('data-section="support"');
 assert.ok(lobby>=0&&lobby<deposit&&deposit<support);
 assert.equal((html.match(/data-provider-bonus=/g)||[]).length,3);
 assert.equal((html.match(/data-provider-art=/g)||[]).length,3);
 assert.equal((html.match(/data-bonus-i18n="claim"/g)||[]).length,3);
 assert.match(html,/id="benefitProvider"/);
 assert.match(html,/id="paymentLobby"/);
 assert.match(html,/id="gameCatalogManager"/);
 assert.match(html,/id="gameCatalogDetails"/);
 assert.match(html,/id="gameCatalogSettings"/);
 assert.match(source,/adminGamePageSize:24/);
 assert.match(source,/Platform photo · 800 × 600 px \(4:3\)/);
 assert.doesNotMatch(html,/customGameForm|platformMiniGames|mini-game-grid/i);
});

test('customer deposit and withdraw navigation is available only to signed-in members',()=>{
 assert.equal((html.match(/<button data-section="(?:deposit|withdraw)"[^>]*hidden/g)||[]).length,4);
 assert.match(source,/\(section==="deposit"\|\|section==="withdraw"\)&&state\.user\?\.role!=="member"/);
 assert.match(source,/querySelectorAll\('\[data-section="deposit"\],\[data-section="withdraw"\]'\)\.forEach\(el=>el\.hidden=u\?\.role!=="member"\)/);
 assert.match(source,/\(state\.section==="deposit"\|\|state\.section==="withdraw"\)&&u\?\.role!=="member"/);
 assert.match(html,/<a href="#adminDepositPanel" data-owner-only>/);
 assert.match(html,/<a href="#adminWithdrawalPanel">/);
});

test('only members see the new support request form while staff retain ticket operations',()=>{
 assert.match(html,/id="ticketForm"/);
 assert.match(source,/\$\("ticketForm"\)\.hidden=!!u&&u\.role!=="member"/);
 assert.match(source,/if\(state\.user\.role!=="member"\).*closeTicket/);
 assert.match(source,/api\("\/api\/tickets\/reply","POST"/);
 assert.match(source,/playTicketTone/);
});

test('the ticket Refresh button replaces page one while Load more explicitly appends',async()=>{
 const button={},calls=[],state={user:{role:'member'},section:'lobby',tickets:[{id:'old-ticket'}],ticketPage:3,ticketHasMore:true,ticketLatestEvent:null};
 const context={state,$:id=>{assert.equal(id,'refreshTickets');return button;},api:async path=>{
  calls.push(path);const page=Number(new URL(path,'https://fixture.test').searchParams.get('page'));
  return {items:[{id:`page-${page}`}],page,hasMore:page<2,unread:0,latestEvent:'synthetic-event'};
 },renderTicketUnreadBadges(){},renderTickets(){},markVisibleTicketsRead(){throw new Error('Inactive support view must not mark messages read');},notification(message){throw new Error(message);}};
 const start=source.indexOf('async function refreshTickets('),end=source.indexOf('\nasync function pollTicketNotifications(',start),binding=source.match(/\$\("refreshTickets"\)\.onclick=[^;]+;/);
 assert.ok(start>=0&&end>start&&binding);
 vm.runInNewContext(`${source.slice(start,end)}\n${binding[0]}`,context);
 await button.onclick({type:'click'});
 assert.deepEqual(calls,['/api/tickets?page=1&limit=20']);
 assert.deepEqual(Array.from(state.tickets,item=>item.id),['page-1']);assert.equal(state.ticketPage,1);
 await context.refreshTickets(true);
 assert.deepEqual(calls,['/api/tickets?page=1&limit=20','/api/tickets?page=2&limit=20']);
 assert.deepEqual(Array.from(state.tickets,item=>item.id),['page-1','page-2']);assert.equal(state.ticketHasMore,false);
});

test('withdraw page renders every enabled payout provider while e-wallet stays on manual company-bank review',()=>{
 assert.match(html,/data-section="withdraw"/);
 assert.match(html,/id="withdrawalForm"/);
 assert.match(html,/id="withdrawProvider"[^>]*required/);
 assert.match(html,/id="withdrawBank"/);
 assert.match(html,/name="withdrawDestinationType" value="ewallet"/);
 assert.match(html,/id="withdrawAccountHolder"/);
 assert.match(html,/id="withdrawAccountNumber"/);
 assert.match(html,/id="withdrawAmount"/);
 assert.match(source,/availableProviders=\(config\.providers\|\|\[\]\)\.filter\(item=>item\.enabled===true\)/);
 assert.match(source,/providerId=\$\("withdrawProvider"\)\.value/);
 assert.match(source,/destinationType==="ewallet"&&providerId!=="manual_bank"/);
 assert.match(source,/option\.disabled=ewallet&&option\.value!=="manual_bank"/);
 assert.match(html,/id="adminWithdrawalPanel"/);
 assert.match(source,/api\("\/api\/withdrawals","POST"/);
 assert.match(source,/item\.providerId==="manual_bank"&&\["pending","approved"\]/);
});

test('GSPAY MYR and USDT are independent profiles and USDT stays fail closed',()=>{
 const deposit=html.slice(html.indexOf('<section id="deposit"'),html.indexOf('<section id="withdraw"'));
 const withdraw=html.slice(html.indexOf('<section id="withdraw"'),html.indexOf('<section id="support"'));
 assert.match(deposit,/data-payment-channel="gspay"/);
 assert.match(deposit,/data-payment-channel="gspay-usdt"/);
 assert.match(html.slice(html.indexOf('id="depositCashier"')),/id="gspayOrderForm"/);
 assert.match(html.slice(html.indexOf('id="depositCashier"')),/id="gspayUsdtOrderForm"/);
 assert.doesNotMatch(withdraw,/<option value="gspay(?:_plus)?">/);
 assert.match(source,/submitGSPayOrder/);
 assert.match(source,/\/api\/payments\/gspay\/status/);
 assert.match(source,/\/api\/payments\/gspay\/orders/);
 assert.match(source,/function cashierReady\(provider\).*orderReady===true/);
 assert.match(source,/trustedGSPayCheckout/);
 assert.match(deposit,/>GSPAY\+ MYR</);
 assert.match(deposit,/>GSPAY\+ USDT</);
 assert.match(source,/\/api\/payments\/gspay\/usdt\/status/);
 for(const channel of ['vpay','gspay','gspay-usdt','1mpay','manual-bank'])assert.match(deposit,new RegExp(`data-payment-channel="${channel}"`));
});

test('public platform summary is loaded separately from admin-only game visibility controls',()=>{
 assert.match(source,/`\/api\/games\?profileId=\$\{encodeURIComponent\(profileId\)\}`:"\/api\/games"/);
 assert.match(source,/api\("\/api\/admin\/games"\)/);
 assert.doesNotMatch(html,/id="providerDirectoryLobby"/);
 assert.doesNotMatch(html,/id="brandDirectoryManager"/);
 assert.match(html,/id="lobbyAdManager"/);
 assert.doesNotMatch(source,/gameStateButtons|supplierControls|independent status controls/);
 assert.match(source,/imageDataForUpload\(file,800,600\)/);
});

test('a stale platform-summary response cannot replace the newest public summary',async()=>{
 const start=source.indexOf('async function loadGameCatalogue('),end=source.indexOf('\nfunction renderItem',start);assert.ok(start>=0&&end>start);
 const pending=[],state={selectedCatalogProvider:null,gameCatalogue:null,gameCatalogueRequestId:0,games:[]},context={state,renderCatalog(){},renderApiSupplierButtons(){},api:url=>new Promise(resolve=>pending.push({url,resolve}))};
 vm.runInNewContext(source.slice(start,end),context);
 const older=context.loadGameCatalogue(),newer=context.loadGameCatalogue();assert.deepEqual(pending.map(item=>item.url),['/api/games','/api/games']);
 pending[1].resolve({providers:[{id:'megah5'}],games:[],platformsOnly:true});await newer;
 pending[0].resolve({providers:[{id:'jili'}],games:[{provider:'jili',gameCode:'must-not-render'}],platformsOnly:true});await older;
 assert.equal(state.gameCatalogue.providers[0].id,'megah5');assert.equal(state.games.length,0);
 assert.match(source,/clearProviderFilter"\)\.onclick=\(\)=>\{state\.gameCatalogueRequestId\+\+/);
});

test('customer lobby exposes selected game cards while wallet settlement remains protected',()=>{
 assert.match(html,/id="gameWalletPanel"/);assert.match(html,/id="gameWalletProfileMeta"/);assert.match(html,/id="gameWalletSettle"/);assert.match(html,/id="gameWalletRecover"/);
 assert.match(html,/id="gameWalletAdminPanel"/);assert.match(html,/id="gameWalletAdminRecords"/);
 assert.match(source,/api\("\/api\/game-launch","POST"/);assert.match(source,/api\("\/api\/game-wallet\/settle","POST"/);assert.match(source,/api\("\/api\/game-wallet\/recover","POST"/);
 assert.match(source,/function settleClosedGameWindow/);assert.match(source,/panel\.hidden=!member\|\|!entry/);
 const renderStart=source.indexOf('function publicGameCard('),renderEnd=source.indexOf('\nfunction renderAdGrid(',renderStart);assert.match(source.slice(renderStart,renderEnd),/startGame|gameCode|game-card/);assert.match(source,/game\.playable!==true/);
 assert.match(source,/\/api\/game-wallet\?profileId=/);assert.match(source,/\{profileId,providerId,gameCode:/);assert.match(source,/sessionId:String\(session\.id/);
 assert.match(source,/loadGameWallet\(\).*loadGameCatalogue\(\)/s);
 assert.match(source,/api\("\/api\/admin\/game-wallet"\)/);assert.match(source,/async function renderAdminGameWallet/);
});

test('selected profile catalogue query preserves profile identity on every game',async()=>{
 const state={selectedCatalogProvider:'jili_myr_1',gameCatalogueRequestId:0,gameCatalogue:null,gameRanking:null,games:[]},calls=[],context={state,api:async url=>{calls.push(url);return {selectedProfileId:'jili_myr_1',profiles:[{profileId:'jili_myr_1',providerId:'jili'}],games:[{provider:'jili',gameCode:'J-1',playable:true},{profileId:'another_profile',provider:'jili',gameCode:'J-2',playable:true}]};},gameProfileEntry:()=>({id:'jili_myr_1',providerId:'jili'}),gameProfileProviderId:entry=>entry.providerId,syncGameProfiles(){},renderCatalog(){},renderApiSupplierButtons(){}};
 const start=source.indexOf('async function loadGameCatalogue('),end=source.indexOf('\nconst previewDashboardCopy',start);assert.ok(start>=0&&end>start);vm.runInNewContext(source.slice(start,end),context);await context.loadGameCatalogue();
 assert.deepEqual(calls,['/api/games?profileId=jili_myr_1']);assert.equal(state.games[0].profileId,'jili_myr_1');assert.equal(state.games[0].providerId,'jili');assert.equal(state.games[0].playable,true);assert.equal(state.games[1].profileMismatch,true);assert.equal(state.games[1].playable,false);
});

test('template navigation opens existing pages and admin links point to real backoffice sections',()=>{
 assert.match(html,/<aside class="portal-sidebar"/);
 assert.match(html,/id="adminSidebarNav"[^>]*hidden/);
 assert.match(source,/\$\("adminSidebarNav"\)\.hidden=!canManage/);
 const targets=[...html.matchAll(/<a href="#([^"]+)"/g)].map(match=>match[1]);
 const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]));
 for(const target of targets)assert.ok(ids.has(target),`Backoffice link target #${target} does not exist`);
 const duplicateIds=[...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]).filter((id,index,all)=>all.indexOf(id)!==index);
 assert.deepEqual(duplicateIds,[]);
 assert.match(html,/class="admin-workspace"/);
 assert.match(html,/class="admin-internal-sidebar"/);
});

test('38 supplied API providers have independent customer and backoffice button hosts',()=>{
 const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
 const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
 const block=source.match(/const apiSupplierEntries=Object\.freeze\(\[([\s\S]*?)\]\);/);
 assert.ok(block);
 const ids=[...block[1].matchAll(/\{id:"([^"]+)",name:"([^"]+)"\}/g)];
 assert.equal(ids.length,38);
 assert.equal(new Set(ids.map(match=>match[1])).size,38);
 assert.deepEqual(ids.map(match=>match[1]).filter(id=>['epicwin','venus','clotplay','godeezone'].includes(id)),['epicwin','venus','clotplay']);
 for(const match of ids){const path=`../public/assets/providers/${match[1]}.webp`;assert.equal(existsSync(new URL(path,import.meta.url)),true,`${match[2]} artwork fallback is missing`);}
 assert.match(html,/id="apiSupplierButtons"/);
 assert.match(html,/id="apiSupplierAdminButtons"/);
 assert.match(source,/function supplierArtwork\(entry,css\)/);
 assert.match(source,/\/api\/supplier-art-list/);
 assert.match(source,/\/api\/admin\/supplier-art/);
 assert.match(source,/Platform photo · 800 × 600 px \(4:3\)/);
 assert.doesNotMatch(source,/supplier status controls/);
 assert.match(source,/supplier-manage-details/);
 assert.doesNotMatch(html,/apiSupplierToggle|paymentDialog/);
 assert.doesNotMatch(source,/supplierExpanded|apiSupplierToggle|paymentDialog/);
 assert.doesNotMatch(style,/state-button|api-supplier-toggle|payment-dialog/);
 assert.match(html,/id="apiSupplierCountLabel"/);
 assert.match(source,/gameProfileCounts/);assert.match(source,/independent game providers/);assert.match(html,/id="lobbyBrandCount"/);
 assert.match(source,/const apiSupplierCategoryIds=Object\.freeze/);
 assert.match(source,/button\.onclick=\(\)=>openCatalogProvider\(entry\.id,entry\.name\)/);
});

test('server game profiles create independent entries for duplicate provider accounts',()=>{
 const start=source.indexOf('const apiSupplierEntries=Object.freeze(['),end=source.indexOf('function supplierFavoriteKeys',start),state={gameProfiles:[],favoriteProviders:['missing-profile'],selectedCatalogProvider:null,selectedCatalogProviderName:null,gameWallet:null},context={state};assert.ok(start>=0&&end>start);
 vm.runInNewContext(`${source.slice(start,end)}\nthis.syncProfiles=syncGameProfiles;this.profileEntries=gameProfileEntries;this.profileCounts=gameProfileCounts;`,context);
 context.syncProfiles({profiles:[
  {profileId:'jili_myr_1',providerId:'jili',displayName:'JILI 1:1',currency:'MYR',walletMode:'transfer',position:1},
  {profileId:'jili_my1_100',providerId:'jili',displayName:'JILI 1:100',currency:'MY1',walletMode:'transfer',position:2},
  {profileId:'kiss_normal_1',providerId:'918kissh5',displayName:'918KISS Normal 1:1',currency:'MYR',position:3},
  {profileId:'kiss_normal_100',providerId:'918kissh5',displayName:'918KISS Normal 1:100',currency:'MY1',position:4},
  {profileId:'kiss_free_myr',providerId:'918kissh5',displayName:'918KISS Free MYR',currency:'MYR',position:5},
  {profileId:'epic_normal',providerId:'epicwin',displayName:'EPICWIN Normal',currency:'MYR',position:6},
  {profileId:'epic_free',providerId:'epicwin',displayName:'EPICWIN Free',currency:'MYR',position:7},
  {profileId:'epic_free',providerId:'epicwin',displayName:'Duplicate must be ignored'},
  {profileId:'../unsafe',providerId:'epicwin',displayName:'Unsafe must be ignored'}
 ]});
 assert.equal(context.profileEntries().length,7);assert.deepEqual(JSON.parse(JSON.stringify(context.profileCounts())),{profiles:7,brands:3});assert.equal(state.favoriteProviders.length,0);assert.equal(context.profileEntries()[0].id,'jili_myr_1');assert.equal(context.profileEntries()[1].id,'jili_my1_100');
 context.syncProfiles({selectedProfileId:'jili_myr_1',profiles:[{profileId:'jili_myr_1',providerId:'jili',displayName:'JILI MYR 1:1',currency:'MYR',position:1}]});assert.equal(context.profileEntries().length,7,'a selected-profile response must not collapse the lobby registry');assert.equal(context.profileEntries()[0].name,'JILI MYR 1:1');
});

test('one provider card retains separate account choices without selecting another account automatically',()=>{
 const start=source.indexOf('const apiSupplierEntries=Object.freeze(['),end=source.indexOf('function supplierFavoriteKeys',start),state={gameProfiles:[],favoriteProviders:[],providerAccountSelections:{}},context={state};
 vm.runInNewContext(`${source.slice(start,end)}\nthis.syncProfiles=syncGameProfiles;this.brandEntries=providerBrandEntries;`,context);
 context.syncProfiles({profiles:[
  {profileId:'jili_myr_1to1',providerId:'jili',displayName:'JILI MYR 1:1',position:1,launchReady:false},
  {profileId:'jili_my1_1to100',providerId:'jili',displayName:'JILI MY1 1:100',position:2,launchReady:true,unitScale:100},
  {profileId:'918kiss_normal_myr',providerId:'918kissh5',displayName:'918KISS Normal',position:3},
  {profileId:'918kiss_free_myr',providerId:'918kissh5',displayName:'918KISS Free',position:4},
 ]});
 const brands=context.brandEntries();assert.equal(brands.length,2);assert.equal(brands[0].name,'JILI');assert.equal(brands[0].profiles.length,2);
 assert.equal(brands[0].id,'jili_myr_1to1','readiness must not silently switch a member to the 1:100 account');
 state.providerAccountSelections.jili='jili_my1_1to100';assert.equal(context.brandEntries()[0].id,'jili_my1_1to100');
 state.providerAccountSelections.jili='918kiss_free_myr';assert.equal(context.brandEntries()[0].id,'jili_myr_1to1','a foreign provider account cannot replace the selected brand');
});

test('owner can publish multiple lobby ads while the main banner keeps rotating',()=>{
 assert.match(html,/MASTER7 company advertising/);
 assert.match(html,/MASTER7 PROMOTION/);
 assert.match(html,/id="lobbyAdCarousel"/);
 assert.match(html,/id="lobbyAdGrid"/);
 assert.match(source,/function renderAdGrid\(items\)/);
 assert.match(source,/\.slice\(0,6\)/);
 assert.match(source,/300000/);
});

test('backoffice live status is health-backed and financial alerts poll without repeating initial records',()=>{
 assert.match(html,/id="adminLivePill"/);assert.match(source,/async function checkPortalLive/);assert.match(source,/health\.status==="ok"&&health\.database==="ready"/);assert.match(source,/async function pollFinancialNotifications/);assert.match(source,/setInterval\(pollFinancialNotifications,15000\)/);assert.match(source,/function financialAlert/);
 assert.match(html,/id="financialAudioToggle"/);assert.match(source,/function toggleFinancialAudio/);assert.match(source,/m7-financial-sound/);assert.match(style,/\.admin-sound-toggle\[aria-pressed="true"\]/);
});

test('game checks separate current connection, cached catalog, launch and wallet states',()=>{
 assert.match(source,/\[copy\.name,copy\.connection,copy\.sync,copy\.launch,copy\.wallet\]/);
 assert.match(source,/\["connectionVerified","catalogueSynced","launchVerified","walletVerified"\]/);
});

test('payment checks and owner controls keep all four payment profiles distinct',()=>{
 assert.match(html,/id="paymentGatewayChecks"/);
 assert.match(source,/function renderPaymentGatewayChecks/);
 assert.match(source,/name:"GSPAY\+ USDT",path:"\/api\/payments\/gspay\/usdt\/status"/);
 assert.match(source,/channel\.currency==="USDT"\?"USDT":"MYR"/);
 for(const label of ["Deposit configured","New order","Query","Callback","Payout","Balance","Wallet verified"])assert.match(source,new RegExp(`"${label}"`));
 assert.doesNotMatch(source,/\["Company","Connected"/);
 for(const provider of ["VPay MYR","GSPAY\\+ MYR","GSPAY\\+ USDT","1MPAY MYR"])assert.match(source,new RegExp(`name:"${provider}"`));
 assert.doesNotMatch(source,/Archived \/ Closed · read-only history|isArchivedGSPay/);
 assert.match(html,/bo\.thegspay\.com\/index/);
 assert.match(html,/Open GSPAY\+ reconciliation BO/);
 assert.match(source,/path:"\/api\/payments\/gspay\/status"/);
 assert.doesNotMatch(source,/providerId:channel\.provider_id,status:value/);
 assert.match(source,/settlementVerified===true&&status\.liveReady===true/);
 assert.match(source,/payout\.submissionEnabled===true/);
});

test('backoffice opens one compact section at a time and benefits show system turnover calculations',()=>{
 assert.match(source,/function selectAdminPanel/);
 assert.match(source,/setAttribute\("aria-current","page"\)/);assert.match(source,/auditData\.items\.slice\(0,100\)/);assert.match(style,/#auditLog\{max-height:/);assert.match(style,/body\.admin-mode \.admin-internal-sidebar\{height:calc\(100vh - 112px\)/);
 assert.match(html,/充值日报/);assert.match(html,/公司银行与银行单/);
 assert.match(html,/VIP 配套/);
 assert.match(html,/福利规则/);
 assert.match(html,/id="benefitCalculationPreview"/);
 assert.match(source,/\/api\/benefits\/calculate/);
 assert.match(source,/Required turnover RM/);
 const benefitSelect=html.match(/<select id="benefitProvider">([\s\S]*?)<\/select>/);assert.ok(benefitSelect);
 const benefitProviderIds=[...benefitSelect[1].matchAll(/<option value="([^"]+)"/g)].map(match=>match[1]);
 assert.deepEqual(benefitProviderIds,['all',...supplierConstants().entries.map(entry=>entry.id)]);
 assert.match(source,/All \$\{GAME_PLATFORM_COUNT\} game platforms/);
});
