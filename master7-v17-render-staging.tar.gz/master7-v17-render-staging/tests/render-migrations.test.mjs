import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { initializePortalDatabase, PORTAL_STATUS_MIGRATION, PAYMENT_PROVIDERS_MIGRATION, ONE_MPAY_CHANNEL_MIGRATION, GAME_ACCESS_ZONE_MIGRATION, PAYMENT_ACCEPTANCE_GUARD_MIGRATION, MARKETING_CONTACT_SCALE_MIGRATION, OPERATIONS_AUTOMATION_MIGRATION, SUPPORT_MARKETING_MIGRATION, PAYOUT_CONTROL_MIGRATION, GSPAY_PAYOUT_ACTIVATION_MIGRATION, PAYMENT_CHANNEL_ACTIVATION_MIGRATIONS } from '../lib/render-migrations.mjs';

const beforeFinalMigration = [
  '0000_broken_bloodscream.sql','0001_orange_owl.sql','0002_lobby_ads.sql','0003_game_visibility.sql',
  '0004_sponsored_brands.sql','0005_custom_game_cards.sql','0006_malaysia_member_phone.sql',
  '0007_vpay_uat_wallet.sql','0008_member_sms_otp.sql','0009_game_payment_statuses.sql',
  '0010_game_visibility_artwork.sql','0011_provider_artwork.sql',
];

test('one-time SQL migration snapshots old controls before closing them and seeds the exact catalog', () => {
  const db = new DatabaseSync(':memory:');
  for (const migration of beforeFinalMigration) db.exec(readFileSync(join('drizzle', migration), 'utf8'));
  db.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner','owner',1,'csrf',1)").run();
  db.prepare("UPDATE providers SET visible=0 WHERE id='jili'").run();
  db.prepare("INSERT INTO game_visibility(provider_id,game_code,visible,status,updated_by,updated_at) VALUES('jili','old-1',1,'active','owner',1)").run();
  db.prepare("INSERT INTO custom_game_cards(id,title,provider_name,game_code,category,image_data,is_platform_mini,enabled,status,position,created_by,created_at,updated_at) VALUES('old-card','Old card','Old supplier','old-1','SLOT','',0,1,'active',0,'owner',1,1)").run();
  db.prepare("UPDATE payment_channel_controls SET status='active' WHERE provider_id='vpay'").run();

  db.exec(readFileSync(join('drizzle', '0012_close_defaults_and_brand_directory.sql'), 'utf8'));
  assert.deepEqual({ ...db.prepare('SELECT status,visible FROM game_visibility').get() }, { status: 'closed', visible: 0 });
  assert.deepEqual({ ...db.prepare('SELECT status,enabled FROM custom_game_cards').get() }, { status: 'closed', enabled: 0 });
  assert.deepEqual({ ...db.prepare("SELECT status FROM payment_channel_controls WHERE provider_id='vpay'").get() }, { status: 'closed' });
  assert.deepEqual({ ...db.prepare("SELECT visible FROM providers WHERE id='jili'").get() }, { visible: 1 });
  const snapshots = db.prepare(`SELECT entity_type,row_data FROM portal_status_snapshots
    WHERE migration_version=? ORDER BY entity_type`).all(PORTAL_STATUS_MIGRATION);
  assert.deepEqual([...new Set(snapshots.map(row => row.entity_type))], ['custom_game_cards','game_visibility','payment_channel_controls','providers']);
  assert.equal(snapshots.filter(row => row.entity_type === 'payment_channel_controls').length, 4);
  assert.equal(snapshots.filter(row => row.entity_type === 'providers').length, 3);
  assert.equal(JSON.parse(snapshots.find(row => row.entity_type === 'game_visibility').row_data).status, 'active');
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM brand_directory_entries').get().count, 76);
  assert.deepEqual(db.prepare('SELECT category,COUNT(*) AS count FROM brand_directory_entries GROUP BY category ORDER BY category').all().map(row => ({...row})), [
    { category: 'FAST GAME', count: 2 }, { category: 'FISH', count: 7 }, { category: 'LIVE', count: 13 },
    { category: 'OTHERS', count: 2 }, { category: 'SLOT', count: 47 }, { category: 'SPORT', count: 5 },
  ]);
  db.close();
});

class FakePgClient {
  constructor({ failOnSeed = false } = {}) { this.events = []; this.applied = new Set(); this.failOnSeed = failOnSeed; this.released = false; }
  async query(sql, params = []) {
    const clean = sql.trim(); this.events.push({ sql: clean, params });
    if (clean === 'BEGIN') return { rows: [] };
    if (clean === 'COMMIT') return { rows: [] };
    if (clean === 'ROLLBACK') { this.applied.clear(); return { rows: [] }; }
    if (clean.startsWith('SELECT version FROM portal_schema_migrations')) return { rows: this.applied.has(params[0]) ? [{ version: params[0] }] : [] };
    if (clean.startsWith('INSERT INTO portal_schema_migrations')) this.applied.add(params[0]);
    if (clean.startsWith('INSERT INTO brand_directory_entries') && this.failOnSeed) throw new Error('seed failed');
    return { rows: [] };
  }
  release() { this.released = true; }
}

test('Render startup status migration is transactional, idempotent and rolls back a failed catalog seed', async t => {
  const client = new FakePgClient();
  const pool = { connect: async () => client };
  const entries = JSON.parse(readFileSync(join('db', 'vendor-directory.json'), 'utf8'));
  const first = await initializePortalDatabase(pool, 'CREATE TABLE test_schema(id INTEGER);', entries);
  assert.deepEqual(first, { migrated: true, connectedServicesOpened: true, seededBrandCount: 76 });
  const snapshots = client.events.filter(event => event.sql.startsWith('INSERT INTO portal_status_snapshots'));
  assert.equal(snapshots.length, 7);
  assert.ok(client.applied.has(PAYMENT_ACCEPTANCE_GUARD_MIGRATION));
  assert.ok(client.applied.has(MARKETING_CONTACT_SCALE_MIGRATION));
  assert.ok(client.applied.has(OPERATIONS_AUTOMATION_MIGRATION));
  assert.ok(client.applied.has(SUPPORT_MARKETING_MIGRATION));
  assert.ok(client.applied.has(PAYOUT_CONTROL_MIGRATION));
  assert.ok(client.events.some(event=>event.sql.startsWith('ALTER TABLE marketing_contacts ADD COLUMN IF NOT EXISTS consented_at')));
  assert.ok(client.events.some(event=>event.sql.startsWith('CREATE TABLE IF NOT EXISTS ticket_reads')));
  assert.ok(client.events.some(event=>event.sql.startsWith('CREATE UNIQUE INDEX IF NOT EXISTS marketing_contacts_unsubscribe')));
  assert.ok(!client.events.some(event=>event.sql.includes('0028-gspay-decommission')));
  assert.equal(client.events.filter(event=>event.sql.startsWith('CREATE INDEX IF NOT EXISTS marketing_contacts_export')).length,1);
  assert.ok(!client.events.some(event => event.sql.includes("provider_id='vpay'") && event.sql.startsWith('UPDATE payment_channel_controls SET status=\'active\'')));
  const firstStatusUpdate = client.events.findIndex(event => event.sql.startsWith('UPDATE game_visibility'));
  assert.ok(firstStatusUpdate > client.events.findIndex(event => event.sql.startsWith('INSERT INTO portal_status_snapshots')));
  assert.ok(client.events.some(event => event.sql === 'COMMIT'));
  const seed = client.events.find(event => event.sql.startsWith('INSERT INTO brand_directory_entries'));
  assert.equal(JSON.parse(seed.params[0]).length, 76);
  assert.equal(client.released, true);

  const second = await initializePortalDatabase(pool, 'CREATE TABLE test_schema(id INTEGER);', entries);
  assert.deepEqual(second, { migrated: false, connectedServicesOpened: false, seededBrandCount: 76 });
  assert.equal(client.events.filter(event => event.sql.startsWith('UPDATE game_visibility')).length, 2);
  assert.equal(client.events.filter(event => event.sql.startsWith('INSERT INTO portal_status_snapshots')).length, 7);

  await t.test('seed errors roll back the staged snapshot and status transition', async () => {
    const failedClient = new FakePgClient({ failOnSeed: true });
    await assert.rejects(() => initializePortalDatabase({ connect: async () => failedClient }, 'CREATE TABLE test_schema(id INTEGER);', entries), /seed failed/);
    assert.equal(failedClient.events.at(-1).sql, 'ROLLBACK');
    assert.equal(failedClient.applied.size, 0);
    assert.equal(failedClient.released, true);
  });
});

test('explicit verified payment configuration opens each deposit channel once', async () => {
  const client=new FakePgClient(),pool={connect:async()=>client},entries=[];
  await initializePortalDatabase(pool,'SELECT 1;',entries);
  assert.ok(client.applied.has(PAYMENT_PROVIDERS_MIGRATION));
  assert.ok(client.applied.has(GAME_ACCESS_ZONE_MIGRATION));
  assert.ok(client.applied.has(MARKETING_CONTACT_SCALE_MIGRATION));
  assert.ok(client.applied.has(OPERATIONS_AUTOMATION_MIGRATION));
  assert.equal(client.events.filter(x=>x.sql.includes("ADD COLUMN IF NOT EXISTS access_zone")).length,1);
  assert.ok(!client.applied.has(ONE_MPAY_CHANNEL_MIGRATION));
  assert.equal(client.events.filter(x=>x.sql.startsWith('ALTER TABLE deposit_orders ADD CONSTRAINT')).length,2);
  await initializePortalDatabase(pool,'SELECT 1;',entries,{oneMpayEnabled:true});
  assert.ok(client.applied.has(ONE_MPAY_CHANNEL_MIGRATION));
  assert.ok(client.applied.has(PAYMENT_CHANNEL_ACTIVATION_MIGRATIONS['1mpay']));
  const opens=()=>client.events.filter(x=>x.sql.startsWith('UPDATE payment_channel_controls')&&x.sql.includes("provider_id='1mpay'")).length;
  const parameterizedOpens=provider=>client.events.filter(x=>x.sql.startsWith('UPDATE payment_channel_controls')&&x.params[0]===provider).length;
  assert.equal(opens(),0);
  assert.equal(parameterizedOpens('1mpay'),1);
  await initializePortalDatabase(pool,'SELECT 1;',entries,{oneMpayEnabled:true});
  assert.equal(opens(),0);
  assert.equal(parameterizedOpens('1mpay'),1);
  assert.equal(client.events.filter(x=>x.sql.startsWith('ALTER TABLE deposit_orders ADD CONSTRAINT')).length,2);
  assert.equal(client.events.filter(x=>x.sql.includes("ADD COLUMN IF NOT EXISTS access_zone")).length,1);

  await initializePortalDatabase(pool,'SELECT 1;',entries,{vpayEnabled:true,oneMpayEnabled:true,gspayEnabled:true});
  assert.equal(parameterizedOpens('vpay'),1);
  assert.equal(parameterizedOpens('1mpay'),1);
  assert.equal(parameterizedOpens('gspay'),1);
  for(const version of Object.values(PAYMENT_CHANNEL_ACTIVATION_MIGRATIONS))assert.ok(client.applied.has(version));
  const activationSnapshots=client.events.filter(x=>x.sql.startsWith('INSERT INTO portal_status_snapshots')&&Object.values(PAYMENT_CHANNEL_ACTIVATION_MIGRATIONS).includes(x.params[0]));
  assert.equal(activationSnapshots.length,3);
  await initializePortalDatabase(pool,'SELECT 1;',entries,{vpayEnabled:true,oneMpayEnabled:true,gspayEnabled:true});
  assert.equal(parameterizedOpens('vpay'),1);
  assert.equal(parameterizedOpens('1mpay'),1);
  assert.equal(parameterizedOpens('gspay'),1);
  assert.equal(client.events.some(x=>x.sql.includes('provider_payout_controls')&&x.sql.startsWith('UPDATE')),false);

  await initializePortalDatabase(pool,'SELECT 1;',entries,{gspayPayoutEnabled:true});
  assert.ok(client.applied.has(GSPAY_PAYOUT_ACTIVATION_MIGRATION));
  const payoutOpens=()=>client.events.filter(x=>x.sql.startsWith('UPDATE provider_payout_controls')&&x.sql.includes("provider_id='gspay'")).length;
  assert.equal(payoutOpens(),1);
  assert.equal(client.events.filter(x=>x.sql.startsWith('INSERT INTO portal_status_snapshots')&&x.params[0]===GSPAY_PAYOUT_ACTIVATION_MIGRATION).length,1);
  await initializePortalDatabase(pool,'SELECT 1;',entries,{gspayPayoutEnabled:true});
  assert.equal(payoutOpens(),1);
});
