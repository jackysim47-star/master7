import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const script=readFileSync(new URL('../public/assets/owner-manual.js',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/assets/owner-manual.css',import.meta.url),'utf8');
const manual=readFileSync(new URL('../docs/MASTER7_OWNER_OPERATIONS_MANUAL_ZH.md',import.meta.url),'utf8');
const portal=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');

test('owner manual adds contextual guides without exposing sensitive values',()=>{
 for(const panel of ['manualBankAdminPanel','paymentChannelManager','adminWithdrawalPanel','apiSupplierManager','gameRankingPanel','vipManager','rewardsManager','engagementManager','responsiblePlayAdminPanel','benefitManager','referralAdminPanel','supportOperationsPanel','financeCenterPanel','accountingPanel','securityPanel','bonusHunterPanel','operationsAiPanel','lobbyAdManager','marketingCenter','systemReadinessPanel'])assert.match(script,new RegExp(`id:\"${panel}\"`));
 assert.match(script,/node\(\"details\",\"setup-guide\"\)/);
 assert.match(script,/管理员操作说明书/);
 assert.match(script,/productionReady/);
 assert.match(script,/settlementVerified/);
 assert.match(script,/AI 与风险系统只提供检查和建议/);
 assert.match(portal,/\/assets\/owner-manual\.css/);
 assert.match(portal,/\/assets\/owner-manual\.js/);
 assert.match(portal,/href="#ownerManualPanel" data-owner-only/);
 assert.match(portal,/id="ownerManualPanel"[^>]*hidden[^>]*data-owner-only/);
 assert.match(script,/ownerManualInstalled/);
 assert.doesNotMatch(portal,/MASTER7_OWNER_OPERATIONS_MANUAL_ZH|\/docs\//);
 assert.doesNotMatch(script,/BEGIN (?:RSA |EC )?PRIVATE KEY/);
 assert.doesNotMatch(script,/(?:secret|password|contract|api[_-]?key|auth(?:entication)?[_-]?key)\s*[:=]\s*["'`][^"'`]{6,}["'`]/i);
});

test('every backoffice menu page has contextual instructions and a working panel target',()=>{
 const menu=portal.slice(portal.indexOf('id="adminInternalSidebar"'),portal.indexOf('</nav>',portal.indexOf('id="adminInternalSidebar"')));
 const targets=[...menu.matchAll(/href="#([A-Za-z0-9]+)"/g)].map(match=>match[1]);
 assert.equal(new Set(targets).size,targets.length,'backoffice menu targets must be unique');
 for(const id of targets){
  assert.match(portal,new RegExp(`id="${id}"`),`${id} needs a panel`);
  if(id==='ownerManualPanel')continue;
  assert.ok(app.includes(`${id}:[`),`${id} needs an inline quick guide`);
  assert.match(script,new RegExp(`id:"${id}"`),`${id} needs a full manual module`);
 }
});

test('guide styles are responsive and manual documents truthful readiness boundaries',()=>{
 assert.match(css,/\.setup-guide/);
 assert.match(css,/owner-manual-grid/);
 assert.match(css,/@media\(max-width:480px\)/);
 for(const phrase of ['不能用 RM0 代替','Preview only','wagerSource/turnoverSource','RULES FALLBACK','不自动封号、扣款、拒付或没收余额','productionReady','settlementVerified'])assert.ok(manual.includes(phrase),`manual must document: ${phrase}`);
 assert.doesNotMatch(manual,/(?:用户名|账号|password|密码)\s*[:：=]\s*\S+/i);
 assert.doesNotMatch(manual,/(?:个人|私人).{0,20}(?:充值|入金|测试金额)/);
});
