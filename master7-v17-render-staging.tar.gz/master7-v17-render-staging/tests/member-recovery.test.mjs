import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {randomBytes,createHash,scryptSync} from 'node:crypto';
import * as auth from '../lib/password-auth.ts';
import {handle} from '../lib/backend.ts';
function fixture(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());
 for(const name of readdirSync(new URL('../drizzle/',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}async first(){return sqlite.prepare(this.sql).get(...this.args)??null;}async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}async run(){return sqlite.prepare(this.sql).run(...this.args);}}
 const db={prepare:sql=>new Statement(sql),async batch(statements){sqlite.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sqlite.exec('COMMIT');return out;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 for(const [id,role] of [['owner','owner'],['target','staff'],['other','member']]){
  sqlite.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at,phone) VALUES(?,?,?,1,?,0,?)').run(id,id,role,'csrf-'+id,id==='target'?'+60108018801':null);
  sqlite.prepare('INSERT INTO password_credentials(username,user_id,salt,password_hash,version,changed_at) VALUES(?,?,?,?,?,0)').run(id==='target'?'master7':id,id,'salt-'+id,'unusable',id==='target'?3:1);
  sqlite.prepare('INSERT INTO password_sessions(token_hash,user_id,csrf,credential_version,expires_at,created_at) VALUES(?,?,?,?,?,0)').run('session-'+id,id,'csrf-'+id,id==='target'?3:1,9999999999);
 }
 sqlite.prepare('INSERT INTO settings(id,value) VALUES(?,?)').run('staff_password_setup:target',JSON.stringify({credentialVersion:3}));
 sqlite.prepare("INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('target','pending','pending',1,'retained-request',1,1)").run();
 const config={db,identity:null,ownerEmail:'owner@example.test'};
 const call=async(data,origin='https://fixture.test')=>{const response=await handle(new Request('https://fixture.test/api/auth/reset-member',{method:'POST',headers:{'Content-Type':'application/json',origin,'cf-connecting-ip':'192.0.2.4'},body:JSON.stringify(data)}),config);return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')};};
 return {sqlite,db,config,call};
}
const newPassword='Member-selected password 2026';
async function restore(f){assert.equal(typeof auth.restorePendingStaffAsMember,'function');return auth.restorePendingStaffAsMember(f.db,'owner','target',3);}
test('restoring pending staff preserves the review and owner, and issues a member-bound private reset grant',async t=>{
 const f=fixture(t),result=await restore(f);assert.equal(result.username,'master7');assert.match(result.code,/^[A-Za-z0-9_-]{43}$/);
 assert.equal(f.sqlite.prepare("SELECT role FROM users WHERE id='target'").get().role,'member');assert.equal(f.sqlite.prepare("SELECT version FROM password_credentials WHERE user_id='target'").get().version,4);
 assert.equal(f.sqlite.prepare("SELECT count(*) n FROM settings WHERE id='staff_password_setup:target'").get().n,0);
 assert.equal(f.sqlite.prepare("SELECT count(*) n FROM password_sessions WHERE user_id='target'").get().n,0);assert.equal(f.sqlite.prepare("SELECT count(*) n FROM password_sessions WHERE user_id='owner'").get().n,1);
 const review=f.sqlite.prepare("SELECT identity_status,aml_status,version FROM manual_compliance_reviews WHERE user_id='target'").get();assert.deepEqual({...review},{identity_status:'pending',aml_status:'pending',version:1});
 const stored=f.sqlite.prepare("SELECT value FROM settings WHERE id='member_password_reset:target'").get().value;assert.equal(stored.includes(result.code),false);assert.ok(stored.includes(createHash('sha256').update(result.code).digest('hex')));
});
test('a member chooses a password once and still needs SMS OTP for sign-in',async t=>{
 const f=fixture(t),grant=await restore(f),data={username:grant.username,code:grant.code,password:newPassword};
 const response=await f.call(data);assert.equal(response.status,200);assert.equal(response.body.username,'master7');assert.equal(response.body.signInAgain,true);assert.match(response.cookie,/Max-Age=0/);
 const credential=f.sqlite.prepare("SELECT * FROM password_credentials WHERE user_id='target'").get();assert.equal(credential.version,5);assert.equal(credential.password_hash,scryptSync(newPassword,credential.salt,32,{N:32768,r:8,p:3,maxmem:64*1024*1024}).toString('hex'));
 assert.equal((await f.call(data)).status,403);assert.equal(f.sqlite.prepare("SELECT count(*) n FROM settings WHERE id='member_password_reset:target'").get().n,0);
 const login=await handle(new Request('https://fixture.test/api/auth/login',{method:'POST',headers:{'content-type':'application/json',origin:'https://fixture.test'},body:JSON.stringify({username:'master7',password:newPassword})}),f.config);assert.equal(login.status,403);assert.match((await login.json()).error,/SMS OTP/);
 assert.equal(f.sqlite.prepare("SELECT count(*) n FROM password_sessions WHERE user_id='target'").get().n,0);assert.equal(f.sqlite.prepare("SELECT count(*) n FROM password_sessions WHERE user_id='owner'").get().n,1);
});
test('recovery rejects the wrong account, wrong code, expired grants and changed credential versions',async t=>{
 for(const kind of ['account','code','expired','version','role','approval']){
  const f=fixture(t),grant=await restore(f),data={username:grant.username,code:grant.code,password:newPassword},before=f.sqlite.prepare("SELECT password_hash FROM password_credentials WHERE user_id='target'").get().password_hash;
  if(kind==='account')data.username='owner';if(kind==='code')data.code='B'.repeat(43);
  if(kind==='expired'){const key='member_password_reset:target',value=JSON.parse(f.sqlite.prepare('SELECT value FROM settings WHERE id=?').get(key).value);value.expiresAt=1;f.sqlite.prepare('UPDATE settings SET value=? WHERE id=?').run(JSON.stringify(value),key);}
  if(kind==='version')f.sqlite.prepare("UPDATE password_credentials SET version=version+1 WHERE user_id='target'").run();
  if(kind==='role')f.sqlite.prepare("UPDATE users SET role='staff' WHERE id='target'").run();
  if(kind==='approval')f.sqlite.prepare("UPDATE users SET approved=0 WHERE id='target'").run();
  assert.equal((await f.call(data)).status,403,kind);assert.equal(f.sqlite.prepare("SELECT password_hash FROM password_credentials WHERE user_id='target'").get().password_hash,before);
 }
});
test('restoration requires the owner, current version and an unfinished staff setup',async t=>{
 for(const kind of ['actor','version','owner','member','ready']){
  const f=fixture(t);let actor='owner',target='target',version=3;
  if(kind==='actor')actor='other';if(kind==='version')version=2;if(kind==='owner'){target='owner';version=1;}if(kind==='member'){target='other';version=1;}if(kind==='ready')f.sqlite.prepare("DELETE FROM settings WHERE id='staff_password_setup:target'").run();
  await assert.rejects(auth.restorePendingStaffAsMember(f.db,actor,target,version));assert.equal(f.sqlite.prepare("SELECT role FROM users WHERE id='target'").get().role,'staff');
 }
});
test('restore and password update failures roll back without losing the pending request or grant',async t=>{
 const f=fixture(t);f.sqlite.exec("CREATE TRIGGER fail_grant BEFORE INSERT ON settings WHEN NEW.id='member_password_reset:target' BEGIN SELECT RAISE(ABORT,'fixture grant failure'); END;");
 await assert.rejects(restore(f));assert.equal(f.sqlite.prepare("SELECT role FROM users WHERE id='target'").get().role,'staff');assert.equal(f.sqlite.prepare("SELECT version FROM password_credentials WHERE user_id='target'").get().version,3);
 f.sqlite.exec('DROP TRIGGER fail_grant');const grant=await restore(f);f.sqlite.exec("CREATE TRIGGER fail_reset_audit BEFORE INSERT ON audit WHEN NEW.event='member_password_reset' BEGIN SELECT RAISE(ABORT,'fixture audit failure'); END;");
 assert.equal((await f.call({username:'master7',code:grant.code,password:newPassword})).status,503);assert.equal(f.sqlite.prepare("SELECT version FROM password_credentials WHERE user_id='target'").get().version,4);assert.ok(f.sqlite.prepare("SELECT value FROM settings WHERE id='member_password_reset:target'").get());
});
test('cross-origin writes and repeated invalid reset attempts do not change passwords',async t=>{
 const f=fixture(t),grant=await restore(f),data={username:'master7',code:grant.code,password:newPassword},before=f.sqlite.prepare("SELECT password_hash FROM password_credentials WHERE user_id='target'").get().password_hash;assert.equal((await f.call(data,'https://attacker.example')).status,403);
 for(let i=0;i<5;i++)assert.equal((await f.call({...data,code:'C'.repeat(43)})).status,403);assert.equal((await f.call(data)).status,429);
 assert.equal(f.sqlite.prepare("SELECT password_hash FROM password_credentials WHERE user_id='target'").get().password_hash,before);
});
