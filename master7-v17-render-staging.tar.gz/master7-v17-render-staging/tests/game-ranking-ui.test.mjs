import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

test('owner ranking panel is wired into the backoffice and lobby catalogue',async()=>{
 const [portal,app]=await Promise.all([readFile(new URL('../app/portal.html',import.meta.url),'utf8'),readFile(new URL('../public/assets/app.js',import.meta.url),'utf8')]);
 assert.match(portal,/href="#gameRankingPanel" data-owner-only/);
 assert.match(portal,/id="gameRankingPanel"[^>]*data-owner-only/);
 assert.match(portal,/owner-curated display order; it does not rank internal game titles/i);
 assert.match(portal,/game-ranking\.js/);
 assert.match(portal,/game-ranking\.css/);
 assert.match(app,/state\.gameRanking=catalogue\.ranking\|\|state\.gameRanking/);
 assert.match(app,/orderEntries\(apiSupplierEntries,rankCategory,state\.gameRanking\)/);
 assert.match(app,/gameRankingPanel:\(\)=>window\.Master7GameRanking\?\.loadAdmin\(\)/);
});

test('each lobby category uses its own owner-curated order',async()=>{
 const source=await readFile(new URL('../public/assets/game-ranking.js',import.meta.url),'utf8'),listeners={};
 const document={readyState:'loading',getElementById(){return null;},addEventListener(name,handler){listeners[name]=handler;}};
 const window={};vm.runInNewContext(source,{window,document,console});
 const entries=[{id:'a'},{id:'b'},{id:'c'}],payload={ranking:{categories:{HOT:['a','b','c'],SLOT:['c','a'],LIVE:['b','c']}}};
 assert.deepEqual(window.Master7GameRanking.orderEntries(entries,'HOT',payload).map(item=>item.id),['a','b','c']);
 assert.deepEqual(window.Master7GameRanking.orderEntries(entries,'SLOT',payload).map(item=>item.id),['c','a']);
 assert.deepEqual(window.Master7GameRanking.orderEntries(entries,'LIVE',payload).map(item=>item.id),['b','c']);
 assert.deepEqual(window.Master7GameRanking.orderEntries(entries,'FISH',payload).map(item=>item.id),['a','b','c']);
 assert.equal(typeof listeners.DOMContentLoaded,'function');
});
