import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFileSync } from 'node:fs';
import {
  postgresPoolMax,
  postgresPoolRuntimeOptions,
  registerPostgresPoolErrorHandler,
} from '../lib/postgres-pool-config.mjs';

test('PostgreSQL pool size is bounded per autoscaled instance', () => {
  for (const value of [undefined, null, '', '0', '-1', '6', '11', '1.5', 'abc', 'Infinity']) {
    assert.equal(postgresPoolMax(value), 5, String(value));
  }
  assert.equal(postgresPoolMax('1'), 1);
  assert.equal(postgresPoolMax('5'), 5);
  assert.deepEqual(postgresPoolRuntimeOptions({ PG_POOL_MAX: '4' }), {
    max: 4,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
    maxLifetimeSeconds: 300,
    keepAlive: true,
    keepAliveInitialDelayMillis: 10_000,
  });
});

test('idle PostgreSQL errors are handled without logging connection details', () => {
  const pool = new EventEmitter();
  const logs = [];
  assert.equal(registerPostgresPoolErrorHandler(pool, message => logs.push(message)), pool);
  const error = Object.assign(new Error('postgres://user:secret@private-db/internal'), { code: 'ECONNRESET' });
  pool.emit('error', error);
  assert.deepEqual(logs, ['MASTER7 PostgreSQL idle connection error; pool will replace the connection (ECONNRESET).']);
  assert.doesNotMatch(logs[0], /secret|private-db|postgres:\/\//);
});

test('Render responses receive the baseline transport security headers', () => {
  const config = readFileSync(new URL('../vite.render.config.ts', import.meta.url), 'utf8');
  const route = readFileSync(new URL('../app/route.ts', import.meta.url), 'utf8');
  const headers = readFileSync(new URL('../lib/http-security.ts', import.meta.url), 'utf8');
  assert.match(config, /"\/\*\*"\s*:\s*\{[\s\S]*headers:\s*RENDER_SECURITY_HEADERS/);
  assert.match(route, /\.\.\.RENDER_SECURITY_HEADERS/);
  for (const name of ['Strict-Transport-Security', 'X-Frame-Options', 'Permissions-Policy', 'X-Permitted-Cross-Domain-Policies']) {
    assert.ok(headers.includes(name), name);
  }
  assert.match(headers, /Strict-Transport-Security': 'max-age=31536000'/);
  assert.doesNotMatch(headers, /includeSubDomains|preload/);
});
