import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const start=source.indexOf('const depositRequestTimeoutMs='),end=source.indexOf('function renderPaymentRecords(',start);
assert.ok(start>=0&&end>start);

function fixture(){
 const stored=new Map(),state={user:{id:'member-1'},vpayAttempt:null,gspayAttempt:null,oneMpayAttempt:null};let sequence=0;
 const sessionStorage={getItem:key=>stored.get(key)??null,setItem:(key,value)=>stored.set(key,value),removeItem:key=>stored.delete(key)};
 const context={state,sessionStorage,crypto:{randomUUID:()=>`request-key-${++sequence}`}};
 runInNewContext(`${source.slice(start,end)}\nthis.helpers={depositRequestTimeoutMs,depositAttemptFor,loadDepositAttempt,clearDepositAttempt,updateDepositAttempt,definitiveDepositFailure,releaseDepositAttemptAfterError,clearCompletedDepositAttempts};`,context);
 return {state,stored,helpers:context.helpers};
}

test('failed deposit records release the browser attempt while unknown records keep one idempotency key',()=>{
 const f=fixture(),first=f.helpers.depositAttemptFor('vpay','fingerprint','same-payment');
 assert.equal(first.requestKey,'request-key-1');
 assert.equal(f.helpers.depositAttemptFor('vpay','fingerprint','same-payment').requestKey,first.requestKey);
 f.helpers.updateDepositAttempt('vpay',first,{id:'order-1',status:'awaiting_confirmation'});
 f.helpers.clearCompletedDepositAttempts([{provider:'vpay',id:'order-1',request_key:first.requestKey,status:'unknown'}]);
 assert.equal(f.helpers.loadDepositAttempt('vpay').requestKey,first.requestKey);
 f.helpers.clearCompletedDepositAttempts([{provider:'vpay',id:'order-1',request_key:first.requestKey,status:'failed'}]);
 assert.equal(f.helpers.loadDepositAttempt('vpay'),null);
 assert.equal(f.stored.has('m7-vpay-order-member-1'),false);
 assert.equal(f.helpers.depositAttemptFor('vpay','fingerprint','same-payment').requestKey,'request-key-2');
});

test('only a definite provider rejection releases an attempt; edge and timeout failures stay idempotent',()=>{
 const f=fixture(),attempt=f.helpers.depositAttemptFor('1mpay','amount','10.00');
 assert.equal(f.helpers.releaseDepositAttemptAfterError('1mpay',{status:502,message:'Service temporarily unavailable'}),false);
 assert.equal(f.helpers.loadDepositAttempt('1mpay').requestKey,attempt.requestKey);
 assert.equal(f.helpers.releaseDepositAttemptAfterError('1mpay',{status:422,message:'different validation error'}),false);
 assert.equal(f.helpers.loadDepositAttempt('1mpay').requestKey,attempt.requestKey);
 assert.equal(f.helpers.releaseDepositAttemptAfterError('1mpay',{status:422,message:'PROVIDER_REJECTED'}),true);
 assert.equal(f.helpers.loadDepositAttempt('1mpay'),null);
});

test('deposit calls have a timeout longer than the complete provider request budget',()=>{
 const f=fixture();assert.equal(f.helpers.depositRequestTimeoutMs,35000);
 for(const provider of ['vpay','gspay','1mpay'])assert.match(source,new RegExp(`api\\("/api/payments/${provider}/orders","POST",[^\\n]+depositRequestTimeoutMs`));
});

test('an order link never marks a deposit as settled or promotes provider verification',()=>{
 const start=source.indexOf('function presentDepositResult('),end=source.indexOf('const depositConflictCopy=',start),result=source.slice(start,end);
 assert.match(result,/result\.status==="credited"\?"paid":"failed"/);
 assert.match(result,/cashierText\("opening"\)/);
 assert.doesNotMatch(result,/settlementVerified\s*=|balance\s*[+]=|wallet.*credit/i);
 assert.match(source,/Your deposit record will update when payment is confirmed/);
});

test('GSPAY+ checkout uses the current tab and uncertain results link to deposit records',()=>{
 const start=source.indexOf('async function submitGSPayOrder('),end=source.indexOf('async function submitOneMpayOrder(',start),gspaySource=source.slice(start,end);
 assert.match(source,/window\.location\.assign\(url\.href\)/);
 assert.doesNotMatch(gspaySource,/target="_blank"|window\.open/);
 assert.match(source,/records:"View deposit records"/);
 assert.match(source,/function appendDepositRecordsAction\(host\)/);
 assert.match(source,/unknown:"Confirming"/);
});
