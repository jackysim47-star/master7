import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handleVPay,refreshVPayOrder} from '../lib/vpay.ts';

// Every VPay response in this file is synthetic; no supplier network is used.
const gateway='https://master7-integration-gateway.onrender.com';
const queryToken='query-token-'.padEnd(40,'q');

function fixture(t,{status='created',providerState='3'}={}){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sql.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('alice','alice','member',1,'csrf',0)").run();
 const orderId='vpay-state-order',tradeNo='vpay-state-trade';
 sql.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,provider_trade_no,created_at,updated_at) VALUES(?,?,?,?,'vpay',2000,'MYR','2',?,?,0,0)").run(orderId,'alice','vpay-state-request','fingerprint',status,tradeNo);
 if(status==='credited')sql.exec(`INSERT INTO wallet_ledger VALUES
  ('vpay-state-member','vpay-state-order','alice','member',2000,'MYR',0),
  ('vpay-state-clearing','vpay-state-order','alice','provider_clearing',-2000,'MYR',0)`);
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const rows=statements.map(statement=>sql.prepare(statement.text).run(...statement.args));sql.exec('COMMIT');return rows;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={queries:0,providerState};
 const context={db,user:{id:'alice',username:'alice',role:'member',approved:1,csrf:'csrf'},gatewayUrl:gateway,orderToken:'order-token-'.padEnd(40,'o'),queryToken,callbackToken:'callback-token-'.padEnd(40,'c'),newDepositsEnabled:'true',mode:'production',vpayTraderId:'fixture-trader',returnUrl:'https://master7-v17-staging.onrender.com/payment/return',fetchImpl:async(input,init)=>{
  const url=new URL(String(input));assert.equal(url.origin,gateway);assert.equal(url.pathname,'/platform/vpay/order-query');assert.equal(init.method,'POST');assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+queryToken);state.queries++;
  assert.deepEqual(JSON.parse(init.body),{outTradeNo:orderId,tradeNo});
  return Response.json({provider:'vpay',result:{code:0,data:{out_trade_no:orderId,trade_no:tradeNo,amount:'20.00',currency:'MYR',state:state.providerState,trader_id:'fixture-trader'}}});
 }};
 async function refresh(){const response=await refreshVPayOrder({orderId},context);return {status:response.status,body:await response.json()};}
 async function callback(callbackState){const response=await handleVPay(new Request('https://portal.example/api/payment-callbacks/vpay/payment',{method:'POST',headers:{authorization:'Bearer '+context.callbackToken,'content-type':'application/json'},body:JSON.stringify({out_trade_no:orderId,trade_no:tradeNo,amount:'20.00',state:callbackState,trader_id:'fixture-trader'})}),context);return {status:response.status,body:await response.text()};}
 t.after(()=>sql.close());return {sql,state,orderId,refresh,callback};
}

for(const providerState of ['0','2'])test(`VPay state ${providerState} remains pending without ledger writes`,async t=>{
 const f=fixture(t,{providerState}),result=await f.refresh();
 assert.deepEqual(result,{status:202,body:{id:f.orderId,status:'awaiting_confirmation'}});
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'created');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('VPay state 1 records a terminal failed order idempotently',async t=>{
 const f=fixture(t,{providerState:'1'}),result=await f.refresh();
 assert.deepEqual(result,{status:422,body:{id:f.orderId,status:'failed'}});
 assert.deepEqual(await f.refresh(),{status:422,body:{id:f.orderId,status:'failed'}});
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'failed');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_deposit_failed' AND target=?").get(f.orderId).n,1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('VPay state 3 credits one balanced MYR ledger and recheck stays idempotent',async t=>{
 const f=fixture(t,{providerState:'3'});assert.deepEqual(await f.refresh(),{status:200,body:{id:f.orderId,status:'credited'}});
 assert.deepEqual(await f.refresh(),{status:200,body:{id:f.orderId,status:'credited'}});
 assert.equal(f.state.queries,2);
 const rows=f.sql.prepare('SELECT account_code,amount_minor FROM wallet_ledger ORDER BY account_code').all();
 assert.deepEqual(rows.map(row=>({...row})),[{account_code:'member',amount_minor:2000},{account_code:'provider_clearing',amount_minor:-2000}]);
});

for(const providerState of ['0','2','9'])test(`post-credit VPay state ${providerState} preserves the ledger but freezes the order for review`,async t=>{
 const f=fixture(t,{status:'credited',providerState}),before=f.sql.prepare('SELECT account_code,amount_minor,currency FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row}));
 assert.deepEqual(await f.refresh(),{status:409,body:{id:f.orderId,status:'review'}});
 assert.deepEqual(await f.refresh(),{status:409,body:{id:f.orderId,status:'review'}});
 assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event='vpay_deposit_state_review' AND target=?").get(f.orderId).n,1);
 assert.deepEqual(f.sql.prepare('SELECT account_code,amount_minor,currency FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row})),before);
});

for(const [providerState,event] of [['4','vpay_deposit_reversed_review'],['5','vpay_deposit_risk_control_review']])test(`VPay state ${providerState} enters an idempotent manual-review incident before credit`,async t=>{
 const f=fixture(t,{providerState});assert.deepEqual(await f.refresh(),{status:409,body:{id:f.orderId,status:'review'}});
 assert.deepEqual(await f.refresh(),{status:409,body:{id:f.orderId,status:'review'}});
 assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM audit WHERE event=? AND target=?').get(event,f.orderId).n,1);
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

for(const [providerState,event] of [['4','vpay_deposit_reversed_review'],['5','vpay_deposit_risk_control_review']])test(`post-credit VPay state ${providerState} preserves the original wallet ledger and creates one incident`,async t=>{
 const f=fixture(t,{status:'credited',providerState}),before=f.sql.prepare('SELECT account_code,amount_minor,currency FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row}));
 assert.deepEqual(await f.refresh(),{status:409,body:{id:f.orderId,status:'review'}});
 assert.deepEqual(await f.refresh(),{status:409,body:{id:f.orderId,status:'review'}});
 assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM audit WHERE event=? AND target=?').get(event,f.orderId).n,1);
 assert.deepEqual(f.sql.prepare('SELECT account_code,amount_minor,currency FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row})),before);
 assert.equal(before.reduce((sum,row)=>sum+row.amount_minor,0),0);
});

for(const [providerState,event] of [['4','vpay_deposit_reversed_review'],['5','vpay_deposit_risk_control_review']])test(`post-credit VPay callback state ${providerState} requires an independent matching query and preserves funds`,async t=>{
 const f=fixture(t,{status:'credited',providerState}),before=f.sql.prepare('SELECT account_code,amount_minor,currency FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row}));
 assert.deepEqual(await f.callback(providerState),{status:409,body:'REVIEW_REQUIRED'});
 assert.deepEqual(await f.callback(providerState),{status:503,body:'LEDGER_REVIEW'});
 assert.equal(f.state.queries,1);assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'review');
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM audit WHERE event=? AND target=?').get(event,f.orderId).n,1);
 assert.deepEqual(f.sql.prepare('SELECT account_code,amount_minor,currency FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row})),before);
});

test('a post-credit reversal callback cannot override an independent successful query',async t=>{
 const f=fixture(t,{status:'credited',providerState:'3'}),before=f.sql.prepare('SELECT account_code,amount_minor FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row}));
 assert.deepEqual(await f.callback('4'),{status:200,body:'SUCCESS'});assert.equal(f.state.queries,1);
 assert.equal(f.sql.prepare('SELECT status FROM deposit_orders WHERE id=?').get(f.orderId).status,'credited');
 assert.equal(f.sql.prepare("SELECT COUNT(*) n FROM audit WHERE event IN ('vpay_deposit_reversed_review','vpay_deposit_risk_control_review')").get().n,0);
 assert.deepEqual(f.sql.prepare('SELECT account_code,amount_minor FROM wallet_ledger ORDER BY account_code').all().map(row=>({...row})),before);
});
