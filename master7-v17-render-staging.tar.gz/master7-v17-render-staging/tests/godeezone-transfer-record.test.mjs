import {test} from 'node:test';
import assert from 'node:assert/strict';
import {GodeeTransferRecordError,matchGodeeTransferRecord} from '../lib/godeezone-transfer-record.ts';

const expected={providerCode:'p1',username:'fixtureplayer',transferId:'fixture-transfer-1',amount:'112.00',currency:'MYR',action:'IN'};
const response={status:'success',data:{provider:'p1',username:'fixtureplayer',transfercode:'fixture-transfer-1',amount:'112',currency:'MYR',actions:'IN'}};
test('documented matching transfer record preserves MYR minor units but does not claim wallet settlement',()=>{
 assert.deepEqual(matchGodeeTransferRecord(response,expected),{amountMinor:'11200',currency:'MYR',action:'IN',matched:true,settlementVerified:false});
 const outExpected={...expected,action:'OUT'};assert.equal(matchGodeeTransferRecord({...response,data:{...response.data,actions:'out'}},outExpected).action,'OUT');
});
test('foreign provider, member, transfer, amount, currency or direction fail closed',()=>{
 for(const changed of [{provider:'p2'},{username:'otherplayer'},{transfercode:'another'},{amount:'111.99'},{amount:112},{currency:'USDT'},{actions:'OUT'}])assert.throws(()=>matchGodeeTransferRecord({...response,data:{...response.data,...changed}},expected),GodeeTransferRecordError);
});
test('failed and ambiguous records or invalid money cannot be mistaken for confirmed transfers',()=>{
 for(const invalid of [{status:'pending',data:response.data},{status:'success',data:null},null,{status:'success',data:{...response.data,amount:'112.001'}},{status:'success',data:{...response.data,amount:'1e2'}}])assert.throws(()=>matchGodeeTransferRecord(invalid,expected),GodeeTransferRecordError);
 for(const changed of [{amount:'0.00'},{amount:'01.00'},{currency:'USDT'},{username:'bad !'},{username:undefined},{providerCode:''}])assert.throws(()=>matchGodeeTransferRecord(response,{...expected,...changed}),GodeeTransferRecordError);
});
