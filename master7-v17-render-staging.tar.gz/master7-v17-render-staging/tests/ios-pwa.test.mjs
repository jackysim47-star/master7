import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const worker=readFileSync(new URL('../public/service-worker.js',import.meta.url),'utf8');
const manifest=JSON.parse(readFileSync(new URL('../public/manifest.webmanifest',import.meta.url),'utf8'));

test('iPhone Safari Web App publishes a scoped standalone MASTER7 manifest',()=>{
 assert.equal(manifest.name,'MASTER7 Premium Game Lobby');
 assert.equal(manifest.short_name,'MASTER7');
 assert.equal(manifest.start_url,'/signin?source=pwa');
 assert.equal(manifest.scope,'/');
 assert.equal(manifest.display,'standalone');
 assert.equal(manifest.prefer_related_applications,false);
 assert.ok(manifest.icons.some(icon=>icon.src==='/assets/pwa-icon-192.png'&&icon.sizes==='192x192'));
 assert.ok(manifest.icons.some(icon=>icon.src==='/assets/pwa-icon-512.png'&&icon.sizes==='512x512'&&icon.purpose==='maskable'));
 assert.match(html,/rel="manifest" href="\/manifest\.webmanifest"/);
 assert.match(html,/name="apple-mobile-web-app-capable" content="yes"/);
 assert.match(html,/rel="apple-touch-icon" sizes="180x180" href="\/assets\/pwa-icon-180\.png"/);
 assert.match(html,/id="iosInstallGuide"/);
 assert.match(html,/Safari<\/strong> 打开 <code>master7\.best<\/code>/);
 assert.doesNotMatch(html,/www\.master7\.best/);
 assert.match(html,/Add to Home Screen/);
});

test('service worker keeps authentication and financial routes network-only',()=>{
 assert.match(worker,/master7-shell-17\.0\.0-selfbuilt\.99-payment-settlement/);
 assert.match(app,/navigator\.serviceWorker\.register\("\/service-worker\.js",\{scope:"\/"\}\)/);
 assert.match(worker,/request\.mode==='navigate'/);
 assert.match(worker,/fetch\(request\)\.catch\(\(\)=>caches\.match\('\/offline\.html'\)\)/);
 assert.match(worker,/url\.pathname\.startsWith\('\/api\/'\)/);
 assert.match(worker,/url\.pathname\.startsWith\('\/downloads\/'\)/);
 assert.doesNotMatch(worker,/caches\.match\(request\).*\/api\//s);
});
