import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const worker=readFileSync(new URL('../public/service-worker.js',import.meta.url),'utf8');
const backend=readFileSync(new URL('../lib/backend.ts',import.meta.url),'utf8');
const manifest=JSON.parse(readFileSync(new URL('../public/manifest.webmanifest',import.meta.url),'utf8'));

test('iPhone Safari Web App publishes a scoped standalone MASTER7 manifest',()=>{
 assert.equal(manifest.name,'MASTER7 Premium Game Lobby');
 assert.equal(manifest.short_name,'MASTER7');
 assert.equal(manifest.start_url,'/signin?source=pwa');
 assert.equal(manifest.scope,'/');
 assert.equal(manifest.display,'standalone');
 assert.equal(manifest.prefer_related_applications,false);
 assert.ok(manifest.icons.some(icon=>icon.src==='/assets/pwa-icon-192.png'&&icon.sizes==='192x192'));
 assert.ok(manifest.icons.some(icon=>icon.src==='/assets/pwa-icon-512.png'&&icon.sizes==='512x512'&&icon.purpose==='maskable'));
 assert.match(html,/rel="manifest" href="\/manifest\.webmanifest"/);
 assert.match(html,/name="apple-mobile-web-app-capable" content="yes"/);
 assert.match(html,/rel="apple-touch-icon" sizes="180x180" href="\/assets\/pwa-icon-180\.png"/);
 assert.doesNotMatch(html,/id="iosInstallGuide"/);
 assert.doesNotMatch(html,/www\.master7\.best/);
});

test('service worker keeps authentication and financial routes network-only',()=>{
 const release=backend.match(/export const RELEASE = '([^']+)'/)?.[1];
 assert.ok(release);
 assert.ok(worker.includes(`const CACHE='master7-shell-${release}'`));
 assert.match(app,/navigator\.serviceWorker\.register\("\/service-worker\.js",\{scope:"\/"\}\)/);
 assert.match(worker,/request\.mode==='navigate'/);
 assert.match(worker,/fetch\(request\)\.catch\(\(\)=>caches\.match\('\/offline\.html'\)\)/);
 assert.match(worker,/url\.pathname\.startsWith\('\/api\/'\)/);
 assert.match(worker,/url\.pathname\.startsWith\('\/downloads\/'\)/);
 assert.doesNotMatch(worker,/caches\.match\(request\).*\/api\//s);
});
