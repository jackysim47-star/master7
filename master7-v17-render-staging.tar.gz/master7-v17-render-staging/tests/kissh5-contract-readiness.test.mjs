import assert from 'node:assert/strict';
import test from 'node:test';
import {
  getKissH5ContractRequirements,
  inspectKissH5ContractManifest,
  KISS_H5_PROFILE_IDS,
} from '../lib/kissh5-contract-readiness.ts';

const profileValues={
  '918kiss_normal_myr':{profileId:'918kiss_normal_myr',account:'normal',currency:'MYR',settlement:'MYR',balanceClass:'cash'},
  '918kiss_normal_my1_1to100':{profileId:'918kiss_normal_my1_1to100',account:'my1',currency:'MY1',settlement:'MYR',balanceClass:'cash'},
  '918kiss_free_myr':{profileId:'918kiss_free_myr',account:'free',currency:'MYR',settlement:'MYR',balanceClass:'free_credit'},
};

function setPath(target,path,value){
 const parts=path.split('.');let current=target;
 for(const part of parts.slice(0,-1))current=current[part]??={};
 current[parts.at(-1)]=value;
}

function completeManifest(profileId){
 const manifest={},profile=profileValues[profileId];
 for(const requirement of getKissH5ContractRequirements(profileId)){
  let value=requirement.expected?.[0]??'documented-value';
  if(requirement.kind==='string_list')value=['documented-field'];
  if(requirement.kind==='positive_integer')value=1;
  if(requirement.kind==='sha256')value='a'.repeat(64);
  if(requirement.kind==='ratio')value='1:1';
  if(requirement.field==='profile.profile_id')value=profile.profileId;
  if(requirement.field==='profile.account_variant')value=profile.account;
  if(requirement.field==='profile.provider_currency')value=profile.currency;
  if(requirement.field==='profile.settlement_currency')value=profile.settlement;
  if(requirement.field==='profile.balance_class')value=profile.balanceClass;
  setPath(manifest,requirement.field,value);
 }
 return manifest;
}

test('all three 918KISS profiles report exact fail-closed contract gaps independently',()=>{
 assert.deepEqual(KISS_H5_PROFILE_IDS,[
  '918kiss_normal_myr','918kiss_normal_my1_1to100','918kiss_free_myr',
 ]);
 for(const profileId of KISS_H5_PROFILE_IDS){
  const diagnostic=inspectKissH5ContractManifest(profileId);
  assert.equal(diagnostic.knownProfile,true);
  assert.equal(diagnostic.manifestComplete,false);
  assert.deepEqual(diagnostic.missingVendorFields,getKissH5ContractRequirements(profileId).map(item=>item.field));
  assert.equal(diagnostic.adapterImplemented,false);
  assert.equal(diagnostic.launchAllowed,false);
  assert.equal(diagnostic.walletAllowed,false);
  assert.equal(diagnostic.playAllowed,false);
 }
 assert.ok(inspectKissH5ContractManifest('918kiss_normal_my1_1to100').missingVendorFields.includes('profile.my1_to_myr_ratio'));
 assert.equal(inspectKissH5ContractManifest('918kiss_normal_myr').missingVendorFields.includes('profile.my1_to_myr_ratio'),false);
 assert.ok(inspectKissH5ContractManifest('918kiss_free_myr').missingVendorFields.includes('profile.free_credit_settlement_rule'));
});

test('catalogue credentials and game rows cannot satisfy runtime contract requirements',()=>{
 const catalogueOnly={
  operatorId:'catalogue-operator',secretKey:'must-never-be-reflected',
  baseUrl:'https://catalogue.invalid',games:[{gameCode:'fixture'}],
 };
 const diagnostic=inspectKissH5ContractManifest('918kiss_normal_myr',catalogueOnly);
 assert.equal(diagnostic.manifestComplete,false);
 assert.equal(diagnostic.missingVendorFields.length,getKissH5ContractRequirements('918kiss_normal_myr').length);
 assert.equal(JSON.stringify(diagnostic).includes('must-never-be-reflected'),false);
 assert.equal(diagnostic.playAllowed,false);
});

test('a syntactically complete documentation manifest still cannot enable an adapter or Play',()=>{
 for(const profileId of KISS_H5_PROFILE_IDS){
  const diagnostic=inspectKissH5ContractManifest(profileId,completeManifest(profileId));
  assert.equal(diagnostic.manifestComplete,true,profileId);
  assert.deepEqual(diagnostic.missingVendorFields,[]);
  assert.deepEqual(diagnostic.invalidVendorFields,[]);
  assert.equal(diagnostic.documentationOnly,true);
  assert.equal(diagnostic.adapterImplemented,false);
  assert.equal(diagnostic.launchAllowed,false);
  assert.equal(diagnostic.walletAllowed,false);
  assert.equal(diagnostic.playAllowed,false);
 }
});

test('profile manifests cannot be reused across normal, MY1 and free accounts',()=>{
 const normal=completeManifest('918kiss_normal_myr');
 const my1=inspectKissH5ContractManifest('918kiss_normal_my1_1to100',normal);
 assert.equal(my1.manifestComplete,false);
 assert.ok(my1.invalidVendorFields.some(item=>item.field==='profile.profile_id'&&item.reason==='unexpected_value'));
 assert.ok(my1.invalidVendorFields.some(item=>item.field==='profile.account_variant'&&item.reason==='unexpected_value'));
 assert.ok(my1.missingVendorFields.includes('profile.my1_definition'));
 const free=inspectKissH5ContractManifest('918kiss_free_myr',normal);
 assert.equal(free.manifestComplete,false);
 assert.ok(free.invalidVendorFields.some(item=>item.field==='profile.balance_class'&&item.reason==='unexpected_value'));
 assert.ok(free.missingVendorFields.includes('profile.free_credit_source'));
});

test('unknown profile IDs do not inherit any 918KISS contract or capability',()=>{
 const diagnostic=inspectKissH5ContractManifest('918kiss_unknown',completeManifest('918kiss_normal_myr'));
 assert.equal(diagnostic.knownProfile,false);
 assert.equal(diagnostic.manifestComplete,false);
 assert.deepEqual(diagnostic.missingVendorFields,[]);
 assert.equal(diagnostic.playAllowed,false);
});

