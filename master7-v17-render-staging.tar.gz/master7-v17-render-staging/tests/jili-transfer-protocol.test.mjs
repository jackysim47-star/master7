import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createJiliProtocolClient,jiliDate,jiliSignature,jiliPlayerId,jiliTransactionId} from '../lib/jili-transfer-protocol.ts';
import {createJiliGameProviderAdapter} from '../lib/jili-provider-adapter.ts';
import {jiliProfileRuntime} from '../lib/jili-profile-runtime.ts';
import {getGameProviderProfile} from '../lib/game-provider-registry.ts';
import {gameTransferRuntime} from '../lib/game-provider-runtime.ts';

const time=Date.parse('2026-11-10T12:00:00Z'),hash=s=>createHash('md5').update(s).digest('hex');
const cfg=(profile='jili_myr_1to1')=>({profile,baseUrl:'https://supplier.example.test/api1',agentId:'synthetic_myr',agentKey:'syntheticKey000000000000000000000',transferAmountUnit:'platform_currency',queryAmountUnit:'platform_currency',balanceAmountUnit:'game_points',reportAmountUnit:'game_points',launchOrigins:['https://games.example.test']});
function fake(handlers,config=cfg()){
 const calls=[],transport=async(url,init)=>{
  const u=new URL(url),method=u.pathname.split('/').at(-1),body=new URLSearchParams(init.body);calls.push({method,body});assert.equal(u.origin,new URL(config.baseUrl).origin);assert.equal(init.redirect,'error');assert.equal(init.method,'POST');
  const excluded=new Set(['Key',...(method==='LoginWithoutRedirect'?['HomeUrl','platform','disableFullScreen']:[])]),query=[...body].filter(([k])=>!excluded.has(k)).map(([k,v])=>`${k}=${v}`).join('&');
  assert.equal(body.get('Key').slice(6,-6),hash(query+hash(jiliDate(time)+config.agentId+config.agentKey)));assert.equal([...body].filter(([k])=>!excluded.has(k)).at(-1)[0],'AgentId');
  const value=handlers[method];if(!value)throw Error('Unexpected method '+method);return typeof value==='function'?value(body):Response.json(value);
 };
 return{calls,transport,client:createJiliProtocolClient(config,transport,()=>time)};
}
const success=data=>({ErrorCode:0,Message:'success',Data:data});
const input={playerId:'m7synthetic',transactionId:'m7original',direction:'deposit',amountMinor:'2000'};
const receipt=(overrides={})=>success({Account:input.playerId,TransactionId:input.transactionId,Amount:20,TransferType:2,Status:1,...overrides});

test('JILI signing matches the published example and the UTC-4 unpadded day boundary',()=>{
 const epoch=Date.parse('2019-01-01T16:00:00Z'),query='Account=Test006&GameId=1&Lang=zh-CN&AgentId=abcd_RMB';
 assert.equal(jiliSignature(query,'abcd_RMB','be8e08f95357d215921f91c6a533f74d3194de52',epoch,'123456','abcdef'),'123456589437f4a0382062dfd0fa5b76eca799abcdef');
 assert.equal(jiliDate(Date.parse('2026-02-07T03:59:59Z')),'26026');assert.equal(jiliDate(Date.parse('2026-02-07T04:00:00Z')),'26027');
 assert.notEqual(jiliPlayerId('jili_myr_1to1','alice'),jiliPlayerId('jili_my1_1to100','alice'));assert.notEqual(jiliTransactionId('jili_myr_1to1','same','deposit'),jiliTransactionId('jili_myr_1to1','same','withdrawal'));
});
test('JILI game catalogue preserves escaped names and rejects duplicate game IDs',async()=>{
 const row={GameId:1,name:{'en-US':'A "quoted" game 123'},GameCategoryId:1},f=fake({GetGameList:success([row])});assert.equal((await f.client.listGames())[0].name,row.name['en-US']);
 const bad=fake({GetGameList:success([row,row])});await assert.rejects(()=>bad.client.listGames(),e=>e.code==='JILI_RESPONSE_INVALID');
});
test('deposit confirmation requires the original account, direction, amount and transaction query',async()=>{
 const f=fake({ExchangeTransferByAgentId:success({TransactionId:input.transactionId,Status:1}),CheckTransferByTransactionId:receipt()});
 assert.deepEqual(await f.client.transfer(input),{state:'confirmed',providerTransactionId:input.transactionId,amountMinor:'2000',requiresLedgerReconciliation:true});
 assert.deepEqual(f.calls.map(x=>x.method),['ExchangeTransferByAgentId','CheckTransferByTransactionId']);assert.equal(f.calls[0].body.get('Amount'),'20.00');
 for(const patch of [{Account:'other'},{TransactionId:'other'},{TransferType:1},{Amount:19.99},{Status:2}]){
  const b=fake({CheckTransferByTransactionId:receipt(patch)});assert.equal((await b.client.queryTransfer(input)).state,'unknown');
 }
});
test('sweeps ignore a delayed member balance and record the actual zero or positive transfer',async()=>{
 for(const amount of [0,15.75]){
  const transfer={...input,direction:'withdrawal'};delete transfer.amountMinor;
  const f=fake({ExchangeTransferByAgentId:success({TransactionId:input.transactionId,Status:1}),CheckTransferByTransactionId:receipt({TransferType:1,Amount:amount})});
  const result=await f.client.transfer(transfer);assert.equal(result.state,'confirmed');assert.equal(result.amountMinor,amount===0?'0':'1575');assert.equal(result.providerTransactionId,input.transactionId);assert.equal(f.calls[0].body.get('TransferType'),'1');assert.equal(f.calls[0].body.get('Amount'),'0');assert.ok(f.calls.every(x=>x.method!=='GetMemberInfo'));
 }
});
test('timeout, duplicate, processing, offline-processing and absent queries never invent a success or retry',async()=>{
 for(const code of [3,20,102,105,106]){const f=fake({ExchangeTransferByAgentId:{ErrorCode:code,Data:null}});assert.equal((await f.client.transfer(input)).state,'unknown');assert.equal(f.calls.length,1);}
 const f=fake({ExchangeTransferByAgentId:()=>{throw Error('Synthetic response lost');},CheckTransferByTransactionId:{ErrorCode:101,Data:null}});assert.equal((await f.client.transfer(input)).state,'unknown');assert.equal((await f.client.queryTransfer(input)).state,'unknown');assert.equal(f.calls.filter(x=>x.method==='ExchangeTransferByAgentId').length,1);
});
test('a definitive new-submit rejection is distinct from a failed recovery query',async()=>{
 const f=fake({ExchangeTransferByAgentId:{ErrorCode:103,Data:null},CheckTransferByTransactionId:{ErrorCode:101,Data:null}});assert.equal((await f.client.transfer(input)).state,'rejected');assert.equal((await f.client.queryTransfer(input)).state,'unknown');
});
test('1:100 uses independently specified transfer and balance units exactly once',async()=>{
 const config=cfg('jili_my1_1to100'),f=fake({GetMemberInfo:success([{Account:input.playerId,Status:2,Balance:1575}]),ExchangeTransferByAgentId:success({TransactionId:input.transactionId,Status:1}),CheckTransferByTransactionId:receipt()},config);
 assert.equal((await f.client.player(input.playerId)).amountMinor,'1575');assert.equal((await f.client.transfer(input)).amountMinor,'2000');assert.equal(f.calls.find(x=>x.method==='ExchangeTransferByAgentId').body.get('Amount'),'20.00');
 const points={...config,transferAmountUnit:'game_points',queryAmountUnit:'game_points'},g=fake({ExchangeTransferByAgentId:success({TransactionId:input.transactionId,Status:1}),CheckTransferByTransactionId:receipt({Amount:2000})},points);assert.equal((await g.client.transfer(input)).amountMinor,'2000');assert.equal(g.calls[0].body.get('Amount'),'2000.00');
});
test('sub-sen and fractional precision mismatches require reconciliation',async()=>{
 const f=fake({CheckTransferByTransactionId:receipt({Amount:20.0001})});assert.equal((await f.client.queryTransfer(input)).state,'unknown');
 const g=fake({GetMemberInfo:success([{Account:input.playerId,Status:2,Balance:0.001}])});assert.equal((await g.client.player(input.playerId)).residual,true);
});
test('login signs ordered mandatory fields and returns only an approved single-use HTTPS URL',async()=>{
 const f=fake({LoginWithoutRedirect:success('https://games.example.test/once?session=synthetic')});assert.equal((await f.client.launch(input.playerId,'1','en','https://www.master7.best/')).launchUrl,'https://games.example.test/once?session=synthetic');assert.equal(f.calls[0].body.get('Lang'),'en-US');
 const g=fake({LoginWithoutRedirect:success('https://unapproved.example.test/once')});await assert.rejects(()=>g.client.launch(input.playerId,'1','en','https://www.master7.best/'),e=>e.code==='JILI_LAUNCH_URL_INVALID');
});
test('lossless wager ingestion preserves numeric 64-bit IDs and binds report pages to their window',async()=>{
 const from=time-30*60_000,to=time-11*60_000,when=new Date(from+60_000-4*60*60_000).toISOString().slice(0,19),raw=`{"ErrorCode":0,"Data":{"Result":[{"Account":"m7synthetic","AgentId":"synthetic_myr","WagersId":1710419268000161101,"RoundIndex":1710419268000161100,"GameId":1,"BetAmount":1.25,"PayoffAmount":2.5,"Status":1,"SettlementTime":"${when}"}],"Pagination":{"CurrentPage":1,"TotalPages":1,"PageLimit":10000,"TotalNumber":1}}}`;
 const f=fake({GetBetRecordByTime:()=>new Response(raw,{headers:{'Content-Type':'application/json'}})}),page=await f.client.wagers(from,to);assert.equal(page.items[0].providerBetId,'1710419268000161101');assert.equal(page.items[0].providerRoundId,'1710419268000161100');assert.equal(page.items[0].betMinor,'125');assert.equal(page.complete,true);
 await assert.rejects(()=>f.client.wagers(from,to,'jili:other:2'),e=>e.code==='JILI_REPORT_CURSOR_INVALID');await assert.rejects(()=>f.client.wagers(from,time),e=>e.code==='JILI_REPORT_WINDOW_INVALID');
});
test('unconfirmed account units and unsafe endpoints fail before contacting any supplier',()=>{
 for(const patch of [{transferAmountUnit:undefined},{queryAmountUnit:'unknown'},{baseUrl:'http://supplier.example.test/api1'},{baseUrl:'https://supplier.example.test/api1?key=bad'},{baseUrl:'https://supplier.example.test/other'}])assert.throws(()=>createJiliProtocolClient({...cfg(),...patch},fetch),e=>e.code==='JILI_CONFIGURATION_INVALID');
});
test('JILI profile and player substitutions cannot reach a transport or create a cash transfer',async()=>{
 const config=cfg(),f=fake({}),adapter=createJiliGameProviderAdapter(config,{fetchImpl:f.transport,allowedReturnOrigins:['https://www.master7.best'],depositEnabled:true,merchantContractVerified:true,sessionClosureVerified:true}),c={profile:getGameProviderProfile(config.profile)};
 await assert.rejects(()=>adapter.depositToGame({profile:getGameProviderProfile('jili_my1_1to100')},{userId:'alice',providerPlayerId:jiliPlayerId(config.profile,'alice'),platformTransactionId:'same',amountMinor:'20',currency:'MYR'}),e=>e.code==='JILI_PROFILE_MISMATCH');
 await assert.rejects(()=>adapter.depositToGame(c,{userId:'alice',providerPlayerId:jiliPlayerId(config.profile,'bob'),platformTransactionId:'same',amountMinor:'20',currency:'MYR'}),e=>e.code==='JILI_PLAYER_MISMATCH');assert.equal(f.calls.length,0);
 const closed=createJiliGameProviderAdapter(config,{fetchImpl:f.transport,allowedReturnOrigins:[],depositEnabled:true});await assert.rejects(()=>closed.depositToGame(c,{userId:'alice',providerPlayerId:jiliPlayerId(config.profile,'alice'),platformTransactionId:'same',amountMinor:'20',currency:'MYR'}),e=>e.code==='JILI_MERCHANT_CONTRACT_UNVERIFIED');assert.equal(f.calls.length,0);
});
test('JILI runtime needs account evidence, closure finality and production acceptance independently',()=>{
 const connection=cfg(),slot={mode:'production',environment:'production',recoveryEnabled:true,qaMemberIds:['alice'],approvedApiEndpoints:[connection.baseUrl],connection,merchantContractVerified:true,merchantContractEvidenceSha256:'a'.repeat(64),sessionClosureVerified:true,allIssuedLaunchesInvalidated:true,lateResultsFinal:true},document=()=>JSON.stringify({profiles:{[connection.profile]:slot}});
 assert.equal(jiliProfileRuntime(document(),connection.profile,'alice').launchAuthorized,false);assert.equal(jiliProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true}).launchAuthorized,true);
 slot.lateResultsFinal=false;assert.equal(jiliProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true}).recoveryEnabled,false);slot.lateResultsFinal=true;slot.merchantContractEvidenceSha256='';assert.equal(jiliProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true}).launchAuthorized,false);
 slot.merchantContractEvidenceSha256='a'.repeat(64);slot.mode='qa';assert.equal(gameTransferRuntime({gameTransferProfilesJson:document()},connection.profile,'bob').launchAuthorized,false);assert.equal(gameTransferRuntime({gameTransferProfilesJson:document()},connection.profile,'alice').launchAuthorized,true);assert.equal(gameTransferRuntime({gameTransferProfilesJson:document()},'jili_my1_1to100','alice'),null);
});
