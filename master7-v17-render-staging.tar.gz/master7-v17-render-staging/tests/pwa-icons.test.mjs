import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const pngSize=path=>{const data=readFileSync(path);assert.deepEqual([...data.subarray(0,8)],[137,80,78,71,13,10,26,10]);return [data.readUInt32BE(16),data.readUInt32BE(20)];};

test('PWA manifest uses standard square PNG icons and iOS uses 180px artwork',()=>{
 const manifest=JSON.parse(readFileSync('public/manifest.webmanifest','utf8'));
 for(const size of [192,512]){assert.ok(manifest.icons.some(icon=>icon.src===`/assets/pwa-icon-${size}.png`&&icon.sizes===`${size}x${size}`));assert.deepEqual(pngSize(`public/assets/pwa-icon-${size}.png`),[size,size]);}
 assert.deepEqual(pngSize('public/assets/pwa-icon-180.png'),[180,180]);
 const portal=readFileSync('app/portal.html','utf8'),worker=readFileSync('public/service-worker.js','utf8');assert.match(portal,/apple-touch-icon" sizes="180x180" href="\/assets\/pwa-icon-180\.png"/);for(const size of [180,192,512])assert.match(worker,new RegExp(`pwa-icon-${size}\\.png`));
});
