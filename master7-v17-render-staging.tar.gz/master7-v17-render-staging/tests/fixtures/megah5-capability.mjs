// Mirrors the already deployed gateway /readiness response, using no secrets.
export function megaCapabilityFixture(){return {
 service:'master7-integration-gateway',scope:'configuration_only',productionQa:'not_verified',liveReady:false,
 megah5Transfer:{mode:'fund_transfer',credentialsConfigured:true,walletTokenConfigured:true,switches:{status:true,transfers:true},channels:Object.fromEntries(['status','deposit','withdrawal'].map(name=>[name,{enabled:true,configurationReady:true,blockers:[],productionQa:'not_verified',liveReady:false}]))},
};}
