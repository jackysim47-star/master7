export async function seedWalletMembers(db){
 for(const user of ['alice','bob','charlie']){
  await db.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,'member',1,'fixture',0)").bind(user,user).run();
  await db.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES(?,?,?,'fixture','vpay',10000,'MYR','bank','credited',0,0)").bind('credit-'+user,user,'credit-request-'+user).run();
  for(const [account,amount] of [['member','10000'],['provider_clearing','-10000']])await db.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES(?,?,?,?,?,'MYR',0)").bind(account+'-'+user,'credit-'+user,user,account,amount).run();
 }
 for(const profile of ['jdb_myr','spribe_myr']){
  await db.prepare("INSERT INTO game_provider_profiles(id,provider_id,display_name,adapter_key,wallet_mode,balance_class,currency,unit_numerator,unit_denominator,environment,status,created_at,updated_at) VALUES(?,?,?,'jdb','transfer','cash','MYR',1,1,'uat','uat',0,0)").bind(profile,profile==='jdb_myr'?'jdb':'spribe',profile).run();
  for(const user of ['alice','bob','charlie'])await db.prepare("INSERT INTO game_provider_players(profile_id,user_id,provider_player_id,status,created_at,updated_at,verified_at) VALUES(?,?,?,'verified',0,0,0)").bind(profile,user,profile+'-'+user).run();
 }
}

export async function seedGenericSession(db,options={}){
 const id=options.id??'session-one',user=options.user??'alice',profile=options.profile??'jdb_myr',status=options.status??'unknown',currency=options.currency??'MYR';
 await db.prepare("INSERT INTO game_provider_sessions(id,profile_id,user_id,provider_player_id,game_code,provider_game_id,request_key,request_fingerprint,wallet_mode,currency,status,created_at,updated_at,closed_at) VALUES(?,?,?,?,'0:100','0:100',?,'fixture','transfer',?,?,0,1,?)")
  .bind(id,profile,user,options.playerId??profile+'-'+user,'request-'+id,currency,status,options.closedAt??null).run();
 const reserved=options.reserved===undefined?'4000':options.reserved;
 if(reserved!==null)await db.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES(?,?,?,?,0)").bind(options.reservationUser??user,options.reservationKind??'game',id,reserved).run();
 if(options.noTransfer!==true){
  const transfer=options.transferStatus??'unknown',attempts=options.attempts??(transfer==='prepared'?0:1),completed=options.completedAt===undefined?(['succeeded','failed'].includes(transfer)?2:null):options.completedAt;
  await db.prepare("INSERT INTO game_wallet_transfers(id,session_id,profile_id,user_id,direction,request_key,request_fingerprint,provider_reference,amount_minor,currency,status,attempts,created_at,updated_at,completed_at) VALUES(?,?,?,?,?,?,'fixture',?,?,?, ?,?,0,1,?)")
   .bind('transfer-'+id,id,profile,user,options.direction??'deposit','transfer-request-'+id,options.providerReference??'provider-'+id,options.transferAmount??'4000',options.transferCurrency??currency,transfer,attempts,completed).run();
 }
 return {id,user,profile};
}

export async function seedGenericPosting(db,session,{status='applied',legs='balanced'}={}){
 await db.prepare("INSERT INTO game_rounds(id,profile_id,user_id,session_id,provider_round_id,provider_game_id,currency,status,opened_at,updated_at,closed_at) VALUES(?,?,?,?,?,'0:100','MYR','settled',0,1,1)").bind('round-'+session.id,session.profile,session.user,session.id,'vendor-round-'+session.id).run();
 await db.prepare("INSERT INTO game_transactions(id,profile_id,user_id,round_id,provider_transaction_id,event_type,amount_minor,currency,request_fingerprint,status,received_at,applied_at) VALUES(?,?,?,?,?,'transfer_result',100,'MYR','fixture',?,0,?)").bind('transaction-'+session.id,session.profile,session.user,'round-'+session.id,'vendor-transaction-'+session.id,status,status==='applied'?1:null).run();
 if(legs!=='none'){
  await db.prepare("INSERT INTO game_wallet_postings(id,transaction_id,profile_id,user_id,account_code,amount_minor,currency,created_at) VALUES(?,?,?,?,'member',100,'MYR',1)").bind('member-'+session.id,'transaction-'+session.id,session.profile,session.user).run();
  if(legs==='balanced')await db.prepare("INSERT INTO game_wallet_postings(id,transaction_id,profile_id,user_id,account_code,amount_minor,currency,created_at) VALUES(?,?,?,?,'provider_game_clearing',-100,'MYR',1)").bind('clearing-'+session.id,'transaction-'+session.id,session.profile,session.user).run();
 }
}
