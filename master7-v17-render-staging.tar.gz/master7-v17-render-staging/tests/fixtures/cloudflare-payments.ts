import {gspayOrderSignature,gspayResultSignature} from '../../lib/gspay.ts';
import {oneMpayCallbackToken,oneMpayOrderToken} from '../../lib/onempay.ts';

type PaymentProvider='vpay'|'gspay'|'1mpay';
type StoredOrder={id:string;amount:string;customer:string;reference:string;player?:string};

const portalReturnUrl='https://master7-v17-staging.onrender.com/payment/return';
const vpayGateway='https://master7-integration-gateway.onrender.com';
const vpayTrader='synthetic-d1-trader';
const vpayOrderToken='synthetic-vpay-order-'.padEnd(48,'o');
const vpayQueryToken='synthetic-vpay-query-'.padEnd(48,'q');
const vpayCallbackToken='synthetic-vpay-callback-'.padEnd(48,'c');
const gspayBase='https://api.thegspay.com';
const gspayAuth='a'.repeat(32),gspaySecret='b'.repeat(32),gspayCheckoutKey='c'.repeat(32);
const oneMpayBase='https://api.1mpay.net';
const oneMpayMerchant='D1TESTMERCHANT',oneMpaySecret='synthetic-d1-1mpay-secret';

function fail(message:string):never{throw new Error(`Synthetic payment fixture: ${message}`);}
function expect(condition:unknown,message:string):asserts condition{if(!condition)fail(message);}

export function createCloudflarePaymentFixture(provider:PaymentProvider){
 const orders=new Map<string,StoredOrder>();
 const observation={createCalls:0,queryCalls:0,callbackCalls:0,forcedQueryFailures:0,externalCalls:0};
 let queryFailuresRemaining=1;
 const syntheticFetch=async(input:RequestInfo|URL,init:RequestInit={})=>{
  const url=new URL(String(input));
  if(provider==='vpay'){
   expect(url.origin===vpayGateway,'unexpected VPay origin');
   const authorization=new Headers(init.headers).get('authorization');
   if(url.pathname==='/platform/vpay/config'){
    expect(init.method==='GET','VPay config must use GET');
    expect(authorization===`Bearer ${vpayQueryToken}`,'VPay config query token mismatch');
    return Response.json({provider:'vpay',mode:'uat',paymentReady:true,traderId:vpayTrader,notifyUrl:`${vpayGateway}/callbacks/vpay/payment`,returnUrl:portalReturnUrl,tradeCodes:['2']});
   }
   const request=JSON.parse(String(init.body??'{}')) as Record<string,unknown>;
   if(url.pathname==='/platform/vpay/order'){
    observation.createCalls++;
    expect(init.method==='POST','VPay order must use POST');
    expect(authorization===`Bearer ${vpayOrderToken}`,'VPay order token mismatch');
    const id=String(request.outTradeNo??''),amount=String(request.amount??'');
    expect(id.length>0&&amount==='20.00','VPay order binding mismatch');
    const reference=`D1VP${id.replace(/[^A-Za-z0-9]/g,'').slice(-20)}`;
    orders.set(id,{id,amount,customer:'',reference});
    return Response.json({provider:'vpay',upstreamStatus:200,result:{code:0,data:{trader_id:vpayTrader,out_trade_no:id,trade_no:reference,amount,pay_url:'https://payment.vpay.club/pay/d1-synthetic'}}});
   }
   if(url.pathname==='/platform/vpay/order-query'){
    observation.queryCalls++;
    expect(init.method==='POST','VPay query must use POST');
    expect(authorization===`Bearer ${vpayQueryToken}`,'VPay query token mismatch');
    const order=orders.get(String(request.outTradeNo??''));expect(order,'unknown VPay order');
    if(queryFailuresRemaining-->0){observation.forcedQueryFailures++;throw new Error('synthetic VPay query timeout');}
    return Response.json({provider:'vpay',upstreamStatus:200,result:{code:0,data:{trader_id:vpayTrader,out_trade_no:order.id,trade_no:order.reference,amount:order.amount,currency:'MYR',state:3}}});
   }
   observation.externalCalls++;return fail('unexpected VPay route');
  }
  if(provider==='gspay'){
   expect(url.origin===gspayBase,'unexpected GSPAY origin');
   const createPath=`/v2/integrations/operators/${gspayAuth}/payment`,queryPath=`/v2/integrations/operators/${gspayAuth}/getpayment`;
   if(url.pathname===createPath){
    observation.createCalls++;
    expect(init.method==='POST','GSPAY order must use POST');
    const request=JSON.parse(String(init.body??'{}')) as Record<string,unknown>;
    const id=String(request.transaction_id??''),player=String(request.player_username??''),amount=Number(request.amount).toFixed(2);
    expect(amount==='20.00','GSPAY amount mismatch');
    expect(request.signature===gspayOrderSignature(id,player,amount,gspaySecret),'GSPAY order signature mismatch');
    const reference='35802335';orders.set(id,{id,amount,customer:'',reference,player});
    return Response.json({code:200,data:JSON.stringify([{payment_id:reference,payment_url:`https://secured.gspay.online/channel?id=${reference}&key=${gspayCheckoutKey}`}]),message:'ok'});
   }
   if(url.pathname===queryPath){
    observation.queryCalls++;
    expect(init.method==='GET','GSPAY query must use GET');
    expect(url.searchParams.get('auth_key')===gspayAuth,'GSPAY query auth mismatch');
    const order=orders.get(url.searchParams.get('transaction_id')??'');expect(order,'unknown GSPAY order');
    if(queryFailuresRemaining-->0){observation.forcedQueryFailures++;throw new Error('synthetic GSPAY query timeout');}
    const result={payment_id:order.reference,transaction_id:order.id,player_username:order.player,amount:order.amount,completed:true,success:true,remark:'paid',signature:gspayResultSignature(order.reference,order.amount,order.id,gspaySecret)};
    return Response.json({code:200,data:JSON.stringify([result]),message:'ok'});
   }
   observation.externalCalls++;return fail('unexpected GSPAY route');
  }
  expect(url.origin===oneMpayBase,'unexpected 1MPay origin');
  if(url.pathname==='/fundtransfer/json'){
   observation.createCalls++;
   expect(init.method==='POST','1MPay order must use POST');
   const request=Object.fromEntries(new URLSearchParams(String(init.body??'')));
   expect(request.amount==='20.00'&&request.currency==='MYR','1MPay amount or currency mismatch');
   expect(request.token===oneMpayOrderToken(oneMpayMerchant,request.amount,request.refid,request.customer,oneMpaySecret),'1MPay order token mismatch');
   const reference=`D1MP${request.refid.slice(-15)}`;orders.set(request.refid,{id:request.refid,amount:request.amount,customer:request.customer,reference});
   return Response.json({code:0,message:'Redirect URL',redirect_url:`${oneMpayBase}/fundtransfer/pay/d1-synthetic`,data:{trxno:reference}});
  }
  if(url.pathname.startsWith('/transquery/')){
   observation.queryCalls++;
   expect(init.method==='GET','1MPay query must use GET');
   const [, ,encodedReference]=url.pathname.split('/'),reference=decodeURIComponent(encodedReference),order=[...orders.values()].find(item=>item.reference===reference);expect(order,'unknown 1MPay order');
   if(queryFailuresRemaining-->0){observation.forcedQueryFailures++;throw new Error('synthetic 1MPay query timeout');}
   const token=oneMpayCallbackToken(oneMpayMerchant,order.amount,order.id,order.customer,oneMpaySecret,order.reference);
   return Response.json({merchant:oneMpayMerchant,amount:order.amount,refid:order.id,customer:order.customer,token,trxno:order.reference,status:'Successful',status_message:'Successful'});
  }
  observation.externalCalls++;return fail('unexpected 1MPay route');
 };
 return {
  context(){
   if(provider==='vpay')return {vpayGatewayUrl:vpayGateway,vpayMode:'uat',vpayTraderId:vpayTrader,vpayOrdersEnabled:'true',vpayOrderToken,vpayQueryToken,vpayCallbackToken,vpayReturnUrl:portalReturnUrl,vpayFetch:syntheticFetch};
   if(provider==='gspay')return {gspayApiBase:gspayBase,gspayAuthKey:gspayAuth,gspaySecretKey:gspaySecret,gspayOrdersEnabled:'true',gspayReturnUrl:portalReturnUrl,gspayFetch:syntheticFetch};
   return {oneMpayApiBase:oneMpayBase,oneMpayMerchant,oneMpaySecretKey:oneMpaySecret,oneMpayOrdersEnabled:'true',oneMpayCallbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',oneMpayReturnUrl:portalReturnUrl,oneMpayDiagnosticToken:'synthetic-d1-diagnostic-'.padEnd(48,'d'),oneMpayFetch:syntheticFetch};
  },
  callbackRequest(orderId:string){
   const order=orders.get(orderId);expect(order,`unknown ${provider} callback order`);observation.callbackCalls++;
   if(provider==='vpay')return new Request(`https://portal.example.test/api/payment-callbacks/vpay/payment`,{method:'POST',headers:{authorization:`Bearer ${vpayCallbackToken}`,'content-type':'application/json'},body:JSON.stringify({out_trade_no:order.id,trade_no:order.reference,amount:order.amount,state:3,trader_id:vpayTrader})});
   if(provider==='gspay')return new Request('https://portal.example.test/api/payment/gspay/callback',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({auth_key:gspayAuth,success:true,completed:true,payment_id:order.reference,transaction_id:order.id,player_username:order.player,amount:order.amount,remark:'paid',signature:gspayResultSignature(order.reference,order.amount,order.id,gspaySecret)})});
   return new Request('https://portal.example.test/api/payment-callbacks/1mpay/payment',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({merchant:oneMpayMerchant,amount:order.amount,refid:order.id,customer:order.customer,trxno:order.reference,status:'Successful',token:oneMpayCallbackToken(oneMpayMerchant,order.amount,order.id,order.customer,oneMpaySecret,order.reference)})});
  },
  observation(){return {...observation,orders:orders.size};},
 };
}
