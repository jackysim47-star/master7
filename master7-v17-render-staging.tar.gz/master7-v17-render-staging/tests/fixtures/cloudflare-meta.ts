// Synthetic transport for a disposable workerd/D1 journey. Never a production binding.
import type { Context } from '../../lib/backend.ts';

export function createCloudflareMetaFixture(profileId: string, capability: string) {
  if (profileId !== 'metagaming_normal_myr') throw new Error('Unsupported isolated META profile');
  const origin = 'https://meta-gateway.example.test';
  const connection = {
    profile: profileId, account: 'normal', baseUrl: origin, currency: 'MYR',
    playerToken: 'p'.repeat(48), walletToken: 'w'.repeat(48), recoveryToken: 'r'.repeat(48), reportToken: 'l'.repeat(48), launchOrigins: ['https://games.example.test'],
  };
  const slot = {
    mode: 'qa', environment: 'production', recoveryEnabled: true, qaMemberIds: [] as string[], approvedApiOrigins: [origin], connection,
    merchantContractVerified: true, merchantContractEvidenceSha256: 'a'.repeat(64), catalogueAvailabilityVerified: true, catalogueAvailabilityEvidenceSha256: 'd'.repeat(64),
    sessionClosureVerified: true, sessionClosureEvidenceSha256: 'b'.repeat(64), allIssuedLaunchesInvalidated: true, lateResultsFinal: true,
  };
  let cash = '0.00', online = false, launches = false, player = '', loseReturnResponse = false, missingQuery = false;
  const transfers = new Map<string, { transactionId: string; amount: string }>();
  const calls: Array<{ method: string; transactionId: string | null; amount: string | null; direction: string | null }> = [];
  const catalogue = () => Response.json({ provider: 'metagaming', account: 'normal', currency: 'MYR', games: [{ gameCode: '1', name: 'Synthetic META slot', gameType: 'SLOT', maintenance: false }], upstreamStatus: 200, complete: true });
  const transport: typeof fetch = async (url, init) => {
    const parsed = new URL(String(url));
    if (parsed.origin !== origin) throw new Error('External META request forbidden');
    if (parsed.pathname === '/providers/metagaming/games' && parsed.searchParams.get('account') === 'normal') return catalogue();
    if (!parsed.pathname.startsWith('/platform/metagaming/') || init?.method !== 'POST') throw new Error('Unexpected synthetic META request');
    const method = parsed.pathname.split('/').at(-1)!, body = JSON.parse(String(init.body));
    const credential = ['deposit', 'withdraw', 'transfer-status'].includes(method) ? connection.walletToken : ['kick', 'unfinished-rounds'].includes(method) ? connection.recoveryToken : connection.playerToken;
    if (new Headers(init.headers).get('Authorization') !== 'Bearer ' + credential || body.profileId !== profileId || body.account !== 'normal') throw new Error('Synthetic META binding mismatch');
    if (player && body.playerId !== player) throw new Error('Synthetic META player mismatch');
    calls.push({ method, transactionId: body.referenceId ?? null, amount: body.amount ?? null, direction: body.transferType ?? null });
    let result: Record<string, unknown> = {};
    if (method === 'player') player = body.playerId;
    else if (method === 'balance') result = { currentBalance: cash, currency: 'MYR' };
    else if (method === 'unfinished-rounds') result = { rounds: online ? [{ id: 'synthetic-open' }] : [] };
    else if (method === 'kick') online = false;
    else if (method === 'deposit' || method === 'withdraw') {
      if (transfers.has(body.referenceId)) throw new Error('Duplicate META transfer submission');
      if (body.amount !== (method === 'deposit' ? '50.00' : cash)) throw new Error('Synthetic META amount mismatch');
      transfers.set(body.referenceId, { transactionId: method === 'deposit' ? '9001' : '9002', amount: body.amount });
      cash = method === 'deposit' ? body.amount : '0.00';
      if (method === 'withdraw' && loseReturnResponse) throw new Error('Synthetic accepted META return response lost');
      result = { currentBalance: cash, currency: 'MYR' };
    } else if (method === 'transfer-status') result = { transaction: missingQuery ? null : transfers.get(body.referenceId) ?? null };
    else if (method === 'launch') { online = true; result = { url: 'https://games.example.test/synthetic-meta-normal' }; }
    else throw new Error('Unexpected synthetic META operation: ' + method);
    return Response.json({ provider: 'metagaming', profileId, account: 'normal', operation: method, result: { ok: true, status: 200, ...result } });
  };
  return {
    context(): Partial<Context> {
      return {
        newGameLaunchesEnabled: launches ? 'true' : 'false', gameTransferProfilesJson: JSON.stringify({ profiles: { [profileId]: slot } }), providerTransferFetch: transport,
        gameGatewayUrl: 'https://master7-integration-gateway.onrender.com', gameGatewayFetch: async url => {
          const parsed = new URL(String(url));
          if (parsed.origin !== 'https://master7-integration-gateway.onrender.com' || parsed.pathname !== '/providers/metagaming/games' || parsed.searchParams.get('account') !== 'normal') throw new Error('Synthetic META catalogue binding mismatch');
          return catalogue();
        },
      };
    },
    async control(req: Request) {
      if (req.headers.get('x-fixture-capability') !== capability) return new Response(null, { status: 403 });
      if (req.method === 'POST') {
        const value = await req.json() as { action?: string; memberId?: string };
        if (value.action === 'configure' && typeof value.memberId === 'string' && /^local:[a-f0-9-]{36}$/.test(value.memberId)) { slot.qaMemberIds = [value.memberId]; launches = true; }
        else if (value.action === 'prepare-lost-sweep') { cash = '53.75'; loseReturnResponse = true; }
        else if (value.action === 'pause-and-hide-query') { launches = false; slot.mode = 'closed'; slot.qaMemberIds = []; missingQuery = true; }
        else if (value.action === 'restore-query') missingQuery = false;
        else return Response.json({ error: 'Invalid isolated fixture command' }, { status: 400 });
      }
      return Response.json({ profileId, account: 'normal', cashMinor: cash === '0.00' ? '0' : cash.replace('.', ''), online, calls, transferCount: transfers.size });
    },
  };
}
