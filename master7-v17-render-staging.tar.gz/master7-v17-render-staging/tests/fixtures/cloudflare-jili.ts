// Synthetic transport for a disposable workerd/D1 journey. Never a production binding.
import type { Context } from '../../lib/backend.ts';

type ProfileId = 'jili_myr_1to1' | 'jili_my1_1to100';
type Transfer = { Account: string; TransactionId: string; Amount: string; TransferType: number; Status: number };
const origin = 'https://supplier.example.test';
const money = (minor: bigint) => `${minor / 100n}.${String(minor % 100n).padStart(2, '0')}`;

export function createCloudflareJiliFixture(profileId: string | undefined, capability: string) {
  if (!profileId) return null;
  if (!['jili_myr_1to1', 'jili_my1_1to100'].includes(profileId)) throw new Error('Unsupported isolated JILI profile');
  const id = profileId as ProfileId, hundred = id === 'jili_my1_1to100';
  const account = hundred ? '1to100' : '1to1';
  const connection = {
    profile: id, baseUrl: origin + '/api1', agentId: 'synthetic_' + account,
    agentKey: 'syntheticAgentKey000000000000000', transferAmountUnit: 'platform_currency',
    queryAmountUnit: 'platform_currency', balanceAmountUnit: 'game_points', reportAmountUnit: 'game_points',
    launchOrigins: ['https://games.example.test'],
  };
  const slot = {
    mode: 'qa', environment: 'production', recoveryEnabled: true, qaMemberIds: [] as string[],
    approvedApiEndpoints: [connection.baseUrl], connection,
    merchantContractVerified: true, merchantContractEvidenceSha256: 'a'.repeat(64),
    catalogueAvailabilityVerified: true, catalogueAvailabilityEvidenceSha256: 'd'.repeat(64),
    sessionClosureVerified: true, sessionClosureEvidenceSha256: 'b'.repeat(64),
    allIssuedLaunchesInvalidated: true, lateResultsFinal: true,
  };
  let cash = 0n, online = false, created = false, player = '', launches = false;
  let loseSweepResponse = false, missingQuery = false;
  const transfers = new Map<string, Transfer>();
  const calls: Array<{ method: string; transactionId: string | null; amount: string | null; direction: string | null }> = [];
  const ok = (Data: unknown) => Response.json({ ErrorCode: 0, Data });
  const transport: typeof fetch = async (url, init) => {
    const u = new URL(String(url));
    if (u.origin !== origin || !u.pathname.startsWith('/api1/') || init?.method !== 'POST') throw new Error('External JILI request forbidden');
    const method = u.pathname.split('/').at(-1)!, form = new URLSearchParams(String(init.body));
    if (form.get('AgentId') !== connection.agentId || !form.get('Key')) throw new Error('Synthetic JILI authentication mismatch');
    const suppliedPlayer = form.get('Account') ?? form.get('Accounts');
    if (player && suppliedPlayer && suppliedPlayer !== player) throw new Error('Synthetic JILI player mismatch');
    calls.push({ method, transactionId: form.get('TransactionId'), amount: form.get('Amount'), direction: form.get('TransferType') });
    if (method === 'GetGameList') return ok([{ GameId: 1, name: { 'en-US': 'Synthetic JILI slot' }, GameCategoryId: 1, JP: false }]);
    if (method === 'CreateMember') { created = true; player = form.get('Account')!; return ok(null); }
    if (method === 'GetMemberInfo') return ok([{ Account: form.get('Accounts'), Balance: hundred ? String(cash) : money(cash), Status: created ? online ? 1 : 2 : 3 }]);
    if (method === 'LoginWithoutRedirect') { online = true; return ok('https://games.example.test/synthetic-' + account); }
    if (method === 'KickMember') { online = false; return ok(null); }
    if (method === 'ExchangeTransferByAgentId') {
      const serial = form.get('TransactionId')!, direction = form.get('TransferType');
      if (transfers.has(serial)) throw new Error('Synthetic supplier received a duplicate transfer submission');
      if (direction !== '1' && direction !== '2') throw new Error('Synthetic JILI direction mismatch');
      const amount = direction === '2' ? form.get('Amount')! : money(cash);
      if (direction === '2' && amount !== '50.00') throw new Error('MYR transfer amount is not exactly the funded 50.00');
      if (direction === '1' && form.get('Amount') !== '0') throw new Error('JILI return must use the existing all-balance sweep');
      transfers.set(serial, { Account: form.get('Account')!, TransactionId: serial, Amount: amount, TransferType: Number(direction), Status: 1 });
      cash = direction === '2' ? 5000n : 0n;
      if (direction === '1' && loseSweepResponse) throw new Error('Synthetic accepted sweep response lost');
      return ok({ TransactionId: serial, Status: 1 });
    }
    if (method === 'CheckTransferByTransactionId') return missingQuery ? Response.json({ ErrorCode: 101, Data: null }) : ok(transfers.get(form.get('TransactionId')!) ?? null);
    throw new Error('Unexpected synthetic JILI operation: ' + method);
  };
  return {
    context(): Partial<Context> {
      return {
        newGameLaunchesEnabled: launches ? 'true' : 'false', providerTransferFetch: transport,
        gameTransferProfilesJson: JSON.stringify({ profiles: { [id]: slot } }),
        gameGatewayUrl: 'https://master7-integration-gateway.onrender.com',
        gameGatewayFetch: async url => {
          const u = new URL(String(url));
          if (u.hostname !== 'master7-integration-gateway.onrender.com' || u.pathname !== '/providers/jili/games' || u.searchParams.get('account') !== account) throw new Error('Synthetic catalogue account mismatch');
          return Response.json({ provider: 'jili', account, currency: 'MYR', ratio: hundred ? '1:100' : '1:1', games: [{ gameCode: '1', name: 'Synthetic JILI slot', category: 'SLOT', maintenance: false }], upstreamStatus: 200, complete: true });
        },
      };
    },
    async control(req: Request) {
      if (req.headers.get('x-fixture-capability') !== capability) return new Response(null, { status: 403 });
      if (req.method === 'POST') {
        const value = await req.json() as { action?: string; memberId?: string };
        if (value.action === 'configure' && typeof value.memberId === 'string' && /^local:[a-f0-9-]{36}$/.test(value.memberId)) { slot.qaMemberIds = [value.memberId]; launches = true; }
        else if (value.action === 'prepare-lost-sweep') { cash = 5375n; loseSweepResponse = true; }
        else if (value.action === 'pause-and-hide-query') { launches = false; slot.mode = 'closed'; slot.qaMemberIds = []; missingQuery = true; }
        else if (value.action === 'restore-query') missingQuery = false;
        else return Response.json({ error: 'Invalid isolated fixture command' }, { status: 400 });
      }
      return Response.json({ profileId: id, account, cashMinor: String(cash), online, calls, transferCount: transfers.size });
    },
  };
}
