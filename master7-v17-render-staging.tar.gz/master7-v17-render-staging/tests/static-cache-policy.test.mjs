import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

test('Render caches static assets while keeping the app shell refreshable',async()=>{
 const [config,route]=await Promise.all([
  readFile(new URL('../vite.render.config.ts',import.meta.url),'utf8'),
  readFile(new URL('../app/route.ts',import.meta.url),'utf8'),
 ]);
 assert.match(config,/"\/assets\/\*\*"[\s\S]*?public, max-age=86400, stale-while-revalidate=604800/);
 assert.match(config,/"\/downloads\/\*\*"[\s\S]*?public, max-age=31536000, immutable/);
 for(const path of ['/service-worker.js','/manifest.webmanifest','/offline.html']){
  const escaped=path.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  assert.match(config,new RegExp(`"${escaped}"[\\s\\S]*?no-cache, max-age=0, must-revalidate`));
 }
 assert.match(route,/'Cache-Control':'no-store'/);
});
