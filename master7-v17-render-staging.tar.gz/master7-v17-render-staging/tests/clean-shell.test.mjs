import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const css=readFileSync(new URL('../public/assets/style.css',import.meta.url),'utf8');
const shell=css.slice(css.indexOf('/* Release 17.0.74 · clean member shell'));

test('clean shell gives every portal menu a decorative cyan status lamp',()=>{
 assert.ok(shell.length>0,'clean shell release block is missing');
 assert.match(shell,/\.nav-button::after,[\s\S]*?\.sidebar-game-filter::after,[\s\S]*?\.admin-internal-sidebar a::after/);
 assert.match(shell,/background:var\(--shell-cyan\)/);
 assert.match(shell,/\.nav-button\.active::after,[\s\S]*?\.sidebar-game-filter\.active::after,[\s\S]*?\.admin-internal-sidebar a\.active::after/);
});

test('only the current menu lamp pulses slowly and reduced motion disables it',()=>{
 assert.match(shell,/@keyframes master7-cyan-menu-pulse/);
 assert.match(shell,/animation:master7-cyan-menu-pulse 3\.1s ease-in-out infinite/);
 assert.doesNotMatch(shell,/\.nav-button::after[^}]*animation:/);
 assert.match(shell,/@media\(prefers-reduced-motion:reduce\)[\s\S]*?animation:none/);
});

test('mobile member navigation is a safe-area aware fixed bottom bar',()=>{
 assert.match(shell,/@media\(max-width:760px\)/);
 assert.match(shell,/\.topnav\{[\s\S]*?position:fixed;[\s\S]*?bottom:calc\(7px \+ env\(safe-area-inset-bottom\)\)/);
 assert.match(shell,/padding-bottom:calc\(76px \+ env\(safe-area-inset-bottom\)\)/);
 assert.match(shell,/\.topnav \.nav-button\{[\s\S]*?min-height:48px/);
});

test('clean shell keeps auth isolated and provides keyboard-sized controls',()=>{
 assert.match(shell,/body:not\(\.auth-entry\)/);
 assert.doesNotMatch(shell,/body\.auth-entry #authDialog/);
 assert.match(shell,/\.button\{min-height:44px/);
 assert.match(shell,/:focus-visible\{outline:2px solid var\(--shell-cyan\)/);
});
