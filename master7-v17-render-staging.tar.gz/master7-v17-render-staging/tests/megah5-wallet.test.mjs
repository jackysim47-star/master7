import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {
 MegaWalletError,
 megaWalletConfigured,
 megaWalletLiveReady,
 prepareMegaWallet,
 recoverMegaWallet,
 settleMegaWallet,
} from '../lib/megah5-wallet.ts';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

const migrations=['0000_broken_bloodscream.sql','0001_orange_owl.sql','0002_lobby_ads.sql','0003_game_visibility.sql','0004_sponsored_brands.sql','0005_custom_game_cards.sql','0006_malaysia_member_phone.sql','0007_vpay_uat_wallet.sql','0008_member_sms_otp.sql','0009_game_payment_statuses.sql','0010_game_visibility_artwork.sql','0011_provider_artwork.sql','0012_close_defaults_and_brand_directory.sql','0013_api_supplier_artwork.sql','0014_withdrawal_requests.sql','0019_game_catalogue_sync.sql','0020_manual_bank_deposits.sql','0021_api_supplier_status.sql','0022_referrals.sql','0023_marketing_campaigns.sql','0024_megah5_transfer_wallet.sql','0025_game_access_zones.sql','0090_security_wallet_reservations.sql'];
const gatewayUrl='https://master7-integration-gateway.onrender.com';
const gameToken='g'.repeat(48),walletToken='w'.repeat(48);

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function harness(){
 const sqlite=new DatabaseSync(':memory:');
 for(const migration of migrations)sqlite.exec(readFileSync(new URL(`../drizzle/${migration}`,import.meta.url),'utf8'));
 const db={
  prepare:sql=>new Statement(sqlite,sql),
  async batch(list){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const statement of list)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}},
 };
 sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member@example.test','member',1,'csrf',0)").run();
 sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('credit-order','member','credit-request','fixture','manual_bank',2000,'MYR','fixture','credited',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('credit-member','credit-order','member','member',2000,'MYR',0),('credit-clearing','credit-order','member','provider_clearing',-2000,'MYR',0)").run();
 const provider={balance:'0.00',deposit:'success',withdraw:'success',statusAmount:'20.00'};
 const calls=[];
 const fetchImpl=async(url,options)=>{
  const path=new URL(url).pathname;calls.push({path,authorization:options.headers.Authorization,body:JSON.parse(options.body)});
  if(path.endsWith('/balance'))return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:provider.balance,Currency:'MYR'}});
  if(path.endsWith('/deposit')){
   if(provider.deposit==='throw')throw new Error('network unavailable');
   if(provider.deposit==='503')return Response.json({error:'upstream_timeout'},{status:503});
   return Response.json({provider:'megah5',result:{Status:200,Description:'Success'}});
  }
  if(path.endsWith('/withdraw')){
   if(provider.withdraw==='throw')throw new Error('network unavailable');
   if(provider.withdraw==='503')return Response.json({error:'upstream_timeout'},{status:503});
   return Response.json({provider:'megah5',result:{Status:200,Description:'Success'}});
  }
  if(path.endsWith('/transfer-status'))return Response.json({provider:'megah5',result:{Status:200,Description:'Success',Trans:{Amount:provider.statusAmount}}});
  throw new Error(`unexpected path ${path}`);
 };
 const context={db,user:{id:'member',username:'member@example.test',role:'member',approved:1},gatewayUrl,gameToken,walletToken,enabled:'true',liveGamesEnabled:'true',settlementVerified:'true',fetchImpl};
 return {sqlite,db,provider,calls,context,close:()=>sqlite.close()};
}

test('MegaH5 wallet remains off unless the pinned origin and separate credentials are enabled',async()=>{
 const h=harness();try{
  let calls=0;const disabled={...h.context,enabled:'false',fetchImpl:async()=>{calls++;throw new Error('must not call');}};
  assert.equal(megaWalletConfigured(disabled),false);
  assert.equal(megaWalletConfigured({...h.context,walletToken:gameToken}),false);
  assert.equal(megaWalletConfigured({...h.context,gatewayUrl:'https://example.test'}),false);
  assert.equal(megaWalletLiveReady({...h.context,liveGamesEnabled:'false'}),false);
  assert.equal(megaWalletLiveReady({...h.context,settlementVerified:'false'}),false);
  assert.equal(megaWalletLiveReady(h.context),true);
  await assert.rejects(()=>prepareMegaWallet(disabled,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  await assert.rejects(()=>prepareMegaWallet({...h.context,liveGamesEnabled:'false'},'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  await assert.rejects(()=>prepareMegaWallet({...h.context,settlementVerified:'false'},'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  assert.equal(calls,0);
 }finally{h.close();}
});

test('launch transfers the member balance once and reuses the active session',async()=>{
 const h=harness();try{
  const first=await prepareMegaWallet(h.context,'55021'),second=await prepareMegaWallet(h.context,'55021');
  assert.equal(first.walletVerified,true);assert.equal(first.amountOutMinor,'2000');assert.equal(first.reused,false);
  assert.equal(second.sessionId,first.sessionId);assert.equal(second.reused,true);
  await assert.rejects(()=>prepareMegaWallet(h.context,'55022'),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,1);
  assert.equal(h.calls.find(x=>x.path.endsWith('/balance')).authorization,`Bearer ${gameToken}`);
  assert.equal(h.calls.find(x=>x.path.endsWith('/deposit')).authorization,`Bearer ${walletToken}`);
  assert.deepEqual({...h.sqlite.prepare('SELECT kind,amount_minor FROM wallet_reservations WHERE user_id=?').get('member')},{kind:'game',amount_minor:2000});
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'2000',availableMinor:'0',heldMinor:'2000',withdrawalHeldMinor:'0',gameHeldMinor:'2000'});
 }finally{h.close();}
});

test('settlement returns the provider balance and books the game result once',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';
  const settled=await settleMegaWallet(h.context);assert.equal(settled.status,'settled');assert.equal(settled.session.resultMinor,'-450');
  assert.equal((await settleMegaWallet(h.context)).status,'none');
  assert.equal(h.calls.filter(x=>x.path.endsWith('/withdraw')).length,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'1550',availableMinor:'1550',heldMinor:'0',withdrawalHeldMinor:'0',gameHeldMinor:'0'});
 }finally{h.close();}
});

test('review or incomplete deposit journals never become spendable wallet credit',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('review-order','member','review-request','fixture','vpay',9000,'MYR','1','review',0,0)").run();
  h.sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('review-member','review-order','member','member',9000,'MYR',0)").run();
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'2000',availableMinor:'2000',heldMinor:'0',withdrawalHeldMinor:'0',gameHeldMinor:'0'});
  h.sqlite.prepare("UPDATE deposit_orders SET status='credited' WHERE id='review-order'").run();
  assert.equal((await withdrawalWalletState(h.db,'member')).balanceMinor,'2000');
 }finally{h.close();}
});

test('shared reservation prevents a game transfer while a withdrawal owns the wallet',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('pending-withdrawal','member','pending-request-key','vpay','VPay','maybank','Maybank','encrypted-holder','encrypted-account','1234',500,'MYR','pending','',0,0)").run();
  h.sqlite.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','withdrawal','pending-withdrawal',500,0)").run();
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,0);
 }finally{h.close();}
});

test('ambiguous deposit stays held and status recovery never sends a second deposit',async()=>{
 const h=harness();try{
  h.provider.deposit='503';
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'deposit_unknown');
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'0');
  const recovered=await recoverMegaWallet(h.context);assert.equal(recovered.status,'active');
  const reused=await prepareMegaWallet(h.context,'55021');assert.equal(reused.reused,true);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,1);
 }finally{h.close();}
});

test('ambiguous withdrawal recovers to one settlement without another withdrawal',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';h.provider.withdraw='throw';h.provider.statusAmount='15.50';
  await assert.rejects(()=>settleMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===503);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'withdraw_unknown');
  const recovered=await recoverMegaWallet(h.context);assert.equal(recovered.status,'settled');assert.equal(recovered.session.resultMinor,'-450');
  assert.equal((await recoverMegaWallet(h.context)).status,'none');
  assert.equal(h.calls.filter(x=>x.path.endsWith('/withdraw')).length,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,1);
 }finally{h.close();}
});

test('recovery amount mismatch requires manual review and cannot credit the ledger',async()=>{
 const h=harness();try{
  h.provider.deposit='throw';h.provider.statusAmount='19.99';
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  await assert.rejects(()=>recoverMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'manual_review');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,0);
  assert.equal((await withdrawalWalletState(h.db,'member')).gameHeldMinor,'2000');
 }finally{h.close();}
});
