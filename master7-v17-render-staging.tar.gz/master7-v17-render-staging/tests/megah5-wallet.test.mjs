import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {
 MegaWalletError,
 megaWalletConfigured,
 megaWalletCapabilities,
 megaWalletLiveReady,
 prepareMegaWallet,
 recoverMegaWallet,
 settleMegaWallet,
 claimMegaLaunch,
 markMegaLaunchIssued,
 markMegaLaunchUnknown,
} from '../lib/megah5-wallet.ts';
import {megaCapabilityFixture} from './fixtures/megah5-capability.mjs';
import {withdrawalWalletState,clearStaleReservation} from '../lib/withdrawals.ts';
import {walletGuardStatements,walletGuardedReservation} from '../lib/wallet-guard.ts';

const migrations=['0000_broken_bloodscream.sql','0001_orange_owl.sql','0002_lobby_ads.sql','0003_game_visibility.sql','0004_sponsored_brands.sql','0005_custom_game_cards.sql','0006_malaysia_member_phone.sql','0007_vpay_uat_wallet.sql','0008_member_sms_otp.sql','0009_game_payment_statuses.sql','0010_game_visibility_artwork.sql','0011_provider_artwork.sql','0012_close_defaults_and_brand_directory.sql','0013_api_supplier_artwork.sql','0014_withdrawal_requests.sql','0019_game_catalogue_sync.sql','0020_manual_bank_deposits.sql','0021_api_supplier_status.sql','0022_referrals.sql','0023_marketing_campaigns.sql','0024_megah5_transfer_wallet.sql','0025_game_access_zones.sql','0090_security_wallet_reservations.sql','0094_payment_recovery_and_payout_state.sql','0110_game_provider_adapter_core.sql','0111_member_wallet_guards.sql','0112_megah5_launch_operations.sql','0113_game_provider_acceptance_evidence.sql'];
const gatewayUrl='https://master7-integration-gateway.onrender.com';
const gameToken='g'.repeat(48),walletToken='w'.repeat(48);

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function harness(){
 const sqlite=new DatabaseSync(':memory:');
 for(const migration of migrations)sqlite.exec(readFileSync(new URL(`../drizzle/${migration}`,import.meta.url),'utf8'));
 const db={
  prepare:sql=>new Statement(sqlite,sql),
  async batch(list){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const statement of list)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}},
 };
 sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member@example.test','member',1,'csrf',0)").run();
 sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('credit-order','member','credit-request','fixture','manual_bank',2000,'MYR','fixture','credited',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('credit-member','credit-order','member','member',2000,'MYR',0),('credit-clearing','credit-order','member','provider_clearing',-2000,'MYR',0)").run();
 const provider={balance:'0.00',balanceCurrency:'MYR',deposit:'success',withdraw:'success',statusAmount:'20.00',statusCurrency:undefined,statusProvider:'megah5',statusPatch:{},depositEnvelopePatch:{},withdrawEnvelopePatch:{},statusEnvelopePatch:{}};
 const calls=[];
 const fetchImpl=async(url,options)=>{
  const path=new URL(url).pathname;if(path==='/readiness')return Response.json(megaCapabilityFixture());calls.push({path,authorization:options.headers.Authorization,body:JSON.parse(options.body)});
  if(path.endsWith('/balance'))return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:provider.balance,Currency:provider.balanceCurrency}});
  if(path.endsWith('/deposit')){
   if(provider.deposit==='throw')throw new Error('network unavailable');
   if(provider.deposit==='503')return Response.json({error:'upstream_timeout'},{status:503});
   return Response.json({provider:'megah5',operation:'deposit',referenceId:JSON.parse(options.body).referenceId,result:{Status:200,Description:'Success'},...provider.depositEnvelopePatch});
  }
  if(path.endsWith('/withdraw')){
   if(provider.withdraw==='throw')throw new Error('network unavailable');
   if(provider.withdraw==='503')return Response.json({error:'upstream_timeout'},{status:503});
   return Response.json({provider:'megah5',operation:'withdraw',referenceId:JSON.parse(options.body).referenceId,result:{Status:200,Description:'Success'},...provider.withdrawEnvelopePatch});
  }
  if(path.endsWith('/transfer-status'))return Response.json({provider:provider.statusProvider,operation:'transfer_status',result:{Status:200,Description:'Success',Trans:{Amount:provider.statusAmount,Currency:provider.statusCurrency,...provider.statusPatch}},...provider.statusEnvelopePatch});
  throw new Error(`unexpected path ${path}`);
 };
 const context={db,user:{id:'member',username:'member@example.test',role:'member',approved:1},gatewayUrl,gameToken,walletToken,enabled:'true',liveGamesEnabled:'true',newGameLaunchesEnabled:'true',settlementVerified:'true',fetchImpl};
 return {sqlite,db,provider,calls,context,close:()=>sqlite.close()};
}

test('wallet uses real connection capability while legacy flags never attest settlement or block recovery',async()=>{
 const h=harness();try{
  const automatic={...h.context,enabled:'false',liveGamesEnabled:'false',settlementVerified:'false'};
  assert.equal(megaWalletConfigured(automatic),true);
  assert.equal(await megaWalletLiveReady(automatic),true);
  const capability=await megaWalletCapabilities(automatic);assert.equal(capability.walletReady,true);assert.equal(capability.walletVerified,false);assert.equal(capability.launchVerified,false);assert.equal(capability.settlementVerified,false);
  let calls=0;
  for(const extra of [{walletToken:gameToken},{gatewayUrl:'https://example.test'},{gameToken:''},{walletToken:'w'.repeat(1025)}]){
   const invalid={...h.context,...extra,fetchImpl:async()=>{calls++;throw Error('must not call');}};
   assert.equal(megaWalletConfigured(invalid),false);assert.equal(await megaWalletLiveReady(invalid),false);
   await assert.rejects(()=>prepareMegaWallet(invalid,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  }
  assert.equal(calls,0);
  await prepareMegaWallet(automatic,'55021');h.provider.balance='20.00';
  assert.equal((await settleMegaWallet(automatic)).status,'settled');
 }finally{h.close();}
});

test('launch transfers the member balance once and reuses the active session',async()=>{
 const h=harness();try{
  const first=await prepareMegaWallet(h.context,'55021'),second=await prepareMegaWallet(h.context,'55021');
  assert.equal(first.walletVerified,true);assert.equal(first.amountOutMinor,'2000');assert.equal(first.reused,false);
  assert.equal(second.sessionId,first.sessionId);assert.equal(second.reused,true);
  await assert.rejects(()=>prepareMegaWallet(h.context,'55022'),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,1);
  assert.equal(h.calls.find(x=>x.path.endsWith('/balance')).authorization,`Bearer ${gameToken}`);
  assert.equal(h.calls.find(x=>x.path.endsWith('/deposit')).authorization,`Bearer ${walletToken}`);
  assert.deepEqual({...h.sqlite.prepare('SELECT kind,amount_minor FROM wallet_reservations WHERE user_id=?').get('member')},{kind:'game',amount_minor:2000});
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'2000',availableMinor:'0',heldMinor:'2000',withdrawalHeldMinor:'0',gameHeldMinor:'2000'});
 }finally{h.close();}
});

test('settlement returns the provider balance and books the game result once',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';
  const settled=await settleMegaWallet(h.context);assert.equal(settled.status,'settled');assert.equal(settled.session.resultMinor,'-450');
  assert.equal((await settleMegaWallet(h.context)).status,'none');
  assert.equal(h.calls.filter(x=>x.path.endsWith('/withdraw')).length,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'1550',availableMinor:'1550',heldMinor:'0',withdrawalHeldMinor:'0',gameHeldMinor:'0'});
 }finally{h.close();}
});

test('review or incomplete deposit journals never become spendable wallet credit',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('review-order','member','review-request','fixture','vpay',9000,'MYR','1','review',0,0)").run();
  h.sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('review-member','review-order','member','member',9000,'MYR',0)").run();
  assert.deepEqual(await withdrawalWalletState(h.db,'member'),{balanceMinor:'2000',availableMinor:'0',heldMinor:'0',withdrawalHeldMinor:'0',gameHeldMinor:'0',reconciliationRequired:true});
  h.sqlite.prepare("UPDATE deposit_orders SET status='credited' WHERE id='review-order'").run();
  assert.equal((await withdrawalWalletState(h.db,'member')).balanceMinor,'2000');
 }finally{h.close();}
});

test('shared reservation prevents a game transfer while a withdrawal owns the wallet',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('pending-withdrawal','member','pending-request-key','vpay','VPay','maybank','Maybank','encrypted-holder','encrypted-account','1234',500,'MYR','pending','',0,0)").run();
  h.sqlite.prepare("INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at) VALUES('member','withdrawal','pending-withdrawal',500,0)").run();
  const frozen=await withdrawalWalletState(h.db,'member');assert.equal(frozen.reconciliationRequired,true);assert.equal(frozen.availableMinor,'0');
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409&&/reconciliation/i.test(error.message));
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,0);
 }finally{h.close();}
});

test('an explicitly non-MYR provider balance cannot start or settle a wallet transfer',async()=>{
 const h=harness();try{
  h.provider.balanceCurrency='USD';
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,0);
  h.provider.balanceCurrency='MYR';await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';h.provider.balanceCurrency='USD';
  await assert.rejects(()=>settleMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'active');
  assert.equal(h.calls.filter(x=>x.path.endsWith('/withdraw')).length,0);
 }finally{h.close();}
});

test('an explicitly non-MYR transfer recovery stays held for manual review',async()=>{
 const h=harness();try{
  h.provider.deposit='throw';h.provider.statusCurrency='USD';
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  await assert.rejects(()=>recoverMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'manual_review');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,0);
  assert.equal((await withdrawalWalletState(h.db,'member')).gameHeldMinor,'2000');
 }finally{h.close();}
});

test('recovery cannot accept another provider, member, transfer reference or transfer type',async t=>{
 for(const [name,patch] of [['provider',{statusProvider:'other'}],['player',{statusPatch:{PlayerId:'different'}}],['reference',{statusPatch:{ReferenceId:'different'}}],['type',{statusPatch:{TransferType:2}}]])await t.test(name,async()=>{
  const h=harness();try{
   h.provider.deposit='throw';Object.assign(h.provider,patch);
   await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
   await assert.rejects(()=>recoverMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
   assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'manual_review');
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,0);
   assert.equal((await withdrawalWalletState(h.db,'member')).gameHeldMinor,'2000');
   assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,1);
  }finally{h.close();}
 });
});

test('recovery accepts matching provider-supplied transaction identifiers',async()=>{
 const h=harness();try{
  h.provider.deposit='throw';
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  const session=h.sqlite.prepare('SELECT player_id,deposit_reference FROM game_wallet_sessions').get();
  h.provider.statusPatch={PlayerId:session.player_id,ReferenceId:session.deposit_reference,TransferType:'1'};
  assert.equal((await recoverMegaWallet(h.context)).status,'active');
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,1);
 }finally{h.close();}
});

test('ambiguous deposit stays held and status recovery never sends a second deposit',async()=>{
 const h=harness();try{
  h.provider.deposit='503';
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'deposit_unknown');
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'0');
  const recovered=await recoverMegaWallet(h.context);assert.equal(recovered.status,'active');
  const reused=await prepareMegaWallet(h.context,'55021');assert.equal(reused.reused,true);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,1);
 }finally{h.close();}
});

test('ambiguous withdrawal recovers to one settlement without another withdrawal',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';h.provider.withdraw='throw';h.provider.statusAmount='15.50';
  await assert.rejects(()=>settleMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===503);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'withdraw_unknown');
  const recovered=await recoverMegaWallet(h.context);assert.equal(recovered.status,'settled');assert.equal(recovered.session.resultMinor,'-450');
  assert.equal((await recoverMegaWallet(h.context)).status,'none');
  assert.equal(h.calls.filter(x=>x.path.endsWith('/withdraw')).length,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,1);
 }finally{h.close();}
});

test('recovery amount mismatch requires manual review and cannot credit the ledger',async()=>{
 const h=harness();try{
  h.provider.deposit='throw';h.provider.statusAmount='19.99';
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
  await assert.rejects(()=>recoverMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'manual_review');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,0);
  assert.equal((await withdrawalWalletState(h.db,'member')).gameHeldMinor,'2000');
 }finally{h.close();}
});

function pauseRequest(context,suffix){
 let release,started;
 const wait=new Promise(resolve=>{release=resolve;}),ready=new Promise(resolve=>{started=resolve;}),original=context.fetchImpl;
 context.fetchImpl=async(url,options)=>{if(new URL(url).pathname.endsWith(suffix)){started();await wait;}return original(url,options);};
 return {ready,release};
}

function insertPayoutReview(h){
 h.sqlite.prepare("INSERT INTO withdrawal_requests(id,user_id,request_key,provider_id,provider_name,bank_code,bank_name,account_holder_encrypted,account_number_encrypted,account_last4,amount_minor,currency,status,owner_note,created_at,updated_at) VALUES('old-payout','member','old-payout-key','vpay','VPay','maybank','Maybank','holder','account','1234',100,'MYR','paid','',0,0)").run();
 h.sqlite.prepare("INSERT INTO provider_payouts(id,withdrawal_id,provider_id,request_key,fingerprint,amount_minor,currency,status,create_outcome,provider_reference,last_error_code,created_at,updated_at) VALUES('P7oldpayout','old-payout','vpay','old-payout-key','fixture',100,'MYR','review','accepted','P7oldpayout','conflict',0,0)").run();
}

test('new payout review after the wallet read prevents a game transfer',async()=>{
 const h=harness();try{
  const original=h.db.batch;let injected=false;
  h.db.batch=async list=>{if(!injected&&list.some(x=>x.sql.includes('WITH member AS')&&x.sql.includes('INSERT INTO wallet_reservations'))){injected=true;insertPayoutReview(h);}return original(list);};
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(injected,true);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
  assert.equal(h.sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE kind='game'").get().n,0);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,0);
 }finally{h.close();}
});

test('game transfer retries if the available balance increases after the snapshot',async()=>{
 const h=harness();try{
  const original=h.db.batch;let injected=false;
  h.db.batch=async list=>{if(!injected&&list.some(x=>x.sql.includes('WITH member AS')&&x.sql.includes('INSERT INTO wallet_reservations'))){
   injected=true;h.sqlite.exec("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('extra-credit','member','extra-credit-key','fixture','manual_bank',500,'MYR','fixture','credited',0,0); INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('extra-member','extra-credit','member','member',500,'MYR',0),('extra-clearing','extra-credit','member','provider_clearing',-500,'MYR',0)");
  }return original(list);};
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409);
  assert.equal(injected,true);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,0);
 }finally{h.close();}
});

test('a zero-balance wallet cannot launch an untracked game session',async()=>{
 const h=harness();try{
  h.sqlite.exec("DELETE FROM wallet_ledger; DELETE FROM deposit_orders;");
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409&&error.message==='Add funds to your wallet before starting this game');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,0);
 }finally{h.close();}
});

test('a deposit arriving after a zero-balance snapshot cannot open an untracked game',async()=>{
 const h=harness();try{
  h.sqlite.exec("DELETE FROM wallet_ledger; DELETE FROM deposit_orders;");
  const prepare=h.db.prepare.bind(h.db);let injected=false;
  h.db.prepare=sql=>{
   const statement=prepare(sql);
   if(sql.includes('SELECT w.id FROM withdrawal_requests w LEFT JOIN provider_payouts')){
    const bind=statement.bind.bind(statement);statement.bind=(...args)=>{
     const bound=bind(...args),first=bound.first.bind(bound);bound.first=async()=>{
      const value=await first();if(!injected){injected=true;h.sqlite.exec("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('late-credit','member','late-credit-key','fixture','manual_bank',2000,'MYR','fixture','credited',0,0); INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('late-member','late-credit','member','member',2000,'MYR',0),('late-clearing','late-credit','member','provider_clearing',-2000,'MYR',0)");}return value;
     };return bound;
    };
   }
   return statement;
  };
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409&&error.message==='Add funds to your wallet before starting this game');
  assert.equal(injected,true);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/deposit')).length,0);
 }finally{h.close();}
});

test('a reviewed payout blocks reopening an active game but does not block settlement',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');insertPayoutReview(h);
  await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===409);
  h.provider.balance='15.50';assert.equal((await settleMegaWallet(h.context)).status,'settled');
  assert.equal((await withdrawalWalletState(h.db,'member')).reconciliationRequired,true);
 }finally{h.close();}
});

test('unconfirmed recovery during an in-flight withdrawal cannot claim settlement or release its reservation',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';h.provider.statusProvider='other';
  const gate=pauseRequest(h.context,'/withdraw'),pending=settleMegaWallet(h.context).then(value=>({value}),error=>({error}));
  await gate.ready;
  await assert.rejects(()=>recoverMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
  gate.release();const result=await pending;assert.equal(result.error?.status,409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'manual_review');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,1);
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'0');
 }finally{h.close();}
});

test('late unconfirmed recovery cannot change an already settled session or freeze its balance',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';h.provider.statusProvider='other';
  const withdrawal=pauseRequest(h.context,'/withdraw'),pending=settleMegaWallet(h.context);
  await withdrawal.ready;
  const query=pauseRequest(h.context,'/transfer-status'),recovery=recoverMegaWallet(h.context).then(value=>({value}),error=>({error}));
  await query.ready;withdrawal.release();assert.equal((await pending).status,'settled');
  query.release();assert.equal((await recovery).error?.status,409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'settled');
  assert.equal(h.sqlite.prepare("SELECT COUNT(*) count FROM audit WHERE event='megah5_recovery_unconfirmed'").get().count,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_ledger').get().count,1);
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'1550');
 }finally{h.close();}
});

test('a conflicting existing game result never finalizes or releases the reservation',async()=>{
 const h=harness();try{
  await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';
  const gate=pauseRequest(h.context,'/withdraw'),pending=settleMegaWallet(h.context).then(value=>({value}),error=>({error}));
  await gate.ready;
  h.sqlite.prepare("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) SELECT 'conflicting',id,user_id,'game_result',999,'MYR',0 FROM game_wallet_sessions").run();
  gate.release();assert.equal((await pending).error?.status,409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'withdraw_pending');
  assert.equal(h.sqlite.prepare('SELECT amount_minor FROM game_wallet_ledger').get().amount_minor,999);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,1);
  const wallet=await withdrawalWalletState(h.db,'member');assert.equal(wallet.balanceMinor,'2000');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
 }finally{h.close();}
});

test('unconfirmed recovery during an in-flight deposit cannot report a launch-ready wallet',async()=>{
 const h=harness();try{
  h.provider.statusProvider='other';const gate=pauseRequest(h.context,'/deposit');
  const pending=prepareMegaWallet(h.context,'55021').then(value=>({value}),error=>({error}));
  await gate.ready;await assert.rejects(()=>recoverMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
  gate.release();assert.equal((await pending).error?.status,409);
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'manual_review');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,1);
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'0');
 }finally{h.close();}
});


test('transfer success must echo the gateway operation and reference before moving money',async t=>{
 const patches=[['missing operation',{operation:undefined}],['wrong operation',{operation:'transfer_status'}],['missing reference',{referenceId:undefined}],['wrong reference',{referenceId:'different-reference'}]];
 for(const [label,patch] of patches){
  await t.test(`deposit: ${label}`,async()=>{
   const h=harness();try{
    h.provider.depositEnvelopePatch=patch;
    await assert.rejects(()=>prepareMegaWallet(h.context,'55021'),error=>error instanceof MegaWalletError&&error.status===503);
    assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'deposit_unknown');
    assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
    assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);
    const recovered=await recoverMegaWallet(h.context);assert.equal(recovered.status,'active');
    assert.equal(h.calls.filter(call=>call.path.endsWith('/deposit')).length,1);
   }finally{h.close();}
  });
  await t.test(`withdrawal: ${label}`,async()=>{
   const h=harness();try{
    await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';h.provider.statusAmount='15.50';h.provider.withdrawEnvelopePatch=patch;
    await assert.rejects(()=>settleMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===503);
    assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'withdraw_unknown');
    assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
    assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);
    const recovered=await recoverMegaWallet(h.context);assert.equal(recovered.status,'settled');assert.equal(recovered.session.resultMinor,'-450');
    assert.equal(h.calls.filter(call=>call.path.endsWith('/withdraw')).length,1);
   }finally{h.close();}
  });
 }
});

test('status recovery rejects a missing or incorrect gateway operation',async t=>{
 for(const [label,operation] of [['missing',undefined],['wrong','withdraw']])await t.test(label,async()=>{
  const h=harness();try{
   h.provider.deposit='throw';await assert.rejects(()=>prepareMegaWallet(h.context,'55021'));h.provider.statusEnvelopePatch={operation};
   await assert.rejects(()=>recoverMegaWallet(h.context),error=>error instanceof MegaWalletError&&error.status===409);
   assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'manual_review');
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);
  }finally{h.close();}
 });
});

test('a durable launch claim blocks settlement during launch and after an issued URL',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021'),attempt=await claimMegaLaunch(h.context,prepared.sessionId,'55021');
  assert.equal(h.sqlite.prepare('SELECT state FROM megah5_launch_operations WHERE id=?').get(attempt.id).state,'launching');
  await assert.rejects(()=>claimMegaLaunch(h.context,prepared.sessionId,'55021'),e=>e instanceof MegaWalletError&&e.status===409);
  await assert.rejects(()=>settleMegaWallet(h.context,prepared.sessionId),e=>e instanceof MegaWalletError&&e.status===409);
  await markMegaLaunchIssued(h.context,attempt.id,prepared.sessionId);
  const displayed=await (await import('../lib/megah5-wallet.ts')).memberMegaWalletState(h.context);
  assert.equal(displayed.session.launchState,'issued');assert.equal(displayed.session.settlementBlocked,true);
  await assert.rejects(()=>settleMegaWallet(h.context,prepared.sessionId),e=>e instanceof MegaWalletError&&e.status===409);
  await markMegaLaunchUnknown(h.context,attempt.id,prepared.sessionId);
  assert.equal(h.sqlite.prepare('SELECT state FROM megah5_launch_operations WHERE id=?').get(attempt.id).state,'issued');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
  assert.equal(h.calls.filter(x=>x.path.endsWith('/withdraw')).length,0);
 }finally{h.close();}
});

test('unknown launch stays held after restart and old timestamps do not expire it',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021'),attempt=await claimMegaLaunch(h.context,prepared.sessionId,'55021');
  await markMegaLaunchUnknown(h.context,attempt.id,prepared.sessionId);
  h.sqlite.prepare('UPDATE megah5_launch_operations SET created_at=0,updated_at=0 WHERE id=?').run(attempt.id);
  const restarted={...h.context};
  await assert.rejects(()=>markMegaLaunchIssued(restarted,attempt.id,prepared.sessionId),e=>e instanceof MegaWalletError&&e.status===409);
  await assert.rejects(()=>claimMegaLaunch(restarted,prepared.sessionId,'55021'),e=>e instanceof MegaWalletError&&e.status===409);
  await assert.rejects(()=>settleMegaWallet(restarted,prepared.sessionId),e=>e instanceof MegaWalletError&&e.status===409);
  assert.equal(h.sqlite.prepare('SELECT state FROM megah5_launch_operations WHERE id=?').get(attempt.id).state,'unknown');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
 }finally{h.close();}
});

test('claim after a settlement balance read prevents withdrawal when launch wins',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';
  const gate=pauseRequest(h.context,'/balance'),pending=settleMegaWallet(h.context,prepared.sessionId).then(value=>({value}),error=>({error}));
  await gate.ready;const attempt=await claimMegaLaunch(h.context,prepared.sessionId,'55021');gate.release();
  assert.equal((await pending).error?.status,409);assert.equal(h.sqlite.prepare('SELECT state FROM megah5_launch_operations WHERE id=?').get(attempt.id).state,'launching');
  assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions WHERE id=?').get(prepared.sessionId).status,'active');
  assert.equal(h.calls.filter(x=>x.path.endsWith('/withdraw')).length,0);
 }finally{h.close();}
});

test('a settlement that has already claimed withdrawal blocks a later launch',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';
  const gate=pauseRequest(h.context,'/withdraw'),pending=settleMegaWallet(h.context,prepared.sessionId);await gate.ready;
  await assert.rejects(()=>claimMegaLaunch(h.context,prepared.sessionId,'55021'),e=>e instanceof MegaWalletError&&e.status===409);
  gate.release();assert.equal((await pending).status,'settled');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM megah5_launch_operations').get().n,0);
 }finally{h.close();}
});

test('claim fails closed for wrong session, game, or member risk without starting an operation',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021');
  await assert.rejects(()=>claimMegaLaunch(h.context,'wrong-session','55021'),e=>e instanceof MegaWalletError&&e.status===409);
  await assert.rejects(()=>claimMegaLaunch(h.context,prepared.sessionId,'55022'),e=>e instanceof MegaWalletError&&e.status===409);
  h.sqlite.prepare("UPDATE deposit_orders SET status='review' WHERE id='credit-order'").run();
  await assert.rejects(()=>claimMegaLaunch(h.context,prepared.sessionId,'55021'),e=>e instanceof MegaWalletError&&e.status===409);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM megah5_launch_operations').get().n,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
 }finally{h.close();}
});

test('recovery refuses an unresolved launch before contacting the provider',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021'),attempt=await claimMegaLaunch(h.context,prepared.sessionId,'55021');
  await markMegaLaunchUnknown(h.context,attempt.id,prepared.sessionId);
  for(const status of ['active','withdraw_pending','withdraw_unknown','deposit_unknown']){
   h.sqlite.prepare("UPDATE game_wallet_sessions SET status=?,withdraw_reference='fixture-withdraw',expected_return_minor=2000 WHERE id=?").run(status,prepared.sessionId);
   const before=h.calls.length;
   await assert.rejects(()=>recoverMegaWallet(h.context,prepared.sessionId),e=>e instanceof MegaWalletError&&e.status===409&&/closure requires reconciliation/.test(e.message));
   assert.equal(h.calls.length,before);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
  }
 }finally{h.close();}
});

test('finalization cannot post or release a wallet if a conflicting launch marker appears in flight',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021');h.provider.balance='15.50';
  const gate=pauseRequest(h.context,'/withdraw'),pending=settleMegaWallet(h.context,prepared.sessionId).then(value=>({value}),error=>({error}));await gate.ready;
  h.sqlite.prepare("INSERT INTO megah5_launch_operations(id,wallet_session_id,user_id,game_code,state,created_at,updated_at) VALUES('fixture-operation',?,'member','55021','unknown',0,0)").run(prepared.sessionId);
  gate.release();assert.equal((await pending).error?.status,409);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
  assert.equal((await withdrawalWalletState(h.db,'member')).reconciliationRequired,true);
 }finally{h.close();}
});

test('an unresolved launch with an inconsistent settled wallet cannot free or expose funds',async()=>{
 const h=harness();try{
  const prepared=await prepareMegaWallet(h.context,'55021'),attempt=await claimMegaLaunch(h.context,prepared.sessionId,'55021');await markMegaLaunchIssued(h.context,attempt.id,prepared.sessionId);
  h.sqlite.prepare("UPDATE game_wallet_sessions SET status='settled',amount_returned_minor=3000 WHERE id=?").run(prepared.sessionId);
  h.sqlite.prepare("INSERT INTO game_wallet_ledger(id,session_id,user_id,account_code,amount_minor,currency,created_at) VALUES('fixture-result',?,'member','game_result',1000,'MYR',0)").run(prepared.sessionId);
  let wallet=await withdrawalWalletState(h.db,'member');assert.equal(wallet.reconciliationRequired,true);assert.equal(wallet.availableMinor,'0');
  await clearStaleReservation(h.db,'member');assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,1);
  h.sqlite.prepare("DELETE FROM wallet_reservations WHERE user_id='member'").run();
  wallet=await withdrawalWalletState(h.db,'member');assert.equal(wallet.reconciliationRequired,true);assert.equal(wallet.availableMinor,'0');
  const results=await h.db.batch([...walletGuardStatements(h.db,'member'),walletGuardedReservation(h.db,{userId:'member',kind:'withdrawal',referenceId:'another-withdrawal',amountMinor:'100',createdAt:0})]);
  assert.equal(Number(results[2].changes??results[2].meta?.changes),0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});
