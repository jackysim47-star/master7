import test from 'node:test';
import assert from 'node:assert/strict';
import {handleVPay,vpayOrdersConfigured} from '../lib/vpay.ts';

const staging='https://master7-v17-staging.onrender.com';
const gateway='https://master7-payment-uat.onrender.com';
const legacy='https://master7-integration-gateway.onrender.com';
function fixture(patch={},remotePatch={}){
  const requests=[];
  const c={user:null,db:{prepare(){return {bind(){return {first:async()=>({status:'paused'})};}};}},
    gatewayUrl:gateway,mode:'uat',portalOrigins:[staging],returnUrl:staging+'/payment/return',
    orderToken:'o'.repeat(48),queryToken:'q'.repeat(48),callbackToken:'c'.repeat(48),
    vpayTraderId:'1234',enabled:'false',newDepositsEnabled:'false',recoveryEnabled:'false',
    fetchImpl:async(input,init)=>{
      requests.push(String(input));
      assert.equal(String(input),c.gatewayUrl+'/platform/vpay/config');
      assert.equal(init.redirect,'error');
      assert.equal(init.headers.Authorization,'Bearer '+c.queryToken);
      return Response.json({provider:'vpay',mode:c.mode,traderId:c.vpayTraderId,
        paymentReady:false,queryReady:true,callbacksReady:true,tradeCodes:['2'],
        notifyUrl:c.gatewayUrl+'/callbacks/vpay/payment',returnUrl:c.returnUrl,...remotePatch});
    },...patch};
  return {c,requests,async status(){return (await handleVPay(new Request(staging+'/api/payments/vpay/status'),c)).json();}};
}
test('isolated UAT uses its exact gateway while maintenance remains independent of closed orders',async()=>{
  const f=fixture(),s=await f.status();
  assert.equal(s.programReady,true);assert.equal(s.queryReady,true);assert.equal(s.callbacksReady,true);
  assert.equal(s.orderReady,false);assert.equal(s.recoveryReady,false);assert.equal(s.payoutReady,false);
  assert.equal(s.realPaymentVerified,false);assert.equal(s.settlementVerified,false);assert.equal(s.liveReady,false);
  assert.deepEqual(f.requests,[gateway+'/platform/vpay/config']);
});
for(const [name,patch] of [
  ['production mode',{mode:'production'}],
  ['production portal',{portalOrigins:['https://www.master7.best']}],
  ['mixed origins',{portalOrigins:[staging,'https://www.master7.best']}],
  ['empty origins',{portalOrigins:[]}],
  ['production return',{returnUrl:'https://www.master7.best/payment/return'}],
  ['arbitrary host',{gatewayUrl:'https://attacker.example'}],
  ['prefix host',{gatewayUrl:gateway+'.attacker.example'}],
  ['userinfo',{gatewayUrl:'https://attacker@master7-payment-uat.onrender.com'}],
  ['port',{gatewayUrl:gateway+':443'}],
  ['path',{gatewayUrl:gateway+'/api'}],
  ['aliased credentials',{callbackToken:'q'.repeat(48)}],
])test('UAT isolation fails closed before network access: '+name,async()=>{
  const f=fixture(patch),s=await f.status();assert.equal(vpayOrdersConfigured(f.c),false);
  assert.equal(s.programReady,false);assert.equal(s.orderReady,false);assert.deepEqual(f.requests,[]);
});
for(const [field,value] of [['mode','production'],['traderId','other'],
  ['notifyUrl',legacy+'/callbacks/vpay/payment'],['returnUrl','https://www.master7.best/payment/return']])
  test('UAT rejects a remote contract mismatch: '+field,async()=>{
    const s=await fixture({}, {[field]:value}).status();
    assert.equal(s.queryReady,false);assert.equal(s.callbacksReady,false);assert.equal(s.orderReady,false);
  });
test('legacy production gateway remains backwards compatible',async()=>{
  const s=await fixture({gatewayUrl:legacy,mode:'production',portalOrigins:['https://www.master7.best'],returnUrl:'https://www.master7.best/payment/return'}).status();
  assert.equal(s.programReady,true);assert.equal(s.queryReady,true);assert.equal(s.callbacksReady,true);
  assert.equal(s.orderReady,false);
});
