import assert from 'node:assert/strict';
import test from 'node:test';
import {GET} from '../app/admin/admin/route.ts';

test('duplicated backoffice path redirects to the canonical admin route',()=>{
 const response=GET(new Request('https://master7-v17-staging.onrender.com/admin/admin?lang=zh'));
 assert.equal(response.status,302);
 assert.equal(response.headers.get('location'),'/admin?lang=zh');
 assert.equal(response.headers.get('cache-control'),'no-store');
});
