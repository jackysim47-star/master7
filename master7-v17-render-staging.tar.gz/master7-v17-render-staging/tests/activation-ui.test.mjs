import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createContext,runInContext} from 'node:vm';

const fullSource=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const source=fullSource.split('(async function start(){')[0];
function fixture(options,initialPath='/activate'){
 const elements=new Map(),requests=[];let path=initialPath;
 const get=id=>{if(!elements.has(id))elements.set(id,{value:'',textContent:'',hidden:false,open:false,handlers:{},attributes:{},classList:{toggle(){}},addEventListener(name,fn){this.handlers[name]=fn;},setAttribute(name,value){this.attributes[name]=String(value);this[name]=String(value);},getAttribute(name){return this.attributes[name]??null;},showModal(){this.open=true;},reset(){for(const x of elements.values())x.value='';}});return elements.get(id);};
 const context=createContext({document:{getElementById:get,querySelectorAll(){return[];}},window:{scrollTo(){}},location:{get pathname(){return path;}},history:{replaceState(a,b,value){path=value;}},options,requests});
 runInContext(source,context);
 runInContext('api=async(url,method="GET")=>{requests.push({url,method});if(options instanceof Error)throw options;return options;}',context);
 return {context,get,requests,path:()=>path,run:code=>runInContext(code,context)};
}
test('direct registration route asks for member ID, password, Malaysian phone and OTP',async()=>{
 const f=fixture({ownerSetupComplete:true},'/register');
 f.run('bind=bindPasswordAuth=bindPaymentPreview=bindBonusBrandPreview=applyLang=renderSession=renderAdmin=()=>{};refreshSession=loadPublic=refreshTickets=async()=>{};');
 await f.run(fullSource.slice(source.length));
 assert.equal(f.path(),'/register');assert.equal(f.run('state.authMode'),'register');
 assert.equal(f.get('phoneField').hidden,false);assert.equal(f.get('memberPhone').required,true);
 assert.equal(f.get('authUsername').required,true);assert.equal(f.get('otpFields').hidden,false);assert.equal(f.get('memberOtp').required,true);
 assert.equal(f.get('passwordField').hidden,false);assert.equal(f.get('authPassword').required,true);assert.equal(f.get('authPassword').minLength,6);assert.equal(f.get('confirmPassword').required,true);
});
test('management sign-in keeps member registration hidden and requires no mobile number',()=>{
 const f=fixture({},'/admin');
 f.run('showAuth("login")');
 assert.equal(f.get('registerToggle').hidden,true);
 assert.equal(f.get('phoneField').hidden,true);
 assert.equal(f.get('memberPhone').required,false);
 assert.equal(f.get('ownerResetLink').hidden,false);
});
test('owner and staff password changes require twelve characters while member changes retain six',()=>{
 for(const role of ['owner','staff']){
  const f=fixture({},'/admin');f.run(`state.user={id:"${role}",username:"${role}",role:"${role}"};showAuth("security")`);
  assert.equal(f.get('authPassword').minLength,12);
  assert.match(f.get('passwordLabel').textContent,/12/);
 }
 const member=fixture({},'/signin');member.run('state.user={id:"member",username:"member",role:"member"};showAuth("security")');
 assert.equal(member.get('authPassword').minLength,6);
 assert.match(member.get('passwordLabel').textContent,/6/);
});
test('used activation link opens sign-in without submitting credentials',async()=>{
 const f=fixture({ownerSetupComplete:true,ownerSetupAvailable:false});
 f.get('authPassword').value='discard this stale value';
 await f.run('openActivation()');
 assert.equal(f.run('state.authMode'),'login');assert.equal(f.path(),'/admin');
 assert.equal(f.get('memberPhone').required,false);assert.equal(f.get('registerToggle').hidden,true);
 assert.equal(f.get('authPassword').value,'');assert.equal(f.get('activationField').hidden,true);
 assert.match(f.get('authFeedback').textContent,/already activated/i);
 assert.deepEqual(f.requests.map(r=>r.method),['GET']);
});
test('unused valid activation stays available; unavailable activation is not called complete',async()=>{
 const available=fixture({ownerSetupComplete:false,ownerSetupAvailable:true});await available.run('openActivation()');
 assert.equal(available.run('state.authMode'),'activate');assert.equal(available.get('activationField').hidden,false);assert.equal(available.get('authPassword').minLength,12);
 const expired=fixture({ownerSetupComplete:false,ownerSetupAvailable:false});await expired.run('openActivation()');
 assert.equal(expired.run('state.authMode'),'login');assert.match(expired.get('authFeedback').textContent,/No activation code/i);
 assert.doesNotMatch(expired.get('authFeedback').textContent,/already activated/i);
});
test('failed status check does not infer activation or send a write',async()=>{
 const f=fixture({});f.run('api=async()=>{throw new Error("Service unavailable")}');await f.run('openActivation()');
 assert.equal(f.run('state.authMode'),'login');assert.equal(f.get('authFeedback').textContent,'Service unavailable');
 assert.equal(f.get('activationField').hidden,true);
});
test('full startup retains the activation message at management sign-in',async()=>{
 const f=fixture({ownerSetupComplete:true,ownerSetupAvailable:false});
 f.run('bind=bindPasswordAuth=bindPaymentPreview=bindBonusBrandPreview=applyLang=renderSession=renderAdmin=()=>{};refreshSession=loadPublic=refreshTickets=async()=>{};');
 await f.run(fullSource.slice(source.length));
 assert.equal(f.path(),'/admin');assert.match(f.get('authFeedback').textContent,/already activated/i);
 assert.equal(f.get('authUsername').value,'master7_owner');
});
test('stale activation form clears passwords and switches only after confirmed completion',async()=>{
 for(const complete of [true,false]){
  const f=fixture({ownerSetupComplete:complete});
  f.run('bindPasswordAuth();showAuth("activate");api=async(url,method="GET")=>{requests.push({url,method});if(method==="POST"){const e=new Error("Activation conflict");e.status=409;throw e;}return options;}');
  f.get('authPassword').value=f.get('confirmPassword').value='Synthetic password only 2026';
  f.get('activationCode').value='synthetic code';
  await f.get('passwordForm').handlers.submit({preventDefault(){}});
  assert.equal(f.run('state.authMode'),complete?'login':'activate');
  assert.equal(f.get('authSubmit').disabled,false);
  assert.deepEqual(f.requests.map(r=>r.method),['POST','GET']);
  if(complete){assert.equal(f.get('authPassword').value,'');assert.equal(f.get('activationCode').value,'');}
  else assert.equal(f.get('authFeedback').textContent,'Activation conflict');
 }
});
test('reset requires matching passwords and returns to sign-in without automatically logging in',async()=>{
 const f=fixture({});f.run('bindPasswordAuth();showAuth("reset");renderSession=renderTickets=()=>{};api=async(url,method,data)=>{requests.push({url,method,data});return {username:"renamed_owner"};};');
 assert.equal(f.get('usernameField').hidden,true);assert.equal(f.get('authUsername').required,false);assert.equal(f.get('activationCode').required,true);
 assert.equal(f.get('ownerResetLink').hidden,true);assert.equal(f.get('authPassword').type,'password');assert.equal(f.get('authPassword').minLength,12);
 f.get('authPassword').value='Synthetic recovery password 2026';f.get('confirmPassword').value='different';
 await f.get('passwordForm').handlers.submit({preventDefault(){}});assert.equal(f.requests.length,0);
 f.get('confirmPassword').value=f.get('authPassword').value;f.get('confirmPassword').handlers.input();assert.match(f.get('passwordMatch').textContent,/passwords match/i);
 f.get('showPasswords').checked=true;f.get('showPasswords').onchange();assert.equal(f.get('authPassword').type,'text');
 f.get('activationCode').value='synthetic reset code';
 await f.get('passwordForm').handlers.submit({preventDefault(){}});
 assert.equal(f.requests.length,1);assert.equal(f.requests[0].url,'/api/auth/reset-owner');assert.deepEqual(Object.keys(f.requests[0].data).sort(),['code','password']);
 assert.equal(f.run('state.authMode'),'login');assert.equal(f.path(),'/admin');assert.equal(f.get('authUsername').value,'renamed_owner');
 assert.equal(f.get('memberPhone').required,false);assert.equal(f.get('phoneField').hidden,true);
 assert.equal(f.get('authPassword').value,'');assert.equal(f.get('activationCode').value,'');assert.equal(f.get('authPassword').type,'password');assert.match(f.get('authFeedback').textContent,/Password reset/i);
});

test('owner reset checks availability without writing or claiming reset success',async()=>{
 for(const available of [true,false]){
  const f=fixture({ownerResetAvailable:available});
  await f.run('openOwnerReset()');
  assert.equal(f.run('state.authMode'),available?'reset':'login');
  assert.deepEqual(f.requests.map(r=>r.method),['GET']);
  if(!available){assert.match(f.get('authFeedback').textContent,/No active owner reset code/i);assert.equal(f.path(),'/admin');assert.equal(f.get('memberPhone').required,false);}
 }
 const f=fixture({},'/reset-owner');f.run('api=async()=>{throw new Error("Service unavailable")}');
 await f.run('openOwnerReset()');assert.equal(f.run('state.authMode'),'login');
 assert.equal(f.path(),'/admin');assert.equal(f.get('memberPhone').required,false);
 assert.equal(f.get('authUsername').value,'');
 assert.equal(f.get('authFeedback').textContent,'Service unavailable');
});
test('a 200 management login without a verified session cannot close the form or enter admin',async()=>{
 const f=fixture({},'/admin');f.run('bindPasswordAuth();showAuth();refreshSession=async()=>{state.user=null};');
 f.get('authUsername').value='master7_owner';f.get('authPassword').value='synthetic only';
 await f.get('passwordForm').handlers.submit({preventDefault(){}});
 assert.equal(f.get('authDialog').open,true);
 assert.match(f.get('authFeedback').textContent,/did not establish a valid session/i);
 assert.equal(f.get('authSubmit').disabled,false);assert.equal(f.path(),'/admin');
});
test('password logout only navigates after the server has revoked its session',async()=>{
 const f=fixture({});f.run('bindPasswordAuth();state.authMethod="password";location.replace=url=>requests.push({navigation:url});');
 await f.get('logoutButton').onclick({preventDefault(){}});
 assert.deepEqual(f.requests.map(r=>r.url||r.navigation),['/api/auth/logout','/admin']);
 const member=fixture({});member.run('bindPasswordAuth();state.authMethod="password";state.user={role:"member"};location.replace=url=>requests.push({navigation:url});');
 await member.get('logoutButton').onclick({preventDefault(){}});
 assert.deepEqual(member.requests.map(r=>r.url||r.navigation),['/api/auth/logout','/signin']);
 const failed=fixture({});failed.run('bindPasswordAuth();state.authMethod="password";api=async()=>{throw new Error("Service unavailable")};notification=()=>{};location.replace=url=>requests.push({navigation:url});');
 await failed.get('logoutButton').onclick({preventDefault(){}});assert.equal(failed.requests.length,0);
});

test('successful activation returns to management login without requesting a phone or authenticating',async()=>{
 const f=fixture({},'/activate');f.run('bindPasswordAuth();showAuth("activate");api=async(url,method,data)=>{requests.push({url,method,data});return {username:"configured_owner"};};');
 f.get('authPassword').value=f.get('confirmPassword').value='Synthetic activation password 2026';
 f.get('activationCode').value='synthetic activation code';
 await f.get('passwordForm').handlers.submit({preventDefault(){}});
 assert.equal(f.path(),'/admin');assert.equal(f.run('state.authMode'),'login');
 assert.equal(f.get('authUsername').value,'configured_owner');assert.equal(f.get('memberPhone').required,false);
 assert.equal(f.get('phoneField').hidden,true);assert.equal(f.get('registerToggle').hidden,true);
 assert.equal(f.get('ownerResetLink').hidden,false);assert.equal(f.get('authPassword').value,'');
 assert.equal(f.get('authDialog').open,true);assert.equal(f.run('state.user'),null);
 assert.deepEqual(f.requests.map(r=>[r.url,r.method]),[['/api/auth/activate','POST']]);
});

test('customer sign-in uses ID, password and a compact OTP field without asking for the phone again',()=>{
 const f=fixture({},'/signin');f.run('showAuth("login")');
 assert.equal(f.get('phoneField').hidden,true);assert.equal(f.get('memberPhone').required,false);
 assert.equal(f.get('otpFields').hidden,false);assert.equal(f.get('memberOtp').required,true);assert.equal(f.get('passwordField').hidden,false);assert.equal(f.get('authPassword').required,true);
 assert.match(f.get('phoneOtpCopy').textContent,/registered mobile/i);
 assert.equal(f.get('registerToggle').hidden,false);assert.equal(f.get('ownerResetLink').hidden,true);
});
