import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {approveWithdrawal,getWithdrawalBanks,listAdminWithdrawals,listMemberWithdrawals,submitWithdrawal} from '../lib/withdrawals.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}

function fixture(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());
 const dir=new URL('../drizzle/',import.meta.url);for(const file of readdirSync(dir).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,dir),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(items){sqlite.exec('BEGIN IMMEDIATE');try{const out=[];for(const item of items)out.push(await item.run());sqlite.exec('COMMIT');return out;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.exec(`INSERT INTO users(id,username,phone,role,approved,csrf,created_at) VALUES('member','member','+60123456789','member',1,'m',0),('owner','owner',NULL,'owner',1,'o',0);
 INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('credit','member','credit-request','f','manual_bank',10000,'MYR','bank','credited',0,0);
 INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('credit-member','credit','member','member',10000,'MYR',0),('credit-clearing','credit','member','provider_clearing',-10000,'MYR',0);
 INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at) VALUES('member','passed','passed',1,'c',0,0);`);
 let payoutCalls=0;const payouts={manual_bank:{enabled:true,reason:'fixture',allowsMember:async()=>true,submit:async()=>{payoutCalls++;return {status:'processing'};}},vpay:{enabled:true,reason:'fixture',submit:async()=>{payoutCalls++;return {status:'processing'};}}};
 return {sqlite,db,payouts,get payoutCalls(){return payoutCalls;},member:{id:'member',username:'member',role:'member',approved:1},owner:{id:'owner',username:'owner',role:'owner',approved:1},key:'ewallet-test-key-'+ 'x'.repeat(40)};
}

const payload={providerId:'manual_bank',destinationType:'ewallet',ewalletCode:'touch_n_go',ewalletAccountIdentifier:'012-345 6789',accountHolder:'Member Legal Name',amount:'20.00',requestKey:'ewallet_withdrawal_0001'};

test('Malaysia e-wallet withdrawal is allowlisted, masked and manually reviewed without automatic payout',async t=>{
 const f=fixture(t),context={db:f.db,user:f.member,dataKey:f.key,payouts:f.payouts};
 const config=await (await getWithdrawalBanks(context)).json();assert.deepEqual(config.ewallets.map(x=>x.id),['touch_n_go','grabpay','boost','shopeepay']);assert.equal(config.verifiedPhoneMasked,'+60 ••• ••• 6789');assert.equal(JSON.stringify(config).includes('+60123456789'),false);
 const created=await submitWithdrawal(payload,context);assert.equal(created.status,201);const body=await created.json();assert.equal(body.withdrawal.destinationType,'ewallet');assert.equal(body.withdrawal.ewalletName,"Touch 'n Go eWallet");assert.equal(body.withdrawal.destinationNumber,'•••• 6789');assert.equal(JSON.stringify(body).includes('+60123456789'),false);
 const stored=f.sqlite.prepare('SELECT destination_type,bank_code,bank_name,account_last4,ewallet_code,ewallet_name,ewallet_account_encrypted,ewallet_account_last4 FROM withdrawal_requests').get();assert.deepEqual({...stored,destination_type:stored.destination_type},{destination_type:'ewallet',bank_code:'',bank_name:'',account_last4:'----',ewallet_code:'touch_n_go',ewallet_name:"Touch 'n Go eWallet",ewallet_account_encrypted:stored.ewallet_account_encrypted,ewallet_account_last4:'6789'});assert.ok(stored.ewallet_account_encrypted&&!stored.ewallet_account_encrypted.includes('60123456789'));
 const memberList=await (await listMemberWithdrawals(context)).json();assert.equal(memberList.items[0].destinationNumber,'•••• 6789');assert.equal(JSON.stringify(memberList).includes('+60123456789'),false);
 const adminContext={db:f.db,user:f.owner,dataKey:f.key,payouts:f.payouts},admin=await (await listAdminWithdrawals(adminContext)).json(),row=admin.items[0];assert.equal(row.destinationMethod,'E-Wallet');assert.equal(row.accountHolder,'Member Legal Name');assert.equal(row.approvalEligible,true);assert.equal(row.auditReference,`MASTER7 ${row.id}`);assert.equal(JSON.stringify(row).includes('+60123456789'),false);
 const approved=await approveWithdrawal({id:row.id,approvalFingerprint:row.approvalFingerprint,ownerNote:'Manual e-wallet review'},adminContext);assert.equal(approved.status,202);assert.deepEqual(await approved.json(),{status:'approved',withdrawal:{id:row.id,status:'approved'},manualTransferRequired:true});assert.equal(f.payoutCalls,0);assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE target=? AND event IN ('withdrawal_requested_v1','withdrawal_approved_v1')").get(row.id).n,2);
});

test('e-wallet destination rejects unverified numbers, unknown wallets and automatic providers',async t=>{
 const f=fixture(t),context={db:f.db,user:f.member,dataKey:f.key,payouts:f.payouts};
 for(const patch of [{ewalletAccountIdentifier:'0111111111'},{ewalletCode:'unknown_wallet'},{providerId:'vpay'}]){
  const response=await submitWithdrawal({...payload,...patch,requestKey:crypto.randomUUID()},context);assert.equal(response.status,400);assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM withdrawal_requests').get().n,0);assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }
});
