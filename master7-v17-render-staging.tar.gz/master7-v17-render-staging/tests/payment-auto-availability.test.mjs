import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';

// Real migrations and synthetic supplier replies only; no external requests.
const origin='https://portal.example.test',gateway='https://master7-integration-gateway.onrender.com',returnUrl='https://master7-v17-staging.onrender.com/payment/return';
const providers=['vpay','gspay','1mpay'];
function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 for(const [id,role,approved] of [['alice','member',1],['pending','member',0],['owner','owner',1]])sql.prepare('INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES(?,?,?,?,?,0)').run(id,id,role,approved,'csrf-'+id);
 sql.prepare("UPDATE payment_channel_controls SET status='closed'").run();
 class Statement{constructor(text,args=[]){this.text=text;this.args=args;}bind(...args){return new Statement(this.text,args);}async first(){return sql.prepare(this.text).get(...this.args)??null;}async all(){return {results:sql.prepare(this.text).all(...this.args)};}async run(){return sql.prepare(this.text).run(...this.args);}}
 const db={prepare:text=>new Statement(text),async batch(statements){sql.exec('BEGIN');try{const result=statements.map(s=>sql.prepare(s.text).run(...s.args));sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}};
 const state={orders:{vpay:0,gspay:0,'1mpay':0},configPatch:value=>value};
 const context={db,identity:null,ownerEmail:'owner@example.test',allowedOrigins:[origin],
  vpayGatewayUrl:gateway,vpayOrderToken:'o'.repeat(40),vpayQueryToken:'q'.repeat(40),vpayCallbackToken:'c'.repeat(40),vpayTraderId:'3647',vpayMode:'production',vpayReturnUrl:returnUrl,vpayOrdersEnabled:'false',
  gspayApiBase:'https://api.thegspay.com',gspayAuthKey:'a'.repeat(32),gspaySecretKey:'b'.repeat(32),gspayReturnUrl:returnUrl,gspayOrdersEnabled:'false',
  oneMpayApiBase:'https://api.1mpay.net',oneMpayMerchant:'fixture-merchant',oneMpaySecretKey:'fixture-secret-'.padEnd(40,'s'),oneMpayCallbackUrl:'https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment',oneMpayReturnUrl:returnUrl,oneMpayOrdersEnabled:'false',
  vpayFetch:async(input,init)=>{
   const url=new URL(input);assert.equal(url.origin,gateway);
   if(url.pathname==='/platform/vpay/config'){assert.equal(init.method,'GET');assert.equal(new Headers(init.headers).get('authorization'),'Bearer '+context.vpayQueryToken);return Response.json(state.configPatch({provider:'vpay',mode:'production',paymentReady:true,traderId:'3647',notifyUrl:gateway+'/callbacks/vpay/payment',returnUrl,tradeCodes:['2']}));}
   assert.equal(url.pathname,'/platform/vpay/order');assert.equal(init.method,'POST');state.orders.vpay++;
   const body=JSON.parse(init.body);return Response.json({provider:'vpay',result:{code:0,data:{trader_id:'3647',out_trade_no:body.outTradeNo,trade_no:'fixture-trade',amount:body.amount,currency:'MYR',pay_url:'https://payment.vpay.club/checkout/fixture-trade'}}});
  },
  gspayFetch:async(input,init)=>{assert.equal(String(input),'https://api.thegspay.com/v2/integrations/operators/'+context.gspayAuthKey+'/payment');assert.equal(init.method,'POST');state.orders.gspay++;return Response.json({code:200,data:{payment_id:'12345',payment_url:'https://secured.gspay.online/channel?id=12345&key='+'d'.repeat(32)}});},
  oneMpayFetch:async(input,init)=>{assert.equal(String(input),'https://api.1mpay.net/fundtransfer/json');assert.equal(init.method,'POST');state.orders['1mpay']++;return Response.json({code:0,data:{trxno:'fixture-1mpay-trade'},redirect_url:'https://api.1mpay.net/checkout/fixture-1mpay-trade'});},
 };
 async function call(path,{who=null,method='GET',data={},headers={}}={}){
  const request=new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(who?{'X-CSRF-Token':'csrf-'+who}:{}),...headers},...(method==='GET'?{}:{body:JSON.stringify(data)})});
  const response=await handle(request,{...context,identity:who?{userId:who,email:who+'@example.test'}:null});return {status:response.status,data:await response.json()};
 }
 const create=(provider,options={})=>call('/api/payments/'+provider+'/orders',{who:'alice',method:'POST',data:{amount:'20.00',requestKey:'automatic-request-'+provider,tradeCode:'2',payerName:'Fixture Member'},...options});
 t.after(()=>sql.close());return {sql,context,state,call,create};
}

test('health, provider status and public/admin channels share readonly automatic availability',async t=>{
 const f=fixture(t),before=f.sql.prepare('SELECT total_changes() n').get().n;
 const health=await f.call('/health'),publicChannels=await f.call('/api/payment-channels'),adminChannels=await f.call('/api/admin/payment-channels',{who:'owner'});
 for(const response of [health,publicChannels,adminChannels]){assert.equal(response.status,200);assert.equal(response.data.availabilityMode,'automatic');assert.equal(response.data.readOnly,true);}
 for(const provider of providers){
  const status=await f.call('/api/payments/'+provider+'/status');assert.equal(status.status,200);assert.equal(status.data.enabled,true);assert.equal(status.data.orderReady,true);assert.equal(status.data.channelStatus,'active');assert.equal(status.data.availabilityMode,'automatic');assert.equal(status.data.readOnly,true);assert.equal(status.data.settlementVerified,false);
  assert.deepEqual(status.data.capabilities.deposit,health.data.providerCapabilities[provider].deposit);assert.equal(health.data.providerOrdersEnabled[provider],true);
  for(const list of [publicChannels,adminChannels]){const item=list.data.items.find(item=>item.provider_id===provider);assert.equal(item.enabled,true);assert.equal(item.status,'active');assert.equal(item.readOnly,true);assert.equal(item.reason,status.data.reason);}
  assert.equal(status.data.capabilities.deposit.verified,false);assert.equal(status.data.capabilities.payout.enabled,false);
 }
 assert.equal(f.sql.prepare('SELECT total_changes() n').get().n,before);assert.deepEqual(f.state.orders,{vpay:0,gspay:0,'1mpay':0});
 assert.equal(health.data.productionReady,false);assert.equal(health.data.settlementVerified,false);
});

for(const legacy of [{flag:'false',channel:'closed'},{flag:undefined,channel:'suspended'}])test('members can create idempotent deposits despite deprecated controls '+legacy.channel,async t=>{
 const f=fixture(t);f.sql.prepare('UPDATE payment_channel_controls SET status=?').run(legacy.channel);
 for(const key of ['vpayOrdersEnabled','gspayOrdersEnabled','oneMpayOrdersEnabled'])f.context[key]=legacy.flag;
 for(const provider of providers){const first=await f.create(provider),repeat=await f.create(provider);assert.equal(first.status,201,provider);assert.equal(repeat.status,200,provider);assert.equal(repeat.data.id,first.data.id);assert.equal(f.state.orders[provider],1);}
 assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM deposit_orders').get().n,3);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('missing provider configuration remains unavailable without supplier or wallet mutations',async t=>{
 const f=fixture(t);f.context.vpayQueryToken=undefined;f.context.gspayAuthKey=undefined;f.context.oneMpaySecretKey=undefined;
 const health=await f.call('/health');
 for(const provider of providers){const status=await f.call('/api/payments/'+provider+'/status');assert.equal(status.data.orderReady,false);assert.equal(status.data.channelStatus,'unavailable');assert.equal(status.data.reason,'deposit_configuration_incomplete');assert.deepEqual(status.data.capabilities.deposit,health.data.providerCapabilities[provider].deposit);assert.equal((await f.create(provider)).status,503);}
 assert.deepEqual(f.state.orders,{vpay:0,gspay:0,'1mpay':0});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM deposit_orders').get().n,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});

test('VPay retains every existing gateway contract binding before creating an order',async t=>{
 const mismatches=[{provider:'other'},{mode:'uat'},{paymentReady:false},{traderId:'9999'},{notifyUrl:'https://attacker.example.test/callback'},{returnUrl:'https://attacker.example.test/return'},{tradeCodes:[]}];
 for(const patch of mismatches)await t.test(Object.keys(patch)[0],async sub=>{
  const f=fixture(sub);f.state.configPatch=value=>({...value,...patch});const status=await f.call('/api/payments/vpay/status'),health=await f.call('/health');
  assert.equal(status.data.enabled,false);assert.equal(status.data.reason,'gateway_contract_not_ready');assert.deepEqual(status.data.capabilities.deposit,health.data.providerCapabilities.vpay.deposit);assert.equal((await f.create('vpay')).status,503);assert.equal(f.state.orders.vpay,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM deposit_orders').get().n,0);
 });
});

test('deprecated admin toggles reject without any database write and retain owner/CSRF checks',async t=>{
 const f=fixture(t),before=f.sql.prepare('SELECT total_changes() n').get().n;
 for(const providerId of providers)for(const status of ['active','suspended','closed']){
  const result=await f.call('/api/admin/payment-channels',{who:'owner',method:'POST',data:{providerId,status}});assert.equal(result.status,405);assert.equal(result.data.error,'PAYMENT_AVAILABILITY_AUTOMATIC');assert.equal(result.data.readOnly,true);assert.equal(result.data.deprecated,true);
 }
 assert.equal((await f.call('/api/admin/payment-channels',{who:'alice',method:'POST'})).status,403);
 assert.equal((await f.call('/api/admin/payment-channels',{who:'owner',method:'POST',headers:{'X-CSRF-Token':'wrong'}})).status,403);
 assert.equal(f.sql.prepare('SELECT total_changes() n').get().n,before);assert.deepEqual(f.state.orders,{vpay:0,gspay:0,'1mpay':0});
});

test('automatic availability never grants owners, anonymous or unapproved users member deposit powers',async t=>{
 const f=fixture(t);
 for(const provider of providers){for(const [who,status] of [[null,401],['owner',403],['pending',403]])assert.equal((await f.create(provider,{who})).status,status);assert.equal((await f.create(provider,{headers:{'X-CSRF-Token':'wrong'}})).status,403);}
 assert.deepEqual(f.state.orders,{vpay:0,gspay:0,'1mpay':0});assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM deposit_orders').get().n,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM wallet_ledger').get().n,0);
});
