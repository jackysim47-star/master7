import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const route=readFileSync(new URL('../app/api/[...path]/route.ts',import.meta.url),'utf8');
const renderEnv=readFileSync(new URL('../lib/render-env.ts',import.meta.url),'utf8');

test('Telegram Bot is an owner-only outbound backoffice module with server-only credentials',()=>{
 assert.match(html,/href="#telegramBotPanel" data-owner-only/);
 assert.match(html,/id="telegramBotPanel" hidden data-owner-only/);
 assert.match(html,/id="telegramBotTest"[^>]+disabled/);
 assert.match(app,/api\("\/api\/admin\/telegram-bot"/);
 assert.match(app,/telegramBotPanel:\(\)=>loadTelegramBot\(\)/);
 assert.match(app,/"telegramBotPanel"/);
 for(const key of ['TELEGRAM_BOT_TOKEN','TELEGRAM_ADMIN_CHAT_ID']){assert.match(route,new RegExp(key));assert.match(renderEnv,new RegExp(key));assert.doesNotMatch(html,new RegExp(`${key}[^<]*(value=|input)`,`i`));}
});
