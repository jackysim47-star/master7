import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {megaCapabilityFixture} from './fixtures/megah5-capability.mjs';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

// These requests exercise the real router and migrated database. The injected
// gateway is a closed fixture; no test can contact a supplier or move real funds.
const gateway='https://master7-integration-gateway.onrender.com';
const gameToken='g'.repeat(48),walletToken='w'.repeat(48);
const game={provider:'megah5',providerName:'MegaH5',gameCode:'55021',name:'Ocean Quest',category:'2',maintenance:false,playable:false};

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function harness(){
 const sqlite=new DatabaseSync(':memory:');
 const migrations=new URL('../drizzle/',import.meta.url);
 for(const file of readdirSync(migrations).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,migrations),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member@example.test','member',1,'fixture-csrf',0)").run();
 sqlite.prepare("INSERT INTO providers(id,name,category,symbol,visible) VALUES('megah5','MegaH5','supplier','M7',1) ON CONFLICT(id) DO UPDATE SET visible=1").run();
 sqlite.prepare("INSERT INTO api_supplier_artwork(provider_id,image_data,status,updated_by,updated_at) VALUES('megah5','','active','member',0) ON CONFLICT(provider_id) DO UPDATE SET status='active'").run();
 sqlite.prepare("INSERT INTO game_visibility(provider_id,game_code,visible,status,image_data,category_override,updated_by,updated_at) VALUES('megah5','55021',1,'active','','','member',0)").run();
 sqlite.prepare("INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,upstream_status,lease_until,complete) VALUES('megah5','available',?,?,?,200,0,1)").run(JSON.stringify([game]),Math.floor(Date.now()/1000),Math.floor(Date.now()/1000));
 sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fixture-credit','member','fixture-credit-key','fixture','manual_bank',2000,'MYR','fixture','credited',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('fixture-member','fixture-credit','member','member',2000,'MYR',0),('fixture-clearing','fixture-credit','member','provider_clearing',-2000,'MYR',0)").run();
 const calls=[],capabilityCalls=[];
 const fixture={sessionStatus:200,capability:megaCapabilityFixture()};
 const fetchImpl=async(url,init)=>{
  const path=new URL(url).pathname;
  if(path==='/readiness'){capabilityCalls.push({path,method:init.method,headers:new Headers(init.headers)});return Response.json(fixture.capability);}
  calls.push({path,method:init.method,authorization:new Headers(init.headers).get('authorization'),body:init.body?JSON.parse(init.body):null});
  if(path==='/providers/megah5/games')return Response.json({provider:'megah5',result:{Status:200,Game:[{GameCode:'55021',GameName:'Ocean Quest',GameType:'2'}]}});
  if(path==='/platform/megah5/session')return Response.json({provider:'megah5',upstreamStatus:200,result:{Status:fixture.sessionStatus,Url:'https://launch.example.test/session'}});
  if(path==='/platform/megah5/balance')return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:'0.00',Currency:'MYR'}});
  if(path==='/platform/megah5/deposit')return Response.json({provider:'megah5',result:{Status:200}});
  throw Error('Unexpected fixture gateway call: '+path);
 };
 const context={db,identity:{userId:'member',email:'member@example.test'},ownerEmail:'owner@example.test',gameGatewayUrl:gateway,gameGatewayToken:gameToken,gameGatewayWalletToken:walletToken,megaTransfersEnabled:'true',megaLiveGamesEnabled:'true',megaSettlementVerified:'true',gameGatewayFetch:fetchImpl};
 async function request(path,{method='GET',data,extra={}}={}){
  const response=await handle(new Request('https://portal.example.test'+path,{method,headers:{'content-type':'application/json',origin:'https://portal.example.test','x-csrf-token':'fixture-csrf','x-forwarded-for':'203.0.113.8'},...(data?{body:JSON.stringify(data)}:{})}),{...context,...extra});
  return {status:response.status,data:await response.json()};
 }
 const launch=extra=>request('/api/game-launch',{method:'POST',data:{providerId:'megah5',gameCode:'55021'},extra});
 return {sqlite,db,calls,capabilityCalls,fixture,context,request,launch,close:()=>sqlite.close()};
}

test('cached platform summary agrees with the selected MegaH5 catalogue without a supplier call or financial operation',async()=>{
 const h=harness();try{
  const summary=await h.request('/api/games');
  const selected=await h.request('/api/games?provider=megah5');
  assert.equal(summary.status,200);assert.equal(selected.status,200);
  assert.equal(selected.data.selectedPlatform.platformLaunchReady,true);
  assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').platformLaunchReady,true);
  assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').platformStatus,'ready');
  assert.equal(summary.data.liveReady,true);assert.equal(summary.data.playable,true);assert.equal(summary.data.launchProvider,'megah5');
  assert.deepEqual(summary.data.games,[]);assert.equal(summary.data.providersOnly,true);
  assert.ok(summary.data.providers.filter(provider=>provider.id!=='megah5').every(provider=>provider.platformLaunchReady===false));
  assert.equal(h.calls.length,0);
 }finally{h.close();}
});

test('legacy manual availability never overrides actual API capability or acceptance evidence',async()=>{
 const h=harness();try{
  h.sqlite.prepare("UPDATE api_supplier_artwork SET status='closed' WHERE provider_id='megah5'").run();
  h.sqlite.prepare("UPDATE providers SET visible=0 WHERE id='megah5'").run();
  h.sqlite.prepare("UPDATE game_visibility SET visible=0,status='suspended' WHERE provider_id='megah5'").run();
  const extra={megaSettlementVerified:'false',megaLiveGamesEnabled:'false',megaTransfersEnabled:'false'};
  const summary=await h.request('/api/games',{extra}),selected=await h.request('/api/games?provider=megah5',{extra});
  for(const data of [summary.data,selected.data]){
   const provider=data.providers.find(provider=>provider.id==='megah5');
   assert.equal(data.availabilityMode,'automatic');assert.equal(provider.readOnlyAvailability,true);
   assert.equal(provider.platformLaunchReady,true);assert.equal(provider.launchReady,true);assert.equal(provider.walletReady,true);
   assert.equal(provider.launchVerified,false);assert.equal(provider.walletVerified,false);assert.equal(provider.settlementVerified,false);
  }
  assert.equal(selected.data.games[0].playable,true);
  const launched=await h.launch(extra);assert.equal(launched.status,200);assert.equal(launched.data.walletVerified,true,'only a real mocked wallet result establishes this request evidence');
  assert.equal(h.calls.filter(call=>call.path.endsWith('/deposit')).length,1);
  assert.ok(h.capabilityCalls.every(call=>call.method==='GET'&&!call.headers.has('authorization')));
 }finally{h.close();}
});

test('automatic readiness still requires credentials, complete fresh catalogue and vendor availability',async()=>{
 const h=harness();try{
  for(const extra of [{gameGatewayToken:''},{gameGatewayWalletToken:gameToken},{gameGatewayUrl:'https://untrusted.example.test'}]){
   const summary=await h.request('/api/games',{extra});assert.equal(summary.data.liveReady,false);
  }
  for(const statement of ["complete=0","complete=1,status='blocked'","status='available',games_json='invalid'","games_json='[]'"]){
   h.sqlite.prepare("UPDATE game_catalogue_cache SET "+statement+" WHERE provider_id='megah5'").run();
   assert.equal((await h.request('/api/games')).data.liveReady,false);
  }
  h.sqlite.prepare("UPDATE game_catalogue_cache SET games_json=? WHERE provider_id='megah5'").run(JSON.stringify([{...game,maintenance:true}]));
  assert.equal((await h.launch()).status,409);assert.equal(h.calls.length,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
 }finally{h.close();}
});

test('gateway flags alone cannot open games without all transfer and recovery contracts',async()=>{
 for(const modify of [data=>{data.megah5Transfer.credentialsConfigured=false;},data=>{data.megah5Transfer.walletTokenConfigured=false;},data=>{delete data.megah5Transfer.channels.status;},data=>{data.megah5Transfer.channels.withdrawal.configurationReady=false;},data=>{data.megah5Transfer.channels.deposit.blockers=['provider_credentials_missing_or_invalid'];}]){
  const h=harness();try{
   modify(h.fixture.capability);const response=await h.request('/api/games');assert.equal(response.data.liveReady,false);
   const provider=response.data.providers.find(provider=>provider.id==='megah5');assert.equal(provider.walletReady,false);assert.equal(provider.launchVerified,false);
   assert.equal((await h.launch()).status,503);assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
  }finally{h.close();}
 }
});

test('a cached summary expires at the catalogue refresh boundary without contacting the supplier',async()=>{
 const h=harness();try{
  const checkedAt=1700000000;
  h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=?,last_success_at=? WHERE provider_id='megah5'").run(checkedAt,checkedAt);
  const expiredCalls=[];
  const rejectedRefresh=async(url,init)=>{if(new URL(url).pathname==='/readiness')return Response.json(megaCapabilityFixture());expiredCalls.push({path:new URL(url).pathname,method:init.method});return Response.json({error:'provider_unavailable'},{status:502});};
  const selectedFresh=await h.request('/api/games?provider=megah5',{extra:{gameSyncNow:()=>checkedAt+299,gameGatewayFetch:rejectedRefresh}});
  assert.equal(selectedFresh.data.liveReady,true);assert.equal(expiredCalls.length,0);
  for(const [elapsed,expected] of [[299,true],[300,false],[301,false]]){
   const summary=await h.request('/api/games',{extra:{gameSyncNow:()=>checkedAt+elapsed,gameGatewayFetch:rejectedRefresh}});
   assert.equal(summary.status,200);assert.equal(summary.data.liveReady,expected,'cache age '+elapsed);
   assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').platformLaunchReady,expected,'cache age '+elapsed);
   assert.equal(expiredCalls.length,0,'the summary must never attempt a refresh');
  }
  const selectedExpired=await h.request('/api/games?provider=megah5',{extra:{gameSyncNow:()=>checkedAt+300,gameGatewayFetch:rejectedRefresh}});
  assert.equal(selectedExpired.data.liveReady,false);
  assert.deepEqual(expiredCalls,[{path:'/providers/megah5/games',method:'GET'}]);
  assert.equal(h.calls.length,0);
 }finally{h.close();}
});

test('a MegaH5 launch refreshes only its own catalogue and preserves scoped wallet credentials',async()=>{
 const h=harness();try{
  h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=0 WHERE provider_id='megah5'").run();
  const launched=await h.launch();
  assert.equal(launched.status,200);assert.equal(launched.data.launchUrl,'https://launch.example.test/session');
  assert.equal(launched.data.amountInGameMinor,'2000');
  assert.deepEqual(h.calls.map(call=>call.path),['/providers/megah5/games','/platform/megah5/session','/platform/megah5/balance','/platform/megah5/deposit']);
  assert.equal(h.calls.find(call=>call.path.endsWith('/session')).authorization,'Bearer '+gameToken);
  assert.equal(h.calls.find(call=>call.path.endsWith('/deposit')).authorization,'Bearer '+walletToken);
  assert.equal(h.calls.find(call=>call.path.endsWith('/deposit')).body.amount,'20.00');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,1);
 }finally{h.close();}
});

test('an incomplete catalogue cannot launch or reserve money through a direct POST',async()=>{
 const h=harness();try{
  h.sqlite.prepare("UPDATE game_catalogue_cache SET complete=0 WHERE provider_id='megah5'").run();
  const selected=await h.request('/api/games?provider=megah5');assert.equal(selected.data.playable,false);
  const launched=await h.launch();assert.equal(launched.status,409);
  assert.equal(h.calls.length,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'2000');
 }finally{h.close();}
});

test('HTTP 200 with a rejected or missing GameLogin business status cannot prepare the wallet',async()=>{
 for(const status of [403,'403',undefined]){
  const h=harness();try{
   h.fixture.sessionStatus=status;
   const launched=await h.launch();assert.equal(launched.status,502,String(status));
   assert.deepEqual(h.calls.map(call=>call.path),['/platform/megah5/session']);
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
   assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'2000');
  }finally{h.close();}
 }
});

test('a successful documented GameLogin string status still creates only one wallet transfer on retry',async()=>{
 const h=harness();try{
  h.fixture.sessionStatus='200';
  assert.equal((await h.launch()).status,200);
  assert.equal((await h.launch()).status,200);
  assert.equal(h.calls.filter(call=>call.path.endsWith('/deposit')).length,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,1);
 }finally{h.close();}
});

test('retired owner availability endpoints perform zero database writes and retain authentication',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner@example.test','owner',1,'fixture-csrf',0)").run();
  const owner={identity:{userId:'owner',email:'owner@example.test'}},requests=[
   ['/api/admin/supplier-art',{providerId:'megah5',status:'closed'}],
   ['/api/admin/provider',{id:'megah5',visible:false}],
   ['/api/admin/game-visibility',{providerId:'megah5',gameCode:'55021',status:'suspended'}],
   ['/api/admin/custom-games',{action:'toggle',id:'mini-fixture',enabled:true}],
   ['/api/admin/custom-games',{action:'status',id:'mini-fixture',status:'active'}],
  ];
  for(const [path,data] of requests){
   const before=h.sqlite.prepare('SELECT total_changes() n').get().n;
   const response=await h.request(path,{method:'POST',data,extra:owner});
   assert.equal(response.status,410,path);assert.equal(response.data.availabilityMode,'automatic');assert.equal(response.data.readOnlyAvailability,true);
   assert.equal(h.sqlite.prepare('SELECT total_changes() n').get().n,before,path+' must not write an audit, rate limit or availability row');
   assert.equal((await h.request(path,{method:'POST',data})).status,403);
  }
  assert.equal(h.calls.length,0);assert.equal(h.capabilityCalls.length,0);
 }finally{h.close();}
});

test('editorial updates retain historical status without enabling a custom mini engine',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner@example.test','owner',1,'fixture-csrf',0)").run();
  h.sqlite.prepare("UPDATE providers SET visible=0 WHERE id='megah5'").run();h.sqlite.prepare("UPDATE api_supplier_artwork SET status='closed' WHERE provider_id='megah5'").run();h.sqlite.prepare("UPDATE game_visibility SET visible=0,status='closed' WHERE provider_id='megah5'").run();
  const extra={identity:{userId:'owner',email:'owner@example.test'}},imageData='data:image/png;base64,iVBORw0KGgoAAAAAAAAAAAAAAAA=';
  for(const [path,data] of [['/api/admin/provider',{id:'megah5',imageData}],['/api/admin/supplier-art',{providerId:'megah5',imageData}],['/api/admin/game-visibility',{providerId:'megah5',gameCode:'55021',accessZone:'free',category:'LIVE',imageData}]])assert.equal((await h.request(path,{method:'POST',data,extra})).status,200,path);
  assert.equal(h.sqlite.prepare("SELECT visible FROM providers WHERE id='megah5'").get().visible,0);
  assert.equal(h.sqlite.prepare("SELECT status FROM api_supplier_artwork WHERE provider_id='megah5'").get().status,'closed');
  const override=h.sqlite.prepare("SELECT visible,status,category_override,access_zone FROM game_visibility WHERE provider_id='megah5'").get();assert.deepEqual({...override},{visible:0,status:'closed',category_override:'LIVE',access_zone:'free'});
  const selected=(await h.request('/api/games?provider=megah5')).data;assert.equal(selected.games[0].playable,true);assert.equal(selected.games[0].accessZone,'free');assert.equal(selected.games[0].imageData,imageData);
  const saved=await h.request('/api/admin/custom-games',{method:'POST',extra,data:{action:'save',title:'Fixture mini',providerName:'MASTER7',isPlatformMini:true,imageData,enabled:true,status:'active'}});assert.equal(saved.status,201);
  const minis=(await h.request('/api/admin/custom-games',{extra})).data;assert.equal(minis.items[0].launchReady,false);assert.equal(minis.items[0].walletVerified,false);assert.equal(minis.items[0].capabilityReason,'custom_game_engine_not_implemented');
  const publicMinis=(await h.request('/api/custom-games')).data;assert.equal(publicMinis.playable,false);assert.deepEqual(publicMinis.items,[]);
 }finally{h.close();}
});

test('a stale catalogue held by a refresh lease cannot launch with retained games',async()=>{
 const h=harness();try{
  const stamp=Math.floor(Date.now()/1000);h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=?,lease_until=? WHERE provider_id='megah5'").run(stamp-600,stamp+30);
  assert.equal((await h.launch()).status,409);assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('health and operations readiness consume observations without probing a game supplier',async()=>{
 const h=harness();try{
  const before=await h.request('/health');assert.equal(before.data.liveGames,false);assert.equal(h.capabilityCalls.length,0);
  assert.equal((await h.request('/api/games')).data.liveReady,true);const count=h.capabilityCalls.length;
  const after=await h.request('/health',{extra:{megaSettlementVerified:'false'}});assert.equal(after.data.liveGames,true);assert.equal(after.data.megaWallet.launchVerified,false);assert.equal(after.data.megaWallet.walletVerified,false);assert.equal(after.data.megaWallet.settlementVerified,false);
  assert.equal(h.capabilityCalls.length,count);assert.equal(h.calls.length,0);
  const changed=await h.request('/health',{extra:{gameGatewayWalletToken:'changed'.repeat(8)}});assert.equal(changed.data.liveGames,false);assert.equal(h.capabilityCalls.length,count);
 }finally{h.close();}
});
