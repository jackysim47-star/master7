import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

// These requests exercise the real router and migrated database. The injected
// gateway is a closed fixture; no test can contact a supplier or move real funds.
const gateway='https://master7-integration-gateway.onrender.com';
const gameToken='g'.repeat(48),walletToken='w'.repeat(48);
const game={provider:'megah5',providerName:'MegaH5',gameCode:'55021',name:'Ocean Quest',category:'2',maintenance:false,playable:false};

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function harness(){
 const sqlite=new DatabaseSync(':memory:');
 const migrations=new URL('../drizzle/',import.meta.url);
 for(const file of readdirSync(migrations).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,migrations),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member@example.test','member',1,'fixture-csrf',0)").run();
 sqlite.prepare("INSERT INTO providers(id,name,category,symbol,visible) VALUES('megah5','MegaH5','supplier','M7',1) ON CONFLICT(id) DO UPDATE SET visible=1").run();
 sqlite.prepare("INSERT INTO api_supplier_artwork(provider_id,image_data,status,updated_by,updated_at) VALUES('megah5','','active','member',0) ON CONFLICT(provider_id) DO UPDATE SET status='active'").run();
 sqlite.prepare("INSERT INTO game_visibility(provider_id,game_code,visible,status,image_data,category_override,updated_by,updated_at) VALUES('megah5','55021',1,'active','','','member',0)").run();
 sqlite.prepare("INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,upstream_status,lease_until,complete) VALUES('megah5','available',?,?,?,200,0,1)").run(JSON.stringify([game]),Math.floor(Date.now()/1000),Math.floor(Date.now()/1000));
 sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fixture-credit','member','fixture-credit-key','fixture','manual_bank',2000,'MYR','fixture','credited',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('fixture-member','fixture-credit','member','member',2000,'MYR',0),('fixture-clearing','fixture-credit','member','provider_clearing',-2000,'MYR',0)").run();
 const calls=[];
 const fixture={sessionStatus:200};
 const fetchImpl=async(url,init)=>{
  const path=new URL(url).pathname;
  calls.push({path,method:init.method,authorization:new Headers(init.headers).get('authorization'),body:init.body?JSON.parse(init.body):null});
  if(path==='/providers/megah5/games')return Response.json({provider:'megah5',result:{Status:200,Game:[{GameCode:'55021',GameName:'Ocean Quest',GameType:'2'}]}});
  if(path==='/platform/megah5/session')return Response.json({provider:'megah5',upstreamStatus:200,result:{Status:fixture.sessionStatus,Url:'https://launch.example.test/session'}});
  if(path==='/platform/megah5/balance')return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:'0.00',Currency:'MYR'}});
  if(path==='/platform/megah5/deposit')return Response.json({provider:'megah5',result:{Status:200}});
  throw Error('Unexpected fixture gateway call: '+path);
 };
 const context={db,identity:{userId:'member',email:'member@example.test'},ownerEmail:'owner@example.test',gameGatewayUrl:gateway,gameGatewayToken:gameToken,gameGatewayWalletToken:walletToken,megaTransfersEnabled:'true',megaLiveGamesEnabled:'true',megaSettlementVerified:'true',gameGatewayFetch:fetchImpl};
 async function request(path,{method='GET',data,extra={}}={}){
  const response=await handle(new Request('https://portal.example.test'+path,{method,headers:{'content-type':'application/json',origin:'https://portal.example.test','x-csrf-token':'fixture-csrf','x-forwarded-for':'203.0.113.8'},...(data?{body:JSON.stringify(data)}:{})}),{...context,...extra});
  return {status:response.status,data:await response.json()};
 }
 const launch=extra=>request('/api/game-launch',{method:'POST',data:{providerId:'megah5',gameCode:'55021'},extra});
 return {sqlite,db,calls,fixture,context,request,launch,close:()=>sqlite.close()};
}

test('cached platform summary agrees with the selected MegaH5 catalogue without a gateway call',async()=>{
 const h=harness();try{
  const summary=await h.request('/api/games');
  const selected=await h.request('/api/games?provider=megah5');
  assert.equal(summary.status,200);assert.equal(selected.status,200);
  assert.equal(selected.data.selectedPlatform.platformLaunchReady,true);
  assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').platformLaunchReady,true);
  assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').platformStatus,'ready');
  assert.equal(summary.data.liveReady,true);assert.equal(summary.data.playable,true);assert.equal(summary.data.launchProvider,'megah5');
  assert.deepEqual(summary.data.games,[]);assert.equal(summary.data.providersOnly,true);
  assert.ok(summary.data.providers.filter(provider=>provider.id!=='megah5').every(provider=>provider.platformLaunchReady===false));
  assert.equal(h.calls.length,0);
 }finally{h.close();}
});

test('platform summary keeps every real readiness and catalogue control effective',async()=>{
 const h=harness();try{
  for(const extra of [{megaSettlementVerified:'false'},{megaLiveGamesEnabled:'false'},{megaTransfersEnabled:'false'},{gameGatewayToken:''},{gameGatewayWalletToken:gameToken},{gameGatewayUrl:'https://untrusted.example.test'}]){
   const summary=await h.request('/api/games',{extra});
   assert.equal(summary.status,200);assert.equal(summary.data.liveReady,false);assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').platformLaunchReady,false);
  }
  for(const status of ['closed','suspended']){
   h.sqlite.prepare("UPDATE api_supplier_artwork SET status=? WHERE provider_id='megah5'").run(status);
   const summary=await h.request('/api/games');assert.equal(summary.data.liveReady,false);
  }
  h.sqlite.prepare("UPDATE api_supplier_artwork SET status='active' WHERE provider_id='megah5'").run();
  h.sqlite.prepare("UPDATE game_visibility SET status='suspended' WHERE provider_id='megah5'").run();
  assert.equal((await h.request('/api/games')).data.liveReady,false);
  h.sqlite.prepare("UPDATE game_visibility SET status='active' WHERE provider_id='megah5'").run();
  h.sqlite.prepare("UPDATE game_catalogue_cache SET complete=0 WHERE provider_id='megah5'").run();
  assert.equal((await h.request('/api/games')).data.liveReady,false);
  h.sqlite.prepare("UPDATE game_catalogue_cache SET complete=1,status='blocked' WHERE provider_id='megah5'").run();
  assert.equal((await h.request('/api/games')).data.liveReady,false);
  h.sqlite.prepare("UPDATE game_catalogue_cache SET status='available',games_json='invalid' WHERE provider_id='megah5'").run();
  assert.equal((await h.request('/api/games')).data.liveReady,false);
  assert.equal(h.calls.length,0);
 }finally{h.close();}
});

test('a cached summary expires at the catalogue refresh boundary without contacting the supplier',async()=>{
 const h=harness();try{
  const checkedAt=1700000000;
  h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=?,last_success_at=? WHERE provider_id='megah5'").run(checkedAt,checkedAt);
  const expiredCalls=[];
  const rejectedRefresh=async(url,init)=>{expiredCalls.push({path:new URL(url).pathname,method:init.method});return Response.json({error:'provider_unavailable'},{status:502});};
  const selectedFresh=await h.request('/api/games?provider=megah5',{extra:{gameSyncNow:()=>checkedAt+299,gameGatewayFetch:rejectedRefresh}});
  assert.equal(selectedFresh.data.liveReady,true);assert.equal(expiredCalls.length,0);
  for(const [elapsed,expected] of [[299,true],[300,false],[301,false]]){
   const summary=await h.request('/api/games',{extra:{gameSyncNow:()=>checkedAt+elapsed,gameGatewayFetch:rejectedRefresh}});
   assert.equal(summary.status,200);assert.equal(summary.data.liveReady,expected,'cache age '+elapsed);
   assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').platformLaunchReady,expected,'cache age '+elapsed);
   assert.equal(expiredCalls.length,0,'the summary must never attempt a refresh');
  }
  const selectedExpired=await h.request('/api/games?provider=megah5',{extra:{gameSyncNow:()=>checkedAt+300,gameGatewayFetch:rejectedRefresh}});
  assert.equal(selectedExpired.data.liveReady,false);
  assert.deepEqual(expiredCalls,[{path:'/providers/megah5/games',method:'GET'}]);
  assert.equal(h.calls.length,0);
 }finally{h.close();}
});

test('a MegaH5 launch refreshes only its own catalogue and preserves scoped wallet credentials',async()=>{
 const h=harness();try{
  h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=0 WHERE provider_id='megah5'").run();
  const launched=await h.launch();
  assert.equal(launched.status,200);assert.equal(launched.data.launchUrl,'https://launch.example.test/session');
  assert.equal(launched.data.amountInGameMinor,'2000');
  assert.deepEqual(h.calls.map(call=>call.path),['/providers/megah5/games','/platform/megah5/session','/platform/megah5/balance','/platform/megah5/deposit']);
  assert.equal(h.calls.find(call=>call.path.endsWith('/session')).authorization,'Bearer '+gameToken);
  assert.equal(h.calls.find(call=>call.path.endsWith('/deposit')).authorization,'Bearer '+walletToken);
  assert.equal(h.calls.find(call=>call.path.endsWith('/deposit')).body.amount,'20.00');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,1);
 }finally{h.close();}
});

test('an incomplete catalogue cannot launch or reserve money through a direct POST',async()=>{
 const h=harness();try{
  h.sqlite.prepare("UPDATE game_catalogue_cache SET complete=0 WHERE provider_id='megah5'").run();
  const selected=await h.request('/api/games?provider=megah5');assert.equal(selected.data.playable,false);
  const launched=await h.launch();assert.equal(launched.status,409);
  assert.equal(h.calls.length,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'2000');
 }finally{h.close();}
});

test('HTTP 200 with a rejected or missing GameLogin business status cannot prepare the wallet',async()=>{
 for(const status of [403,'403',undefined]){
  const h=harness();try{
   h.fixture.sessionStatus=status;
   const launched=await h.launch();assert.equal(launched.status,502,String(status));
   assert.deepEqual(h.calls.map(call=>call.path),['/platform/megah5/session']);
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
   assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'2000');
  }finally{h.close();}
 }
});

test('a successful documented GameLogin string status still creates only one wallet transfer on retry',async()=>{
 const h=harness();try{
  h.fixture.sessionStatus='200';
  assert.equal((await h.launch()).status,200);
  assert.equal((await h.launch()).status,200);
  assert.equal(h.calls.filter(call=>call.path.endsWith('/deposit')).length,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,1);
 }finally{h.close();}
});
