import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';
import {prepareMegaWallet} from '../lib/megah5-wallet.ts';
import {megaCapabilityFixture} from './fixtures/megah5-capability.mjs';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

// These requests exercise the real router and migrated database. The injected
// gateway is a closed fixture; no test can contact a supplier or move real funds.
const gateway='https://master7-integration-gateway.onrender.com';
const gameToken='g'.repeat(48),walletToken='w'.repeat(48);
const game={provider:'megah5',providerName:'MegaH5',gameCode:'55021',name:'Ocean Quest',category:'2',maintenance:false,playable:false};

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
}

function harness(){
 const sqlite=new DatabaseSync(':memory:');
 const migrations=new URL('../drizzle/',import.meta.url);
 for(const file of readdirSync(migrations).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,migrations),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec('COMMIT');return results;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member@example.test','member',1,'fixture-csrf',0)").run();
 sqlite.prepare("INSERT INTO providers(id,name,category,symbol,visible) VALUES('megah5','MegaH5','supplier','M7',1) ON CONFLICT(id) DO UPDATE SET visible=1").run();
 sqlite.prepare("INSERT INTO api_supplier_artwork(provider_id,image_data,status,updated_by,updated_at) VALUES('megah5','','active','member',0) ON CONFLICT(provider_id) DO UPDATE SET status='active'").run();
 sqlite.prepare("INSERT INTO game_visibility(provider_id,game_code,visible,status,image_data,category_override,updated_by,updated_at) VALUES('megah5','55021',1,'active','','','member',0)").run();
 sqlite.prepare("INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,upstream_status,lease_until,complete) VALUES('megah5','available',?,?,?,200,0,1)").run(JSON.stringify([game]),Math.floor(Date.now()/1000),Math.floor(Date.now()/1000));
 sqlite.prepare("INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('fixture-credit','member','fixture-credit-key','fixture','manual_bank',2000,'MYR','fixture','credited',0,0)").run();
 sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('fixture-member','fixture-credit','member','member',2000,'MYR',0),('fixture-clearing','fixture-credit','member','provider_clearing',-2000,'MYR',0)").run();
 const calls=[],capabilityCalls=[],catalogueCalls=[];
 const fixture={sessionStatus:200,sessionUrl:'https://launch.example.test/session',capability:megaCapabilityFixture()};
 const fetchImpl=async(url,init)=>{
  const parsed=new URL(url),path=parsed.pathname;
  if(path==='/readiness'){capabilityCalls.push({path,method:init.method,headers:new Headers(init.headers)});return Response.json(fixture.capability);}
  if(path==='/providers/918kissh5/games'){
   const account=parsed.searchParams.get('account'),currency=account==='my1'?'MY1':'MYR',count=account==='free'?88:92;
   if(!['normal','my1','free'].includes(account))throw Error('Unexpected 918KISS account: '+account);
   catalogueCalls.push({path,account,currency});
   return Response.json({provider:'918kissh5',account,currency,games:Array.from({length:count},(_,index)=>({gameCode:`${account}-${index+1}`,name:`${account} title ${index+1}`,category:'SLOT'}))});
  }
  if(path==='/providers/metagaming/games'){
   const account=parsed.searchParams.get('account'),currency='MYR',count=account==='free'?2:3;
   if(!['normal','free'].includes(account))throw Error('Unexpected META GAMING account: '+account);
   catalogueCalls.push({path,account,currency});
   return Response.json({apiVersion:'3.4.8',provider:'metagaming',account,currency,games:Array.from({length:count},(_,index)=>({gameCode:`meta-${account}-${index+1}`,name:`META ${account} ${index+1}`,gameType:1,imageUrl:'https://unverified.example.test/thumbs/Web/10000.png',hasDemo:true}))});
  }
  calls.push({path,method:init.method,authorization:new Headers(init.headers).get('authorization'),body:init.body?JSON.parse(init.body):null});
  if(path==='/providers/megah5/games')return Response.json({provider:'megah5',result:{Status:200,Game:[{GameCode:'55021',GameName:'Ocean Quest',GameType:'2'}]}});
  if(path==='/platform/megah5/session')return Response.json({provider:'megah5',upstreamStatus:200,result:{Status:fixture.sessionStatus,Url:fixture.sessionUrl}});
  if(path==='/platform/megah5/balance')return Response.json({provider:'megah5',result:{Status:200,CurrentBalance:'0.00',Currency:'MYR'}});
  if(path==='/platform/megah5/deposit')return Response.json({provider:'megah5',operation:'deposit',referenceId:JSON.parse(init.body).referenceId,result:{Status:200}});
  throw Error('Unexpected fixture gateway call: '+path);
 };
 const context={db,identity:{userId:'member',email:'member@example.test'},ownerEmail:'owner@example.test',newGameLaunchesEnabled:'true',gameGatewayUrl:gateway,gameGatewayToken:gameToken,gameGatewayWalletToken:walletToken,megaLaunchOriginsJson:'["https://launch.example.test"]',megaTransfersEnabled:'true',megaLiveGamesEnabled:'true',megaSettlementVerified:'true',gameGatewayFetch:fetchImpl};
 async function request(path,{method='GET',data,extra={}}={}){
  const response=await handle(new Request('https://portal.example.test'+path,{method,headers:{'content-type':'application/json',origin:'https://portal.example.test','x-csrf-token':'fixture-csrf','x-forwarded-for':'203.0.113.8'},...(data?{body:JSON.stringify(data)}:{})}),{...context,...extra});
  return {status:response.status,data:await response.json()};
 }
 const launch=extra=>request('/api/game-launch',{method:'POST',data:{providerId:'megah5',gameCode:'55021'},extra});
 const prepareWallet=()=>prepareMegaWallet({db,user:{id:'member',username:'member@example.test',role:'member',approved:1},gatewayUrl:gateway,gameToken,walletToken,launchOriginsJson:context.megaLaunchOriginsJson,newGameLaunchesEnabled:context.newGameLaunchesEnabled,fetchImpl},'55021');
 return {sqlite,db,calls,capabilityCalls,catalogueCalls,fixture,context,request,launch,prepareWallet,close:()=>sqlite.close()};
}

function acceptMega(h){
 for(const [index,capability] of ['catalogue','launch','wallet','settlement','recovery'].entries()){
  const id=`fixture-megah5-${capability}`;
  h.sqlite.prepare(`INSERT INTO game_provider_acceptance_events(id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at) VALUES(?, 'megah5_myr',1,?,'production','passed',?,?,'member',1,1)`).run(id,capability,String(index+1).repeat(64),`fixture/${capability}`);
  h.sqlite.prepare("INSERT INTO game_provider_acceptance_current(profile_id,capability,environment,event_id) VALUES('megah5_myr',?,'production',?)").run(capability,id);
 }
}
const verifiedClosure={megaClosureContractVerified:true,megaSessionCloser:async input=>({state:'closed',receipt:{...input,providerClosureReference:'FIXTURE-CLOSE-1',allIssuedLaunchesInvalidated:true,pendingRounds:0,lateResultsFinal:true}})};

test('cached capability and game directory stay unplayable without verified acceptance',async()=>{
 const h=harness();try{
  const summary=await h.request('/api/games');assert.equal(summary.status,200);assert.equal(h.capabilityCalls.length,0);
  const summaryProvider=summary.data.providers.find(item=>item.id==='megah5');assert.equal(summaryProvider.connectionVerified,true);assert.equal(summaryProvider.walletReady,false);assert.equal(summaryProvider.platformLaunchReady,false);assert.equal(summaryProvider.platformStatus,'catalogue_ready');assert.equal(summaryProvider.capabilityReason,'gateway_not_probed_by_catalogue_summary');assert.equal(summaryProvider.launchVerified,false);assert.equal(summaryProvider.walletVerified,false);assert.equal(summaryProvider.settlementVerified,false);assert.equal(summary.data.liveReady,false);assert.equal(summary.data.playable,false);assert.equal(summary.data.launchProvider,null);
  const selected=await h.request('/api/games?provider=megah5');assert.equal(selected.status,200);assert.equal(h.capabilityCalls.length,1);
  const selectedProvider=selected.data.providers.find(item=>item.id==='megah5');assert.equal(selectedProvider.connectionVerified,true);assert.equal(selectedProvider.walletReady,true);assert.equal(selectedProvider.platformLaunchReady,false);assert.equal(selectedProvider.platformStatus,'awaiting_acceptance');assert.equal(selectedProvider.launchVerified,false);assert.equal(selectedProvider.walletVerified,false);assert.equal(selectedProvider.settlementVerified,false);assert.equal(selected.data.liveReady,false);assert.equal(selected.data.playable,false);assert.equal(selected.data.launchProvider,null);
  assert.ok(selected.data.games.length>0);assert.ok(selected.data.games.every(game=>game.playable===false));
  assert.deepEqual(summary.data.games,[]);assert.equal(summary.data.providersOnly,true);assert.equal(h.calls.length,0);
 }finally{h.close();}
});

test('public game responses expose 37 brands and isolated fail-closed profile metadata',async()=>{
 const h=harness();try{
  const summary=await h.request('/api/games');assert.equal(summary.status,200);
  assert.equal(summary.data.platformCount,37);assert.equal(summary.data.profileBrandCount,37);
  assert.ok(summary.data.profileCount>37);assert.equal(summary.data.profiles.length,summary.data.profileCount);
  assert.equal(summary.data.implementedProfileCount,4);assert.equal(summary.data.verifiedProfileCount,0);
  const mega=summary.data.profiles.find(profile=>profile.profileId==='megah5_myr');assert.equal(mega.providerId,'megah5');assert.equal(mega.walletMode,'transfer');assert.equal(mega.launchVerified,false);
  const jili=summary.data.providers.find(provider=>provider.id==='jili');assert.deepEqual(jili.profiles.map(profile=>profile.profileId),['jili_myr_1to1','jili_my1_1to100']);
  assert.ok(jili.profiles.every(profile=>profile.launchReady===false&&profile.walletReady===false&&profile.enabled===false));
  const selected=await h.request('/api/games?provider=megah5&profileId=megah5_myr');assert.equal(selected.status,200);assert.equal(selected.data.selectedProvider,'megah5');assert.equal(selected.data.selectedProfileId,'megah5_myr');
  const alias=await h.request('/api/games?profile=megah5_myr');assert.equal(alias.status,200);assert.equal(alias.data.selectedProvider,'megah5');assert.equal(alias.data.selectedProfile.profileId,'megah5_myr');
  assert.equal((await h.request('/api/games?provider=megah5&profile=jili_myr_1to1')).status,400);
 }finally{h.close();}
});

test('918KISS profile selection returns only its independent normal, MY1 or free catalogue',async()=>{
 const h=harness();try{
  const cases=[
   ['918kiss_normal_myr','normal','MYR',92],
   ['918kiss_normal_my1_1to100','my1','MY1',92],
   ['918kiss_free_myr','free','MYR',88],
  ];
  for(const [profileId,account,currency,count] of cases){
   const response=await h.request(`/api/games?profileId=${encodeURIComponent(profileId)}`);assert.equal(response.status,200);
   assert.equal(response.data.selectedProvider,'918kissh5');assert.equal(response.data.selectedProfileId,profileId);assert.equal(response.data.selectedProfile.profileId,profileId);
   assert.equal(response.data.selectedPlatform.catalogueProfileId,profileId);assert.equal(response.data.selectedPlatform.catalogueAccount,account);assert.equal(response.data.selectedPlatform.providerCurrency,currency);assert.equal(response.data.selectedPlatform.cachedGameCount,count);
   assert.equal(response.data.totalGameCount,count);assert.equal(response.data.games.length,count);assert.ok(response.data.games.every(game=>game.profileId===profileId&&game.catalogueAccount===account&&game.providerCurrency===currency&&game.gameCode.startsWith(account+'-')));
   assert.ok(response.data.games.every(game=>game.playable===false));assert.equal(response.data.liveReady,false);assert.equal(response.data.launchProvider,null);
  }
  assert.deepEqual(h.catalogueCalls.map(call=>[call.account,call.currency]),[['normal','MYR'],['my1','MY1'],['free','MYR']]);
  assert.equal(h.calls.length,0);assert.deepEqual(h.sqlite.prepare("SELECT provider_id FROM game_catalogue_cache WHERE provider_id LIKE '918kiss_%' ORDER BY provider_id").all().map(row=>row.provider_id),cases.map(([profileId])=>profileId).sort());
  assert.equal(h.sqlite.prepare("SELECT COUNT(*) count FROM game_catalogue_cache WHERE provider_id='918kissh5'").get().count,0,'profile reads must not borrow the provider-level normal cache');
 }finally{h.close();}
});

test('META GAMING profile selection keeps normal and free-credit catalogues isolated and unplayable',async()=>{
 const h=harness();try{
  const cases=[['metagaming_free_myr','free',2],['metagaming_normal_myr','normal',3]];
  for(const [profileId,account,count] of cases){
   const response=await h.request(`/api/games?profileId=${encodeURIComponent(profileId)}`);assert.equal(response.status,200);
   assert.equal(response.data.selectedProvider,'metagaming');assert.equal(response.data.selectedProfileId,profileId);assert.equal(response.data.selectedProfile.profileId,profileId);
   assert.equal(response.data.selectedPlatform.catalogueProfileId,profileId);assert.equal(response.data.selectedPlatform.catalogueAccount,account);assert.equal(response.data.selectedPlatform.providerCurrency,'MYR');assert.equal(response.data.selectedPlatform.cachedGameCount,count);
   assert.equal(response.data.selectedPlatform.connectionVerified,true);assert.equal(response.data.selectedPlatform.catalogueCacheStatus,'available');assert.equal(response.data.selectedPlatform.catalogueCacheFresh,true);
   assert.equal(response.data.games.length,count);assert.ok(response.data.games.every(game=>game.profileId===profileId&&game.catalogueAccount===account&&game.providerCurrency==='MYR'&&game.gameCode.startsWith(`meta-${account}-`)&&game.category==='1'&&game.imageUrl==='/assets/providers/metagaming.webp'&&game.playable===false));
   assert.equal(response.data.playable,false);assert.equal(response.data.liveReady,false);assert.equal(response.data.launchProvider,null);
  }
  assert.deepEqual(h.catalogueCalls.map(call=>[call.account,call.currency]),[['free','MYR'],['normal','MYR']]);
  assert.deepEqual(h.sqlite.prepare("SELECT provider_id FROM game_catalogue_cache WHERE provider_id LIKE 'metagaming_%' ORDER BY provider_id").all().map(row=>row.provider_id),cases.map(([profileId])=>profileId).sort());
 }finally{h.close();}
});

test('non-executable and mismatched launch profiles fail before any game state or supplier request',async()=>{
 const h=harness();try{
  const cases=[
   [{providerId:'918kissh5',profileId:'918kiss_normal_myr',gameCode:'fixture'},503,'GAME_PROVIDER_UNAVAILABLE','adapter_unimplemented'],
   [{providerId:'fuma',profileId:'fuma_myr',gameCode:'fixture'},503,'GAME_PROVIDER_UNAVAILABLE','contract_missing'],
   [{providerId:'megah5',profileId:'jili_myr_1to1',gameCode:'55021'},400,'GAME_PROFILE_PROVIDER_MISMATCH','profile_provider_mismatch'],
   [{providerId:'jili',gameCode:'fixture'},400,'GAME_PROFILE_REQUIRED','multiple_profiles'],
  ];
  for(const [data,status,code,reason] of cases){
   const response=await h.request('/api/game-launch',{method:'POST',data});assert.equal(response.status,status);assert.equal(response.data.code,code);assert.equal(response.data.reason,reason);
  }
  assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('wallet profile reads preserve MegaH5 and expose unimplemented profiles without enabling them',async()=>{
 const h=harness();try{
  const legacy=await h.request('/api/game-wallet');assert.equal(legacy.status,200);assert.equal(legacy.data.profileId,'megah5_myr');
  const explicit=await h.request('/api/game-wallet?profileId=megah5_myr');assert.equal(explicit.status,200);assert.equal(explicit.data.profileId,'megah5_myr');
  const foreign=await h.request('/api/game-wallet?profileId=918kiss_normal_myr');assert.equal(foreign.status,200);assert.equal(foreign.data.profileId,'918kiss_normal_myr');assert.equal(foreign.data.readOnly,true);assert.equal(foreign.data.walletReady,false);assert.equal(foreign.data.supportsRecovery,false);
  const settle=await h.request('/api/game-wallet/settle',{method:'POST',data:{profileId:'megah5_myr'}});assert.equal(settle.status,200);assert.equal(settle.data.profileId,'megah5_myr');assert.equal(settle.data.status,'none');
  const rejected=await h.request('/api/game-wallet/recover',{method:'POST',data:{profileId:'fuma_myr'}});assert.equal(rejected.status,503);assert.equal(rejected.data.reason,'contract_missing');
  assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
 }finally{h.close();}
});

test('unverified acceptance blocks the public launch before any wallet transfer',async()=>{
 const h=harness();try{
  h.sqlite.exec('DELETE FROM wallet_ledger; DELETE FROM deposit_orders;');
  const result=await h.launch();assert.equal(result.status,503);assert.match(result.data.error,/acceptance is pending/);
  assert.equal(h.calls.filter(call=>call.path==='/platform/megah5/deposit'||call.path==='/platform/megah5/session').length,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('a production-accepted launch still requires a reviewed exact origin allowlist before any wallet call',async()=>{
 for(const origins of [undefined,'[]','["http://launch.example.test"]','["https://*.example.test"]']){
  const h=harness();try{
   acceptMega(h);const result=await h.launch({...verifiedClosure,megaLaunchOriginsJson:origins});
   assert.equal(result.status,503,String(origins));assert.match(result.data.error,/capability is unavailable/);
   assert.equal(h.capabilityCalls.length,0);assert.equal(h.calls.length,0);
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
   assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
  }finally{h.close();}
 }
});

test('a production-accepted launch returns only a URL from the reviewed exact origin',async()=>{
 const h=harness();try{
  acceptMega(h);const result=await h.launch(verifiedClosure);
  assert.equal(result.status,200,JSON.stringify(result));assert.equal(result.data.launchUrl,'https://launch.example.test/session');
  assert.deepEqual(h.calls.map(call=>call.path),['/platform/megah5/balance','/platform/megah5/deposit','/platform/megah5/session']);
  assert.equal(h.sqlite.prepare("SELECT state FROM megah5_launch_operations").get().state,'issued');
 }finally{h.close();}
});

test('an unapproved HTTPS GameLogin origin is withheld and leaves the funded attempt recoverable',async()=>{
 const h=harness();try{
  acceptMega(h);h.fixture.sessionUrl='https://launch.example.test.evil.invalid/session';
  const result=await h.launch(verifiedClosure);assert.equal(result.status,502);assert.match(result.data.error,/launch URL is invalid/);assert.equal(result.data.launchUrl,undefined);
  assert.deepEqual(h.calls.map(call=>call.path),['/platform/megah5/balance','/platform/megah5/deposit','/platform/megah5/session']);
  assert.equal(h.sqlite.prepare("SELECT state FROM megah5_launch_operations").get().state,'unknown');
  assert.equal(h.sqlite.prepare("SELECT status FROM game_wallet_sessions").get().status,'active');
  assert.equal(h.sqlite.prepare("SELECT COUNT(*) n FROM wallet_reservations WHERE kind='game'").get().n,1);
 }finally{h.close();}
});

test('a stale session identifier cannot settle or recover the member’s current game',async()=>{
 const h=harness();try{
  assert.equal((await h.prepareWallet()).walletVerified,true);const before=h.calls.length;
  for(const path of ['/api/game-wallet/settle','/api/game-wallet/recover']){
   const result=await h.request(path,{method:'POST',data:{profileId:'megah5_myr',sessionId:'previous-session'}});assert.equal(result.status,409);
  }
  assert.equal(h.calls.length,before);assert.equal(h.sqlite.prepare('SELECT status FROM game_wallet_sessions').get().status,'active');
 }finally{h.close();}
});

test('Godee credentials cannot make an old ATG cache appear connected or expose Godee publicly',async()=>{
 const h=harness();try{
  const stamp=Math.floor(Date.now()/1000),old=JSON.stringify([{provider:'atg',gameCode:'old-atg-game',name:'Old game'}]);
  h.sqlite.prepare("INSERT INTO game_catalogue_cache(provider_id,status,games_json,checked_at,last_success_at,lease_until,complete) VALUES('atg','available',?,?,?,0,1)").run(old,stamp,stamp);
  let external=0;const extra={godeeApiBase:'https://api.godeezone1.com',godeeOperatorId:'fixture-operator',godeeApiKey:'fixture-private-key',gameCatalogueFetch:async()=>{external++;throw Error('unexpected supplier call');}};
  const summary=await h.request('/api/games',{extra});assert.equal(summary.status,200);
  assert.equal(summary.data.providers.find(p=>p.id==='atg').connectionVerified,false);
  assert.equal(summary.data.providers.some(p=>p.id==='godeezone'),false);
  const atg=await h.request('/api/games?provider=atg',{extra});assert.deepEqual(atg.data.games,[]);
  assert.equal((await h.request('/api/games?provider=godeezone',{extra})).status,400);
  assert.equal(external,0);assert.equal(h.sqlite.prepare("SELECT games_json FROM game_catalogue_cache WHERE provider_id='atg'").get().games_json,old);
 }finally{h.close();}
});

test('configuration and legacy flags cannot create game acceptance evidence',async()=>{
 const h=harness();try{
  for(const value of ['false','true']){
   const extra={megaSettlementVerified:value,megaLiveGamesEnabled:'true',megaTransfersEnabled:'true'};
   const selected=await h.request('/api/games?provider=megah5',{extra}),provider=selected.data.providers.find(item=>item.id==='megah5');
   assert.equal(provider.walletReady,true);assert.equal(provider.launchVerified,false);assert.equal(provider.walletVerified,false);assert.equal(provider.settlementVerified,false);
   assert.equal(provider.platformLaunchReady,false);assert.equal(provider.capabilityReason,'session_closure_contract_unavailable');assert.ok(selected.data.games.every(game=>game.playable===false));
   assert.equal((await h.launch(extra)).status,503);
  }
  assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('automatic readiness still requires credentials, complete fresh catalogue and vendor availability',async()=>{
 const h=harness();try{
  for(const extra of [{gameGatewayToken:''},{gameGatewayWalletToken:gameToken},{gameGatewayUrl:'https://untrusted.example.test'}]){
   const summary=await h.request('/api/games',{extra});assert.equal(summary.data.liveReady,false);
  }
  for(const statement of ["complete=0","complete=1,status='blocked'","status='available',games_json='invalid'","games_json='[]'"]){
   h.sqlite.prepare("UPDATE game_catalogue_cache SET "+statement+" WHERE provider_id='megah5'").run();
   assert.equal((await h.request('/api/games')).data.liveReady,false);
  }
  h.sqlite.prepare("UPDATE game_catalogue_cache SET games_json=? WHERE provider_id='megah5'").run(JSON.stringify([{...game,maintenance:true}]));
  assert.equal((await h.launch()).status,503);assert.equal(h.calls.length,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
 }finally{h.close();}
});

test('gateway flags alone cannot open games without all transfer and recovery contracts',async()=>{
 for(const modify of [data=>{data.megah5Transfer.credentialsConfigured=false;},data=>{data.megah5Transfer.walletTokenConfigured=false;},data=>{delete data.megah5Transfer.channels.status;},data=>{data.megah5Transfer.channels.withdrawal.configurationReady=false;},data=>{data.megah5Transfer.channels.deposit.blockers=['provider_credentials_missing_or_invalid'];}]){
  const h=harness();try{
   modify(h.fixture.capability);const response=await h.request('/api/games');assert.equal(response.data.liveReady,false);
   const provider=response.data.providers.find(provider=>provider.id==='megah5');assert.equal(provider.walletReady,false);assert.equal(provider.launchVerified,false);
   assert.equal((await h.launch()).status,503);assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
  }finally{h.close();}
 }
});

test('a cached summary expires at the catalogue refresh boundary without contacting the supplier',async()=>{
 const h=harness();try{
  const checkedAt=1700000000;
  h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=?,last_success_at=? WHERE provider_id='megah5'").run(checkedAt,checkedAt);
  const expiredCalls=[];
  const rejectedRefresh=async(url,init)=>{if(new URL(url).pathname==='/readiness')return Response.json(megaCapabilityFixture());expiredCalls.push({path:new URL(url).pathname,method:init.method});return Response.json({error:'provider_unavailable'},{status:502});};
  const selectedFresh=await h.request('/api/games?provider=megah5',{extra:{gameSyncNow:()=>checkedAt+299,gameGatewayFetch:rejectedRefresh}});
  assert.equal(selectedFresh.data.liveReady,false);assert.equal(selectedFresh.data.selectedPlatform.connectionVerified,true);assert.equal(expiredCalls.length,0);
  for(const [elapsed,expected] of [[299,true],[300,false],[301,false]]){
   const summary=await h.request('/api/games',{extra:{gameSyncNow:()=>checkedAt+elapsed,gameGatewayFetch:rejectedRefresh}});
   assert.equal(summary.status,200);assert.equal(summary.data.liveReady,false,'cache age '+elapsed);
   assert.equal(summary.data.providers.find(provider=>provider.id==='megah5').connectionVerified,expected,'cache age '+elapsed);
   assert.equal(expiredCalls.length,0,'the summary must never attempt a refresh');
  }
  const selectedExpired=await h.request('/api/games?provider=megah5',{extra:{gameSyncNow:()=>checkedAt+300,gameGatewayFetch:rejectedRefresh}});
  assert.equal(selectedExpired.data.liveReady,false);
  assert.deepEqual(expiredCalls,[{path:'/providers/megah5/games',method:'GET'}]);
  assert.equal(h.calls.length,0);
 }finally{h.close();}
});

test('unverified MegaH5 launch does not refresh a catalogue or transfer wallet funds',async()=>{
 const h=harness();try{
  h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=0 WHERE provider_id='megah5'").run();
  const launched=await h.launch();assert.equal(launched.status,503);assert.match(launched.data.error,/acceptance is pending/);
  assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('an incomplete catalogue cannot launch or reserve money through a direct POST',async()=>{
 const h=harness();try{
  h.sqlite.prepare("UPDATE game_catalogue_cache SET complete=0 WHERE provider_id='megah5'").run();
  const selected=await h.request('/api/games?provider=megah5');assert.equal(selected.data.playable,false);
  const launched=await h.launch();assert.equal(launched.status,503);
  assert.equal(h.calls.length,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,0);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) count FROM wallet_reservations').get().count,0);
  assert.equal((await withdrawalWalletState(h.db,'member')).availableMinor,'2000');
 }finally{h.close();}
});

test('an unverified profile cannot call GameLogin for any mocked response status',async()=>{
 for(const status of [200,403,'403',undefined]){
  const h=harness();try{
   h.fixture.sessionStatus=status;const launched=await h.launch();assert.equal(launched.status,503,String(status));
   assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
  }finally{h.close();}
 }
});

test('repeated unverified launch requests cannot create a transfer',async()=>{
 const h=harness();try{
  h.fixture.sessionStatus='200';assert.equal((await h.launch()).status,503);assert.equal((await h.launch()).status,503);
  assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
 }finally{h.close();}
});

test('retired owner availability endpoints perform zero database writes and retain authentication',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner@example.test','owner',1,'fixture-csrf',0)").run();
  const owner={identity:{userId:'owner',email:'owner@example.test'}},requests=[
   ['/api/admin/supplier-art',{providerId:'megah5',status:'closed'}],
   ['/api/admin/provider',{id:'megah5',visible:false}],
   ['/api/admin/game-visibility',{providerId:'megah5',gameCode:'55021',status:'suspended'}],
   ['/api/admin/custom-games',{action:'toggle',id:'mini-fixture',enabled:true}],
   ['/api/admin/custom-games',{action:'status',id:'mini-fixture',status:'active'}],
  ];
  for(const [path,data] of requests){
   const before=h.sqlite.prepare('SELECT total_changes() n').get().n;
   const response=await h.request(path,{method:'POST',data,extra:owner});
   assert.equal(response.status,410,path);assert.equal(response.data.availabilityMode,'automatic');assert.equal(response.data.readOnlyAvailability,true);
   assert.equal(h.sqlite.prepare('SELECT total_changes() n').get().n,before,path+' must not write an audit, rate limit or availability row');
   assert.equal((await h.request(path,{method:'POST',data})).status,403);
  }
  assert.equal(h.calls.length,0);assert.equal(h.capabilityCalls.length,0);
 }finally{h.close();}
});

test('editorial updates retain historical status without enabling a custom mini engine',async()=>{
 const h=harness();try{
  h.sqlite.prepare("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner@example.test','owner',1,'fixture-csrf',0)").run();
  h.sqlite.prepare("UPDATE providers SET visible=0 WHERE id='megah5'").run();h.sqlite.prepare("UPDATE api_supplier_artwork SET status='closed' WHERE provider_id='megah5'").run();h.sqlite.prepare("UPDATE game_visibility SET visible=0,status='closed' WHERE provider_id='megah5'").run();
  const extra={identity:{userId:'owner',email:'owner@example.test'}},imageData='data:image/png;base64,iVBORw0KGgoAAAAAAAAAAAAAAAA=';
  for(const [path,data] of [['/api/admin/provider',{id:'megah5',imageData}],['/api/admin/supplier-art',{providerId:'megah5',imageData}],['/api/admin/game-visibility',{providerId:'megah5',gameCode:'55021',accessZone:'free',category:'LIVE',imageData}]])assert.equal((await h.request(path,{method:'POST',data,extra})).status,200,path);
  assert.equal(h.sqlite.prepare("SELECT visible FROM providers WHERE id='megah5'").get().visible,0);
  assert.equal(h.sqlite.prepare("SELECT status FROM api_supplier_artwork WHERE provider_id='megah5'").get().status,'closed');
  const override=h.sqlite.prepare("SELECT visible,status,category_override,access_zone FROM game_visibility WHERE provider_id='megah5'").get();assert.deepEqual({...override},{visible:0,status:'closed',category_override:'LIVE',access_zone:'free'});
  const selected=(await h.request('/api/games?provider=megah5')).data;assert.equal(selected.games[0].playable,false);assert.equal(selected.games[0].accessZone,'free');assert.equal(selected.games[0].imageData,imageData);
  const saved=await h.request('/api/admin/custom-games',{method:'POST',extra,data:{action:'save',title:'Fixture mini',providerName:'MASTER7',isPlatformMini:true,imageData,enabled:true,status:'active'}});assert.equal(saved.status,201);
  const minis=(await h.request('/api/admin/custom-games',{extra})).data;assert.equal(minis.items[0].launchReady,false);assert.equal(minis.items[0].walletVerified,false);assert.equal(minis.items[0].capabilityReason,'custom_game_engine_not_implemented');
  const publicMinis=(await h.request('/api/custom-games')).data;assert.equal(publicMinis.playable,false);assert.deepEqual(publicMinis.items,[]);
 }finally{h.close();}
});

test('a stale catalogue held by a refresh lease cannot launch with retained games',async()=>{
 const h=harness();try{
  const stamp=Math.floor(Date.now()/1000);h.sqlite.prepare("UPDATE game_catalogue_cache SET checked_at=?,lease_until=? WHERE provider_id='megah5'").run(stamp-600,stamp+30);
  assert.equal((await h.launch()).status,503);assert.equal(h.calls.length,0);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('health and operations readiness consume observations without probing a game supplier',async()=>{
 const h=harness();try{
  const before=await h.request('/health');assert.equal(before.data.liveGames,false);assert.equal(h.capabilityCalls.length,0);
  assert.equal((await h.request('/api/games')).data.liveReady,false);assert.equal(h.capabilityCalls.length,0);const count=h.capabilityCalls.length;
  const after=await h.request('/health',{extra:{megaSettlementVerified:'false'}});assert.equal(after.data.liveGames,false);assert.equal(after.data.megaWallet.liveReady,false);assert.ok(after.data.readinessBlockers.includes('game_launch_or_settlement_not_ready'));assert.equal(after.data.megaWallet.launchVerified,false);assert.equal(after.data.megaWallet.walletVerified,false);assert.equal(after.data.megaWallet.settlementVerified,false);
  assert.equal(h.capabilityCalls.length,count);assert.equal(h.calls.length,0);
  const changed=await h.request('/health',{extra:{gameGatewayWalletToken:'changed'.repeat(8)}});assert.equal(changed.data.liveGames,false);assert.equal(h.capabilityCalls.length,count);
 }finally{h.close();}
});

test('an existing game session can settle after the manual review gate is enabled',async()=>{
 const h=harness();try{
  const opened=await h.prepareWallet();assert.equal(opened.walletVerified,true);
  const extra={manualComplianceEnforced:'true'};
  const blocked=await h.launch(extra);assert.equal(blocked.status,403);assert.equal(blocked.data.code,'COMPLIANCE_REVIEW_REQUIRED');
  const settled=await h.request('/api/game-wallet/settle',{method:'POST',data:{},extra});assert.equal(settled.status,200);assert.equal(settled.data.status,'settled');
  assert.equal((await h.request('/api/game-wallet/settle',{method:'POST',data:{},extra})).data.status,'none');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});

test('new-game maintenance defaults closed while an existing game can settle exactly once',async()=>{
 const h=harness();try{
  for(const flag of [undefined,'false','TRUE']){
   h.context.newGameLaunchesEnabled=flag;
   const denied=await h.launch();assert.equal(denied.status,503);assert.equal(denied.data.code,'GAMES_MAINTENANCE');assert.equal(h.calls.length,0);
   const selected=await h.request('/api/games?provider=megah5');assert.equal(selected.data.playable,false);assert.equal(selected.data.selectedPlatform.platformLaunchReady,false);assert.equal(selected.data.selectedPlatform.capabilityReason,'new_game_launches_paused');
  }
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_sessions').get().n,0);
  h.context.newGameLaunchesEnabled='true';assert.equal((await h.prepareWallet()).walletVerified,true);
  h.context.newGameLaunchesEnabled='false';const wallet=await h.request('/api/game-wallet');assert.equal(wallet.data.walletReady,true);assert.equal(wallet.data.liveReady,false);
  const blocked=await h.launch();assert.equal(blocked.data.code,'GAMES_MAINTENANCE');
  const settled=await h.request('/api/game-wallet/settle',{method:'POST',data:{}});assert.equal(settled.status,200);assert.equal(settled.data.status,'settled');
  assert.equal((await h.request('/api/game-wallet/settle',{method:'POST',data:{}})).data.status,'none');
  assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM game_wallet_ledger').get().n,1);assert.equal(h.sqlite.prepare('SELECT COUNT(*) n FROM wallet_reservations').get().n,0);
 }finally{h.close();}
});
