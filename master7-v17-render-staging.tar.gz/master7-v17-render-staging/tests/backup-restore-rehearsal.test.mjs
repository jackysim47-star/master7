import test from 'node:test';
import assert from 'node:assert/strict';
import {constants,createCipheriv,createDecipheriv,createHash,createPublicKey,generateKeyPairSync,privateDecrypt,publicEncrypt,randomBytes} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {mkdtempSync,readFileSync,readdirSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {DatabaseSync} from 'node:sqlite';
import {gunzipSync,gzipSync} from 'node:zlib';
import {BACKUP_EXCLUDED_TABLES,BACKUP_SCHEMA_VERSION,BACKUP_TABLES,createEncryptedPortalBackup} from '../lib/encrypted-backup.ts';

const root=fileURLToPath(new URL('..',import.meta.url));
const gameAdapterTables=['game_provider_profiles','game_provider_players','game_provider_sessions','game_wallet_transfers','game_rounds','game_transactions','game_wallet_postings','game_callback_receipts','game_wager_sync_cursors','game_recovery_leases'];
const acceptanceTables=['game_provider_acceptance_events','game_provider_acceptance_current'];

async function fixture(t){
 const directory=mkdtempSync(join(tmpdir(),'master7-synthetic-restore-'));
 const sqlite=new DatabaseSync(':memory:');
 t.after(()=>{sqlite.close();rmSync(directory,{recursive:true,force:true});});
 sqlite.exec('PRAGMA foreign_keys=ON');
 for(const migration of readdirSync(join(root,'drizzle')).filter(name=>/^\d{4}_.+\.sql$/.test(name)).sort())sqlite.exec(readFileSync(join(root,'drizzle',migration),'utf8'));
 sqlite.exec(`
  INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES
   ('restore-owner','synthetic_restore_owner','owner',1,'synthetic-owner-csrf',1),
   ('restore-member','synthetic_restore_member','member',1,'synthetic-member-csrf',1);
  INSERT INTO benefit_rules(id,title,description,rules_json,status,created_by,created_at,updated_at)
   VALUES('restore-benefit','Synthetic benefit','Local fixture only','{}','draft','restore-owner',1,1);
  INSERT INTO benefit_claims(id,user_id,benefit_rule_id,request_key,rules_snapshot_json,reward_minor,expires_at,created_at,updated_at,review_status,reviewed_by,reviewed_at,review_note)
   VALUES('restore-claim','restore-member','restore-benefit','restore-request','{}',8800,9999999999,1,2,'approved_pending_settlement','restore-owner',2,'Synthetic eligibility evidence');
  INSERT INTO voucher_manual_reviews(claim_id,status,max_plays,plays_used,won_once,turnover_required_minor,payout_cap_minor,approved_by,approved_at,created_at,updated_at)
   VALUES('restore-claim','approved',5,1,0,8800,8800,'restore-owner',2,2,3);
  INSERT INTO voucher_manual_play_events(id,claim_id,play_number,outcome,evidence_reference,recorded_by,created_at)
   VALUES('restore-play','restore-claim',1,'loss','synthetic-local-evidence','restore-owner',3);
  INSERT INTO password_sessions(token_hash,user_id,csrf,credential_version,expires_at,created_at)
   VALUES('synthetic-session-hash','restore-member','synthetic-session-csrf',1,9999999999,1);
  INSERT INTO rate_limits(id,count,expires_at) VALUES('synthetic-limit',1,9999999999);
  INSERT INTO marketing_contacts(id,phone,name,consent_status,source,created_at,updated_at)
   VALUES('restore-contact','+60100000001','Synthetic contact','opted_out','local_fixture',1,1);
  INSERT INTO marketing_campaigns(id,name,channel,message,status,created_by,created_at,updated_at,provider,template_name,template_params_json,audience_count)
   VALUES('restore-campaign','Synthetic campaign','whatsapp','Local fixture only','paused','restore-owner',1,1,'whatsapp_business','synthetic_template','{"1":"local fixture"}',1);
  INSERT INTO marketing_deliveries(campaign_id,contact_id,status,provider_message_id,updated_at,claim_token,locked_until,submitted_at,delivered_at)
   VALUES('restore-campaign','restore-contact','delivered','synthetic-message',3,NULL,0,2,3);
  INSERT INTO marketing_webhook_events(event_key,provider_message_id,event_type,status,payload_hash,received_at)
   VALUES('synthetic-webhook','synthetic-message','status','delivered','synthetic-payload-hash',3);
  INSERT INTO responsible_play_locks(user_id,touched_at) VALUES('restore-member',3);
  INSERT INTO member_wallet_guards(user_id,revision) VALUES('restore-member',5);
  INSERT INTO responsible_play_profiles(user_id,daily_limit_minor,self_excluded_until,last_change_id,created_at,updated_at)
   VALUES('restore-member',10000,9999999999,'synthetic-profile-change',1,3);
  INSERT INTO responsible_play_deposit_reservations(user_id,request_key,provider,amount_minor,status,expires_at,created_at,updated_at)
   VALUES('restore-member','synthetic-reservation','vpay',1000,'reserved',9999999999,1,3);
  INSERT INTO manual_compliance_reviews(user_id,identity_status,aml_status,version,last_change_id,created_at,updated_at)
   VALUES('restore-member','passed','pending',2,'synthetic-review',1,3);
  INSERT INTO manual_compliance_events(id,user_id,reviewer_id,review_type,decision,created_at)
   VALUES('synthetic-review','restore-member','restore-owner','identity','passed',3);
  INSERT INTO game_wallet_sessions(id,user_id,provider,player_id,game_code,status,amount_out_minor,deposit_reference,created_at,updated_at)
   VALUES('restore-wallet-session','restore-member','megah5','synthetic-player','55021','active',100,'synthetic-deposit',1,3);
  INSERT INTO megah5_launch_operations(id,wallet_session_id,user_id,game_code,state,created_at,updated_at,last_error)
   VALUES('restore-launch','restore-wallet-session','restore-member','55021','unknown',2,3,'synthetic-timeout');
  INSERT INTO game_provider_acceptance_events(id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
   VALUES('restore-acceptance','megah5_myr',1,'catalogue','production','passed','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','restore:acceptance','restore-owner',2,3);
  INSERT INTO game_provider_acceptance_current(profile_id,capability,environment,event_id)
   VALUES('megah5_myr','catalogue','production','restore-acceptance');
 `);
 assert.deepEqual(sqlite.prepare('PRAGMA foreign_key_check').all(),[]);
 const schemaTables=sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(row=>row.name);
 assert.deepEqual(schemaTables,[...BACKUP_TABLES,...BACKUP_EXCLUDED_TABLES].sort(),'Every release table must be durable or explicitly transient');
 const passphrase=randomBytes(32).toString('hex');
 const {publicKey,privateKey}=generateKeyPairSync('rsa',{
  modulusLength:2048,
  publicKeyEncoding:{type:'spki',format:'pem'},
  privateKeyEncoding:{type:'pkcs8',format:'pem',cipher:'aes-256-cbc',passphrase},
 });
 const fingerprint=createHash('sha256').update(createPublicKey(publicKey).export({type:'spki',format:'der'})).digest('hex');
 const db={prepare(sql){return {bind(...values){return {all:async()=>({results:sqlite.prepare(sql).all(...values)})};}};}};
 const {envelope}=await createEncryptedPortalBackup(db,'synthetic-release-0107',{publicKey,publicKeySha256:fingerprint});
 const backup=join(directory,'synthetic-backup.json'),key=join(directory,'synthetic-private.pem'),pass=join(directory,'synthetic-passphrase.txt'),receipt=join(directory,'synthetic-receipt.json');
 writeFileSync(backup,JSON.stringify(envelope),{mode:0o600});
 writeFileSync(key,privateKey,{mode:0o600});
 writeFileSync(pass,passphrase,{mode:0o600});
 return {sqlite,envelope,backup,key,pass,receipt,publicKey,privateKey,passphrase};
}

function repack(f,change){
 const hash=value=>createHash('sha256').update(value).digest('hex');
 const key=privateDecrypt({key:f.privateKey,passphrase:f.passphrase,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(f.envelope.encryptedKey,'base64'));
 const decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(f.envelope.iv,'base64'));
 decipher.setAuthTag(Buffer.from(f.envelope.authTag,'base64'));
 const payload=JSON.parse(gunzipSync(Buffer.concat([decipher.update(Buffer.from(f.envelope.ciphertext,'base64')),decipher.final()])).toString('utf8'));
 change(payload);
 payload.manifest.tables=payload.manifest.tables.map(table=>({...table,rows:payload.tables[table.name].length,sha256:hash(JSON.stringify(payload.tables[table.name]))}));
 payload.manifest.tableCount=payload.manifest.tables.length;
 payload.manifest.totalRecords=payload.manifest.tables.reduce((sum,table)=>sum+table.rows,0);
 const plaintext=Buffer.from(JSON.stringify(payload)),contentKey=randomBytes(32),iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',contentKey,iv);
 const ciphertext=Buffer.concat([cipher.update(gzipSync(plaintext)),cipher.final()]);
 const envelope={...f.envelope,schemaVersion:payload.schemaVersion,schemaSha256:payload.schemaSha256,manifest:{...payload.manifest,tables:payload.manifest.tables.map(({name,rows})=>({name,rows}))},encryptedKey:publicEncrypt({key:f.publicKey,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},contentKey).toString('base64'),iv:iv.toString('base64'),authTag:cipher.getAuthTag().toString('base64'),ciphertext:ciphertext.toString('base64'),ciphertextSha256:hash(ciphertext),plaintextSha256:hash(plaintext)};
 writeFileSync(f.backup,JSON.stringify(envelope),{mode:0o600});
}

function verify(f){return spawnSync(process.execPath,[join(root,'scripts/verify-encrypted-backup.mjs'),f.backup,f.key,f.pass,f.receipt],{cwd:root,encoding:'utf8',timeout:30000});}

test('current release backup restores acceptance evidence and reviewed benefit columns in isolation',async t=>{
 const f=await fixture(t);
 assert.equal(BACKUP_SCHEMA_VERSION,'0113-game-provider-acceptance');
 assert.equal(f.envelope.manifest.tableCount,BACKUP_TABLES.length);
 for(const table of ['benefit_claims','voucher_manual_reviews','voucher_manual_play_events','marketing_webhook_events','responsible_play_profiles','responsible_play_deposit_reservations'])assert.equal(f.envelope.manifest.tables.find(item=>item.name===table).rows,1);
 for(const table of gameAdapterTables)assert.equal(f.envelope.manifest.tables.find(item=>item.name===table).rows,0);
 assert.equal(f.envelope.manifest.tables.find(item=>item.name==='megah5_launch_operations').rows,1);
 for(const table of acceptanceTables)assert.equal(f.envelope.manifest.tables.find(item=>item.name===table).rows,1);
 // The launch uncertainty is financial recovery evidence, not an ephemeral
 // lock.  Ensure it is actually present in the encrypted payload being restored.
 repack(f,payload=>{
  assert.deepEqual(payload.tables.megah5_launch_operations.map(row=>({id:row.id,state:row.state,wallet_session_id:row.wallet_session_id})),[{id:'restore-launch',state:'unknown',wallet_session_id:'restore-wallet-session'}]);
 });
 const result=verify(f);
 assert.equal(result.status,0,result.stderr);
 const receipt=JSON.parse(readFileSync(f.receipt,'utf8'));
 assert.equal(receipt.tableCount,BACKUP_TABLES.length);
 assert.equal(receipt.totalRecords,f.envelope.manifest.totalRecords);
 assert.equal(receipt.foreignKeyViolations,0);
 assert.equal(receipt.status,'verified');
 assert.equal(receipt.coverageComplete,true);
 assert.equal(receipt.readConsistency,'unverified');
 assert.deepEqual(receipt.missingTables,[]);
 assert.equal(receipt.restoreTarget,'isolated in-memory SQLite schema');
 assert.deepEqual(receipt.tables.map(item=>item.name),[...BACKUP_TABLES]);
 assert.deepEqual(receipt.excludedTables,{password_sessions:0,otp_challenges:0,rate_limits:0,responsible_play_locks:0,member_wallet_guards:0});
});

test('restore refuses a backup from a different schema instead of dropping its fields',async t=>{
 const f=await fixture(t);
 writeFileSync(f.backup,JSON.stringify({...f.envelope,schemaVersion:'incompatible-schema'}),{mode:0o600});
 const result=verify(f);
 assert.notEqual(result.status,0);
 assert.match(result.stderr,/Backup schema version does not match this release/);
});

test('previous 0112 backup is recoverable but cannot certify acceptance evidence coverage',async t=>{
 const f=await fixture(t),oldHash='2ce57d7e348bdee3a0b6e145d19479a113136ccadc61e9fdfda2e1511a6a3e3b';
 repack(f,payload=>{
  payload.schemaVersion='0112-megah5-launch-operations';
  for(const name of acceptanceTables)delete payload.tables[name];
  payload.manifest.tables=payload.manifest.tables.filter(table=>!acceptanceTables.includes(table.name));
  assert.equal(createHash('sha256').update(JSON.stringify({format:payload.format,schemaVersion:payload.schemaVersion,tables:payload.manifest.tables.map(table=>table.name)})).digest('hex'),oldHash);
  payload.schemaSha256=oldHash;
 });
 const result=verify(f);assert.equal(result.status,0,result.stderr);
 const receipt=JSON.parse(readFileSync(f.receipt,'utf8'));
 assert.equal(receipt.status,'verified_legacy_coverage');assert.equal(receipt.coverageComplete,false);
 assert.deepEqual(receipt.missingTables,acceptanceTables);
});

test('previous 0110 backup is recoverable but cannot certify launch-operation coverage',async t=>{
 const f=await fixture(t),oldHash='4a1e7437fb14dc212ec39a801e173f7e898fcfa44707e7b523f5c8ba299b1555';
 repack(f,payload=>{
  payload.schemaVersion='0110-game-provider-adapter-core';
  delete payload.tables.megah5_launch_operations;for(const name of acceptanceTables)delete payload.tables[name];
  payload.manifest.tables=payload.manifest.tables.filter(table=>table.name!=='megah5_launch_operations'&&!acceptanceTables.includes(table.name));
  assert.equal(createHash('sha256').update(JSON.stringify({format:payload.format,schemaVersion:payload.schemaVersion,tables:payload.manifest.tables.map(table=>table.name)})).digest('hex'),oldHash);
  payload.schemaSha256=oldHash;
 });
 const result=verify(f);assert.equal(result.status,0,result.stderr);
 const receipt=JSON.parse(readFileSync(f.receipt,'utf8'));
 assert.equal(receipt.status,'verified_legacy_coverage');assert.equal(receipt.coverageComplete,false);
 assert.deepEqual(receipt.missingTables,['megah5_launch_operations',...acceptanceTables]);
});

test('known 0108 backup remains recoverable and reports every missing adapter table',async t=>{
 const f=await fixture(t),oldHash='6453a7551fd5cbc19e6b7ca6728405f4ead79db7864b5b8d52186905bcb8798a';
 repack(f,payload=>{
  payload.schemaVersion='0108-manual-compliance-review';
  for(const name of [...gameAdapterTables,'megah5_launch_operations',...acceptanceTables])delete payload.tables[name];
  payload.manifest.tables=payload.manifest.tables.filter(table=>![...gameAdapterTables,'megah5_launch_operations',...acceptanceTables].includes(table.name));
  assert.equal(createHash('sha256').update(JSON.stringify({format:payload.format,schemaVersion:payload.schemaVersion,tables:payload.manifest.tables.map(table=>table.name)})).digest('hex'),oldHash);
  payload.schemaSha256=oldHash;
 });
 const result=verify(f);assert.equal(result.status,0,result.stderr);
 const receipt=JSON.parse(readFileSync(f.receipt,'utf8'));assert.equal(receipt.status,'verified_legacy_coverage');
 assert.deepEqual(receipt.missingTables,[...gameAdapterTables,'megah5_launch_operations',...acceptanceTables]);
});

test('known 0107 legacy backup remains recoverable with explicit incomplete-coverage receipt',async t=>{
 const f=await fixture(t),legacyHash='2648becd21723884358bcaf90f5928dc19c7cc58dcf090c87ca1db3c00c34d69';
 repack(f,payload=>{
  payload.schemaVersion='0107-benefit-claim-reviews';
  delete payload.tables.manual_compliance_reviews;delete payload.tables.manual_compliance_events;
  delete payload.tables.marketing_webhook_events;
  for(const name of [...gameAdapterTables,'megah5_launch_operations',...acceptanceTables])delete payload.tables[name];
  payload.manifest.tables=payload.manifest.tables.filter(table=>!['marketing_webhook_events','manual_compliance_reviews','manual_compliance_events',...gameAdapterTables,'megah5_launch_operations',...acceptanceTables].includes(table.name));
  const calculated=createHash('sha256').update(JSON.stringify({format:payload.format,schemaVersion:payload.schemaVersion,tables:payload.manifest.tables.map(table=>table.name)})).digest('hex');
  assert.equal(calculated,legacyHash);
  payload.schemaSha256=legacyHash;
  delete payload.readConsistency;
  payload.restorePolicy.excludedTables=payload.restorePolicy.excludedTables.filter(name=>name!=='responsible_play_locks');
 });
 const result=verify(f);
 assert.equal(result.status,0,result.stderr);
 const receipt=JSON.parse(readFileSync(f.receipt,'utf8'));
 assert.equal(receipt.status,'verified_legacy_coverage');
 assert.equal(receipt.coverageComplete,false);
 assert.deepEqual(receipt.missingTables,['marketing_webhook_events','manual_compliance_reviews','manual_compliance_events',...gameAdapterTables,'megah5_launch_operations',...acceptanceTables]);
 assert.equal(receipt.schemaSha256,legacyHash);
 assert.equal(receipt.tableCount,50);
 assert.equal(receipt.foreignKeyViolations,0);
 assert.equal(receipt.readConsistency,'unverified');
});

test('previous 0107 full backup stays recoverable and declares missing compliance records',async t=>{
 const f=await fixture(t),oldHash='5ce4d8778d03097b16ef0fff08c1cc6fa05e7ce9a639bce232564a728982cae9';
 repack(f,payload=>{
  payload.schemaVersion='0107-benefit-claim-reviews';
  for(const name of ['manual_compliance_reviews','manual_compliance_events',...gameAdapterTables,'megah5_launch_operations',...acceptanceTables])delete payload.tables[name];
  payload.manifest.tables=payload.manifest.tables.filter(table=>!['manual_compliance_reviews','manual_compliance_events',...gameAdapterTables,'megah5_launch_operations',...acceptanceTables].includes(table.name));
  assert.equal(createHash('sha256').update(JSON.stringify({format:payload.format,schemaVersion:payload.schemaVersion,tables:payload.manifest.tables.map(table=>table.name)})).digest('hex'),oldHash);
  payload.schemaSha256=oldHash;
 });
 const result=verify(f);assert.equal(result.status,0,result.stderr);
 const receipt=JSON.parse(readFileSync(f.receipt,'utf8'));assert.equal(receipt.status,'verified_legacy_coverage');
 assert.deepEqual(receipt.missingTables,['manual_compliance_reviews','manual_compliance_events',...gameAdapterTables,'megah5_launch_operations',...acceptanceTables]);
});

test('restore rejects an unauthenticated envelope snapshot claim',async t=>{
 const f=await fixture(t);
 writeFileSync(f.backup,JSON.stringify({...f.envelope,readConsistency:'transaction_snapshot'}),{mode:0o600});
 const result=verify(f);
 assert.notEqual(result.status,0);
 assert.match(result.stderr,/Backup read consistency metadata mismatch/);
});

test('authenticated backup rows with broken foreign keys still fail isolated restoration',async t=>{
 const f=await fixture(t);
 repack(f,payload=>{payload.tables.benefit_claims[0].user_id='missing-synthetic-member';});
 const result=verify(f);
 assert.notEqual(result.status,0);
 assert.match(result.stderr,/Foreign key validation failed/);
});
