import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,readdirSync,statSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const apkUrl=new URL('../public/downloads/MASTER7-Android-v17.0.52.apk',import.meta.url);
const apk=readFileSync(apkUrl);

test('customer portal publishes the signed MASTER7 Android release',()=>{
  assert.match(html,/href="\/downloads\/MASTER7-Android-v17\.0\.52\.apk" download/);
  assert.ok(statSync(apkUrl).size>50_000);
  assert.equal(apk.subarray(0,2).toString(),'PK');
  const expected=readFileSync(new URL('../public/downloads/MASTER7-Android-v17.0.52.apk.sha256',import.meta.url),'utf8').trim().split(/\s+/)[0];
  assert.equal(createHash('sha256').update(apk).digest('hex'),expected);
});

test('Android wrapper is HTTPS-only and ships without signing secrets',()=>{
  const manifest=readFileSync(new URL('../android-master7/app/src/main/AndroidManifest.xml',import.meta.url),'utf8');
  const build=readFileSync(new URL('../android-master7/app/build.gradle',import.meta.url),'utf8');
  assert.match(manifest,/android:usesCleartextTraffic="false"/);
  assert.match(build,/applicationId 'com\.master7\.portal'/);
  assert.match(build,/versionName '17\.0\.52'/);
  const activity=readFileSync(new URL('../android-master7/app/src/main/java/com/master7/portal/MainActivity.java',import.meta.url),'utf8');
  assert.match(activity,/PRIMARY_URL = "https:\/\/www\.master7\.best\/"/);
  assert.deepEqual(readdirSync(new URL('../android-master7/',import.meta.url)).filter(name=>/keystore|credential/i.test(name)),[]);
});
