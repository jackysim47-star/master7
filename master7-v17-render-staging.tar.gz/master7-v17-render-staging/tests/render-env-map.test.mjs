import { test } from "node:test";
import assert from "node:assert/strict";
import { mapGSPayEnvironment, mapGSPayUsdtEnvironment, mapVPayEnvironment } from "../lib/render-env-map.mjs";

const keys = [
  "VPAY_GATEWAY_URL",
  "VPAY_ORDER_TOKEN",
  "VPAY_QUERY_TOKEN",
  "VPAY_CALLBACK_TOKEN",
  "VPAY_PAYOUT_TOKEN",
  "VPAY_PAYOUT_ENABLED",
  "VPAY_ORDERS_ENABLED",
  "VPAY_MODE",
  "VPAY_TRADER_ID",
  "VPAY_RETURN_URL",
  "VPAY_RECOVERY_ENABLED",
];

test("maps the server-side VPay settings without changing their values", () => {
  const source = Object.fromEntries(keys.map((key, i) => [key, `test-${i}`]));
  assert.deepEqual(mapVPayEnvironment(source), source);
});

test("leaves missing VPay settings unset and does not enable orders by default", () => {
  const mapped = mapVPayEnvironment({});
  assert.deepEqual(Object.keys(mapped).sort(), [...keys].sort());
  assert.ok(Object.values(mapped).every((value) => value === undefined));
});

const gspayKeys = ["GSPAY_API_BASE_URL","GSPAY_AUTH_KEY","GSPAY_SECRET_KEY","GSPAY_CALLBACK_TOKEN","GSPAY_ORDERS_ENABLED","GSPAY_RETURN_URL","GSPAY_RECOVERY_ENABLED","GSPAY_BALANCE_QUERY_ENABLED","GSPAY_PAYOUT_ENABLED","GSPAY_PAYOUT_IP_WHITELIST_CONFIRMED","GSPAY_BANK_TARGETS_JSON"];
test("maps only the server-side GSPAY provider settings",()=>{
 const source=Object.fromEntries(gspayKeys.map((key,index)=>[key,`fixture-${index}`]));
 source.GSPAY_GATEWAY_URL='legacy-must-not-be-forwarded';
 assert.deepEqual(mapGSPayEnvironment(source),Object.fromEntries(gspayKeys.map((key,index)=>[key,`fixture-${index}`])));
 assert.equal(JSON.stringify(mapGSPayEnvironment(source)).includes('legacy-must-not-be-forwarded'),false);
});
test("leaves missing GSPAY provider settings unset and orders disabled by default",()=>{
 const mapped=mapGSPayEnvironment({});assert.deepEqual(Object.keys(mapped).sort(),[...gspayKeys].sort());assert.ok(Object.values(mapped).every(value=>value===undefined));
});

const gspayUsdtKeys=["GSPAY_USDT_API_BASE_URL","GSPAY_USDT_AUTH_KEY","GSPAY_USDT_SECRET_KEY","GSPAY_USDT_CALLBACK_TOKEN","GSPAY_USDT_ORDERS_ENABLED","GSPAY_USDT_RETURN_URL","GSPAY_USDT_CALLBACK_URL","GSPAY_USDT_RECOVERY_ENABLED","GSPAY_USDT_BALANCE_QUERY_ENABLED","GSPAY_USDT_CONTRACT_VERIFIED","GSPAY_USDT_ASSET_NETWORK","GSPAY_USDT_CURRENCY_SCALE","GSPAY_USDT_CHECKOUT_ORIGIN"];
test("maps the independent GSPAY USDT profile without falling back to MYR",()=>{
 const source=Object.fromEntries(gspayUsdtKeys.map((key,index)=>[key,`usdt-${index}`]));
 source.GSPAY_AUTH_KEY='myr-auth-key-must-not-be-forwarded';
 const mapped=mapGSPayUsdtEnvironment(source);
 assert.deepEqual(mapped,Object.fromEntries(gspayUsdtKeys.map((key,index)=>[key,`usdt-${index}`])));
 assert.doesNotMatch(JSON.stringify(mapped),/myr-auth-key-must-not-be-forwarded/);
});
test("missing GSPAY USDT settings remain unset even when MYR is fully configured",()=>{
 const mapped=mapGSPayUsdtEnvironment(Object.fromEntries(gspayKeys.map(key=>[key,'myr-only'])));
 assert.deepEqual(Object.keys(mapped).sort(),[...gspayUsdtKeys].sort());
 assert.ok(Object.values(mapped).every(value=>value===undefined));
});
