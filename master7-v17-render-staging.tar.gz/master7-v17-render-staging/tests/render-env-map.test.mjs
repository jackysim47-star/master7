import { test } from "node:test";
import assert from "node:assert/strict";
import { mapVPayEnvironment } from "../lib/render-env-map.mjs";

const keys = [
  "VPAY_GATEWAY_URL",
  "VPAY_ORDER_TOKEN",
  "VPAY_QUERY_TOKEN",
  "VPAY_CALLBACK_TOKEN",
  "VPAY_ORDERS_ENABLED",
  "VPAY_MODE",
  "VPAY_TRADER_ID",
  "VPAY_RETURN_URL",
];

test("maps the eight server-side VPay settings without changing their values", () => {
  const source = Object.fromEntries(keys.map((key, i) => [key, `test-${i}`]));
  assert.deepEqual(mapVPayEnvironment(source), source);
});

test("leaves missing VPay settings unset and does not enable orders by default", () => {
  const mapped = mapVPayEnvironment({});
  assert.deepEqual(Object.keys(mapped).sort(), [...keys].sort());
  assert.ok(Object.values(mapped).every((value) => value === undefined));
});
