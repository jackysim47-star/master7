import { test } from "node:test";
import assert from "node:assert/strict";
import { mapGSPayEnvironment, mapVPayEnvironment } from "../lib/render-env-map.mjs";

const keys = [
  "VPAY_GATEWAY_URL",
  "VPAY_ORDER_TOKEN",
  "VPAY_QUERY_TOKEN",
  "VPAY_CALLBACK_TOKEN",
  "VPAY_ORDERS_ENABLED",
  "VPAY_MODE",
  "VPAY_TRADER_ID",
  "VPAY_RETURN_URL",
];

test("maps the eight server-side VPay settings without changing their values", () => {
  const source = Object.fromEntries(keys.map((key, i) => [key, `test-${i}`]));
  assert.deepEqual(mapVPayEnvironment(source), source);
});

test("leaves missing VPay settings unset and does not enable orders by default", () => {
  const mapped = mapVPayEnvironment({});
  assert.deepEqual(Object.keys(mapped).sort(), [...keys].sort());
  assert.ok(Object.values(mapped).every((value) => value === undefined));
});

const gspayKeys = ["GSPAY_GATEWAY_URL","GSPAY_ORDER_TOKEN","GSPAY_QUERY_TOKEN","GSPAY_CALLBACK_TOKEN","GSPAY_ORDERS_ENABLED","GSPAY_MODE"];
test("maps only the six portal-side GSPAY capability settings",()=>{
 const source=Object.fromEntries(gspayKeys.map((key,index)=>[key,`fixture-${index}`]));
 source.GSPAY_OPERATOR_SECRET_KEY='must-stay-in-gateway';
 assert.deepEqual(mapGSPayEnvironment(source),Object.fromEntries(gspayKeys.map((key,index)=>[key,`fixture-${index}`])));
 assert.equal(JSON.stringify(mapGSPayEnvironment(source)).includes('must-stay-in-gateway'),false);
});
test("leaves missing GSPAY capability settings disabled",()=>{
 const mapped=mapGSPayEnvironment({});assert.deepEqual(Object.keys(mapped).sort(),[...gspayKeys].sort());assert.ok(Object.values(mapped).every(value=>value===undefined));
});
