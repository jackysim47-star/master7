import { test } from "node:test";
import assert from "node:assert/strict";
import { mapGSPayEnvironment, mapVPayEnvironment } from "../lib/render-env-map.mjs";

const keys = [
  "VPAY_GATEWAY_URL",
  "VPAY_ORDER_TOKEN",
  "VPAY_QUERY_TOKEN",
  "VPAY_CALLBACK_TOKEN",
  "VPAY_ORDERS_ENABLED",
  "VPAY_MODE",
  "VPAY_TRADER_ID",
  "VPAY_RETURN_URL",
  "VPAY_RECOVERY_ENABLED",
];

test("maps the server-side VPay settings without changing their values", () => {
  const source = Object.fromEntries(keys.map((key, i) => [key, `test-${i}`]));
  assert.deepEqual(mapVPayEnvironment(source), source);
});

test("leaves missing VPay settings unset and does not enable orders by default", () => {
  const mapped = mapVPayEnvironment({});
  assert.deepEqual(Object.keys(mapped).sort(), [...keys].sort());
  assert.ok(Object.values(mapped).every((value) => value === undefined));
});

const gspayKeys = ["GSPAY_API_BASE_URL","GSPAY_AUTH_KEY","GSPAY_SECRET_KEY","GSPAY_ORDERS_ENABLED","GSPAY_RETURN_URL","GSPAY_RECOVERY_ENABLED","GSPAY_BALANCE_QUERY_ENABLED"];
test("maps only the server-side GSPAY provider settings",()=>{
 const source=Object.fromEntries(gspayKeys.map((key,index)=>[key,`fixture-${index}`]));
 source.GSPAY_GATEWAY_URL='legacy-must-not-be-forwarded';
 assert.deepEqual(mapGSPayEnvironment(source),Object.fromEntries(gspayKeys.map((key,index)=>[key,`fixture-${index}`])));
 assert.equal(JSON.stringify(mapGSPayEnvironment(source)).includes('legacy-must-not-be-forwarded'),false);
});
test("leaves missing GSPAY provider settings unset and orders disabled by default",()=>{
 const mapped=mapGSPayEnvironment({});assert.deepEqual(Object.keys(mapped).sort(),[...gspayKeys].sort());assert.ok(Object.values(mapped).every(value=>value===undefined));
});
