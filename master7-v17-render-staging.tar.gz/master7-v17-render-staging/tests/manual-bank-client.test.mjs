import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');

test('manual-bank retries reuse one request key until success or an explicit reset',()=>{
 const start=source.indexOf('function manualBankAttemptStorageKey(){'),end=source.indexOf('\nasync function submitManualBankDeposit',start);
 assert.ok(start>=0&&end>start);
 const stored=new Map();let sequence=0;
 const context={
  state:{user:{id:'member-one'},manualBankAttempt:null},
  crypto:{randomUUID:()=>`request-${++sequence}`},
  sessionStorage:{getItem:key=>stored.get(key)??null,setItem:(key,value)=>stored.set(key,value),removeItem:key=>stored.delete(key)}
 };
 vm.runInNewContext(source.slice(start,end),context);
 const receipt={name:'receipt.jpg',size:12345,lastModified:1700000000000,type:'image/jpeg'};
 const first=context.manualBankAttemptFor('bank-one','25.00',receipt);
 assert.equal(first.requestKey,'request-1');
 assert.equal(context.manualBankAttemptFor('bank-one','25.00',receipt).requestKey,'request-1');

 context.state.manualBankAttempt=null;
 assert.equal(context.manualBankAttemptFor('bank-one','25.00',receipt).requestKey,'request-1','a page reload/lost response must retain the request key');
 assert.equal(context.manualBankAttemptFor('bank-one','26.00',receipt).requestKey,'request-2','changed form data starts a new intent');

 context.clearManualBankAttempt();
 assert.equal(context.state.manualBankAttempt,null);
 assert.equal(stored.has('m7-manual-bank-order-member-one'),false);
 assert.equal(context.manualBankAttemptFor('bank-one','26.00',receipt).requestKey,'request-3','explicit reset starts a new intent');

 context.state.user={id:'member-two'};
 assert.equal(context.manualBankAttemptFor('bank-one','26.00',receipt).requestKey,'request-4','request keys never cross member accounts');
});

test('receipt preprocessing fits the complete tall or wide image without cropping',async()=>{
 const start=source.indexOf('async function receiptDataForUpload('),end=source.indexOf('\nasync function renderAdManager',start);
 assert.ok(start>=0&&end>start);
 const canvases=[];
 class FileReader {
  readAsDataURL(){this.result='data:image/jpeg;base64,AAECAwQFBgcICQoLDA0ODw==';this.onload();}
 }
 const context={
  Blob,
  FileReader,
  createImageBitmap:async file=>({width:file.width,height:file.height,closed:false,close(){this.closed=true;}}),
  document:{createElement:tag=>{
   assert.equal(tag,'canvas');
   const canvas={width:0,height:0,draw:null,fill:null};
   const context2d={
    fillStyle:'',
    fillRect:(...args)=>{canvas.fill=args;},
    drawImage:(...args)=>{canvas.draw=args;}
   };
   canvas.getContext=type=>{assert.equal(type,'2d');return context2d;};
   canvas.toBlob=callback=>callback(new Blob([new Uint8Array(100)],{type:'image/jpeg'}));
   canvases.push(canvas);return canvas;
  }}
 };
 vm.runInNewContext(source.slice(start,end),context);

 await context.receiptDataForUpload({type:'image/jpeg',width:600,height:3000},1200,1600);
 let canvas=canvases.at(-1);
 assert.deepEqual([canvas.width,canvas.height],[320,1600]);
 assert.deepEqual(canvas.draw.slice(1),[0,0,320,1600]);
 assert.deepEqual(canvas.fill,[0,0,320,1600]);

 await context.receiptDataForUpload({type:'image/png',width:3000,height:600},1200,1600);
 canvas=canvases.at(-1);
 assert.deepEqual([canvas.width,canvas.height],[1200,240]);
 assert.deepEqual(canvas.draw.slice(1),[0,0,1200,240]);
 assert.deepEqual(canvas.fill,[0,0,1200,240]);

 await assert.rejects(()=>context.receiptDataForUpload({type:'application/pdf',width:100,height:100}),/Choose a JPG, PNG or WebP image/);
});

test('manual-bank submit uses the hardened receipt path and reset clears its pending intent',()=>{
 assert.match(source,/receiptDataForUpload\(file,1200,1600\)/);
 assert.match(source,/requestKey:attempt\.requestKey/);
 assert.match(source,/addEventListener\("reset",clearManualBankAttempt\)/);
 assert.doesNotMatch(source,/manual-bank\/deposits[\s\S]{0,300}requestKey:crypto\.randomUUID\(\)/);
});
