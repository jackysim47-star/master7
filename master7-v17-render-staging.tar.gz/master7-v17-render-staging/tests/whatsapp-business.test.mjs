import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {malaysiaWhatsAppRecipient,parseWhatsAppWebhook,sendWhatsAppTemplate,verifyWhatsAppWebhookChallenge,verifyWhatsAppWebhookSignature,whatsappBusinessStatus} from '../lib/whatsapp-business.ts';

const base={
 enabled:'true',graphApiVersion:'v25.0',phoneNumberId:'123456789012345',wabaId:'987654321098765',
 accessToken:'EAA'+'.'.repeat(50),appSecret:'a'.repeat(32),webhookVerifyToken:'verify-token-'+ 'x'.repeat(32),
 businessNumber:'+601166336686',templateName:'master7_launch_invitation',templateLanguage:'zh_CN',
};

test('WhatsApp readiness requires the exact MASTER7 business number and every server credential without exposing secrets',()=>{
 const absent=whatsappBusinessStatus({businessNumber:'+601166336686'});
 assert.equal(absent.ready,false);assert.deepEqual(absent.blockers,['configuration_incomplete','sending_disabled']);
 const ready=whatsappBusinessStatus(base);assert.equal(ready.ready,true);assert.equal(ready.provider,'meta_whatsapp_cloud_api');assert.equal(ready.mode,'approved_template_only');
 const publicValue=JSON.stringify(ready);assert.doesNotMatch(publicValue,/EAA/);assert.doesNotMatch(publicValue,/verify-token/);assert.doesNotMatch(publicValue,/aaaaaaaa/);
 assert.equal(whatsappBusinessStatus({...base,businessNumber:'+601166336685'}).ready,false);
 assert.equal(whatsappBusinessStatus({...base,enabled:'false'}).ready,false);
});

test('Malaysian recipient normalization accepts valid mobile forms and rejects foreign or fixed-line numbers',()=>{
 assert.equal(malaysiaWhatsAppRecipient('+60 11-6633 6686'),'+601166336686');
 assert.equal(malaysiaWhatsAppRecipient('01166336686'),'+601166336686');
 assert.equal(malaysiaWhatsAppRecipient('601166336686'),'+601166336686');
 assert.equal(malaysiaWhatsAppRecipient('+6591234567'),null);
 assert.equal(malaysiaWhatsAppRecipient('0377788888'),null);
});

test('template send uses only the fixed Graph host, approved template and server bearer token',async()=>{
 let observed;
 const fetchImpl=async(url,init)=>{observed={url,init};return Response.json({messaging_product:'whatsapp',contacts:[{input:'60112223333',wa_id:'60112223333'}],messages:[{id:'wamid.HBgMNjAxMTIyMjMzMzMVAgARGBI0QkNERUY='}]});};
 const result=await sendWhatsAppTemplate({...base,fetchImpl},{recipient:'+60112223333',bodyParameters:['祝您顺心如意','https://master7.best/register'],headerImageId:'123456789'});
 assert.equal(result.ok,true);assert.equal(result.recipient,'+60112223333');
 assert.equal(observed.url,'https://graph.facebook.com/v25.0/123456789012345/messages');
 assert.equal(observed.init.redirect,'error');assert.equal(observed.init.headers.Authorization,`Bearer ${base.accessToken}`);
 const body=JSON.parse(observed.init.body);assert.deepEqual(body,{messaging_product:'whatsapp',recipient_type:'individual',to:'60112223333',type:'template',template:{name:'master7_launch_invitation',language:{code:'zh_CN'},components:[{type:'header',parameters:[{type:'image',image:{id:'123456789'}}]},{type:'body',parameters:[{type:'text',text:'祝您顺心如意'},{type:'text',text:'https://master7.best/register'}]}]}});
});

test('send fails closed and returns only safe error facts',async()=>{
 let called=0;const fetchImpl=async()=>{called++;return new Response(JSON.stringify({error:{message:'do not expose this provider body',code:131000}}),{status:429,headers:{'Content-Type':'application/json','Retry-After':'42'}});};
 assert.deepEqual(await sendWhatsAppTemplate({...base,enabled:'false',fetchImpl},{recipient:'+60112223333'}),{ok:false,kind:'not_configured'});assert.equal(called,0);
 assert.deepEqual(await sendWhatsAppTemplate({...base,fetchImpl},{recipient:'+6591234567'}),{ok:false,kind:'invalid_recipient'});assert.equal(called,0);
 const rejected=await sendWhatsAppTemplate({...base,fetchImpl},{recipient:'+60112223333'});assert.deepEqual(rejected,{ok:false,kind:'rate_limited',httpStatus:429,retryAfter:42});assert.doesNotMatch(JSON.stringify(rejected),/provider body|131000/);
});

test('webhook verification uses the raw-body SHA256 signature and constant-time token comparison',()=>{
 const body=Buffer.from('{"object":"whatsapp_business_account"}'),signature='sha256='+createHmac('sha256',base.appSecret).update(body).digest('hex');
 assert.equal(verifyWhatsAppWebhookSignature(body,signature,base.appSecret),true);
 assert.equal(verifyWhatsAppWebhookSignature(body,signature.replace(/.$/,'0'),base.appSecret),false);
 assert.equal(verifyWhatsAppWebhookSignature(Buffer.from('{}'),signature,base.appSecret),false);
 const ok=verifyWhatsAppWebhookChallenge(new URLSearchParams({'hub.mode':'subscribe','hub.verify_token':base.webhookVerifyToken,'hub.challenge':'challenge-123'}),base.webhookVerifyToken);
 assert.deepEqual(ok,{ok:true,challenge:'challenge-123'});
 assert.deepEqual(verifyWhatsAppWebhookChallenge(new URLSearchParams({'hub.mode':'subscribe','hub.verify_token':'wrong','hub.challenge':'challenge-123'}),base.webhookVerifyToken),{ok:false});
});

test('webhook parser accepts bounded delivery states and multilingual opt-out intent only',()=>{
 const parsed=parseWhatsAppWebhook({entry:[{changes:[{field:'messages',value:{statuses:[
  {id:'wamid.sent-123',recipient_id:'60112223333',status:'sent',timestamp:'1793970000'},
  {id:'wamid.failed-456',recipient_id:'60114445555',status:'failed',timestamp:'bad',errors:[{code:131026,message:'not returned'}]},
  {id:'bad id',recipient_id:'60114445555',status:'read'}
 ],messages:[
  {from:'60112223333',type:'text',text:{body:' STOP '}},
  {from:'60114445555',type:'text',text:{body:'退订'}},
  {from:'60118889999',type:'text',text:{body:'Berhenti'}},
  {from:'60116667777',type:'text',text:{body:'Tell me more'}}
 ]}}]}]});
 assert.deepEqual(parsed.statuses,[
  {messageId:'wamid.sent-123',recipient:'+60112223333',status:'sent',timestamp:1793970000,errorCode:null},
  {messageId:'wamid.failed-456',recipient:'+60114445555',status:'failed',timestamp:null,errorCode:131026}
 ]);
 assert.deepEqual(parsed.optOuts,['+60112223333','+60114445555','+60118889999']);
 assert.deepEqual(parseWhatsAppWebhook(null),{statuses:[],optOuts:[]});
});
