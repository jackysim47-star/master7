import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const vip=readFileSync(new URL('../public/assets/vip.js',import.meta.url),'utf8');
const style=readFileSync(new URL('../public/assets/vip.css',import.meta.url),'utf8');

test('member portal exposes one independent VIP suite and keeps ordinary benefits separate',()=>{
 assert.equal((html.match(/id="vip"/g)||[]).length,1);
 assert.equal((html.match(/id="vipManager"/g)||[]).length,1);
 assert.match(html,/data-section="vip" id="referralNav"/);
 assert.match(html,/8 VIP LEVELS/);
 assert.match(html,/Deposit Commission/);
 assert.match(html,/Turnover Commission/);
 assert.match(html,/Company Profit Dividend/);
 assert.match(html,/id="benefitManagerTitle">Customer benefits · 普通福利/);
 assert.doesNotMatch(html,/<option value="vip">/);
 assert.doesNotMatch(html,/VIP rules remain drafts/);
 assert.ok(html.indexOf('id="vipCommissionTitle"')<html.indexOf('id="referralCard"'),'referral ownership belongs inside the VIP suite');
});

test('VIP UI consumes the backend member and three-ledger capability contract',()=>{
 assert.match(vip,/member\?\.creditedDeposits\?\.amountMYR/);
 assert.match(vip,/member\?\.previewCurrentTier/);
 assert.match(vip,/member\?\.nextTierProgress\?\.percent/);
 assert.match(vip,/data\?\.commissionCapabilities/);
 assert.match(vip,/companyProfitDividend/);
 assert.match(vip,/rates\.L1,rates\.L2,rates\.L3/);
 assert.match(vip,/settlement==="preview_only"/);
 assert.match(vip,/NO WALLET CREDIT/);
 assert.match(vip,/SCOPE · ALL 34 PLATFORMS/);
});

test('owner editor saves exactly eight tiers and preserves nullable withdrawal limits',()=>{
 for(const name of ['Bronze','Silver','Gold','Platinum','Diamond','Royal','Crown','Master'])assert.match(vip,new RegExp(`"${name}"`));
 assert.match(vip,/path==="withdrawalLimitMYR"&&input\.value\.trim\(\)===""\?null/);
 assert.match(vip,/payload=\{version:1,enabled:/);
 assert.match(vip,/api\("\/api\/admin\/vip","POST",payload\)/);
 assert.match(vip,/querySelectorAll\("\[data-vip-tier\]"\)/);
 assert.match(app,/vipManager:\(\)=>window\.Master7Vip\?\.loadAdmin\(\)/);
 assert.match(app,/\["operationsAiPanel","accountingPanel","vipManager","referralAdminPanel"/);
});

test('VIP presentation is responsive and money automation stays visibly guarded',()=>{
 for(const capability of ['walletCredit','cashbackAutomation','dividendAutomation','turnoverEnforcement'])assert.match(vip,new RegExp(`\"${capability}\"`));
 assert.match(style,/\.vip-tier-grid\{display:grid/);
 assert.match(style,/\.vip-matrix-scroll\{overflow:auto/);
 assert.match(style,/@media\(max-width:720px\)/);
 assert.match(style,/\.vip-commission-grid\{grid-template-columns:1fr\}/);
});

test('VIP work preserves the featured platform showcase and owner platform controls',()=>{
 assert.match(html,/class="featured-games-panel"/);
 assert.match(html,/id="bonusBrandLobby"/);
 assert.match(html,/id="providerPanel"/);
 assert.match(app,/renderProviderManager\(\$\("providerManager"\),state\.user\?\.role==="owner"\)/);
 assert.match(app,/apiSupplierEntries=Object\.freeze\(\[/);
});
