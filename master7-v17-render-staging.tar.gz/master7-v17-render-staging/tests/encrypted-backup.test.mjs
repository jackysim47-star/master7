import test from 'node:test';
import assert from 'node:assert/strict';
import {constants,createDecipheriv,createHash,createPublicKey,generateKeyPairSync,privateDecrypt} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {BACKUP_EXCLUDED_TABLES,BACKUP_FORMAT,BACKUP_PAGE_SIZE,BACKUP_SCHEMA_SHA256,BACKUP_SCHEMA_VERSION,BACKUP_TABLES,backupRestoreContract,createEncryptedPortalBackup,orderBackupRestoreRows} from '../lib/encrypted-backup.ts';

test('portal backup encrypts every recovery table and excludes authentication sessions',async()=>{
 const username='backup-test-owner',passwordHash='sensitive-password-hash',users=Array.from({length:10005},(_,index)=>({id:`owner-${String(index).padStart(5,'0')}`,username:index?`member-${index}`:username,role:index?'member':'owner',approved:1,csrf:index?'': 'private-csrf',created_at:index+1})),fixtures={users,password_credentials:[{user_id:'owner-00000',password_hash:passwordHash,salt:'private-salt',credential_version:1,updated_at:1}]},queries=[];
 const db={prepare(sql){
  const match=sql.match(/^SELECT \* FROM ([a-z0-9_]+) ORDER BY [a-z0-9_,]+ LIMIT \? OFFSET \?$/);assert.ok(match);
  return {bind(limit,offset){
   assert.equal(limit,BACKUP_PAGE_SIZE);queries.push({table:match[1],offset});
   return {all:async()=>({results:(fixtures[match[1]]??[]).slice(offset,offset+limit)})};
  }};
 }};
 const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}}),fingerprint=createHash('sha256').update(createPublicKey(publicKey).export({type:'spki',format:'der'})).digest('hex'),{envelope,metadata}=await createEncryptedPortalBackup(db,'test-release',{publicKey,publicKeySha256:fingerprint}),serialized=JSON.stringify(envelope);
 assert.equal(envelope.format,BACKUP_FORMAT);assert.equal(metadata.tableCount,BACKUP_TABLES.length);assert.equal(metadata.totalRecords,10006);assert.equal(envelope.publicKeySha256,fingerprint);assert.equal(envelope.schemaVersion,BACKUP_SCHEMA_VERSION);assert.equal(envelope.schemaSha256,BACKUP_SCHEMA_SHA256);assert.ok(queries.some(item=>item.table==='users'&&item.offset===10000));assert.ok(!serialized.includes(username));assert.ok(!serialized.includes(passwordHash));assert.ok(!serialized.includes('private-csrf'));
 assert.equal(envelope.readConsistency,'unverified');assert.equal(metadata.readConsistency,'unverified');
 const key=privateDecrypt({key:privateKey,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64')),decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(envelope.iv,'base64'));decipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));const payload=JSON.parse(gunzipSync(Buffer.concat([decipher.update(Buffer.from(envelope.ciphertext,'base64')),decipher.final()])).toString());
 assert.equal(payload.tables.users[0].username,username);assert.equal(payload.tables.users.length,10005);assert.equal(payload.tables.password_credentials[0].password_hash,passwordHash);assert.deepEqual(payload.restorePolicy.excludedTables,[...BACKUP_EXCLUDED_TABLES]);assert.equal(payload.manifest.totalRecords,10006);assert.equal(payload.schemaVersion,BACKUP_SCHEMA_VERSION);assert.equal(payload.schemaSha256,BACKUP_SCHEMA_SHA256);
 assert.equal(payload.readConsistency,'unverified');
});

test('exact 0121 backup manifest remains recoverable with complete table coverage',()=>{
 const schemaVersion='0121-jdb-wager-coverage-staging';
 const schemaSha256=createHash('sha256').update(JSON.stringify({format:BACKUP_FORMAT,schemaVersion,tables:BACKUP_TABLES})).digest('hex');
 const contract=backupRestoreContract(schemaVersion,schemaSha256);
 assert.deepEqual(contract.tables,[...BACKUP_TABLES]);
 assert.deepEqual(contract.missingTables,[]);
 assert.throws(()=>backupRestoreContract(schemaVersion,'0'.repeat(64)),/Backup schema version does not match this release/);
});

test('acceptance restore rows are ordered by stream and revision instead of random event id',()=>{
 const gameRows=[
  {id:'a-revision-2',profile_id:'profile-b',capability:'launch',environment:'production',revision:2},
  {id:'z-revision-1',profile_id:'profile-b',capability:'launch',environment:'production',revision:1},
  {id:'m-other-stream',profile_id:'profile-a',capability:'wallet',environment:'uat',revision:1},
 ];
 assert.deepEqual(orderBackupRestoreRows('game_provider_acceptance_events',gameRows).map(row=>row.id),['m-other-stream','z-revision-1','a-revision-2']);
 const productionRows=[
  {id:'a-revision-2',category:'domain',subject_id:'www.master7.best',capability:'dns_tls_routing',environment:'production',revision:2},
  {id:'z-revision-1',category:'domain',subject_id:'www.master7.best',capability:'dns_tls_routing',environment:'production',revision:1},
 ];
 assert.deepEqual(orderBackupRestoreRows('production_acceptance_events',productionRows).map(row=>row.id),['z-revision-1','a-revision-2']);
 assert.equal(orderBackupRestoreRows('users',gameRows),gameRows);
});
