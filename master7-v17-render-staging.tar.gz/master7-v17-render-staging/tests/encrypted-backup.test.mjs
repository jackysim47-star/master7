import test from 'node:test';
import assert from 'node:assert/strict';
import {constants,createDecipheriv,createHash,createPublicKey,generateKeyPairSync,privateDecrypt} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {BACKUP_FORMAT,BACKUP_TABLES,createEncryptedPortalBackup} from '../lib/encrypted-backup.ts';

test('portal backup encrypts every recovery table and excludes authentication sessions',async()=>{
 const username='backup-test-owner',passwordHash='sensitive-password-hash',fixtures={users:[{id:'owner-1',username,role:'owner',approved:1,csrf:'private-csrf',created_at:1}],password_credentials:[{user_id:'owner-1',password_hash:passwordHash,salt:'private-salt',credential_version:1,updated_at:1}]};
 const db={prepare(sql){const match=sql.match(/^SELECT \* FROM ([a-z0-9_]+) LIMIT 10001$/);assert.ok(match);return {all:async()=>({results:fixtures[match[1]]??[]})};}};
 const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}}),fingerprint=createHash('sha256').update(createPublicKey(publicKey).export({type:'spki',format:'der'})).digest('hex'),{envelope,metadata}=await createEncryptedPortalBackup(db,'test-release',{publicKey,publicKeySha256:fingerprint}),serialized=JSON.stringify(envelope);
 assert.equal(envelope.format,BACKUP_FORMAT);assert.equal(metadata.tableCount,BACKUP_TABLES.length);assert.equal(metadata.totalRecords,2);assert.equal(envelope.publicKeySha256,fingerprint);assert.ok(!serialized.includes(username));assert.ok(!serialized.includes(passwordHash));assert.ok(!serialized.includes('private-csrf'));
 const key=privateDecrypt({key:privateKey,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64')),decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(envelope.iv,'base64'));decipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));const payload=JSON.parse(gunzipSync(Buffer.concat([decipher.update(Buffer.from(envelope.ciphertext,'base64')),decipher.final()])).toString());
 assert.equal(payload.tables.users[0].username,username);assert.equal(payload.tables.password_credentials[0].password_hash,passwordHash);assert.deepEqual(payload.restorePolicy.excludedTables,['password_sessions','otp_challenges','rate_limits']);assert.equal(payload.manifest.totalRecords,2);
});
