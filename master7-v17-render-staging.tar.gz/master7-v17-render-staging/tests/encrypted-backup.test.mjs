import test from 'node:test';
import assert from 'node:assert/strict';
import {constants,createDecipheriv,createHash,createPublicKey,generateKeyPairSync,privateDecrypt} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {BACKUP_FORMAT,BACKUP_PAGE_SIZE,BACKUP_SCHEMA_SHA256,BACKUP_SCHEMA_VERSION,BACKUP_TABLES,createEncryptedPortalBackup} from '../lib/encrypted-backup.ts';

test('portal backup encrypts every recovery table and excludes authentication sessions',async()=>{
 const username='backup-test-owner',passwordHash='sensitive-password-hash',users=Array.from({length:10005},(_,index)=>({id:`owner-${String(index).padStart(5,'0')}`,username:index?`member-${index}`:username,role:index?'member':'owner',approved:1,csrf:index?'': 'private-csrf',created_at:index+1})),fixtures={users,password_credentials:[{user_id:'owner-00000',password_hash:passwordHash,salt:'private-salt',credential_version:1,updated_at:1}]},queries=[];
 const db={prepare(sql){
  const match=sql.match(/^SELECT \* FROM ([a-z0-9_]+) ORDER BY 1 LIMIT \? OFFSET \?$/);assert.ok(match);
  return {bind(limit,offset){
   assert.equal(limit,BACKUP_PAGE_SIZE);queries.push({table:match[1],offset});
   return {all:async()=>({results:(fixtures[match[1]]??[]).slice(offset,offset+limit)})};
  }};
 }};
 const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}}),fingerprint=createHash('sha256').update(createPublicKey(publicKey).export({type:'spki',format:'der'})).digest('hex'),{envelope,metadata}=await createEncryptedPortalBackup(db,'test-release',{publicKey,publicKeySha256:fingerprint}),serialized=JSON.stringify(envelope);
 assert.equal(envelope.format,BACKUP_FORMAT);assert.equal(metadata.tableCount,BACKUP_TABLES.length);assert.equal(metadata.totalRecords,10006);assert.equal(envelope.publicKeySha256,fingerprint);assert.equal(envelope.schemaVersion,BACKUP_SCHEMA_VERSION);assert.equal(envelope.schemaSha256,BACKUP_SCHEMA_SHA256);assert.ok(queries.some(item=>item.table==='users'&&item.offset===10000));assert.ok(!serialized.includes(username));assert.ok(!serialized.includes(passwordHash));assert.ok(!serialized.includes('private-csrf'));
 const key=privateDecrypt({key:privateKey,oaepHash:'sha256',padding:constants.RSA_PKCS1_OAEP_PADDING},Buffer.from(envelope.encryptedKey,'base64')),decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(envelope.iv,'base64'));decipher.setAuthTag(Buffer.from(envelope.authTag,'base64'));const payload=JSON.parse(gunzipSync(Buffer.concat([decipher.update(Buffer.from(envelope.ciphertext,'base64')),decipher.final()])).toString());
 assert.equal(payload.tables.users[0].username,username);assert.equal(payload.tables.users.length,10005);assert.equal(payload.tables.password_credentials[0].password_hash,passwordHash);assert.deepEqual(payload.restorePolicy.excludedTables,['password_sessions','otp_challenges','rate_limits']);assert.equal(payload.manifest.totalRecords,10006);assert.equal(payload.schemaVersion,BACKUP_SCHEMA_VERSION);assert.equal(payload.schemaSha256,BACKUP_SCHEMA_SHA256);
});
