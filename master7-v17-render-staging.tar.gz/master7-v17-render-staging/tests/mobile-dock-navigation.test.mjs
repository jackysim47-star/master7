import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const html=readFileSync(new URL('../app/portal.html',import.meta.url),'utf8');
const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');

class ClassList{
 constructor(values=[]){this.values=new Set(values);}
 toggle(name,enabled){if(enabled)this.values.add(name);else this.values.delete(name);}
 contains(name){return this.values.has(name);}
}

function element({id='',section='',target='',active=false}={}){
 const attributes=new Map();
 return {
  id,
  dataset:{...(section?{section}:{}),...(target?{mobileDockTarget:target}:{})},
  classList:new ClassList(active?['active']:[]),
  setAttribute(name,value){attributes.set(name,String(value));},
  removeAttribute(name){attributes.delete(name);},
  getAttribute(name){return attributes.get(name)??null;},
 };
}

function harness(){
 const dock=[
  element({section:'lobby',target:'home',active:true}),
  element({target:'games'}),
  element({section:'deposit',target:'deposit'}),
  element({section:'rewards',target:'rewards'}),
  element({section:'support',target:'support'}),
 ];
 const sections=['lobby','deposit','rewards','support'].map(id=>element({id}));
 const body=element(),scrolls=[],loads=[];
 const document={
  body,
  querySelectorAll(selector){
   if(selector==='.section')return sections;
   if(selector==='.nav-button')return dock.filter(item=>item.dataset.section);
   if(selector==='[data-mobile-dock-target]')return dock;
   return [];
  },
 };
 const context={
  state:{user:{role:'member'},section:'lobby'},
  document,
  window:{
   scrollTo(value){scrolls.push(value);},
   Master7Rewards:{loadPublic(){loads.push('rewards');}},
  },
  loadWithdrawals(){loads.push('withdraw');},
  refreshTickets(){loads.push('support');},
  renderAdmin(){loads.push('admin');},
 };
 const start=source.indexOf('function setMobileDockTarget(');
 const end=source.indexOf('function openAdminNotifications(',start);
 assert.ok(start>=0&&end>start,'mobile dock navigation functions must be extractable');
 vm.runInNewContext(`${source.slice(start,end)}\nthis.selected=selected;`,context);
 return {...context,dock,sections,scrolls,loads};
}

function currentTargets(dock){
 return dock.filter(item=>item.classList.contains('active')&&item.getAttribute('aria-current')==='page').map(item=>item.dataset.mobileDockTarget);
}

test('mobile dock exposes one explicit current destination',()=>{
 const dockMarkup=html.match(/<nav class="mobile-dock"[\s\S]*?<\/nav>/)?.[0]??'';
 assert.equal((dockMarkup.match(/data-mobile-dock-target=/g)??[]).length,5);
 assert.match(dockMarkup,/data-mobile-dock-target="home" aria-current="page"/);
 assert.match(dockMarkup,/id="mobileGamesButton" data-mobile-dock-target="games"/);
});

test('Games and Home remain distinct current targets inside the lobby',()=>{
 const h=harness();
 h.selected('lobby','games');
 assert.deepEqual(currentTargets(h.dock),['games']);
 assert.equal(h.sections.find(item=>item.id==='lobby').classList.contains('active'),true);
 assert.equal(h.scrolls.at(-1)?.top,0);
 assert.equal(h.scrolls.at(-1)?.behavior,'smooth');

 h.selected('lobby');
 assert.deepEqual(currentTargets(h.dock),['home']);
 assert.equal(h.sections.find(item=>item.id==='lobby').classList.contains('active'),true);
});

test('Wallet, Promotions and Support each own the current dock state',()=>{
 const h=harness();
 h.selected('deposit');
 assert.deepEqual(currentTargets(h.dock),['deposit']);
 h.selected('rewards');
 assert.deepEqual(currentTargets(h.dock),['rewards']);
 assert.ok(h.loads.includes('rewards'));
 h.selected('support');
 assert.deepEqual(currentTargets(h.dock),['support']);
 assert.ok(h.loads.includes('support'));
});

test('game entry handlers explicitly retain the Games dock target',()=>{
 const provider=source.slice(source.indexOf('function openCatalogProvider('),source.indexOf('function openProviderBonus('));
 const wallet=source.slice(source.indexOf('function bindWalletActions('),source.indexOf('function trustedGSPayCheckout('));
 const bind=source.slice(source.indexOf('function bind(){'),source.indexOf('(function restoreLanguage'));
 assert.match(provider,/selected\('lobby','games'\)/);
 assert.match(wallet,/mobileGamesButton[\s\S]*selected\("lobby","games"\)/);
 assert.match(bind,/data-game-category[\s\S]*setMobileDockTarget\("games"\)/);
 assert.match(bind,/data-sidebar-game-category[\s\S]*selected\("lobby","games"\)/);
});
