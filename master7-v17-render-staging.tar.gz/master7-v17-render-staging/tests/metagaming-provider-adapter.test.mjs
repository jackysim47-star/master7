import test from 'node:test';
import assert from 'node:assert/strict';
import {createMetaGamingProviderAdapter,metaGamingPlayerId,metaGamingReferenceId} from '../lib/metagaming-provider-adapter.ts';
import {metaGamingProfileRuntime} from '../lib/metagaming-profile-runtime.ts';
import {gameTransferRuntime,seedTransferProfile} from '../lib/game-provider-runtime.ts';
import {getGameProviderProfile} from '../lib/game-provider-registry.ts';

const tokens={player:'p'.repeat(48),wallet:'w'.repeat(48),recovery:'r'.repeat(48),report:'l'.repeat(48)};
const config=(profile='metagaming_normal_myr')=>({profile,account:profile.includes('_free_')?'free':'normal',baseUrl:'https://gateway.example.test',currency:'MYR',playerToken:tokens.player,walletToken:tokens.wallet,recoveryToken:tokens.recovery,reportToken:tokens.report,launchOrigins:['https://games.example.test']});
const success=result=>({ok:true,status:200,description:'Success',responseDateTime:'2026-11-10 09:00:00',...result});
function fake(profile='metagaming_normal_myr',overrides={}){
 const cfg=config(profile),calls=[],handlers={player:success({}),launch:success({url:'https://games.example.test/play?session=synthetic'}),balance:success({currentBalance:'15.75',currency:'MYR'}),deposit:success({currentBalance:'20.00',currency:'MYR'}),withdraw:success({currentBalance:'0.00',currency:'MYR'}),'transfer-status':success({transaction:{transactionId:'123456',amount:'20.00',previousBalance:'0',newBalance:'20.00'}}),kick:success({kickAccepted:true,closureFinal:false}),'unfinished-rounds':success({rounds:[]}),reports:success({logs:[]}),...overrides},expected={player:tokens.player,launch:tokens.player,balance:tokens.player,deposit:tokens.wallet,withdraw:tokens.wallet,'transfer-status':tokens.wallet,kick:tokens.recovery,'unfinished-rounds':tokens.recovery,reports:tokens.report,'flag-log':tokens.report};
 const transport=async(url,init={})=>{const parsed=new URL(url);if(parsed.pathname==='/providers/metagaming/games')return Response.json({provider:'metagaming',account:cfg.account,currency:'MYR',games:[{gameCode:'10001',name:'Synthetic slot',gameType:1,maintenance:true}]});const method=parsed.pathname.split('/').at(-1),body=JSON.parse(init.body);calls.push({method,body,authorization:init.headers.Authorization});assert.equal(init.method,'POST');assert.equal(init.redirect,'error');assert.equal(init.headers.Authorization,`Bearer ${expected[method]}`);assert.equal(body.profileId,profile);assert.equal(body.account,cfg.account);const value=handlers[method];if(value instanceof Response)return value;if(typeof value==='function')return value(body);return Response.json({provider:'metagaming',profileId:profile,account:cfg.account,operation:method,result:value});};
 const adapter=createMetaGamingProviderAdapter(cfg,{fetchImpl:transport,allowedReturnOrigins:['https://www.master7.best'],merchantContractVerified:true,catalogueAvailabilityVerified:true,sessionClosureVerified:true,playerCreationEnabled:true,balanceEnabled:true,depositEnabled:true,withdrawalEnabled:true,launchEnabled:true,transferStatusEnabled:true,recoveryEnabled:true,reportEnabled:true});
 return{cfg,calls,transport,adapter,context:{profile:getGameProviderProfile(profile)}};
}
const transfer=(profile='metagaming_normal_myr',patch={})=>({userId:'alice',providerPlayerId:metaGamingPlayerId(profile,'alice'),platformTransactionId:'wallet-transaction-1',amountMinor:'2000',currency:'MYR',...patch});

test('META transfer binding is non-secret, route/profile specific and stable across credential-only rotation',()=>{
 const make=cfg=>createMetaGamingProviderAdapter(cfg,{fetchImpl:async()=>{throw Error('no transport required');},allowedReturnOrigins:['https://www.master7.best']});
 const cfg=config(),adapter=make(cfg),fingerprint=adapter.transferContractFingerprint;
 assert.match(fingerprint,/^[a-f0-9]{64}$/);assert.equal(make({...cfg}).transferContractFingerprint,fingerprint);
 assert.equal(make({...cfg,playerToken:'P'.repeat(48),walletToken:'W'.repeat(48),recoveryToken:'R'.repeat(48),reportToken:'L'.repeat(48)}).transferContractFingerprint,fingerprint);
 assert.notEqual(make({...cfg,baseUrl:'https://different-gateway.example.test'}).transferContractFingerprint,fingerprint);
 assert.notEqual(make(config('metagaming_free_myr')).transferContractFingerprint,fingerprint);
 cfg.baseUrl='https://caller-mutated.example.test';assert.equal(adapter.transferContractFingerprint,fingerprint);
});

const withDeadline=(promise,milliseconds=750)=>{
 let timer;const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Test deadline: META request did not terminate')),milliseconds);});
 return Promise.race([promise,deadline]).finally(()=>clearTimeout(timer));
};
function timeoutAdapter(transport,patch={}){
 const cfg=config();return {cfg,adapter:createMetaGamingProviderAdapter(cfg,{fetchImpl:transport,allowedReturnOrigins:['https://www.master7.best'],merchantContractVerified:true,catalogueAvailabilityVerified:true,sessionClosureVerified:true,balanceEnabled:true,depositEnabled:true,timeoutMs:25,...patch}),context:{profile:getGameProviderProfile(cfg.profile)}};
}

test('META bounds an unresponsive gateway request even when its transport ignores abort',async()=>{
 let calls=0,signal;
 const f=timeoutAdapter(async(url,init)=>{calls++;signal=init.signal;return new Promise(()=>{});});
 await assert.rejects(()=>withDeadline(f.adapter.queryBalance(f.context,transfer())),e=>e.code==='META_GATEWAY_TIMEOUT');
 assert.equal(calls,1);assert.equal(signal.aborted,true);
});

test('META response-body reads share the same request deadline',async()=>{
 let calls=0,signal,cancelled=false;
 const f=timeoutAdapter(async(url,init)=>{calls++;signal=init.signal;return new Response(new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode('{'));},cancel(){cancelled=true;}}),{headers:{'Content-Type':'application/json'}});});
 await assert.rejects(()=>withDeadline(f.adapter.queryBalance(f.context,transfer())),e=>e.code==='META_GATEWAY_TIMEOUT');
 assert.equal(calls,1);assert.equal(signal.aborted,true);assert.equal(cancelled,true);
});

test('META timed-out deposit surfaces a bounded unknown-outcome error without another submission',async()=>{
 let calls=0;
 const f=timeoutAdapter(async()=>{calls++;return new Promise(()=>{});});
 await assert.rejects(()=>withDeadline(f.adapter.depositToGame(f.context,transfer())),e=>e.code==='META_GATEWAY_TIMEOUT');
 assert.equal(calls,1);
});

test('META catalogue requests use the same bounded gateway deadline',async()=>{
 let calls=0;const f=timeoutAdapter(async()=>{calls++;return new Promise(()=>{});});
 await assert.rejects(()=>withDeadline(f.adapter.listGames(f.context)),e=>e.code==='META_GATEWAY_TIMEOUT');assert.equal(calls,1);
});

test('META cancels an oversized response before an unclosed body can continue buffering',async()=>{
 let cancelled=false;
 const f=timeoutAdapter(async()=>new Response(new ReadableStream({start(controller){controller.enqueue(new Uint8Array(1024*1024));controller.enqueue(new Uint8Array(1024*1024+1));},cancel(){cancelled=true;}})),{timeoutMs:500});
 await assert.rejects(()=>withDeadline(f.adapter.queryBalance(f.context,transfer())),e=>e.code==='META_GATEWAY_RESPONSE_INVALID');assert.equal(cancelled,true);
});

test('META player and transaction identifiers are stable and profile isolated',()=>{const normal=metaGamingPlayerId('metagaming_normal_myr','alice'),free=metaGamingPlayerId('metagaming_free_myr','alice');assert.match(normal,/^m7mn_[a-f0-9]{45}$/);assert.match(free,/^m7mf_[a-f0-9]{45}$/);assert.notEqual(normal,free);assert.notEqual(metaGamingReferenceId('metagaming_normal_myr','same','deposit'),metaGamingReferenceId('metagaming_normal_myr','same','withdrawal'));assert.notEqual(metaGamingReferenceId('metagaming_normal_myr','same','deposit'),metaGamingReferenceId('metagaming_free_myr','same','deposit'));});

test('normal and free adapters bind exact profile, account, player namespace and token role',async()=>{for(const profile of ['metagaming_normal_myr','metagaming_free_myr']){const f=fake(profile),player=await f.adapter.createOrVerifyPlayer(f.context,{userId:'alice',username:'alice'});assert.equal(player.providerPlayerId,metaGamingPlayerId(profile,'alice'));assert.equal((await f.adapter.queryBalance(f.context,{userId:'alice',providerPlayerId:player.providerPlayerId})).amountMinor,'1575');assert.deepEqual((await f.adapter.listGames(f.context)).map(x=>x.providerGameId),['10001']);assert.deepEqual(f.calls.map(x=>x.method),['player','balance']);const other=profile==='metagaming_normal_myr'?'metagaming_free_myr':'metagaming_normal_myr';await assert.rejects(()=>f.adapter.queryBalance({profile:getGameProviderProfile(other)},{userId:'alice',providerPlayerId:player.providerPlayerId}),e=>e.code==='META_PROFILE_MISMATCH');assert.equal(f.calls.length,2);await assert.rejects(()=>f.adapter.queryBalance(f.context,{userId:'alice',providerPlayerId:metaGamingPlayerId(profile,'bob')}),e=>e.code==='META_PLAYER_MISMATCH');assert.equal(f.calls.length,2);}});

test('disabled META capabilities make zero gateway calls even with complete credentials',async()=>{const cfg=config(),calls=[],adapter=createMetaGamingProviderAdapter(cfg,{fetchImpl:async()=>{calls.push(1);throw Error('must not call');},allowedReturnOrigins:['https://www.master7.best'],merchantContractVerified:true,sessionClosureVerified:true}),context={profile:getGameProviderProfile(cfg.profile)},input=transfer();for(const action of [()=>adapter.createOrVerifyPlayer(context,{userId:'alice',username:'alice'}),()=>adapter.queryBalance(context,input),()=>adapter.depositToGame(context,input),()=>adapter.withdrawFromGame(context,input),()=>adapter.queryTransfer(context,{...input,direction:'deposit'}),()=>adapter.launchGame(context,{userId:'alice',providerPlayerId:input.providerPlayerId,providerGameId:'10001',language:'en',ip:'192.0.2.8',returnUrl:'https://www.master7.best/'})])await assert.rejects(action,e=>/DISABLED/.test(e.code));assert.equal(calls.length,0);});

test('META catalogue stays closed without profile-bound availability evidence',async()=>{
 const cfg=config(),calls=[],adapter=createMetaGamingProviderAdapter(cfg,{fetchImpl:async()=>{calls.push(1);throw Error('must not call');},allowedReturnOrigins:['https://www.master7.best'],merchantContractVerified:true}),context={profile:getGameProviderProfile(cfg.profile)};
 await assert.rejects(()=>adapter.listGames(context),e=>e.code==='META_CATALOGUE_UNVERIFIED');assert.equal(calls.length,0);
});

test('transfer submit without status permission remains unknown until the exact signed receipt matches',async()=>{
 const f=fake(),input=transfer(),adapter=createMetaGamingProviderAdapter(f.cfg,{fetchImpl:f.transport,allowedReturnOrigins:['https://www.master7.best'],merchantContractVerified:true,sessionClosureVerified:true,depositEnabled:true});
 const submitted=await adapter.depositToGame(f.context,input);assert.deepEqual(submitted,{state:'unknown',errorCode:'META_TRANSFER_STATUS_REQUIRED',requiresLedgerReconciliation:true});assert.deepEqual(f.calls.map(x=>x.method),['deposit']);
 assert.equal(f.calls[0].body.amount,'20.00');assert.equal(f.calls[0].body.referenceId,metaGamingReferenceId(f.cfg.profile,input.platformTransactionId,'deposit'));
 const confirmed=await f.adapter.queryTransfer(f.context,{...input,direction:'deposit'});assert.deepEqual(confirmed,{state:'confirmed',providerTransactionId:'123456',requiresLedgerReconciliation:true});
});

test('META transfer continuation requires one independent status query bound to the same player and reference',async()=>{
 for(const direction of ['deposit','withdrawal']){
  const f=fake(),input=transfer(),result=await f.adapter[direction==='deposit'?'depositToGame':'withdrawFromGame'](f.context,input);
  assert.deepEqual(result,{state:'confirmed',providerTransactionId:'123456',requiresLedgerReconciliation:true});assert.deepEqual(f.calls.map(x=>x.method),[direction==='deposit'?'deposit':'withdraw','transfer-status']);
  assert.equal(f.calls[1].body.referenceId,f.calls[0].body.referenceId);assert.equal(f.calls[1].body.playerId,f.calls[0].body.playerId);assert.equal(f.calls[1].body.transferType,direction);
 }
});

test('META transfer acknowledgements cannot substitute for missing, mismatched or invalid status receipts',async()=>{
 for(const reply of [success({transaction:null}),success({transaction:{transactionId:'123456',amount:'19.99'}}),Response.json({provider:'metagaming',profileId:'metagaming_free_myr',account:'free',operation:'transfer-status',result:success({transaction:{transactionId:'123456',amount:'20.00'}})})]){
  const f=fake('metagaming_normal_myr',{'transfer-status':reply});assert.equal((await f.adapter.depositToGame(f.context,transfer())).state,'unknown');assert.deepEqual(f.calls.map(x=>x.method),['deposit','transfer-status']);
 }
});

test('META accepted submit followed by status timeout remains unknown without retrying the submit',async()=>{
 let submissions=0,queries=0;
 const f=timeoutAdapter(async(url)=>{
  const method=new URL(url).pathname.split('/').at(-1);
  if(method==='transfer-status'){queries++;return new Promise(()=>{});}
  submissions++;return Response.json({provider:'metagaming',profileId:'metagaming_normal_myr',account:'normal',operation:'deposit',result:success({currentBalance:'20.00',currency:'MYR'})});
 },{transferStatusEnabled:true});
 assert.equal((await withDeadline(f.adapter.depositToGame(f.context,transfer()))).state,'unknown');assert.equal(submissions,1);assert.equal(queries,1);
});

test('launch accepts only documented English, exact return origin, exact IPv4 and approved provider origin',async()=>{const f=fake(),input={userId:'alice',providerPlayerId:metaGamingPlayerId(f.cfg.profile,'alice'),providerGameId:'10001',language:'en',ip:'192.0.2.8',returnUrl:'https://www.master7.best/'};assert.equal((await f.adapter.launchGame(f.context,input)).launchUrl,'https://games.example.test/play?session=synthetic');assert.equal(f.calls[0].body.language,'en');assert.equal(f.calls[0].body.demo,false);for(const patch of [{language:'zh'},{ip:'999.0.0.1'},{ip:'256.0.0.1'},{ip:'192.00.2.8'},{returnUrl:'https://master7.best/'},{returnUrl:'https://www.master7.best/#fragment'}])await assert.rejects(()=>f.adapter.launchGame(f.context,{...input,...patch}),e=>/^META_/.test(e.code));assert.equal(f.calls.length,1);const bad=fake('metagaming_normal_myr',{launch:success({url:'https://unapproved.example.test/play'})});await assert.rejects(()=>bad.adapter.launchGame(bad.context,input),e=>e.code==='META_LAUNCH_URL_INVALID');const wrongOperation=fake('metagaming_normal_myr',{launch:Response.json({provider:'metagaming',profileId:'metagaming_normal_myr',account:'normal',operation:'balance',result:success({url:'https://games.example.test/play'})})});await assert.rejects(()=>wrongOperation.adapter.launchGame(wrongOperation.context,input),e=>e.code==='META_GATEWAY_BINDING_INVALID');});

test('PullLog reports are projected without auto-flagging or false coverage',async()=>{const profile='metagaming_normal_myr',playerId=metaGamingPlayerId(profile,'alice'),f=fake(profile,{reports:success({logs:[{transactionId:'9007199254740993123',playerId,turnover:'3.60',validTurnover:'3.60',payout:'1.80',winLose:'-1.80',transactionDateTime:'2026-11-10T08:30:00Z',transactionType:0,gameCode:'10001',gameType:1,gameName:'Synthetic'}]})}),page=await f.adapter.fetchWagers(f.context,{from:Date.parse('2026-11-10T08:00:00Z'),to:Date.parse('2026-11-10T09:00:00Z')});assert.equal(page.complete,false);assert.equal(page.nextCursor,undefined);assert.equal(page.items[0].providerBetId,'9007199254740993123');assert.equal(page.items[0].betMinor,'360');assert.equal(page.items[0].winMinor,'180');assert.equal(page.items[0].providerRoundId,null);assert.equal(page.items[0].sourceDetails.flagging,'not_performed');assert.deepEqual(f.calls.map(x=>x.method),['reports']);});

test('runtime requires isolated tokens, accepted catalogue, contract, finality evidence and explicit account binding',()=>{const connection=config(),slot={mode:'production',environment:'production',recoveryEnabled:true,reportEnabled:true,reportFlaggingVerified:true,qaMemberIds:['alice'],approvedApiOrigins:[connection.baseUrl],allowedReturnOrigins:['https://www.master7.best'],connection,merchantContractVerified:true,merchantContractEvidenceSha256:'a'.repeat(64),catalogueAvailabilityVerified:true,catalogueAvailabilityEvidenceSha256:'d'.repeat(64),sessionClosureVerified:true,sessionClosureEvidenceSha256:'b'.repeat(64),allIssuedLaunchesInvalidated:true,lateResultsFinal:true,reportEvidenceSha256:'c'.repeat(64)},document=()=>JSON.stringify({profiles:{[connection.profile]:slot}});assert.equal(metaGamingProfileRuntime(document(),connection.profile,'alice').launchAuthorized,false);let runtime=metaGamingProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true});assert.ok(runtime);assert.equal(runtime.launchAuthorized,true);assert.equal(runtime.catalogueEnabled,true);assert.equal(runtime.recoveryEnabled,true);assert.equal(runtime.reportEnabled,true);assert.equal(gameTransferRuntime({gameTransferProfilesJson:document()},connection.profile,'alice',true).adapter.key,'metagaming');slot.catalogueAvailabilityEvidenceSha256='';runtime=metaGamingProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true});assert.equal(runtime.launchAuthorized,false);assert.equal(runtime.catalogueEnabled,false);slot.catalogueAvailabilityEvidenceSha256='d'.repeat(64);slot.lateResultsFinal=false;runtime=metaGamingProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true});assert.equal(runtime.launchAuthorized,false);assert.equal(runtime.recoveryEnabled,false);slot.lateResultsFinal=true;connection.walletToken=connection.playerToken;assert.equal(metaGamingProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true}),null);connection.walletToken=tokens.wallet;connection.account='free';assert.equal(metaGamingProfileRuntime(document(),connection.profile,'alice',{productionAccepted:true}),null);});

test('free-credit META adapter remains outside the member cash ledger',async()=>{const connection=config('metagaming_free_myr'),slot={mode:'qa',environment:'production',recoveryEnabled:true,reportEnabled:false,reportFlaggingVerified:false,qaMemberIds:['alice'],approvedApiOrigins:[connection.baseUrl],allowedReturnOrigins:['https://www.master7.best'],connection,merchantContractVerified:true,merchantContractEvidenceSha256:'a'.repeat(64),catalogueAvailabilityVerified:true,catalogueAvailabilityEvidenceSha256:'d'.repeat(64),sessionClosureVerified:true,sessionClosureEvidenceSha256:'b'.repeat(64),allIssuedLaunchesInvalidated:true,lateResultsFinal:true},runtime=gameTransferRuntime({gameTransferProfilesJson:JSON.stringify({profiles:{[connection.profile]:slot}})},connection.profile,'alice');assert.ok(runtime);assert.equal(runtime.profile.balanceClass,'free_credit');assert.equal(runtime.adapter.executable,true);assert.equal(runtime.launchAuthorized,true);assert.equal(await seedTransferProfile({prepare(){throw Error('cash database must not be touched');}},runtime),false);});
