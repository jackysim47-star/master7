import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {probeProductionReadiness,validateBaseUrl} from '../scripts/production-readiness-probe.mjs';

const providerIds=['megah5','jili','918kissh5','gameplay','lionking','suncity','pgsoft','gfg','sagaming','ps9','dragoonsoft','jdb','bg','allbet','quickspin','astar','metagaming','fuma','yl','funky','gamitech','spadegaming','turbo','ct855','pragmaticplay','joker','cg','atg','rectangle','m8bet','awc','evo888h5','cosmoplay','geminiupdown','epicwin','venus','clotplay'];
const providers=providerIds.map((id,index)=>({id,position:index+1,platformLaunchReady:false,launchReady:false,launchVerified:false,walletVerified:false,settlementVerified:false,playable:false,platformStatus:'awaiting_api',operationalStatus:'awaiting_api'}));
const sourceRelease='17.0.0-v8-fixture';
const closedCapabilities={...Object.fromEntries(['vpay','gspay','1mpay'].map(provider=>[provider,{deposit:{enabled:false,blockers:['new_deposits_paused']}}])),gspay_usdt:{deposit:{implemented:false,enabled:false,blockers:['provider_contract_unverified','deposit_adapter_not_implemented']}}};
const closedStatus=provider=>({provider,readOnly:true,enabled:false,orderReady:false,realPayments:false,queryReady:true,callbacksReady:true,capabilities:{deposit:{enabled:false,blockers:['new_deposits_paused']}}});
const closedUsdtStatus={provider:'gspay',profileId:'gspay_usdt',currency:'USDT',readOnly:true,enabled:false,orderReady:false,realPayments:false,queryReady:false,callbacksReady:false,capabilities:{deposit:{implemented:false,enabled:false,blockers:['provider_contract_unverified','deposit_adapter_not_implemented']}}};
const payloads={
 '/health/live':{status:'ok',database:'ready',release:sourceRelease,sourceRelease,scope:'portal-liveness'},
 '/health':{status:'ok',database:'ready',release:sourceRelease,sourceRelease,maintenanceControlsConfigured:{deposits:true,gameLaunches:true,payouts:true},productionReady:false,settlementVerified:false,transactionsEnabled:false,realPayments:false,payoutsEnabled:false,liveGames:false,newDepositsEnabled:false,newGameLaunchesEnabled:false,newPayoutsEnabled:false,providerOrdersEnabled:{vpay:false,gspay:false,gspay_usdt:false,'1mpay':false},providerPayoutsEnabled:{vpay:false,gspay:false,gspay_usdt:false,'1mpay':false},providerCapabilities:closedCapabilities,readinessBlockers:['deposit_provider_not_ready','payout_provider_not_ready','payment_settlement_not_verified','game_launch_or_settlement_not_ready']},
 '/api/version':{status:'ok',database:'ready',release:sourceRelease,sourceRelease},
 '/api/payment-channels':{readOnly:true,maintenanceControlsConfigured:{deposits:true,gameLaunches:true,payouts:true},transactionsEnabled:false,realPayments:false,payoutsEnabled:false,providerOrdersEnabled:{vpay:false,gspay:false,gspay_usdt:false,'1mpay':false,gspay_plus:false},providerPayoutsEnabled:{vpay:false,gspay:false,gspay_usdt:false,'1mpay':false},items:[...['vpay','gspay','1mpay'].map(provider_id=>({provider_id,enabled:false,status:'unavailable',channelStatus:'unavailable',settlementVerified:false,capabilities:{deposit:{enabled:false,blockers:['new_deposits_paused']}}})),{provider_id:'gspay_usdt',enabled:false,status:'unavailable',channelStatus:'unavailable',settlementVerified:false,capabilities:{deposit:{implemented:false,enabled:false,blockers:['provider_contract_unverified','deposit_adapter_not_implemented']}}}]},
 '/api/payments/vpay/status':closedStatus('vpay'),
 '/api/payments/gspay/status':closedStatus('gspay'),
 '/api/payments/gspay/usdt/status':closedUsdtStatus,
 '/api/payments/1mpay/status':closedStatus('1mpay'),
 '/api/withdrawal-banks':{currency:'MYR',enabled:false,banks:[],providers:[{id:'vpay',enabled:false},{id:'gspay',enabled:false},{id:'1mpay',enabled:false}]},
 '/api/games':{readOnlyAvailability:true,providers,games:[],platformCount:37,liveReady:false,playable:false},
 '/api/games?provider=__probe_invalid__':{error:'Invalid game provider'},
};

async function serve(t,handler){
 const server=createServer(handler);await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));t.after(()=>new Promise(resolve=>server.close(resolve)));
 const address=server.address();return `http://127.0.0.1:${address.port}`;
}

test('read-only probe accepts a closed 37-provider release and sends no credentials',async t=>{
 const calls=[],baseUrl=await serve(t,(req,res)=>{calls.push({method:req.method,url:req.url,authorization:req.headers.authorization,cookie:req.headers.cookie});res.statusCode=req.url.includes('__probe_invalid__')?400:200;res.setHeader('content-type','application/json');res.setHeader('cache-control','no-store');res.end(JSON.stringify(payloads[req.url]));});
 const result=await probeProductionReadiness({baseUrl,expectedReleasePrefix:'17.0.0-v8'});
 assert.equal(result.ok,true);assert.equal(result.providerPositions,37);assert.equal(result.channelCount,4);
 assert.deepEqual(new Set(calls.map(item=>item.url)),new Set(Object.keys(payloads)));assert.ok(calls.every(item=>item.method==='GET'));
 assert.ok(calls.every(item=>item.authorization===undefined&&item.cookie===undefined));
});

for(const flag of ['newDepositsEnabled','newGameLaunchesEnabled','newPayoutsEnabled','productionReady','transactionsEnabled','realPayments','payoutsEnabled','liveGames'])test(`probe rejects open health flag ${flag}`,async t=>{
 const changed=structuredClone(payloads);changed['/health'][flag]=true;
 const baseUrl=await serve(t,(req,res)=>{res.statusCode=req.url.includes('__probe_invalid__')?400:200;res.setHeader('content-type','application/json');res.setHeader('cache-control','no-store');res.end(JSON.stringify(changed[req.url]));});
 const result=await probeProductionReadiness({baseUrl});assert.equal(result.ok,false);assert.equal(result.checks.find(item=>item.name===`health.${flag}`).pass,false);
});

test('probe rejects an enabled payment channel and playable unverified provider',async t=>{
 const changed=structuredClone(payloads);changed['/api/payment-channels'].items[0].enabled=true;changed['/api/games'].providers[0].playable=true;
 const baseUrl=await serve(t,(req,res)=>{res.statusCode=req.url.includes('__probe_invalid__')?400:200;res.setHeader('content-type','application/json');res.setHeader('cache-control','no-store');res.end(JSON.stringify(changed[req.url]));});
 const result=await probeProductionReadiness({baseUrl});assert.equal(result.ok,false);
 assert.equal(result.checks.find(item=>item.name==='paymentChannels.itemsClosed').pass,false);assert.equal(result.checks.find(item=>item.name==='games.unverifiedProvidersClosed').pass,false);
});

test('probe rejects maintenance switches that only default closed instead of being explicit',async t=>{
 const changed=structuredClone(payloads);changed['/health'].maintenanceControlsConfigured.gameLaunches=false;
 const baseUrl=await serve(t,(req,res)=>{res.statusCode=req.url.includes('__probe_invalid__')?400:200;res.setHeader('content-type','application/json');res.setHeader('cache-control','no-store');res.end(JSON.stringify(changed[req.url]));});
 const result=await probeProductionReadiness({baseUrl});assert.equal(result.ok,false);
 assert.equal(result.checks.find(item=>item.name==='health.maintenanceControlsConfigured').pass,false);
});

test('probe rejects redirects',async t=>{
 const baseUrl=await serve(t,(req,res)=>{res.statusCode=302;res.setHeader('location','https://example.invalid/');res.end();});
 await assert.rejects(()=>probeProductionReadiness({baseUrl}),/fetch failed|redirect/i);
});

test('probe rejects credential-bearing URLs before any request',()=>{
 assert.throws(()=>validateBaseUrl('https://owner:secret@example.test'),/must not contain credentials/);
});

test('probe rejects release drift, missing provider positions and cacheable responses',async t=>{
 const changed=structuredClone(payloads);changed['/api/version'].release='other';changed['/api/games'].providers[0].position=2;
 const baseUrl=await serve(t,(req,res)=>{res.statusCode=req.url.includes('__probe_invalid__')?400:200;res.setHeader('content-type','application/json');res.setHeader('cache-control','no-store');res.end(JSON.stringify(changed[req.url]));});
 const result=await probeProductionReadiness({baseUrl});assert.equal(result.ok,false);
 assert.equal(result.checks.find(item=>item.name==='version.releaseMatchesHealth').pass,false);assert.equal(result.checks.find(item=>item.name==='games.positions').pass,false);
 const cacheable=await serve(t,(req,res)=>{res.statusCode=req.url.includes('__probe_invalid__')?400:200;res.setHeader('content-type','application/json');res.end(JSON.stringify(payloads[req.url]));});
 await assert.rejects(()=>probeProductionReadiness({baseUrl:cacheable}),/Cache-Control/);
});

test('probe times out without exposing response data',async t=>{
 const baseUrl=await serve(t,()=>{});await assert.rejects(()=>probeProductionReadiness({baseUrl,timeoutMs:25}),/timed out/);
});
