import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle} from '../lib/backend.ts';

// Mixed-mode coverage is deliberately kept at the router and capability
// boundary. Provider-specific suites separately prove successful deposits,
// game sessions and payouts. These requests cannot reach a real supplier.
const origin='https://portal.example.test';
const gateway='https://master7-integration-gateway.onrender.com';

function fixture(t,flags){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
 for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(file=>file.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 sqlite.exec(`
  INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member@example.test','member',1,'csrf-member',0);
  INSERT INTO company_bank_accounts(id,bank_name,account_name,account_number,enabled,position,updated_by,updated_at)
   VALUES('bank','Fixture Bank','MASTER7 FIXTURE','1234567890',1,0,'member',0);
  UPDATE payment_channel_controls SET status='active' WHERE provider_id='vpay';
 `);
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sqlite.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sqlite.prepare(this.text).all(...this.args)};}
  async run(){return sqlite.prepare(this.text).run(...this.args);}
 }
 const db={prepare:text=>new Statement(text),async batch(statements){sqlite.exec('BEGIN');try{const result=statements.map(statement=>sqlite.prepare(statement.text).run(...statement.args));sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.prepare("INSERT INTO settings(id,value) VALUES('manual_bank:configuration',?)").run(JSON.stringify({mode:'qa',qaMemberIds:['member']}));
 const context={
  db,identity:{userId:'member',email:'member@example.test'},ownerEmail:'owner@example.test',allowedOrigins:[origin],
  newDepositsEnabled:String(flags.deposits),newGameLaunchesEnabled:String(flags.games),newPayoutsEnabled:String(flags.payouts),
  withdrawalDataKey:'withdrawal-key-'.padEnd(40,'w'),vpayGatewayUrl:gateway,vpayPayoutToken:'payout-token-'.padEnd(40,'p'),vpayCallbackToken:'callback-token-'.padEnd(40,'c'),vpayPayoutEnabled:'true',vpayTraderId:'3647',
  vpayFetch:async()=>{throw Error('Mixed maintenance test attempted a supplier request');},
  gameGatewayFetch:async()=>{throw Error('Mixed maintenance test attempted a game request');},
 };
 async function call(path,{method='GET',data}={}){
  const response=await handle(new Request(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json','X-CSRF-Token':'csrf-member','X-Forwarded-For':'203.0.113.8'},...(data===undefined?{}:{body:JSON.stringify(data)})}),context);
  return {status:response.status,data:await response.json()};
 }
 t.after(()=>sqlite.close());return {sqlite,call};
}

const scenarios=[
 {name:'deposits paused only',flags:{deposits:false,games:true,payouts:true}},
 {name:'games paused only',flags:{deposits:true,games:false,payouts:true}},
 {name:'payouts paused only',flags:{deposits:true,games:true,payouts:false}},
];

for(const scenario of scenarios)test(`mixed maintenance matrix: ${scenario.name}`,async t=>{
 t.mock.method(globalThis,'fetch',async()=>{throw Error('Unexpected external request');});
 const {sqlite,call}=fixture(t,scenario.flags),before={
  deposits:sqlite.prepare('SELECT COUNT(*) count FROM deposit_orders').get().count,
  withdrawals:sqlite.prepare('SELECT COUNT(*) count FROM withdrawal_requests').get().count,
  sessions:sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,
 };

 const accounts=await call('/api/manual-bank/accounts');assert.equal(accounts.status,200);
 if(scenario.flags.deposits){assert.equal(accounts.data.maintenance,undefined);assert.equal(accounts.data.items.length,1);}
 else{assert.equal(accounts.data.maintenance,true);assert.deepEqual(accounts.data.items,[]);}
 const deposit=await call('/api/manual-bank/deposits',{method:'POST',data:{}});
 assert.equal(deposit.status,scenario.flags.deposits?400:503);
 assert.equal(deposit.data.code,scenario.flags.deposits?undefined:'DEPOSITS_MAINTENANCE');

 const launch=await call('/api/game-launch',{method:'POST',data:{}});
 assert.equal(launch.status,scenario.flags.games?400:503);
 assert.equal(launch.data.code,scenario.flags.games?undefined:'GAMES_MAINTENANCE');

 const banks=await call('/api/withdrawal-banks');assert.equal(banks.status,200);
 assert.equal(banks.data.providers.find(provider=>provider.id==='vpay').enabled,scenario.flags.payouts);
 const withdrawal=await call('/api/withdrawals',{method:'POST',data:{providerId:'vpay',bankCode:'invalid',accountHolder:'Fixture Member',accountNumber:'1234567890',amount:'10.00',requestKey:'maintenance-matrix-0001'}});
 assert.equal(withdrawal.status,scenario.flags.payouts?400:503);
 assert.match(withdrawal.data.error,scenario.flags.payouts?/Invalid withdrawal details/:/payout is not connected/);

 assert.deepEqual({
  deposits:sqlite.prepare('SELECT COUNT(*) count FROM deposit_orders').get().count,
  withdrawals:sqlite.prepare('SELECT COUNT(*) count FROM withdrawal_requests').get().count,
  sessions:sqlite.prepare('SELECT COUNT(*) count FROM game_wallet_sessions').get().count,
 },before,'maintenance checks and validation failures must not create financial records');
});
