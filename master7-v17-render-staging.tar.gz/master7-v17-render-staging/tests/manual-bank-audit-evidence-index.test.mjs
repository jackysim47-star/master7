import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';

const migration=readFileSync(new URL('../drizzle/0124_manual_bank_audit_evidence_index.sql',import.meta.url),'utf8');

test('manual-bank paid evidence index is partial, non-unique, covering and idempotent',()=>{
 const db=new DatabaseSync(':memory:');
 try{
  db.exec('CREATE TABLE audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,event TEXT NOT NULL,target TEXT NOT NULL,created_at INTEGER NOT NULL)');
  db.exec(migration);db.exec(migration);
  const listed=db.prepare("PRAGMA index_list('audit')").all().find(row=>row.name==='audit_manual_bank_payout_paid_evidence');
  assert.deepEqual({unique:listed?.unique,partial:listed?.partial},{unique:0,partial:1});
  assert.deepEqual(db.prepare("PRAGMA index_info('audit_manual_bank_payout_paid_evidence')").all().map(row=>row.name),['target','user_id','created_at']);
  const definition=db.prepare("SELECT sql FROM sqlite_master WHERE type='index' AND name='audit_manual_bank_payout_paid_evidence'").get().sql;
  assert.match(definition,/WHERE event='manual_bank_payout_paid'$/);
  const insert=db.prepare('INSERT INTO audit(id,user_id,event,target,created_at) VALUES(?,?,?,?,?)');
  for(let i=0;i<200;i++)insert.run(`other-${i}`,'owner','other_event',`target-${i}`,i);
  insert.run('paid-1','owner','manual_bank_payout_paid','bank-transaction',123);
  insert.run('paid-2','owner','manual_bank_payout_paid','bank-transaction',123);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM audit a WHERE a.event='manual_bank_payout_paid' AND a.target=? AND a.user_id=?").get('bank-transaction','owner').n,2,'duplicates remain detectable for fail-closed review');
  for(const query of [
   "EXPLAIN QUERY PLAN SELECT COUNT(*) FROM audit a WHERE a.event='manual_bank_payout_paid' AND a.target=? AND a.user_id=?",
   "EXPLAIN QUERY PLAN SELECT 1 FROM audit a WHERE a.event='manual_bank_payout_paid' AND a.target=? AND a.user_id=? AND a.created_at=? LIMIT 1",
  ]){
   const args=query.includes('created_at')?['bank-transaction','owner',123]:['bank-transaction','owner'];
   const plan=db.prepare(query).all(...args).map(row=>row.detail).join('\n');
   assert.match(plan,/USING COVERING INDEX audit_manual_bank_payout_paid_evidence/);
  }
 }finally{db.close();}
});
