import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const style=readFileSync(new URL('../public/assets/style.css',import.meta.url),'utf8');
const start=app.indexOf('const gameSyncCopy='),end=app.indexOf('async function renderGameSync',start);
assert.ok(start>=0&&end>start,'game check presentation helpers must be present');
const context={Number,String};
vm.runInNewContext(`${app.slice(start,end)}\nthis.helpers={gameSyncCopy,gameCheckExplicitError,gameCheckCount,gameCheckReason,gameCheckPresentation};`,context);
const {gameSyncCopy,gameCheckExplicitError,gameCheckCount,gameCheckReason,gameCheckPresentation}=context.helpers,copy=gameSyncCopy.en;

test('current catalogue is distinct from launch and wallet acceptance',()=>{
 const provider={status:'available',count:297,stale:false,connectionVerified:true,catalogueSynced:true,launchVerified:false,walletVerified:false};
 assert.equal(gameCheckPresentation(provider,'connectionVerified',copy).tone,'ready');
 assert.equal(gameCheckPresentation(provider,'connectionVerified',copy).label,'Connected');
 assert.equal(gameCheckPresentation(provider,'catalogueSynced',copy).tone,'ready');
 assert.equal(gameCheckPresentation(provider,'catalogueSynced',copy).label,'297 catalogued');
 assert.equal(gameCheckPresentation(provider,'launchVerified',copy).tone,'progress');
 assert.equal(gameCheckPresentation(provider,'walletVerified',copy).tone,'progress');
 assert.equal(gameCheckReason(provider,copy),'Catalogue is synced; launch and wallet acceptance are pending');
});

test('missing vendor API is waiting rather than a red failure',()=>{
 const provider={status:'not_configured',platformStatus:'awaiting_api',count:0,stale:false,connectionVerified:false,catalogueSynced:false,launchVerified:false,walletVerified:false};
 assert.equal(gameCheckPresentation(provider,'connectionVerified',copy).tone,'waiting');
 assert.equal(gameCheckPresentation(provider,'connectionVerified',copy).label,'Waiting for vendor API');
 assert.equal(gameCheckPresentation(provider,'catalogueSynced',copy).label,'0 titles');
 assert.equal(gameCheckPresentation(provider,'launchVerified',copy).tone,'waiting');
 assert.equal(gameCheckPresentation(provider,'walletVerified',copy).tone,'waiting');
 assert.equal(gameCheckReason(provider,copy),'Waiting for vendor API');
 assert.equal(gameCheckExplicitError(provider),false);
});

test('provider rejection is red while a retained catalogue stays amber',()=>{
 const provider={status:'blocked',upstreamStatus:502,count:64,stale:true,connectionVerified:false,catalogueSynced:true,launchVerified:false,walletVerified:false};
 assert.equal(gameCheckPresentation(provider,'connectionVerified',copy).tone,'error');
 assert.equal(gameCheckPresentation(provider,'connectionVerified',copy).label,'Provider check failed · HTTP 502');
 assert.equal(gameCheckPresentation(provider,'catalogueSynced',copy).tone,'waiting');
 assert.equal(gameCheckPresentation(provider,'catalogueSynced',copy).label,'64 retained');
 assert.equal(gameCheckPresentation(provider,'launchVerified',copy).tone,'waiting');
 assert.equal(gameCheckReason(provider,copy),'Provider check failed · HTTP 502');
});

test('no result does not invent a failure or catalogue count',()=>{
 for(const key of ['connectionVerified','catalogueSynced','launchVerified','walletVerified']){
  const status=gameCheckPresentation(undefined,key,copy);assert.equal(status.tone,'waiting');assert.equal(status.label,'No check result');
 }
 assert.equal(gameCheckCount(undefined),null);
 assert.equal(gameCheckCount({count:null}),null);
 assert.equal(gameCheckReason(undefined,copy),'No check result');
});

test('legacy owner state does not override actual API checks',()=>{
 for(const operationalStatus of ['closed','suspended']){
  const result={operationalStatus,status:'available',count:64,connectionVerified:true,catalogueSynced:true,launchVerified:false,walletVerified:false};
  assert.equal(gameCheckPresentation(result,'connectionVerified',copy).label,'Connected');
  assert.equal(gameCheckPresentation(result,'catalogueSynced',copy).label,'64 catalogued');
  assert.equal(gameCheckPresentation(result,'launchVerified',copy).tone,'progress');
  assert.equal(gameCheckReason(result,copy),'Catalogue is synced; launch and wallet acceptance are pending');
 }
});

test('game checks use accessible semantic pills and reserve red for errors',()=>{
 const source=app.slice(start,app.indexOf('function adminGameFiltered',start));
 assert.doesNotMatch(source,/❌|Incomplete|game-check-pending|game-check-done/);
 assert.match(source,/pill\.setAttribute\("aria-label"/);
 assert.match(style,/\.game-check-pill\.is-ready\{color:var\(--game-check-ready\)\}/);
 assert.match(style,/\.game-check-pill\.is-progress\{color:var\(--game-check-progress\)\}/);
 assert.match(style,/\.game-check-pill\.is-waiting\{color:var\(--game-check-waiting\)\}/);
 assert.match(style,/\.game-check-pill\.is-error\{color:var\(--game-check-error\)\}/);
 assert.match(style,/@media\(prefers-reduced-motion:reduce\)/);
 assert.doesNotMatch(app,/🔧 Maintenance/);
 assert.match(app,/⏳ Acceptance pending/);
});


test('available launch and wallet contracts stay distinct from settlement acceptance',()=>{
 const provider={status:'available',count:297,stale:false,connectionVerified:true,catalogueSynced:true,launchReady:true,walletReady:true,launchVerified:false,walletVerified:false};
 assert.equal(gameCheckPresentation(provider,'launchVerified',copy).tone,'progress');
 assert.equal(gameCheckPresentation(provider,'launchVerified',copy).label,'Launch available · acceptance pending');
 assert.equal(gameCheckPresentation(provider,'walletVerified',copy).label,'Wallet API available · acceptance pending');
 assert.equal(gameCheckReason(provider,copy),'Launch and wallet APIs are available; settlement acceptance is pending');
 assert.equal(gameCheckPresentation({...provider,stale:true},'launchVerified',copy).label,'Waiting for catalogue');
});
