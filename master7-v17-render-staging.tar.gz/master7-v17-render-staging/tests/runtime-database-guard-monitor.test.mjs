import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { startRuntimeDatabaseGuardMonitor } from "../scripts/runtime-database-guard-monitor.mjs";
import { criticalDatabaseGuardRows } from "./critical-database-guard-fixture.mjs";

class FakeClient {
  constructor({ rows = criticalDatabaseGuardRows(), connectError, queryError, endError, eventError, queryGate } = {}) {
    this.rows = rows;
    this.connectError = connectError;
    this.queryError = queryError;
    this.endError = endError;
    this.eventError = eventError;
    this.queryGate = queryGate;
    this.connects = 0;
    this.queries = 0;
    this.ends = 0;
  }
  on(event, listener) { if (event === "error") this.errorListener = listener; }
  off(event, listener) { if (event === "error" && this.errorListener === listener) this.errorListener = undefined; }
  async connect() { this.connects++; if (this.connectError) throw this.connectError; }
  async query() {
    this.queries++;
    if (this.queryGate) await this.queryGate;
    if (this.queryError) throw this.queryError;
    if (this.eventError) this.errorListener?.(this.eventError);
    return { rows: this.rows };
  }
  async end() { this.ends++; if (this.endError) throw this.endError; }
}

function harness(overrides = {}) {
  const clients = [];
  const scheduled = [];
  const cancelled = [];
  const exits = [];
  const logs = [];
  const errors = [];
  const monitor = startRuntimeDatabaseGuardMonitor({
    connectionString: "postgresql://fixture.invalid/master7",
    clientFactory: () => {
      const client = overrides.clientFactory?.() ?? new FakeClient();
      clients.push(client);
      return client;
    },
    schedule: (callback, delay) => {
      const timer = { callback, delay };
      scheduled.push(timer);
      return timer;
    },
    cancel: timer => cancelled.push(timer),
    exit: code => exits.push(code),
    logger: { log: message => logs.push(message), error: message => errors.push(message) },
    intervalMs: overrides.intervalMs,
    queryTimeoutMs: overrides.queryTimeoutMs,
    cleanupTimeoutMs: overrides.cleanupTimeoutMs,
  });
  return { monitor, clients, scheduled, cancelled, exits, logs, errors };
}

test("runtime database guard monitor verifies immediately and schedules only after completion", async () => {
  let releaseQuery;
  const queryGate = new Promise(resolve => { releaseQuery = resolve; });
  const h = harness({ clientFactory: () => new FakeClient({ queryGate }), intervalMs: 15_000, queryTimeoutMs: 1_000 });
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(h.monitor.isRunning(), true);
  assert.equal(h.scheduled.length, 0);
  releaseQuery();
  assert.equal(await h.monitor.ready, true);
  assert.equal(h.clients.length, 1);
  assert.equal(h.clients[0].ends, 1);
  assert.equal(h.scheduled.length, 1);
  assert.equal(h.scheduled[0].delay, 15_000);
  assert.equal(h.logs.length, 1);
  assert.match(h.logs[0], /database guards 9\/9 ready; guard functions 5\/5 attested/);
  assert.deepEqual(h.exits, []);
  await h.monitor.stop();
  assert.deepEqual(h.cancelled, [h.scheduled[0]]);
});

test("runtime database guard monitor uses one short connection per cycle without overlap", async () => {
  let releaseSecond;
  const clients = [new FakeClient(), new FakeClient({ queryGate: new Promise(resolve => { releaseSecond = resolve; }) })];
  const h = harness({ clientFactory: () => clients.shift() });
  assert.equal(await h.monitor.ready, true);
  const secondRun = h.scheduled[0].callback();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(h.monitor.isRunning(), true);
  assert.equal(h.scheduled.length, 1, "the next timer is not scheduled while a check is in flight");
  releaseSecond();
  assert.equal(await secondRun, true);
  assert.equal(h.scheduled.length, 2);
  assert.equal(h.logs.length, 1, "success is logged once instead of every interval");
  assert.ok(h.clients.every(client => client.connects === 1 && client.queries === 1 && client.ends === 1));
  await h.monitor.stop();
});

test("stop is idempotent before a timer and during an in-flight check", async () => {
  let releaseQuery;
  const queryGate = new Promise(resolve => { releaseQuery = resolve; });
  const h = harness({ clientFactory: () => new FakeClient({ queryGate }) });
  await new Promise(resolve => setImmediate(resolve));
  const stopping = h.monitor.stop();
  releaseQuery();
  await stopping;
  await h.monitor.stop();
  assert.equal(await h.monitor.ready, true);
  assert.equal(h.scheduled.length, 0);
  assert.deepEqual(h.exits, []);
});

test("runtime database guard drift fails closed once without logging guard source", async () => {
  const rows = criticalDatabaseGuardRows();
  rows[0] = { ...rows[0], function_source: "BEGIN RETURN NEW; END" };
  const h = harness({ clientFactory: () => new FakeClient({ rows }) });
  assert.equal(await h.monitor.ready, false);
  assert.equal(h.monitor.hasFailed(), true);
  assert.deepEqual(h.exits, [1]);
  assert.equal(h.scheduled.length, 0);
  assert.deepEqual(h.errors, ["MASTER7 runtime database guard monitor fail-closed (ATTESTATION:UNKNOWN); exiting."]);
  assert.doesNotMatch(h.errors[0], /BEGIN RETURN NEW/);
  await h.monitor.stop();
});

for (const [name, options, category] of [
  ["connect", { connectError: Object.assign(new Error("sensitive-private-password-material"), { code: "ECONNREFUSED" }) }, "CONNECT"],
  ["query", { queryError: Object.assign(new Error("sensitive-private-password-material"), { code: "57014" }) }, "ATTESTATION"],
  ["cleanup", { endError: Object.assign(new Error("sensitive-private-password-material"), { code: "ECONNRESET" }) }, "CLEANUP"],
  ["client event", { eventError: Object.assign(new Error("sensitive-private-password-material"), { code: "EPIPE" }) }, "ATTESTATION"],
]) test(`runtime ${name} errors are sanitized and fail closed exactly once`, async () => {
  const h = harness({ clientFactory: () => new FakeClient(options) });
  assert.equal(await h.monitor.ready, false);
  assert.deepEqual(h.exits, [1]);
  assert.equal(h.errors.length, 1);
  assert.match(h.errors[0], new RegExp(`\\(${category}:[A-Z0-9_]+\\)`));
  assert.doesNotMatch(h.errors[0], /private|password|postgresql/);
  assert.equal(h.scheduled.length, 0);
  await h.monitor.stop();
  assert.deepEqual(h.exits, [1]);
});

test("a synchronous client factory failure is handled as one sanitized connect failure", async () => {
  const h = harness({ clientFactory: () => { throw new Error("sensitive-private-password-material"); } });
  assert.equal(await h.monitor.ready, false);
  assert.deepEqual(h.exits, [1]);
  assert.deepEqual(h.errors, ["MASTER7 runtime database guard monitor fail-closed (CONNECT:UNKNOWN); exiting."]);
  assert.equal(h.scheduled.length, 0);
});

test("client cleanup is bounded and destroys a stuck connection before failing closed", async () => {
  let destroyed = 0;
  const client = new FakeClient();
  client.connection = { stream: { destroy: () => { destroyed++; } } };
  client.end = () => new Promise(() => {});
  const h = harness({ clientFactory: () => client, cleanupTimeoutMs: 100 });
  assert.equal(await h.monitor.ready, false);
  assert.equal(destroyed, 1);
  assert.deepEqual(h.exits, [1]);
  assert.deepEqual(h.errors, ["MASTER7 runtime database guard monitor fail-closed (CLEANUP:CLEANUP_TIMEOUT); exiting."]);
  assert.equal(h.scheduled.length, 0);
});

test("a timer scheduling failure cannot silently disable monitoring", async () => {
  const exits = [], errors = [];
  const monitor = startRuntimeDatabaseGuardMonitor({
    connectionString: "postgresql://fixture.invalid/master7",
    clientFactory: () => new FakeClient(),
    schedule: () => { throw Object.assign(new Error("timer internals"), { code: "SCHEDULE_ERROR" }); },
    exit: code => exits.push(code),
    logger: { log: () => {}, error: message => errors.push(message) },
  });
  assert.equal(await monitor.ready, false);
  assert.deepEqual(exits, [1]);
  assert.deepEqual(errors, ["MASTER7 runtime database guard monitor fail-closed (SCHEDULE:SCHEDULE_ERROR); exiting."]);
});

test("runtime database guard monitor is mandatory and bounds operational timing", async () => {
  assert.throws(() => startRuntimeDatabaseGuardMonitor(), /requires a PostgreSQL connection/);
  const h = harness({ intervalMs: 1, queryTimeoutMs: 999_999 });
  assert.equal(h.monitor.intervalMs, 60_000);
  assert.equal(h.monitor.queryTimeoutMs, 10_000);
  assert.equal(h.monitor.cleanupTimeoutMs, 2_000);
  assert.equal(await h.monitor.ready, true);
  await h.monitor.stop();
});

test("Render starts the per-instance monitor outside scheduler leadership", () => {
  const source = readFileSync(new URL("../scripts/start-render.mjs", import.meta.url), "utf8");
  assert.match(source, /startRuntimeDatabaseGuardMonitor\(\{/);
  assert.match(source, /PORTAL_DATABASE_GUARD_MONITOR_INTERVAL_MS/);
  assert.match(source, /PORTAL_DATABASE_GUARD_MONITOR_QUERY_TIMEOUT_MS/);
  assert.ok(source.indexOf("initializePortalDatabase") < source.indexOf("startRuntimeDatabaseGuardMonitor"));
  assert.ok(source.indexOf('await import("../.output/server/index.mjs")') < source.indexOf("startRuntimeDatabaseGuardMonitor"));
  const monitorCall = source.indexOf("startRuntimeDatabaseGuardMonitor({");
  const leaderCall = source.indexOf("startSchedulerLeadership({");
  const workerFactory = source.indexOf("startWorkers:");
  assert.ok(monitorCall < leaderCall && leaderCall < workerFactory, "monitor must run once per instance, not inside leader workers");
  assert.doesNotMatch(source, /process\.(?:on|once)\(["']SIG(?:TERM|INT)/, "default Node signal exit must remain intact");
});
