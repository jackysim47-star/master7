import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
function section(start,end){const a=source.indexOf(start),b=source.indexOf(end,a+start.length);assert.ok(a>=0&&b>a);return source.slice(a,b);}
class Element{constructor(tag='div'){this.tagName=tag;this.className='';this.textContent='';this.children=[];this.hidden=false;this.disabled=false;}append(...children){this.children.push(...children);}replaceChildren(...children){this.children=children;}}
const node=(tag,css='',text='')=>Object.assign(new Element(tag),{className:css,textContent:String(text)});

test('the member can inspect a held profile session without seeing unsupported settlement buttons',()=>{
 const elements=new Map(),get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
 const state={lang:'zh',user:{id:'alice',role:'member',approved:1},gameWalletMemberId:'alice',selectedCatalogProvider:'jdb_myr',gameSettlementBusy:false,gameWallet:{readOnly:true,providerId:'jdb',profileId:'jdb_myr',walletReady:false,liveReady:false,supportsSettlement:false,supportsRecovery:false,wallet:{availableMinor:'6000',gameHeldMinor:'4000'},session:{id:'session1',gameCode:'0:1',status:'active',reservedMinor:'4000'},transfers:[{id:'transfer1',direction:'deposit',status:'unknown',amountMinor:'4000',currency:'MYR'}]}};
 const context={state,$:get,node,clear:el=>el.replaceChildren(),gameProfileEntry:()=>({id:'jdb_myr',name:'JDB MYR',currency:'MYR',walletMode:'transfer'}),apiSupplierState:()=>({}),moneyMinor:value=>`MYR ${value}`};
 vm.runInNewContext(section('const gameWalletCopy=','async function loadGameWallet('),context);
 context.renderGameWallet();assert.equal(get('gameWalletPanel').hidden,false);assert.equal(get('gameWalletHeld').textContent,'MYR 4000');assert.equal(get('gameWalletSettle').hidden,true);assert.equal(get('gameWalletRecover').hidden,true);assert.match(JSON.stringify(get('gameWalletTransfers')),/transfer1/);
 state.gameWallet.session.status='unknown';context.renderGameWallet();assert.match(get('gameWalletSession').textContent,/未确认/);assert.equal(get('gameWalletRecover').hidden,true);
 state.gameWallet={...state.gameWallet,readOnly:false,supportsSettlement:true,supportsRecovery:true,session:{gameCode:'55021',status:'active'}};context.renderGameWallet();assert.equal(get('gameWalletSettle').hidden,false);
 state.gameWallet.session.status='withdraw_unknown';context.renderGameWallet();assert.equal(get('gameWalletRecover').hidden,false);
 state.user={id:'bob',role:'member',approved:1};context.renderGameWallet();assert.equal(get('gameWalletSettle').hidden,true);assert.equal(get('gameWalletRecover').hidden,true);assert.doesNotMatch(get('gameWalletSession').textContent,/55021/);
});

test('a late wallet response cannot replace the newly selected profile or member',async()=>{
 const state={user:{id:'alice',role:'member',approved:1},selectedCatalogProvider:'jdb_myr',gameWalletRequestId:0,gameWallet:null},pending=[];
 const context={state,gameProfileEntry:id=>id?{id,providerId:id.split('_')[0]}:null,gameProfileProviderId:entry=>entry.providerId,renderGameWallet(){},renderCatalog(){},api:path=>new Promise(resolve=>pending.push({path,resolve}))};
 vm.runInNewContext(section('async function loadGameWallet(','function stopGameWindowWatch('),context);
 const old=context.loadGameWallet('jdb_myr');state.selectedCatalogProvider='jili_myr';const current=context.loadGameWallet('jili_myr');
 pending[1].resolve({profileId:'jili_myr',providerId:'jili',session:{id:'jili-session'}});await current;
 pending[0].resolve({profileId:'jdb_myr',providerId:'jdb',session:{id:'jdb-session'}});await old;
 assert.equal(state.gameWallet.profileId,'jili_myr');assert.equal(state.gameWallet.session.id,'jili-session');
 const previousMember=context.loadGameWallet('jili_myr');state.user={id:'bob',role:'member',approved:1};pending[2].resolve({profileId:'jili_myr',providerId:'jili',session:{id:'alice-private'}});await previousMember;
 assert.notEqual(state.gameWallet.session.id,'alice-private');
});

test('closing a game settles the captured member and session even after another profile is selected',async()=>{
 const calls=[],state={user:{id:'alice',role:'member',approved:1},selectedCatalogProvider:'jdb_myr',gameSettlementBusy:false,gameWindow:{closed:true},gameWindowPoll:1,gameWindowContext:{memberId:'alice',profileId:'megah5_myr',sessionId:'mega-session'},gameWallet:{profileId:'jdb_myr',session:{id:'jdb-session',status:'active'}}};
 const context={state,clearInterval(){},renderGameWallet(){},notification(){},gwt:key=>key,loadGameWallet:async()=>{},loadMemberWallet:async()=>{},loadGameCatalogue:async()=>{},api:async(path,method,data)=>{calls.push({path,method,data});return {status:'settled'};}};
 vm.runInNewContext(section('function stopGameWindowWatch(','function publicGameCard('),context);
 await context.settleClosedGameWindow();assert.equal(calls.length,1);assert.equal(calls[0].data.profileId,'megah5_myr');assert.equal(calls[0].data.sessionId,'mega-session');
 state.gameWindow={closed:true};state.gameWindowContext={memberId:'alice',profileId:'megah5_myr',sessionId:'old-session'};state.user={id:'bob',role:'member',approved:1};await context.settleClosedGameWindow();assert.equal(calls.length,1);
});

test('staff view shows generic sessions and unmatched holds without a money-changing action',async()=>{
 const elements=new Map(),get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);},calls=[];
 const context={state:{user:{role:'staff'}},$:get,node,clear:el=>el.replaceChildren(),moneyMinor:value=>`MYR ${value}`,api:async path=>{calls.push(path);return {items:[],profileItems:[{id:'session1',profileId:'jdb_myr',displayName:'JDB MYR',username:'alice',gameCode:'0:1',status:'unknown',reservedMinor:'4000',createdAt:1,lastTransfer:{direction:'deposit',currency:'MYR',amountMinor:'4000',status:'unknown',providerReference:'ref1'}}],unmatchedReservations:[{username:'bob',referenceId:'missing1',amountMinor:'2000'}],walletReady:false,settlementVerified:false};}};
 vm.runInNewContext(section('function adminGameWalletNotice(','async function loadAccounting('),context);
 await context.renderAdminGameWallet();const body=JSON.stringify(get('gameWalletAdminRecords'));
 assert.match(body,/JDB MYR/);assert.match(body,/ref1/);assert.match(body,/missing1/);assert.match(body,/MYR 4000/);assert.equal(get('gameWalletAdminTitle').textContent,'游戏钱包记录 · 2 待处理');
 assert.doesNotMatch(body,/"tagName":"button"/);assert.deepEqual(calls,['/api/admin/game-wallet']);
 context.api=async()=>({items:[],profileItems:[{id:'sweep1',profileId:'jili_my1_1to100',username:'alice',gameCode:'1',status:'withdraw_unknown',createdAt:1,reservedMinor:'2000',lastTransfer:{direction:'withdrawal',currency:'MYR',amountMinor:null,status:'unknown'}}],unmatchedReservations:[]});
 await context.renderAdminGameWallet();const unknown=JSON.stringify(get('gameWalletAdminRecords'));assert.match(unknown,/Amount pending provider confirmation/);assert.doesNotMatch(unknown,/MYR null|MYR undefined/);
});


test('insufficient wallet funds are explained to members in all supported languages',()=>{
 for(const [lang,expected] of [['zh','请先为会员钱包充值，再进入游戏。'],['en','Add funds to your wallet before starting this game.'],['ms','Tambah dana ke dompet anda sebelum memulakan permainan ini.']]){
  const context={state:{lang}};
  assert.equal(vm.runInNewContext(section('const gameWalletCopy=','function gameWalletAmount(')+'\ngwt("fundsRequired")',context),expected);
 }
 assert.match(section('async function startGame(','async function settleGameWallet('),/error\.message==="Add funds to your wallet before starting this game"\?gwt\("fundsRequired"\):error\.message/);
});

test('an unverified game entry explains that acceptance is pending in each language',()=>{
 for(const [lang,wallet,expected] of [['zh','转账钱包','等待生产验收'],['en','Transfer wallet','Production acceptance pending'],['ms','Dompet pindahan','Menunggu penerimaan produksi']]){
  const context={state:{lang},apiSupplierState:()=>({})};
  const result=vm.runInNewContext(section('function profileCapabilityText(','function supplierFavoriteKeys(')+'\nprofileCapabilityText({currency:"MYR",walletMode:"Transfer",capabilityReason:"acceptance_pending"})',context);
  assert.equal(result,`MYR · ${wallet} · ${expected}`);
 }
});

test('customer game cards never expose internal capability codes or unknown wallet modes',()=>{
 const context={state:{lang:'en'},apiSupplierState:()=>({})};
 const source=section('function profileCapabilityText(','function supplierFavoriteKeys(');
 for(const [reason,label] of [['adapter_unimplemented','Provider setup pending'],['contract_missing','Provider contract pending'],['provider_maintenance','Provider maintenance'],['provider_contract_and_acceptance_pending','Provider contract and acceptance pending']]){
  const result=vm.runInNewContext(source+`\nprofileCapabilityText({currency:"MYR",walletMode:"unknown",capabilityReason:"${reason}"})`,context);
  assert.equal(result,`MYR · ${label}`);assert.equal(result.includes(reason),false);
 }
 assert.equal(vm.runInNewContext(source+'\nprofileCapabilityText({currency:"MYR",walletMode:"unknown",capabilityReason:"unknown"})',context),'MYR');
});

test('unclosed provider sessions show reconciliation in all languages and hide financial actions',()=>{
 for(const [lang,expected] of [['zh','游戏会话关闭状态需要核对'],['en','game session closure needs review'],['ms','Penutupan sesi permainan perlu disemak']]){
  const elements=new Map(),get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
  const state={lang,user:{id:'alice',role:'member',approved:1},gameWalletMemberId:'alice',selectedCatalogProvider:'megah5_myr',gameSettlementBusy:false,gameWallet:{supportsSettlement:true,supportsRecovery:true,wallet:{availableMinor:'0',gameHeldMinor:'2000'},session:{id:'wallet1',gameCode:'55021',status:'active',launchState:'unknown',settlementBlocked:true}}};
  const context={state,$:get,node,clear:el=>el.replaceChildren(),gameProfileEntry:()=>({id:'megah5_myr',name:'MegaH5',currency:'MYR',walletMode:'transfer'}),apiSupplierState:()=>({}),moneyMinor:value=>`MYR ${value}`};
  vm.runInNewContext(section('const gameWalletCopy=','async function loadGameWallet('),context);context.renderGameWallet();
  assert.ok(get('gameWalletSession').textContent.includes(expected));assert.equal(get('gameWalletSettle').hidden,true);assert.equal(get('gameWalletRecover').hidden,true);
  state.gameWallet.session.status='withdraw_unknown';context.renderGameWallet();assert.equal(get('gameWalletRecover').hidden,true);
 }
});

test('closing an unconfirmed game window never auto-settles and recovery cannot be called from its panel',async()=>{
 const calls=[],notices=[],state={user:{id:'alice',role:'member',approved:1},selectedCatalogProvider:'megah5_myr',gameWalletMemberId:'alice',gameSettlementBusy:false,gameWindow:{closed:true},gameWindowPoll:1,gameWindowContext:{memberId:'alice',profileId:'megah5_myr',sessionId:'wallet1',settlementBlocked:true},gameWallet:{profileId:'megah5_myr',supportsSettlement:true,supportsRecovery:true,session:{id:'wallet1',status:'active',settlementBlocked:true}}};
 const context={state,clearInterval(){},renderGameWallet(){},notification:x=>notices.push(x),gwt:key=>key,loadGameWallet:async()=>{},loadMemberWallet:async()=>{},loadGameCatalogue:async()=>{},api:async(path,method,data)=>{calls.push({path,method,data});return {status:'settled'};}};
 vm.runInNewContext(section('function stopGameWindowWatch(','function publicGameCard('),context);
 await context.settleClosedGameWindow();await context.settleGameWallet(false);state.gameWallet.session.status='withdraw_unknown';await context.recoverGameWallet();
 assert.equal(calls.length,0);assert.deepEqual(notices,['sessionReview','sessionReview','sessionReview']);
});
