import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

const read=path=>readFile(new URL(path,import.meta.url),'utf8');

test('operations intelligence UI is read-only and calls only its report endpoint',async()=>{
 const source=await read('../public/assets/operations-intelligence.js');
 assert.match(source,/\/api\/admin\/operations-intelligence\?period=/);
 assert.match(source,/所有动作保持人工批准/);
 assert.match(source,/系统没有执行动作/);
 assert.doesNotMatch(source,/method\s*:\s*['"]POST|['"]POST['"]|automaticDepositApproval\s*=\s*true|automaticPayout\s*=\s*true/);
});

test('owner-only operations intelligence panel is statically wired into the backoffice',async()=>{
 const [portal,app,style]=await Promise.all([read('../app/portal.html'),read('../public/assets/app.js'),read('../public/assets/operations-intelligence.css')]);
 assert.equal((portal.match(/\/assets\/operations-intelligence\.css/g)||[]).length,1);
 assert.equal((portal.match(/\/assets\/operations-intelligence\.js/g)||[]).length,1);
 assert.match(portal,/href="#operationsAiPanel" data-owner-only/);
 assert.match(portal,/id="operationsAiPanel"[^>]*hidden[^>]*data-owner-only/);
 for(const id of ['refreshOperationsAi','operationsAiStatus','operationsAiSummary','operationsAiMetrics','operationsAiRecommendations','operationsAiSourcePolicy'])assert.match(portal,new RegExp(`id="${id}"`));
 for(const period of ['day','week','month'])assert.match(portal,new RegExp(`data-ops-period="${period}"`));
 assert.equal((portal.match(/data-ops-period="[^"]+" aria-pressed="(?:true|false)"/g)||[]).length,3);
 assert.match(await read('../public/assets/operations-intelligence.js'),/setAttribute\('aria-pressed',String\(selected\)\)/);
 assert.match(portal,/确定性检查/);assert.match(portal,/所有建议必须人工批准/);
 assert.match(app,/operationsAiPanel:\(\)=>window\.Master7OperationsIntelligence\?\.load\(\)/);
 assert.match(app,/state\.user\?\.role!=="owner"&&\["operationsAiPanel"/);
 assert.match(style,/\.ops-ai-panel/);
});
