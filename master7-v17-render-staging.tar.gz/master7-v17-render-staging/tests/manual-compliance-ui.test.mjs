import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createContext,runInContext} from 'node:vm';

const source=readFileSync(new URL('../public/assets/manual-compliance.js',import.meta.url),'utf8');
function fixture(user,request){
 const elements=new Map();
 function element(id=''){
  return {id,hidden:false,disabled:false,textContent:'',className:'',children:[],listeners:{},
   addEventListener(type,fn){this.listeners[type]=fn;},append(...children){this.children.push(...children);},replaceChildren(...children){this.children=[...children];},querySelector(){return null;}};
 }
 const get=id=>{if(!elements.has(id))elements.set(id,element(id));return elements.get(id);};
 const nav=[element('nav1'),element('nav2')],state={user,lang:'en',section:'lobby'},window={confirm:()=>true};
 const document={getElementById:get,querySelectorAll:selector=>selector==='[data-section="member-verification"]'?nav:[],createElement:()=>element()};
 const api=async(...args)=>request(...args),context=createContext({document,window,state,api});runInContext(source,context);
 return {get,nav,state,window};
}

test('member requests review without sending personal documents and sees the resulting status',async()=>{
 const calls=[],f=fixture({id:'local:alice',role:'member'},async(path,method,data)=>{calls.push({path,method,data});return method==='POST'?{identityStatus:'pending',amlStatus:'pending'}:{identityStatus:'not_started',amlStatus:'not_started'};});
 await f.window.Master7ManualCompliance.load();assert.equal(f.get('manualComplianceRequest').hidden,false);assert.match(f.get('manualComplianceStatus').textContent,/Not requested/);
 await f.get('manualComplianceRequest').listeners.click();assert.equal(f.get('manualComplianceRequest').hidden,true);assert.match(f.get('manualComplianceStatus').textContent,/Awaiting manual review/);
 assert.deepEqual(calls.map(x=>[x.path,x.method]),[['/api/compliance',undefined],['/api/compliance','POST']]);assert.equal(Object.keys(calls[1].data).length,0);
 f.state.lang='ms';f.get('locale').listeners.change();assert.equal(f.get('manualComplianceTitle').textContent,'Pengesahan identiti');
});

test('late member response is discarded after switching accounts',async()=>{
 let release;const delayed=new Promise(resolve=>{release=resolve;});const f=fixture({id:'alice',role:'member'},()=>delayed);
 const pending=f.window.Master7ManualCompliance.load();f.state.user={id:'bob',role:'member'};f.window.Master7ManualCompliance.sessionChanged(f.state.user);
 release({identityStatus:'passed',amlStatus:'failed'});await pending;
 assert.equal(f.get('manualComplianceStatus').textContent,'');assert.equal(f.get('manualComplianceAdminRows').children.length,0);
});

test('owner review requires explicit confirmation and cannot be submitted after switching to staff',async()=>{
 const calls=[],f=fixture({id:'owner',role:'owner'},async(path,method,data)=>{calls.push({path,method,data});return method==='POST'?{reviewComplete:false}:{items:[{user_id:'local:alice',username:'Alice',identity_status:'pending',aml_status:'pending',version:1}]};});
 await f.window.Master7ManualCompliance.loadAdmin();const row=f.get('manualComplianceAdminRows').children[0],pass=row.children[2];
 f.window.confirm=()=>false;await pass.listeners.click();assert.equal(calls.length,1);
 f.window.confirm=()=>true;await pass.listeners.click();assert.equal(calls.filter(x=>x.method==='POST').length,1);assert.equal(calls.find(x=>x.method==='POST').data.confirmed,true);
 const stalePass=f.get('manualComplianceAdminRows').children[0].children[2];f.state.user={id:'staff',role:'staff'};f.window.Master7ManualCompliance.sessionChanged(f.state.user);await stalePass.listeners.click();assert.equal(calls.filter(x=>x.method==='POST').length,1);
 assert.equal(f.get('manualComplianceAdminRows').children.length,0);
});

test('member sees whether the review gate actually applies in each language',async()=>{
 let enabled=true;
 const f=fixture({id:'alice',role:'member'},async()=>({identityStatus:'pending',amlStatus:'pending',enforcementEnabled:enabled}));
 await f.window.Master7ManualCompliance.load();assert.match(f.get('manualComplianceStatus').textContent,/require identity and risk review/);
 f.state.lang='zh';f.get('locale').listeners.change();assert.match(f.get('manualComplianceStatus').textContent,/需要身份和风险审核通过/);
 f.state.lang='ms';f.get('locale').listeners.change();assert.match(f.get('manualComplianceStatus').textContent,/memerlukan semakan identiti dan risiko/);
 enabled=false;await f.window.Master7ManualCompliance.load();assert.match(f.get('manualComplianceStatus').textContent,/belum mengehadkan transaksi baharu/);
});

test('the shared API client translates the review error for game and withdrawal screens',async()=>{
 const app=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
 const start=app.indexOf('function complianceReviewRequiredText()'),end=app.indexOf('function selected(section)',start);assert.ok(start>=0&&end>start);
 for(const [lang,expected] of [['en',/request identity and risk review/],['zh',/申请身份及风险审核/],['ms',/mohon semakan identiti dan risiko/]]){
  const state={lang},context=createContext({state,AbortController,setTimeout,clearTimeout,fetch:async()=>new Response(JSON.stringify({error:'private server explanation',code:'COMPLIANCE_REVIEW_REQUIRED'}),{status:403,headers:{'Content-Type':'application/json'}}),t:key=>key});
  runInContext(app.slice(start,end),context);
  for(const path of ['/api/game-launch','/api/withdrawals'])await assert.rejects(context.api(path,'POST',{}),error=>error.status===403&&error.code==='COMPLIANCE_REVIEW_REQUIRED'&&expected.test(error.message));
 }
});
