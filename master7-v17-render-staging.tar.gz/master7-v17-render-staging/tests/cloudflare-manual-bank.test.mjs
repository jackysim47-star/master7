import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

test('Cloudflare D1 supports registered-member Bank-In and guarded Bank-Out without weakening cash controls', { timeout: 90_000 }, () => {
  const source = fileURLToPath(new URL('../', import.meta.url));
  const child = spawnSync(process.execPath, ['scripts/verify-cloudflare-manual-bank.mjs'], {
    cwd: source,
    env: { ...process.env, MASTER7_VERIFICATION_SOURCE: source },
    encoding: 'utf8',
    timeout: 85_000,
    maxBuffer: 2 * 1024 * 1024,
  });
  assert.ifError(child.error);
  assert.equal(child.status, 0, child.stderr + child.stdout);
  const evidence = JSON.parse(child.stdout);
  assert.equal(evidence.result, 'passed');
  assert.equal(evidence.runtime, 'Cloudflare workerd + disposable D1');
  assert.deepEqual(evidence.syntheticAmountMinor, { bankIn: '5000', bankOut: '2000', endingBalance: '3000' });
  assert.ok(evidence.checks.includes('Owner-only approval, exact fingerprint, review barrier and concurrent single approval'));
  assert.equal(evidence.auditEvents.find(x => x.event === 'withdrawal_approved_v1').n, 1);
  assert.equal(evidence.auditEvents.find(x => x.event === 'manual_bank_payout_paid').n, 1);
  assert.ok(evidence.limitations.includes('not UAT acceptance'));
});
