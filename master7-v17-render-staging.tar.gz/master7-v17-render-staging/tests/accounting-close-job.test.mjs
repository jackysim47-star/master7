import {test} from 'node:test';
import assert from 'node:assert/strict';
import {triggerAccountingClose,startAccountingCloseScheduler} from '../scripts/accounting-close-job.mjs';

test('accounting close scheduler calls only the protected JSON endpoint',async()=>{
 let observed;
 const result=await triggerAccountingClose({endpoint:'http://127.0.0.1:10000/api/internal/accounting-close',token:'x'.repeat(32),fetchImpl:async(url,init)=>{observed={url,init};return Response.json({status:'completed',closed:1});}});
 assert.deepEqual(result,{status:'completed',closed:1});assert.equal(observed.url,'http://127.0.0.1:10000/api/internal/accounting-close');assert.equal(observed.init.method,'POST');assert.equal(observed.init.headers.Authorization,'Bearer '+'x'.repeat(32));assert.equal(observed.init.body,'{}');
 await assert.rejects(()=>triggerAccountingClose({endpoint:'http://127.0.0.1:10000/api/internal/accounting-close',token:'short',fetchImpl:fetch}),/at least 32/);
});

test('in-process scheduler is inert when its secret is absent',()=>{
 const original=console.warn;console.warn=()=>{};try{const scheduler=startAccountingCloseScheduler({token:''});assert.equal(scheduler.enabled,false);scheduler.stop();}finally{console.warn=original;}
});
