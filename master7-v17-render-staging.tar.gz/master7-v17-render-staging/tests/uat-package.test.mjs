import assert from 'node:assert/strict';
import test from 'node:test';
import {createUatPackageTemplate,validateUatPackageManifest} from '../lib/uat-package.ts';

const digest='a'.repeat(64);
const complete=input=>{
 const template=createUatPackageTemplate(input);
 return {
  ...template,
  authorizedUat:true,
  officialContactVerified:true,
  whitelistConfirmed:true,
  testFundsType:'provider_test_credit',
  evidence:Object.fromEntries(template.requiredEvidence.map(key=>[key,{reference:`vendor/${input.providerProfile}/${key}`,sha256:digest}])),
 };
};

test('JILI 1:1 package stays blocked until every official UAT artifact exists',()=>{
 const manifest=complete({kind:'game',providerProfile:'jili_myr_1to1',releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
 delete manifest.evidence.session_closure_finality_contract;
 const result=validateUatPackageManifest(manifest);
 assert.equal(result.schemaValid,true);
 assert.equal(result.readyForRestrictedUat,false);
 assert.deepEqual(result.missingEvidence,['session_closure_finality_contract']);
 assert.equal(result.accepted,false);
 assert.equal(result.live,false);
 assert.equal(result.productionReady,false);
});

test('JILI 1:100 requires independent scale evidence and never inherits 1:1 readiness',()=>{
 const oneToOne=complete({kind:'game',providerProfile:'jili_myr_1to1',releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
 const oneToHundred=complete({kind:'game',providerProfile:'jili_my1_1to100',releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
 delete oneToHundred.evidence.unit_scale_and_rounding_contract;
 assert.equal(validateUatPackageManifest(oneToOne).readyForRestrictedUat,true);
 const result=validateUatPackageManifest(oneToHundred);
 assert.equal(result.readyForRestrictedUat,false);
 assert.ok(result.missingEvidence.includes('unit_scale_and_rounding_contract'));
 assert.equal(result.providerProfile,'jili_my1_1to100');
});

test('registered supplier profile IDs may start with a digit',()=>{
 for(const providerProfile of ['918kiss_normal_myr','918kiss_normal_my1_1to100','918kiss_free_myr']){
  const manifest=complete({kind:'game',providerProfile,releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
  const result=validateUatPackageManifest(manifest);
  assert.equal(result.schemaValid,true,providerProfile);
  assert.equal(result.readyForRestrictedUat,true,providerProfile);
  assert.equal(result.providerProfile,providerProfile);
  assert.equal(result.accepted,false);
  assert.equal(result.live,false);
  assert.equal(result.productionReady,false);
 }
});

test('primary MYR payment package can become UAT-ready without becoming accepted',()=>{
 const manifest=complete({kind:'payment',providerProfile:'gspay_myr',releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
 const result=validateUatPackageManifest(manifest);
 assert.equal(result.schemaValid,true);
 assert.equal(result.readyForRestrictedUat,true);
 assert.equal(result.accepted,false);
 assert.equal(result.live,false);
 assert.equal(result.productionReady,false);
 assert.equal(result.evidenceCount,result.requiredEvidence.length);
});

test('separate USDT profile is not admitted into the three-MYR-gateway UAT scope',()=>{
 const manifest=complete({kind:'payment',providerProfile:'gspay_usdt',releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
 const result=validateUatPackageManifest(manifest);
 assert.equal(result.schemaValid,true);
 assert.equal(result.readyForRestrictedUat,false);
 assert.ok(result.blockers.includes('profile_outside_primary_myr_scope'));
});

test('manifest rejects production, secrets, real funds and malformed evidence',()=>{
 const manifest=complete({kind:'payment',providerProfile:'vpay_myr',releaseVersion:'17.0.0-selfbuilt.174-uat-preview'});
 manifest.environment='production';
 manifest.testFundsType='real_money';
 manifest.apiSecret='must-not-be-here';
 manifest.evidence.order_contract={reference:'bad reference with spaces',sha256:'short'};
 const result=validateUatPackageManifest(manifest);
 assert.equal(result.schemaValid,false);
 assert.equal(result.readyForRestrictedUat,false);
 for(const blocker of ['environment_must_be_uat','test_funds_must_be_provider_credit','unexpected_top_level_field:apiSecret','invalid_evidence:order_contract'])assert.ok(result.blockers.includes(blocker),blocker);
});

test('unknown profiles and the Lebet gateway cannot become executable UAT profiles',()=>{
 const unknown=validateUatPackageManifest({schemaVersion:1,kind:'game',providerProfile:'unknown',environment:'uat',releaseVersion:'17.0.0-selfbuilt.174-uat-preview',authorizedUat:true,officialContactVerified:true,whitelistConfirmed:true,testFundsType:'provider_test_credit',evidence:{}});
 assert.ok(unknown.blockers.includes('unknown_provider_profile'));
 const gateway=validateUatPackageManifest({schemaVersion:1,kind:'game',providerProfile:'lebet',environment:'uat',releaseVersion:'17.0.0-selfbuilt.174-uat-preview',authorizedUat:true,officialContactVerified:true,whitelistConfirmed:true,testFundsType:'provider_test_credit',evidence:{}});
 assert.ok(gateway.blockers.includes('gateway_is_not_a_supplier_profile'));
});
