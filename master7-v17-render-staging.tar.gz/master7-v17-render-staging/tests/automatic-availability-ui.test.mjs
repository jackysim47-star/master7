import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
function extract(from,to){const a=source.indexOf(from),b=source.indexOf(to,a+from.length);assert.ok(a>=0&&b>a);return source.slice(a,b);}
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.textContent='';this.attributes={};this.dataset={};}
 append(...items){this.children.push(...items);}
 replaceChildren(...items){this.children=items;}
 setAttribute(key,value){this.attributes[key]=String(value);}
}
const node=(tag,css='',text='')=>Object.assign(new Element(tag),{className:css,textContent:text});
const descendants=el=>[el,...el.children.flatMap(descendants)];

test('supplier state follows the catalogue response even when old browser controls say closed',()=>{
 const state={lang:'en',supplierControls:{megah5:'closed'},gameCatalogue:{providers:[{id:'megah5',operationalStatus:'closed',connectionVerified:true,catalogueSynced:true,platformLaunchReady:true}]}},context={state};
 vm.runInNewContext(extract('function apiSupplierState(','function applyDefaultSupplierArtwork('),context);
 let info=context.apiSupplierState({id:'megah5'});
 assert.equal(info.connected,true);assert.equal(info.platformLaunchReady,true);
 assert.equal(context.apiSupplierStatusText(info),'Game entry available');
 state.gameCatalogue.providers[0]={id:'megah5',connectionVerified:false,catalogueSynced:false,platformLaunchReady:false};
 info=context.apiSupplierState({id:'megah5'});assert.equal(info.connected,false);assert.equal(info.platformLaunchReady,false);
 assert.equal(context.apiSupplierStatusText(info),'Awaiting API connection');
});

test('customer payment cards follow readiness and preserve their selected provider',()=>{
 const buttons=['vpay','gspay','1mpay','manual-bank'].map(code=>{const el=new Element('button');el.dataset.paymentChannel=code;el.label=new Element('small');el.querySelector=()=>el.label;el.addEventListener=(name,handler)=>{assert.equal(name,'click');el.click=handler;};return el;});
 const state={lang:'en',user:null,paymentChannels:{vpay:'closed',gspay:'suspended','1mpay':'closed','manual-bank':'active'},paymentStatus:{orderReady:true},gspayStatus:{orderReady:true},oneMpayStatus:{orderReady:false}},calls=[];
 const context={state,$:()=>new Element(),document:{querySelectorAll:selector=>selector==='[data-payment-channel]'?buttons:[]}};
 vm.runInNewContext(extract('const paymentPreview =','const walletCopy='),context);
 context.renderPaymentPreview();
 assert.deepEqual(buttons.map(item=>item.label.textContent),['Available','Available','Unavailable','Unavailable']);
 state.gspayStatus=null;context.renderPaymentPreview();assert.equal(buttons[1].label.textContent,'Unavailable');
 context.openDepositCashier=provider=>calls.push(provider);context.bindPaymentPreview();
 for(const button of buttons)button.click();
 assert.deepEqual(calls,['vpay','gspay','1mpay','manual-bank']);
});

test('manual-bank availability follows the current approved member account read and clears on failure or identity change',async()=>{
 const nodes=new Map(),bankButton=new Element('button');bankButton.dataset.paymentChannel='manual-bank';bankButton.label=new Element('small');bankButton.querySelector=()=>bankButton.label;
 const get=id=>{if(!nodes.has(id)){const el=new Element();el.value='';Object.defineProperty(el,'options',{get:()=>el.children});nodes.set(id,el);}return nodes.get(id);};
 const state={lang:'en',user:{id:'member-a',role:'member',approved:1},authMethod:'password',section:'lobby',manualBanks:[],manualBankMemberId:null,memberWalletRequestId:0,paymentChannels:{'manual-bank':'active'},depositProvider:'manual-bank'};
 let bankRead=()=>({items:[{id:'synthetic-bank',bank_name:'Fixture bank'}]});
 const context={state,$:get,node,clear:el=>el.replaceChildren(),document:{querySelectorAll:selector=>selector==='[data-payment-channel]'?[bankButton]:[]},window:{},t:key=>key,wt:key=>key,dt:key=>key,moneyMinor:value=>String(value),renderManualBankCopyDetails(){},clearCompletedDepositAttempts(){},renderPaymentRecords(){},renderTicketUnreadBadges(){},renderGameWallet(){},api:async path=>{
  if(path==='/api/manual-bank/accounts')return bankRead();
  if(path==='/api/wallet')return {availableMinor:'0'};
  if(path==='/api/payment-records')return {items:[]};
  assert.match(path,/^\/api\/payments\/(vpay|gspay|1mpay)\/status$/);return {enabled:false,orderReady:false};
 }};
 vm.runInNewContext(extract('const paymentPreview =','const walletCopy=')+extract('async function loadMemberWallet(','function renderManualBankCopyDetails(')+extract('function renderSession(','function renderAnnouncements('),context);
 context.renderPaymentPreview();assert.equal(bankButton.label.textContent,'Unavailable','a legacy channel flag cannot establish bank availability');
 await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Available');
 bankRead=()=>({items:[]});await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Unavailable');
 bankRead=()=>({items:[{id:'synthetic-bank',bank_name:'Fixture bank'}]});await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Available');
 bankRead=()=>Promise.reject(new Error('synthetic unavailable'));await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Unavailable');assert.equal(state.manualBanks.length,0);assert.equal(state.manualBankMemberId,null);
 let finishOldRead;bankRead=()=>new Promise(resolve=>{finishOldRead=resolve;});const pending=context.loadMemberWallet();
 state.user={id:'member-b',role:'member',approved:1};context.renderSession();assert.equal(bankButton.label.textContent,'Unavailable');
 finishOldRead({items:[{id:'previous-member-bank',bank_name:'Previous fixture'}]});await pending;assert.equal(state.manualBanks.length,0);assert.equal(state.manualBankMemberId,null);
 bankRead=()=>({items:[{id:'current-member-bank',bank_name:'Current fixture'}]});await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Available');assert.equal(state.manualBankMemberId,'member-b');
 state.user=null;context.renderSession();assert.equal(bankButton.label.textContent,'Unavailable');assert.equal(state.manualBanks.length,0);assert.equal(state.manualBankMemberId,null);
});

test('payment backoffice renders read-only connection records and never constructs a mutation',async()=>{
 const host=new Element(),calls=[],context={state:{lang:'en'},$:()=>host,node,clear:el=>el.replaceChildren(),paymentText:key=>({active:'Available',unavailable:'Unavailable'})[key],renderPaymentGatewayChecks:async()=>{},api:async(path,method='GET')=>{calls.push({path,method});return {availabilityMode:'automatic',readOnly:true,items:[{provider_id:'gspay',provider_name:'GSPAY+',enabled:true,status:'closed'},{provider_id:'1mpay',provider_name:'1MPAY',enabled:false,reason:'configuration_incomplete'}]};}};
 vm.runInNewContext(extract('async function renderPaymentChannelManager(','function renderTicketUnreadBadges('),context);
 await context.renderPaymentChannelManager(true);
 assert.deepEqual(calls,[{path:'/api/admin/payment-channels',method:'GET'}]);
 assert.equal(descendants(host).filter(el=>el.tagName==='button').length,0);
 assert.equal(descendants(host).filter(el=>el.attributes.role==='status').map(el=>el.textContent).join('|'),'Available|Unavailable');
 assert.ok(descendants(host).some(el=>el.textContent==='configuration_incomplete'));
});

test('supplier backoffice preserves artwork uploads without availability buttons for owner or staff',()=>{
 const host=new Element(),context={state:{lang:'en',supplierArtwork:{}},$:()=>host,node,clear:el=>el.replaceChildren(),document:{createElement:tag=>new Element(tag)},apiSupplierEntries:[{id:'megah5',name:'MEGA H5'}],apiSupplierState:()=>({connected:true,platformLaunchReady:true}),apiSupplierStatusText:()=> 'Game entry available',supplierArtwork:()=>new Element('img')};
 vm.runInNewContext(extract('function renderApiSupplierAdminButtons(','const paymentPreview ='),context);
 context.renderApiSupplierAdminButtons(true);
 assert.equal(descendants(host).filter(el=>el.tagName==='button').length,0);
 assert.equal(descendants(host).filter(el=>el.tagName==='input').length,1);
 context.renderApiSupplierAdminButtons(false);
 assert.equal(descendants(host).filter(el=>el.tagName==='input'||el.tagName==='button').length,0);
});
