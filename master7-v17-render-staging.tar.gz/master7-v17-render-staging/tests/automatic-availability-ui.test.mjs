import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
function extract(from,to){const a=source.indexOf(from),b=source.indexOf(to,a+from.length);assert.ok(a>=0&&b>a);return source.slice(a,b);}
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.textContent='';this.attributes={};this.dataset={};this.handlers={};this.disabled=false;}
 append(...items){this.children.push(...items);}
 replaceChildren(...items){this.children=items;}
 setAttribute(key,value){this.attributes[key]=String(value);}
 addEventListener(name,handler){this.handlers[name]=handler;}
}
const node=(tag,css='',text='')=>Object.assign(new Element(tag),{className:css,textContent:text});
const descendants=el=>[el,...el.children.flatMap(descendants)];

test('supplier state follows the catalogue response even when old browser controls say closed',()=>{
 const state={lang:'en',supplierControls:{megah5:'closed'},gameCatalogue:{providers:[{id:'megah5',operationalStatus:'closed',connectionVerified:true,catalogueSynced:true,platformLaunchReady:true}]}},context={state};
 vm.runInNewContext(extract('function apiSupplierState(','function applyDefaultSupplierArtwork('),context);
 let info=context.apiSupplierState({id:'megah5'});
 assert.equal(info.connected,true);assert.equal(info.platformLaunchReady,true);
 assert.equal(context.apiSupplierStatusText(info),'Game entry available');
 state.gameCatalogue.providers[0]={id:'megah5',connectionVerified:false,catalogueSynced:false,platformLaunchReady:false};
 info=context.apiSupplierState({id:'megah5'});assert.equal(info.connected,false);assert.equal(info.platformLaunchReady,false);
 assert.equal(context.apiSupplierStatusText(info),'Awaiting API connection');
});

test('profile readiness and brand catalogue connection remain separate for multi-account suppliers',()=>{
 const state={gameCatalogue:{profiles:[{profileId:'jili_myr_1to1',providerId:'jili',launchReady:false},{profileId:'jili_my1_1to100',providerId:'jili',launchReady:true}],providers:[{id:'jili',connectionVerified:true,catalogueSynced:true,platformLaunchReady:true}]}},context={state};
 vm.runInNewContext(extract('function apiSupplierState(','function apiSupplierStatusText('),context);
 const normal=context.apiSupplierState({id:'jili_myr_1to1',providerId:'jili'});assert.equal(normal.connected,true);assert.equal(normal.platformLaunchReady,false);
 const hundred=context.apiSupplierState({id:'jili_my1_1to100',providerId:'jili'});assert.equal(hundred.connected,true);assert.equal(hundred.platformLaunchReady,true);
 state.gameCatalogue.profiles[0].connectionVerified=false;assert.equal(context.apiSupplierState({id:'jili_myr_1to1',providerId:'jili'}).connected,false);
});

test('customer payment cards follow readiness and preserve their selected provider',()=>{
 const buttons=['vpay','gspay','1mpay','manual-bank'].map(code=>{const el=new Element('button');el.dataset.paymentChannel=code;el.label=new Element('small');el.querySelector=()=>el.label;el.addEventListener=(name,handler)=>{assert.equal(name,'click');el.click=handler;};return el;});
 const state={lang:'en',user:null,paymentChannels:{vpay:'closed',gspay:'suspended','1mpay':'closed','manual-bank':'active'},paymentStatus:{orderReady:true},gspayStatus:{orderReady:true},oneMpayStatus:{orderReady:false}},calls=[];
 const context={state,$:()=>new Element(),activeDepositRestriction:()=>null,document:{querySelectorAll:selector=>selector==='[data-payment-channel]'?buttons:[]}};
 vm.runInNewContext(extract('const paymentPreview =','const walletCopy='),context);
 context.renderPaymentPreview();
 assert.deepEqual(buttons.map(item=>item.label.textContent),['Available','Available','Unavailable','Unavailable']);
 state.gspayStatus=null;context.renderPaymentPreview();assert.equal(buttons[1].label.textContent,'Unavailable');
 context.openDepositCashier=provider=>calls.push(provider);context.bindPaymentPreview();
 for(const button of buttons)button.click();
 assert.deepEqual(calls,['vpay','gspay','1mpay','manual-bank']);
});

test('manual-bank availability follows the current approved member account read and clears on failure or identity change',async()=>{
 const nodes=new Map(),bankButton=new Element('button');bankButton.dataset.paymentChannel='manual-bank';bankButton.label=new Element('small');bankButton.querySelector=()=>bankButton.label;
 const get=id=>{if(!nodes.has(id)){const el=new Element();el.value='';Object.defineProperty(el,'options',{get:()=>el.children});nodes.set(id,el);}return nodes.get(id);};
 const state={lang:'en',user:{id:'member-a',role:'member',approved:1},authMethod:'password',section:'lobby',manualBanks:[],manualBankMemberId:null,memberWalletRequestId:0,paymentChannels:{'manual-bank':'active'},depositProvider:'manual-bank'};
 let bankRead=()=>({items:[{id:'synthetic-bank',bank_name:'Fixture bank'}]}),walletRead=()=>({availableMinor:'0'});
 const context={state,$:get,node,clear:el=>el.replaceChildren(),activeDepositRestriction:()=>null,document:{querySelectorAll:selector=>selector==='[data-payment-channel]'?[bankButton]:[]},window:{},t:key=>key,wt:key=>key,dt:key=>key,moneyMinor:value=>String(value),renderManualBankCopyDetails(){},clearCompletedDepositAttempts(){},renderPaymentRecords(){},renderTicketUnreadBadges(){},renderGameWallet(){},api:async path=>{
  if(path==='/api/manual-bank/accounts')return bankRead();
  if(path==='/api/wallet')return walletRead();
  if(path==='/api/payment-records')return {items:[]};
  assert.match(path,/^\/api\/payments\/(vpay|gspay|1mpay)\/status$/);return {enabled:false,orderReady:false};
 }};
 vm.runInNewContext(extract('const paymentPreview =','const walletCopy=')+extract('async function loadMemberWallet(','function renderManualBankCopyDetails(')+extract('function renderSession(','function renderAnnouncements('),context);
 context.renderPaymentPreview();assert.equal(bankButton.label.textContent,'Unavailable','a legacy channel flag cannot establish bank availability');
 await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Available');
 bankRead=()=>({items:[]});await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Unavailable');
 bankRead=()=>({items:[{id:'synthetic-bank',bank_name:'Fixture bank'}]});await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Available');
 bankRead=()=>Promise.reject(new Error('synthetic unavailable'));await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Unavailable');assert.equal(state.manualBanks.length,0);assert.equal(state.manualBankMemberId,null);
 let finishOldRead;bankRead=()=>new Promise(resolve=>{finishOldRead=resolve;});const pending=context.loadMemberWallet();
 state.user={id:'member-b',role:'member',approved:1};context.renderSession();assert.equal(bankButton.label.textContent,'Unavailable');
 finishOldRead({items:[{id:'previous-member-bank',bank_name:'Previous fixture'}]});await pending;assert.equal(state.manualBanks.length,0);assert.equal(state.manualBankMemberId,null);
 bankRead=()=>({items:[{id:'current-member-bank',bank_name:'Current fixture'}]});await context.loadMemberWallet();assert.equal(bankButton.label.textContent,'Available');assert.equal(state.manualBankMemberId,'member-b');
 walletRead=()=>({availableMinor:'0',reconciliationRequired:true});await context.loadMemberWallet();assert.equal(get('walletBalance').textContent,'MYR —');assert.equal(get('walletNotice').textContent,'reconciliation');
 state.user=null;context.renderSession();assert.equal(bankButton.label.textContent,'Unavailable');assert.equal(state.manualBanks.length,0);assert.equal(state.manualBankMemberId,null);
});

test('withdrawal UI displays review and disables submission when the wallet requires reconciliation',async()=>{
 const nodes=new Map(),get=id=>{if(!nodes.has(id)){const el=new Element();el.value='';Object.defineProperty(el,'options',{get:()=>el.children});nodes.set(id,el);}return nodes.get(id);};
 const context={state:{user:{id:'member',role:'member',approved:1}},$:get,node,clear:el=>el.replaceChildren(),withdrawText:key=>key,wt:key=>key,moneyMinor:value=>String(value),renderMemberWithdrawals(){},syncWithdrawalDestinationFields(){get('withdrawSubmit').disabled=get('withdrawSubmit').dataset.walletReview==='true';},api:async path=>path==='/api/withdrawal-banks'?{banks:[],providers:[{id:'vpay',name:'VPay',enabled:true}]}:{items:[],wallet:{availableMinor:'0',reconciliationRequired:true}}};
 vm.runInNewContext(extract('async function loadWithdrawals(){','async function submitWithdrawalForm('),context);
 await context.loadWithdrawals();assert.equal(get('withdrawAvailable').textContent,'MYR —');assert.equal(get('withdrawMessage').textContent,'reconciliation');assert.equal(get('withdrawSubmit').disabled,true);
});

function paymentAdminFixture(role='owner',lang='en'){
 const host=new Element(),calls=[],notices=[],state={lang,user:{id:role+'-id',role}},modes={vpay:'auto',gspay:'paused','1mpay':'auto',manual_bank:'auto'};
 const scenario={failRead:false,failWrite:false,invalidRead:false};
 const context={state,$:()=>host,node,clear:el=>el.replaceChildren(),notification:value=>notices.push(value),paymentText:key=>({active:'Available',unavailable:'Unavailable'})[key],renderPaymentGatewayChecks:async()=>{},api:async(path,method='GET',body)=>{
  calls.push({path,method,body});
  if(path==='/api/admin/payment-channels')return {items:[{provider_id:'gspay',provider_name:'GSPAY+',enabled:true,status:'active'},{provider_id:'1mpay',provider_name:'1MPAY',enabled:false,reason:'configuration_incomplete'}]};
  assert.equal(path,'/api/admin/deposit-controls');
  if(method==='GET'){if(scenario.failRead)throw Error('synthetic unavailable');return {items:scenario.invalidRead?[{providerId:'vpay',mode:'auto'}]:Object.entries(modes).map(([providerId,mode])=>({providerId,mode}))};}
  if(scenario.failWrite)throw Error('synthetic rejected');modes[body.providerId]=body.mode;return {status:'ok'};
 }};
 vm.runInNewContext(extract('async function renderPaymentChannelManager(','function renderTicketUnreadBadges('),context);
 return {host,calls,notices,context,scenario,modes};
}

test('staff see actual connection and new-deposit control status without write buttons',async()=>{
 const f=paymentAdminFixture('staff');await f.context.renderPaymentChannelManager();
 assert.deepEqual(f.calls.map(({path,method})=>({path,method})),[{path:'/api/admin/payment-channels',method:'GET'},{path:'/api/admin/deposit-controls',method:'GET'}]);
 assert.equal(descendants(f.host).filter(el=>el.tagName==='button').length,0);
 assert.equal(descendants(f.host).filter(el=>el.attributes.role==='status').map(el=>el.textContent).join('|'),'Available|Unavailable');
 assert.ok(descendants(f.host).some(el=>el.textContent==='New deposits paused'));
 assert.ok(descendants(f.host).some(el=>el.textContent==='configuration_incomplete'));
});

test('owner pauses and resumes only the selected independent deposit channel',async()=>{
 const f=paymentAdminFixture();await f.context.renderPaymentChannelManager();
 let buttons=descendants(f.host).filter(el=>el.tagName==='button');assert.equal(buttons.length,4);
 let button=buttons.find(el=>el.attributes['aria-label']==='Pause new deposits · VPay MYR');assert.ok(button);await button.handlers.click();
 let writes=f.calls.filter(call=>call.method==='POST');assert.equal(writes.length,1);assert.equal(JSON.stringify(writes[0].body),JSON.stringify({providerId:'vpay',mode:'paused'}));assert.equal(f.modes.vpay,'paused');assert.equal(f.modes.gspay,'paused');assert.equal(f.modes['1mpay'],'auto');assert.equal(f.modes.manual_bank,'auto');
 buttons=descendants(f.host).filter(el=>el.tagName==='button');button=buttons.find(el=>el.attributes['aria-label']==='Resume automatic · VPay MYR');assert.ok(button);await button.handlers.click();
 writes=f.calls.filter(call=>call.method==='POST');assert.equal(writes.length,2);assert.equal(JSON.stringify(writes[1].body),JSON.stringify({providerId:'vpay',mode:'auto'}));assert.equal(f.modes.vpay,'auto');
});

test('controls fail closed on missing data and handle denied updates without changing displayed state',async()=>{
 for(const failure of ['failRead','invalidRead']){const f=paymentAdminFixture();f.scenario[failure]=true;await f.context.renderPaymentChannelManager();assert.equal(descendants(f.host).filter(el=>el.tagName==='button').length,0);assert.ok(descendants(f.host).some(el=>el.textContent.includes('Deposit controls are unavailable')));}
 const f=paymentAdminFixture();f.scenario.failWrite=true;await f.context.renderPaymentChannelManager();const button=descendants(f.host).find(el=>el.attributes['aria-label']==='Pause new deposits · VPay MYR');await button.handlers.click();
 assert.equal(f.modes.vpay,'auto');assert.equal(button.disabled,false);assert.ok(f.notices[0].includes('Could not update'));
});

test('deposit controls explain in-flight and resumption effects in Chinese, English and Malay without presenting USDT as playable',async()=>{
 for(const [lang,heading,note,resume,acceptance] of [['en','New deposit controls','callbacks and recovery may continue','immediately allow new deposits','does not confirm real-payment acceptance'],['zh','新充值控制','回调和补查可能继续处理','新充值可能立即开放','不代表真实付款已验收'],['ms','Kawalan deposit baharu','callback dan pemulihan mungkin diteruskan','segera membuka deposit baharu','tidak membuktikan pembayaran sebenar telah disahkan']]){
  const f=paymentAdminFixture('owner',lang);await f.context.renderPaymentChannelManager();const all=descendants(f.host);assert.ok(all.some(el=>el.textContent===heading));for(const phrase of [note,resume,acceptance])assert.ok(all.some(el=>el.textContent.includes(phrase)),`${lang}: ${phrase}`);assert.equal(all.filter(el=>el.tagName==='button').length,4);assert.ok(!all.some(el=>el.tagName==='button'&&String(el.attributes['aria-label']).includes('USDT')));
 }
});

test('supplier backoffice preserves artwork uploads without availability buttons for owner or staff',()=>{
 const host=new Element(),context={state:{lang:'en',supplierArtwork:{}},$:()=>host,node,clear:el=>el.replaceChildren(),document:{createElement:tag=>new Element(tag)},apiSupplierEntries:[{id:'megah5',name:'MEGA H5'}],apiSupplierState:()=>({connected:true,platformLaunchReady:true}),apiSupplierStatusText:()=> 'Game entry available',supplierArtwork:()=>new Element('img')};
 vm.runInNewContext(extract('function renderApiSupplierAdminButtons(','const paymentPreview ='),context);
 context.renderApiSupplierAdminButtons(true);
 assert.equal(descendants(host).filter(el=>el.tagName==='button').length,0);
 assert.equal(descendants(host).filter(el=>el.tagName==='input').length,1);
 context.renderApiSupplierAdminButtons(false);
 assert.equal(descendants(host).filter(el=>el.tagName==='input'||el.tagName==='button').length,0);
});
