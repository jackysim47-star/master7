import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
function extract(from,to){const a=source.indexOf(from),b=source.indexOf(to,a+from.length);assert.ok(a>=0&&b>a);return source.slice(a,b);}
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.textContent='';this.attributes={};this.dataset={};}
 append(...items){this.children.push(...items);}
 replaceChildren(...items){this.children=items;}
 setAttribute(key,value){this.attributes[key]=String(value);}
}
const node=(tag,css='',text='')=>Object.assign(new Element(tag),{className:css,textContent:text});
const descendants=el=>[el,...el.children.flatMap(descendants)];

test('supplier state follows the catalogue response even when old browser controls say closed',()=>{
 const state={lang:'en',supplierControls:{megah5:'closed'},gameCatalogue:{providers:[{id:'megah5',operationalStatus:'closed',connectionVerified:true,catalogueSynced:true,platformLaunchReady:true}]}},context={state};
 vm.runInNewContext(extract('function apiSupplierState(','function applyDefaultSupplierArtwork('),context);
 let info=context.apiSupplierState({id:'megah5'});
 assert.equal(info.connected,true);assert.equal(info.platformLaunchReady,true);
 assert.equal(context.apiSupplierStatusText(info),'Game entry available');
 state.gameCatalogue.providers[0]={id:'megah5',connectionVerified:false,catalogueSynced:false,platformLaunchReady:false};
 info=context.apiSupplierState({id:'megah5'});assert.equal(info.connected,false);assert.equal(info.platformLaunchReady,false);
 assert.equal(context.apiSupplierStatusText(info),'Awaiting API connection');
});

test('customer payment options follow readiness and route only members to the four deposit forms',()=>{
 const buttons=['vpay','gspay','1mpay','manual-bank'].map(code=>{const el=new Element('button');el.dataset.paymentChannel=code;el.label=new Element('small');el.querySelector=()=>el.label;el.addEventListener=(name,handler)=>{assert.equal(name,'click');el.click=handler;};return el;});
 const state={lang:'en',user:null,paymentChannels:{vpay:'closed',gspay:'suspended','1mpay':'closed','manual-bank':'active'},paymentStatus:{orderReady:true},gspayStatus:{orderReady:true},oneMpayStatus:{orderReady:false}},calls=[];
 const context={state,$:id=>{assert.equal(id,'memberWallet');return {scrollIntoView:()=>calls.push('wallet')};},document:{querySelectorAll:selector=>selector==='[data-payment-channel]'?buttons:[]},showAuth:()=>calls.push('auth'),loadMemberWallet:()=>calls.push('load'),notification:message=>calls.push(message)};
 vm.runInNewContext(extract('const paymentPreview =','const walletCopy='),context);
 context.renderPaymentPreview();
 assert.deepEqual(buttons.map(item=>item.label.textContent),['Available','Available','Unavailable','Available']);
 state.gspayStatus=null;context.renderPaymentPreview();assert.equal(buttons[1].label.textContent,'Unavailable');
 context.bindPaymentPreview();
 for(const button of buttons){
  calls.length=0;state.user=null;button.click();assert.deepEqual(calls,['auth']);
  for(const role of ['owner','staff']){calls.length=0;state.user={role};button.click();assert.deepEqual(calls,['Deposits are available to member accounts.']);}
  calls.length=0;state.user={role:'member'};button.click();assert.deepEqual(calls,['wallet','load']);assert.equal(state.depositProvider,button.dataset.paymentChannel);
 }
});

test('payment backoffice renders read-only connection records and never constructs a mutation',async()=>{
 const host=new Element(),calls=[],context={state:{lang:'en'},$:()=>host,node,clear:el=>el.replaceChildren(),paymentText:key=>({active:'Available',unavailable:'Unavailable'})[key],renderPaymentGatewayChecks:async()=>{},api:async(path,method='GET')=>{calls.push({path,method});return {availabilityMode:'automatic',readOnly:true,items:[{provider_id:'gspay',provider_name:'GSPAY+',enabled:true,status:'closed'},{provider_id:'1mpay',provider_name:'1MPAY',enabled:false,reason:'configuration_incomplete'}]};}};
 vm.runInNewContext(extract('async function renderPaymentChannelManager(','function renderTicketUnreadBadges('),context);
 await context.renderPaymentChannelManager(true);
 assert.deepEqual(calls,[{path:'/api/admin/payment-channels',method:'GET'}]);
 assert.equal(descendants(host).filter(el=>el.tagName==='button').length,0);
 assert.equal(descendants(host).filter(el=>el.attributes.role==='status').map(el=>el.textContent).join('|'),'Available|Unavailable');
 assert.ok(descendants(host).some(el=>el.textContent==='configuration_incomplete'));
});

test('supplier backoffice preserves artwork uploads without availability buttons for owner or staff',()=>{
 const host=new Element(),context={state:{lang:'en',supplierArtwork:{}},$:()=>host,node,clear:el=>el.replaceChildren(),document:{createElement:tag=>new Element(tag)},apiSupplierEntries:[{id:'megah5',name:'MEGA H5'}],apiSupplierState:()=>({connected:true,platformLaunchReady:true}),apiSupplierStatusText:()=> 'Game entry available',supplierArtwork:()=>new Element('img')};
 vm.runInNewContext(extract('function renderApiSupplierAdminButtons(','const paymentPreview ='),context);
 context.renderApiSupplierAdminButtons(true);
 assert.equal(descendants(host).filter(el=>el.tagName==='button').length,0);
 assert.equal(descendants(host).filter(el=>el.tagName==='input').length,1);
 context.renderApiSupplierAdminButtons(false);
 assert.equal(descendants(host).filter(el=>el.tagName==='input'||el.tagName==='button').length,0);
});
