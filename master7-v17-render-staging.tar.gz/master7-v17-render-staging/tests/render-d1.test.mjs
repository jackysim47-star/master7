import test from "node:test";
import assert from "node:assert/strict";
import { postgresSql } from "../lib/render-sql.mjs";

test("converts D1 positional placeholders while preserving SQL literals", () => {
  assert.equal(
    postgresSql("SELECT * FROM users WHERE id=? AND username='what? ever' AND role=?"),
    "SELECT * FROM users WHERE id=$1 AND username='what? ever' AND role=$2",
  );
});

test("converts SQLite INSERT OR IGNORE to PostgreSQL conflict handling", () => {
  assert.equal(
    postgresSql("INSERT OR IGNORE INTO users(id, username) VALUES(?, ?)"),
    "INSERT INTO users(id, username) VALUES($1, $2) ON CONFLICT DO NOTHING",
  );
});

test("keeps existing PostgreSQL upsert statements intact", () => {
  assert.equal(
    postgresSql("INSERT INTO settings(id,value) VALUES('social',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value"),
    "INSERT INTO settings(id,value) VALUES('social',$1) ON CONFLICT(id) DO UPDATE SET value=excluded.value",
  );
});
