import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {getGameCatalogue,cachedGameArtwork,gameSources} from '../lib/game-catalogue.ts';

function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec(readFileSync(new URL('../drizzle/0000_broken_bloodscream.sql',import.meta.url),'utf8'));sql.exec(readFileSync(new URL('../drizzle/0019_game_catalogue_sync.sql',import.meta.url),'utf8'));t.after(()=>sql.close());
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sql.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.text).all(...this.args)};}
  async run(){return sql.prepare(this.text).run(...this.args);}
 }
 const state={time:1000,calls:[],fail:false,empty:false,delay:null,image:'https://backendapi.evo888h5.com/slots/cover-img/cover_fixture.png'};
 const c={db:{prepare:text=>new Statement(text)},gameGatewayUrl:'https://master7-integration-gateway.onrender.com',gameSyncNow:()=>state.time,gameGatewayFetch:async(url,init)=>{
  const u=new URL(url);assert.equal(u.origin,c.gameGatewayUrl);assert.equal(init.method,'GET');assert.equal(init.redirect,'error');assert.equal(Object.hasOwn(init,'body'),false);state.calls.push(u.pathname);
  const provider=u.pathname.split('/')[2];if(state.delay&&provider==='evo888h5')await state.delay;
  if(state.fail)return Response.json({error:'sensitive-upstream-error',upstreamStatus:403},{status:502});
  const rows=state.empty?[]:[{gameCode:'1',name:provider+' title',privateToken:'must-not-leak',playable:true}];
  if(provider==='megah5')return Response.json({result:{Status:200,Game:state.empty?[]:[{GameCode:'1',GameName:'Mega title',Maintenance:'false'}]}});
  if(provider==='evo888h5')return Response.json({result:{code:0,data:state.empty?[]:[{gameid:'1',title:'EVO title',thumbnail:state.image,privateToken:'must-not-leak',weekturnover:90000}]}});
  return Response.json({games:rows});
 }};return {sql,c,state};
}
test('all seven documented gateway catalogues synchronize independently and never become playable by a flag',async t=>{
 const {sql,c,state}=fixture(t),data=await getGameCatalogue(c);
 assert.equal(data.games.length,7);assert.equal(data.providers.length,7);assert.equal(state.calls.length,7);
 assert.ok(data.games.every(g=>g.playable===false));assert.ok(data.providers.every(p=>p.launchVerified===false&&p.walletVerified===false));assert.ok(data.providers.every(p=>p.catalogueSynced&&p.connectionVerified));
 assert.equal(data.games.find(g=>g.provider==='megah5').maintenance,false,'the string false must not become maintenance');
 assert.equal(data.games.find(g=>g.provider==='evo888h5').imageUrl,'/api/game-art?provider=evo888h5&gameCode=1');
 assert.ok(!JSON.stringify(data).includes('must-not-leak'));assert.ok(!JSON.stringify(data).includes('weekturnover'));assert.ok(!JSON.stringify(data).includes('artworkSource'));
 assert.equal(sql.prepare('SELECT COUNT(*) n FROM game_catalogue_cache').get().n,7);
 assert.equal(sql.prepare("SELECT visible FROM providers WHERE id='evo888h5'").get().visible,1);
});
test('a fresh application instance uses persisted snapshots without repeated supplier requests',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.calls=[];
 const restarted={...c,gameGatewayFetch:async()=>{throw Error('A fresh snapshot must not contact a supplier');}};
 assert.equal((await getGameCatalogue(restarted)).games.length,7);assert.equal(state.calls.length,0);
});
test('supplier failures retain last successful games and mark them stale and under maintenance',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.time+=301;state.fail=true;
 const data=await getGameCatalogue(c);assert.equal(data.games.length,7);assert.ok(data.games.every(g=>g.maintenance));
 assert.ok(data.providers.every(p=>p.stale&&!p.connectionVerified&&p.lastSuccessAt===1000&&p.checkedAt===1301&&p.upstreamStatus===403));assert.ok(!JSON.stringify(data).includes('sensitive-upstream-error'));
});
test('only a successful empty catalogue clears the previous snapshot',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.time+=301;state.empty=true;
 const data=await getGameCatalogue(c);assert.equal(data.games.length,0);assert.ok(data.providers.every(p=>p.status==='empty'&&!p.stale));
});
test('database sync leases prevent overlapping refreshes across independent callers',async t=>{
 const {c,state}=fixture(t);let release;state.delay=new Promise(resolve=>release=resolve);
 const first=getGameCatalogue(c);await new Promise(resolve=>setImmediate(resolve));
 await getGameCatalogue({...c},{force:true});assert.equal(state.calls.length,7);
 release();await first;assert.equal(state.calls.filter(x=>x.includes('/evo888h5/')).length,1);
});
test('a foreign gateway URL never receives a request and does not claim a sync lease',async t=>{
 const {sql,c,state}=fixture(t),data=await getGameCatalogue({...c,gameGatewayUrl:'https://attacker.example.test'});
 assert.equal(state.calls.length,0);assert.equal(data.games.length,0);assert.ok(data.providers.every(p=>p.status==='not_configured'));assert.equal(sql.prepare('SELECT COUNT(*) n FROM game_catalogue_cache').get().n,0);
});
test('only the pinned EVO cover host and path may be fetched through the same-origin artwork proxy',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);assert.equal(await cachedGameArtwork(c,'evo888h5','1'),state.image);
 for(const image of ['https://attacker.example.test/slots/cover-img/a.png','http://backendapi.evo888h5.com/slots/cover-img/a.png','https://backendapi.evo888h5.com/private/a.png','https://backendapi.evo888h5.com/slots/cover-img/a.png?token=secret']){
  state.time+=301;state.image=image;const data=await getGameCatalogue(c);assert.equal(await cachedGameArtwork(c,'evo888h5','1'),null);assert.equal(data.games.find(g=>g.provider==='evo888h5').imageUrl,'/assets/providers/evo888h5.webp');
 }
 assert.equal(await cachedGameArtwork(c,'unknown','1'),null);
});
test('malformed or oversized provider data cannot overwrite a known good catalogue',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.time+=301;
 const invalid={...c,gameGatewayFetch:async()=>new Response('x'.repeat(2*1024*1024+1),{headers:{'Content-Type':'application/json'}})};
 const data=await getGameCatalogue(invalid);assert.equal(data.games.length,7);assert.ok(data.providers.every(p=>p.status==='unavailable'&&p.stale));
});
test('EVO publisher metadata cannot merge the same game id with another supplier',async t=>{
 const {c}=fixture(t),data=await getGameCatalogue(c);assert.equal(new Set(data.games.map(g=>g.provider+':'+g.gameCode)).size,7);assert.equal(data.games.filter(g=>g.gameCode==='1').length,7);
});
test('manual refresh is throttled while periodic refresh resumes after the five-minute interval',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);await getGameCatalogue(c,{force:true});assert.equal(state.calls.length,gameSources.length);
 state.time+=6;await getGameCatalogue(c,{force:true});assert.equal(state.calls.length,gameSources.length*2);
 state.time+=301;await getGameCatalogue(c);assert.equal(state.calls.length,gameSources.length*3);
});
