import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {getGameCatalogue,cachedGameArtwork,gameSources} from '../lib/game-catalogue.ts';

function fixture(t){
 const sql=new DatabaseSync(':memory:');sql.exec(readFileSync(new URL('../drizzle/0000_broken_bloodscream.sql',import.meta.url),'utf8'));sql.exec(readFileSync(new URL('../drizzle/0019_game_catalogue_sync.sql',import.meta.url),'utf8'));t.after(()=>sql.close());
 class Statement{
  constructor(text,args=[]){this.text=text;this.args=args;}
  bind(...args){return new Statement(this.text,args);}
  async first(){return sql.prepare(this.text).get(...this.args)??null;}
  async all(){return {results:sql.prepare(this.text).all(...this.args)};}
  async run(){return sql.prepare(this.text).run(...this.args);}
 }
 const state={time:1000,calls:[],fail:false,empty:false,delay:null,image:'https://backendapi.evo888h5.com/slots/cover-img/cover_fixture.png'};
 const c={db:{prepare:text=>new Statement(text)},gameGatewayUrl:'https://master7-integration-gateway.onrender.com',gameSyncNow:()=>state.time,gameGatewayFetch:async(url,init)=>{
  const u=new URL(url);assert.equal(u.origin,c.gameGatewayUrl);assert.equal(init.method,'GET');assert.equal(init.redirect,'error');assert.equal(Object.hasOwn(init,'body'),false);state.calls.push(u.pathname);
  const provider=u.pathname.split('/')[2];if(state.delay&&provider==='evo888h5')await state.delay;
  if(state.fail)return Response.json({error:'sensitive-upstream-error',upstreamStatus:403},{status:502});
  const rows=state.empty?[]:[{gameCode:'1',name:provider+' title',privateToken:'must-not-leak',playable:true}];
  if(provider==='megah5')return Response.json({result:{Status:200,Game:state.empty?[]:[{GameCode:'1',GameName:'Mega title',Maintenance:'false'}]}});
  if(provider==='evo888h5')return Response.json({result:{code:0,data:state.empty?[]:[{gameid:'1',title:'EVO title',thumbnail:state.image,privateToken:'must-not-leak',weekturnover:90000}]}});
  if(provider==='918kissh5')return Response.json({provider,account:u.searchParams.get('account'),currency:u.searchParams.get('account')==='my1'?'MY1':'MYR',games:rows});
  if(provider==='metagaming')return Response.json({provider,account:u.searchParams.get('account'),currency:'MYR',games:rows});
  return Response.json({games:rows});
 }};return {sql,c,state};
}
test('all documented gateway catalogues synchronize independently and never become playable by a flag',async t=>{
 const {sql,c,state}=fixture(t),data=await getGameCatalogue(c);
 assert.equal(data.games.length,gameSources.length);assert.equal(data.providers.length,gameSources.length);assert.equal(state.calls.length,gameSources.length);
 assert.ok(data.games.every(g=>g.playable===false));assert.ok(data.providers.every(p=>p.launchVerified===false&&p.walletVerified===false));assert.ok(data.providers.every(p=>p.catalogueSynced&&p.connectionVerified));
 assert.equal(data.games.find(g=>g.provider==='megah5').maintenance,false,'the string false must not become maintenance');
 assert.equal(data.games.find(g=>g.provider==='evo888h5').imageUrl,'/api/game-art?provider=evo888h5&gameCode=1');
 assert.ok(!JSON.stringify(data).includes('must-not-leak'));assert.ok(!JSON.stringify(data).includes('weekturnover'));assert.ok(!JSON.stringify(data).includes('artworkSource'));
 assert.equal(sql.prepare('SELECT COUNT(*) n FROM game_catalogue_cache').get().n,gameSources.length);
 assert.equal(sql.prepare("SELECT visible FROM providers WHERE id='evo888h5'").get().visible,1);
 for(const included of ['epicwin','venus','clotplay'])assert.equal(sql.prepare('SELECT id FROM providers WHERE id=?').get(included)?.id,included);
 assert.equal(sql.prepare("SELECT id FROM providers WHERE id='godeezone'").get(),undefined);
});
test('a fresh application instance uses persisted snapshots without repeated supplier requests',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.calls=[];
 const restarted={...c,gameGatewayFetch:async()=>{throw Error('A fresh snapshot must not contact a supplier');}};
 assert.equal((await getGameCatalogue(restarted)).games.length,gameSources.length);assert.equal(state.calls.length,0);
});
test('supplier failures retain last successful games and mark them stale and under maintenance',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.time+=301;state.fail=true;
 const data=await getGameCatalogue(c);assert.equal(data.games.length,gameSources.length);assert.ok(data.games.every(g=>g.maintenance));
 assert.ok(data.providers.every(p=>p.stale&&!p.connectionVerified&&p.lastSuccessAt===1000&&p.checkedAt===1301&&p.upstreamStatus===403));assert.ok(!JSON.stringify(data).includes('sensitive-upstream-error'));
});
test('only a successful empty catalogue clears the previous snapshot',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.time+=301;state.empty=true;
 const data=await getGameCatalogue(c);assert.equal(data.games.length,0);assert.ok(data.providers.every(p=>p.status==='empty'&&!p.stale));
});
test('database sync leases prevent overlapping refreshes across independent callers',async t=>{
 const {c,state}=fixture(t);let release;state.delay=new Promise(resolve=>release=resolve);
 const first=getGameCatalogue(c);await new Promise(resolve=>setImmediate(resolve));
 await getGameCatalogue({...c},{force:true});assert.equal(state.calls.length,gameSources.length);
 release();await first;assert.equal(state.calls.filter(x=>x.includes('/evo888h5/')).length,1);
});
test('a foreign gateway URL never receives a request and does not claim a sync lease',async t=>{
 const {sql,c,state}=fixture(t),data=await getGameCatalogue({...c,gameGatewayUrl:'https://attacker.example.test'});
 assert.equal(state.calls.length,0);assert.equal(data.games.length,0);assert.ok(data.providers.every(p=>p.status==='not_configured'));assert.equal(sql.prepare('SELECT COUNT(*) n FROM game_catalogue_cache').get().n,0);
});
test('only the pinned EVO cover host and path may be fetched through the same-origin artwork proxy',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);assert.equal(await cachedGameArtwork(c,'evo888h5','1'),state.image);
 for(const image of ['https://attacker.example.test/slots/cover-img/a.png','http://backendapi.evo888h5.com/slots/cover-img/a.png','https://backendapi.evo888h5.com/private/a.png','https://backendapi.evo888h5.com/slots/cover-img/a.png?token=secret']){
  state.time+=301;state.image=image;const data=await getGameCatalogue(c);assert.equal(await cachedGameArtwork(c,'evo888h5','1'),null);assert.equal(data.games.find(g=>g.provider==='evo888h5').imageUrl,'/assets/providers/evo888h5.webp');
 }
 assert.equal(await cachedGameArtwork(c,'unknown','1'),null);
});
test('malformed or oversized provider data cannot overwrite a known good catalogue',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);state.time+=301;
 const invalid={...c,gameGatewayFetch:async()=>new Response('x'.repeat(2*1024*1024+1),{headers:{'Content-Type':'application/json'}})};
 const data=await getGameCatalogue(invalid);assert.equal(data.games.length,gameSources.length);assert.ok(data.providers.every(p=>p.status==='unavailable'&&p.stale));
});
test('EVO publisher metadata cannot merge the same game id with another supplier',async t=>{
 const {c}=fixture(t),data=await getGameCatalogue(c);assert.equal(new Set(data.games.map(g=>g.provider+':'+g.gameCode)).size,gameSources.length);assert.equal(data.games.filter(g=>g.gameCode==='1').length,gameSources.length);
});
test('manual refresh is throttled while periodic refresh resumes after the five-minute interval',async t=>{
 const {c,state}=fixture(t);await getGameCatalogue(c);await getGameCatalogue(c,{force:true});assert.equal(state.calls.length,gameSources.length);
 state.time+=6;await getGameCatalogue(c,{force:true});assert.equal(state.calls.length,gameSources.length*2);
 state.time+=301;await getGameCatalogue(c);assert.equal(state.calls.length,gameSources.length*3);
});

test('JILI 1:1 and 1:100 profiles use fixed accounts, ratios and independent catalogue snapshots',async t=>{
 const {sql,c}=fixture(t),requests=[];
 const definitions=[
  ['jili_myr_1to1','1to1','1:1'],
  ['jili_my1_1to100','1to100','1:100'],
 ];
 const isolated={...c,gameGatewayFetch:async(url,init)=>{
  const parsed=new URL(url),account=parsed.searchParams.get('account'),entry=definitions.find(([,name])=>name===account);
  assert.equal(parsed.origin,c.gameGatewayUrl);assert.equal(parsed.pathname,'/providers/jili/games');assert.equal(init.method,'GET');assert.ok(entry);
  requests.push(parsed.pathname+parsed.search);const [,name,ratio]=entry;
  return Response.json({provider:'jili',account:name,currency:'MYR',ratio,games:[{gameCode:`${name}-1`,name:`${name} title`,category:'SLOT'}]});
 }};
 for(const [profileId,account] of definitions){
  const data=await getGameCatalogue(isolated,{providerId:'jili',profileId});
  assert.deepEqual(data.providers.map(provider=>({profileId:provider.catalogueProfileId,account:provider.catalogueAccount,currency:provider.providerCurrency,count:provider.count})),[{profileId,account,currency:'MYR',count:1}]);
  assert.deepEqual(data.games.map(game=>({profileId:game.profileId,account:game.catalogueAccount,currency:game.providerCurrency,code:game.gameCode,playable:game.playable})),[{profileId,account,currency:'MYR',code:`${account}-1`,playable:false}]);
 }
 assert.deepEqual(requests,definitions.map(([,account])=>`/providers/jili/games?account=${account}`));
 assert.deepEqual(sql.prepare("SELECT provider_id FROM game_catalogue_cache WHERE provider_id LIKE 'jili_%' ORDER BY provider_id").all().map(row=>row.provider_id),definitions.map(([profileId])=>profileId).sort());
 const noNetwork={...isolated,gameGatewayFetch:async()=>{throw Error('fresh JILI profile snapshots must not contact the gateway');}};
 for(const [profileId,account] of definitions){const data=await getGameCatalogue(noNetwork,{providerId:'jili',profileId});assert.equal(data.games[0].profileId,profileId);assert.equal(data.games[0].gameCode,`${account}-1`);}
});

test('JILI rejects provider, account, currency or ratio mismatches without crossing profile snapshots',async t=>{
 const {sql,c,state}=fixture(t),profileId='jili_my1_1to100',goodGames=[{gameCode:'1to100-1',name:'1:100 title'}];
 let data=await getGameCatalogue({...c,gameGatewayFetch:async()=>Response.json({provider:'jili',account:'1to100',currency:'MYR',ratio:'1:100',games:goodGames})},{providerId:'jili',profileId});
 assert.equal(data.games.length,1);const stored=sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(profileId).games_json;
 for(const mismatch of [
  {provider:'other',account:'1to100',currency:'MYR',ratio:'1:100'},
  {provider:'jili',account:'1to1',currency:'MYR',ratio:'1:100'},
  {provider:'jili',account:'1to100',currency:'MY1',ratio:'1:100'},
  {provider:'jili',account:'1to100',currency:'MYR',ratio:'1:1'},
 ]){
  state.time+=301;
  data=await getGameCatalogue({...c,gameGatewayFetch:async()=>Response.json({...mismatch,games:[{gameCode:'foreign-1',name:'Foreign title'}]})},{providerId:'jili',profileId});
  assert.equal(data.providers[0].status,'blocked');assert.equal(data.providers[0].stale,true);assert.equal(data.games.length,1);assert.equal(data.games[0].gameCode,'1to100-1');assert.equal(data.games[0].profileId,profileId);assert.equal(data.games[0].maintenance,true);assert.ok(!JSON.stringify(data).includes('foreign-1'));
  assert.equal(sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(profileId).games_json,stored);
 }
});

test('918KISS normal, MY1 and free profiles use fixed accounts and independent catalogue snapshots',async t=>{
 const {sql,c}=fixture(t),requests=[];
 const definitions=[
  ['918kiss_normal_myr','normal','MYR',92],
  ['918kiss_normal_my1_1to100','my1','MY1',92],
  ['918kiss_free_myr','free','MYR',88],
 ];
 const isolated={...c,gameGatewayFetch:async(url,init)=>{
  const parsed=new URL(url),account=parsed.searchParams.get('account'),entry=definitions.find(([,name])=>name===account);
  assert.equal(parsed.origin,c.gameGatewayUrl);assert.equal(parsed.pathname,'/providers/918kissh5/games');assert.equal(init.method,'GET');assert.ok(entry);
  requests.push(parsed.pathname+parsed.search);
  const [,name,currency,count]=entry;
  return Response.json({provider:'918kissh5',account:name,currency,games:Array.from({length:count},(_,index)=>({gameCode:`${name}-${index+1}`,name:`${name} title ${index+1}`,category:'SLOT',imageUrl:index===0?'https://gth.kissh5.com/thumbs/profile-cover.png':null}))});
 }};
 for(const [profileId,account,currency,count] of definitions){
  const data=await getGameCatalogue(isolated,{providerId:'918kissh5',profileId});
  assert.equal(data.providers.length,1);assert.equal(data.providers[0].catalogueProfileId,profileId);assert.equal(data.providers[0].catalogueAccount,account);assert.equal(data.providers[0].providerCurrency,currency);assert.equal(data.providers[0].count,count);
  assert.equal(data.games.length,count);assert.ok(data.games.every(game=>game.profileId===profileId&&game.catalogueAccount===account&&game.providerCurrency===currency&&game.playable===false&&game.maintenance===true&&game.providerMaintenance===true));
  assert.ok(data.games.every(game=>game.gameCode.startsWith(account+'-')));assert.equal(data.games[0].imageUrl,`/api/game-art?provider=918kissh5&profileId=${encodeURIComponent(profileId)}&gameCode=${account}-1`);
 }
 assert.deepEqual(requests,definitions.map(([,account])=>`/providers/918kissh5/games?account=${account}`));
 assert.deepEqual(sql.prepare("SELECT provider_id FROM game_catalogue_cache WHERE provider_id LIKE '918kiss_%' ORDER BY provider_id").all().map(row=>row.provider_id),definitions.map(([profileId])=>profileId).sort());
 const noNetwork={...isolated,gameGatewayFetch:async()=>{throw Error('fresh profile snapshots must not contact the gateway');}};
 for(const [profileId,account,,count] of definitions){const data=await getGameCatalogue(noNetwork,{providerId:'918kissh5',profileId});assert.equal(data.games.length,count);assert.ok(data.games.every(game=>game.profileId===profileId&&game.gameCode.startsWith(account+'-')));}
});

test('918KISS profile metadata mismatch cannot overwrite or borrow another profile catalogue',async t=>{
 const {sql,c,state}=fixture(t),freeProfile='918kiss_free_myr';
 const freeGames=Array.from({length:88},(_,index)=>({gameCode:`free-${index+1}`,name:`Free ${index+1}`}));
 const good={...c,gameGatewayFetch:async()=>Response.json({provider:'918kissh5',account:'free',currency:'MYR',games:freeGames})};
 let data=await getGameCatalogue(good,{providerId:'918kissh5',profileId:freeProfile});assert.equal(data.games.length,88);
 const stored=sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(freeProfile).games_json;
 state.time+=301;
 const mismatched={...c,gameGatewayFetch:async()=>Response.json({provider:'918kissh5',account:'normal',currency:'MYR',games:[{gameCode:'normal-only',name:'Normal only'}]})};
 data=await getGameCatalogue(mismatched,{providerId:'918kissh5',profileId:freeProfile});
 assert.equal(data.providers[0].status,'blocked');assert.equal(data.providers[0].stale,true);assert.equal(data.games.length,88);assert.ok(data.games.every(game=>game.profileId===freeProfile&&game.catalogueAccount==='free'&&game.gameCode.startsWith('free-')&&game.maintenance===true));
 assert.equal(sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(freeProfile).games_json,stored);assert.ok(!JSON.stringify(data).includes('normal-only'));
});

test('918KISS rejects a partially malformed profile catalogue and keeps the last complete snapshot',async t=>{
 const {sql,c,state}=fixture(t),profileId='918kiss_normal_myr';
 const goodGames=[{gameCode:'normal-1',name:'Normal one'},{gameCode:'normal-2',name:'Normal two',maintenance:false}];
 let data=await getGameCatalogue({...c,gameGatewayFetch:async()=>Response.json({provider:'918kissh5',account:'normal',currency:'MYR',games:goodGames})},{providerId:'918kissh5',profileId});
 assert.equal(data.providers[0].status,'available');assert.deepEqual(data.games.map(game=>[game.gameCode,game.maintenance]),[['normal-1',true],['normal-2',false]]);
 const stored=sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(profileId).games_json;
 state.time+=301;
 const malformed=[{gameCode:'foreign-1',name:'Foreign one'},{gameCode:'',name:'Missing code'},{gameCode:'foreign-1',name:'Duplicate code'}];
 data=await getGameCatalogue({...c,gameGatewayFetch:async()=>Response.json({provider:'918kissh5',account:'normal',currency:'MYR',games:malformed})},{providerId:'918kissh5',profileId});
 assert.equal(data.providers[0].status,'blocked');assert.equal(data.providers[0].stale,true);assert.deepEqual(data.games.map(game=>game.gameCode),['normal-1','normal-2']);assert.ok(data.games.every(game=>game.maintenance===true));
 assert.equal(sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(profileId).games_json,stored);assert.ok(!JSON.stringify(data).includes('foreign-1'));
});

test('META GAMING normal and free-credit catalogues use fixed paths and isolated cache keys',async t=>{
 const {sql,c}=fixture(t),requests=[];
 const definitions=[
  ['metagaming_normal_myr','normal'],
  ['metagaming_free_myr','free'],
 ];
 const isolated={...c,gameGatewayFetch:async(url,init)=>{
  const parsed=new URL(url),account=parsed.searchParams.get('account');
  assert.equal(parsed.origin,c.gameGatewayUrl);assert.equal(parsed.pathname,'/providers/metagaming/games');assert.equal(init.method,'GET');assert.ok(definitions.some(([,value])=>value===account));
  requests.push(parsed.pathname+parsed.search);
  return Response.json({apiVersion:'3.4.8',provider:'metagaming',account,currency:'MYR',games:[{gameCode:`${account}-1`,name:`${account} title`,gameType:1,imageUrl:'https://unverified.example.test/thumbs/Web/10000.png',hasDemo:true}]});
 }};
 for(const [profileId,account] of definitions){
  const data=await getGameCatalogue(isolated,{providerId:'metagaming',profileId});
  assert.equal(data.providers.length,1);assert.equal(data.providers[0].catalogueProfileId,profileId);assert.equal(data.providers[0].catalogueAccount,account);assert.equal(data.providers[0].providerCurrency,'MYR');assert.equal(data.providers[0].count,1);
  assert.deepEqual(data.games.map(game=>({profileId:game.profileId,account:game.catalogueAccount,currency:game.providerCurrency,code:game.gameCode,category:game.category,playable:game.playable,imageUrl:game.imageUrl})),[{profileId,account,currency:'MYR',code:`${account}-1`,category:'1',playable:false,imageUrl:'/assets/providers/metagaming.webp'}]);
  assert.equal(await cachedGameArtwork(isolated,'metagaming',`${account}-1`,profileId),null,'the official document supplies no concrete thumbnail host');
 }
 assert.deepEqual(requests,definitions.map(([,account])=>`/providers/metagaming/games?account=${account}`));
 assert.deepEqual(sql.prepare("SELECT provider_id FROM game_catalogue_cache WHERE provider_id LIKE 'metagaming_%' ORDER BY provider_id").all().map(row=>row.provider_id),definitions.map(([profileId])=>profileId).sort());
 const noNetwork={...isolated,gameGatewayFetch:async()=>{throw Error('fresh META profile snapshots must not contact the gateway');}};
 for(const [profileId,account] of definitions){const data=await getGameCatalogue(noNetwork,{providerId:'metagaming',profileId});assert.equal(data.games.length,1);assert.equal(data.games[0].gameCode,`${account}-1`);}
});

test('META GAMING rejects provider, account or currency metadata mismatches without crossing profile snapshots',async t=>{
 const {sql,c,state}=fixture(t),profileId='metagaming_free_myr',goodGames=[{gameCode:'free-1',name:'Free title'}];
 let data=await getGameCatalogue({...c,gameGatewayFetch:async()=>Response.json({provider:'metagaming',account:'free',currency:'MYR',games:goodGames})},{providerId:'metagaming',profileId});
 assert.equal(data.games.length,1);const stored=sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(profileId).games_json;
 for(const mismatch of [
  {provider:'megah5',account:'free',currency:'MYR'},
  {provider:'metagaming',account:'normal',currency:'MYR'},
  {provider:'metagaming',account:'free',currency:'MY1'},
 ]){
  state.time+=301;
  data=await getGameCatalogue({...c,gameGatewayFetch:async()=>Response.json({...mismatch,games:[{gameCode:'foreign-1',name:'Foreign title'}]})},{providerId:'metagaming',profileId});
  assert.equal(data.providers[0].status,'blocked');assert.equal(data.providers[0].stale,true);assert.equal(data.games.length,1);assert.equal(data.games[0].gameCode,'free-1');assert.equal(data.games[0].maintenance,true);assert.ok(!JSON.stringify(data).includes('foreign-1'));
  assert.equal(sql.prepare('SELECT games_json FROM game_catalogue_cache WHERE provider_id=?').get(profileId).games_json,stored);
 }
});
