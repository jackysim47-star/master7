import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {
 GAME_PROVIDER_ACCEPTANCE_CAPABILITIES,GameProviderAcceptanceError,getGameProviderAcceptance,
 getGameProviderAcceptanceReadiness,recordGameProviderAcceptance,
} from '../lib/game-provider-acceptance.ts';
import {GAME_PROVIDER_PROFILES} from '../lib/game-provider-registry.ts';

const owner={id:'owner',role:'owner'},staff={id:'staff',role:'staff'},member={id:'member',role:'member'};

function d1(sqlite){
 const statement=(sql,values=[])=>({
  bind(...next){return statement(sql,next);},
  async all(){return {results:sqlite.prepare(sql).all(...values).map(row=>({...row}))};},
  async first(){const row=sqlite.prepare(sql).get(...values);return row?{...row}:null;},
  async run(){const result=sqlite.prepare(sql).run(...values);return {success:true,meta:{changes:Number(result.changes)}};},
 });
 return {prepare:sql=>statement(sql),async batch(items){sqlite.exec('BEGIN');try{for(const item of items)await item.run();sqlite.exec('COMMIT');}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
}

function fixture(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());sqlite.exec('PRAGMA foreign_keys=ON');
 sqlite.exec(readFileSync(new URL('../drizzle/0000_broken_bloodscream.sql',import.meta.url),'utf8'));
 sqlite.exec(readFileSync(new URL('../drizzle/0113_game_provider_acceptance_evidence.sql',import.meta.url),'utf8'));
 sqlite.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner','owner',1,'o',1),('staff','staff','staff',1,'s',1),('member','member','member',1,'m',1)");
 return {sqlite,db:d1(sqlite)};
}

const evidence=(overrides={})=>({profileId:'megah5_myr',capability:'catalogue',environment:'production',result:'passed',
 evidenceSha256:'a'.repeat(64),evidenceReference:'uat-report:case-100',observedAt:100,expectedEventId:null,...overrides});

test('acceptance defaults every registered profile and capability to false',async t=>{
 const f=fixture(t),report=await getGameProviderAcceptance(f.db,staff,{environment:'production'});
 assert.equal(report.profiles.length,GAME_PROVIDER_PROFILES.length);
 assert.equal(report.profiles.filter(item=>item.listedInLobby).length,43);
 assert.deepEqual(report.events,[]);
 for(const profile of report.profiles){
  assert.equal(profile.accepted,false,profile.profileId);
  for(const capability of GAME_PROVIDER_ACCEPTANCE_CAPABILITIES){
   assert.deepEqual(profile.capabilities[capability],{passed:false,result:'not_recorded',eventId:null,revision:0,evidenceSha256:null,evidenceReference:null,verifiedBy:null,observedAt:null,recordedAt:null});
  }
 }
 const readiness=await getGameProviderAcceptanceReadiness(f.db,['megah5_myr']);
 assert.deepEqual({required:readiness.requiredProfileCount,accepted:readiness.acceptedProfileCount,live:readiness.liveProfileCount,verified:readiness.allGamesVerified,liveGames:readiness.liveGames},{required:43,accepted:0,live:0,verified:false,liveGames:false});
 const coba8=readiness.blockers.find(item=>item.profileId==='coba8_myr');
 assert.equal(coba8.contractDiagnostic.manifestComplete,false);
 assert.equal(coba8.contractDiagnostic.adapterImplemented,false);
 assert.equal(coba8.contractDiagnostic.playAllowed,false);
 assert.ok(coba8.contractDiagnostic.missingContractFields.includes('authentication.signature_algorithm'));
 assert.ok(coba8.contractDiagnostic.missingContractFields.includes('launch.endpoint'));
 assert.ok(coba8.contractDiagnostic.missingContractFields.includes('wallet.transfer_query.terminal_statuses'));
});

test('only an owner can append evidence while staff can read the immutable history',async t=>{
 const f=fixture(t);
 await assert.rejects(recordGameProviderAcceptance(f.db,staff,evidence(),101),error=>error instanceof GameProviderAcceptanceError&&error.status===403&&error.code==='OWNER_REQUIRED');
 await assert.rejects(getGameProviderAcceptance(f.db,member),error=>error instanceof GameProviderAcceptanceError&&error.status===403&&error.code==='ACCESS_DENIED');
 const first=await recordGameProviderAcceptance(f.db,owner,evidence(),101);
 const current=await getGameProviderAcceptance(f.db,staff,{environment:'production'}),mega=current.profiles.find(item=>item.profileId==='megah5_myr');
 assert.equal(mega.capabilities.catalogue.passed,true);
 assert.equal(mega.capabilities.catalogue.eventId,first.id);
 assert.equal(current.events.length,1);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='game_provider_acceptance_recorded'").get().n,1);
 assert.throws(()=>f.sqlite.prepare(`INSERT INTO game_provider_acceptance_events
  (id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
  VALUES('concurrent-loser','megah5_myr',1,'catalogue','production','failed',?,'case:concurrent','owner',100,101)`).run('d'.repeat(64)),/UNIQUE/,'same-revision concurrent writers cannot both commit');

 await assert.rejects(recordGameProviderAcceptance(f.db,owner,evidence({result:'failed',expectedEventId:null,evidenceSha256:'b'.repeat(64)}),102),error=>error instanceof GameProviderAcceptanceError&&error.status===409&&error.code==='STALE_ACCEPTANCE');
 assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM game_provider_acceptance_events').get().n,1);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='game_provider_acceptance_recorded'").get().n,1);

 const second=await recordGameProviderAcceptance(f.db,owner,evidence({result:'revoked',expectedEventId:first.id,evidenceSha256:'c'.repeat(64),evidenceReference:'incident:case-101'}),103);
 const after=await getGameProviderAcceptance(f.db,owner,{environment:'production'}),afterMega=after.profiles.find(item=>item.profileId==='megah5_myr');
 assert.equal(afterMega.capabilities.catalogue.result,'revoked');
 assert.equal(afterMega.capabilities.catalogue.passed,false);
 assert.equal(afterMega.capabilities.catalogue.eventId,second.id);
 assert.deepEqual(f.sqlite.prepare('SELECT id,result FROM game_provider_acceptance_events ORDER BY recorded_at,id').all().map(row=>({...row})),[
  {id:first.id,result:'passed'},{id:second.id,result:'revoked'},
 ]);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='game_provider_acceptance_recorded'").get().n,2);
});

test('UAT evidence and owner evidence cannot independently make a game live',async t=>{
 const f=fixture(t);let previous=null,stamp=200;
 for(const capability of GAME_PROVIDER_ACCEPTANCE_CAPABILITIES){
  const result=await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'918kiss_normal_myr',capability,environment:'production',evidenceSha256:String(capability.length).padStart(64,'0'),evidenceReference:`case:jili-${capability}`,observedAt:stamp,expectedEventId:null}),stamp++);
  previous=result.id;
 }
 await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'megah5_myr',environment:'uat',evidenceReference:'case:megah5-uat',observedAt:stamp,expectedEventId:null}),stamp);
 const readiness=await getGameProviderAcceptanceReadiness(f.db,['918kiss_normal_myr']);
 assert.equal(readiness.acceptedProfileCount,1);
 assert.equal(readiness.liveProfileCount,0,'918KISS remains non-live because its adapter is unimplemented');
 assert.equal(readiness.allGamesVerified,false);
 assert.equal(readiness.liveGames,false);
 const kissBlocker=readiness.blockers.find(item=>item.profileId==='918kiss_normal_myr');
 assert.equal(kissBlocker.adapterImplemented,false);
 assert.equal(kissBlocker.contractDiagnostic.manifestComplete,false);
 assert.equal(kissBlocker.contractDiagnostic.playAllowed,false);
 assert.ok(kissBlocker.contractDiagnostic.missingVendorFields.includes('launch.endpoint'));
 assert.ok(kissBlocker.contractDiagnostic.missingVendorFields.includes('wallet.transaction_query.terminal_success_statuses'));
 assert.equal(readiness.profiles.find(item=>item.profileId==='918kiss_normal_myr').contractDiagnostic.playAllowed,false);
 assert.equal((await getGameProviderAcceptance(f.db,staff,{environment:'production'})).profiles.find(item=>item.profileId==='megah5_myr').capabilities.catalogue.passed,false,'UAT does not count as production evidence');
 assert.ok(previous);
});

test('write validation rejects unregistered profiles, ambiguous evidence and extra fields',async t=>{
 const f=fixture(t),cases=[
  [evidence({profileId:'unknown'}),'PROFILE_NOT_REGISTERED'],
  [evidence({evidenceSha256:'A'.repeat(64)}),'INVALID_EVIDENCE_DIGEST'],
  [evidence({evidenceReference:'https://host/report?token=secret'}),'INVALID_EVIDENCE_REFERENCE'],
  [{...evidence(),secret:'must-not-be-stored'},'INVALID_FIELDS'],
  [evidence({expectedEventId:undefined}),'INVALID_EXPECTED_EVENT'],
 ];
 for(const [input,code] of cases)await assert.rejects(recordGameProviderAcceptance(f.db,owner,input,101),error=>error instanceof GameProviderAcceptanceError&&error.code===code,code);
 assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM game_provider_acceptance_events').get().n,0);
});

test('a concurrent same-revision database conflict is returned as stale acceptance',async()=>{
 const bound={bind(){return this;},async first(){return {event_id:'11111111-1111-1111-1111-111111111111'};}};
 const db={prepare(){return bound;},async batch(){throw new Error('UNIQUE constraint failed: game_provider_acceptance_events.profile_id, game_provider_acceptance_events.capability, game_provider_acceptance_events.environment, game_provider_acceptance_events.revision');}};
 await assert.rejects(recordGameProviderAcceptance(db,owner,evidence(),101),error=>error instanceof GameProviderAcceptanceError&&error.status===409&&error.code==='STALE_ACCEPTANCE');
});
