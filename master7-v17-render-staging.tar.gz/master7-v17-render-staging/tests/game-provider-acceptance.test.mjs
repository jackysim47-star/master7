import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {
 GAME_PROVIDER_ACCEPTANCE_CAPABILITIES,GameProviderAcceptanceError,getGameProviderAcceptance,
 getGameProviderAcceptanceReadiness,recordGameProviderAcceptance,
} from '../lib/game-provider-acceptance.ts';
import {GAME_PROVIDER_PROFILES} from '../lib/game-provider-registry.ts';

const owner={id:'owner',role:'owner'},staff={id:'staff',role:'staff'},member={id:'member',role:'member'};

function d1(sqlite){
 const statement=(sql,values=[])=>({
  bind(...next){return statement(sql,next);},
  async all(){return {results:sqlite.prepare(sql).all(...values).map(row=>({...row}))};},
  async first(){const row=sqlite.prepare(sql).get(...values);return row?{...row}:null;},
  async run(){const result=sqlite.prepare(sql).run(...values);return {success:true,meta:{changes:Number(result.changes)}};},
 });
 return {prepare:sql=>statement(sql),async batch(items){sqlite.exec('BEGIN');try{for(const item of items)await item.run();sqlite.exec('COMMIT');}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
}

function fixture(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());sqlite.exec('PRAGMA foreign_keys=ON');
 sqlite.exec(readFileSync(new URL('../drizzle/0000_broken_bloodscream.sql',import.meta.url),'utf8'));
 sqlite.exec(readFileSync(new URL('../drizzle/0113_game_provider_acceptance_evidence.sql',import.meta.url),'utf8'));
 sqlite.exec(readFileSync(new URL('../drizzle/0118_production_acceptance_evidence.sql',import.meta.url),'utf8'));
 sqlite.exec(readFileSync(new URL('../drizzle/0122_acceptance_ledger_integrity.sql',import.meta.url),'utf8'));
 sqlite.exec("INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('owner','owner','owner',1,'o',1),('staff','staff','staff',1,'s',1),('member','member','member',1,'m',1)");
 return {sqlite,db:d1(sqlite)};
}

const evidence=(overrides={})=>({profileId:'megah5_myr',capability:'catalogue',environment:'production',result:'passed',
 evidenceSha256:'a'.repeat(64),evidenceReference:'uat-report:case-100',observedAt:100,expectedEventId:null,...overrides});

test('acceptance defaults every registered profile and capability to false',async t=>{
 const f=fixture(t),report=await getGameProviderAcceptance(f.db,staff,{environment:'production'});
 assert.equal(report.profiles.length,GAME_PROVIDER_PROFILES.length);
 assert.equal(report.profiles.filter(item=>item.listedInLobby).length,43);
 assert.deepEqual(report.events,[]);
 for(const profile of report.profiles){
  assert.equal(profile.accepted,false,profile.profileId);
  for(const capability of GAME_PROVIDER_ACCEPTANCE_CAPABILITIES){
   assert.deepEqual(profile.capabilities[capability],{passed:false,integrityValid:true,result:'not_recorded',eventId:null,currentEventId:null,revision:0,evidenceSha256:null,evidenceReference:null,verifiedBy:null,observedAt:null,recordedAt:null});
  }
 }
 const ownerPgsoft=report.profiles.find(item=>item.profileId==='pgsoft_myr');
 assert.equal(ownerPgsoft.contractStatus,'missing');
 assert.ok(ownerPgsoft.contractDiagnostic.missingContractFields.includes('launch.endpoint'));
 const ownerEpicFree=report.profiles.find(item=>item.profileId==='epicwin_free_myr');
 assert.equal(ownerEpicFree.contractStatus,'incomplete');
 assert.ok(ownerEpicFree.contractDiagnostic.missingVendorFields.includes('profile.free_credit_withdrawal_rule'));
 const readiness=await getGameProviderAcceptanceReadiness(f.db,['megah5_myr']);
 assert.deepEqual({required:readiness.requiredProfileCount,accepted:readiness.acceptedProfileCount,live:readiness.liveProfileCount,verified:readiness.allGamesVerified,liveGames:readiness.liveGames},{required:43,accepted:0,live:0,verified:false,liveGames:false});
 const coba8=readiness.blockers.find(item=>item.profileId==='coba8_myr');
 assert.equal(coba8.contractDiagnostic.manifestComplete,false);
 assert.equal(coba8.contractDiagnostic.adapterImplemented,false);
 assert.equal(coba8.contractDiagnostic.playAllowed,false);
 assert.ok(coba8.contractDiagnostic.missingContractFields.includes('authentication.signature_algorithm'));
 assert.ok(coba8.contractDiagnostic.missingContractFields.includes('launch.endpoint'));
 assert.ok(coba8.contractDiagnostic.missingContractFields.includes('wallet.transfer_query.terminal_statuses'));
 for(const profileId of ['epicwin_normal_myr','epicwin_free_myr']){
  const epic=readiness.blockers.find(item=>item.profileId===profileId);
  assert.equal(epic.contractDiagnostic.knownProfile,true,profileId);
  assert.equal(epic.contractDiagnostic.manifestComplete,false,profileId);
  assert.equal(epic.contractDiagnostic.adapterImplemented,false,profileId);
  assert.equal(epic.contractDiagnostic.playAllowed,false,profileId);
  assert.ok(epic.contractDiagnostic.missingVendorFields.includes('network.waf_requirements'),profileId);
  assert.ok(epic.contractDiagnostic.missingVendorFields.includes('launch.endpoint'),profileId);
  assert.ok(epic.contractDiagnostic.missingVendorFields.includes('wallet.transaction_query.terminal_success_statuses'),profileId);
 }
 assert.equal(readiness.blockers.find(item=>item.profileId==='epicwin_normal_myr').contractDiagnostic.missingVendorFields.includes('profile.free_credit_settlement_rule'),false);
 assert.ok(readiness.blockers.find(item=>item.profileId==='epicwin_free_myr').contractDiagnostic.missingVendorFields.includes('profile.free_credit_settlement_rule'));
 const contractMissing=GAME_PROVIDER_PROFILES.filter(profile=>profile.listedInLobby&&profile.contractStatus==='missing');
 assert.equal(contractMissing.length,32);
 for(const profile of contractMissing){
  const blocker=readiness.blockers.find(item=>item.profileId===profile.profileId);
  assert.ok(blocker.contractDiagnostic,profile.profileId);
  assert.equal(blocker.contractDiagnostic.manifestComplete,false,profile.profileId);
  assert.equal(blocker.contractDiagnostic.adapterImplemented,false,profile.profileId);
  assert.equal(blocker.contractDiagnostic.playAllowed,false,profile.profileId);
 }
 const pgsoft=readiness.blockers.find(item=>item.profileId==='pgsoft_myr');
 assert.ok(pgsoft.contractDiagnostic.missingContractFields.includes('authentication.signature_algorithm'));
 assert.ok(pgsoft.contractDiagnostic.missingContractFields.includes('launch.endpoint'));
 assert.ok(pgsoft.contractDiagnostic.missingContractFields.includes('wallet.transaction_query.terminal_success_statuses'));
});

test('production acceptance requires matching current UAT evidence for the same profile and capability',async t=>{
 const f=fixture(t);
 await assert.rejects(
  recordGameProviderAcceptance(f.db,owner,evidence(),101),
  error=>error instanceof GameProviderAcceptanceError&&error.status===409&&error.code==='UAT_EVIDENCE_REQUIRED',
 );
 assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM game_provider_acceptance_events').get().n,0);
 const uat=await recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat',evidenceReference:'uat-report:case-101'}),101);
 const production=await recordGameProviderAcceptance(f.db,owner,evidence({observedAt:102,evidenceReference:'acceptance:case-102'}),102);
 assert.equal(uat.accepted,true);assert.equal(production.accepted,true);
 assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM game_provider_acceptance_events').get().n,2);
});

test('only an owner can append evidence while staff can read the immutable history',async t=>{
 const f=fixture(t);
 await assert.rejects(recordGameProviderAcceptance(f.db,staff,evidence(),101),error=>error instanceof GameProviderAcceptanceError&&error.status===403&&error.code==='OWNER_REQUIRED');
 await assert.rejects(getGameProviderAcceptance(f.db,member),error=>error instanceof GameProviderAcceptanceError&&error.status===403&&error.code==='ACCESS_DENIED');
 const first=await recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat'}),101);
 const current=await getGameProviderAcceptance(f.db,staff,{environment:'uat'}),mega=current.profiles.find(item=>item.profileId==='megah5_myr');
 assert.equal(mega.capabilities.catalogue.passed,true);
 assert.equal(mega.capabilities.catalogue.eventId,first.id);
 assert.equal(current.events.length,1);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='game_provider_acceptance_recorded'").get().n,1);
 assert.throws(()=>f.sqlite.prepare(`INSERT INTO game_provider_acceptance_events
  (id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
  VALUES('concurrent-loser','megah5_myr',1,'catalogue','uat','failed',?,'case:concurrent','owner',100,101)`).run('d'.repeat(64)),/revisions must be contiguous/,'same-revision concurrent writers cannot both commit');

 await assert.rejects(recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat',result:'failed',expectedEventId:null,evidenceSha256:'b'.repeat(64)}),102),error=>error instanceof GameProviderAcceptanceError&&error.status===409&&error.code==='STALE_ACCEPTANCE');
 assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM game_provider_acceptance_events').get().n,1);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='game_provider_acceptance_recorded'").get().n,1);

 const second=await recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat',result:'revoked',expectedEventId:first.id,evidenceSha256:'c'.repeat(64),evidenceReference:'incident:case-101'}),103);
 const after=await getGameProviderAcceptance(f.db,owner,{environment:'uat'}),afterMega=after.profiles.find(item=>item.profileId==='megah5_myr');
 assert.equal(afterMega.capabilities.catalogue.result,'revoked');
 assert.equal(afterMega.capabilities.catalogue.passed,false);
 assert.equal(afterMega.capabilities.catalogue.eventId,second.id);
 assert.deepEqual(f.sqlite.prepare('SELECT id,result FROM game_provider_acceptance_events ORDER BY recorded_at,id').all().map(row=>({...row})),[
  {id:first.id,result:'passed'},{id:second.id,result:'revoked'},
 ]);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='game_provider_acceptance_recorded'").get().n,2);
});

test('UAT evidence and owner evidence cannot independently make a game live',async t=>{
 const f=fixture(t);let previous=null,stamp=200;
 for(const capability of GAME_PROVIDER_ACCEPTANCE_CAPABILITIES){
  await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'918kiss_normal_myr',capability,environment:'uat',evidenceSha256:String(capability.length+1).padStart(64,'0'),evidenceReference:`case:jili-uat-${capability}`,observedAt:stamp,expectedEventId:null}),stamp++);
  const result=await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'918kiss_normal_myr',capability,environment:'production',evidenceSha256:String(capability.length).padStart(64,'0'),evidenceReference:`case:jili-${capability}`,observedAt:stamp,expectedEventId:null}),stamp++);
  previous=result.id;
 }
 await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'megah5_myr',environment:'uat',evidenceReference:'case:megah5-uat',observedAt:stamp,expectedEventId:null}),stamp);
 const readiness=await getGameProviderAcceptanceReadiness(f.db,['918kiss_normal_myr']);
 assert.equal(readiness.acceptedProfileCount,1);
 assert.equal(readiness.liveProfileCount,0,'918KISS remains non-live because its adapter is unimplemented');
 assert.equal(readiness.allGamesVerified,false);
 assert.equal(readiness.liveGames,false);
 const kissBlocker=readiness.blockers.find(item=>item.profileId==='918kiss_normal_myr');
 assert.equal(kissBlocker.adapterImplemented,false);
 assert.equal(kissBlocker.contractDiagnostic.manifestComplete,false);
 assert.equal(kissBlocker.contractDiagnostic.playAllowed,false);
 assert.ok(kissBlocker.contractDiagnostic.missingVendorFields.includes('launch.endpoint'));
 assert.ok(kissBlocker.contractDiagnostic.missingVendorFields.includes('wallet.transaction_query.terminal_success_statuses'));
 assert.equal(readiness.profiles.find(item=>item.profileId==='918kiss_normal_myr').contractDiagnostic.playAllowed,false);
 assert.equal((await getGameProviderAcceptance(f.db,staff,{environment:'production'})).profiles.find(item=>item.profileId==='megah5_myr').capabilities.catalogue.passed,false,'UAT does not count as production evidence');
 assert.ok(previous);
});

test('profiles and capabilities never inherit acceptance and a UAT revocation demotes production evidence',async t=>{
 const f=fixture(t);let stamp=300,megah5UatLaunch=null;
 for(const capability of GAME_PROVIDER_ACCEPTANCE_CAPABILITIES){
  const uat=await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'megah5_myr',capability,environment:'uat',evidenceReference:`case:megah5-uat-${capability}`,observedAt:stamp}),stamp++);
  if(capability==='launch')megah5UatLaunch=uat;
  await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'megah5_myr',capability,environment:'production',evidenceReference:`case:megah5-production-${capability}`,observedAt:stamp}),stamp++);
 }
 let readiness=await getGameProviderAcceptanceReadiness(f.db,['megah5_myr']);
 assert.equal(readiness.acceptedProfileCount,1);
 assert.equal(readiness.profiles.find(item=>item.profileId==='megah5_myr').evidenceAccepted,true);
 assert.equal(readiness.profiles.find(item=>item.profileId==='jdb_myr').evidenceAccepted,false);

 await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'jdb_myr',capability:'catalogue',environment:'uat',evidenceReference:'case:jdb-uat-catalogue',observedAt:stamp}),stamp++);
 await assert.rejects(
  recordGameProviderAcceptance(f.db,owner,evidence({profileId:'jdb_myr',capability:'launch',environment:'production',evidenceReference:'case:jdb-production-launch',observedAt:stamp}),stamp++),
  error=>error instanceof GameProviderAcceptanceError&&error.code==='UAT_EVIDENCE_REQUIRED',
 );
 assert.equal((await getGameProviderAcceptanceReadiness(f.db,['megah5_myr'])).acceptedProfileCount,1,'JDB catalogue UAT cannot certify JDB launch or MegaH5');

 await recordGameProviderAcceptance(f.db,owner,evidence({profileId:'megah5_myr',capability:'launch',environment:'uat',result:'revoked',expectedEventId:megah5UatLaunch.id,evidenceSha256:'f'.repeat(64),evidenceReference:'incident:megah5-uat-launch',observedAt:stamp}),stamp++);
 readiness=await getGameProviderAcceptanceReadiness(f.db,['megah5_myr']);
 const megah5=readiness.profiles.find(item=>item.profileId==='megah5_myr'),blocker=readiness.blockers.find(item=>item.profileId==='megah5_myr');
 assert.equal(readiness.acceptedProfileCount,0);
 assert.equal(readiness.liveProfileCount,0);
 assert.equal(megah5.uatEvidenceAccepted,false);
 assert.equal(megah5.productionEvidenceAccepted,true,'production history remains visible but cannot override revoked UAT');
 assert.equal(megah5.evidenceAccepted,false);
 assert.deepEqual(blocker.missingUatEvidence,['launch']);
 assert.deepEqual(blocker.missingProductionEvidence,[]);
});

test('a concurrent UAT revocation cannot race a production promotion',async t=>{
 const f=fixture(t);
 const uat=await recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat',evidenceReference:'case:uat-before-race'}),101);
 let raced=false;
 const raceDb={
  prepare:sql=>f.db.prepare(sql),
  async batch(items){
   if(!raced){
    raced=true;
    const revoked='33333333-3333-4333-8333-333333333333';
    f.sqlite.prepare(`INSERT INTO game_provider_acceptance_events
     (id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
     VALUES(?,'megah5_myr',2,'catalogue','uat','revoked',?,'incident:concurrent-uat-revocation','owner',102,102)`).run(revoked,'f'.repeat(64));
    f.sqlite.prepare("UPDATE game_provider_acceptance_current SET event_id=? WHERE profile_id='megah5_myr' AND capability='catalogue' AND environment='uat'").run(revoked);
   }
   return f.db.batch(items);
  },
 };
 await assert.rejects(
  recordGameProviderAcceptance(raceDb,owner,evidence({environment:'production',evidenceReference:'case:production-race'}),103),
  error=>error instanceof GameProviderAcceptanceError&&error.code==='UAT_EVIDENCE_REQUIRED',
 );
 assert.equal(raced,true);assert.ok(uat.id);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM game_provider_acceptance_events WHERE environment='production'").get().n,0);
 assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE target LIKE '%:production:%'").get().n,0);
});

test('write validation rejects unregistered profiles, ambiguous evidence and extra fields',async t=>{
 const f=fixture(t),cases=[
  [evidence({profileId:'unknown'}),'PROFILE_NOT_REGISTERED'],
  [evidence({evidenceSha256:'A'.repeat(64)}),'INVALID_EVIDENCE_DIGEST'],
  [evidence({evidenceReference:'https://host/report?token=secret'}),'INVALID_EVIDENCE_REFERENCE'],
  [{...evidence(),secret:'must-not-be-stored'},'INVALID_FIELDS'],
  [evidence({expectedEventId:undefined}),'INVALID_EXPECTED_EVENT'],
 ];
 for(const [input,code] of cases)await assert.rejects(recordGameProviderAcceptance(f.db,owner,input,101),error=>error instanceof GameProviderAcceptanceError&&error.code===code,code);
 assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM game_provider_acceptance_events').get().n,0);
});

test('a concurrent same-revision database conflict is returned as stale acceptance',async()=>{
 const bound={bind(){return this;},async first(){return {event_id:'11111111-1111-1111-1111-111111111111'};}};
 const db={prepare(){return bound;},async batch(){throw Object.assign(new Error('duplicate key value violates unique constraint game_provider_acceptance_even_profile_id_capability_environ_key'),{code:'23505'});}};
 await assert.rejects(recordGameProviderAcceptance(db,owner,evidence({environment:'uat'}),101),error=>error instanceof GameProviderAcceptanceError&&error.status===409&&error.code==='STALE_ACCEPTANCE');
});

test('latest immutable game evidence is authoritative when the projection is stale',async t=>{
 const f=fixture(t),first=await recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat'}),101),orphan='22222222-2222-4222-8222-222222222222';
 f.sqlite.prepare(`INSERT INTO game_provider_acceptance_events
  (id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
  VALUES(?,'megah5_myr',2,'catalogue','uat','revoked',?,'incident:orphan','owner',102,102)`).run(orphan,'f'.repeat(64));
 const report=await getGameProviderAcceptance(f.db,staff,{environment:'uat'}),state=report.profiles.find(item=>item.profileId==='megah5_myr').capabilities.catalogue;
 assert.deepEqual({eventId:state.eventId,currentEventId:state.currentEventId,result:state.result,passed:state.passed,integrityValid:state.integrityValid},{eventId:orphan,currentEventId:first.id,result:'revoked',passed:false,integrityValid:false});
 const readiness=await getGameProviderAcceptanceReadiness(f.db,['megah5_myr']);
 assert.equal(readiness.integrityReady,false);
 assert.deepEqual(readiness.blockers.find(item=>item.profileId==='megah5_myr').integrityFailures,['catalogue']);
 await assert.rejects(recordGameProviderAcceptance(f.db,owner,evidence({environment:'production',evidenceReference:'case:corrupt-uat-must-not-promote'}),103),error=>error instanceof GameProviderAcceptanceError&&error.code==='ACCEPTANCE_INTEGRITY_ERROR');
 await assert.rejects(recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat',expectedEventId:orphan,evidenceSha256:'e'.repeat(64)}),103),error=>error instanceof GameProviderAcceptanceError&&error.code==='ACCEPTANCE_INTEGRITY_ERROR');
});

test('game acceptance events are immutable and the projection only advances one latest revision',async t=>{
 const f=fixture(t),first=await recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat'}),101);
 assert.throws(()=>f.sqlite.prepare(`INSERT INTO game_provider_acceptance_events
  (id,profile_id,revision,capability,environment,result,evidence_sha256,evidence_reference,verified_by,observed_at,recorded_at)
  VALUES('gap-game','megah5_myr',3,'launch','uat','passed',?,'case:gap','owner',100,101)`).run('9'.repeat(64)),/revisions must be contiguous/);
 assert.throws(()=>f.sqlite.prepare('UPDATE game_provider_acceptance_events SET result=? WHERE id=?').run('revoked',first.id),/history is immutable/);
 assert.throws(()=>f.sqlite.prepare('DELETE FROM game_provider_acceptance_events WHERE id=?').run(first.id),/history is immutable/);
 const second=await recordGameProviderAcceptance(f.db,owner,evidence({environment:'uat',expectedEventId:first.id,result:'revoked',evidenceSha256:'c'.repeat(64)}),102);
 assert.throws(()=>f.sqlite.prepare('UPDATE game_provider_acceptance_current SET event_id=? WHERE profile_id=? AND capability=? AND environment=?').run(first.id,'megah5_myr','catalogue','uat'),/advance exactly one revision/);
 assert.throws(()=>f.sqlite.prepare('DELETE FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=?').run('megah5_myr','catalogue','uat'),/cannot be deleted/);
 assert.equal(f.sqlite.prepare('SELECT event_id FROM game_provider_acceptance_current WHERE profile_id=? AND capability=? AND environment=?').get('megah5_myr','catalogue','uat').event_id,second.id);
});
