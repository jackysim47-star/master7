import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {manualBankPost} from '../lib/manual-bank.ts';
import {withdrawalWalletState} from '../lib/withdrawals.ts';

class Statement{
 constructor(sqlite,sql,args=[]){this.sqlite=sqlite;this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sqlite,this.sql,args);}
 async first(){return this.sqlite.prepare(this.sql).get(...this.args)??null;}
 async run(){return this.sqlite.prepare(this.sql).run(...this.args);}
 async all(){return {results:this.sqlite.prepare(this.sql).all(...this.args)};}
}
function setup(t){
 const sqlite=new DatabaseSync(':memory:');t.after(()=>sqlite.close());
 const dir=new URL('../drizzle/',import.meta.url);
 for(const file of readdirSync(dir).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(readFileSync(new URL(file,dir),'utf8'));
 const db={prepare:sql=>new Statement(sqlite,sql),async batch(items){sqlite.exec('BEGIN IMMEDIATE');try{const out=[];for(const item of items)out.push(await item.run());sqlite.exec('COMMIT');return out;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
 sqlite.exec(`INSERT INTO users(id,username,role,approved,csrf,created_at) VALUES('member','member','member',1,'csrf',0),('other','other','member',1,'csrf',0),('staff','staff','staff',1,'csrf',0);
 INSERT INTO company_bank_accounts(id,bank_name,account_name,account_number,enabled,position,updated_by,updated_at) VALUES('bank','Maybank','Fixture','1234567890',1,0,'staff',0);
 INSERT INTO deposit_orders(id,user_id,request_key,fingerprint,provider,amount_minor,currency,trade_code,status,created_at,updated_at) VALUES('deposit','member','request_manual','bank:2000','manual_bank',2000,'MYR','bank','pending',0,0),('previous','member','request_old','bank:5000','manual_bank',5000,'MYR','bank','credited',0,0);
 INSERT INTO manual_deposit_requests(deposit_order_id,bank_account_id,receipt_data,created_at,updated_at) VALUES('deposit','bank','data:image/png;base64,fixture',0,0);
 INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('old_member','previous','member','member',5000,'MYR',0),('old_clearing','previous','member','provider_clearing',-5000,'MYR',0);`);
 const user={id:'staff',username:'staff',role:'staff',approved:1};
 return {sqlite,db,user};
}
const review=(c,action)=>manualBankPost('/api/admin/manual-bank/review',{id:'deposit',action,bankReference:'BANK-REF-0001',bankAccountId:'bank',bankAmount:'20.00',currency:'MYR',bankConfirmed:true,bankOccurredAt:1700000000,proofData:'data:image/png;base64,'+Buffer.from([137,80,78,71,13,10,26,10,...new Array(20).fill(0)]).toString('base64')},c);

for(const action of ['approve','reject'])test(`manual bank ${action} preserves a historical single-sided ledger for review`,async t=>{
 const {sqlite,db,user}=setup(t);
 sqlite.prepare("INSERT INTO wallet_ledger(id,order_id,user_id,account_code,amount_minor,currency,created_at) VALUES('partial','deposit','member','member',1900,'MYR',0)").run();
 const response=await review({db,user},action);assert.equal(response.status,409);
 assert.equal(sqlite.prepare("SELECT status FROM deposit_orders WHERE id='deposit'").get().status,'review');
 assert.deepEqual(sqlite.prepare("SELECT id,account_code,amount_minor FROM wallet_ledger WHERE order_id='deposit'").all().map(x=>({...x})),[{id:'partial',account_code:'member',amount_minor:1900}]);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='manual_bank_deposit_review' AND target='deposit'").get().n,1);
 const wallet=await withdrawalWalletState(db,'member');assert.equal(wallet.availableMinor,'0');assert.equal(wallet.reconciliationRequired,true);
});

for(const field of ['user_id','amount_minor'])test(`manual bank approval does not write after ${field} changes before the lock`,async t=>{
 const {sqlite,db,user}=setup(t),original=db.batch.bind(db);let injected=false;
 db.batch=async items=>{if(!injected){injected=true;sqlite.prepare(`UPDATE deposit_orders SET ${field}=? WHERE id='deposit'`).run(field==='user_id'?'other':2100);}return original(items);};
 const response=await review({db,user},'approve');assert.equal(response.status,409);
 assert.equal(sqlite.prepare("SELECT status FROM deposit_orders WHERE id='deposit'").get().status,'pending');
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM wallet_ledger WHERE order_id='deposit'").get().n,0);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE target='deposit'").get().n,0);
 assert.equal(sqlite.prepare("SELECT reviewed_by FROM manual_deposit_requests WHERE deposit_order_id='deposit'").get().reviewed_by,null);
});

test('normal manual bank approval posts exactly once and records the reviewer',async t=>{
 const {sqlite,db,user}=setup(t);const first=await review({db,user},'approve');assert.equal(first.status,200);
 assert.equal((await review({db,user},'approve')).status,409);
 assert.deepEqual(sqlite.prepare("SELECT account_code,amount_minor FROM wallet_ledger WHERE order_id='deposit' ORDER BY account_code").all().map(x=>({...x})),[{account_code:'member',amount_minor:2000},{account_code:'provider_clearing',amount_minor:-2000}]);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM audit WHERE event='manual_bank_deposit_approved' AND target='deposit'").get().n,1);
});
