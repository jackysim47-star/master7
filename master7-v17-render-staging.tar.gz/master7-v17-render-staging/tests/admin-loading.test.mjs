import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const source=readFileSync(new URL('../public/assets/app.js',import.meta.url),'utf8');
const start=source.indexOf('const previewDashboardCopy =');
const end=source.indexOf('function showAuth(',start);
assert.ok(start>=0&&end>start,'admin loader source block must exist');
const adminSource=source.slice(start,end);

function fixture(){
 const requests=[],loaderCalls=[];
 const makeClassList=initial=>{const values=new Set(initial||[]);return{contains:value=>values.has(value),toggle(value,on){if(on===undefined?values.has(value):!on)values.delete(value);else values.add(value);}}};
 const content={children:[]};
 const element=(id,classes=[])=>({id,hidden:false,textContent:'',title:'',children:[],parentElement:content,classList:makeClassList(classes),append(...items){this.children.push(...items);},replaceChildren(...items){this.children=[...items];},setAttribute(){},removeAttribute(){}});
 const elements=new Map();
 const get=id=>{if(!elements.has(id))elements.set(id,element(id));return elements.get(id);};
 const heading=element('heading',['admin-dashboard-heading']);
 const panelIds=['adminStats','operationsPanel','paymentChannelManager','adminDepositPanel','manualBankAdminPanel','adminWithdrawalPanel','securityPanel','announcementPanel','providerPanel','apiSupplierManager','gameSyncPanel','gameWalletAdminPanel','lobbyAdManager','marketingCenter','benefitManager','referralAdminPanel','socialPanel','supportOperationsPanel','systemReadinessPanel','pendingPanel','auditPanel'];
 content.children=[heading,...panelIds.map(get)];
 const links=panelIds.map(id=>({href:'#'+id,classList:makeClassList(),getAttribute(name){return name==='href'?this.href:null;},setAttribute(){},removeAttribute(){}}));
 const state={lang:'en',user:{id:'owner',username:'owner',role:'owner'},adminPanel:'operationsPanel',adminLoadedPanels:new Set(),adminPendingPanels:new Map(),adminBaseLoaded:false,adminBasePending:null,adminSummary:null,adminOperations:null,adminSecurity:null,financialEventCursor:null,ticketUnread:0,ticketLatestEvent:null};
 const api=async path=>{requests.push(path);if(path==='/api/admin/summary')return{users:4,pending:1,ticketsOpen:2,ticketsUnread:1,ticketLatestEvent:'123:ticket-event'};if(path==='/health')return{status:'ok',database:'ready',release:'test'};if(path==='/api/admin/operations')return{metrics:{depositMembersToday:0,depositOrdersToday:0,depositMYR:0,withdrawMembersToday:0,withdrawRequestsToday:0,withdrawMYR:0,bonusMYR:null,netRevenueMYR:null,newMembersPreview:0,groupJoins:null}};throw new Error('unexpected API '+path);};
 const loader=name=>(...args)=>{loaderCalls.push([name,...args]);};
 const context={state,$:get,api,clear:host=>{host.children=[];},node:(tag,css,text)=>({tag,css,textContent:text??'',children:[],append(...items){this.children.push(...items);}}),notification:message=>{throw new Error('unexpected notification '+message);},renderTicketUnreadBadges:()=>{get('adminNotificationCount').textContent=String(state.ticketUnread);},document:{body:{classList:makeClassList()},querySelector:selector=>selector==='.admin-content'?content:null,querySelectorAll:selector=>selector==='.admin-internal-sidebar a'?links:[]},location:{pathname:'/admin'},history:{replaceState(){}},renderAnnouncements:loader('announcements'),loadAccounting:loader('accounting'),renderPaymentChannelManager:loader('payment'),renderAdminDeposits:loader('deposits'),renderManualBankAdmin:loader('manual-bank'),renderAdminWithdrawals:loader('withdrawals'),renderProviderManager:loader('providers'),renderApiSupplierAdminButtons:loader('supplier-apis'),renderGameSync:loader('game-sync'),renderAdminGameWallet:loader('game-wallet'),renderAdManager:loader('ads'),loadMarketingCenter:loader('marketing'),renderBenefitManager:loader('benefits'),loadReferralAdmin:loader('referrals'),renderSocialAdmin:loader('social'),loadSupportAutomation:loader('support'),loadSystemReadiness:loader('readiness'),t:value=>value,renderItem:loader('render-item'),console,Date,Set,Map,Object,Promise};
 vm.createContext(context);vm.runInContext(adminSource,context);
 return{context,state,requests,loaderCalls};
}

test('admin entry loads only summary, health and the current operations panel',async()=>{
 const f=fixture();
 await Promise.all([f.context.renderAdmin(),f.context.renderAdmin(),f.context.loadAdminPanel('operationsPanel')]);
 assert.deepEqual(f.requests.sort(),['/api/admin/operations','/api/admin/summary','/health'].sort());
 assert.deepEqual(f.loaderCalls,[]);
 assert.equal(f.state.adminLoadedPanels.has('operationsPanel'),true);
});

test('hidden admin panels load once on first selection and explicit refresh reloads',async()=>{
 const f=fixture();await f.context.renderAdmin();
 f.context.selectAdminPanel('paymentChannelManager');
 await f.state.adminPendingPanels.get('paymentChannelManager');
 assert.equal(f.loaderCalls.filter(([name])=>name==='payment').length,1);
 f.context.selectAdminPanel('paymentChannelManager');await Promise.resolve();
 assert.equal(f.loaderCalls.filter(([name])=>name==='payment').length,1,'cached panel must not reload');
 await Promise.all([f.context.loadAdminPanel('paymentChannelManager',{force:true}),f.context.loadAdminPanel('paymentChannelManager',{force:true})]);
 assert.equal(f.loaderCalls.filter(([name])=>name==='payment').length,2,'explicit concurrent refreshes share one request');
 assert.deepEqual(f.requests.sort(),['/api/admin/operations','/api/admin/summary','/health'].sort(),'opening payment panel does not reload the base dashboard');
});

function notificationFixture(replies){
 const start=source.indexOf('async function pollFinancialNotifications()');
 const end=source.indexOf('async function renderManualBankAdmin()',start);
 assert.ok(start>=0&&end>start);
 const requests=[],alerts=[],state={section:'admin',user:{role:'owner'},financialEventCursor:null};
 const context={state,document:{visibilityState:'visible'},api:async path=>{requests.push(path);return replies.shift();},financialAlert:label=>alerts.push(label),encodeURIComponent,Set,Array};
 vm.createContext(context);vm.runInContext(source.slice(start,end),context);
 return{context,state,requests,alerts};
}

test('financial polling uses the lightweight cursor feed and never rings for initial or repeated events',async()=>{
 const f=notificationFixture([
  {cursor:'cursor-one',events:[],pending:{total:1},latestIds:{deposit:'old'}},
  {cursor:'cursor-two',events:[{cursor:'cursor-two',type:'manual_bank',id:'bank-new'}],pending:{total:2},latestIds:{manualBank:'bank-new'}},
  {cursor:'cursor-two',events:[],pending:{total:2},latestIds:{manualBank:'bank-new'}}
 ]);
 await f.context.pollFinancialNotifications();
 assert.deepEqual(f.alerts,[],'existing records must not ring on first poll');
 await f.context.pollFinancialNotifications();
 assert.deepEqual(f.alerts,['收到新的银行转账申请']);
 await f.context.pollFinancialNotifications();
 assert.deepEqual(f.alerts,['收到新的银行转账申请'],'same cursor must not ring again');
 assert.deepEqual(f.requests,['/api/admin/financial-events','/api/admin/financial-events?after=cursor-one','/api/admin/financial-events?after=cursor-two']);
 assert.ok(f.requests.every(path=>!['/api/admin/deposits','/api/admin/withdrawals','/api/admin/manual-bank'].includes(path)));
});

test('notification bell count matches unread tickets and opens the ticket list',async()=>{
 const f=fixture();await f.context.renderAdmin();
 assert.equal(f.context.$('adminNotificationCount').textContent,'1','open but already read tickets are not mixed into the unread bell');
 const start=source.indexOf('function selected(section)');
 const end=source.indexOf('function renderSession()',start);
 assert.ok(start>=0&&end>start,'notification navigation source must exist');
 const calls=[];
 const state={section:'admin',user:{role:'owner'}};
 const context={state,document:{body:{classList:{toggle(){}},},querySelectorAll:()=>[]},window:{scrollTo(){}},loadWithdrawals(){},refreshTickets(){calls.push('tickets')},renderAdmin(){},Array};
 vm.createContext(context);vm.runInContext(source.slice(start,end),context);
 context.openAdminNotifications();
 assert.equal(state.section,'support');
 assert.deepEqual(calls,['tickets']);
 state.section='admin';state.user={role:'member'};context.openAdminNotifications();
 assert.equal(state.section,'admin','members cannot use the staff notification shortcut');
 assert.deepEqual(calls,['tickets']);
});
