import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const users = sqliteTable('users', {
 id:text('id').primaryKey(), username:text('username').notNull(), role:text('role').notNull().default('member'), approved:integer('approved').notNull().default(0), csrf:text('csrf').notNull(), created_at:integer('created_at').notNull()
});
export const tickets = sqliteTable('tickets', {
 id:text('id').primaryKey(), user_id:text('user_id').notNull().references(()=>users.id), subject:text('subject').notNull(), message:text('message').notNull(), status:text('status').notNull().default('open'), created_at:integer('created_at').notNull()
},t=>[index('ticket_user').on(t.user_id)]);
export const replies = sqliteTable('replies', {
 id:text('id').primaryKey(), ticket_id:text('ticket_id').notNull().references(()=>tickets.id), user_id:text('user_id').notNull().references(()=>users.id), message:text('message').notNull(), created_at:integer('created_at').notNull()
},t=>[index('reply_ticket').on(t.ticket_id)]);
export const announcements = sqliteTable('announcements', {
 id:text('id').primaryKey(), title:text('title').notNull(), body:text('body').notNull(), created_by:text('created_by').notNull().references(()=>users.id), created_at:integer('created_at').notNull()
});
export const providers = sqliteTable('providers', { id:text('id').primaryKey(), name:text('name').notNull(), category:text('category').notNull(), symbol:text('symbol').notNull(), visible:integer('visible').notNull().default(0) });
export const settings = sqliteTable('settings', { id:text('id').primaryKey(), value:text('value').notNull() });
export const audit = sqliteTable('audit', { id:text('id').primaryKey(), user_id:text('user_id').notNull(), event:text('event').notNull(), target:text('target').notNull(), created_at:integer('created_at').notNull() });
export const rateLimits = sqliteTable('rate_limits', { id:text('id').primaryKey(), count:integer('count').notNull(), expires_at:integer('expires_at').notNull() });
export const passwordCredentials = sqliteTable('password_credentials', {
 username:text('username').primaryKey(),user_id:text('user_id').notNull().unique().references(()=>users.id),salt:text('salt').notNull(),password_hash:text('password_hash').notNull(),version:integer('version').notNull().default(1),changed_at:integer('changed_at').notNull()
});
export const passwordSessions = sqliteTable('password_sessions', {
 token_hash:text('token_hash').primaryKey(),user_id:text('user_id').notNull().references(()=>users.id),csrf:text('csrf').notNull(),credential_version:integer('credential_version').notNull(),expires_at:integer('expires_at').notNull(),created_at:integer('created_at').notNull()
},t=>[index('password_session_user').on(t.user_id),index('password_session_expiry').on(t.expires_at)]);
