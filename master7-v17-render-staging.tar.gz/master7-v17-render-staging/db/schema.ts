import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const users = sqliteTable('users', {
 id:text('id').primaryKey(), username:text('username').notNull(), phone:text('phone'), role:text('role').notNull().default('member'), approved:integer('approved').notNull().default(0), csrf:text('csrf').notNull(), created_at:integer('created_at').notNull()
});
export const tickets = sqliteTable('tickets', {
 id:text('id').primaryKey(), user_id:text('user_id').notNull().references(()=>users.id), subject:text('subject').notNull(), message:text('message').notNull(), status:text('status').notNull().default('open'), created_at:integer('created_at').notNull()
},t=>[index('ticket_user').on(t.user_id)]);
export const replies = sqliteTable('replies', {
 id:text('id').primaryKey(), ticket_id:text('ticket_id').notNull().references(()=>tickets.id), user_id:text('user_id').notNull().references(()=>users.id), message:text('message').notNull(), created_at:integer('created_at').notNull()
},t=>[index('reply_ticket').on(t.ticket_id)]);
export const announcements = sqliteTable('announcements', {
 id:text('id').primaryKey(), title:text('title').notNull(), body:text('body').notNull(), created_by:text('created_by').notNull().references(()=>users.id), created_at:integer('created_at').notNull()
});
export const lobbyAds = sqliteTable('lobby_ads', {
 id:text('id').primaryKey(), title:text('title').notNull(), image_data:text('image_data').notNull(), target_url:text('target_url').notNull().default(''), enabled:integer('enabled').notNull().default(1), position:integer('position').notNull().default(0), created_by:text('created_by').notNull().references(()=>users.id), created_at:integer('created_at').notNull(), updated_at:integer('updated_at').notNull()
},t=>[index('lobby_ads_order').on(t.enabled,t.position,t.created_at)]);
export const benefitRules = sqliteTable('benefit_rules', {
 id:text('id').primaryKey(), title:text('title').notNull(), description:text('description').notNull(), rules_json:text('rules_json').notNull(), status:text('status').notNull().default('draft'), created_by:text('created_by').notNull().references(()=>users.id), created_at:integer('created_at').notNull(), updated_at:integer('updated_at').notNull()
},t=>[index('benefit_rules_status').on(t.status,t.updated_at)]);
export const gameVisibility = sqliteTable('game_visibility', {
 provider_id:text('provider_id').notNull(), game_code:text('game_code').notNull(), visible:integer('visible').notNull().default(1), status:text('status').notNull().default('active'), updated_by:text('updated_by').notNull().references(()=>users.id), updated_at:integer('updated_at').notNull()
},t=>[index('game_visibility_key').on(t.provider_id,t.game_code)]);
export const customGameCards = sqliteTable('custom_game_cards', {
 id:text('id').primaryKey(), title:text('title').notNull(), provider_name:text('provider_name').notNull(), game_code:text('game_code').notNull().default(''), category:text('category').notNull().default(''), image_data:text('image_data').notNull(), is_platform_mini:integer('is_platform_mini').notNull().default(0), enabled:integer('enabled').notNull().default(1), status:text('status').notNull().default('active'), position:integer('position').notNull().default(0), created_by:text('created_by').notNull().references(()=>users.id), created_at:integer('created_at').notNull(), updated_at:integer('updated_at').notNull()
},t=>[index('custom_game_cards_order').on(t.enabled,t.is_platform_mini,t.provider_name,t.position)]);
export const paymentChannelControls = sqliteTable('payment_channel_controls', { provider_id:text('provider_id').primaryKey(),provider_name:text('provider_name').notNull(),status:text('status').notNull().default('suspended'),updated_by:text('updated_by').notNull().default('system'),updated_at:integer('updated_at').notNull().default(0) });
export const providers = sqliteTable('providers', { id:text('id').primaryKey(), name:text('name').notNull(), category:text('category').notNull(), symbol:text('symbol').notNull(), visible:integer('visible').notNull().default(0) });
export const settings = sqliteTable('settings', { id:text('id').primaryKey(), value:text('value').notNull() });
export const audit = sqliteTable('audit', { id:text('id').primaryKey(), user_id:text('user_id').notNull(), event:text('event').notNull(), target:text('target').notNull(), created_at:integer('created_at').notNull() });
export const rateLimits = sqliteTable('rate_limits', { id:text('id').primaryKey(), count:integer('count').notNull(), expires_at:integer('expires_at').notNull() });
export const otpChallenges = sqliteTable('otp_challenges', { id:text('id').primaryKey(),phone:text('phone').notNull(),code_hash:text('code_hash').notNull(),attempts:integer('attempts').notNull().default(0),expires_at:integer('expires_at').notNull(),created_at:integer('created_at').notNull(),consumed_at:integer('consumed_at') },t=>[index('otp_challenges_phone_created').on(t.phone,t.created_at)]);
export const passwordCredentials = sqliteTable('password_credentials', {
 username:text('username').primaryKey(),user_id:text('user_id').notNull().unique().references(()=>users.id),salt:text('salt').notNull(),password_hash:text('password_hash').notNull(),version:integer('version').notNull().default(1),changed_at:integer('changed_at').notNull()
});
export const passwordSessions = sqliteTable('password_sessions', {
 token_hash:text('token_hash').primaryKey(),user_id:text('user_id').notNull().references(()=>users.id),csrf:text('csrf').notNull(),credential_version:integer('credential_version').notNull(),expires_at:integer('expires_at').notNull(),created_at:integer('created_at').notNull()
},t=>[index('password_session_user').on(t.user_id),index('password_session_expiry').on(t.expires_at)]);
