CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY NOT NULL,
  username TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'member',
  approved INTEGER NOT NULL DEFAULT 0,
  csrf TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique ON users(phone) WHERE phone IS NOT NULL;
CREATE TABLE IF NOT EXISTS announcements (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL,
  event TEXT NOT NULL,
  target TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS providers (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  symbol TEXT NOT NULL,
  visible INTEGER NOT NULL DEFAULT 0
);
INSERT INTO providers(id,name,category,symbol,visible) VALUES
 ('jili','JILI','supplier','JILI',1),
 ('megah5','MegaH5','supplier','MEGA H5',1),
 ('918kissh5','918KISS','supplier','918KISS',1)
ON CONFLICT(id) DO NOTHING;
CREATE TABLE IF NOT EXISTS rate_limits (
  id TEXT PRIMARY KEY NOT NULL,
  count INTEGER NOT NULL,
  expires_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS tickets (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS replies (
  id TEXT PRIMARY KEY NOT NULL,
  ticket_id TEXT NOT NULL REFERENCES tickets(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  message TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY NOT NULL,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_credentials (
  username TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id),
  salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  changed_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_sessions (
  token_hash TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  csrf TEXT NOT NULL,
  credential_version INTEGER NOT NULL,
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS reply_ticket ON replies(ticket_id);
CREATE INDEX IF NOT EXISTS ticket_user ON tickets(user_id);
CREATE INDEX IF NOT EXISTS password_session_user ON password_sessions(user_id);
CREATE INDEX IF NOT EXISTS password_session_expiry ON password_sessions(expires_at);
CREATE TABLE IF NOT EXISTS lobby_ads (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  image_data TEXT NOT NULL,
  target_url TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS lobby_ads_order ON lobby_ads(enabled, position, created_at);
CREATE TABLE IF NOT EXISTS benefit_rules (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  rules_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS benefit_rules_status ON benefit_rules(status, updated_at);
CREATE TABLE IF NOT EXISTS game_visibility (
  provider_id TEXT NOT NULL,
  game_code TEXT NOT NULL,
  visible INTEGER NOT NULL DEFAULT 1,
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (provider_id, game_code)
);
CREATE INDEX IF NOT EXISTS game_visibility_key ON game_visibility(provider_id, game_code);
CREATE TABLE IF NOT EXISTS custom_game_cards (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  game_code TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  image_data TEXT NOT NULL,
  is_platform_mini INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS custom_game_cards_order ON custom_game_cards(enabled, is_platform_mini, provider_name, position);
