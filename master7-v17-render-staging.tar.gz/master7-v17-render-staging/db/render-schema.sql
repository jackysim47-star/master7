CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY NOT NULL,
  username TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'member',
  approved INTEGER NOT NULL DEFAULT 0,
  csrf TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique ON users(phone) WHERE phone IS NOT NULL;
CREATE TABLE IF NOT EXISTS referral_codes (
  code TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id),
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS referral_relationships (
  member_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id),
  referrer_id TEXT NOT NULL REFERENCES users(id),
  code TEXT NOT NULL REFERENCES referral_codes(code),
  created_at BIGINT NOT NULL,
  CHECK (member_id <> referrer_id)
);
CREATE INDEX IF NOT EXISTS referral_relationships_referrer ON referral_relationships(referrer_id,created_at DESC);
CREATE TABLE IF NOT EXISTS otp_challenges (
  id TEXT PRIMARY KEY NOT NULL,
  phone TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL,
  consumed_at BIGINT
);
CREATE INDEX IF NOT EXISTS otp_challenges_phone_created ON otp_challenges(phone, created_at DESC);
CREATE TABLE IF NOT EXISTS deposit_orders (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  provider TEXT NOT NULL CHECK (provider IN ('vpay','1mpay','gspay','manual_bank')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  trade_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','creating','created','unknown','credited','review','failed')),
  provider_trade_no TEXT,
  checkout_url TEXT,
  expires_at_raw TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key),
  UNIQUE(provider, provider_trade_no)
);
CREATE INDEX IF NOT EXISTS deposit_orders_user_created ON deposit_orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS deposit_orders_status_created ON deposit_orders(status, created_at);
CREATE TABLE IF NOT EXISTS wallet_ledger (
  id TEXT PRIMARY KEY NOT NULL,
  order_id TEXT NOT NULL REFERENCES deposit_orders(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  account_code TEXT NOT NULL CHECK (account_code IN ('member','provider_clearing')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor <> 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  created_at BIGINT NOT NULL,
  UNIQUE(order_id, account_code)
);
CREATE INDEX IF NOT EXISTS wallet_ledger_user_created ON wallet_ledger(user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS company_bank_accounts (
  id TEXT PRIMARY KEY NOT NULL,
  bank_name TEXT NOT NULL,
  account_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS manual_deposit_requests (
  deposit_order_id TEXT PRIMARY KEY NOT NULL REFERENCES deposit_orders(id),
  bank_account_id TEXT NOT NULL REFERENCES company_bank_accounts(id),
  receipt_data TEXT NOT NULL,
  reviewed_by TEXT REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS manual_deposit_pending ON manual_deposit_requests(updated_at DESC);
CREATE TABLE IF NOT EXISTS announcements (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL,
  event TEXT NOT NULL,
  target TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS providers (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  symbol TEXT NOT NULL,
  visible INTEGER NOT NULL DEFAULT 0,
  image_data TEXT NOT NULL DEFAULT ''
);
ALTER TABLE providers ADD COLUMN IF NOT EXISTS image_data TEXT NOT NULL DEFAULT '';
INSERT INTO providers(id,name,category,symbol,visible) VALUES
 ('jili','JILI','supplier','JILI',1),
 ('megah5','MegaH5','supplier','MEGA H5',1),
 ('918kissh5','918KISS','supplier','918KISS',1)
ON CONFLICT(id) DO NOTHING;
CREATE TABLE IF NOT EXISTS rate_limits (
  id TEXT PRIMARY KEY NOT NULL,
  count INTEGER NOT NULL,
  expires_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS tickets (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS replies (
  id TEXT PRIMARY KEY NOT NULL,
  ticket_id TEXT NOT NULL REFERENCES tickets(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  message TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY NOT NULL,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_credentials (
  username TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id),
  salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  changed_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_sessions (
  token_hash TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  csrf TEXT NOT NULL,
  credential_version INTEGER NOT NULL,
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS reply_ticket ON replies(ticket_id);
CREATE INDEX IF NOT EXISTS ticket_user ON tickets(user_id);
CREATE INDEX IF NOT EXISTS password_session_user ON password_sessions(user_id);
CREATE INDEX IF NOT EXISTS password_session_expiry ON password_sessions(expires_at);
CREATE TABLE IF NOT EXISTS lobby_ads (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  image_data TEXT NOT NULL,
  target_url TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS lobby_ads_order ON lobby_ads(enabled, position, created_at);
CREATE TABLE IF NOT EXISTS benefit_rules (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  rules_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS benefit_rules_status ON benefit_rules(status, updated_at);
CREATE TABLE IF NOT EXISTS game_visibility (
  provider_id TEXT NOT NULL,
  game_code TEXT NOT NULL,
  visible INTEGER NOT NULL DEFAULT 0,
  category_override TEXT NOT NULL DEFAULT '',
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (provider_id, game_code)
);
CREATE INDEX IF NOT EXISTS game_visibility_key ON game_visibility(provider_id, game_code);
ALTER TABLE game_visibility ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'closed';
ALTER TABLE game_visibility ALTER COLUMN status SET DEFAULT 'closed';
ALTER TABLE game_visibility ADD COLUMN IF NOT EXISTS image_data TEXT NOT NULL DEFAULT '';
ALTER TABLE game_visibility ADD COLUMN IF NOT EXISTS category_override TEXT NOT NULL DEFAULT '';
CREATE TABLE IF NOT EXISTS custom_game_cards (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  game_code TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  image_data TEXT NOT NULL,
  is_platform_mini INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'closed',
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
ALTER TABLE custom_game_cards ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'closed';
ALTER TABLE custom_game_cards ALTER COLUMN status SET DEFAULT 'closed';
CREATE INDEX IF NOT EXISTS custom_game_cards_order ON custom_game_cards(enabled, is_platform_mini, provider_name, position);
CREATE TABLE IF NOT EXISTS payment_channel_controls (
  provider_id TEXT PRIMARY KEY NOT NULL,
  provider_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('suspended','active','closed')),
  updated_by TEXT NOT NULL DEFAULT 'system',
  updated_at BIGINT NOT NULL DEFAULT 0
);
INSERT INTO payment_channel_controls(provider_id,provider_name,status) VALUES
 ('vpay','VPay','suspended'),('gspay','GSPAY','suspended'),('1mpay','1MPAY','suspended'),('gspay_plus','GSPAY+','suspended')
ON CONFLICT(provider_id) DO NOTHING;
ALTER TABLE payment_channel_controls ALTER COLUMN status SET DEFAULT 'closed';

CREATE TABLE IF NOT EXISTS brand_directory_entries (
  id TEXT PRIMARY KEY NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('SLOT','FAST GAME','LIVE','FISH','SPORT','OTHERS')),
  display_name TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  marked BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('suspended','active','closed')),
  image_data TEXT NOT NULL DEFAULT '',
  updated_by TEXT REFERENCES users(id),
  updated_at BIGINT NOT NULL DEFAULT 0,
  UNIQUE(category, display_name)
);
CREATE INDEX IF NOT EXISTS brand_directory_order ON brand_directory_entries(category, position);
CREATE TABLE IF NOT EXISTS api_supplier_artwork (
  provider_id TEXT PRIMARY KEY NOT NULL,
  image_data TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','closed')),
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS portal_schema_migrations (
  version TEXT PRIMARY KEY NOT NULL,
  applied_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS portal_status_snapshots (
  migration_version TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_key TEXT NOT NULL,
  row_data JSONB NOT NULL,
  captured_at BIGINT NOT NULL,
  PRIMARY KEY(migration_version, entity_type, entity_key)
);
CREATE INDEX IF NOT EXISTS portal_status_snapshot_key ON portal_status_snapshots(migration_version, entity_type, entity_key);
CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  provider_id TEXT NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay','gspay_plus')),
  provider_name TEXT NOT NULL,
  bank_code TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_holder_encrypted TEXT NOT NULL,
  account_number_encrypted TEXT NOT NULL,
  account_last4 TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  status TEXT NOT NULL CHECK (status IN ('pending','approved','processing','paid','rejected','cancelled')),
  owner_note TEXT NOT NULL DEFAULT '',
  updated_by TEXT REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key)
);
CREATE INDEX IF NOT EXISTS withdrawal_requests_user_created ON withdrawal_requests(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS withdrawal_requests_status_created ON withdrawal_requests(status,created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS withdrawal_one_open_per_member ON withdrawal_requests(user_id) WHERE status IN ('pending','approved','processing');

CREATE TABLE IF NOT EXISTS game_catalogue_cache (
 provider_id TEXT PRIMARY KEY NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('available','empty','blocked','unavailable')),
 games_json TEXT NOT NULL DEFAULT '[]',
 checked_at BIGINT NOT NULL DEFAULT 0,
 last_success_at BIGINT NOT NULL DEFAULT 0,
 lease_until BIGINT NOT NULL DEFAULT 0,
 upstream_status INTEGER,
 complete INTEGER NOT NULL DEFAULT 0 CHECK(complete IN (0,1))
);

INSERT INTO providers(id,name,category,symbol,visible) VALUES('evo888h5','EVO888H5','supplier','EVO',1) ON CONFLICT(id) DO NOTHING;
