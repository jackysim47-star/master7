CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY NOT NULL,
  username TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'member',
  approved INTEGER NOT NULL DEFAULT 0,
  csrf TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique ON users(phone) WHERE phone IS NOT NULL;
CREATE TABLE IF NOT EXISTS referral_codes (
  code TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id),
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS referral_relationships (
  member_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id),
  referrer_id TEXT NOT NULL REFERENCES users(id),
  code TEXT NOT NULL REFERENCES referral_codes(code),
  created_at BIGINT NOT NULL,
  CHECK (member_id <> referrer_id)
);
CREATE INDEX IF NOT EXISTS referral_relationships_referrer ON referral_relationships(referrer_id,created_at DESC);
CREATE TABLE IF NOT EXISTS marketing_contacts (
  id TEXT PRIMARY KEY NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL DEFAULT '',
  consent_status TEXT NOT NULL DEFAULT 'unknown' CHECK (consent_status IN ('opted_in','unknown','opted_out')),
  source TEXT NOT NULL DEFAULT 'csv',
  consented_at BIGINT,
  consent_source TEXT NOT NULL DEFAULT '',
  consent_proof TEXT NOT NULL DEFAULT '',
  unsubscribe_token TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
ALTER TABLE marketing_contacts ADD COLUMN IF NOT EXISTS consented_at BIGINT;
ALTER TABLE marketing_contacts ADD COLUMN IF NOT EXISTS consent_source TEXT NOT NULL DEFAULT '';
ALTER TABLE marketing_contacts ADD COLUMN IF NOT EXISTS consent_proof TEXT NOT NULL DEFAULT '';
ALTER TABLE marketing_contacts ADD COLUMN IF NOT EXISTS unsubscribe_token TEXT;
CREATE INDEX IF NOT EXISTS marketing_contacts_consent ON marketing_contacts(consent_status,created_at DESC);
CREATE INDEX IF NOT EXISTS marketing_contacts_export ON marketing_contacts(consent_status,created_at,id);
CREATE UNIQUE INDEX IF NOT EXISTS marketing_contacts_unsubscribe ON marketing_contacts(unsubscribe_token) WHERE unsubscribe_token IS NOT NULL;
CREATE TABLE IF NOT EXISTS marketing_campaigns (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('whatsapp','sms','share')),
  message TEXT NOT NULL,
  image_data TEXT NOT NULL DEFAULT '',
  benefit_text TEXT NOT NULL DEFAULT '',
  referral_code TEXT REFERENCES referral_codes(code),
  retention_goal INTEGER NOT NULL DEFAULT 18000,
  send_rate_per_minute INTEGER NOT NULL DEFAULT 30,
  scheduled_at BIGINT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','ready','blocked','sending','paused','completed')),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS marketing_campaigns_updated ON marketing_campaigns(updated_at DESC);
CREATE TABLE IF NOT EXISTS marketing_deliveries (
  campaign_id TEXT NOT NULL REFERENCES marketing_campaigns(id),
  contact_id TEXT NOT NULL REFERENCES marketing_contacts(id),
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','delivered','failed','opted_out')),
  provider_message_id TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (campaign_id,contact_id)
);
CREATE INDEX IF NOT EXISTS marketing_deliveries_status ON marketing_deliveries(campaign_id,status,updated_at);
CREATE TABLE IF NOT EXISTS otp_challenges (
  id TEXT PRIMARY KEY NOT NULL,
  phone TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL,
  consumed_at BIGINT
);
CREATE INDEX IF NOT EXISTS otp_challenges_phone_created ON otp_challenges(phone, created_at DESC);
CREATE TABLE IF NOT EXISTS deposit_orders (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  provider TEXT NOT NULL CHECK (provider IN ('vpay','1mpay','gspay','manual_bank')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  trade_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','creating','created','unknown','credited','review','failed')),
  provider_trade_no TEXT,
  checkout_url TEXT,
  expires_at_raw TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key),
  UNIQUE(provider, provider_trade_no)
);
CREATE INDEX IF NOT EXISTS deposit_orders_user_created ON deposit_orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS deposit_orders_status_created ON deposit_orders(status, created_at);
CREATE TABLE IF NOT EXISTS wallet_ledger (
  id TEXT PRIMARY KEY NOT NULL,
  order_id TEXT NOT NULL REFERENCES deposit_orders(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  account_code TEXT NOT NULL CHECK (account_code IN ('member','provider_clearing')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor <> 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  created_at BIGINT NOT NULL,
  UNIQUE(order_id, account_code)
);
CREATE INDEX IF NOT EXISTS wallet_ledger_user_created ON wallet_ledger(user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS game_wallet_sessions (
 id TEXT PRIMARY KEY NOT NULL,
 user_id TEXT NOT NULL REFERENCES users(id),
 provider TEXT NOT NULL DEFAULT 'megah5' CHECK (provider='megah5'),
 player_id TEXT NOT NULL,
 game_code TEXT NOT NULL,
 status TEXT NOT NULL CHECK (status IN ('deposit_pending','deposit_unknown','deposit_failed','active','withdraw_pending','withdraw_unknown','settled','manual_review')),
 amount_out_minor BIGINT NOT NULL CHECK (amount_out_minor>0),
 amount_returned_minor BIGINT,
 expected_return_minor BIGINT,
 deposit_reference TEXT NOT NULL UNIQUE,
 withdraw_reference TEXT UNIQUE,
 provider_residual TEXT NOT NULL DEFAULT '',
 last_error TEXT NOT NULL DEFAULT '',
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL,
 settled_at BIGINT
);
CREATE UNIQUE INDEX IF NOT EXISTS game_wallet_one_open_session ON game_wallet_sessions(user_id,provider)
 WHERE status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review');
CREATE INDEX IF NOT EXISTS game_wallet_sessions_updated ON game_wallet_sessions(updated_at DESC,id DESC);
CREATE TABLE IF NOT EXISTS game_wallet_ledger (
 id TEXT PRIMARY KEY NOT NULL,
 session_id TEXT NOT NULL UNIQUE REFERENCES game_wallet_sessions(id),
 user_id TEXT NOT NULL REFERENCES users(id),
 account_code TEXT NOT NULL DEFAULT 'game_result' CHECK (account_code='game_result'),
 amount_minor BIGINT NOT NULL,
 currency TEXT NOT NULL DEFAULT 'MYR' CHECK (currency='MYR'),
 created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS game_wallet_ledger_user_created ON game_wallet_ledger(user_id,created_at DESC);
CREATE TABLE IF NOT EXISTS wallet_reservations (
 user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id),
 kind TEXT NOT NULL CHECK (kind IN ('withdrawal','game')),
 reference_id TEXT NOT NULL UNIQUE,
 amount_minor BIGINT NOT NULL CHECK (amount_minor>0),
 created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS wallet_reservations_created ON wallet_reservations(created_at,user_id);
CREATE TABLE IF NOT EXISTS company_bank_accounts (
  id TEXT PRIMARY KEY NOT NULL,
  bank_name TEXT NOT NULL,
  account_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  image_data TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS manual_deposit_requests (
  deposit_order_id TEXT PRIMARY KEY NOT NULL REFERENCES deposit_orders(id),
  bank_account_id TEXT NOT NULL REFERENCES company_bank_accounts(id),
  receipt_data TEXT NOT NULL,
  reviewed_by TEXT REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS manual_deposit_pending ON manual_deposit_requests(updated_at DESC);
CREATE TABLE IF NOT EXISTS announcements (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL,
  event TEXT NOT NULL,
  target TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS providers (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  symbol TEXT NOT NULL,
  visible INTEGER NOT NULL DEFAULT 0,
  image_data TEXT NOT NULL DEFAULT ''
);
ALTER TABLE providers ADD COLUMN IF NOT EXISTS image_data TEXT NOT NULL DEFAULT '';
INSERT INTO providers(id,name,category,symbol,visible) VALUES
 ('jili','JILI','supplier','JILI',1),
 ('megah5','MegaH5','supplier','MEGA H5',1),
 ('918kissh5','918KISS','supplier','918KISS',1)
ON CONFLICT(id) DO NOTHING;
CREATE TABLE IF NOT EXISTS rate_limits (
  id TEXT PRIMARY KEY NOT NULL,
  count INTEGER NOT NULL,
  expires_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS tickets (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS replies (
  id TEXT PRIMARY KEY NOT NULL,
  ticket_id TEXT NOT NULL REFERENCES tickets(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  message TEXT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS ticket_reads (
  ticket_id TEXT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  last_event_at BIGINT NOT NULL,
  last_event_id TEXT NOT NULL,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (ticket_id,user_id)
);
CREATE INDEX IF NOT EXISTS ticket_reads_user ON ticket_reads(user_id,updated_at DESC);
CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY NOT NULL,
  value TEXT NOT NULL
);
INSERT INTO settings(id,value)
SELECT 'marketing_contact_count',CAST(COUNT(*) AS TEXT)
FROM marketing_contacts
WHERE 1=1
ON CONFLICT(id) DO NOTHING;
INSERT INTO settings(id,value) VALUES('marketing_import_lock','0') ON CONFLICT(id) DO NOTHING;
CREATE TABLE IF NOT EXISTS password_credentials (
  username TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id),
  salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  changed_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_sessions (
  token_hash TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  csrf TEXT NOT NULL,
  credential_version INTEGER NOT NULL,
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS reply_ticket ON replies(ticket_id);
CREATE INDEX IF NOT EXISTS ticket_user ON tickets(user_id);
CREATE INDEX IF NOT EXISTS password_session_user ON password_sessions(user_id);
CREATE INDEX IF NOT EXISTS password_session_expiry ON password_sessions(expires_at);
CREATE TABLE IF NOT EXISTS lobby_ads (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  image_data TEXT NOT NULL,
  target_url TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS lobby_ads_order ON lobby_ads(enabled, position, created_at);
CREATE TABLE IF NOT EXISTS benefit_rules (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  rules_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS benefit_rules_status ON benefit_rules(status, updated_at);
CREATE TABLE IF NOT EXISTS game_visibility (
  provider_id TEXT NOT NULL,
  game_code TEXT NOT NULL,
  visible INTEGER NOT NULL DEFAULT 0,
  category_override TEXT NOT NULL DEFAULT '',
  access_zone TEXT NOT NULL DEFAULT 'paid' CHECK (access_zone IN ('free','paid')),
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (provider_id, game_code)
);
CREATE INDEX IF NOT EXISTS game_visibility_key ON game_visibility(provider_id, game_code);
ALTER TABLE game_visibility ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'closed';
ALTER TABLE game_visibility ALTER COLUMN status SET DEFAULT 'closed';
ALTER TABLE game_visibility ADD COLUMN IF NOT EXISTS image_data TEXT NOT NULL DEFAULT '';
ALTER TABLE game_visibility ADD COLUMN IF NOT EXISTS category_override TEXT NOT NULL DEFAULT '';
ALTER TABLE game_visibility ADD COLUMN IF NOT EXISTS access_zone TEXT NOT NULL DEFAULT 'paid';
CREATE TABLE IF NOT EXISTS custom_game_cards (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  game_code TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  image_data TEXT NOT NULL,
  is_platform_mini INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'closed',
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
ALTER TABLE custom_game_cards ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'closed';
ALTER TABLE custom_game_cards ALTER COLUMN status SET DEFAULT 'closed';
CREATE INDEX IF NOT EXISTS custom_game_cards_order ON custom_game_cards(enabled, is_platform_mini, provider_name, position);
CREATE TABLE IF NOT EXISTS payment_channel_controls (
  provider_id TEXT PRIMARY KEY NOT NULL,
  provider_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('suspended','active','closed')),
  updated_by TEXT NOT NULL DEFAULT 'system',
  updated_at BIGINT NOT NULL DEFAULT 0
);
INSERT INTO payment_channel_controls(provider_id,provider_name,status) VALUES
 ('vpay','VPay','suspended'),('gspay','GSPAY','closed'),('1mpay','1MPAY','suspended'),('gspay_plus','GSPAY+','closed')
ON CONFLICT(provider_id) DO NOTHING;
ALTER TABLE payment_channel_controls ALTER COLUMN status SET DEFAULT 'closed';

CREATE TABLE IF NOT EXISTS brand_directory_entries (
  id TEXT PRIMARY KEY NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('SLOT','FAST GAME','LIVE','FISH','SPORT','OTHERS')),
  display_name TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  marked BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('suspended','active','closed')),
  image_data TEXT NOT NULL DEFAULT '',
  updated_by TEXT REFERENCES users(id),
  updated_at BIGINT NOT NULL DEFAULT 0,
  UNIQUE(category, display_name)
);
CREATE INDEX IF NOT EXISTS brand_directory_order ON brand_directory_entries(category, position);
CREATE TABLE IF NOT EXISTS api_supplier_artwork (
  provider_id TEXT PRIMARY KEY NOT NULL,
  image_data TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','closed')),
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS portal_schema_migrations (
  version TEXT PRIMARY KEY NOT NULL,
  applied_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS portal_status_snapshots (
  migration_version TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_key TEXT NOT NULL,
  row_data JSONB NOT NULL,
  captured_at BIGINT NOT NULL,
  PRIMARY KEY(migration_version, entity_type, entity_key)
);
CREATE INDEX IF NOT EXISTS portal_status_snapshot_key ON portal_status_snapshots(migration_version, entity_type, entity_key);
CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  provider_id TEXT NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay','gspay_plus')),
  provider_name TEXT NOT NULL,
  bank_code TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_holder_encrypted TEXT NOT NULL,
  account_number_encrypted TEXT NOT NULL,
  account_last4 TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  status TEXT NOT NULL CHECK (status IN ('pending','approved','processing','paid','rejected','cancelled')),
  owner_note TEXT NOT NULL DEFAULT '',
  updated_by TEXT REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key)
);
CREATE INDEX IF NOT EXISTS withdrawal_requests_user_created ON withdrawal_requests(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS withdrawal_requests_status_created ON withdrawal_requests(status,created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS withdrawal_one_open_per_member ON withdrawal_requests(user_id) WHERE status IN ('pending','approved','processing');

-- Populate the shared reservation guard for sessions/requests created before
-- this table existed. Game holds win if a legacy race produced both records,
-- because those funds may already have moved to the supplier.
INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at)
 SELECT user_id,'game',id,amount_out_minor,created_at FROM game_wallet_sessions
 WHERE status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')
 ON CONFLICT DO NOTHING;
INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at)
 SELECT user_id,'withdrawal',id,amount_minor,created_at FROM withdrawal_requests
 WHERE status IN ('pending','approved','processing')
 ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS payment_recovery_leases (
  provider TEXT NOT NULL CHECK (provider IN ('vpay','gspay')),
  order_id TEXT NOT NULL REFERENCES deposit_orders(id) ON DELETE CASCADE,
  claim_token TEXT NOT NULL,
  locked_until BIGINT NOT NULL DEFAULT 0,
  last_checked_at BIGINT NOT NULL DEFAULT 0,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  PRIMARY KEY(provider,order_id)
);
CREATE INDEX IF NOT EXISTS payment_recovery_due ON payment_recovery_leases(provider,locked_until,last_checked_at);
CREATE TABLE IF NOT EXISTS provider_payout_controls (
  provider_id TEXT PRIMARY KEY NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay')),
  submission_enabled INTEGER NOT NULL DEFAULT 0 CHECK (submission_enabled=0 OR (provider_id='gspay' AND submission_enabled=1)),
  updated_at BIGINT NOT NULL DEFAULT 0
);
INSERT INTO provider_payout_controls(provider_id,submission_enabled,updated_at)
VALUES ('vpay',0,0),('gspay',0,0),('1mpay',0,0)
ON CONFLICT(provider_id) DO NOTHING;
CREATE TABLE IF NOT EXISTS provider_payouts (
  id TEXT PRIMARY KEY NOT NULL,
  withdrawal_id TEXT NOT NULL UNIQUE REFERENCES withdrawal_requests(id),
  provider_id TEXT NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay')),
  request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  status TEXT NOT NULL CHECK (status IN ('prepared','submitting','processing','succeeded','failed','reversed','review')),
  create_outcome TEXT NOT NULL DEFAULT 'not_submitted' CHECK (create_outcome IN ('not_submitted','in_flight','accepted','unknown','rejected')),
  provider_reference TEXT,
  last_event_hash TEXT,
  last_error_code TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  completed_at BIGINT,
  UNIQUE(provider_id,request_key),
  UNIQUE(provider_id,provider_reference)
);
CREATE INDEX IF NOT EXISTS provider_payout_status ON provider_payouts(provider_id,status,updated_at);

CREATE TABLE IF NOT EXISTS game_catalogue_cache (
 provider_id TEXT PRIMARY KEY NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('available','empty','blocked','unavailable')),
 games_json TEXT NOT NULL DEFAULT '[]',
 checked_at BIGINT NOT NULL DEFAULT 0,
 last_success_at BIGINT NOT NULL DEFAULT 0,
 lease_until BIGINT NOT NULL DEFAULT 0,
 upstream_status INTEGER,
 complete INTEGER NOT NULL DEFAULT 0 CHECK(complete IN (0,1))
);

INSERT INTO providers(id,name,category,symbol,visible) VALUES('evo888h5','EVO888H5','supplier','EVO',1) ON CONFLICT(id) DO NOTHING;

-- Release 67 operations automation. Existing rows are promoted once by the
-- matching startup migration in lib/render-migrations.mjs.
ALTER TABLE lobby_ads ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'draft';
ALTER TABLE lobby_ads ADD COLUMN IF NOT EXISTS starts_at BIGINT;
ALTER TABLE lobby_ads ADD COLUMN IF NOT EXISTS ends_at BIGINT;
CREATE INDEX IF NOT EXISTS lobby_ads_publish_window
  ON lobby_ads(status,enabled,starts_at,ends_at,position);

ALTER TABLE announcements ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'draft';
ALTER TABLE announcements ADD COLUMN IF NOT EXISTS starts_at BIGINT;
ALTER TABLE announcements ADD COLUMN IF NOT EXISTS ends_at BIGINT;
ALTER TABLE announcements ADD COLUMN IF NOT EXISTS updated_at BIGINT;
CREATE INDEX IF NOT EXISTS announcements_publish_window
  ON announcements(status,starts_at,ends_at,created_at);

CREATE TABLE IF NOT EXISTS accounting_daily_snapshots (
  period_start BIGINT PRIMARY KEY NOT NULL,
  period_end BIGINT NOT NULL UNIQUE,
  label TEXT NOT NULL,
  timezone TEXT NOT NULL DEFAULT 'Asia/Kuching',
  report_type TEXT NOT NULL DEFAULT 'settled_cashflow',
  deposit_orders INTEGER NOT NULL,
  deposit_members INTEGER NOT NULL,
  deposit_minor TEXT NOT NULL,
  withdrawal_orders INTEGER NOT NULL,
  withdrawal_members INTEGER NOT NULL,
  withdrawal_minor TEXT NOT NULL,
  net_cashflow_minor TEXT NOT NULL,
  deposit_providers_json TEXT NOT NULL,
  withdrawal_providers_json TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1,
  checksum TEXT NOT NULL,
  closed_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS accounting_daily_closed
  ON accounting_daily_snapshots(closed_at DESC,period_start DESC);

CREATE TABLE IF NOT EXISTS accounting_snapshot_adjustments (
  id TEXT PRIMARY KEY NOT NULL,
  period_start BIGINT NOT NULL REFERENCES accounting_daily_snapshots(period_start),
  revision INTEGER NOT NULL,
  deposit_orders_delta INTEGER NOT NULL,
  deposit_minor_delta TEXT NOT NULL,
  withdrawal_orders_delta INTEGER NOT NULL,
  withdrawal_minor_delta TEXT NOT NULL,
  net_cashflow_minor_delta TEXT NOT NULL,
  detected_at BIGINT NOT NULL,
  details_json TEXT NOT NULL,
  UNIQUE(period_start,revision)
);
CREATE INDEX IF NOT EXISTS accounting_snapshot_adjustment_period
  ON accounting_snapshot_adjustments(period_start,revision);

CREATE TABLE IF NOT EXISTS accounting_late_adjustments (
  id TEXT PRIMARY KEY NOT NULL,
  original_period_start BIGINT NOT NULL REFERENCES accounting_daily_snapshots(period_start),
  source_type TEXT NOT NULL CHECK(source_type IN ('deposit','withdrawal')),
  source_id TEXT NOT NULL,
  provider TEXT NOT NULL,
  amount_minor TEXT NOT NULL,
  settled_at BIGINT NOT NULL,
  detected_at BIGINT NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS accounting_late_adjustment_period
  ON accounting_late_adjustments(original_period_start,settled_at);

CREATE TABLE IF NOT EXISTS accounting_job_runs (
  job_key TEXT PRIMARY KEY NOT NULL,
  period_start BIGINT NOT NULL,
  started_at BIGINT NOT NULL,
  completed_at BIGINT,
  status TEXT NOT NULL CHECK(status IN ('running','completed','failed')),
  result_json TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS accounting_job_status
  ON accounting_job_runs(status,started_at DESC);
CREATE INDEX IF NOT EXISTS deposit_orders_settlement_scan
  ON deposit_orders(status,updated_at);
CREATE INDEX IF NOT EXISTS withdrawal_requests_settlement_scan
  ON withdrawal_requests(status,updated_at);

-- Reward automation is deliberately fail-closed. These rows preserve immutable
-- previews/intents for later acceptance without posting to the real wallet.
CREATE TABLE IF NOT EXISTS benefit_claims (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  benefit_rule_id TEXT NOT NULL,
  request_key TEXT NOT NULL,
  deposit_order_id TEXT REFERENCES deposit_orders(id),
  rules_snapshot_json TEXT NOT NULL,
  deposit_minor BIGINT NOT NULL DEFAULT 0 CHECK (deposit_minor >= 0),
  reward_minor BIGINT NOT NULL CHECK (reward_minor > 0),
  turnover_required_minor BIGINT NOT NULL DEFAULT 0 CHECK (turnover_required_minor >= 0),
  expires_at BIGINT NOT NULL,
  status TEXT NOT NULL DEFAULT 'awaiting_acceptance' CHECK (status IN ('awaiting_acceptance','rejected','expired','cancelled')),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status IN ('disabled','pending_acceptance')),
  turnover_source_status TEXT NOT NULL DEFAULT 'not_connected' CHECK (turnover_source_status IN ('not_connected','pending_acceptance')),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id,request_key)
);
CREATE INDEX IF NOT EXISTS benefit_claims_user_created ON benefit_claims(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS benefit_claims_rule_status ON benefit_claims(benefit_rule_id,status,created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS benefit_claims_one_per_deposit ON benefit_claims(user_id,benefit_rule_id,deposit_order_id) WHERE deposit_order_id IS NOT NULL;

-- RM88 Voucher fulfillment is intentionally company-manual. The portal records
-- the review, up to five evidenced plays, turnover verification and the final
-- company transfer reference; it never posts funds or invents provider results.
CREATE TABLE IF NOT EXISTS voucher_manual_reviews (
  claim_id TEXT PRIMARY KEY NOT NULL REFERENCES benefit_claims(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('approved','closed_no_win','turnover_review','eligible_for_payout','paid','rejected')),
  max_plays INTEGER NOT NULL CHECK (max_plays BETWEEN 1 AND 100),
  plays_used INTEGER NOT NULL DEFAULT 0 CHECK (plays_used >= 0 AND plays_used <= max_plays),
  won_once INTEGER NOT NULL DEFAULT 0 CHECK (won_once IN (0,1)),
  provider_credit_reference TEXT NOT NULL DEFAULT '',
  turnover_required_minor BIGINT NOT NULL CHECK (turnover_required_minor >= 0),
  turnover_verified_minor BIGINT NOT NULL DEFAULT 0 CHECK (turnover_verified_minor >= 0),
  turnover_evidence_reference TEXT NOT NULL DEFAULT '',
  payout_cap_minor BIGINT NOT NULL CHECK (payout_cap_minor > 0),
  payout_minor BIGINT NOT NULL DEFAULT 0 CHECK (payout_minor >= 0 AND payout_minor <= payout_cap_minor),
  payout_reference TEXT NOT NULL DEFAULT '',
  approved_by TEXT REFERENCES users(id),
  approved_at BIGINT,
  paid_by TEXT REFERENCES users(id),
  paid_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS voucher_manual_reviews_status ON voucher_manual_reviews(status,updated_at DESC);

CREATE TABLE IF NOT EXISTS voucher_manual_play_events (
  id TEXT PRIMARY KEY NOT NULL,
  claim_id TEXT NOT NULL REFERENCES voucher_manual_reviews(claim_id) ON DELETE CASCADE,
  play_number INTEGER NOT NULL CHECK (play_number BETWEEN 1 AND 100),
  outcome TEXT NOT NULL CHECK (outcome IN ('win','loss')),
  evidence_reference TEXT NOT NULL,
  recorded_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  UNIQUE(claim_id,play_number)
);
CREATE INDEX IF NOT EXISTS voucher_manual_play_events_claim ON voucher_manual_play_events(claim_id,play_number);

CREATE TABLE IF NOT EXISTS commission_periods (
  id TEXT PRIMARY KEY NOT NULL,
  settings_hash TEXT NOT NULL,
  settings_snapshot_json TEXT NOT NULL,
  basis TEXT NOT NULL CHECK (basis IN ('deposit','turnover','company_profit')),
  frequency TEXT NOT NULL CHECK (frequency IN ('daily','weekly_mon','monthly')),
  period_start BIGINT NOT NULL,
  period_end BIGINT NOT NULL,
  total_basis_minor BIGINT NOT NULL DEFAULT 0 CHECK (total_basis_minor >= 0),
  total_commission_minor BIGINT NOT NULL DEFAULT 0 CHECK (total_commission_minor >= 0),
  status TEXT NOT NULL DEFAULT 'preview' CHECK (status IN ('preview','disabled','unsupported')),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status='disabled'),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(settings_hash,period_start,period_end)
);
CREATE INDEX IF NOT EXISTS commission_periods_latest ON commission_periods(period_end DESC,updated_at DESC);

CREATE TABLE IF NOT EXISTS commission_entries (
  id TEXT PRIMARY KEY NOT NULL,
  period_id TEXT NOT NULL REFERENCES commission_periods(id),
  upline_user_id TEXT NOT NULL REFERENCES users(id),
  source_user_id TEXT NOT NULL REFERENCES users(id),
  level INTEGER NOT NULL CHECK (level BETWEEN 1 AND 3),
  rate_basis_points INTEGER NOT NULL CHECK (rate_basis_points BETWEEN 0 AND 10000),
  basis_minor BIGINT NOT NULL CHECK (basis_minor >= 0),
  commission_minor BIGINT NOT NULL CHECK (commission_minor > 0),
  available_at BIGINT NOT NULL,
  expires_at BIGINT,
  status TEXT NOT NULL DEFAULT 'preview' CHECK (status='preview'),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status='disabled'),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(period_id,upline_user_id,source_user_id,level)
);
CREATE INDEX IF NOT EXISTS commission_entries_upline ON commission_entries(upline_user_id,period_id,level);

CREATE TABLE IF NOT EXISTS turnover_obligations (
  id TEXT PRIMARY KEY NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN ('benefit','commission')),
  source_id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  required_minor BIGINT NOT NULL CHECK (required_minor >= 0),
  completed_minor BIGINT NOT NULL DEFAULT 0 CHECK (completed_minor=0),
  wager_source_status TEXT NOT NULL DEFAULT 'not_connected' CHECK (wager_source_status='not_connected'),
  status TEXT NOT NULL DEFAULT 'blocked' CHECK (status='blocked'),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS turnover_obligations_user ON turnover_obligations(user_id,status,created_at DESC);

CREATE TABLE IF NOT EXISTS wallet_posting_intents (
  id TEXT PRIMARY KEY NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN ('benefit','commission')),
  source_id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  account_bucket TEXT NOT NULL CHECK (account_bucket IN ('bonus','commission')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  idempotency_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'disabled' CHECK (status='disabled'),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS wallet_posting_intents_user ON wallet_posting_intents(user_id,status,created_at DESC);

-- Rewards Hub points are a separate, non-cash ledger. No row in these tables
-- can post to the member money wallet or be redeemed in this release.
CREATE TABLE IF NOT EXISTS rewards_checkins (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  myt_day BIGINT NOT NULL,
  cycle_day INTEGER NOT NULL CHECK (cycle_day BETWEEN 1 AND 7),
  streak INTEGER NOT NULL CHECK (streak > 0),
  points INTEGER NOT NULL DEFAULT 0 CHECK (points >= 0),
  created_at BIGINT NOT NULL,
  UNIQUE(user_id,myt_day)
);
CREATE INDEX IF NOT EXISTS rewards_checkins_user_day
  ON rewards_checkins(user_id,myt_day DESC);

CREATE TABLE IF NOT EXISTS rewards_points_ledger (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL CHECK (source_type IN ('checkin','mission','milestone')),
  source_id TEXT NOT NULL,
  points INTEGER NOT NULL CHECK (points > 0),
  status TEXT NOT NULL DEFAULT 'earned' CHECK (status='earned'),
  cash_value_status TEXT NOT NULL DEFAULT 'none' CHECK (cash_value_status='none'),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status='disabled'),
  redemption_status TEXT NOT NULL DEFAULT 'disabled' CHECK (redemption_status='disabled'),
  created_at BIGINT NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS rewards_points_user_created
  ON rewards_points_ledger(user_id,created_at DESC,id DESC);

-- Member-selected Responsible Play settings. No profile row means no limits,
-- preserving existing member behavior until the member opts in.
CREATE TABLE IF NOT EXISTS responsible_play_locks (
  user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  touched_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS responsible_play_profiles (
  user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  daily_limit_minor BIGINT CHECK (daily_limit_minor IS NULL OR daily_limit_minor > 0),
  weekly_limit_minor BIGINT CHECK (weekly_limit_minor IS NULL OR weekly_limit_minor > 0),
  monthly_limit_minor BIGINT CHECK (monthly_limit_minor IS NULL OR monthly_limit_minor > 0),
  pending_daily_limit_minor BIGINT CHECK (pending_daily_limit_minor IS NULL OR pending_daily_limit_minor > 0),
  pending_weekly_limit_minor BIGINT CHECK (pending_weekly_limit_minor IS NULL OR pending_weekly_limit_minor > 0),
  pending_monthly_limit_minor BIGINT CHECK (pending_monthly_limit_minor IS NULL OR pending_monthly_limit_minor > 0),
  pending_limits_effective_at BIGINT,
  cooling_off_until BIGINT,
  self_excluded_until BIGINT,
  version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
  last_change_id TEXT NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS responsible_play_active_windows
  ON responsible_play_profiles(cooling_off_until,self_excluded_until);
CREATE TABLE IF NOT EXISTS responsible_play_deposit_reservations (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  request_key TEXT NOT NULL,
  provider TEXT NOT NULL CHECK (provider IN ('vpay','gspay','1mpay','manual_bank')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','consumed','released')),
  order_id TEXT REFERENCES deposit_orders(id),
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY(user_id,request_key)
);
CREATE INDEX IF NOT EXISTS responsible_play_reservations_active
  ON responsible_play_deposit_reservations(user_id,status,expires_at);
CREATE OR REPLACE FUNCTION responsible_play_reject_active_window_shortening()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE current_epoch BIGINT := CAST(EXTRACT(EPOCH FROM NOW()) AS BIGINT);
BEGIN
  IF OLD.cooling_off_until IS NOT NULL AND OLD.cooling_off_until > current_epoch
     AND (NEW.cooling_off_until IS NULL OR NEW.cooling_off_until < OLD.cooling_off_until) THEN
    RAISE EXCEPTION 'RESPONSIBLE_PLAY_ACTIVE_WINDOW_IMMUTABLE';
  END IF;
  IF OLD.self_excluded_until IS NOT NULL AND OLD.self_excluded_until > current_epoch
     AND (NEW.self_excluded_until IS NULL OR NEW.self_excluded_until < OLD.self_excluded_until) THEN
    RAISE EXCEPTION 'RESPONSIBLE_PLAY_ACTIVE_WINDOW_IMMUTABLE';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS responsible_play_no_active_window_shortening ON responsible_play_profiles;
CREATE TRIGGER responsible_play_no_active_window_shortening
BEFORE UPDATE OF cooling_off_until,self_excluded_until ON responsible_play_profiles
FOR EACH ROW EXECUTE FUNCTION responsible_play_reject_active_window_shortening();
