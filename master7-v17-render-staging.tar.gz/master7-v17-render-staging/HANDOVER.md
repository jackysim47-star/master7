# MASTER7 payment and registration handover — 5 November 2026

Release: `17.0.0-selfbuilt.31-1mpay-deposits`.
Deployment: Render ahbi, `master7-v17-staging`. The tracked `master7-v17-render-staging.tar.gz` is the deployed source. The unrelated standalone app at the repository root is not deployed by this service.

## Customer and owner entry

- Member: `https://master7.best` currently redirects to the deployed `/signin` page. Members sign in using ID and password. Malaysian SMS OTP is for registration only.
- Owner: `https://master7.site` currently redirects to `/admin`. Owner/staff use ID and password without SMS.
- Anchor uses its supplied non-token GET protocol over HTTPS, sender 66886. Credentials are configured only on the server. `smsOtpReady` confirms configuration, not successful delivery to every handset.
- This release does not reset an owner or member password and does not publish the separate staff/reward candidate. No account password is included in this document.

## VPay

- Deployed member checkout follows the backend enabled flag. The gateway and application order/callback tokens were paired; vendor credentials and query token were preserved.
- The member submits amount, method and payer name. Only the validated VPay cashier URL is shown.
- Signed vendor notifications are forwarded through the gateway; the application independently queries the provider before writing two balanced, idempotent ledger entries.
- `/payment/return` exists. Authenticated callback-configuration GET is read-only.
- The internal `uat` label remains in the existing adapter. It is not evidence that the supplier offers a sandbox. Actual bank payment and wallet settlement still require verification.

## 1MPay deposit integration

- Implements the supplied 1MPay API Specification 1.3 (23 June 2026), production API `https://api.1mpay.net`.
- Backend POST `/fundtransfer/json`: amount fixed to two decimals, unique refid, stable pseudonymous member customer, MYR, callback/return URLs and base64 of the raw SHA256 digest in the exact documented concatenation order.
- Callback: `https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment`.
- Return: `https://master7-v17-staging.onrender.com/payment/return`.
- Callback token is validated, then GET `/transquery/{trxno}/{base64_token}` independently confirms the merchant, amount, reference, customer, provider transaction and token. The documented callback signature does not cover status, so callback status alone cannot credit a wallet.
- Initial failure/timeout can be followed by a later success, as required by the supplier. Duplicate notifications cannot add duplicate wallet credit. Failed database batches roll back. Inconsistent existing ledger entries are held for review.
- Member POST `/api/payments/1mpay/orders/query` reconciles only that member's own order. Closing a channel prevents new orders while outstanding signed payments can still settle.
- Health and payment-channel status now report configured deposit switches separately from settlement verification; enabling production checkout does not mark a bank payment verified.
- The existing member wallet and owner deposit list include both providers. Customer records display platform and provider reference numbers.
- The application talks directly to 1MPay. The separate game/payment gateway IP must not be substituted for this application's outbound IP. Private authenticated diagnostics reports an observed application IP; it does not guarantee a fixed IP or the full Render outbound range.
- `/payout` is not invoked by this integration. Provider bank/settlement settings were not changed. An unpaid checkout or API configuration is not proof of a completed bank deposit.

Server-only variables: ONE_MPAY_API_BASE_URL, ONE_MPAY_MERCHANT, ONE_MPAY_SECRET_KEY, ONE_MPAY_ORDERS_ENABLED, ONE_MPAY_CALLBACK_URL, ONE_MPAY_RETURN_URL, ONE_MPAY_DIAGNOSTICS_TOKEN. No secret values are in this archive.

## Financial schema and activation

PostgreSQL migration 0017 widens only the existing deposit provider constraint; it deletes no orders or ledger entries. The SQLite migration preserves and checks both tables with foreign-key enforcement enabled. The one-time 0018 startup activation opens 1MPay only when its server configuration is present. It does not reopen a channel that the owner closes after activation. Migration and state snapshot are committed atomically with startup initialization.

Deployment rollback does not reverse a database migration. The added provider constraint is backward compatible with existing VPay rows; do not restore the old VPay-only constraint after 1MPay orders exist.

## Verification and remaining limits

- 105 Node/SQLite/backend/auth/UI checks passed.
- Real Chromium at 390px tested VPay and 1MPay with simulated RM20 provider responses: checkout visibility, method selection, stable duplicate request key, order references, independent query credit, return page, disabled channels and no mobile overflow.
- Render-specific TypeScript check (`tsconfig.render.json`, ES2022 for the deployed Node runtime) and production bundle build passed. Financial tests contacted no external provider and moved no money.
- GSPAY/GSPAY+ are still closed. Recent Google Authenticator attempts were rejected; no further stale code is submitted. Exact create-order response and callback acknowledgement rules plus merchant API configuration remain unresolved. Backoffice login or a supplier screenshot must not be marked as live wallet settlement.
- Games remain catalogue-only; actual launch, transfer/seamless debit and credit, turnover settlement and automated benefits are not made operational by this payment release. Consult the individual game API report for supplier errors.
