# MASTER7 V17 自建服务门户交接

本项目是从 V17 QA3 r3 界面迁移到托管 Worker + D1 的独立服务门户，不是原平台数据库恢复，也不包含已开通的游戏或收付款服务。

- 应用版本：17.0.0-selfbuilt.5
- 界面来源版本：17.0.0-preview.6-qa3-integrated-r3
- 原升级包 SHA256：5f3291b0f0f5e9f0c29a5dd82d4bfb0324e3b913ba94d91fc72c7a478bbb3033
- Site ID：appgprj_6ae447787f1c819193237856fd58b858
- 前台：站点根路径 `/`
- 后台：`/admin`；HTML 入口公开，数据和写操作均在服务端验证角色。
- 健康与版本：`/health`、`/api/version`，明确报告支付和游戏未连接。

## 使用

1. 已激活老板 ID 为 `master7_owner`（若本人改过 ID，使用新 ID）。直接进入 `/signin` 登录；不要重复激活。忘记密码时，先由站点维护人员签发一次性重设码，再进入 `/reset-owner` 设置新密码（15–128 个字符）。账号安全可更改 ID 与密码，需要当前密码；保存后该 ID 的所有密码会话失效。激活码不写入源码或本文。
2. 用户明确要求独立 ID/密码，因此在保留 Sites 托管登录集成的同时增加本门户密码登录。ChatGPT 仍作为独立登录选项；OWNER_EMAIL 对应的身份可获得老板权限，ChatGPT 会话不受本门户改密码影响。
3. 会员可自行注册 ID，或使用 ChatGPT 登录，均等待老板审批。两个入口不会按相同显示名自动合并。旧站账号没有迁移。
3. 员工先登录，再由老板进入后台“会员审批与员工授权”授权。只有老板可以审批、授权、查看审计和导出数据。
4. 会员提交工单；员工进入“客服”查看并回复、关闭或重新打开工单。
5. 员工可发布公告。老板可设置经审核的 Facebook / Instagram 主页。
6. 后台“导出门户数据”下载 JSON；不导出 CSRF 值。该导出供归档，不是已验收的整库恢复方案。

## 安全和数据

- 独立密码用原生 scrypt（N=32768,r=8,p=3、每账号随机盐）保存散列，不保存明文；OTP/邮箱密码找回尚未提供。
- 本门户密码会话为 32 字节随机令牌，只存 SHA-256；Secure、HttpOnly、SameSite=Strict、Host-only Cookie，固定 8 小时到期，每账号最多约 5 个活跃会话。密码变更递增版本并撤销该账号全部密码会话；退出撤销当前会话。
- 激活凭据只保存 SHA-256 环境变量，72 小时有效；数据库唯一消费标记与账号创建原子提交，不能重复使用。
- 登录按 ID 每 10 分钟 10 次、认证按 IP 每 10 分钟 30 次；注册每 IP 每 10 分钟 5 次，改密码每账号每 10 分钟 5 次。真实 IP 缺失时使用保守全站备用计数。
- 保留 Sites ChatGPT 登录，独立于密码会话。平台保留的身份和会话不能通过本门户密码更改撤销。
- D1 保存会员、工单、回复、公告、配置、审计和限流计数；不使用浏览器 localStorage 保存业务数据。
- 写操作验证同源 Origin、每用户 CSRF、审批状态、角色和每分钟 30 次写入限制。
- 会员只能读取自己的工单；员工不能修改老板或提升角色；撤权对下次请求立即生效。
- 每请求最多 24 KB；工单正文/回复最多 2000 字符，公告正文 1000 字符。
- 界面最多展示最近 100 条工单、500 名会员、100 条公告/审计；导出每表上限 10000 条，超过时拒绝而不静默截断。
- 不承诺并发容量或网络带宽上限；未做真实负载、跨区域和真机测试。

## 维护与部署

- `.openai/hosting.json` 保留原 project_id，D1 逻辑绑定 DB。
- Schema：`db/schema.ts`；已应用迁移不可修改，只能追加。
- 运行 API 安全回归：`node --test tests/api.test.mjs tests/password-auth.test.mjs`；Worker/D1 兼容回归：`node tests/auth-worker.mjs`。
- JS 检查：`node --check public/assets/app.js`；类型检查：`node node_modules/typescript/bin/tsc --noEmit`。
- 通过 Sites source helper 构建、提交和推送后再部署；应用版本与部署提交分别记录。
- 代码回退使用之前的已保存版本；数据库回退不能靠重新部署自动完成。可退回保存版本 2 的托管登录版本；密码表保留，回退不会删除账号资料。
- 首次部署前已做 SQLite 实际 SQL 回归（身份、CSRF、跨用户隔离、审批、员工授权、回复、关闭、撤权、重开数据、社媒校验、导出和限流）。这不代替真实用户登录及厂家端到端验收。

## 尚未接通

- 原站会员、余额、订单和交易历史。
- JILI、MegaH5、918KISS 的真实启动 API 和奖金接口。
- VPAY、GSPAY、1MPAY、GSPAY+ 收付款、签名回调及对账。
- 顾客前台 `www.master7.vip` 与共用后台 `admin.master7.vip` 的新站域名验证/DNS切换。
- www.master7.admin 不是有效公网域名；使用本站 `/admin`，以后可绑定合法子域名。
- 自动备份、整库恢复演练、生产容量验收和告警。

配置任何厂家前，需其正式 API 文档、商户账号对应的安全密钥配置入口、回调地址、允许来源及测试账号；不通过聊天正文传递密钥。

## 首次上线记录

2026-10-30：首版部署成功，公开入口已开启；正式站 `/health` 返回 ok，D1 ready。浏览器已验证首页、后台未登录保护、ChatGPT 登录跳转和 390px 窄屏布局（不是手机真机验收）。正式老板登录因浏览器尚未登录 OpenAI，未完成端到端验收。

当前正式入口只使用顾客前台 `www.master7.vip` 和共用后台 `admin.master7.vip`；域名仍需 DNS 验证，不能把独立网址上线视为正式域名已修复。

## 独立 ID 更新（用户选择 A）

保留现有网站和资料，新增密码凭据、会话两张表及追加迁移 0001。20 项 Node/SQLite 检查通过；8 个 Cloudflare workerd/D1 认证流程通过，包括激活、重复激活拒绝、登录、会话、老板权限、改密码、旧会话撤销、新密码登录。真实老板激活与首次登录需由用户设置自己的密码后完成，不用测试凭据冒充。

独立 ID 仅属于新服务门户，不是 Spaceship、原 MASTER7 后台、Google 或 ChatGPT 的账号。原域名 DNS、旧数据、游戏和付款连接仍未完成。

## 激活入口修正（17.0.0-selfbuilt.3）

2026-10-30：根据正式日志的激活 201、重复激活 409 和登录 401，修正旧激活链接仍可重复填写的问题。进入 `/activate` 会先读取服务器状态；激活已完成时切换登录页，提示使用首次设置的密码。旧页面提交遇到冲突后先确认已激活状态，再清空密码与激活码并切换登录。码不可用与账号已激活使用不同提示，读取失败不会被当作激活成功。

本次只增加公开激活状态布尔值和三语界面处理，不重设密码，不修改账号或迁移数据库。新增 5 项客户端流程检查；密码认证原有 9 项检查、JS 语法及类型检查通过。本地浏览器已核对不可用激活入口转到登录页并保留提示；已激活分支使用隔离客户端检查。真实老板登录仍未通过验收，域名验证、旧数据、游戏和支付接入仍未完成。


## 老板密码重设（17.0.0-selfbuilt.4）

新增 `/reset-owner`，只接受由已授权站点所有者签发、私下交接的 32 字节随机重设码。生产码有效期 60 分钟，仅保存 SHA-256；不提供自动邮件找回。新密码由用户本人输入两次，支持本地显示与一致性提示；源码、日志和交接文件不包含原始重设码或密码。

重设只绑定首次激活记录中的老板账号，不接受请求指定账号。密码自签发后已变更、码过期或已使用时拒绝；按 IP 每 10 分钟最多 5 次。消费标记、密码版本更新、全部该账号密码会话撤销及审计在同一事务提交，并防止读取后并发改密码覆盖。成功后回登录页，不自动登录；清除该 ID 的登录失败计数，IP 限流保留。会员、工单及其他网站资料不变，ChatGPT 登录仍独立管理。导出进一步排除激活与重设内部标记。

重设入口发布不等于真实账号已重设。需用户提交后核对服务器成功记录，并另行验收真实老板登录。保留上一版激活入口修正。

## 交接流程修正（17.0.0-selfbuilt.5）

- 重设页先读取服务端可用状态。没有有效重设码时显示明确说明，不让用户反复填写无效表单；读取失败不声称已激活或已重设。最终是否有效仍由服务端在提交时校验。
- 密码登录成功响应必须随后取得有效会话才关闭登录窗口、进入前后台。会话缺失时保留错误提示。
- 本门户密码退出成功后回本站登录页，不再依赖 ChatGPT 退出路由；ChatGPT 会话继续独立管理。
- 本轮没有重设真实老板密码、变更生产账号、迁移资料或开启资金与游戏。真实老板登录、域名 DNS 验证和整个平台营业验收仍未完成。

本轮验收：40 项 Node/SQLite/客户端检查通过；14 项 Cloudflare workerd/D1 认证检查通过；JS 语法、TypeScript 检查及正式构建通过。所有账号测试使用隔离数据库，未改生产资料。预览服务报告运行，但云端浏览器访问返回 ERR_CONNECTION_REFUSED，因此本轮视觉/真机验收未完成。生产账号最新可见登录为 2026-10-30 18:15:16 MYT 的 401，不能标记为已成功登录。

交付预览入口：https://master7-v17-selfbuilt.sunlitdog513.chatgpt.site ，前后台共用 `/signin`。正式地址仅为 `www.master7.vip` 和 `admin.master7.vip`；仍需持有域名 DNS 管理权限的人完成验证与服务绑定。没有游戏/支付真实接入验收，因此不能将此次门户发布交接称为整个平台已可营业。

## 渲染版三态管理更新（17.0.0-selfbuilt.14）

2026-11-04：每款厂商游戏、后台自定义游戏卡和四个充值入口分别使用 `Maintenance`、`Active`、`Close` 三态，并记录审计事件。`Maintenance` 在顾客大厅保留并标注维护，厂家返回的维护标记也会映射到此状态；`Close` 从顾客入口隐藏。`Active` 只表示后台状态，不会启用真钱支付、提款或未验收的游戏启动。回归、类型检查和 Render 构建已通过；真实 OTP、游戏启动及支付验收仍需外部配置与供应商 UAT。


## 大厅、赞助入口与 Claim Bonus（17.0.0-selfbuilt.15）

- 第一页为游戏大厅，第二页为 Deposit；游戏来自三个已配置厂商的目录，逐款展示并按类型及厂商分组。每款游戏后台独立上传 800 × 600（4:3）封面，使用 Maintenance、Active、Close 三态。Close 仅隐藏顾客入口。
- JILI、MEGAH5、918KISS 三个赞助入口各有独立图片上传（800 × 600）、View games 和 Claim Bonus 按钮。后台福利可选指定厂商并发布；Claim Bonus 展示该厂商福利，会员提交后建立客服工单供人工审核。它不会自动加余额。
- 旧的小游戏记录保留在独立数据库中，但从顾客 API 和后台页面移除展示入口，不删除旧记录。
- 新增供应商图片与游戏图片两项数据库迁移；新封面只保存在新门户数据库。
- staging 尚未通过短信 OTP、厂家启动/结算、正式支付提款的端到端 UAT；Active 不代表可真钱运营。生产 DNS 和旧站数据未修改。

本轮验证：62 项 Node 回归通过、`npx tsc --noEmit` 通过、`npm run build:render` 通过。

## 分类别名录与关闭默认值（17.0.0-selfbuilt.16）

- 加入老板后台专用的 76 个游戏厂家/品牌目录，按 SLOT、FAST GAME、LIVE、FISH、SPORT、OTHERS 六类独立展示；未接通的厂家不会出现在顾客大厅。
- 老板可以为目录项和已接入目录的单款游戏上传 800 × 600（4:3）图片，并设置 Maintenance、Active 或 Close；员工只读。
- 新迁移会在数据库事务内先快照原有游戏、支付通道、小游戏卡及赞助厂家显示状态，再把游戏、支付通道和小游戏卡设为 Close。该状态快照可协助回滚本次更改，不等同于整库备份。
- Active 只改后台展示/状态，短信 OTP、真钱交易和真实游戏启动仍待供应商 UAT。


## 2026-11-05 checkout and registration correction

Release: `17.0.0-selfbuilt.30-vpay-checkout`. The member checkout now follows the backend `enabled` result instead of requiring an unreachable `live` label. The backend still validates merchant identity, configured methods and amounts; callbacks independently query the provider and credit a balanced ledger once. Added the payment-return route and an authenticated GET callback-configuration check that never writes money.

Member sign-in uses ID and password. Malaysian SMS OTP verifies registration only, using the supplied Anchor non-token GET protocol and its actual 201/data[] receipt format. Successfully phone-verified registrations receive member access; historical unapproved accounts are unchanged.

Validation: backend/regression tests, password/OTP tests, production bundle build and a real Chromium flow with a simulated RM20 checkout. No actual payment or payout was submitted by these tests. VPay settlement remains unverified until a real customer payment is confirmed. GSPAY and 1MPay are not marked complete by this release; their separate integration work continues.
