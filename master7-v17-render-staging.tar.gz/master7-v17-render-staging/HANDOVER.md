# Wallet deposit, withdrawal and company-bank handover — 5 November 2026

## V174 public UAT preview — 14 November 2026 MYT

- Release: `17.0.0-selfbuilt.174-uat-preview`.
- `/uat-preview` is an unauthenticated, read-only view of the current health,
  OTP, three primary MYR payment profiles and game-profile acceptance status.
- The page uses only `GET /health`, `GET /api/payment-channels` and
  `GET /api/games`. It cannot create orders, move wallet balances, launch a
  provider game, place a wager or submit a withdrawal.
- The member sign-in page links to the preview so the Owner can inspect the
  platform without a customer account. Search indexing is disabled.
- Existing fail-closed controls remain unchanged. This release does not
  represent supplier UAT, merchant settlement acceptance or production GO.
- Local verification passed: maintenance `12/12`, release probe `27/27`, full
  regression `1461/1461`, Render DB `3/3`, TypeScript, ESLint and the Render
  production build. No live provider transaction was performed.

## GSPAY post-credit conflict candidate · `.118`

- A contradictory or incomplete post-credit notification triggers a bound
  independent query. A confirmed failure or nonterminal state preserves the
  ledger and holds the same order for review; a successful query preserves
  the credit. A timeout is retryable and never treats the hint as proof.
- Credited member refresh now rechecks the provider. Query binding conflicts
  are held only against the matching member, amount and provider reference.
- The owner control UI explains that automatic mode can reopen deposits and
  does not certify real-payment acceptance. Local tests only; no deployment.
  The GSPAY direct-host startup/payout mismatch remains unresolved. See
  `docs/MASTER7_GSPAY_STATUS_CONFLICT_V26.md`.

## Independent deposit controls candidate · `.117`

- Owner-only, audited pause/automatic controls cover VPay, GSPAY MYR, 1MPay
  and manual bank. Staff can view controls. Missing overrides preserve the
  previous automatic behavior; invalid values are treated as paused.
- New deposits are checked independently; existing callbacks, queries and
  recovery remain available. Requests already past the pause check may finish.
- The setting lives in the existing backed-up settings table. Old `.99` code
  ignores it: production rollout must prevent mixed-version financial writes.
  See `docs/MASTER7_DEPOSIT_ADMIN_CONTROLS_V25.md`.

## VPay lost-reference recovery candidate · `.116`

- Gateway candidate 1.13.2 accepts VPay `ORDER_GET` by trader order number
  when the provider transaction number was lost; the existing query-token
  scope and provider request signature still apply.
- Portal candidate can recover stale `creating` and `unknown` MYR orders
  without a reference. It checks order, amount, optional merchant/currency,
  paid state, member guard and both ledger legs before reporting credit.
- A synthetic gateway/portal test against isolated PostgreSQL covers two
  workers, callback loss, conflicting amount/reference, and member change.
- Local candidates only. The provider's actual behavior with this query and
  all real-money settlement remain unverified. Gateway update precedes portal
  update after separate approval. See `docs/MASTER7_VPAY_LOST_REFERENCE_V24.md`.

## Manual bank review guard candidate · `.115`

- Serialize review with wallet writes and bind it to the order's member,
  currency and amount. An existing or partial journal is retained for review.
- A claimed approval reports success only after verifying both matching ledger
  legs and its audit record; a lost claim or changed order returns a conflict.
- Five targeted SQLite cases and five isolated PostgreSQL tests (including the
  parent suite) passed. Concurrent reviewers created one balanced journal;
  audit failure rolled back the approval.
- Local candidate only; real bank payment, restore/rollback and production
  deployment are not verified. All running writers must share the guard.
  See `docs/MASTER7_MANUAL_BANK_GUARD_V23.md`.


## Durable game launch guard candidate · `.114`

- Persist an operation bound to member, game and wallet session before
  GameLogin. Launch and settlement claim the same member guard; unresolved
  launch states never expire or imply the provider session has closed.
- Preserve settlement and recovery for legacy sessions without a launch row,
  while documenting that their provider closure is not proven. No new launch
  is exposed until independent provider acceptance.
- 1MPay detects partial journals and contradictory provider statuses under the
  member guard and preserves the evidence for review.
- A new persistent launch table is in encrypted backups; older restore receipts
  have incomplete launch coverage. Provider close/wager rules remain unknown.
- Local verification: regression 924/924; maintenance 11/11; release probes
  16/16; Render DB adapter 3/3; isolated PostgreSQL launch 8/8 and 1MPay
  guard 5/5; TypeScript, ESLint and Render build passed.
- Local candidate only; migration, real game/payment acceptance and deployment
  have not occurred. See `docs/MASTER7_LAUNCH_GUARD_V22.md`.


## Deposit evidence and provider acceptance candidate · `.113`

- VPay and GSPAY MYR confirm the current order, provider reference and balanced
  ledger before reporting credit; persisted checkout responses must match.
- Provider contradictions and preexisting partial or invalid ledger entries are
  preserved and placed under review while holding the member guard. GSPAY
  review callbacks now return HTTP 409; vendor retry rules remain unverified.
- Unverified game providers remain visible in the directory but cannot launch;
  settlement and recovery of existing game wallets remain available. MegaH5
  zero-balance new sessions are blocked pending a durable session contract.
- Local verification: full regression 908/908, maintenance 11/11, release
  probes 16/16, Render database adapter 3/3, isolated Postgres deposit races
  11/11, game wallet 4/4, wallet guard 11/11; TypeScript, ESLint and build.
- Candidate only; no live transactions or deployment were performed. See
  `docs/MASTER7_DEPOSIT_EVIDENCE_V21.md` and
  `docs/MASTER7_GAME_LAUNCH_SETTLEMENT_RACE.md`.


## Payment acknowledgment and game response binding candidate · `.112`

- 1MPay callbacks only acknowledge after an independently queried success
  matches the current credited order and balanced ledger. An unconfirmed
  response gets a retryable HTTP response; provider retry behavior is unverified.
- MegaH5 deposit/withdraw responses require the gateway's operation and
  referenceId; transfer-status requires its operation. Ambiguous responses keep
  the wallet reserved for recovery.
- GSPAY non-credited review transitions also acquire the member guard to
  prevent a historical partial ledger from racing a new commitment.
- Local verification: regression 882/882, maintenance 11/11, release probes
  16/16, Render DB adapter 3/3; isolated PostgreSQL callback 4/4, game 4/4
  and wallet guard 11/11; TypeScript, ESLint and Render build passed.
- Local candidate only. Existing orders, true provider transactions and live
  game settlement remain unverified; see docs/MASTER7_CALLBACK_BINDING_V20.md.


## Member wallet serialization candidate · `.111`

- Introduces a per-member transient guard so current payout, deposit review,
  game settlement and new withdrawal/game reservation writes use one locking
  order; new commitments recheck risk and integer balance inside the lock.
- A credited deposit placed in review freezes new commitments pending
  reconciliation; uncredited reviewed orders alone do not freeze the member.
- The 0111 guard contains no financial state, is excluded from encrypted
  backups and is re-created on demand. Persistent balances, ledger and
  reservations must remain in backups.
- Candidate only; live provider/payment acceptance and historical incident
  evidence remain outstanding. Existing in-flight calls cannot be recalled.
- Local verification: full regression 855/855; maintenance 11/11; release
  probes 16/16; Render DB adapter 3/3; isolated PostgreSQL wallet guard 9/9.
  TypeScript, ESLint and Render build passed.
- Migration and rollout must prevent old and new service instances from
  processing financial operations concurrently; direct SQL and future game
  adapters must obey this same guard. See docs/MASTER7_WALLET_GUARD_V19.md.


## Payout protection candidate · `.110`

- VPay and GSPAY payout observations are reconciled with matching payout,
  withdrawal and reservation state; rejected or contradictory observations
  now require review and retain pending funds rather than release them.
- Owner cancellation competes with provider submission on the same payout
  row; legacy records with missing or contradictory evidence require review.
- Operational change: provider failures and reversals are held for manual
  reconciliation. Plan a supervised resolution process before deployment.
- Common account-level serialization between a newly raised risk hold and all
  spending paths remains unproven. Live payments, payouts, games and historical
  transaction recovery are not certified by this local candidate.
- Local verification: full regression 833/833; maintenance 11/11; release
  probes 16/16; Render DB adapter 3/3; isolated PostgreSQL payout 11/11 and
  game wallet 4/4. TypeScript, ESLint and Render build passed.
- See `docs/MASTER7_PAYOUT_PROTECTION_V18_20261109.md`.


## GSPAY and MegaH5 transaction consistency candidate · `.109`

- Protect GSPAY MYR order creation against concurrent callback or recovery; a
  stale create response cannot expose a checkout link for a different or
  already-finalized transaction.
- Protect MegaH5 recovery and settlement from stale status updates; release a
  game reservation only after a matching session and ledger are established.
- Verification: full regression 790/790, maintenance 11/11, release probes
  16/16, Render DB adapter 3/3, isolated PostgreSQL payment 9/9 and game
  wallet 4/4; TypeScript, ESLint and Render build passed.
- Local candidate only; no provider, payment, game, or production acceptance is
  implied. See `docs/MASTER7_TRANSACTION_CONSISTENCY_V17_20261109.md`.
- VPay/GSPAY payout terminal-state concurrency remains an open financial risk;
  do not enable new payout processing on the strength of this candidate.


## VPay / GSPAY MYR recovery candidate · `.108`

- Preserves an authenticated VPay callback reference across query timeout;
  concurrent create responses cannot overwrite it or falsely mark it failed.
- Allows stale GSPAY MYR orders without a provider reference to be checked by
  portal order ID. Recovery and wallet posting remain restricted to MYR.
- The isolated PostgreSQL verification uses synthetic providers and an empty
  loopback database; it does not prove live settlement. See
  `docs/MASTER7_PAYMENT_RECOVERY_V16_20261109.md`.
- Local verification: 780/780 full regression, 11/11 maintenance, 16/16
  release probes, 3/3 Render database adapter and 6/6 isolated PostgreSQL
  payment checks; TypeScript, ESLint and Render build passed.



## 1MPay recovery candidate · `.107`

- Fixes the local scheduler so an independently enabled 1MPay recovery flag
  can start the loopback job without VPay or GSPAY being enabled. The worker
  remains opt-in and never resubmits an order.
- Preserves an authenticated order-bound callback reference before an
  independent query, protects review from stale reference observations, and
  records credit audit only for an actually credited matching order.
- Before deployment, check effective recovery flags and pending orders:
  existing `ONE_MPAY_RECOVERY_ENABLED=true` plus a valid token may now start
  automatic recovery. See `docs/MASTER7_1MPAY_RECOVERY_FIX_20261108.md`.
- Local candidate only; production payment acceptance and the owner-reported
  historical transaction remain unverified.
- Local verification: 765/765 full regression, 11/11 maintenance, 16/16
  release probes, 3/3 Render database adapter checks, TypeScript, ESLint and
  the Render-target build passed. No real payment was tested.



## Deposit evidence view candidate · `.106`

- The owner can look up a read-only order trace by ID or open it from the report, showing
  the order, provider reference, wallet entries and recorded diagnostic or
  callback-review events. A missing callback record remains unknown.
- The trace neither contacts a provider nor changes money. Ledger mismatches
  are flagged for review. Owner access is enforced by the server; stale browser
  responses are discarded on account change.
- GSPAY USDT is still disabled and requires its own provider contract. Real
  settlement, production deployment and recovery scheduling remain unverified.
  See `docs/MASTER7_DEPOSIT_TRACE_20261108.md`.
- Local verification: 756/756 full regression, 11/11 maintenance, 16/16
  release probes, 3/3 Render database adapter checks, TypeScript, ESLint and
  the Render-target build passed. No real payment was tested.



## Game wallet records and MYR reporting candidate · `.105`

- Members can inspect their own generic game-profile session and transfers;
  owner/staff can inspect generic and unmatched reservation records. These are
  read-only views and do not enable a supplier or add money-moving routes.
- A captured MegaH5 session ID protects against settling a newer session.
  Browser wallet records and auto-settlement stay bound to the member and
  profile which initiated them.
- MYR deposit report totals and detail exclude other currencies. GSPAY USDT
  remains a separate disabled profile without a transaction adapter.
- Payment and game provider real-money acceptance remains outstanding.
  See `docs/MASTER7_GAME_WALLET_RECORDS_20261108.md`.
- This is local code only; no live provider transaction, deployment, DNS,
  secret or production database changes were made.
- Local verification: 746/746 full regression, 11/11 maintenance, 16/16
  release probes, 3/3 Render database adapter checks, TypeScript, ESLint and
  the Render-target build passed. These include simulated, not real, payments.


## Game wallet reservation guard candidate · `.104`

- The member wallet now includes newer-profile and unmatched game
  reservations in its held balance. Cleanup preserves those reservations
  until an explicit settlement/review flow releases them atomically.
- A protected game reservation blocks a new MegaH5 transfer and withdrawal.
  Existing MegaH5 recovery remains available. Legacy settled reservations
  require a matching game-result ledger before cleanup.
- Migration `0110-game-provider-adapter-core` is required. Generic game
  settlement and actual JDB/VENUS wallet integration remain unimplemented.
  See `docs/MASTER7_GAME_WALLET_GUARD_20261108.md`.
- This is local code only. No production provider calls, deployment, DNS,
  secret changes or production database writes were made.
- Local verification: 737/737 full regression, 11/11 maintenance, 16/16
  release probes, 3/3 Render database adapter checks, TypeScript, ESLint and
  the Render-target build passed. Real-provider acceptance remains outstanding.

## JDB / EliteHubz protocol candidate · `.103`

- Adds an isolated, dependency-injected JDB transfer protocol client for
  catalogue, player, launch, transfer, transfer query and report operations.
  It is not connected to portal routes, wallet postings or the registry.
- Adds the EliteHubz v1.20.5 canonical query and HMAC helper validated against
  its published sample. It is not connected to live VENUS operations.
- JDB and SPRIBE player IDs and transfer serials use separate profile
  namespaces. Ambiguous transfer results remain unknown; exact matches still
  require ledger reconciliation. JDB `RM` currency and sub-cent balances are
  checked explicitly.
- JDB's introduction says space padding while JavaScript and Java samples use
  zero padding. The client requires an explicit vendor-confirmed choice.
  Report timezone, authorization, UAT, transfer integration and any callback
  contract remain unverified. See `docs/MASTER7_JDB_ELITEHUBZ_PROTOCOL_20261108.md`.
- This is a local candidate only; no production provider calls, deployment,
  DNS, secret or database changes were performed.
- Local verification: 728/728 full regression, 11/11 maintenance, 16/16
  release probes, 3/3 Render database adapter checks, TypeScript, ESLint and
  Render-target build passed. These fixtures do not establish supplier UAT.

## Universal game-provider core candidate · `.102`

Release candidate: `17.0.0-selfbuilt.102-game-provider-core`.

- The customer lobby retains **37 public brands** and now derives **41 public
  profiles** from the server registry. The registry contains **42 profiles in
  total** because `spribe_myr` is intentionally hidden until its independent
  contract is verified; it never reuses JDB player or ledger namespaces.
- Profiles that must stay independent are fixed as follows:
  `jili_myr_1to1` and `jili_my1_1to100`;
  `918kiss_normal_myr`, `918kiss_normal_my1_1to100` and
  `918kiss_free_myr`; `epicwin_normal_myr` and `epicwin_free_myr`.
  Each profile owns its player namespace, ledger namespace, wallet mode and
  unit scale. The frontend renders these profiles dynamically instead of
  treating one brand card as one wallet contract.
- `GameProviderAdapter` defines nine common operations: `listGames`,
  `createOrVerifyPlayer`, `depositToGame`, `launchGame`, `queryBalance`,
  `withdrawFromGame`, `queryTransfer`, `fetchWagers` and `handleCallback`.
  Missing contracts and missing implementations return a deterministic 503
  fail-closed result; a catalogue or brand image never enables real play.
- MegaH5 remains the only executable profile. Its transfer wallet is prepared
  before the provider launch request, so a failed or unknown wallet transfer
  cannot create a provider launch. Launch, wallet and settlement acceptance
  flags remain false until a controlled real-member reconciliation is signed.
- Migration `0110-game-provider-adapter-core` adds profile, player, session,
  transfer, round, transaction, balanced posting, callback receipt, wager
  cursor and recovery-lease tables without dropping or rewriting legacy game
  wallet records. Render startup requires the migration and all new tables.
  Encrypted backup/restore coverage includes them; older backups remain
  recoverable only with an explicit incomplete-coverage receipt.
- JDB has enough previously reviewed transfer-wallet documentation to begin a
  separate offline adapter, but callback mode, production parameters,
  whitelist and UAT acceptance remain open. RSG also has a documented transfer
  protocol, but its MASTER7 brand/profile mapping is unknown, so no public
  profile or executable adapter is assigned. Every other profile remains
  fail-closed until its exact versioned contract is supplied.
- Keys, tokens, IVs, passwords, certificates and private keys remain Secret or
  Secret File values. Credentials already shared in chat or attachments must
  be rotated before configuration. They are not copied into source or this
  handover.
- This candidate was prepared locally only. It does not deploy, change DNS or
  Render settings, write a production database, launch a game, move a wallet,
  process a callback or claim real settlement. Production acceptance still
  requires per-profile catalogue, player, launch, wallet, recovery, wager and
  reconciliation evidence.
- Local verification passed: **709/709** full regression checks, **11/11**
  maintenance checks, **16/16** release-probe checks, TypeScript, lint,
  **3/3** Render database adapter checks and the Render production build.
  These checks use controlled fixtures and do not replace provider or
  real-money production acceptance.


## Four independent payment profiles candidate · `.101`

Release candidate: `17.0.0-selfbuilt.101-payment-profiles`.

- Payment discovery now presents four fixed, independent server-side profiles:
  `vpay_myr`, `gspay_myr`, `gspay_usdt` and `onempay_myr`. Manual Bank remains
  a separate company-bank review flow and is not an automatic gateway profile.
- Each automatic profile has its own new-order gate. A profile gate must be
  explicitly enabled before a new order can be created. Closing that gate must
  not interrupt an existing order's authenticated callback, query or recovery.
  `PORTAL_NEW_DEPOSITS_ENABLED` remains the global new-deposit maintenance gate.
- GSPAY+ USDT has an independent public status and Portal card, but remains
  fail-closed. No USDT order, callback, query, recovery, wallet ledger or
  conversion is implemented until the supplier confirms the network, scale,
  signature, checkout, finality and reconciliation contract. Existing MYR
  tables and reports are not widened to USDT by this candidate.
- 1MPay recovery is separately controlled by `ONE_MPAY_RECOVERY_ENABLED`. It
  queries only an existing order that already has its bound provider reference;
  missing or conflicting references enter manual review, and a confirmed
  success can create only one balanced MYR ledger pair.
- VPay states 4 (reversed) and 5 (risk control) now require an independent
  provider query and create an idempotent manual-review incident. A prior
  balanced wallet credit is preserved for review and is never silently debited.
- Keys, tokens, passwords, certificates and provider credentials remain
  Render secrets only. Credentials pasted into chat or screenshots must be
  rotated before any production configuration; they are not copied into this
  repository or handover.
- Local verification passed: 695/695 full regression checks, 11/11 maintenance
  checks, 16/16 release-probe checks, TypeScript, lint, 3/3 Render database
  adapter checks and the Render production build. No real payment, payout,
  callback, wallet credit, USDT transfer or production settlement is claimed.
  Each enabled MYR profile still requires one approved minimum-value end-to-end
  reconciliation before production acceptance.

## Payment network bridge release — 7 November 2026

Release: `17.0.0-selfbuilt.91-payment-network-bridge`.

## GSPAY Portal ↔ Gateway bridge · `.91`

- The Portal now calls the current integration gateway for GSPAY MYR order and
  query traffic. Supplier credentials remain only in the gateway service.
- Order, query/signing and callback forwarding use three separate internal
  credentials. The public callback verifies the supplier signature, re-signs
  the event for the Portal and acknowledges only after the Portal returns an
  exact durable `ok` or `success` response.
- The supplier callback endpoint is
  `https://master7-integration-gateway.onrender.com/callbacks/gspay/payment`.
  The Portal callback is internal to the bridge and rejects a callback without
  its independent bearer token.
- GSPAY reports query and callback network readiness separately from new-order
  and paid-settlement acceptance. Real orders remain disabled until one
  controlled paid MYR order reconciles across supplier, Portal order and both
  balanced wallet entries.
- GSPAY records supplier callback source `52.221.96.227`. The merchant
  backoffice records MASTER7 outbound whitelist `74.220.52.132`; deployment
  egress must be checked again after each infrastructure change.
- Validation: 400/400 Portal tests, Render database adapter 3/3, 103/103
  Gateway tests and the Render production build pass.

## Direct GSPAY return route · `.90`

- GSPAY checkout returns directly to the live Render portal at
  `https://master7-v17-staging.onrender.com/payment/return`.
- The former `www.master7.best` return target is rejected because that hostname
  has no DNS record. The apex and `.site` domains currently use 302 forwarding,
  which is unsuitable for provider POST callbacks.
- Program configuration, checkout URL validation, startup activation and the
  environment example all require the same direct return URL.
- Real GSPAY orders, recovery, balance and payouts remain disabled. The change
  repairs routing only and does not claim payment or settlement acceptance.
- Validation: 399/399 full tests, Render database adapter 3/3, 47 focused
  GSPAY/routing/UI tests and the Render production build pass.

## Game checks truth · `.89`

- The backoffice keeps all 34 independent suppliers and now explains every
  connection, catalogue, launch and wallet result with compact status pills.
- Green means a check is complete, cyan means acceptance is pending, amber
  means the portal is waiting for a supplier or showing a retained maintenance
  catalogue, and red is reserved for an explicit supplier error or rejection.
- Catalogue cells show their saved title count. A retained catalogue remains
  visible as maintenance and never implies that a game can launch or settle.
- Each provider row states its current blocker, and the table summary separates
  catalogued titles from launch-ready providers.
- System readiness calls payment and game maintenance states “acceptance
  pending”, so an unverified production flow is not mistaken for an outage.
- This release changes the accuracy and presentation of the read-only checks.
  It does not enable games, wallets, settlements, payments or payouts.
- Validation: 398/398 full tests, Render DB adapter 3/3, the six focused
  game-check presentation tests and the Render production build pass.

## Payment preview truth · `.88`

- The public VPay, GSPAY+ and 1MPay cards require both the owner channel control
  and the provider status API `orderReady=true` before they display Available.
- A database channel marked active cannot advertise a disabled new-order route.
- This release changes presentation only; it does not enable a payment, game,
  wallet, settlement or payout switch.

- Customer assets use one `.88` cache key. Render serves versioned assets with
  browser caching while HTML, the service worker, manifest and offline shell
  remain revalidatable, reducing repeat-load delay without trapping an old UI.
- The lobby keeps exactly 34 independent provider entries. JDB and Pragmatic
  Play read-only catalogue sources are included; ATG maps to its assigned direct
  catalogue. Extra integration-only sources never appear as additional public
  providers.
- A retained or all-maintenance catalogue is displayed as maintenance. It does
  not make a provider launch-ready or a game playable. Catalogue, launch,
  transfer-wallet and settlement checks remain separate.
- Published customer benefits have a generic data-driven lobby area. No fixed
  RM88 promotion is embedded in the customer portal.
- GSPAY+ MYR uses the existing idempotent order and wallet workflow. The
  checkout opens in the current tab only after validating the exact HTTPS
  `secured.gspay.online` channel URL. Uncertain results lead members back to
  their own deposit records and display as confirming.
- GSPAY+ order availability and wallet-settlement acceptance are displayed
  separately. Production order creation remains closed until the supplier
  query-success, callback acknowledgement/retry contract and one reconciled
  real payment have been accepted. DuitNow, USDT and payout remain separate.
- Validation for `.88`: 392/392 full tests, Render DB adapter 3/3, focused customer-flow
  tests and the Render production build pass. Automated verification creates no
  player, payment, transfer, wager, wallet credit or payout.

## Operations corrections release — 6 November 2026

Release: `17.0.0-selfbuilt.66-operations-corrections`.

- Benefit calculations now treat a fixed turnover value of zero as unset and
  use the configured turnover multiplier. Members below the minimum deposit
  receive zero reward and zero turnover in both the API and browser preview.
- The backoffice bell counts open support tickets and opens the Support panel
  directly. It no longer mixes pending-member approvals into the ticket count
  or sends the operator to AI settings.
- The member Referral card labels its current figure as an all-time L1 gross
  estimate and explicitly states that it is not withdrawable. Commission
  period, hold, cap and wallet settlement remain separate and disabled until
  real business acceptance is complete.
- Release validation is 202/202 Portal tests, TypeScript pass, lint pass,
  Render DB 3/3 and production build pass. Runtime commit
  `7cd1c0bc7cd4f364b73770b01f864abfbe1c07fc`, bundle SHA-256
  `bfdfcb22549911ca996b25b84617b4064cb9da2c425c3644c06b497f4e5b4285`
  and Render deploy `dep-dbmrhjbbc2fs73aompu0` are live.
- Post-deploy health is HTTP 200 with `.66` and the database ready. New-instance
  application error/critical/fatal and request 5xx counts are zero.
- This release does not change any payment, game, payout, callback or wallet
  production switch. `.65-payment-safety` remains the rollback release.

## Payment safety release — 6 November 2026

Release: `17.0.0-selfbuilt.65-payment-safety`.

- VPay callback settlement now proves that both wallet-ledger entries belong to
  the order member, use the order currency and amount, and balance to zero.
  Missing, partial, unbalanced or cross-member ledgers move the order to
  `review`; they are not queried, posted or acknowledged as successful.
- VPay financial inserts are bound to the database order, provider, state and
  provider transaction. A committed order and its ledger are checked again
  before a success acknowledgement is returned.
- 1MPay can continue querying and reconciling already-created orders while the
  new-order channel remains closed. This does not enable a new order, callback
  or automatic settlement switch.
- The AI support response type no longer contains a duplicate `status` field,
  and the Render environment declaration now includes the existing GSPAY
  variables. Neither change configures an AI provider or a payment secret.
- Release validation is 199/199 Portal tests, TypeScript pass, affected-file
  lint pass, Render DB 3/3 and production build pass. No real order, callback,
  payout, game transfer or wallet movement was created by this validation.
- Runtime commit `6b432399eabf09b22e6a309e4a547c700515cfbc`, bundle
  SHA-256 `2af1922f4018a4213e38fad7d5ab101188a183dbdd605f530d017e1ee70b4026`
  and Render deploy `dep-dbmr15s9v7es73ahfaf0` are live. Post-deploy health
  returns `.65` with the database ready; every real-payment/new-order switch
  remains off. `.64` remains the recorded rollback release.

## Full game audit and trusted control coverage — 6 November 2026

Release: `17.0.0-selfbuilt.64-game-controls`.

- The live catalogue audit found 766 unique games with complete names, codes
  and image URLs. MegaH5, JILI, 918KISS H5 and Rectangle returned current
  catalogues. EVO888H5 retained a stale maintenance cache; EPICWIN, Venus,
  ClotPlay and GodeeZone returned no current catalogue.
- Rectangle and GodeeZone now use the same fixed trusted provider allowlist as
  the seven gateway catalogues for per-game status and artwork controls.
  Unknown provider IDs remain rejected.
- MegaH5 is the only supplier with a launch and transfer-wallet adapter. The
  gateway transfer and transfer-status configuration switches are persistent;
  the Portal switch is controlled separately. Other suppliers remain catalogue
  entries until their launch and wallet contracts are implemented.
- Catalogue connection is not recorded as production launch, wallet, exit or
  settlement acceptance. Those checks require an approved member session and
  one controlled end-to-end provider transaction.
- Portal deploy `dep-dbmqj56tlv9c73bo3u6g` and gateway code deploy
  `dep-dbmqqqtg1s2s73d9msq0` (`7f65d6a`) are live. Portal and gateway MegaH5 transfer
  switches remain enabled in persistent Render environment configuration.
- Gateway `7f65d6a` adds a stable service User-Agent to EPICWIN and ClotPlay
  catalogue calls and stops caching HTTP-200 business rejections from EVO and
  MegaH5. Gateway regression is 85/85. Post-deploy production probes still
  show EVO `code 130`, EPICWIN/ClotPlay 403, Venus missing `X-Sign`/`X-Ts`,
  and GodeeZone `/token` Cloudflare 403. These remain supplier blockers.
- Suppliers must allow the complete Render Singapore outbound ranges
  `74.220.52.0/24` and `74.220.60.0/24`; a single observed egress address is
  not a stable allowlist contract.

## GSPAY contract and business-setup safety — 6 November 2026

Candidate release: `17.0.0-selfbuilt.63-gspay-contract`.

- The user confirmed that GSPAY must remain an integration target and supplied
  the official MYR Payment, Get Payment and callback contract. The Portal calls
  the pinned official GSPAY origin directly behind disabled channel and order
  switches; no live order is sent by automated verification.
- The MYR flow uses a two-decimal amount, MD5 contract signatures, a two-minute
  cashier URL, independent Get Payment verification, ten-minute no-callback
  expiry, and balanced once-only wallet posting. DuitNow, USDT and Payout remain
  outside this candidate and disabled.
- The configured payment callback is
  `https://www.master7.best/api/payment/gspay/callback`. This www host currently
  has no verified DNS. It must become a direct Render custom domain or a
  body-preserving reverse proxy before live use.
- The merchant Render egress IP is `74.220.52.132`. The supplier also supplied
  `52.221.96.227` as a server IP; its ownership/use must be confirmed before any
  optional source-IP enforcement. Authentication key, MD5 signature and an
  independent provider query remain mandatory.
- The last pasted Operator Authentication Key has only 31 hexadecimal
  characters. The exact 32-character value must be copied from the supplier
  backoffice before it is stored in Render. Secrets never enter source or docs.
- 1MPay contract mapping and exact lowercase `ok` callback ACK are implemented,
  while company-bank retry/image handling and benefit/advertising publication
  validation are hardened. Real bank, benefit and advertising content is not
  invented.
- Payment and game production switches remain off. Portal validation is 192/192
  tests, lint pass, Render DB 3/3 and production build pass. Commit, bundle
  checksum, deploy ID and live verification remain release-time evidence.

## Full-platform acceptance handover — 6 November 2026

Candidate release: `17.0.0-selfbuilt.59-full-platform-handover`.

- Added a canonical redirect from `/admin/admin` to `/admin`, preserving query
  parameters. This protects staff access when an external domain redirect
  appends `/admin` twice.
- Standardized financial and commission display timezone to `Asia/Kuching`
  (MYT, UTC+8).
- Added the received full-platform requirements baseline and the requested
  acceptance deliverables for F01–F28, games, payments, recovery and owner
  handover. The live deployment receipt is maintained in the repository after
  deployment.
- The game acceptance register contains 76 brand-directory records plus current
  integration-only providers. The payment register contains six stages for
  VPay, GSPAY and 1MPAY.
- The latest three-gateway handover is included. `PAYMENT_SOURCE_TRACE.md` maps
  each contract to its exact module, functions and offline tests: 1MPay
  deposit/order/query/callback behavior is implemented and tested, while
  GSPAY settlement remains fail-closed pending query and callback terms.
- Validation: 165/165 full tests, 3/3 Render database adapter tests and the
  Render production build passed.
- Payment ordering, wallet credit, game launch and game settlement remain
  fail-closed. This release does not move money, launch a production game,
  restore data into production or change provider credentials.

Release: `17.0.0-selfbuilt.58-payment-startup-guard`.

- VPay, GSPAY, 1MPAY and GSPAY+ now remain fail-closed during database startup.
  Legacy setup migrations can record configured programs but cannot turn a
  payment channel Active.
- A one-time acceptance guard snapshots the previous four channel rows, sets
  VPay and 1MPAY to Suspended, and sets GSPAY and GSPAY+ to Close. A later
  owner decision remains persistent because the guard is applied only once.
- The compact five-step payment checklist from `.57` remains unchanged.

Release: `17.0.0-selfbuilt.57-payment-checks`.

- The backoffice now shows one compact VPay / GSPAY / 1MPAY checklist with
  Connected, Order, Query, Callback and Wallet columns. Every result is a simple
  ✅ or ❌, with a slow cyan light on passed checks.
- The matrix reads each provider's real, secret-free status endpoint. It does
  not infer Wallet readiness from a configured credential or an Active display
  switch; Wallet requires verified settlement and live readiness.
- No money switch, callback settlement rule, member balance or provider
  credential is changed by this release.

Release: `17.0.0-selfbuilt.56-gspay-complete-program`.

- GSPAY MYR now has a complete, fail-closed portal program: member wallet entry,
  strict amount validation, idempotent order record, isolated gateway capability
  tokens, safe checkout redirect validation and backoffice deposit records.
- The integration gateway alone stores the supplier credential and calls the
  pinned supplier origin. The portal never stores or returns provider secrets.
- The previously cited supplier ticket does not belong to MASTER7 and has been
  removed from acceptance evidence. MASTER7's create success/failure envelope,
  query response wrapping, callback acknowledgement/retry rules and end-to-end
  wallet settlement are unconfirmed, so GSPAY orders, queries,
  callbacks and automatic wallet credit remain disabled.
- Backoffice Game checks now separates Connected, Catalog, Launch and Wallet
  into visible ✅/❌ columns. A cached catalogue can no longer be mistaken for a
  verified launch or wallet settlement.
- The 1MPAY supplier follow-up remains pending formal API, merchant activation,
  signed callback/query samples and end-to-end acceptance. Its money switch is
  unchanged and remains off.

Verification: 164 portal tests, 3 Render database tests, JavaScript syntax and
the Render production build pass locally. No real order, payment, payout, game
launch or wallet credit was created by this release.

Release: `17.0.0-selfbuilt.37-platform-advertising`.

- The member wallet now presents primary Deposit and Withdraw actions. Automated deposit choices are VPay, GSPAY and 1MPay; each remains gated by its independently verified production readiness.
- Company direct bank transfer is a separate flow. The owner manages receiving-bank details, members upload a receipt, staff receive a pending record and may approve or reject it. Approval posts a balanced, idempotent wallet ledger entry exactly once.
- Owner and staff can review company-bank requests and receipts. Only the owner can change the company receiving account. Exports include bank configuration and review metadata but exclude receipt image data.
- Manual receipt files accept only bounded PNG, JPEG or WebP data and are returned with private no-store and sandboxed response headers.
- Existing provider transaction records, daily reporting, member isolation, staff roles and wallet controls remain in place.
- All 12 test files passed, including API, authentication, migrations, game catalogues, 1MPay and startup readiness. The Render production build also passed.

Provider production readiness remains truthful: VPay is still reported by its gateway as UAT with payout disabled; GSPAY lacks the production operator authentication key and secret in the deployed gateway; 1MPay deposits are implemented, while automatic payout balance-routing requires the provider's documented balance/status contract and production acceptance. No production payment success is claimed by this release.

---

# Wallet deposit, withdrawal and company-bank handover — 5 November 2026

Release: `17.0.0-selfbuilt.36-supplier-controls`.

- The member wallet now presents primary Deposit and Withdraw actions. Automated deposit choices are VPay, GSPAY and 1MPay; each remains gated by its independently verified production readiness.
- Company direct bank transfer is a separate flow. The owner manages receiving-bank details, members upload a receipt, staff receive a pending record and may approve or reject it. Approval posts a balanced, idempotent wallet ledger entry exactly once.
- Owner and staff can review company-bank requests and receipts. Only the owner can change the company receiving account. Exports include bank configuration and review metadata but exclude receipt image data.
- Manual receipt files accept only bounded PNG, JPEG or WebP data and are returned with private no-store and sandboxed response headers.
- Existing provider transaction records, daily reporting, member isolation, staff roles and wallet controls remain in place.
- All 12 test files passed, including API, authentication, migrations, game catalogues, 1MPay and startup readiness. The Render production build also passed.

Provider production readiness remains truthful: VPay is still reported by its gateway as UAT with payout disabled; GSPAY lacks the production operator authentication key and secret in the deployed gateway; 1MPay deposits are implemented, while automatic payout balance-routing requires the provider's documented balance/status contract and production acceptance. No production payment success is claimed by this release.

---

# Wallet deposit, withdrawal and company-bank handover — 5 November 2026

Release: `17.0.0-selfbuilt.35-wallet-deposit-withdraw`.

- The member wallet now presents primary Deposit and Withdraw actions. Automated deposit choices are VPay, GSPAY and 1MPay; each remains gated by its independently verified production readiness.
- Company direct bank transfer is a separate flow. The owner manages receiving-bank details, members upload a receipt, staff receive a pending record and may approve or reject it. Approval posts a balanced, idempotent wallet ledger entry exactly once.
- Owner and staff can review company-bank requests and receipts. Only the owner can change the company receiving account. Exports include bank configuration and review metadata but exclude receipt image data.
- Manual receipt files accept only bounded PNG, JPEG or WebP data and are returned with private no-store and sandboxed response headers.
- Existing provider transaction records, daily reporting, member isolation, staff roles and wallet controls remain in place.
- Removed the per-title “Individual supplier game controls” panel and its sidebar entry at the owner’s request. Supplier synchronization, front-end catalogue display and game connection checks remain available.
- Each supplier card now has owner-controlled Active, Maintenance and Close states. The upload label specifies 800 × 600 px (4:3), JPG/PNG/WebP, maximum 350 KB. Closed suppliers are hidden from members and Maintenance suppliers remain visible but unavailable.
- Removed the separate 76-entry supplier brand directory from both member and backoffice pages. Platform advertising remains in the lobby advertisement manager with upload, display toggle, rotation and optional destination link.
- All 12 test files passed, including API, authentication, migrations, game catalogues, 1MPay and startup readiness. The Render production build also passed.

Provider production readiness remains truthful: VPay is still reported by its gateway as UAT with payout disabled; GSPAY lacks the production operator authentication key and secret in the deployed gateway; 1MPay deposits are implemented, while automatic payout balance-routing requires the provider's documented balance/status contract and production acceptance. No production payment success is claimed by this release.

---

# Read-only financial records update — 5 November 2026

Release: `17.0.0-selfbuilt.34-read-only-financial-records`.

- Member deposits and withdrawals remain initiated from the customer portal and linked to the member wallet by one platform order ID.
- The MASTER7 backoffice is a read-only record view for deposits and withdrawals. Owner/staff controls cannot manually credit a wallet or mark a withdrawal paid.
- Daily reporting now shows successful deposit member count, order count and MYR total, plus withdrawal member count, request count and MYR total in Malaysia time.
- Deposit rows include the member ID, selected provider, amount, status and timestamp. Withdrawal rows include the member, selected provider, bank, masked/account details for owner support, amount, status and timestamp.
- Wallet credits remain limited to independently verified provider callbacks/queries and balanced ledger entries. Provider backoffices remain the provider-side reconciliation source.
- All 128 regression checks and the Render production build passed.

---

# Additional catalogue and checkout response update — 5 November 2026

Release: `17.0.0-selfbuilt.33-additional-game-sync`.

- Added read-only catalogue adapters for the supplied Rectangle and godeezone1 protocols. Rectangle signs GET requests using the assigned API host, UTC date, empty-body SHA256 and documented hexadecimal HMAC. The other adapter obtains a server-side token, follows provider/game pagination and preserves provider-specific game IDs. No game launch, transfer or wager is invoked by these adapters.
- These two additional adapters issue requests from the portal application, separately from the existing integration gateway. Manufacturer allowlists must follow the actual requesting service; the gateway observation 74.220.52.132 cannot be substituted for the portal's observed IP or a full fixed range.
- A private authenticated loopback job refreshes persisted catalogues while the Node service is running. Refreshes are lease-controlled and only call documented catalogue GET endpoints. Public pages and reports never receive API keys or access tokens.
- VPay can validate partial creation replies by independently querying the order binding. Monetary JSON numbers must have exact two-decimal precision. Optional expiry metadata does not override the vendor cashier's expiry.
- 1MPay strictly parses bounded JSON bodies even if a provider labels JSON as text. HTML and malformed bodies remain rejected; cashier host and settlement verification remain enforced.
- Owner-only payment diagnostics persist controlled response codes, HTTP statuses and missing-field names. Raw provider bodies, credentials, bank details, signatures and checkout query strings are never recorded.
- Checkout UI retains the chosen VPay method and reuses the same request key while an attempt is pending. Credited records clear the completed attempt before the next deposit.
- 128 backend/authentication/cache/payment regression checks passed. Render TypeScript, production build, game checkmark browser and the payment idempotency browser passed after final UI corrections. All automated financial tests used simulated provider replies.

Live account operations performed by the owner's explicit request: one phone-verified test member registered and its login verified; the owner login ID/password was changed and verified. Credentials are held in separate private handover files and are not included here.

Production low-value checkout attempts were made for VPay and 1MPay, with no bank authentication or payment execution. Both initial attempts returned awaiting_confirmation without a cashier URL. No successful payment or wallet credit is claimed by these attempts. Fresh diagnostics/retests and independent settlement confirmation are still required before declaring these flows complete.

---

# Game synchronization update — 5 November 2026

Release: `17.0.0-selfbuilt.32-game-sync`.

- Added the previously omitted EVO888H5 catalogue and its 150 titles to the customer lobby and owner controls. Supplier identities and game IDs remain separate; current readable catalogues total 705 titles.
- Seven existing gateway catalogue routes now synchronize through a persisted five-minute cache. Database leases prevent repeated concurrent supplier calls. Temporary errors preserve the last successful catalogue and display maintenance; successful empty replies replace it.
- Added owner/staff checkmark table for all 37 current supplier entries, separately showing catalogue sync, verified launch and verified wallet. Unimplemented/unverified flows remain incomplete; adding catalogue records does not declare a game playable.
- Added a protected Sync now action and automatic refresh while an authenticated user views the lobby/backoffice. Customer pages contain no supplier API error details.
- EVO cover images are proxied from the pinned official image host, with bounds and a supplier fallback. Existing per-title owner artwork and state controls are preserved.
- This release creates only a catalogue cache and an EVO provider entry. It changes no member balance, payment order, game transfer or wager.
- Validation: 115 full regression checks, followed by 37 targeted backend/cache/authorization checks after final adjustments; Render type check, production bundle build and a 390px Chromium flow with actual read-only supplier recordings. Browser shows 705 titles, 150 separate EVO cards and 37 checkmark rows, and confirms no wallet/order mutation.

Known latest catalogue blockers after gateway deploy `dep-dbmqqqtg1s2s73d9msq0`: EVO returns HTTP 200 with business `code 130` for its IP allowlist; EPICWIN and CLOTPLAY remain upstream 403 from the production Render source; VENUS returns `Code: 0` without the documented `X-Sign`/`X-Ts`; GodeeZone is blocked by Cloudflare HTML 403 on the first `/token` request. They remain incomplete. Other suppliers without verified adapters are not represented as successfully connected.

---

# MASTER7 payment and registration handover — 5 November 2026

Release: `17.0.0-selfbuilt.31-1mpay-deposits`.
Deployment: Render ahbi, `master7-v17-staging`. The tracked `master7-v17-render-staging.tar.gz` is the deployed source. The unrelated standalone app at the repository root is not deployed by this service.

## Customer and owner entry

- Member: `https://www.master7.best` is the designated primary entry; its DNS/TLS is still pending. Until then, `https://master7.best` redirects to the deployed `/signin` page. Members sign in using ID and password. Malaysian SMS OTP is for registration only.
- Owner: `https://www.master7.site` currently redirects to `/admin`. Owner/staff use ID and password without SMS.
- Anchor uses its supplied non-token GET protocol over HTTPS, sender 66886. Credentials are configured only on the server. `smsOtpReady` confirms configuration, not successful delivery to every handset.
- This release does not reset an owner or member password and does not publish the separate staff/reward candidate. No account password is included in this document.

## VPay

- Deployed member checkout follows the backend enabled flag. The gateway and application order/callback tokens were paired; vendor credentials and query token were preserved.
- The member submits amount, method and payer name. Only the validated VPay cashier URL is shown.
- Signed vendor notifications are forwarded through the gateway; the application independently queries the provider before writing two balanced, idempotent ledger entries.
- `/payment/return` exists. Authenticated callback-configuration GET is read-only.
- The internal `uat` label remains in the existing adapter. It is not evidence that the supplier offers a sandbox. Actual bank payment and wallet settlement still require verification.

## 1MPay deposit integration

- Implements the supplied 1MPay API Specification 1.3 (23 June 2026), production API `https://api.1mpay.net`.
- Backend POST `/fundtransfer/json`: amount fixed to two decimals, unique refid, stable pseudonymous member customer, MYR, callback/return URLs and base64 of the raw SHA256 digest in the exact documented concatenation order.
- Callback: `https://master7-v17-staging.onrender.com/api/payment-callbacks/1mpay/payment`.
- Return: `https://master7-v17-staging.onrender.com/payment/return`.
- Callback token is validated, then GET `/transquery/{trxno}/{base64_token}` independently confirms the merchant, amount, reference, customer, provider transaction and token. The documented callback signature does not cover status, so callback status alone cannot credit a wallet.
- Initial failure/timeout can be followed by a later success, as required by the supplier. Duplicate notifications cannot add duplicate wallet credit. Failed database batches roll back. Inconsistent existing ledger entries are held for review.
- Member POST `/api/payments/1mpay/orders/query` reconciles only that member's own order. Closing a channel prevents new orders while outstanding signed payments can still settle.
- Health and payment-channel status now report configured deposit switches separately from settlement verification; enabling production checkout does not mark a bank payment verified.
- The existing member wallet and owner deposit list include both providers. Customer records display platform and provider reference numbers.
- The application talks directly to 1MPay. The separate game/payment gateway IP must not be substituted for this application's outbound IP. Private authenticated diagnostics reports an observed application IP; it does not guarantee a fixed IP or the full Render outbound range.
- `/payout` is not invoked by this integration. Provider bank/settlement settings were not changed. An unpaid checkout or API configuration is not proof of a completed bank deposit.

Server-only variables: ONE_MPAY_API_BASE_URL, ONE_MPAY_MERCHANT, ONE_MPAY_SECRET_KEY, ONE_MPAY_ORDERS_ENABLED, ONE_MPAY_CALLBACK_URL, ONE_MPAY_RETURN_URL, ONE_MPAY_DIAGNOSTICS_TOKEN. No secret values are in this archive.

## Financial schema and activation

PostgreSQL migration 0017 widens only the existing deposit provider constraint; it deletes no orders or ledger entries. The SQLite migration preserves and checks both tables with foreign-key enforcement enabled. The one-time 0018 startup activation opens 1MPay only when its server configuration is present. It does not reopen a channel that the owner closes after activation. Migration and state snapshot are committed atomically with startup initialization.

Deployment rollback does not reverse a database migration. The added provider constraint is backward compatible with existing VPay rows; do not restore the old VPay-only constraint after 1MPay orders exist.

## Verification and remaining limits

- 105 Node/SQLite/backend/auth/UI checks passed.
- Real Chromium at 390px tested VPay and 1MPay with simulated low-value provider responses: checkout visibility, method selection, stable duplicate request key, order references, independent query credit, return page, disabled channels and no mobile overflow.
- Render-specific TypeScript check (`tsconfig.render.json`, ES2022 for the deployed Node runtime) and production bundle build passed. Financial tests contacted no external provider and moved no money.
- GSPAY/GSPAY+ are still closed. Recent Google Authenticator attempts were rejected; no further stale code is submitted. Exact create-order response and callback acknowledgement rules plus merchant API configuration remain unresolved. Backoffice login or a supplier screenshot must not be marked as live wallet settlement.
- Games remain catalogue-only; actual launch, transfer/seamless debit and credit, turnover settlement and automated benefits are not made operational by this payment release. Consult the individual game API report for supplier errors.
