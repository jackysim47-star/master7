INSERT INTO payment_channel_controls(provider_id,provider_name,status,updated_by,updated_at)
VALUES ('gspay_usdt','GSPAY+ USDT','closed','system',0)
ON CONFLICT(provider_id) DO NOTHING;
