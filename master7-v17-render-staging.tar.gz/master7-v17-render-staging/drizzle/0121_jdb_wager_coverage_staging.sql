CREATE TABLE IF NOT EXISTS jdb_wager_sync_windows (
  window_id TEXT PRIMARY KEY NOT NULL,
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  time_basis TEXT NOT NULL CHECK (time_basis IN ('lastModifyTime','gameDate')),
  window_start_ms BIGINT NOT NULL CHECK (window_start_ms >= 0),
  window_end_ms BIGINT NOT NULL CHECK (window_end_ms > window_start_ms),
  state TEXT NOT NULL DEFAULT 'idle' CHECK (state IN ('idle','syncing','review')),
  current_fence BIGINT NOT NULL DEFAULT 0 CHECK (current_fence >= 0),
  last_receipt_id TEXT,
  last_error_code TEXT,
  created_at BIGINT NOT NULL CHECK (created_at >= 0),
  updated_at BIGINT NOT NULL CHECK (updated_at >= created_at),
  CHECK ((time_basis='lastModifyTime' AND window_end_ms-window_start_ms <= 900000) OR (time_basis='gameDate' AND window_end_ms-window_start_ms <= 300000)),
  UNIQUE (profile_id,time_basis,window_start_ms,window_end_ms),
  UNIQUE (window_id,profile_id)
);

CREATE INDEX IF NOT EXISTS jdb_wager_sync_windows_range
  ON jdb_wager_sync_windows(profile_id,time_basis,window_start_ms,window_end_ms);

CREATE TABLE IF NOT EXISTS jdb_wager_receipts (
  id TEXT PRIMARY KEY NOT NULL,
  window_id TEXT NOT NULL REFERENCES jdb_wager_sync_windows(window_id),
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  fence BIGINT NOT NULL CHECK (fence > 0),
  claim_token_sha256 TEXT NOT NULL CHECK (length(claim_token_sha256) = 64),
  page_sha256 TEXT NOT NULL CHECK (length(page_sha256) = 64),
  input_count INTEGER NOT NULL DEFAULT 0 CHECK (input_count >= 0),
  unique_input_count INTEGER NOT NULL DEFAULT 0 CHECK (unique_input_count >= 0 AND unique_input_count <= input_count),
  original_count INTEGER NOT NULL DEFAULT 0 CHECK (original_count >= 0),
  duplicate_count INTEGER NOT NULL DEFAULT 0 CHECK (duplicate_count >= 0),
  late_count INTEGER NOT NULL DEFAULT 0 CHECK (late_count >= 0),
  revision_count INTEGER NOT NULL DEFAULT 0 CHECK (revision_count >= 0),
  reversal_candidate_count INTEGER NOT NULL DEFAULT 0 CHECK (reversal_candidate_count >= 0),
  page_complete INTEGER NOT NULL DEFAULT 0 CHECK (page_complete = 0),
  source_finality_verified INTEGER NOT NULL DEFAULT 0 CHECK (source_finality_verified = 0),
  session_closure_verified INTEGER NOT NULL DEFAULT 0 CHECK (session_closure_verified = 0),
  merchant_authorization_verified INTEGER NOT NULL DEFAULT 0 CHECK (merchant_authorization_verified = 0),
  coverage_complete INTEGER NOT NULL DEFAULT 0 CHECK (coverage_complete = 0),
  status TEXT NOT NULL DEFAULT 'review' CHECK (status = 'review'),
  observed_at BIGINT NOT NULL CHECK (observed_at >= 0),
  FOREIGN KEY (window_id,profile_id) REFERENCES jdb_wager_sync_windows(window_id,profile_id),
  UNIQUE (window_id,fence),
  UNIQUE (window_id,page_sha256)
);

CREATE INDEX IF NOT EXISTS jdb_wager_receipts_window
  ON jdb_wager_receipts(window_id,observed_at,id);

CREATE TABLE IF NOT EXISTS jdb_wager_identities (
  identity_sha256 TEXT PRIMARY KEY NOT NULL CHECK (length(identity_sha256) = 64),
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  first_payload_sha256 TEXT NOT NULL CHECK (length(first_payload_sha256) = 64),
  first_receipt_id TEXT NOT NULL REFERENCES jdb_wager_receipts(id),
  first_observed_at BIGINT NOT NULL CHECK (first_observed_at >= 0),
  UNIQUE (identity_sha256,profile_id)
);

CREATE TABLE IF NOT EXISTS jdb_wager_event_versions (
  identity_sha256 TEXT NOT NULL,
  payload_sha256 TEXT NOT NULL CHECK (length(payload_sha256) = 64),
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  provider_round_sha256 TEXT CHECK (provider_round_sha256 IS NULL OR length(provider_round_sha256) = 64),
  provider_player_sha256 TEXT NOT NULL CHECK (length(provider_player_sha256) = 64),
  provider_game_sha256 TEXT NOT NULL CHECK (length(provider_game_sha256) = 64),
  bet_minor BIGINT NOT NULL CHECK (bet_minor >= 0),
  win_minor BIGINT NOT NULL CHECK (win_minor >= 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  settled_at_ms BIGINT NOT NULL CHECK (settled_at_ms >= 0),
  source_details_sha256 TEXT NOT NULL CHECK (length(source_details_sha256) = 64),
  classification TEXT NOT NULL CHECK (classification IN ('original','late','revision','reversal_candidate')),
  first_receipt_id TEXT NOT NULL REFERENCES jdb_wager_receipts(id),
  first_observed_at BIGINT NOT NULL CHECK (first_observed_at >= 0),
  PRIMARY KEY (identity_sha256,payload_sha256),
  FOREIGN KEY (identity_sha256,profile_id) REFERENCES jdb_wager_identities(identity_sha256,profile_id)
);

CREATE INDEX IF NOT EXISTS jdb_wager_event_versions_observed
  ON jdb_wager_event_versions(profile_id,classification,first_observed_at,identity_sha256,payload_sha256);

CREATE TABLE IF NOT EXISTS jdb_wager_observations (
  receipt_id TEXT NOT NULL REFERENCES jdb_wager_receipts(id),
  identity_sha256 TEXT NOT NULL,
  payload_sha256 TEXT NOT NULL,
  classification TEXT NOT NULL CHECK (classification IN ('original','duplicate','late','revision','reversal_candidate')),
  occurrence_count INTEGER NOT NULL DEFAULT 1 CHECK (occurrence_count > 0),
  PRIMARY KEY (receipt_id,identity_sha256,payload_sha256),
  FOREIGN KEY (identity_sha256,payload_sha256)
    REFERENCES jdb_wager_event_versions(identity_sha256,payload_sha256)
);

CREATE INDEX IF NOT EXISTS jdb_wager_observations_receipt
  ON jdb_wager_observations(receipt_id,classification,identity_sha256,payload_sha256);
