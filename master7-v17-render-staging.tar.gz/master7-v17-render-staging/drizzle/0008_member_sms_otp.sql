CREATE TABLE IF NOT EXISTS otp_challenges (
  id TEXT PRIMARY KEY NOT NULL,
  phone TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  consumed_at INTEGER
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS otp_challenges_phone_created ON otp_challenges(phone, created_at DESC);
