CREATE TABLE IF NOT EXISTS game_wallet_sessions (
 id TEXT PRIMARY KEY NOT NULL,
 user_id TEXT NOT NULL REFERENCES users(id),
 provider TEXT NOT NULL DEFAULT 'megah5' CHECK (provider='megah5'),
 player_id TEXT NOT NULL,
 game_code TEXT NOT NULL,
 status TEXT NOT NULL CHECK (status IN ('deposit_pending','deposit_unknown','deposit_failed','active','withdraw_pending','withdraw_unknown','settled','manual_review')),
 amount_out_minor BIGINT NOT NULL CHECK (amount_out_minor>0),
 amount_returned_minor BIGINT,
 expected_return_minor BIGINT,
 deposit_reference TEXT NOT NULL UNIQUE,
 withdraw_reference TEXT UNIQUE,
 provider_residual TEXT NOT NULL DEFAULT '',
 last_error TEXT NOT NULL DEFAULT '',
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL,
 settled_at BIGINT
);
CREATE UNIQUE INDEX IF NOT EXISTS game_wallet_one_open_session ON game_wallet_sessions(user_id,provider)
 WHERE status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review');
CREATE INDEX IF NOT EXISTS game_wallet_sessions_updated ON game_wallet_sessions(updated_at DESC,id DESC);

CREATE TABLE IF NOT EXISTS game_wallet_ledger (
 id TEXT PRIMARY KEY NOT NULL,
 session_id TEXT NOT NULL UNIQUE REFERENCES game_wallet_sessions(id),
 user_id TEXT NOT NULL REFERENCES users(id),
 account_code TEXT NOT NULL DEFAULT 'game_result' CHECK (account_code='game_result'),
 amount_minor BIGINT NOT NULL,
 currency TEXT NOT NULL DEFAULT 'MYR' CHECK (currency='MYR'),
 created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS game_wallet_ledger_user_created ON game_wallet_ledger(user_id,created_at DESC);
