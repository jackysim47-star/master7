CREATE TABLE IF NOT EXISTS marketing_contacts (
  id TEXT PRIMARY KEY NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL DEFAULT '',
  consent_status TEXT NOT NULL DEFAULT 'unknown' CHECK (consent_status IN ('opted_in','unknown','opted_out')),
  source TEXT NOT NULL DEFAULT 'csv',
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS marketing_contacts_consent ON marketing_contacts(consent_status,created_at DESC);

CREATE TABLE IF NOT EXISTS marketing_campaigns (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('whatsapp','sms','share')),
  message TEXT NOT NULL,
  image_data TEXT NOT NULL DEFAULT '',
  benefit_text TEXT NOT NULL DEFAULT '',
  referral_code TEXT REFERENCES referral_codes(code),
  retention_goal INTEGER NOT NULL DEFAULT 18000,
  send_rate_per_minute INTEGER NOT NULL DEFAULT 30,
  scheduled_at BIGINT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','ready','blocked','sending','paused','completed')),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS marketing_campaigns_updated ON marketing_campaigns(updated_at DESC);

CREATE TABLE IF NOT EXISTS marketing_deliveries (
  campaign_id TEXT NOT NULL REFERENCES marketing_campaigns(id),
  contact_id TEXT NOT NULL REFERENCES marketing_contacts(id),
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','delivered','failed','opted_out')),
  provider_message_id TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (campaign_id,contact_id)
);
CREATE INDEX IF NOT EXISTS marketing_deliveries_status ON marketing_deliveries(campaign_id,status,updated_at);
