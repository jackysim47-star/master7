-- MASTER7 Rewards Hub points are deliberately non-cash. The only live issuer
-- in this release is the idempotent MYT daily check-in flow. Mission and
-- coupon rewards remain eligibility previews until separately accepted.
CREATE TABLE IF NOT EXISTS rewards_checkins (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  myt_day BIGINT NOT NULL,
  cycle_day INTEGER NOT NULL CHECK (cycle_day BETWEEN 1 AND 7),
  streak INTEGER NOT NULL CHECK (streak > 0),
  points INTEGER NOT NULL DEFAULT 0 CHECK (points >= 0),
  created_at BIGINT NOT NULL,
  UNIQUE(user_id,myt_day)
);
CREATE INDEX IF NOT EXISTS rewards_checkins_user_day
  ON rewards_checkins(user_id,myt_day DESC);

CREATE TABLE IF NOT EXISTS rewards_points_ledger (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL CHECK (source_type IN ('checkin','mission','milestone')),
  source_id TEXT NOT NULL,
  points INTEGER NOT NULL CHECK (points > 0),
  status TEXT NOT NULL DEFAULT 'earned' CHECK (status='earned'),
  cash_value_status TEXT NOT NULL DEFAULT 'none' CHECK (cash_value_status='none'),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status='disabled'),
  redemption_status TEXT NOT NULL DEFAULT 'disabled' CHECK (redemption_status='disabled'),
  created_at BIGINT NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS rewards_points_user_created
  ON rewards_points_ledger(user_id,created_at DESC,id DESC);
