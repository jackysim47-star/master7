-- Keep benefit eligibility decisions separate from financial settlement.
-- Approval never credits a wallet or marks turnover complete.
ALTER TABLE benefit_claims ADD COLUMN review_status TEXT NOT NULL DEFAULT 'pending'
  CHECK (review_status IN ('pending','approved_pending_settlement','rejected'));
ALTER TABLE benefit_claims ADD COLUMN reviewed_by TEXT REFERENCES users(id);
ALTER TABLE benefit_claims ADD COLUMN reviewed_at BIGINT;
ALTER TABLE benefit_claims ADD COLUMN review_note TEXT NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS benefit_claims_review_queue
  ON benefit_claims(review_status,created_at DESC);
