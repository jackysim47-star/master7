CREATE TABLE IF NOT EXISTS voucher_manual_reviews (
  claim_id TEXT PRIMARY KEY NOT NULL REFERENCES benefit_claims(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('approved','closed_no_win','turnover_review','eligible_for_payout','paid','rejected')),
  max_plays INTEGER NOT NULL CHECK (max_plays BETWEEN 1 AND 100),
  plays_used INTEGER NOT NULL DEFAULT 0 CHECK (plays_used >= 0 AND plays_used <= max_plays),
  won_once INTEGER NOT NULL DEFAULT 0 CHECK (won_once IN (0,1)),
  provider_credit_reference TEXT NOT NULL DEFAULT '',
  turnover_required_minor INTEGER NOT NULL CHECK (turnover_required_minor >= 0),
  turnover_verified_minor INTEGER NOT NULL DEFAULT 0 CHECK (turnover_verified_minor >= 0),
  turnover_evidence_reference TEXT NOT NULL DEFAULT '',
  payout_cap_minor INTEGER NOT NULL CHECK (payout_cap_minor > 0),
  payout_minor INTEGER NOT NULL DEFAULT 0 CHECK (payout_minor >= 0 AND payout_minor <= payout_cap_minor),
  payout_reference TEXT NOT NULL DEFAULT '',
  approved_by TEXT REFERENCES users(id),
  approved_at INTEGER,
  paid_by TEXT REFERENCES users(id),
  paid_at INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS voucher_manual_reviews_status ON voucher_manual_reviews(status,updated_at DESC);

CREATE TABLE IF NOT EXISTS voucher_manual_play_events (
  id TEXT PRIMARY KEY NOT NULL,
  claim_id TEXT NOT NULL REFERENCES voucher_manual_reviews(claim_id) ON DELETE CASCADE,
  play_number INTEGER NOT NULL CHECK (play_number BETWEEN 1 AND 100),
  outcome TEXT NOT NULL CHECK (outcome IN ('win','loss')),
  evidence_reference TEXT NOT NULL,
  recorded_by TEXT NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL,
  UNIQUE(claim_id,play_number)
);

CREATE INDEX IF NOT EXISTS voucher_manual_play_events_claim ON voucher_manual_play_events(claim_id,play_number);
