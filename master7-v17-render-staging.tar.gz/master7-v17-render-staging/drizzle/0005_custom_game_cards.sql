CREATE TABLE IF NOT EXISTS custom_game_cards (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  game_code TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  image_data TEXT NOT NULL,
  is_platform_mini INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS custom_game_cards_order ON custom_game_cards(enabled, is_platform_mini, provider_name, position);
