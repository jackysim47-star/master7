-- Acceptance evidence is authoritative safety data.  Event rows are append-only
-- and the current projection may only move to the next, latest revision.

CREATE TRIGGER IF NOT EXISTS game_provider_acceptance_events_no_update
BEFORE UPDATE ON game_provider_acceptance_events
BEGIN
  SELECT RAISE(ABORT,'game provider acceptance history is immutable');
END;

CREATE TRIGGER IF NOT EXISTS game_provider_acceptance_events_contiguous_insert
BEFORE INSERT ON game_provider_acceptance_events
WHEN NEW.revision<>COALESCE((
  SELECT MAX(previous.revision) FROM game_provider_acceptance_events previous
  WHERE previous.profile_id=NEW.profile_id AND previous.capability=NEW.capability
    AND previous.environment=NEW.environment
),0)+1
BEGIN
  SELECT RAISE(ABORT,'game provider acceptance history revisions must be contiguous');
END;

CREATE TRIGGER IF NOT EXISTS game_provider_acceptance_events_no_delete
BEFORE DELETE ON game_provider_acceptance_events
BEGIN
  SELECT RAISE(ABORT,'game provider acceptance history is immutable');
END;

CREATE TRIGGER IF NOT EXISTS production_acceptance_events_no_update
BEFORE UPDATE ON production_acceptance_events
BEGIN
  SELECT RAISE(ABORT,'production acceptance history is immutable');
END;

CREATE TRIGGER IF NOT EXISTS production_acceptance_events_contiguous_insert
BEFORE INSERT ON production_acceptance_events
WHEN NEW.revision<>COALESCE((
  SELECT MAX(previous.revision) FROM production_acceptance_events previous
  WHERE previous.category=NEW.category AND previous.subject_id=NEW.subject_id
    AND previous.capability=NEW.capability AND previous.environment=NEW.environment
),0)+1
BEGIN
  SELECT RAISE(ABORT,'production acceptance history revisions must be contiguous');
END;

CREATE TRIGGER IF NOT EXISTS production_acceptance_events_no_delete
BEFORE DELETE ON production_acceptance_events
BEGIN
  SELECT RAISE(ABORT,'production acceptance history is immutable');
END;

CREATE TRIGGER IF NOT EXISTS game_provider_acceptance_current_insert_latest
BEFORE INSERT ON game_provider_acceptance_current
WHEN NOT EXISTS (
  SELECT 1 FROM game_provider_acceptance_events e
  WHERE e.id=NEW.event_id AND e.profile_id=NEW.profile_id
    AND e.capability=NEW.capability AND e.environment=NEW.environment
    AND e.revision=(
      SELECT MAX(latest.revision) FROM game_provider_acceptance_events latest
      WHERE latest.profile_id=NEW.profile_id AND latest.capability=NEW.capability
        AND latest.environment=NEW.environment
    )
    AND (SELECT MIN(history.revision) FROM game_provider_acceptance_events history
      WHERE history.profile_id=NEW.profile_id AND history.capability=NEW.capability AND history.environment=NEW.environment)=1
    AND (SELECT COUNT(*) FROM game_provider_acceptance_events history
      WHERE history.profile_id=NEW.profile_id AND history.capability=NEW.capability AND history.environment=NEW.environment)=e.revision
)
BEGIN
  SELECT RAISE(ABORT,'game provider acceptance projection must reference the latest revision');
END;

CREATE TRIGGER IF NOT EXISTS game_provider_acceptance_current_update_next
BEFORE UPDATE ON game_provider_acceptance_current
WHEN NEW.profile_id<>OLD.profile_id OR NEW.capability<>OLD.capability OR NEW.environment<>OLD.environment OR NOT EXISTS (
  SELECT 1 FROM game_provider_acceptance_events next
  JOIN game_provider_acceptance_events previous ON previous.id=OLD.event_id
  WHERE next.id=NEW.event_id AND next.profile_id=OLD.profile_id
    AND next.capability=OLD.capability AND next.environment=OLD.environment
    AND next.revision=previous.revision+1
    AND next.revision=(
      SELECT MAX(latest.revision) FROM game_provider_acceptance_events latest
      WHERE latest.profile_id=OLD.profile_id AND latest.capability=OLD.capability
        AND latest.environment=OLD.environment
    )
    AND (SELECT MIN(history.revision) FROM game_provider_acceptance_events history
      WHERE history.profile_id=OLD.profile_id AND history.capability=OLD.capability AND history.environment=OLD.environment)=1
    AND (SELECT COUNT(*) FROM game_provider_acceptance_events history
      WHERE history.profile_id=OLD.profile_id AND history.capability=OLD.capability AND history.environment=OLD.environment)=next.revision
)
BEGIN
  SELECT RAISE(ABORT,'game provider acceptance projection must advance exactly one revision');
END;

CREATE TRIGGER IF NOT EXISTS game_provider_acceptance_current_no_delete
BEFORE DELETE ON game_provider_acceptance_current
BEGIN
  SELECT RAISE(ABORT,'game provider acceptance projection cannot be deleted');
END;

CREATE TRIGGER IF NOT EXISTS production_acceptance_current_insert_latest
BEFORE INSERT ON production_acceptance_current
WHEN NOT EXISTS (
  SELECT 1 FROM production_acceptance_events e
  WHERE e.id=NEW.event_id AND e.category=NEW.category AND e.subject_id=NEW.subject_id
    AND e.capability=NEW.capability AND e.environment=NEW.environment
    AND e.revision=(
      SELECT MAX(latest.revision) FROM production_acceptance_events latest
      WHERE latest.category=NEW.category AND latest.subject_id=NEW.subject_id
        AND latest.capability=NEW.capability AND latest.environment=NEW.environment
    )
    AND (SELECT MIN(history.revision) FROM production_acceptance_events history
      WHERE history.category=NEW.category AND history.subject_id=NEW.subject_id
        AND history.capability=NEW.capability AND history.environment=NEW.environment)=1
    AND (SELECT COUNT(*) FROM production_acceptance_events history
      WHERE history.category=NEW.category AND history.subject_id=NEW.subject_id
        AND history.capability=NEW.capability AND history.environment=NEW.environment)=e.revision
)
BEGIN
  SELECT RAISE(ABORT,'production acceptance projection must reference the latest revision');
END;

CREATE TRIGGER IF NOT EXISTS production_acceptance_current_update_next
BEFORE UPDATE ON production_acceptance_current
WHEN NEW.category<>OLD.category OR NEW.subject_id<>OLD.subject_id OR NEW.capability<>OLD.capability OR NEW.environment<>OLD.environment OR NOT EXISTS (
  SELECT 1 FROM production_acceptance_events next
  JOIN production_acceptance_events previous ON previous.id=OLD.event_id
  WHERE next.id=NEW.event_id AND next.category=OLD.category AND next.subject_id=OLD.subject_id
    AND next.capability=OLD.capability AND next.environment=OLD.environment
    AND next.revision=previous.revision+1
    AND next.revision=(
      SELECT MAX(latest.revision) FROM production_acceptance_events latest
      WHERE latest.category=OLD.category AND latest.subject_id=OLD.subject_id
        AND latest.capability=OLD.capability AND latest.environment=OLD.environment
    )
    AND (SELECT MIN(history.revision) FROM production_acceptance_events history
      WHERE history.category=OLD.category AND history.subject_id=OLD.subject_id
        AND history.capability=OLD.capability AND history.environment=OLD.environment)=1
    AND (SELECT COUNT(*) FROM production_acceptance_events history
      WHERE history.category=OLD.category AND history.subject_id=OLD.subject_id
        AND history.capability=OLD.capability AND history.environment=OLD.environment)=next.revision
)
BEGIN
  SELECT RAISE(ABORT,'production acceptance projection must advance exactly one revision');
END;

CREATE TRIGGER IF NOT EXISTS production_acceptance_current_no_delete
BEFORE DELETE ON production_acceptance_current
BEGIN
  SELECT RAISE(ABORT,'production acceptance projection cannot be deleted');
END;
