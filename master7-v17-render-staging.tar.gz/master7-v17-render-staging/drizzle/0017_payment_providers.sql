-- Standalone SQLite migration. Keeps FK enforcement and every financial row.
BEGIN;
CREATE TABLE deposit_orders_expanded (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  provider TEXT NOT NULL CHECK (provider IN ('vpay','1mpay','gspay')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  trade_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','creating','created','unknown','credited','review','failed')),
  provider_trade_no TEXT,
  checkout_url TEXT,
  expires_at_raw TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key),
  UNIQUE(provider, provider_trade_no)
);

INSERT INTO deposit_orders_expanded SELECT * FROM deposit_orders;
CREATE TABLE wallet_ledger_expanded (
  id TEXT PRIMARY KEY NOT NULL,
  order_id TEXT NOT NULL REFERENCES deposit_orders_expanded(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  account_code TEXT NOT NULL CHECK (account_code IN ('member','provider_clearing')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor <> 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  created_at BIGINT NOT NULL,
  UNIQUE(order_id, account_code)
);
INSERT INTO wallet_ledger_expanded SELECT * FROM wallet_ledger;
DROP TABLE wallet_ledger;
DROP TABLE deposit_orders;
ALTER TABLE deposit_orders_expanded RENAME TO deposit_orders;
ALTER TABLE wallet_ledger_expanded RENAME TO wallet_ledger;
CREATE INDEX deposit_orders_user_created ON deposit_orders(user_id,created_at DESC);
CREATE INDEX deposit_orders_status_created ON deposit_orders(status,created_at);
CREATE INDEX wallet_ledger_user_created ON wallet_ledger(user_id,created_at DESC);
COMMIT;
