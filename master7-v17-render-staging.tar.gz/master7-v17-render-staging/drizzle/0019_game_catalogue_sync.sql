CREATE TABLE IF NOT EXISTS game_catalogue_cache (
 provider_id TEXT PRIMARY KEY NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('available','empty','blocked','unavailable')),
 games_json TEXT NOT NULL DEFAULT '[]',
 checked_at BIGINT NOT NULL DEFAULT 0,
 last_success_at BIGINT NOT NULL DEFAULT 0,
 lease_until BIGINT NOT NULL DEFAULT 0,
 upstream_status INTEGER,
 complete INTEGER NOT NULL DEFAULT 0 CHECK(complete IN (0,1))
);
INSERT OR IGNORE INTO providers(id,name,category,symbol,visible) VALUES('evo888h5','EVO888H5','supplier','EVO',1);
