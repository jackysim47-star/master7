-- Append-only production/UAT acceptance evidence for each registered game
-- provider profile.  Absence of a current row means not accepted.
CREATE TABLE IF NOT EXISTS game_provider_acceptance_events (
  id TEXT PRIMARY KEY NOT NULL,
  profile_id TEXT NOT NULL,
  revision INTEGER NOT NULL CHECK (revision > 0),
  capability TEXT NOT NULL CHECK (capability IN ('catalogue','launch','wallet','settlement','recovery')),
  environment TEXT NOT NULL CHECK (environment IN ('uat','production')),
  result TEXT NOT NULL CHECK (result IN ('passed','failed','revoked')),
  evidence_sha256 TEXT NOT NULL CHECK (length(evidence_sha256) = 64),
  evidence_reference TEXT NOT NULL CHECK (length(evidence_reference) BETWEEN 1 AND 200),
  verified_by TEXT NOT NULL REFERENCES users(id),
  observed_at BIGINT NOT NULL CHECK (observed_at >= 0),
  recorded_at BIGINT NOT NULL CHECK (recorded_at >= 0),
  UNIQUE(id,profile_id,capability,environment),
  UNIQUE(profile_id,capability,environment,revision)
);

CREATE INDEX IF NOT EXISTS game_provider_acceptance_events_profile
  ON game_provider_acceptance_events(profile_id,environment,capability,recorded_at DESC,id DESC);

-- This is only a projection of the append-only event stream.  Updating the
-- projection never erases the evidence event it supersedes.
CREATE TABLE IF NOT EXISTS game_provider_acceptance_current (
  profile_id TEXT NOT NULL,
  capability TEXT NOT NULL CHECK (capability IN ('catalogue','launch','wallet','settlement','recovery')),
  environment TEXT NOT NULL CHECK (environment IN ('uat','production')),
  event_id TEXT NOT NULL UNIQUE,
  PRIMARY KEY(profile_id,capability,environment),
  FOREIGN KEY(event_id,profile_id,capability,environment)
    REFERENCES game_provider_acceptance_events(id,profile_id,capability,environment)
);

CREATE INDEX IF NOT EXISTS game_provider_acceptance_current_environment
  ON game_provider_acceptance_current(environment,profile_id,capability);
