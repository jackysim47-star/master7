ALTER TABLE game_visibility
ADD COLUMN access_zone TEXT NOT NULL DEFAULT 'paid'
CHECK (access_zone IN ('free','paid'));
