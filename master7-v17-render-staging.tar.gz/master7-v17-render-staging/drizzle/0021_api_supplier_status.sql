ALTER TABLE api_supplier_artwork ADD COLUMN status TEXT NOT NULL DEFAULT 'active'
  CHECK (status IN ('active','suspended','closed'));
