-- Existing sessions retain their exact-amount protocol. New sweep sessions
-- snapshot the mode before a supplier deposit can be submitted.
ALTER TABLE provider_wallet_operations ADD COLUMN withdrawal_mode TEXT NOT NULL DEFAULT 'exact' CHECK(withdrawal_mode IN ('exact','all'));
ALTER TABLE provider_wallet_operations ADD COLUMN adapter_contract_sha256 TEXT NOT NULL DEFAULT '' CHECK(adapter_contract_sha256='' OR (length(adapter_contract_sha256)=64 AND adapter_contract_sha256 NOT GLOB '*[^a-f0-9]*'));
CREATE TRIGGER provider_wallet_contract_immutable BEFORE UPDATE OF withdrawal_mode,adapter_contract_sha256 ON provider_wallet_operations
 WHEN NEW.withdrawal_mode<>OLD.withdrawal_mode OR NEW.adapter_contract_sha256<>OLD.adapter_contract_sha256
 BEGIN SELECT RAISE(ABORT,'provider wallet contract is immutable'); END;
