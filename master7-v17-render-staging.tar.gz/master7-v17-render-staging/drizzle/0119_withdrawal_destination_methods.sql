ALTER TABLE withdrawal_requests ADD COLUMN destination_type TEXT NOT NULL DEFAULT 'bank' CHECK(destination_type IN ('bank','ewallet'));
ALTER TABLE withdrawal_requests ADD COLUMN ewallet_code TEXT;
ALTER TABLE withdrawal_requests ADD COLUMN ewallet_name TEXT;
ALTER TABLE withdrawal_requests ADD COLUMN ewallet_account_encrypted TEXT;
ALTER TABLE withdrawal_requests ADD COLUMN ewallet_account_last4 TEXT;
