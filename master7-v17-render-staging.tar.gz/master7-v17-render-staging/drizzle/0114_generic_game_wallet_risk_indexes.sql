CREATE INDEX IF NOT EXISTS game_provider_sessions_user_status ON game_provider_sessions(user_id,status,id);
CREATE INDEX IF NOT EXISTS game_wallet_transfers_user_status ON game_wallet_transfers(user_id,status,session_id);
CREATE INDEX IF NOT EXISTS game_transactions_user_status ON game_transactions(user_id,status,id);
