CREATE TABLE IF NOT EXISTS referral_codes (
  code TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id),
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS referral_relationships (
  member_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id),
  referrer_id TEXT NOT NULL REFERENCES users(id),
  code TEXT NOT NULL REFERENCES referral_codes(code),
  created_at INTEGER NOT NULL,
  CHECK (member_id <> referrer_id)
);
CREATE INDEX IF NOT EXISTS referral_relationships_referrer ON referral_relationships(referrer_id,created_at DESC);
