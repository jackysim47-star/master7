CREATE TABLE IF NOT EXISTS payment_recovery_leases (
  provider TEXT NOT NULL CHECK (provider IN ('vpay','gspay')),
  order_id TEXT NOT NULL REFERENCES deposit_orders(id) ON DELETE CASCADE,
  claim_token TEXT NOT NULL,
  locked_until BIGINT NOT NULL DEFAULT 0,
  last_checked_at BIGINT NOT NULL DEFAULT 0,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  PRIMARY KEY(provider,order_id)
);
CREATE INDEX IF NOT EXISTS payment_recovery_due ON payment_recovery_leases(provider,locked_until,last_checked_at);

CREATE TABLE IF NOT EXISTS provider_payout_controls (
  provider_id TEXT PRIMARY KEY NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay')),
  submission_enabled INTEGER NOT NULL DEFAULT 0 CHECK (submission_enabled=0 OR (provider_id='gspay' AND submission_enabled=1)),
  updated_at BIGINT NOT NULL DEFAULT 0
);
INSERT INTO provider_payout_controls(provider_id,submission_enabled,updated_at)
VALUES ('vpay',0,0),('gspay',0,0),('1mpay',0,0)
ON CONFLICT(provider_id) DO NOTHING;

CREATE TABLE IF NOT EXISTS provider_payouts (
  id TEXT PRIMARY KEY NOT NULL,
  withdrawal_id TEXT NOT NULL UNIQUE REFERENCES withdrawal_requests(id),
  provider_id TEXT NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay')),
  request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  status TEXT NOT NULL CHECK (status IN ('prepared','submitting','processing','succeeded','failed','reversed','review')),
  create_outcome TEXT NOT NULL DEFAULT 'not_submitted' CHECK (create_outcome IN ('not_submitted','in_flight','accepted','unknown','rejected')),
  provider_reference TEXT,
  last_event_hash TEXT,
  last_error_code TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  completed_at BIGINT,
  UNIQUE(provider_id,request_key),
  UNIQUE(provider_id,provider_reference)
);
CREATE INDEX IF NOT EXISTS provider_payout_status ON provider_payouts(provider_id,status,updated_at);
