-- Keep the provider's money_id separate from our existing out_money_id.
-- Historical payouts remain nullable until an authenticated callback binds it.
ALTER TABLE provider_payouts ADD COLUMN provider_money_id TEXT;
CREATE UNIQUE INDEX provider_payout_money_id ON provider_payouts(provider_id,provider_money_id)
 WHERE provider_money_id IS NOT NULL;
