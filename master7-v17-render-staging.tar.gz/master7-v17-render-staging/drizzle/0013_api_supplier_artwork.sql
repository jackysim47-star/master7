CREATE TABLE IF NOT EXISTS api_supplier_artwork (
  provider_id TEXT PRIMARY KEY,
  image_data TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY (updated_by) REFERENCES users(id)
);
