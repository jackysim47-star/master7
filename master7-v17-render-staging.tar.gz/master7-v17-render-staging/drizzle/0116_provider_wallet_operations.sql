PRAGMA foreign_keys=OFF;
BEGIN;
CREATE TABLE game_wallet_sessions_provider (
 id TEXT PRIMARY KEY NOT NULL,
 user_id TEXT NOT NULL REFERENCES users(id),
 provider TEXT NOT NULL DEFAULT 'megah5',
 profile_id TEXT REFERENCES game_provider_profiles(id) DEFERRABLE INITIALLY DEFERRED,
 player_id TEXT NOT NULL,
 game_code TEXT NOT NULL,
 status TEXT NOT NULL CHECK (status IN ('deposit_pending','deposit_unknown','deposit_failed','active','withdraw_pending','withdraw_unknown','settled','manual_review')),
 amount_out_minor BIGINT NOT NULL CHECK (amount_out_minor>0),
 amount_returned_minor BIGINT,
 expected_return_minor BIGINT,
 deposit_reference TEXT NOT NULL UNIQUE,
 withdraw_reference TEXT UNIQUE,
 provider_residual TEXT NOT NULL DEFAULT '',
 last_error TEXT NOT NULL DEFAULT '',
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL,
 settled_at BIGINT
);
INSERT INTO game_wallet_sessions_provider(id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,expected_return_minor,deposit_reference,withdraw_reference,provider_residual,last_error,created_at,updated_at,settled_at) SELECT id,user_id,provider,player_id,game_code,status,amount_out_minor,amount_returned_minor,expected_return_minor,deposit_reference,withdraw_reference,provider_residual,last_error,created_at,updated_at,settled_at FROM game_wallet_sessions;
DROP TABLE game_wallet_sessions;
ALTER TABLE game_wallet_sessions_provider RENAME TO game_wallet_sessions;
CREATE UNIQUE INDEX IF NOT EXISTS game_wallet_one_open_session ON game_wallet_sessions(user_id,provider)
 WHERE status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review');
CREATE INDEX IF NOT EXISTS game_wallet_sessions_updated ON game_wallet_sessions(updated_at DESC,id DESC);
CREATE UNIQUE INDEX IF NOT EXISTS game_wallet_session_identity ON game_wallet_sessions(id,user_id,game_code);

CREATE TABLE IF NOT EXISTS provider_wallet_operations (
 session_id TEXT PRIMARY KEY NOT NULL REFERENCES game_wallet_sessions(id),
 profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
 user_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL,
 request_fingerprint TEXT NOT NULL,
 deposit_state TEXT NOT NULL CHECK(deposit_state IN ('prepared','submitting','unknown','confirmed','rejected','review')),
 deposit_attempts INTEGER NOT NULL DEFAULT 0 CHECK(deposit_attempts BETWEEN 0 AND 1),
 deposit_provider_reference TEXT,
 withdrawal_state TEXT NOT NULL DEFAULT 'none' CHECK(withdrawal_state IN ('none','prepared','submitting','unknown','confirmed','rejected','review')),
 withdrawal_attempts INTEGER NOT NULL DEFAULT 0 CHECK(withdrawal_attempts BETWEEN 0 AND 1),
 withdrawal_provider_reference TEXT,
 launch_state TEXT NOT NULL DEFAULT 'prepared' CHECK(launch_state IN ('prepared','launching','issued','unknown','closed')),
 closure_state TEXT NOT NULL DEFAULT 'unknown' CHECK(closure_state IN ('unknown','confirmed')),
 closure_evidence TEXT NOT NULL DEFAULT '',
 zero_balance_verified INTEGER NOT NULL DEFAULT 0 CHECK(zero_balance_verified IN (0,1)),
 last_error_code TEXT NOT NULL DEFAULT '',
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL,
 UNIQUE(profile_id,request_key)
);
CREATE INDEX IF NOT EXISTS provider_wallet_operations_user ON provider_wallet_operations(user_id,profile_id,updated_at);
COMMIT;
PRAGMA foreign_keys=ON;
