PRAGMA foreign_keys=OFF;
BEGIN;
CREATE TABLE deposit_orders_manual_bank (
 id TEXT PRIMARY KEY NOT NULL,user_id TEXT NOT NULL REFERENCES users(id),request_key TEXT NOT NULL,fingerprint TEXT NOT NULL,
 provider TEXT NOT NULL CHECK(provider IN ('vpay','1mpay','gspay','manual_bank')),
 amount_minor BIGINT NOT NULL CHECK(amount_minor>0 AND amount_minor<=10000000),currency TEXT NOT NULL CHECK(currency='MYR'),trade_code TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('pending','creating','created','unknown','credited','review','failed')),provider_trade_no TEXT,checkout_url TEXT,expires_at_raw TEXT,
 created_at BIGINT NOT NULL,updated_at BIGINT NOT NULL,UNIQUE(user_id,request_key),UNIQUE(provider,provider_trade_no)
);
INSERT INTO deposit_orders_manual_bank SELECT * FROM deposit_orders;
CREATE TABLE wallet_ledger_manual_bank (
 id TEXT PRIMARY KEY NOT NULL,order_id TEXT NOT NULL REFERENCES deposit_orders_manual_bank(id),user_id TEXT NOT NULL REFERENCES users(id),
 account_code TEXT NOT NULL CHECK(account_code IN ('member','provider_clearing')),amount_minor BIGINT NOT NULL CHECK(amount_minor<>0),currency TEXT NOT NULL CHECK(currency='MYR'),created_at BIGINT NOT NULL,UNIQUE(order_id,account_code)
);
INSERT INTO wallet_ledger_manual_bank SELECT * FROM wallet_ledger;
DROP TABLE wallet_ledger;
DROP TABLE deposit_orders;
ALTER TABLE deposit_orders_manual_bank RENAME TO deposit_orders;
ALTER TABLE wallet_ledger_manual_bank RENAME TO wallet_ledger;
CREATE INDEX deposit_orders_user_created ON deposit_orders(user_id,created_at DESC);
CREATE INDEX deposit_orders_status_created ON deposit_orders(status,created_at);
CREATE INDEX wallet_ledger_user_created ON wallet_ledger(user_id,created_at DESC);
CREATE TABLE company_bank_accounts(id TEXT PRIMARY KEY NOT NULL,bank_name TEXT NOT NULL,account_name TEXT NOT NULL,account_number TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,position INTEGER NOT NULL DEFAULT 0,updated_by TEXT NOT NULL REFERENCES users(id),updated_at BIGINT NOT NULL);
CREATE TABLE manual_deposit_requests(deposit_order_id TEXT PRIMARY KEY NOT NULL REFERENCES deposit_orders(id),bank_account_id TEXT NOT NULL REFERENCES company_bank_accounts(id),receipt_data TEXT NOT NULL,reviewed_by TEXT REFERENCES users(id),created_at BIGINT NOT NULL,updated_at BIGINT NOT NULL);
CREATE INDEX manual_deposit_pending ON manual_deposit_requests(updated_at DESC);
COMMIT;
PRAGMA foreign_keys=ON;
