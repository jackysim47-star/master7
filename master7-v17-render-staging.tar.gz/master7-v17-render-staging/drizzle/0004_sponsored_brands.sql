INSERT INTO providers(id,name,category,symbol,visible) VALUES
 ('jili','JILI','supplier','JILI',1),
 ('megah5','MegaH5','supplier','MEGA H5',1),
 ('918kissh5','918KISS','supplier','918KISS',1)
ON CONFLICT(id) DO NOTHING;
