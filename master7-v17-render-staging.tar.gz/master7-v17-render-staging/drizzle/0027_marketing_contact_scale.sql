CREATE INDEX IF NOT EXISTS marketing_contacts_export
  ON marketing_contacts(consent_status,created_at,id);

INSERT INTO settings(id,value)
SELECT 'marketing_contact_count',CAST(COUNT(*) AS TEXT)
FROM marketing_contacts
WHERE 1=1
ON CONFLICT(id) DO NOTHING;

INSERT INTO settings(id,value)
VALUES('marketing_import_lock','0')
ON CONFLICT(id) DO NOTHING;
