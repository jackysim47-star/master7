ALTER TABLE game_visibility ADD COLUMN image_data TEXT NOT NULL DEFAULT '';
