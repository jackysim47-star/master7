-- Local preparation: identity and AML decisions are independent and manual.
-- Do not store identity documents, identity numbers or screening details here.
CREATE TABLE IF NOT EXISTS manual_compliance_reviews (
 user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id),
 identity_status TEXT NOT NULL DEFAULT 'pending' CHECK (identity_status IN ('pending','passed','failed')),
 aml_status TEXT NOT NULL DEFAULT 'pending' CHECK (aml_status IN ('pending','passed','failed')),
 version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
 last_change_id TEXT NOT NULL,
 last_authorization_id TEXT,
 created_at INTEGER NOT NULL,
 updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS manual_compliance_events (
 id TEXT PRIMARY KEY NOT NULL,
 user_id TEXT NOT NULL REFERENCES users(id),
 reviewer_id TEXT NOT NULL REFERENCES users(id),
 review_type TEXT NOT NULL CHECK (review_type IN ('identity','aml')),
 decision TEXT NOT NULL CHECK (decision IN ('passed','failed')),
 created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS manual_compliance_events_member ON manual_compliance_events(user_id,created_at,id);
