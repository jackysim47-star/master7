PRAGMA foreign_keys=OFF;
BEGIN;
CREATE TABLE withdrawal_requests_bank (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  provider_id TEXT NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay','gspay_plus','manual_bank')),
  provider_name TEXT NOT NULL,
  bank_code TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_holder_encrypted TEXT NOT NULL,
  account_number_encrypted TEXT NOT NULL,
  account_last4 TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  status TEXT NOT NULL CHECK (status IN ('pending','approved','processing','paid','rejected','cancelled')),
  owner_note TEXT NOT NULL DEFAULT '',
  updated_by TEXT REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key)
);
CREATE TABLE provider_payout_controls_bank (
  provider_id TEXT PRIMARY KEY NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay','manual_bank')),
  submission_enabled INTEGER NOT NULL DEFAULT 0 CHECK (submission_enabled=0 OR (provider_id IN ('gspay','manual_bank') AND submission_enabled=1)),
  updated_at BIGINT NOT NULL DEFAULT 0
);
CREATE TABLE provider_payouts_bank (
  id TEXT PRIMARY KEY NOT NULL,
  withdrawal_id TEXT NOT NULL UNIQUE REFERENCES withdrawal_requests(id),
  provider_id TEXT NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay','manual_bank')),
  request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  status TEXT NOT NULL CHECK (status IN ('prepared','submitting','processing','succeeded','failed','reversed','review')),
  create_outcome TEXT NOT NULL DEFAULT 'not_submitted' CHECK (create_outcome IN ('not_submitted','in_flight','accepted','unknown','rejected')),
  provider_reference TEXT,
  last_event_hash TEXT,
  last_error_code TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  completed_at BIGINT,
  UNIQUE(provider_id,request_key),
  UNIQUE(provider_id,provider_reference)
);
INSERT INTO withdrawal_requests_bank SELECT * FROM withdrawal_requests;
INSERT INTO provider_payout_controls_bank SELECT * FROM provider_payout_controls;
INSERT INTO provider_payouts_bank SELECT * FROM provider_payouts;
DROP TABLE provider_payouts;
DROP TABLE provider_payout_controls;
DROP TABLE withdrawal_requests;
ALTER TABLE withdrawal_requests_bank RENAME TO withdrawal_requests;
ALTER TABLE provider_payout_controls_bank RENAME TO provider_payout_controls;
ALTER TABLE provider_payouts_bank RENAME TO provider_payouts;
CREATE INDEX withdrawal_requests_user_created ON withdrawal_requests(user_id,created_at DESC);
CREATE INDEX withdrawal_requests_status_created ON withdrawal_requests(status,created_at DESC);
CREATE UNIQUE INDEX withdrawal_one_open_per_member ON withdrawal_requests(user_id) WHERE status IN ('pending','approved','processing');
CREATE INDEX provider_payout_status ON provider_payouts(provider_id,status,updated_at);
ALTER TABLE company_bank_accounts ADD COLUMN supersedes_id TEXT REFERENCES company_bank_accounts(id) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE provider_payouts ADD COLUMN manual_bank_account_id TEXT REFERENCES company_bank_accounts(id);
INSERT INTO provider_payout_controls(provider_id,submission_enabled,updated_at) VALUES('manual_bank',0,0);
CREATE TABLE IF NOT EXISTS manual_bank_transactions (
 id TEXT PRIMARY KEY NOT NULL,
 bank_account_id TEXT NOT NULL REFERENCES company_bank_accounts(id),
 bank_account_key TEXT NOT NULL CHECK(length(bank_account_key)=64),
 bank_reference TEXT NOT NULL CHECK(length(bank_reference) BETWEEN 4 AND 100),
 normalized_reference TEXT NOT NULL CHECK(length(normalized_reference) BETWEEN 4 AND 100),
 direction TEXT NOT NULL CHECK(direction IN ('deposit','withdrawal')),
 amount_minor BIGINT NOT NULL CHECK(amount_minor>0 AND amount_minor<=10000000),
 currency TEXT NOT NULL CHECK(currency='MYR'),
 deposit_order_id TEXT UNIQUE REFERENCES deposit_orders(id),
 payout_id TEXT UNIQUE REFERENCES provider_payouts(id),
 proof_data TEXT NOT NULL CHECK(length(proof_data)>0),
 proof_sha256 TEXT NOT NULL CHECK(length(proof_sha256)=64),
 bank_occurred_at BIGINT NOT NULL CHECK(bank_occurred_at>=1577836800),
 recorded_by TEXT NOT NULL REFERENCES users(id),
 recorded_at BIGINT NOT NULL,
 CHECK((direction='deposit' AND deposit_order_id IS NOT NULL AND payout_id IS NULL) OR
       (direction='withdrawal' AND payout_id IS NOT NULL AND deposit_order_id IS NULL)),
 UNIQUE(bank_account_key,normalized_reference)
);
CREATE INDEX IF NOT EXISTS manual_bank_transactions_recorded ON manual_bank_transactions(recorded_at DESC,id);
CREATE UNIQUE INDEX IF NOT EXISTS company_bank_successor ON company_bank_accounts(supersedes_id) WHERE supersedes_id IS NOT NULL;
COMMIT;
PRAGMA foreign_keys=ON;
