CREATE TABLE IF NOT EXISTS portal_schema_migrations (
  version TEXT PRIMARY KEY NOT NULL,
  applied_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS portal_status_snapshots (
  migration_version TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_key TEXT NOT NULL,
  row_data TEXT NOT NULL,
  captured_at INTEGER NOT NULL,
  PRIMARY KEY(migration_version, entity_type, entity_key)
);
CREATE INDEX IF NOT EXISTS portal_status_snapshot_key ON portal_status_snapshots(migration_version, entity_type, entity_key);
ALTER TABLE game_visibility ADD COLUMN category_override TEXT NOT NULL DEFAULT '';
CREATE TABLE IF NOT EXISTS brand_directory_entries (
  id TEXT PRIMARY KEY NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('SLOT','FAST GAME','LIVE','FISH','SPORT','OTHERS')),
  display_name TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  marked INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('suspended','active','closed')),
  image_data TEXT NOT NULL DEFAULT '',
  updated_by TEXT REFERENCES users(id),
  updated_at INTEGER NOT NULL DEFAULT 0,
  UNIQUE(category, display_name)
);
CREATE INDEX IF NOT EXISTS brand_directory_order ON brand_directory_entries(category, position);

INSERT INTO portal_status_snapshots(migration_version,entity_type,entity_key,row_data,captured_at)
SELECT '0012-close-defaults-and-brand-directory','game_visibility',provider_id || ':' || game_code,json_object('status',status,'visible',visible),CAST(strftime('%s','now') AS INTEGER) FROM game_visibility;
INSERT INTO portal_status_snapshots(migration_version,entity_type,entity_key,row_data,captured_at)
SELECT '0012-close-defaults-and-brand-directory','custom_game_cards',id,json_object('status',status,'enabled',enabled),CAST(strftime('%s','now') AS INTEGER) FROM custom_game_cards;
INSERT INTO portal_status_snapshots(migration_version,entity_type,entity_key,row_data,captured_at)
SELECT '0012-close-defaults-and-brand-directory','payment_channel_controls',provider_id,json_object('status',status),CAST(strftime('%s','now') AS INTEGER) FROM payment_channel_controls;
INSERT INTO portal_status_snapshots(migration_version,entity_type,entity_key,row_data,captured_at)
SELECT '0012-close-defaults-and-brand-directory','providers',id,json_object('visible',visible),CAST(strftime('%s','now') AS INTEGER) FROM providers;

UPDATE game_visibility SET status='closed',visible=0;
UPDATE custom_game_cards SET status='closed',enabled=0;
UPDATE payment_channel_controls SET status='closed';
UPDATE providers SET visible=1 WHERE id IN ('jili','megah5','918kissh5');
INSERT INTO brand_directory_entries(id,category,display_name,position,marked,status,image_data,updated_at) VALUES
('slot:3win8','SLOT','3WIN8',0,0,'closed','',0),
('slot:5g-games','SLOT','5G GAMES',1,0,'closed','',0),
('slot:918kaya','SLOT','918KAYA',2,1,'closed','',0),
('slot:918kiss','SLOT','918KISS',3,1,'closed','',0),
('slot:918kiss-h5','SLOT','918KISS H5',4,1,'closed','',0),
('slot:ace333','SLOT','ACE333',5,0,'closed','',0),
('slot:acewin','SLOT','ACEWIN',6,0,'closed','',0),
('slot:advantplay','SLOT','ADVANTPLAY',7,1,'closed','',0),
('slot:astar','SLOT','ASTAR',8,0,'closed','',0),
('slot:boongo','SLOT','BOONGO',9,0,'closed','',0),
('slot:bt-gaming','SLOT','BT GAMING',10,1,'closed','',0),
('slot:clotplay','SLOT','CLOTPLAY',11,1,'closed','',0),
('slot:cq9','SLOT','CQ9',12,0,'closed','',0),
('slot:dragoon-soft','SLOT','DRAGOON SOFT',13,0,'closed','',0),
('slot:epicwin','SLOT','EPICWIN',14,0,'closed','',0),
('slot:evo888','SLOT','EVO888',15,0,'closed','',0),
('slot:evo888h5','SLOT','EVO888H5',16,1,'closed','',0),
('slot:fachai','SLOT','FACHAI',17,1,'closed','',0),
('slot:greatwall99','SLOT','GREATWALL99',18,1,'closed','',0),
('slot:jdb','SLOT','JDB',19,1,'closed','',0),
('slot:jili00','SLOT','JILI00',20,1,'closed','',0),
('slot:joker','SLOT','JOKER',21,1,'closed','',0),
('slot:ka-gaming','SLOT','KA GAMING',22,1,'closed','',0),
('slot:lfc888','SLOT','LFC888',23,1,'closed','',0),
('slot:live22','SLOT','LIVE22',24,0,'closed','',0),
('slot:lucky365','SLOT','LUCKY365',25,1,'closed','',0),
('slot:mario-club','SLOT','MARIO CLUB',26,1,'closed','',0),
('slot:mega888','SLOT','MEGA888',27,1,'closed','',0),
('slot:megah5','SLOT','MEGAH5',28,1,'closed','',0),
('slot:meta-gaming','SLOT','META GAMING',29,1,'closed','',0),
('slot:microgaming','SLOT','MICROGAMING',30,1,'closed','',0),
('slot:next-spin','SLOT','NEXT SPIN',31,1,'closed','',0),
('slot:pegasus','SLOT','PEGASUS',32,0,'closed','',0),
('slot:playstar','SLOT','PLAYSTAR',33,0,'closed','',0),
('slot:playtech','SLOT','PLAYTECH',34,0,'closed','',0),
('slot:pragmatic-play','SLOT','PRAGMATIC PLAY',35,1,'closed','',0),
('slot:pussy888','SLOT','PUSSY888',36,0,'closed','',0),
('slot:pxplay','SLOT','PXPLAY',37,0,'closed','',0),
('slot:relax-gaming','SLOT','RELAX GAMING',38,1,'closed','',0),
('slot:rich-gaming','SLOT','RICH GAMING',39,0,'closed','',0),
('slot:rich88','SLOT','RICH88',40,0,'closed','',0),
('slot:royal-slot-gaming','SLOT','ROYAL SLOT GAMING',41,1,'closed','',0),
('slot:spade-gaming','SLOT','SPADE GAMING',42,0,'closed','',0),
('slot:suncity','SLOT','SUNCITY',43,0,'closed','',0),
('slot:vpower','SLOT','VPOWER',44,1,'closed','',0),
('slot:xe88','SLOT','XE88',45,1,'closed','',0),
('slot:ygr','SLOT','YGR',46,0,'closed','',0),
('fast-game:elotto','FAST GAME','ELOTTO',0,1,'closed','',0),
('fast-game:spribe','FAST GAME','SPRIBE',1,1,'closed','',0),
('live:allbet','LIVE','ALLBET',0,1,'closed','',0),
('live:bbin','LIVE','BBIN',1,0,'closed','',0),
('live:big-gaming','LIVE','BIG GAMING',2,1,'closed','',0),
('live:ct855','LIVE','CT855',3,1,'closed','',0),
('live:evolution','LIVE','EVOLUTION',4,1,'closed','',0),
('live:gameplay-interactive','LIVE','GAMEPLAY INTERACTIVE',5,0,'closed','',0),
('live:microgaming','LIVE','MICROGAMING',6,1,'closed','',0),
('live:playtech','LIVE','PLAYTECH',7,1,'closed','',0),
('live:pragmatic-play','LIVE','PRAGMATIC PLAY',8,1,'closed','',0),
('live:sa-gaming','LIVE','SA GAMING',9,0,'closed','',0),
('live:awc-sexy-baccarat','LIVE','AWC SEXY BACCARAT',10,1,'closed','',0),
('live:wm-casino','LIVE','WM CASINO',11,0,'closed','',0),
('live:yeebet','LIVE','YEEBET',12,0,'closed','',0),
('fish:bt-gaming','FISH','BT GAMING',0,1,'closed','',0),
('fish:jdb','FISH','JDB',1,0,'closed','',0),
('fish:jili00','FISH','JILI00',2,1,'closed','',0),
('fish:joker','FISH','JOKER',3,1,'closed','',0),
('fish:ka-gaming','FISH','KA GAMING',4,0,'closed','',0),
('fish:spade-gaming','FISH','SPADE GAMING',5,0,'closed','',0),
('fish:youlian-gaming','FISH','YOULIAN GAMING',6,0,'closed','',0),
('sport:ae-esport','SPORT','AE ESPORT',0,1,'closed','',0),
('sport:ia-e-sport','SPORT','IA E-SPORT',1,0,'closed','',0),
('sport:ibc-bet','SPORT','IBC BET',2,1,'closed','',0),
('sport:m8bet','SPORT','M8BET',3,1,'closed','',0),
('sport:sbobet','SPORT','SBOBET',4,1,'closed','',0),
('others:lottery-4d-lottery','OTHERS','LOTTERY (4D LOTTERY)',0,1,'closed','',0),
('others:awc-sv388','OTHERS','AWC SV388',1,1,'closed','',0);
INSERT INTO portal_schema_migrations(version,applied_at)
VALUES('0012-close-defaults-and-brand-directory',CAST(strftime('%s','now') AS INTEGER));
