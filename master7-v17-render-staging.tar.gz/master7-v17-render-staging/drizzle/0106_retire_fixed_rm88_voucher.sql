-- Retire the former fixed promotion without deleting historical audit records.
UPDATE benefit_rules SET status='draft',updated_at=unixepoch()
WHERE id='new-member-rm88-sponsored';
