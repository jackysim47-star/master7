-- Retained as a historical migration. Fixed-value promotions are owner-managed
-- and are no longer seeded by the platform.
UPDATE benefit_rules SET status='draft',updated_at=unixepoch()
WHERE id='new-member-rm88-sponsored';
