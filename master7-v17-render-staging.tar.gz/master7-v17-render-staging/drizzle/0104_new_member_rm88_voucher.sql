INSERT INTO benefit_rules(id,title,description,rules_json,status,created_by,created_at,updated_at)
SELECT
  'new-member-rm88-sponsored',
  'RM88 FREE · Up to 5 Plays',
  'New approved member: choose JILI, MegaH5 or 918KISS. RM88 free credit allows up to 5 plays; the first win ends all remaining free plays. After RM1,760 reviewed turnover, MASTER7 company pays up to RM50 to the member. One eligibility request per member.',
  json_object(
    'currency','MYR',
    'providerId','all',
    'sponsoredProviderIds',json_array('jili','megah5','918kissh5'),
    'campaignKey','new_member_rm88_sponsored_v1',
    'campaignStartsAt',unixepoch(),
    'rewardType','free_credit',
    'rewardAmountMYR',88,
    'rewardPercent',NULL,
    'minDepositMYR',0,
    'maxRewardMYR',88,
    'turnoverMultiplier',NULL,
    'turnoverBase','bonus',
    'turnoverRequiredMYR',1760,
    'withdrawalCapMYR',50,
    'freeChances',5,
    'stopFreeChancesOnFirstWin',json('true'),
    'newMemberOnly',json('true'),
    'lifetimeClaimLimit',json('true'),
    'claimLimitPerMember',1,
    'validityDays',30
  ),
  'active',
  owner.id,
  unixepoch(),
  unixepoch()
FROM users AS owner
WHERE owner.role='owner'
ORDER BY owner.created_at,owner.id
LIMIT 1
ON CONFLICT(id) DO NOTHING;
