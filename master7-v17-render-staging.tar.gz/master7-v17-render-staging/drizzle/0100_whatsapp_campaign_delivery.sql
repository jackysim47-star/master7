ALTER TABLE marketing_campaigns ADD COLUMN provider TEXT NOT NULL DEFAULT 'unconfigured';
ALTER TABLE marketing_campaigns ADD COLUMN template_name TEXT NOT NULL DEFAULT '';
ALTER TABLE marketing_campaigns ADD COLUMN template_language TEXT NOT NULL DEFAULT '';
ALTER TABLE marketing_campaigns ADD COLUMN template_params_json TEXT NOT NULL DEFAULT '{}';
ALTER TABLE marketing_campaigns ADD COLUMN audience_count INTEGER NOT NULL DEFAULT 0 CHECK (audience_count >= 0);
ALTER TABLE marketing_campaigns ADD COLUMN started_at BIGINT;
ALTER TABLE marketing_campaigns ADD COLUMN completed_at BIGINT;

-- SQLite cannot widen a CHECK constraint in place. Rebuild the delivery table
-- while preserving every existing campaign/contact row and provider message id.
CREATE TABLE marketing_deliveries_next (
  campaign_id TEXT NOT NULL REFERENCES marketing_campaigns(id) ON DELETE CASCADE,
  contact_id TEXT NOT NULL REFERENCES marketing_contacts(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','submitting','unknown','sent','delivered','read','failed','opted_out')),
  provider_message_id TEXT,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  claim_token TEXT,
  locked_until BIGINT NOT NULL DEFAULT 0,
  next_attempt_at BIGINT NOT NULL DEFAULT 0,
  provider_error_code TEXT,
  submitted_at BIGINT,
  sent_at BIGINT,
  delivered_at BIGINT,
  read_at BIGINT,
  failed_at BIGINT,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (campaign_id,contact_id)
);

INSERT INTO marketing_deliveries_next(
  campaign_id,contact_id,status,provider_message_id,attempts,updated_at
)
SELECT campaign_id,contact_id,status,provider_message_id,attempts,updated_at
FROM marketing_deliveries;

DROP TABLE marketing_deliveries;
ALTER TABLE marketing_deliveries_next RENAME TO marketing_deliveries;

CREATE INDEX marketing_deliveries_status
  ON marketing_deliveries(campaign_id,status,updated_at);
CREATE INDEX marketing_deliveries_due
  ON marketing_deliveries(status,next_attempt_at,locked_until,updated_at);
CREATE UNIQUE INDEX marketing_deliveries_provider_message
  ON marketing_deliveries(provider_message_id)
  WHERE provider_message_id IS NOT NULL;

CREATE TABLE marketing_webhook_events (
  event_key TEXT PRIMARY KEY NOT NULL,
  provider_message_id TEXT,
  event_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT '',
  payload_hash TEXT NOT NULL,
  received_at BIGINT NOT NULL
);
CREATE INDEX marketing_webhook_events_message
  ON marketing_webhook_events(provider_message_id,received_at);
