CREATE TABLE IF NOT EXISTS game_provider_profiles (
  id TEXT PRIMARY KEY NOT NULL,
  provider_id TEXT NOT NULL,
  display_name TEXT NOT NULL,
  adapter_key TEXT NOT NULL,
  wallet_mode TEXT NOT NULL CHECK (wallet_mode IN ('transfer','seamless')),
  balance_class TEXT NOT NULL CHECK (balance_class IN ('cash','free_credit')),
  currency TEXT NOT NULL CHECK (length(currency) BETWEEN 3 AND 8),
  unit_numerator BIGINT NOT NULL DEFAULT 1 CHECK (unit_numerator > 0),
  unit_denominator BIGINT NOT NULL DEFAULT 1 CHECK (unit_denominator > 0),
  environment TEXT NOT NULL CHECK (environment IN ('uat','production')),
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('closed','uat','active','maintenance')),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS game_provider_profiles_provider ON game_provider_profiles(provider_id,status,id);

CREATE TABLE IF NOT EXISTS game_provider_players (
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  provider_player_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','blocked','review')),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  verified_at BIGINT,
  PRIMARY KEY(profile_id,user_id),
  UNIQUE(profile_id,provider_player_id)
);
CREATE INDEX IF NOT EXISTS game_provider_players_user ON game_provider_players(user_id,profile_id);

CREATE TABLE IF NOT EXISTS game_provider_sessions (
  id TEXT PRIMARY KEY NOT NULL,
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  provider_player_id TEXT NOT NULL,
  game_code TEXT NOT NULL,
  provider_game_id TEXT NOT NULL,
  provider_session_id TEXT,
  request_key TEXT NOT NULL,
  request_fingerprint TEXT NOT NULL,
  wallet_mode TEXT NOT NULL CHECK (wallet_mode IN ('transfer','seamless')),
  currency TEXT NOT NULL CHECK (length(currency) BETWEEN 3 AND 8),
  status TEXT NOT NULL CHECK (status IN ('prepared','launching','active','settling','settled','failed','unknown','review')),
  last_error_code TEXT NOT NULL DEFAULT '',
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  closed_at BIGINT,
  FOREIGN KEY(profile_id,user_id) REFERENCES game_provider_players(profile_id,user_id),
  UNIQUE(profile_id,request_key),
  UNIQUE(id,profile_id,user_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS game_provider_sessions_provider_session ON game_provider_sessions(profile_id,provider_session_id) WHERE provider_session_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS game_provider_sessions_one_open ON game_provider_sessions(user_id,profile_id) WHERE status IN ('prepared','launching','active','settling','unknown','review');
CREATE INDEX IF NOT EXISTS game_provider_sessions_updated ON game_provider_sessions(profile_id,status,updated_at,id);

CREATE TABLE IF NOT EXISTS game_wallet_transfers (
  id TEXT PRIMARY KEY NOT NULL,
  session_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('deposit','withdrawal')),
  request_key TEXT NOT NULL,
  request_fingerprint TEXT NOT NULL,
  provider_reference TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (length(currency) BETWEEN 3 AND 8),
  status TEXT NOT NULL CHECK (status IN ('prepared','submitting','unknown','succeeded','failed','review','reversed')),
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  last_error_code TEXT NOT NULL DEFAULT '',
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  completed_at BIGINT,
  FOREIGN KEY(session_id,profile_id,user_id) REFERENCES game_provider_sessions(id,profile_id,user_id),
  UNIQUE(profile_id,request_key),
  UNIQUE(profile_id,provider_reference)
);
CREATE INDEX IF NOT EXISTS game_wallet_transfers_recovery ON game_wallet_transfers(profile_id,status,updated_at,id);
CREATE INDEX IF NOT EXISTS game_wallet_transfers_session ON game_wallet_transfers(session_id,created_at,id);

CREATE TABLE IF NOT EXISTS game_rounds (
  id TEXT PRIMARY KEY NOT NULL,
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  session_id TEXT,
  provider_round_id TEXT NOT NULL,
  provider_game_id TEXT NOT NULL,
  currency TEXT NOT NULL CHECK (length(currency) BETWEEN 3 AND 8),
  status TEXT NOT NULL CHECK (status IN ('open','settled','rolled_back','reopened','review')),
  total_bet_minor BIGINT NOT NULL DEFAULT 0 CHECK (total_bet_minor >= 0),
  total_win_minor BIGINT NOT NULL DEFAULT 0 CHECK (total_win_minor >= 0),
  opened_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  closed_at BIGINT,
  FOREIGN KEY(session_id,profile_id,user_id) REFERENCES game_provider_sessions(id,profile_id,user_id),
  UNIQUE(profile_id,provider_round_id),
  UNIQUE(id,profile_id,user_id)
);
CREATE INDEX IF NOT EXISTS game_rounds_user_updated ON game_rounds(user_id,updated_at,id);
CREATE INDEX IF NOT EXISTS game_rounds_profile_status ON game_rounds(profile_id,status,updated_at,id);

CREATE TABLE IF NOT EXISTS game_transactions (
  id TEXT PRIMARY KEY NOT NULL,
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  round_id TEXT NOT NULL,
  provider_transaction_id TEXT NOT NULL,
  parent_transaction_id TEXT REFERENCES game_transactions(id),
  parent_provider_transaction_id TEXT,
  event_type TEXT NOT NULL CHECK (event_type IN ('debit','credit','refund','rollback','adjustment','resettlement','transfer_result')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor >= 0),
  currency TEXT NOT NULL CHECK (length(currency) BETWEEN 3 AND 8),
  request_fingerprint TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('received','applied','duplicate','rejected','review')),
  provider_occurred_at BIGINT,
  received_at BIGINT NOT NULL,
  applied_at BIGINT,
  FOREIGN KEY(round_id,profile_id,user_id) REFERENCES game_rounds(id,profile_id,user_id),
  UNIQUE(profile_id,provider_transaction_id),
  UNIQUE(id,profile_id,user_id)
);
CREATE INDEX IF NOT EXISTS game_transactions_round ON game_transactions(round_id,received_at,id);
CREATE INDEX IF NOT EXISTS game_transactions_profile_status ON game_transactions(profile_id,status,received_at,id);

CREATE TABLE IF NOT EXISTS game_wallet_postings (
  id TEXT PRIMARY KEY NOT NULL,
  transaction_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  account_code TEXT NOT NULL CHECK (account_code IN ('member','provider_game_clearing')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor <> 0),
  currency TEXT NOT NULL CHECK (length(currency) BETWEEN 3 AND 8),
  created_at BIGINT NOT NULL,
  FOREIGN KEY(transaction_id,profile_id,user_id) REFERENCES game_transactions(id,profile_id,user_id),
  UNIQUE(transaction_id,account_code)
);
CREATE INDEX IF NOT EXISTS game_wallet_postings_user ON game_wallet_postings(user_id,currency,created_at,id);
CREATE INDEX IF NOT EXISTS game_wallet_postings_profile ON game_wallet_postings(profile_id,created_at,id);

CREATE TABLE IF NOT EXISTS game_callback_receipts (
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  event_key TEXT NOT NULL,
  provider_event_id TEXT,
  callback_type TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  payload_redacted_json TEXT NOT NULL DEFAULT '{}',
  signature_status TEXT NOT NULL CHECK (signature_status IN ('valid','invalid','not_applicable','unverified')),
  processing_status TEXT NOT NULL CHECK (processing_status IN ('received','processed','duplicate','rejected','review')),
  last_error_code TEXT NOT NULL DEFAULT '',
  received_at BIGINT NOT NULL,
  processed_at BIGINT,
  PRIMARY KEY(profile_id,event_key)
);
CREATE UNIQUE INDEX IF NOT EXISTS game_callback_receipts_provider_event ON game_callback_receipts(profile_id,provider_event_id,callback_type) WHERE provider_event_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS game_callback_receipts_status ON game_callback_receipts(profile_id,processing_status,received_at,event_key);

CREATE TABLE IF NOT EXISTS game_wager_sync_cursors (
  profile_id TEXT PRIMARY KEY NOT NULL REFERENCES game_provider_profiles(id),
  cursor_value TEXT NOT NULL DEFAULT '',
  watermark_at BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'idle' CHECK (status IN ('idle','syncing','review')),
  last_error_code TEXT NOT NULL DEFAULT '',
  last_success_at BIGINT NOT NULL DEFAULT 0,
  updated_at BIGINT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS game_recovery_leases (
  profile_id TEXT NOT NULL REFERENCES game_provider_profiles(id),
  resource_type TEXT NOT NULL CHECK (resource_type IN ('session','transfer','transaction','wager_sync')),
  resource_id TEXT NOT NULL,
  claim_token TEXT NOT NULL DEFAULT '',
  locked_until BIGINT NOT NULL DEFAULT 0,
  last_checked_at BIGINT NOT NULL DEFAULT 0,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  PRIMARY KEY(profile_id,resource_type,resource_id)
);
CREATE INDEX IF NOT EXISTS game_recovery_leases_due ON game_recovery_leases(profile_id,resource_type,locked_until,last_checked_at,resource_id);
