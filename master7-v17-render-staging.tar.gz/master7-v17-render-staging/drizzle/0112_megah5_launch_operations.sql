-- Durable local evidence of a provider launch.  This is not a provider session
-- closure signal and never stores a game URL, bearer token or credentials.
CREATE UNIQUE INDEX IF NOT EXISTS game_wallet_session_identity ON game_wallet_sessions(id,user_id,game_code);
CREATE TABLE IF NOT EXISTS megah5_launch_operations (
 id TEXT PRIMARY KEY NOT NULL,
 wallet_session_id TEXT NOT NULL UNIQUE,
 user_id TEXT NOT NULL REFERENCES users(id),
 game_code TEXT NOT NULL,
 state TEXT NOT NULL CHECK (state IN ('launching','issued','unknown','closed')),
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL,
 last_error TEXT NOT NULL DEFAULT '',
 FOREIGN KEY (wallet_session_id,user_id,game_code) REFERENCES game_wallet_sessions(id,user_id,game_code)
);
CREATE INDEX IF NOT EXISTS megah5_launch_operations_user_state ON megah5_launch_operations(user_id,state);
