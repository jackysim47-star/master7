CREATE TABLE IF NOT EXISTS game_visibility (
  provider_id TEXT NOT NULL,
  game_code TEXT NOT NULL,
  visible INTEGER NOT NULL DEFAULT 1,
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (provider_id, game_code)
);
CREATE INDEX IF NOT EXISTS game_visibility_key ON game_visibility(provider_id, game_code);
