CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  provider_id TEXT NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay','gspay_plus')),
  provider_name TEXT NOT NULL,
  bank_code TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_holder_encrypted TEXT NOT NULL,
  account_number_encrypted TEXT NOT NULL,
  account_last4 TEXT NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  status TEXT NOT NULL CHECK (status IN ('pending','approved','processing','paid','rejected','cancelled')),
  owner_note TEXT NOT NULL DEFAULT '',
  updated_by TEXT REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key)
);
CREATE INDEX IF NOT EXISTS withdrawal_requests_user_created ON withdrawal_requests(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS withdrawal_requests_status_created ON withdrawal_requests(status,created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS withdrawal_one_open_per_member ON withdrawal_requests(user_id) WHERE status IN ('pending','approved','processing');
