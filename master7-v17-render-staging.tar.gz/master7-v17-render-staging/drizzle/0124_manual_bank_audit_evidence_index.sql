CREATE INDEX IF NOT EXISTS audit_manual_bank_payout_paid_evidence
  ON audit(target,user_id,created_at)
  WHERE event='manual_bank_payout_paid';
