CREATE TABLE IF NOT EXISTS deposit_orders (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  provider TEXT NOT NULL CHECK (provider = 'vpay'),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 10000000),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  trade_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','creating','created','unknown','credited','review','failed')),
  provider_trade_no TEXT,
  checkout_url TEXT,
  expires_at_raw TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id, request_key),
  UNIQUE(provider, provider_trade_no)
);
CREATE INDEX IF NOT EXISTS deposit_orders_user_created ON deposit_orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS deposit_orders_status_created ON deposit_orders(status, created_at);

CREATE TABLE IF NOT EXISTS wallet_ledger (
  id TEXT PRIMARY KEY NOT NULL,
  order_id TEXT NOT NULL REFERENCES deposit_orders(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  account_code TEXT NOT NULL CHECK (account_code IN ('member','provider_clearing')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor <> 0),
  currency TEXT NOT NULL CHECK (currency = 'MYR'),
  created_at BIGINT NOT NULL,
  UNIQUE(order_id, account_code)
);
CREATE INDEX IF NOT EXISTS wallet_ledger_user_created ON wallet_ledger(user_id, created_at DESC);
