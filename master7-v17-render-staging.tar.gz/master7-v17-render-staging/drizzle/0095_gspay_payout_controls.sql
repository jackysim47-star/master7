CREATE TABLE IF NOT EXISTS provider_payout_controls_next (
  provider_id TEXT PRIMARY KEY NOT NULL CHECK (provider_id IN ('vpay','gspay','1mpay')),
  submission_enabled INTEGER NOT NULL DEFAULT 0 CHECK (submission_enabled=0 OR (provider_id='gspay' AND submission_enabled=1)),
  updated_at BIGINT NOT NULL DEFAULT 0
);
INSERT OR REPLACE INTO provider_payout_controls_next(provider_id,submission_enabled,updated_at)
SELECT provider_id,submission_enabled,updated_at FROM provider_payout_controls;
DROP TABLE provider_payout_controls;
ALTER TABLE provider_payout_controls_next RENAME TO provider_payout_controls;
INSERT INTO provider_payout_controls(provider_id,submission_enabled,updated_at)
VALUES ('vpay',0,0),('gspay',0,0),('1mpay',0,0)
ON CONFLICT(provider_id) DO NOTHING;
