CREATE TABLE IF NOT EXISTS wallet_reservations (
 user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id),
 kind TEXT NOT NULL CHECK (kind IN ('withdrawal','game')),
 reference_id TEXT NOT NULL UNIQUE,
 amount_minor BIGINT NOT NULL CHECK (amount_minor>0),
 created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS wallet_reservations_created ON wallet_reservations(created_at,user_id);

INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at)
 SELECT user_id,'game',id,amount_out_minor,created_at FROM game_wallet_sessions
 WHERE status IN ('deposit_pending','deposit_unknown','active','withdraw_pending','withdraw_unknown','manual_review')
 ON CONFLICT DO NOTHING;
INSERT INTO wallet_reservations(user_id,kind,reference_id,amount_minor,created_at)
 SELECT user_id,'withdrawal',id,amount_minor,created_at FROM withdrawal_requests
 WHERE status IN ('pending','approved','processing')
 ON CONFLICT DO NOTHING;
