CREATE TABLE IF NOT EXISTS public_contact_revisions (
  id TEXT PRIMARY KEY NOT NULL,
  revision INTEGER NOT NULL UNIQUE CHECK (revision > 0),
  configuration TEXT NOT NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL CHECK (created_at >= 0)
);

CREATE INDEX IF NOT EXISTS public_contact_revisions_created
  ON public_contact_revisions(revision DESC, created_at DESC);

CREATE TRIGGER IF NOT EXISTS public_contact_revisions_no_update
BEFORE UPDATE ON public_contact_revisions
BEGIN
  SELECT RAISE(ABORT, 'contact revision history is immutable');
END;

CREATE TRIGGER IF NOT EXISTS public_contact_revisions_no_delete
BEFORE DELETE ON public_contact_revisions
BEGIN
  SELECT RAISE(ABORT, 'contact revision history is immutable');
END;
