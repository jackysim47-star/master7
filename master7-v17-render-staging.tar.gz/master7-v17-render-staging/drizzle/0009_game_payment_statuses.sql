ALTER TABLE game_visibility ADD COLUMN status TEXT NOT NULL DEFAULT 'active';
--> statement-breakpoint
ALTER TABLE custom_game_cards ADD COLUMN status TEXT NOT NULL DEFAULT 'active';
--> statement-breakpoint
UPDATE custom_game_cards SET status='closed' WHERE enabled=0;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS payment_channel_controls (
  provider_id TEXT PRIMARY KEY NOT NULL,
  provider_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'suspended' CHECK (status IN ('suspended','active','closed')),
  updated_by TEXT NOT NULL DEFAULT 'system',
  updated_at INTEGER NOT NULL DEFAULT 0
);
--> statement-breakpoint
INSERT INTO payment_channel_controls(provider_id,provider_name,status) VALUES
 ('vpay','VPay','suspended'),('gspay','GSPAY','suspended'),('1mpay','1MPAY','suspended'),('gspay_plus','GSPAY+','suspended')
ON CONFLICT(provider_id) DO NOTHING;
