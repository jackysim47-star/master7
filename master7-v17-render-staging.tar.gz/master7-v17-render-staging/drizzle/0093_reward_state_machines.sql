-- Financial automation remains fail-closed. These tables persist previews,
-- claim intents and future turnover/wallet work without changing balances.
CREATE TABLE IF NOT EXISTS benefit_claims (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  benefit_rule_id TEXT NOT NULL,
  request_key TEXT NOT NULL,
  deposit_order_id TEXT REFERENCES deposit_orders(id),
  rules_snapshot_json TEXT NOT NULL,
  deposit_minor BIGINT NOT NULL DEFAULT 0 CHECK (deposit_minor >= 0),
  reward_minor BIGINT NOT NULL CHECK (reward_minor > 0),
  turnover_required_minor BIGINT NOT NULL DEFAULT 0 CHECK (turnover_required_minor >= 0),
  expires_at BIGINT NOT NULL,
  status TEXT NOT NULL DEFAULT 'awaiting_acceptance' CHECK (status IN ('awaiting_acceptance','rejected','expired','cancelled')),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status IN ('disabled','pending_acceptance')),
  turnover_source_status TEXT NOT NULL DEFAULT 'not_connected' CHECK (turnover_source_status IN ('not_connected','pending_acceptance')),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(user_id,request_key)
);
CREATE INDEX IF NOT EXISTS benefit_claims_user_created ON benefit_claims(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS benefit_claims_rule_status ON benefit_claims(benefit_rule_id,status,created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS benefit_claims_one_per_deposit
  ON benefit_claims(user_id,benefit_rule_id,deposit_order_id)
  WHERE deposit_order_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS commission_periods (
  id TEXT PRIMARY KEY NOT NULL,
  settings_hash TEXT NOT NULL,
  settings_snapshot_json TEXT NOT NULL,
  basis TEXT NOT NULL CHECK (basis IN ('deposit','turnover','company_profit')),
  frequency TEXT NOT NULL CHECK (frequency IN ('daily','weekly_mon','monthly')),
  period_start BIGINT NOT NULL,
  period_end BIGINT NOT NULL,
  total_basis_minor BIGINT NOT NULL DEFAULT 0 CHECK (total_basis_minor >= 0),
  total_commission_minor BIGINT NOT NULL DEFAULT 0 CHECK (total_commission_minor >= 0),
  status TEXT NOT NULL DEFAULT 'preview' CHECK (status IN ('preview','disabled','unsupported')),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status='disabled'),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(settings_hash,period_start,period_end)
);
CREATE INDEX IF NOT EXISTS commission_periods_latest ON commission_periods(period_end DESC,updated_at DESC);

CREATE TABLE IF NOT EXISTS commission_entries (
  id TEXT PRIMARY KEY NOT NULL,
  period_id TEXT NOT NULL REFERENCES commission_periods(id),
  upline_user_id TEXT NOT NULL REFERENCES users(id),
  source_user_id TEXT NOT NULL REFERENCES users(id),
  level INTEGER NOT NULL CHECK (level BETWEEN 1 AND 3),
  rate_basis_points INTEGER NOT NULL CHECK (rate_basis_points BETWEEN 0 AND 10000),
  basis_minor BIGINT NOT NULL CHECK (basis_minor >= 0),
  commission_minor BIGINT NOT NULL CHECK (commission_minor > 0),
  available_at BIGINT NOT NULL,
  expires_at BIGINT,
  status TEXT NOT NULL DEFAULT 'preview' CHECK (status='preview'),
  wallet_credit_status TEXT NOT NULL DEFAULT 'disabled' CHECK (wallet_credit_status='disabled'),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(period_id,upline_user_id,source_user_id,level)
);
CREATE INDEX IF NOT EXISTS commission_entries_upline ON commission_entries(upline_user_id,period_id,level);

CREATE TABLE IF NOT EXISTS turnover_obligations (
  id TEXT PRIMARY KEY NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN ('benefit','commission')),
  source_id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  required_minor BIGINT NOT NULL CHECK (required_minor >= 0),
  completed_minor BIGINT NOT NULL DEFAULT 0 CHECK (completed_minor=0),
  wager_source_status TEXT NOT NULL DEFAULT 'not_connected' CHECK (wager_source_status='not_connected'),
  status TEXT NOT NULL DEFAULT 'blocked' CHECK (status='blocked'),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS turnover_obligations_user ON turnover_obligations(user_id,status,created_at DESC);

CREATE TABLE IF NOT EXISTS wallet_posting_intents (
  id TEXT PRIMARY KEY NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN ('benefit','commission')),
  source_id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  account_bucket TEXT NOT NULL CHECK (account_bucket IN ('bonus','commission')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  idempotency_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'disabled' CHECK (status='disabled'),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS wallet_posting_intents_user ON wallet_posting_intents(user_id,status,created_at DESC);
