CREATE TABLE IF NOT EXISTS lobby_ads (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  image_data TEXT NOT NULL,
  target_url TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS lobby_ads_order ON lobby_ads(enabled, position, created_at);
CREATE TABLE IF NOT EXISTS benefit_rules (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  rules_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS benefit_rules_status ON benefit_rules(status, updated_at);
