ALTER TABLE lobby_ads ADD COLUMN status TEXT NOT NULL DEFAULT 'draft'
  CHECK(status IN ('draft','published'));
ALTER TABLE lobby_ads ADD COLUMN starts_at INTEGER;
ALTER TABLE lobby_ads ADD COLUMN ends_at INTEGER;
UPDATE lobby_ads SET status=CASE WHEN enabled=1 THEN 'published' ELSE 'draft' END;
CREATE INDEX IF NOT EXISTS lobby_ads_publish_window
  ON lobby_ads(status,enabled,starts_at,ends_at,position);

ALTER TABLE announcements ADD COLUMN status TEXT NOT NULL DEFAULT 'draft'
  CHECK(status IN ('draft','published'));
ALTER TABLE announcements ADD COLUMN starts_at INTEGER;
ALTER TABLE announcements ADD COLUMN ends_at INTEGER;
ALTER TABLE announcements ADD COLUMN updated_at INTEGER;
UPDATE announcements SET status='published',updated_at=created_at WHERE updated_at IS NULL;
CREATE INDEX IF NOT EXISTS announcements_publish_window
  ON announcements(status,starts_at,ends_at,created_at);

CREATE TABLE IF NOT EXISTS accounting_daily_snapshots (
  period_start INTEGER PRIMARY KEY NOT NULL,
  period_end INTEGER NOT NULL UNIQUE,
  label TEXT NOT NULL,
  timezone TEXT NOT NULL DEFAULT 'Asia/Kuching',
  report_type TEXT NOT NULL DEFAULT 'settled_cashflow',
  deposit_orders INTEGER NOT NULL,
  deposit_members INTEGER NOT NULL,
  deposit_minor TEXT NOT NULL,
  withdrawal_orders INTEGER NOT NULL,
  withdrawal_members INTEGER NOT NULL,
  withdrawal_minor TEXT NOT NULL,
  net_cashflow_minor TEXT NOT NULL,
  deposit_providers_json TEXT NOT NULL,
  withdrawal_providers_json TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1,
  checksum TEXT NOT NULL,
  closed_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS accounting_daily_closed
  ON accounting_daily_snapshots(closed_at DESC,period_start DESC);

CREATE TABLE IF NOT EXISTS accounting_snapshot_adjustments (
  id TEXT PRIMARY KEY NOT NULL,
  period_start INTEGER NOT NULL REFERENCES accounting_daily_snapshots(period_start),
  revision INTEGER NOT NULL,
  deposit_orders_delta INTEGER NOT NULL,
  deposit_minor_delta TEXT NOT NULL,
  withdrawal_orders_delta INTEGER NOT NULL,
  withdrawal_minor_delta TEXT NOT NULL,
  net_cashflow_minor_delta TEXT NOT NULL,
  detected_at INTEGER NOT NULL,
  details_json TEXT NOT NULL,
  UNIQUE(period_start,revision)
);
CREATE INDEX IF NOT EXISTS accounting_snapshot_adjustment_period
  ON accounting_snapshot_adjustments(period_start,revision);

CREATE TABLE IF NOT EXISTS accounting_late_adjustments (
  id TEXT PRIMARY KEY NOT NULL,
  original_period_start INTEGER NOT NULL REFERENCES accounting_daily_snapshots(period_start),
  source_type TEXT NOT NULL CHECK(source_type IN ('deposit','withdrawal')),
  source_id TEXT NOT NULL,
  provider TEXT NOT NULL,
  amount_minor TEXT NOT NULL,
  settled_at INTEGER NOT NULL,
  detected_at INTEGER NOT NULL,
  UNIQUE(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS accounting_late_adjustment_period
  ON accounting_late_adjustments(original_period_start,settled_at);

CREATE TABLE IF NOT EXISTS accounting_job_runs (
  job_key TEXT PRIMARY KEY NOT NULL,
  period_start INTEGER NOT NULL,
  started_at INTEGER NOT NULL,
  completed_at INTEGER,
  status TEXT NOT NULL CHECK(status IN ('running','completed','failed')),
  result_json TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS accounting_job_status
  ON accounting_job_runs(status,started_at DESC);

CREATE INDEX IF NOT EXISTS deposit_orders_settlement_scan
  ON deposit_orders(status,updated_at);
CREATE INDEX IF NOT EXISTS withdrawal_requests_settlement_scan
  ON withdrawal_requests(status,updated_at);
