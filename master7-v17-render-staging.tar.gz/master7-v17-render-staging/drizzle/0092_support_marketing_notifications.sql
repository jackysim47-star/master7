ALTER TABLE marketing_contacts ADD COLUMN consented_at integer;
ALTER TABLE marketing_contacts ADD COLUMN consent_source text NOT NULL DEFAULT '';
ALTER TABLE marketing_contacts ADD COLUMN consent_proof text NOT NULL DEFAULT '';
ALTER TABLE marketing_contacts ADD COLUMN unsubscribe_token text;
UPDATE marketing_contacts SET unsubscribe_token=lower(hex(randomblob(16))) WHERE unsubscribe_token IS NULL;
CREATE UNIQUE INDEX marketing_contacts_unsubscribe ON marketing_contacts(unsubscribe_token) WHERE unsubscribe_token IS NOT NULL;

CREATE TABLE ticket_reads (
  ticket_id text NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  last_event_at integer NOT NULL,
  last_event_id text NOT NULL,
  updated_at integer NOT NULL,
  PRIMARY KEY (ticket_id,user_id)
);
CREATE INDEX ticket_reads_user ON ticket_reads(user_id,updated_at DESC);
