-- Append-only external production acceptance evidence. The event stream is
-- generic so new provider subjects can be recorded without another schema
-- migration. Only the server-owned canonical requirement list affects the
-- production-ready gate.
CREATE TABLE IF NOT EXISTS production_acceptance_events (
  id TEXT PRIMARY KEY NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('domain','credential','payment','signoff')),
  subject_id TEXT NOT NULL CHECK (length(subject_id) BETWEEN 1 AND 128),
  capability TEXT NOT NULL CHECK (length(capability) BETWEEN 2 AND 64),
  environment TEXT NOT NULL CHECK (environment IN ('uat','production')),
  revision INTEGER NOT NULL CHECK (revision > 0),
  result TEXT NOT NULL CHECK (result IN ('passed','failed','revoked')),
  evidence_sha256 TEXT NOT NULL CHECK (length(evidence_sha256) = 64),
  evidence_reference TEXT NOT NULL CHECK (length(evidence_reference) BETWEEN 1 AND 200),
  verified_by TEXT NOT NULL REFERENCES users(id),
  observed_at BIGINT NOT NULL CHECK (observed_at >= 0),
  recorded_at BIGINT NOT NULL CHECK (recorded_at >= 0),
  UNIQUE(id,category,subject_id,capability,environment),
  UNIQUE(category,subject_id,capability,environment,revision)
);

CREATE INDEX IF NOT EXISTS production_acceptance_events_subject
  ON production_acceptance_events(category,subject_id,environment,capability,recorded_at DESC,id DESC);

CREATE TABLE IF NOT EXISTS production_acceptance_current (
  category TEXT NOT NULL CHECK (category IN ('domain','credential','payment','signoff')),
  subject_id TEXT NOT NULL CHECK (length(subject_id) BETWEEN 1 AND 128),
  capability TEXT NOT NULL CHECK (length(capability) BETWEEN 2 AND 64),
  environment TEXT NOT NULL CHECK (environment IN ('uat','production')),
  event_id TEXT NOT NULL UNIQUE,
  PRIMARY KEY(category,subject_id,capability,environment),
  FOREIGN KEY(event_id,category,subject_id,capability,environment)
    REFERENCES production_acceptance_events(id,category,subject_id,capability,environment)
);

CREATE INDEX IF NOT EXISTS production_acceptance_current_environment
  ON production_acceptance_current(environment,category,subject_id,capability);
