-- Coordination rows are ephemeral: real holds and risk decisions remain in the ledger/session tables.
CREATE TABLE IF NOT EXISTS member_wallet_guards (
 user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id),
 revision BIGINT NOT NULL DEFAULT 0
);
