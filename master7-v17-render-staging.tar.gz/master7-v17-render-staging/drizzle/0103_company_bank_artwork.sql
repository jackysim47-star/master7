ALTER TABLE company_bank_accounts ADD COLUMN image_data TEXT NOT NULL DEFAULT '';
