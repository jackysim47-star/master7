CREATE TABLE IF NOT EXISTS responsible_play_locks (
 user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 touched_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS responsible_play_profiles (
 user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 daily_limit_minor BIGINT CHECK (daily_limit_minor IS NULL OR daily_limit_minor > 0),
 weekly_limit_minor BIGINT CHECK (weekly_limit_minor IS NULL OR weekly_limit_minor > 0),
 monthly_limit_minor BIGINT CHECK (monthly_limit_minor IS NULL OR monthly_limit_minor > 0),
 pending_daily_limit_minor BIGINT CHECK (pending_daily_limit_minor IS NULL OR pending_daily_limit_minor > 0),
 pending_weekly_limit_minor BIGINT CHECK (pending_weekly_limit_minor IS NULL OR pending_weekly_limit_minor > 0),
 pending_monthly_limit_minor BIGINT CHECK (pending_monthly_limit_minor IS NULL OR pending_monthly_limit_minor > 0),
 pending_limits_effective_at BIGINT,
 cooling_off_until BIGINT,
 self_excluded_until BIGINT,
 version INTEGER NOT NULL DEFAULT 1 CHECK (version > 0),
 last_change_id TEXT NOT NULL,
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS responsible_play_active_windows
 ON responsible_play_profiles(cooling_off_until,self_excluded_until);

CREATE TABLE IF NOT EXISTS responsible_play_deposit_reservations (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 request_key TEXT NOT NULL,
 provider TEXT NOT NULL CHECK (provider IN ('vpay','gspay','1mpay','manual_bank')),
 amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
 status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','consumed','released')),
 order_id TEXT REFERENCES deposit_orders(id),
 expires_at BIGINT NOT NULL,
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL,
 PRIMARY KEY(user_id,request_key)
);
CREATE INDEX IF NOT EXISTS responsible_play_reservations_active
 ON responsible_play_deposit_reservations(user_id,status,expires_at);

-- An active member-selected window is irreversible at the database boundary.
-- The trigger protects against future staff tools accidentally adding an override.
CREATE TRIGGER IF NOT EXISTS responsible_play_no_active_window_shortening
BEFORE UPDATE OF cooling_off_until,self_excluded_until ON responsible_play_profiles
FOR EACH ROW
WHEN (
  OLD.cooling_off_until IS NOT NULL
  AND OLD.cooling_off_until > CAST(strftime('%s','now') AS BIGINT)
  AND (NEW.cooling_off_until IS NULL OR NEW.cooling_off_until < OLD.cooling_off_until)
) OR (
  OLD.self_excluded_until IS NOT NULL
  AND OLD.self_excluded_until > CAST(strftime('%s','now') AS BIGINT)
  AND (NEW.self_excluded_until IS NULL OR NEW.self_excluded_until < OLD.self_excluded_until)
)
BEGIN
 SELECT RAISE(ABORT,'RESPONSIBLE_PLAY_ACTIVE_WINDOW_IMMUTABLE');
END;
