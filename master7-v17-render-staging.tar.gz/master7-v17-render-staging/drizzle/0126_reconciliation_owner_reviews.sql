-- Persist canonical reconciliation reports and append-only Owner review notes.
-- These tables contain evidence metadata only. They have no foreign key or
-- trigger capable of posting to a wallet, deposit, payout or acceptance table.
CREATE TABLE IF NOT EXISTS reconciliation_runs (
  run_id TEXT PRIMARY KEY NOT NULL CHECK (length(run_id) = 64),
  report_sha256 TEXT NOT NULL CHECK (length(report_sha256) = 64),
  schema_version TEXT NOT NULL CHECK (schema_version = 'master7-reconciliation-report-v1'),
  source_commit TEXT NOT NULL CHECK (length(source_commit) = 40),
  mapping_version TEXT NOT NULL CHECK (length(mapping_version) BETWEEN 1 AND 200),
  rule_version TEXT NOT NULL CHECK (length(rule_version) BETWEEN 1 AND 200),
  internal_snapshot_id TEXT NOT NULL CHECK (length(internal_snapshot_id) BETWEEN 1 AND 200),
  period_start TEXT NOT NULL,
  period_end_exclusive TEXT NOT NULL,
  result TEXT NOT NULL CHECK (result IN ('incomplete','differences_found','matched_inputs')),
  internal_count INTEGER NOT NULL CHECK (internal_count >= 0),
  external_count INTEGER NOT NULL CHECK (external_count >= 0),
  matched_count INTEGER NOT NULL CHECK (matched_count >= 0),
  discrepancy_count INTEGER NOT NULL CHECK (discrepancy_count >= 0),
  report_json TEXT NOT NULL,
  evidence_reference TEXT NOT NULL CHECK (length(evidence_reference) BETWEEN 1 AND 200),
  recorded_by TEXT NOT NULL REFERENCES users(id),
  recorded_at BIGINT NOT NULL CHECK (recorded_at >= 0)
);

CREATE INDEX IF NOT EXISTS reconciliation_runs_recorded
  ON reconciliation_runs(recorded_at DESC,run_id DESC);

CREATE TABLE IF NOT EXISTS reconciliation_review_events (
  id TEXT PRIMARY KEY NOT NULL,
  run_id TEXT NOT NULL REFERENCES reconciliation_runs(run_id),
  revision INTEGER NOT NULL CHECK (revision > 0),
  decision TEXT NOT NULL CHECK (decision IN ('acknowledged','needs_follow_up')),
  note TEXT NOT NULL CHECK (length(note) BETWEEN 5 AND 500),
  evidence_reference TEXT NOT NULL CHECK (length(evidence_reference) BETWEEN 1 AND 200),
  request_key TEXT NOT NULL CHECK (length(request_key) BETWEEN 16 AND 80),
  reviewed_by TEXT NOT NULL REFERENCES users(id),
  reviewed_at BIGINT NOT NULL CHECK (reviewed_at >= 0),
  UNIQUE(run_id,revision),
  UNIQUE(run_id,request_key)
);

CREATE INDEX IF NOT EXISTS reconciliation_review_events_run
  ON reconciliation_review_events(run_id,revision DESC);
