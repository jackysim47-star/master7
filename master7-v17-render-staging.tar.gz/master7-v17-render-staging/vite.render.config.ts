import { fileURLToPath } from "node:url";
import vinext from "vinext";
import { nitro } from "nitro/vite";
import { defineConfig } from "vite";

export default defineConfig({
  resolve: {
    alias: {
      "cloudflare:workers": fileURLToPath(new URL("./lib/render-env.ts", import.meta.url)),
    },
  },
  plugins: [
    vinext(),
    nitro({
      routeRules: {
        "/assets/**": {
          headers: {
            "cache-control": "public, max-age=86400, stale-while-revalidate=604800",
          },
        },
        "/downloads/**": {
          headers: {
            "cache-control": "public, max-age=31536000, immutable",
          },
        },
        "/service-worker.js": {
          headers: { "cache-control": "no-cache, max-age=0, must-revalidate" },
        },
        "/manifest.webmanifest": {
          headers: { "cache-control": "no-cache, max-age=0, must-revalidate" },
        },
        "/offline.html": {
          headers: { "cache-control": "no-cache, max-age=0, must-revalidate" },
        },
      },
    }),
  ],
});
