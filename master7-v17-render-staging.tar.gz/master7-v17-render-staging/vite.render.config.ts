import { fileURLToPath } from "node:url";
import vinext from "vinext";
import { nitro } from "nitro/vite";
import { defineConfig } from "vite";
import { RENDER_SECURITY_HEADERS } from "./lib/http-security";

export default defineConfig({
  resolve: {
    alias: {
      "cloudflare:workers": fileURLToPath(new URL("./lib/render-env.ts", import.meta.url)),
    },
  },
  plugins: [
    vinext(),
    nitro({
      routeRules: {
        "/**": {
          headers: RENDER_SECURITY_HEADERS,
        },
        "/assets/**": {
          headers: {
            "cache-control": "public, max-age=86400, stale-while-revalidate=604800",
          },
        },
        "/downloads/**": {
          headers: {
            "cache-control": "public, max-age=31536000, immutable",
          },
        },
        "/service-worker.js": {
          headers: { "cache-control": "no-cache, max-age=0, must-revalidate" },
        },
        "/manifest.webmanifest": {
          headers: { "cache-control": "no-cache, max-age=0, must-revalidate" },
        },
        "/offline.html": {
          headers: { "cache-control": "no-cache, max-age=0, must-revalidate" },
        },
      },
    }),
  ],
});
